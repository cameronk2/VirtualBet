// Writes docs/bonus-buy.md from the adapters and the simulated prices.
import fs from 'node:fs';
import { ADAPTERS, NOT_SUPPORTED, defaultConfig } from '../server/games/bonusbuy/buy.js';
import { PRICES } from '../server/games/bonusbuy/prices.js';
import { GAMES } from '../server/games/registry.js';

const cfg = defaultConfig();
const rows = [];
for (const [id, a] of Object.entries(ADAPTERS)) for (const o of a.options) {
  const p = PRICES[id]?.[o.id] || {}, cost = cfg.games[id].options[o.id].cost;
  rows.push(`| ${GAMES[id].label} | ${o.name} | ${o.feature} | ${cost}x | ${p.avg ?? '–'}x ± ${p.se ?? '–'} | ${p.avg ? ((p.avg / cost) * 100).toFixed(1) + '%' : '–'} | ${(p.n ?? 0).toLocaleString()} |`);
}
const md = `# Bonus Buy – universal system, audit and test report

Virtual money only. Every slot with a real bonus round has a Bonus Buy button next to Spin. It opens a menu of
the bonuses that slot actually has, then a confirmation screen (cost, current balance, balance after).

## How it works

* **Price** = total bet × the option's cost multiplier. The server works it out from its own settings at the
  moment of purchase; the screen only shows it. Changing the bet changes the price.
* **The bonus is real.** A purchase plays that slot's own spin, with its own reels and weights, drawn until the
  spin triggers the feature that was bought (a conditional draw: every triggering spin is exactly as likely as
  it would be naturally). Its line wins and the whole bonus that follows are played and paid by the slot's own
  code, through the same screens as a natural trigger. Gong Fortune keeps its own purpose-built buy (it starts
  the bonus directly). No reel, paytable or bonus number changes because a bonus was bought.
* **Atomic and safe.** The debit, the triggering spin and the purchase record happen in one database transaction.
  Each purchase carries a one-time reference, so a repeated tap or resent request is refused and never charged
  twice. Purchases are refused with a bonus already in play, in practice mode, outside the bet range, for an
  option that is switched off, or without enough balance (nothing is taken).
* **Records.** Every purchase is stored (\`bonus_buys\`): slot, bonus, bet, multiplier, price, everything the bonus
  paid, status (in play / settled) and times. Players see them under Account → Bonus buys and in each game's
  menu; the game's own history marks the row as a Bonus Buy; the wallet line reads "<slot> – Bonus Buy: <bonus>".
* **Admin** (Account → Admin: Bonus Buy, for usernames listed in the \`ADMIN_USERS\` environment variable):
  switch Bonus Buy on or off globally, per slot and per option; set each cost multiplier; set the minimum and
  maximum bet; see purchases, money in and out, observed return per option, and the change log. Every saved
  change is validated on the server and logged with who made it.

## Adding a new slot

1. Add an adapter in \`server/games/bonusbuy/adapters.js\`: its options, how to recognise each feature in the
   slot's spin result (\`match\`/\`matchAll\`), \`inBonus(state)\` and, for pick or respin bonuses, \`autoplay\`.
2. Run \`node scripts/sim-bonusbuy.mjs 20000 <game>\` to price it, then \`node scripts/bonusbuy-report.mjs\`.
3. Put \`<SpinBar buy={{ game, onBuy: (b) => { armBuy(b); spin(); } }} …>\` (or \`<BonusBuy …>\`) next to its spin
   button. \`armBuy\` turns the page's next spin request into the purchase, so nothing else on the page changes.

## Prices and theoretical return

Average return = everything a bought bonus pays (its triggering spin plus the whole bonus), in multiples of the
bet, measured by playing that many purchases through the real engines. Default cost = average ÷ 0.96, rounded,
so each option returns about 96% (Gong Fortune keeps its published 50x and 100x prices).

| Slot | Bonus | Starts from | Default cost | Average return | RTP | Bonuses simulated |
| --- | --- | --- | --- | --- | --- | --- |
${rows.join('\n')}

Not available: ${Object.entries(NOT_SUPPORTED).map(([k, v]) => `**${k}** – ${v}`).join(' ')} Lakeside Lures (the
original slot on its own page) is not included yet: it runs on a separate older system.

## Test report

* \`test/bonusbuy.test.js\` (run with \`npm test\`): for every option on every slot it buys through the real
  casino handler and wallet, checks the price (bet × multiplier) at several bets, checks the bought spin really
  triggers that feature, plays the bonus to the end, checks the purchase record equals everything paid and the
  balance equals start − price + winnings, and checks the wallet ledger is continuous. It also checks: not
  enough balance (refused, nothing taken), duplicate reference, bonus already in play, negative / fractional /
  too-large bets, unknown option, a slot with no bonus, bets outside a slot's own list, admin-only settings,
  switching a slot off, an admin price change, the change log, and settings validation.
* Browser check (Chromium, iPhone-size screen) on all 16 slots: opened the menu, read the confirmation (price,
  balance, balance after), confirmed, and saw each slot's own bonus intro start, with the price taken from the
  balance and the purchase recorded. Admin page: changed a price, saved, saw it logged, reset.
* Natural spins are untouched: the full suite (including every slot's own tests) passes.
`;
fs.writeFileSync(new URL('../docs/bonus-buy.md', import.meta.url), md);
console.log('docs/bonus-buy.md written');
