// Searches the estimated land chances so each bonus averages its target.
import { act, init, bonusState } from '../server/games/tigerdragon/engine.js';
import { TUNE } from '../server/games/tigerdragon/config.js';
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const bet = 7500;
function mean(type, runs, seed) {
  const rand = rng(seed); let w = 0, jp = 0;
  for (let i = 0; i < runs; i++) {
    let s = bonusState(type, bet, rand);
    while (s.mode !== 'base') { const r = act(s, 'respin', {}, { rand }); s = r.state; w += r.payout; if (r.out.result?.jackpot) jp++; }
  }
  return [w / runs / bet, jp / runs];
}
const targets = { tiger: ['tigerLand', Number(process.argv[2] || 45)], dragon: ['dragonLand', Number(process.argv[3] || 40)], combined: ['combinedLand', Number(process.argv[4] || 96)] };
for (const [type, [key, target]] of Object.entries(targets)) {
  let lo = 0.01, hi = 0.5;
  for (let it = 0; it < 16; it++) {
    TUNE[key] = (lo + hi) / 2;
    const [m] = mean(type, type === 'combined' ? 6000 : 15000, 7 + it);
    if (m > target) hi = TUNE[key]; else lo = TUNE[key];
  }
  TUNE[key] = +((lo + hi) / 2).toFixed(4);
  const [m, jp] = mean(type, type === 'combined' ? 40000 : 100000, 4242);
  console.log(`${type}: ${key} = ${TUNE[key]}  -> avg ${m.toFixed(1)}x  jackpot 1/${jp ? (1 / jp).toFixed(0) : '-'}`);
}
