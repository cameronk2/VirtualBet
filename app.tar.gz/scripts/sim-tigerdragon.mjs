// Monte Carlo for Gong Fortune: overall RTP, each feature's share, hit rates,
// bonus averages and the two bonus buys. Usage: node scripts/sim-tigerdragon.mjs [spins] [bonusRuns]
import { act, init, bonusState } from '../server/games/tigerdragon/engine.js';

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const N = Number(process.argv[2] || 2e6), B = Number(process.argv[3] || 40000);
const bet = 7500;

function playBonus(state, rand) {
  let s = state, win = 0, out;
  while (s.mode !== 'base') { const r = act(s, 'respin', {}, { rand }); s = r.state; win += r.payout; out = r.out; }
  return { s, win, out };
}

const rand = rng(12345);
let s = init(), staked = 0, paid = 0, lines = 0, myst = 0, hits = 0, mystHits = 0;
const feat = { tiger: { n: 0, w: 0 }, dragon: { n: 0, w: 0 }, combined: { n: 0, w: 0 } };
let jackpots = 0, maxX = 0, big10 = 0;
for (let i = 0; i < N; i++) {
  const r = act(s, 'spin', { stake: bet }, { rand });
  s = r.state; staked += r.stake; paid += r.payout;
  lines += r.out.lineWin; const m = Math.min(r.out.mystery?.total || 0, r.payout - Math.min(r.out.lineWin, r.payout)); myst += m;
  if (r.payout > 0) hits++; if (m > 0) mystHits++;
  let spinWin = r.payout;
  if (r.out.started) {
    const t = r.out.started; const b = playBonus(s, rand); s = b.s; paid += b.win; spinWin += b.win;
    feat[t].n++; feat[t].w += b.win; if (b.out.result?.jackpot) jackpots++;
  }
  maxX = Math.max(maxX, spinWin / bet); if (spinWin >= 10 * bet) big10++;
}
const pct = (x) => (100 * x / staked).toFixed(2) + '%';
console.log(`spins ${N}  RTP ${pct(paid)}  lines ${pct(lines)}  mystery ${pct(myst)}  hit 1/${(N / hits).toFixed(1)}  mysteryPays 1/${(N / mystHits).toFixed(0)}  10x+ 1/${(N / big10).toFixed(0)}  max ${maxX.toFixed(0)}x`);
for (const [k, v] of Object.entries(feat)) console.log(`  ${k.padEnd(8)} every ${(N / v.n).toFixed(0)} spins  avg ${(v.w / v.n / bet).toFixed(1)}x  share ${pct(v.w)}`);
console.log(`  jackpots ${jackpots}`);

// Bonus averages and the two buys
function bonusStats(type, runs) {
  const r2 = rng(999 + type.length); let w = 0, jp = 0, zero = 0, gongs = 0, mx = 0;
  for (let i = 0; i < runs; i++) {
    let st = bonusState(type, bet, r2);
    const b = playBonus(st, r2); w += b.win; if (b.out.result.jackpot) jp++; if (!b.win) zero++; gongs += b.out.result.gongs; mx = Math.max(mx, b.win / bet);
  }
  return { avgX: w / runs / bet, jp: jp / runs, zero: zero / runs, gongs: gongs / runs, mx };
}
const T = bonusStats('tiger', B), D = bonusStats('dragon', B), C = bonusStats('combined', B);
for (const [k, v] of [['tiger', T], ['dragon', D], ['combined', C]]) console.log(`bonus ${k.padEnd(8)} avg ${v.avgX.toFixed(1)}x  gongs ${v.gongs.toFixed(1)}  pays-nothing ${(v.zero * 100).toFixed(1)}%  jackpot 1/${v.jp ? (1 / v.jp).toFixed(0) : '-'}  max ${v.mx.toFixed(0)}x`);
const W = { tiger: 45, dragon: 45, combined: 10 }, tot = 100;
const randomBuy = (W.tiger * T.avgX + W.dragon * D.avgX + W.combined * C.avgX) / tot;
console.log(`buy random (50x): returns ${(randomBuy / 50 * 100).toFixed(1)}%   buy Tiger & Dragon (100x): returns ${(C.avgX / 100 * 100).toFixed(1)}%`);
