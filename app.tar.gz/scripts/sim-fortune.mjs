// Simulates Fortune Live: every spot's return, hit rates and bonus averages.
//   node scripts/sim-fortune.mjs [rounds]
import { spinRound, finishWall, finishFrenzy } from '../server/games/fortune/engine.js';
import { SPOT_IDS, TABLES, FLAPPERS } from '../server/games/fortune/config.js';
import { spotRtp, boosterChance } from '../server/games/fortune/maths.js';

// sfc32 seeded PRNG so runs are repeatable
function sfc32(a, b, c, d) { return () => { a >>>= 0; b >>>= 0; c >>>= 0; d >>>= 0; let t = (a + b) | 0; a = b ^ (b >>> 9); b = (c + (c << 3)) | 0; c = (c << 21) | (c >>> 11); d = (d + 1) | 0; t = (t + d) | 0; c = (c + t) | 0; return (t >>> 0) / 4294967296; }; }
const rand = sfc32(0x9e3779b9, 0x243f6a88, 0xb7e15162, Date.now() & 0xffffffff);
const N = Number(process.argv[2] || 2_000_000);
const bets = Object.fromEntries(SPOT_IDS.map((id) => [id, 100]));
const ret = Object.fromEntries(SPOT_IDS.map((id) => [id, 0]));
const hits = {}; let maxX = 0; let boosted = 0;
for (let i = 0; i < N; i++) {
  let r = spinRound(bets, rand);
  if (!r.done) {
    const p = r.pending;
    const shown = p.bonus === 'wall' ? finishWall(p, Math.floor(rand() * 108)) : finishFrenzy(p, FLAPPERS[Math.floor(rand() * 3)], rand);
    r = { ...r, results: { [r.landed]: { bet: 100, ret: Math.floor(100 * (1 + shown.x)) } }, x: shown.x };
  }
  ret[r.landed] += r.results[r.landed].ret;
  hits[r.landed] = (hits[r.landed] || 0) + 1;
  if (r.boost > 1) boosted++;
  maxX = Math.max(maxX, r.x);
}
console.log(`Fortune Live: ${N.toLocaleString()} rounds (booster lit something on ${(boosterChance() * 100).toFixed(1)}% of rounds; boosted the landed spot on ${(boosted / N * 100).toFixed(2)}%)`);
console.log('spot      exact     simulated  hit-rate');
for (const id of SPOT_IDS) console.log(`${id.padEnd(8)}  ${(spotRtp(id) * 100).toFixed(3)}%  ${(ret[id] / (N * 100) * 100).toFixed(3)}%   1 in ${(N / (hits[id] || 1)).toFixed(1)}`);
console.log('max multiple seen', maxX);
for (const [id, t] of Object.entries(TABLES)) console.log(id, 'first weight', t[0][1].toFixed(2));
