// Full-game simulation report for Gong Fortune: every spin is played to the end, including any bonus it
// triggers, at a given stake (pence). Usage: node scripts/report-tigerdragon.mjs [stake] [spins] [seed]
import { act, init } from '../server/games/tigerdragon/engine.js';
import { RTP_PROFILE, MAX_WIN_X } from '../server/games/tigerdragon/config.js';
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const stake = Number(process.argv[2] || 50), N = Number(process.argv[3] || 2e6), rand = rng(Number(process.argv[4] || 11));
const buckets = [[0, 0, '0x'], [0, 1, 'under 1x'], [1, 2, '1x-2x'], [2, 5, '2x-5x'], [5, 10, '5x-10x'], [10, 50, '10x-50x'], [50, 100, '50x-100x'], [100, 500, '100x-500x'], [500, MAX_WIN_X, '500x-2,000x'], [MAX_WIN_X, Infinity, '2,000x (max)']];
const dist = buckets.map(() => 0);
let staked = 0, won = 0, hits = 0, maxX = 0, sumSq = 0, mystery = 0, luck = 0;
const B = { tiger: [], dragon: [], combined: [] };
let s = init();
for (let i = 0; i < N; i++) {
  const r = act(s, 'spin', { stake }, { rand }); s = r.state; staked += r.stake;
  let w = r.payout; if (r.out.mystery) mystery++; if (r.out.luck) luck++;
  if (r.out.started) {
    const type = r.out.started; let bw = 0;
    while (s.mode !== 'base') { const x = act(s, 'respin', {}, { rand }); s = x.state; bw += x.payout; }
    B[type].push(bw / stake); w += bw;
  }
  won += w; const x = w / stake; sumSq += x * x; if (w > 0) hits++; if (x > maxX) maxX = x;
  dist[x === 0 ? 0 : x >= MAX_WIN_X ? 9 : buckets.findIndex(([lo, hi], k) => k > 0 && x > lo - 1e-9 && x < hi && !(k === 1 && x >= 1))]++;
}
const rtp = won / staked, sd = Math.sqrt(sumSq / N - rtp * rtp);
const pct = (v) => `${(v * 100).toFixed(2)}%`;
const q = (arr, p) => { const a = [...arr].sort((x, y) => x - y); return a.length ? a[Math.min(a.length - 1, Math.floor(p * a.length))] : 0; };
console.log(`Gong Fortune · profile ${RTP_PROFILE}% · stake ${stake}p · ${N.toLocaleString()} spins (bonuses played out)`);
console.log(`simulated RTP ${pct(rtp)} (±${pct((1.96 * sd) / Math.sqrt(N))} at 95%) · std dev per spin ${sd.toFixed(1)}x · hit frequency 1 in ${(N / hits).toFixed(2)} · Mystery Gongs 1 in ${(N / mystery).toFixed(0)} spins · Luck Has Arrived 1 in ${(N / luck).toFixed(0)} spins`);
console.log(`highest single-spin return ${maxX.toFixed(1)}x (cap ${MAX_WIN_X}x)`);
for (const [k, v] of Object.entries(B)) {
  if (!v.length) continue;
  const mean = v.reduce((a, b) => a + b, 0) / v.length, zero = v.filter((x) => x === 0).length / v.length, over = v.filter((x) => x > 1).length / v.length;
  console.log(`${k.padEnd(8)} 1 in ${(N / v.length).toFixed(0)} spins · avg ${mean.toFixed(1)}x · pays more than the stake ${pct(over)} · pays 0 ${pct(zero)} · median ${q(v, 0.5).toFixed(1)}x · 90th pct ${q(v, 0.9).toFixed(0)}x · 99th pct ${q(v, 0.99).toFixed(0)}x · best ${Math.max(...v).toFixed(0)}x`);
}
console.log('return distribution per spin (incl. bonus):');
buckets.forEach(([, , l], k) => console.log(`  ${l.padEnd(13)} ${pct(dist[k] / N).padStart(8)}  (1 in ${dist[k] ? (N / dist[k]).toFixed(0) : '-'})`));
