// Prices every Bonus Buy option by playing real purchases through the real engines.
//   node scripts/sim-bonusbuy.mjs [rounds=4000] [game ...]
// Each round: buy at a £1 bet (cost 1x, so the result is the return in multiples of the bet), then
// play the bonus to the end with the adapter's autoplay. Writes server/games/bonusbuy/prices.js.
import fs from 'node:fs';
import crypto from 'node:crypto';
import { GAMES } from '../server/games/registry.js';
import { ADAPTERS, runBuy, defaultConfig } from '../server/games/bonusbuy/buy.js';
import { PRICES } from '../server/games/bonusbuy/prices.js';

const N = Number(process.argv[2] || 4000);
const only = process.argv.slice(3);
const rand = () => crypto.randomInt(0, 2 ** 32) / 2 ** 32;
const BET = 100;
const ctx = { rand, now: Date.now(), minStake: 10, maxStake: 10000 };
const out = { ...PRICES };
const report = [];

export function playOut(id, state, bet) {
  const a = ADAPTERS[id], g = GAMES[id];
  let s = state, pay = 0, steps = 0;
  while (a.inBonus(s)) {
    if (++steps > 5000) throw new Error(`${id}: bonus did not finish`);
    const step = a.autoplay ? a.autoplay(s) : { action: 'spin' };
    const r = g.act(structuredClone(s), step.action, { stake: bet, ...(step.body || {}) }, ctx);
    if (r.stake) throw new Error(`${id}: bonus step charged a stake`);
    pay += r.payout || 0; s = r.state;
  }
  return { pay, steps, state: s };
}

for (const [id, a] of Object.entries(ADAPTERS)) {
  if (only.length && !only.includes(id)) continue;
  const cfg = defaultConfig();
  for (const o of a.options) {
    cfg.games[id].options[o.id].cost = 1;
    let sum = 0, sq = 0, tries = 0, max = 0, steps = 0;
    const t0 = Date.now();
    for (let i = 0; i < N; i++) {
      const r = runBuy(id, GAMES[id], GAMES[id].init(), { stake: BET, option: o.id }, ctx, cfg);
      const p = playOut(id, r.state, BET);
      const x = (r.payout + p.pay) / BET;
      sum += x; sq += x * x; tries += r.buy.tries || 0; max = Math.max(max, x); steps += p.steps;
    }
    const avg = sum / N, sd = Math.sqrt(Math.max(0, sq / N - avg * avg));
    const cost = Math.max(1, Math.round(avg / 0.96));
    out[id] = { ...(out[id] || {}), [o.id]: { avg: Math.round(avg * 100) / 100, cost, se: Math.round((sd / Math.sqrt(N)) * 100) / 100, n: N } };
    report.push(`${id.padEnd(12)} ${o.id.padEnd(10)} avg ${avg.toFixed(2).padStart(8)}x  ±${(sd / Math.sqrt(N)).toFixed(2)}  cost ${String(cost).padStart(4)}x  trigger ~1 in ${(tries / N).toFixed(0)}  max ${max.toFixed(0)}x  steps ${(steps / N).toFixed(1)}  ${((Date.now() - t0) / N).toFixed(1)}ms/buy`);
    console.log(report[report.length - 1]);
    write();
  }
}
function write() {
const body = `// Written by scripts/sim-bonusbuy.mjs. avg = average return of a bought bonus (triggering spin +
// the whole bonus) in multiples of the bet; cost = the default price (avg / 0.96, rounded); se = standard
// error of avg; n = bought bonuses simulated.
export const PRICES = ${JSON.stringify(out, null, 2).replace(/"([a-z]+)":/g, '$1:')};
`;
fs.writeFileSync(new URL('../server/games/bonusbuy/prices.js', import.meta.url), body);
}
