// Precise RTP: base game measured over many spins (bonuses not played), plus
// each bonus's trigger rate times its own long-run average (measured separately).
// Usage: node scripts/rtp-tigerdragon.mjs [baseSpins] [bonusRuns]
import { act, init, bonusState } from '../server/games/tigerdragon/engine.js';
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const N = Number(process.argv[2] || 5e6), R = Number(process.argv[3] || 200000), bet = 7500;
let rand = rng(1), s = init(), staked = 0, lines = 0, myst = 0, hits = 0;
const trig = { tiger: 0, dragon: 0, combined: 0 };
for (let i = 0; i < N; i++) {
  const r = act(s, 'spin', { stake: bet }, { rand });
  staked += r.stake; lines += Math.min(r.out.lineWin, r.payout); myst += r.payout - Math.min(r.out.lineWin, r.payout); if (r.payout) hits++;
  if (r.out.started) trig[r.out.started]++;
}
const mean = (type, seed) => { const rr = rng(seed); let w = 0, jp = 0; for (let i = 0; i < R; i++) { let st = bonusState(type, bet, rr); while (st.mode !== 'base') { const x = act(st, 'respin', {}, { rand: rr }); st = x.state; w += x.payout; if (x.out.result?.jackpot) jp++; } } return { x: w / R / bet, jp: jp / R }; };
const M = { tiger: mean('tiger', 2), dragon: mean('dragon', 3), combined: mean('combined', 4) };
const p = (x) => (x * 100).toFixed(2) + '%';
let total = (lines + myst) / staked;
console.log(`base lines ${p(lines / staked)}  mystery ${p(myst / staked)}  hit rate 1 in ${(N / hits).toFixed(2)}`);
for (const k of Object.keys(trig)) { const f = trig[k] / N; total += f * M[k].x; console.log(`${k.padEnd(9)} 1 in ${(1 / f).toFixed(0)} spins, averages ${M[k].x.toFixed(1)}x -> ${p(f * M[k].x)}${M[k].jp ? `  (jackpot 1 in ${(1 / M[k].jp).toFixed(0)} bonuses)` : ''}`); }
console.log(`TOTAL RTP ${p(total)}`);
console.log(`Bonus buy random 50x returns ${p((0.45 * M.tiger.x + 0.45 * M.dragon.x + 0.10 * M.combined.x) / 50)};  Tiger & Dragon 100x returns ${p(M.combined.x / 100)}`);
