// Measures the theoretical return of every racing bet type. For each race: price the card, then run
// the race S more times and count how often each horse wins / places and each exact 1-2 and 1-2-3
// occurs. Return of a bet type = average over every possible selection of (chance × price).
//   node scripts/sim-racing.mjs [races=300] [runs per race=600]
import { buildHorses, FORMATS, COURSES } from '../server/racing/data.js';
import { BET_TYPES, makeCard, priceBet, simulate, fastRand } from '../server/racing/core.js';
const N = Number(process.argv[2] || 300), S = Number(process.argv[3] || 600);
const H = buildHorses();
const rand = fastRand(Math.random);
const acc = Object.fromEntries([...Object.keys(BET_TYPES), 'fav_win', 'fav_ew'].map((k) => [k, { ret: 0, n: 0 }]));
const add = (k, x, w = 1) => { acc[k].ret += x * w; acc[k].n += w; };
for (let i = 0; i < N; i++) {
  const f = FORMATS[i % FORMATS.length];
  const card = makeCard({ pool: H, rand, courseId: COURSES[i % 8].id, formatId: f.id, sims: 500 });
  const n = card.runners.length, places = card.terms?.places || 3;
  const win = new Array(n).fill(0), plc = new Array(n).fill(0), pair = new Map(), tri = new Map();
  for (let s = 0; s < S; s++) {
    const o = simulate(card, H, rand, { trace: false }).order;
    win[o[0]]++; for (let k = 0; k < places; k++) plc[o[k]]++;
    const pk = `${o[0]},${o[1]}`; pair.set(pk, (pair.get(pk) || 0) + 1);
    const tk = `${o[0]},${o[1]},${o[2]}`; tri.set(tk, (tri.get(tk) || 0) + 1);
  }
  const no = (k) => card.runners[k].no;
  for (let a = 0; a < n; a++) {
    const pw = win[a] / S, pp = plc[a] / S;
    const w = priceBet(card, 'win', [no(a)]); add('win', pw * w.win.dec);
    if (card.terms) {
      const e = priceBet(card, 'each_way', [no(a)]); add('each_way', (pw * e.win.dec + pp * e.place.dec) / 2);
      const p = priceBet(card, 'place', [no(a)]); add('place', pp * p.place.dec);
    }
  }
  for (let a = 0; a < n; a++) for (let b = 0; b < n; b++) if (a !== b) {
    const fc = priceBet(card, 'forecast', [no(a), no(b)]); add('forecast', ((pair.get(`${a},${b}`) || 0) / S) * fc.lines[0].dec);
    if (a < b) { const rf = priceBet(card, 'reverse_forecast', [no(a), no(b)]); add('reverse_forecast', rf.lines.reduce((t, l) => t + ((pair.get(`${card.runners.findIndex((r) => r.no === l.order[0])},${card.runners.findIndex((r) => r.no === l.order[1])}`) || 0) / S) * l.dec, 0) / 2); }
  }
  if (n <= 12) {
    for (let a = 0; a < n; a++) for (let b = 0; b < n; b++) for (let c = 0; c < n; c++) if (a !== b && b !== c && a !== c) {
      const tc = priceBet(card, 'tricast', [no(a), no(b), no(c)]); add('tricast', ((tri.get(`${a},${b},${c}`) || 0) / S) * tc.lines[0].dec);
      if (a < b && b < c) {
        const t3 = priceBet(card, 'trio', [no(a), no(b), no(c)]);
        const perms = [[a, b, c], [a, c, b], [b, a, c], [b, c, a], [c, a, b], [c, b, a]];
        add('trio', perms.reduce((t, p) => t + (tri.get(p.join(',')) || 0), 0) / S * t3.lines[0].dec);
      }
    }
  }
  const fav = card.runners.reduce((x, r, k) => (r.odds.dec < card.runners[x].odds.dec ? k : x), 0);
  add('fav_win', (win[fav] / S) * card.runners[fav].odds.dec);
  if (card.terms) { const e = priceBet(card, 'each_way', [no(fav)]); add('fav_ew', (win[fav] / S * e.win.dec + plc[fav] / S * e.place.dec) / 2); }
}
for (const [k, v] of Object.entries(acc)) console.log(`${(BET_TYPES[k]?.name || k).padEnd(18)} return ${(v.ret / v.n * 100).toFixed(1)}%`);
