// Finds the Tiger/Dragon scatter weight that keeps the total RTP on target once Luck Has Arrived
// (a random guaranteed bonus) is added. Bonus averages are independent of the base reels, so they
// are taken as measured (scripts/rtp-tigerdragon.mjs). Usage: node scripts/tune-luck-tigerdragon.mjs [target%] [spins]
import { act, init } from '../server/games/tigerdragon/engine.js';
import { setScatterWeight } from '../server/games/tigerdragon/reels.js';
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const target = Number(process.argv[2] || 96.28) / 100, N = Number(process.argv[3] || 1500000);
const M = { tiger: 46.1, dragon: 39.2, combined: 95.5 };
const rtpAt = (w, seed) => {
  setScatterWeight(w);
  const rand = rng(seed); let staked = 0, base = 0, bon = 0, luck = 0; const s = init();
  for (let i = 0; i < N; i++) { const r = act(s, 'spin', { stake: 7500 }, { rand }); staked += r.stake; base += r.payout; if (r.out.started) { bon += M[r.out.started] * 7500; if (r.out.luck) luck++; } }
  return { rtp: (base + bon) / staked, luck: N / luck };
};
let lo = 1.4, hi = 1.95;
for (let it = 0; it < 9; it++) { const w = (lo + hi) / 2; const r = rtpAt(w, 100 + it); if (r.rtp > target) hi = w; else lo = w; console.log(w.toFixed(4), (r.rtp * 100).toFixed(2), `luck 1 in ${r.luck.toFixed(0)}`); }
console.log('SCATTER_WEIGHT', ((lo + hi) / 2).toFixed(3));
