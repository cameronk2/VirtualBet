// Phoenix Ember Link – Monte Carlo simulator. Plays the real engine (eggs carried spin to spin at one
// stake, as a player would) and reports RTP, hit rate, bonus and jackpot rates, max win and volatility.
// Usage: node scripts/sim-phoenix.mjs [spins=2000000] [seed=1] [stake=100]
import { act, init } from '../server/games/phoenix/engine.js';
import { useProfile } from '../server/games/phoenix/config.js';

export function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export function simulate(spins, seed = 1, bet = 100) {
  const rand = rng(seed);
  let st = init();
  const S = { spins: 0, staked: 0, paid: 0, line: 0, hits: 0, bonuses: 0, firestorms: 0, bonusPaid: 0, grands: 0, jp: { mini: 0, minor: 0, major: 0 }, max: 0, sumSq: 0, ups: {}, upCount: [0, 0, 0, 0, 0, 0], arrays2: 0 };
  for (let i = 0; i < spins; i++) {
    let r = act(st, 'spin', { stake: bet }, { rand });
    st = r.state; let win = r.payout; S.line += r.payout; S.staked += r.stake; S.spins++;
    if (r.out.started) {
      S.bonuses++; if (r.out.firestorm) S.firestorms++;
      S.upCount[r.out.upgrades.length]++;
      for (const u of r.out.upgrades) S.ups[u] = (S.ups[u] || 0) + 1;
      let guard = 0;
      while (st.mode === 'bonus') {
        r = act(st, 'respin', {}, { rand }); st = r.state;
        if (++guard > 500) throw new Error('bonus never ended');
        if (r.out.result) {
          S.bonusPaid += r.payout; win += r.payout;
          for (const a of r.out.result.arrays) { if (a.grand) S.grands++; for (const j of a.jackpots) if (S.jp[j] !== undefined) S.jp[j]++; }
          if (r.out.result.arrays.length > 1) S.arrays2++;
        }
      }
    }
    if (win > 0) S.hits++;
    S.paid += win; const x = win / bet; S.sumSq += x * x; if (x > S.max) S.max = x;
  }
  const rtp = S.paid / S.staked;
  const mean = S.paid / S.spins / bet;
  return { ...S, rtp, lineRtp: S.line / S.staked, bonusRtp: S.bonusPaid / S.staked, hitRate: S.hits / S.spins, bonusEvery: S.spins / S.bonuses, firestormEvery: S.spins / S.firestorms, avgBonusX: S.bonusPaid / S.bonuses / bet, sd: Math.sqrt(S.sumSq / S.spins - mean * mean) };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const [n = 2000000, seed = 1, bet = 100] = process.argv.slice(2, 5).map(Number);
  const vol = process.argv[5] || 'medium', rtpP = Number(process.argv[6] || 96);
  useProfile(vol, rtpP);
  const t = Date.now();
  const r = simulate(n, seed, bet);
  console.log(JSON.stringify({ vol, rtpP, ...r, ms: Date.now() - t }, (k, v) => (typeof v === 'number' ? Math.round(v * 10000) / 10000 : v), 1));
}
