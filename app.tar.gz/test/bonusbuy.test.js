// Universal Bonus Buy: every option on every slot, through the real casino handler and ledger.
import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { ADAPTERS, NOT_SUPPORTED, defaultConfig, mergeConfig, validateConfig, runBuy, publicOptions } from '../server/games/bonusbuy/buy.js';
import { triggered } from '../server/games/bonusbuy/adapters.js';
import { GAMES } from '../server/games/registry.js';

process.env.DATABASE_PATH = path.join(os.tmpdir(), `vb-bb-${process.pid}-${Date.now()}.db`);
process.env.ADMIN_USERS = 'boss';
const { openDb, q } = await import('../server/db.js');
openDb(process.env.DATABASE_PATH);
const { playCasino } = await import('../server/casino.js');
const { credit } = await import('../server/wallet.js');
const bb = await import('../server/bonusbuy.js');

let n = 0;
const nonce = () => `t${Date.now().toString(36)}${(n++).toString(36)}x`;
function user(name, funds) {
  q('INSERT INTO users (username, password_hash, balance, created_at) VALUES (?, ?, 0, 0)').run(name, 'x');
  const id = q('SELECT id FROM users WHERE username = ?').get(name).id;
  if (funds) credit(id, 'DEPOSIT', funds, null, 'test funds');
  return id;
}
const balance = (id) => q('SELECT balance FROM users WHERE id = ?').get(id).balance;
const stakeFor = (game, i) => (game === 'phoenix' ? [20, 50, 100][i % 3] : game === 'tigerdragon' ? [10, 50, 100][i % 3] : [10, 50, 100][i % 3]);

/** Plays a bonus to the end through the API. Returns the total paid by the bonus steps. */
function playOut(uid, game, view, bet) {
  const a = ADAPTERS[game];
  let paid = 0, steps = 0;
  const state = view;
  // autoplay needs the raw saved state, so read it from the database
  const raw = () => JSON.parse(q('SELECT state FROM casino_state WHERE user_id = ? AND game = ?').get(uid, game).state);
  let s = raw();
  while (a.inBonus(s)) {
    assert.ok(++steps < 3000, `${game}: bonus finished`);
    const st = a.autoplay ? a.autoplay(s) : { action: 'spin' };
    const before = balance(uid);
    const r = playCasino(uid, game, st.action, { stake: bet, ...(st.body || {}) });
    assert.equal(r.out.staked || 0, 0, `${game}: bonus steps cost nothing`);
    paid += balance(uid) - before;
    s = raw();
  }
  return { paid, steps, state };
}

test('every slot is either supported or explained', () => {
  const slots = ['phoenix', 'tigerdragon', 'genie', 'stampede', 'brick', 'mummy', 'moonridge', 'frost', 'atlantis', 'neon', 'dragon', 'cosmic', 'pharaoh', 'starlight', 'nebula', 'vault', 'fruit'];
  for (const s of slots) assert.ok(ADAPTERS[s] || NOT_SUPPORTED[s], s);
  for (const id of Object.keys(ADAPTERS)) assert.ok(GAMES[id], `${id} is a registered game`);
});

test('the price is always bet × cost multiplier, at every bet', () => {
  const cfg = defaultConfig();
  for (const [id, a] of Object.entries(ADAPTERS)) for (const o of a.options) for (const bet of id === 'phoenix' ? [20, 50, 100, 200] : id === 'tigerdragon' ? [10, 20, 50, 150] : [10, 20, 50, 100, 200]) {
    const r = runBuy(id, GAMES[id], GAMES[id].init(), { stake: bet, option: o.id }, { rand: Math.random, minStake: 10 }, cfg);
    assert.equal(r.stake, Math.round(bet * cfg.games[id].options[o.id].cost), `${id}/${o.id} at ${bet}`);
    assert.equal(r.settled.staked, r.stake);
    if (!a.native) assert.ok(triggered(id, r.out).includes(o.id), `${id}/${o.id} triggers the feature it sold`);
    else assert.ok(r.out.started, `${id}/${o.id} starts its bonus`);
    if (a.inBonus !== undefined && id !== 'vault') assert.ok(a.inBonus(r.state), `${id}/${o.id}: the bonus is in play after buying`);
  }
});

test('buying through the API: debit, real bonus, payout, records and history for every option', () => {
  const uid = user('buyer', 10_000_000);
  for (const [game, a] of Object.entries(ADAPTERS)) {
    a.options.forEach((o, i) => {
      const bet = stakeFor(game, i);
      const before = balance(uid);
      const r = playCasino(uid, game, 'buy', { stake: bet, option: o.id, nonce: nonce() });
      const cost = r.out.bought.cost;
      assert.equal(r.out.staked, cost);
      assert.equal(cost, Math.round(bet * bb.getConfig().games[game].options[o.id].cost));
      const afterBuy = balance(uid);
      const first = afterBuy - (before - cost); // what the triggering spin paid
      const p = playOut(uid, game, r.view, bet);
      const rec = q('SELECT * FROM bonus_buys WHERE user_id = ? ORDER BY id DESC LIMIT 1').get(uid);
      assert.equal(rec.status, 'settled', `${game}/${o.id} purchase closed when the bonus ended`);
      assert.equal(rec.cost, cost);
      assert.equal(rec.payout, first + p.paid, `${game}/${o.id} purchase payout = everything the bonus paid`);
      assert.equal(balance(uid), before - cost + rec.payout, `${game}/${o.id} balance`);
      const hist = playCasino(uid, game, 'buy', { stake: bet, option: o.id, nonce: nonce() }).history[0];
      assert.equal(hist.buy, o.name);
      playOut(uid, game, null, bet);
    });
  }
  const tx = q('SELECT amount, balance_before b0, balance_after b1 FROM wallet_tx WHERE user_id = ? ORDER BY id').all(uid);
  assert.ok(tx.every((t, i) => t.b1 === t.b0 + t.amount && (i === 0 || tx[i - 1].b1 === t.b0)), 'the wallet ledger is continuous');
});

test('refuses: not enough balance, duplicate purchase, bonus in play, bad stake, unknown option, switched off', () => {
  const poor = user('poor', 1000);
  assert.throws(() => playCasino(poor, 'neon', 'buy', { stake: 100, option: 'free', nonce: nonce() }), /Not enough virtual balance/);
  assert.equal(balance(poor), 1000, 'nothing taken');
  assert.equal(q('SELECT COUNT(*) c FROM bonus_buys WHERE user_id = ?').get(poor).c, 0, 'nothing recorded');

  const uid = user('dup', 1_000_000);
  const once = nonce();
  playCasino(uid, 'vault', 'buy', { stake: 10, option: 'hold', nonce: once });
  const bal = balance(uid);
  assert.throws(() => playCasino(uid, 'vault', 'buy', { stake: 10, option: 'hold', nonce: once }), /already been made/);
  assert.equal(balance(uid), bal, 'a repeated tap is not charged');
  assert.throws(() => playCasino(uid, 'vault', 'buy', { stake: 10, option: 'hold' }), /Purchase reference/);

  playCasino(uid, 'neon', 'buy', { stake: 10, option: 'free', nonce: nonce() });
  assert.throws(() => playCasino(uid, 'neon', 'buy', { stake: 10, option: 'free', nonce: nonce() }), /Finish the bonus/);
  assert.throws(() => playCasino(uid, 'nebula', 'buy', { stake: -10, option: 'free', nonce: nonce() }), /at least/);
  assert.throws(() => playCasino(uid, 'nebula', 'buy', { stake: 10.5, option: 'free', nonce: nonce() }), /at least/);
  assert.throws(() => playCasino(uid, 'nebula', 'buy', { stake: 100000, option: 'free', nonce: nonce() }), /up to/);
  assert.throws(() => playCasino(uid, 'nebula', 'buy', { stake: 10, option: 'jackpot', nonce: nonce() }), /Choose a bonus/);
  assert.throws(() => playCasino(uid, 'fruit', 'buy', { stake: 10, option: 'x', nonce: nonce() }), /no bonus round/);
  assert.throws(() => playCasino(uid, 'phoenix', 'buy', { stake: 30, option: 'arealink', nonce: nonce() }), /listed bets/);

  const admin = q("SELECT * FROM users WHERE username = 'buyer'").get();
  assert.throws(() => bb.adminSave(admin, defaultConfig()), /Admins only/);
  const boss = { id: user('boss', 0), username: 'boss' };
  const cfg = defaultConfig(); cfg.games.nebula.enabled = false; cfg.games.vault.options.hold.cost = 200;
  bb.adminSave(boss, cfg);
  assert.throws(() => playCasino(uid, 'nebula', 'buy', { stake: 10, option: 'free', nonce: nonce() }), /switched off/);
  const v = playCasino(uid, 'vault', 'buy', { stake: 50, option: 'hold', nonce: nonce() });
  assert.equal(v.out.staked, 10000, 'admin price applied: 50p × 200');
  assert.ok(bb.adminView(boss).log[0].change.some((c) => c.includes('vault/hold cost')), 'change logged');
  bb.adminSave(boss, defaultConfig());
});

test('settings are validated and merged safely', () => {
  assert.match(validateConfig({ enabled: true, minStake: 10, maxStake: 1000, games: { vault: { options: { hold: { cost: 0 } } } } }), /between 1x/);
  assert.match(validateConfig({ enabled: true, minStake: 5, maxStake: 1000, games: {} }), /at least 10p/);
  assert.match(validateConfig({ enabled: true, minStake: 10, maxStake: 1000, games: { nope: {} } }), /Unknown game/);
  assert.equal(validateConfig(defaultConfig()), null);
  const m = mergeConfig({ games: { vault: { options: { hold: { cost: 'free' } } } } });
  assert.equal(m.games.vault.options.hold.cost, defaultConfig().games.vault.options.hold.cost, 'junk ignored');
  const pub = publicOptions('vault', defaultConfig());
  assert.ok(pub.options[0].cost > 1 && pub.options[0].rtp > 0);
  assert.equal(publicOptions('fruit', defaultConfig()), null);
});
