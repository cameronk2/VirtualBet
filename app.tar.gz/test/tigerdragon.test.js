// Gong Fortune: the 20 required scenarios, each forced deterministically,
// plus cluster/Arrow maths and balance updates through the real casino API.
import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { act, init, rowsFor } from '../server/games/tigerdragon/engine.js';
import { clusterCredits, findClusters, settle } from '../server/games/tigerdragon/gongs.js';
import { BUY_COMBINED_X, BUY_RANDOM_X, JACKPOT_X, MAX_WIN_X, RESPINS } from '../server/games/tigerdragon/config.js';

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const never = () => 0.999999; // a rand that never lands a gong and never triggers Mystery Gongs
const bet = 150;
const G = (cols) => cols.map((col) => col.map((s) => ({ s })));
// reel 1 and reel 2 share no symbol, so no ways win
const NOWIN = (over = {}) => G([['ENVELOPE', 'LOTUS', 'LANTERN'], ['FAN', 'BANGLE', 'ORNAMENT'], ['LOTUS', 'FAN', 'ENVELOPE'], ['BANGLE', 'LANTERN', 'ORNAMENT'], ['FAN', 'LOTUS', 'BANGLE']].map((col, c) => col.map((s, r) => over[`${c}-${r}`] || s)));
const spin = (grid, extra = {}, rand = never) => act(init(), 'spin', { stake: bet }, { rand, inject: { grid, mystery: null, ...extra } });
const respin = (s, lands, rand = never) => act(s, 'respin', {}, { rand, inject: lands ? { lands } : undefined });

test('1. three Tiger scatters trigger the Tiger Bonus', () => {
  const r = spin(NOWIN({ '0-0': 'TIGER', '2-1': 'TIGER', '4-2': 'TIGER' }));
  assert.equal(r.out.trigger, 'tiger');
  assert.equal(r.state.mode, 'tiger');
  assert.deepEqual(r.out.startCells.sort(), ['0-0', '2-1', '4-2']); // the Tigers become the first gongs
});

test('2. three Dragon scatters trigger the Dragon Bonus', () => {
  const r = spin(NOWIN({ '1-0': 'DRAGON', '2-2': 'DRAGON', '3-1': 'DRAGON' }));
  assert.equal(r.out.trigger, 'dragon');
  assert.equal(r.state.mode, 'dragon');
});

test('3. five Tiger and Dragon together trigger the combined bonus (and take priority)', () => {
  const r = spin(NOWIN({ '0-0': 'TIGER', '1-1': 'TIGER', '2-2': 'TIGER', '3-0': 'DRAGON', '4-1': 'DRAGON' }));
  assert.equal(r.out.trigger, 'combined');
  assert.equal(r.state.bonus.open, 3);
  // the 5 x 3 reels map onto the bottom three rows of the 8-row grid
  assert.deepEqual(r.out.startCells.sort(), ['0-5', '1-6', '2-7', '3-5', '4-6']);
  const four = spin(NOWIN({ '0-0': 'TIGER', '1-1': 'TIGER', '3-0': 'DRAGON', '4-1': 'DRAGON' }));
  assert.equal(four.out.trigger, null, '2 + 2 is not enough for anything');
});

test('4. Tiger Bonus starts with exactly three spins', () => {
  const r = spin(NOWIN({ '0-0': 'TIGER', '2-1': 'TIGER', '4-2': 'TIGER' }));
  assert.equal(r.state.bonus.spinsLeft, 3);
  assert.equal(r.out.view.bonus.spinsLeft, 3);
});

test('5 & 6. new Tiger gongs reset the counter; locked gongs stay locked', () => {
  let s = spin(NOWIN({ '0-0': 'TIGER', '2-1': 'TIGER', '4-2': 'TIGER' })).state;
  let r = respin(s, []); assert.equal(r.out.spinsLeft, 2); s = r.state;
  r = respin(s, []); assert.equal(r.out.spinsLeft, 1); s = r.state;
  r = respin(s, ['1-0']); assert.equal(r.out.spinsLeft, RESPINS, 'a new gong resets to 3'); s = r.state;
  for (const k of ['0-0', '2-1', '4-2', '1-0']) assert.ok(s.bonus.cells[k], `${k} still locked`);
  const before = JSON.stringify(s.bonus.cells);
  r = respin(s, ['0-0']); // already locked: cannot land again or change
  assert.equal(r.out.lands.length, 0); assert.equal(r.out.spinsLeft, 2);
  assert.equal(JSON.stringify(r.state.bonus.cells), before);
  s = r.state; r = respin(s, []); s = r.state; r = respin(s, []);
  assert.ok(r.out.result, 'ends when the spins run out'); assert.equal(r.state.mode, 'base');
});

test('Tiger Bonus ends when all 15 spots are filled', () => {
  const s = spin(NOWIN({ '0-0': 'TIGER', '2-1': 'TIGER', '4-2': 'TIGER' })).state;
  const all = []; for (let r = 0; r < 3; r++) for (let c = 0; c < 5; c++) all.push(`${c}-${r}`);
  const r = respin(s, all);
  assert.equal(r.out.full, true); assert.ok(r.out.result); assert.equal(r.out.count, 15);
});

test('7. Dragon Bonus awards exactly one spin, then settles', () => {
  const s = spin(NOWIN({ '1-0': 'DRAGON', '2-2': 'DRAGON', '3-1': 'DRAGON' })).state;
  assert.equal(s.bonus.spinsLeft, 1); assert.equal(Object.keys(s.bonus.cells).length, 0);
  const r = respin(s, ['0-3', '1-3', '2-3']); // lands still finish it: no respin reset
  assert.ok(r.out.result); assert.equal(r.state.mode, 'base'); assert.equal(r.out.spinsLeft, 0);
  assert.equal(r.out.result.clusters.length, 1);
});

test('8-13. combined bonus: 3 rows open, rows open at 6, 9, 14, 19 and 25 gongs', () => {
  assert.deepEqual([0, 5, 6, 8, 9, 13, 14, 18, 19, 24, 25, 32].map(rowsFor), [3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8]);
  let s = spin(NOWIN({ '0-0': 'TIGER', '1-1': 'TIGER', '2-2': 'TIGER', '3-0': 'DRAGON', '4-1': 'DRAGON' })).state; // 5 gongs
  assert.equal(s.bonus.open, 3);
  // gongs can't land in closed rows
  let r = respin(s, ['0-0', '0-4']); assert.deepEqual(r.out.lands, [], 'rows 1-5 from the top are closed'); s = r.state;
  r = respin(s, ['0-7']); assert.equal(r.out.count, 6); assert.equal(r.out.open, 4); assert.deepEqual(r.out.unlocked, [4]); s = r.state;
  r = respin(s, ['1-4', '2-4', '3-4']); assert.equal(r.out.count, 9); assert.equal(r.out.open, 5); s = r.state;
  r = respin(s, ['0-3', '1-3', '2-3', '3-3', '4-3']); assert.equal(r.out.count, 14); assert.equal(r.out.open, 6); s = r.state;
  r = respin(s, ['0-2', '1-2', '2-2', '3-2', '4-2']); assert.equal(r.out.count, 19); assert.equal(r.out.open, 7); s = r.state;
  r = respin(s, ['0-1', '1-1', '2-1', '3-1', '4-1', '1-5']); assert.equal(r.out.count, 25); assert.equal(r.out.open, 8); s = r.state;
  assert.ok(!r.out.result);
});

test('a newly opened row is only playable from the next spin', () => {
  let s = spin(NOWIN({ '0-0': 'TIGER', '1-1': 'TIGER', '2-2': 'TIGER', '3-0': 'DRAGON', '4-1': 'DRAGON' })).state;
  const r = respin(s, ['0-7', '1-4']); // 0-7 makes 6 (opens row index 4) but 1-4 was closed during this spin
  assert.deepEqual(r.out.lands, ['0-7']); assert.equal(r.out.open, 4);
  s = r.state;
  assert.deepEqual(respin(s, ['1-4']).out.lands, ['1-4']);
});

test('14. every newly locked gong resets the combined respin counter', () => {
  let s = spin(NOWIN({ '0-0': 'TIGER', '1-1': 'TIGER', '2-2': 'TIGER', '3-0': 'DRAGON', '4-1': 'DRAGON' })).state;
  let r = respin(s, []); assert.equal(r.out.spinsLeft, 2); s = r.state;
  r = respin(s, []); assert.equal(r.out.spinsLeft, 1); s = r.state;
  r = respin(s, ['4-7']); assert.equal(r.out.spinsLeft, 3); s = r.state;
  r = respin(s, []); r = respin(r.state, []); r = respin(r.state, []);
  assert.ok(r.out.result); assert.equal(r.out.result.jackpot, false);
});

test('15. 32 gongs win the jackpot, which takes priority over cluster pays', () => {
  const s0 = act(init(), 'buy', { stake: bet, option: 'combined' }, { rand: rng(3) }).state;
  let s = s0, r;
  const row = (n) => [0, 1, 2, 3, 4].map((c) => `${c}-${n}`);
  for (const lands of [[...row(7), ...row(6), ...row(5)], row(4), row(3), row(2), row(1), row(0)]) {
    r = respin(s, lands); s = r.state;
    if (r.out.result) break;
  }
  assert.ok(r.out.result.jackpot); assert.ok(r.out.count >= 32);
  assert.equal(r.payout, bet * JACKPOT_X);
  assert.deepEqual(r.out.result.clusters, [], 'no ordinary settlement on a jackpot');
});

test('16. fewer than 32 gongs settle clusters normally', () => {
  let s = act(init(), 'buy', { stake: bet, option: 'combined' }, { rand: rng(5) }).state;
  // empty the starting gongs so the cluster is exactly known
  s.bonus.cells = { '0-7': { n: 5 }, '1-7': { n: 3 } };
  let r = respin(s, []); r = respin(r.state, []); r = respin(r.state, []);
  assert.equal(r.out.result.jackpot, false);
  assert.equal(r.out.result.clusters.length, 1);
  assert.equal(r.out.result.clusters[0].text, '53');
  assert.equal(r.payout, Math.floor((53 * bet) / 75));
});

test('17. Mystery Gongs can award after a non-winning spin, never after a win', () => {
  const cells = { '0-1': { n: 5 }, '1-1': { n: 3 }, '3-1': { n: 9 } };
  const r = spin(NOWIN(), { mystery: cells });
  assert.equal(r.out.lineWin, 0);
  assert.equal(r.out.mystery.clusters.length, 1);
  assert.equal(r.payout, Math.floor((53 * bet) / 75));
  // a winning spin never gets them, even with the chance forced
  const win = G([['FAN', 'FAN', 'FAN'], ['FAN', 'LOTUS', 'LOTUS'], ['FAN', 'LOTUS', 'LOTUS'], ['LOTUS', 'LOTUS', 'LOTUS'], ['LOTUS', 'LOTUS', 'LOTUS']]);
  const w = act(init(), 'spin', { stake: bet }, { rand: () => 0, inject: { grid: win } });
  assert.ok(w.out.lineWin > 0); assert.equal(w.out.mystery, null);
  // and the natural path really happens: with rand 0 a no-win spin gets Mystery Gongs
  const m = act(init(), 'spin', { stake: bet }, { rand: () => 0, inject: { grid: NOWIN() } });
  assert.ok(m.out.mystery);
});

test('18. two or more horizontally connected gongs qualify; diagonals and lone gongs do not', () => {
  const cells = { '0-0': { n: 1 }, '1-1': { n: 2 }, '2-1': { n: 3 }, '4-1': { n: 7 }, '3-2': { n: 4 }, '3-0': { n: 9 } };
  const cl = findClusters(cells, 5, 3);
  assert.equal(cl.length, 1);
  assert.deepEqual(cl[0].map((g) => `${g.c}-${g.r}`), ['1-1', '2-1']);
  assert.equal(findClusters({ '2-0': { n: 1 }, '2-1': { n: 2 } }, 5, 3).length, 0, 'vertical neighbours do not connect');
});

test('cluster numbers read left to right; Arrows add to the leftmost number', () => {
  assert.equal(clusterCredits([{ n: 8 }, { n: 5 }, { n: 10 }]).text, '8510');
  assert.equal(clusterCredits([{ n: 1 }, { a: 80 }, { n: 25 }]).text, '8125'); // the reference's 125 -> 8125 example
  assert.equal(clusterCredits([{ a: 5 }, { n: 1 }, { n: 2 }, { n: 0 + 3 }]).text, '623');
  assert.equal(clusterCredits([{ a: 5 }, { n: 5 }, { n: 3 }, { n: 5 }]).text, '1035'); // 5 nudged to 10, as in 5-3-5-0 -> 10-3-5-0
  assert.equal(clusterCredits([{ a: 4 }, { a: 6 }]).credits, 0, 'arrows alone pay nothing');
  const s = settle({ '0-0': { n: 4 }, '1-0': { n: 2 }, '3-2': { n: 1 }, '4-2': { a: 3 } }, 5, 3, 750);
  assert.equal(s.clusters.length, 2);
  assert.equal(s.total, 42 * 10 + 4 * 10, 'every cluster pays: 42 and (1+3)=4, at 10p a credit');
});

test('19. both bonus buys charge the right stake and start straight away', () => {
  const a = act(init(), 'buy', { stake: 300, option: 'random' }, { rand: rng(9) });
  assert.equal(a.stake, 300 * BUY_RANDOM_X); assert.ok(['tiger', 'dragon', 'combined'].includes(a.out.started)); assert.equal(a.state.mode, a.out.started);
  const b = act(init(), 'buy', { stake: 300, option: 'combined' }, { rand: rng(9) });
  assert.equal(b.stake, 300 * BUY_COMBINED_X); assert.equal(b.state.mode, 'combined'); assert.equal(b.state.bonus.open, 3);
  const seen = new Set(); for (let i = 0; i < 300; i++) seen.add(act(init(), 'buy', { stake: 300, option: 'random' }, { rand: rng(i) }).out.started);
  assert.deepEqual([...seen].sort(), ['combined', 'dragon', 'tiger']);
  assert.throws(() => act(b.state, 'spin', { stake: 300 }, { rand: rng(1) }), /Finish the bonus/);
});

test('every bonus can be completed and wins never exceed 2,000x', () => {
  const rand = rng(77);
  for (const opt of ['random', 'combined']) for (let i = 0; i < 400; i++) {
    let s = act(init(), 'buy', { stake: 9000, option: opt }, { rand }).state, total = 0, n = 0;
    while (s.mode !== 'base') { const r = act(s, 'respin', {}, { rand }); s = r.state; total += r.payout; assert.ok(++n < 100, 'bonus finishes'); }
    assert.ok(total <= 9000 * MAX_WIN_X);
  }
});

test('20. payouts reach the balance through the real casino ledger', async () => {
  process.env.DATABASE_PATH = path.join(os.tmpdir(), `vb-td-${process.pid}-${Date.now()}.db`);
  const { openDb, q } = await import('../server/db.js');
  openDb(process.env.DATABASE_PATH);
  const { playCasino } = await import('../server/casino.js');
  const { credit } = await import('../server/wallet.js');
  q("INSERT INTO users (username, password_hash, balance, created_at) VALUES ('gongtest', 'x', 0, 0)").run();
  const uid = q("SELECT id FROM users WHERE username = 'gongtest'").get().id;
  credit(uid, 'DEPOSIT', 100000, null, 'test funds');
  const bal = () => q('SELECT balance FROM users WHERE id = ?').get(uid).balance;
  let paid = 0, staked = 0;
  for (let i = 0; i < 60; i++) { const r = playCasino(uid, 'tigerdragon', 'spin', { stake: 75 }); staked += r.out.staked; paid += r.out.win; while (r.view.mode !== 'base') { const x = playCasino(uid, 'tigerdragon', 'respin', {}); paid += x.out.win; r.view = x.view; } }
  const b = playCasino(uid, 'tigerdragon', 'buy', { stake: 75, option: 'combined' }); staked += b.out.staked;
  assert.equal(b.out.staked, 7500);
  let v = b.view; while (v.mode !== 'base') { const x = playCasino(uid, 'tigerdragon', 'respin', {}); paid += x.out.win; v = x.view; }
  assert.equal(bal(), 100000 - staked + paid);
  const tx = q('SELECT amount, balance_before b0, balance_after b1 FROM wallet_tx WHERE user_id = ? ORDER BY id').all(uid);
  assert.ok(tx.every((t, i) => t.b1 === t.b0 + t.amount && (i === 0 || tx[i - 1].b1 === t.b0)));
});
