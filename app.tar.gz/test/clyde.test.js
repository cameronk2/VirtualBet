// Clyde Blackjack: the Top 3 side bet and the clyde table through the real handler and ledger.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { topThree, TOP3_PAYS, startRound, perfectPairs, twentyOnePlus3, CLYDE_PP_PAYS, CLYDE_T213_PAYS, PP_PAYS } from '../server/blackjack.js';

test('Top 3 pays trips 90:1, straight flush 180:1, suited trips 270:1, nothing else', () => {
  assert.equal(topThree(['7H', '7H', '7H']), 'suitedTrips');
  assert.equal(topThree(['7H', '7S', '7D']), 'trips');
  assert.equal(topThree(['5C', '6C', '7C']), 'straightFlush');
  assert.equal(topThree(['QD', 'KD', 'AD']), 'straightFlush');
  assert.equal(topThree(['5C', '6D', '7C']), null, 'a plain straight does not pay');
  assert.equal(topThree(['2C', '9C', 'KC']), null, 'a plain flush does not pay');
  assert.deepEqual(TOP3_PAYS, { suitedTrips: 270, straightFlush: 180, trips: 90 });
});

test('side bets settle on the deal and add to the round total', () => {
  let n = 0;
  for (let seed = 1; seed < 4000; seed++) {
    let x = seed; const rand = () => ((x = (x * 48271) % 2147483647) / 2147483647);
    const s = startRound([{ bet: 100, pp: 10, t213: 10, top3: 10 }], rand, { table: 'clyde' });
    const seat = s.seats[0];
    assert.equal(s.totalStaked, 130);
    const k = topThree([seat.hands[0].cards[0], seat.hands[0].cards[1], s.dealer[0]]);
    assert.equal(seat.side.top3.result, k);
    assert.equal(seat.side.top3.payout, k ? 10 * (TOP3_PAYS[k] + 1) : 0);
    if (k) n++;
    const pk = perfectPairs(seat.hands[0].cards[0], seat.hands[0].cards[1]);
    assert.equal(seat.side.pp.payout, pk ? 10 * (CLYDE_PP_PAYS[pk] + 1) : 0);
    const tk = twentyOnePlus3([seat.hands[0].cards[0], seat.hands[0].cards[1], s.dealer[0]]);
    assert.equal(seat.side.t213.payout, tk ? 100 : 0, '21+3 pays a flat 9:1 at the Clyde table');
  }
  assert.ok(n >= 0);
});

process.env.DATABASE_PATH = path.join(os.tmpdir(), `vb-clyde-${process.pid}-${Date.now()}.db`);
const { openDb, q } = await import('../server/db.js');
openDb(process.env.DATABASE_PATH);
const { deal, action, getTable } = await import('../server/casino.js');
const { credit } = await import('../server/wallet.js');

test('the clyde table: one box, Top 3 accepted, stake and returns through the wallet', () => {
  q('INSERT INTO users (username, password_hash, balance, created_at) VALUES (?, ?, 0, 0)').run('clyde1', 'x');
  const uid = q('SELECT id FROM users WHERE username = ?').get('clyde1').id;
  credit(uid, 'DEPOSIT', 1_000_000, null, 'test');
  const bal = () => q('SELECT balance FROM users WHERE id = ?').get(uid).balance;
  assert.throws(() => deal(uid, { seats: [{ bet: 100 }, { bet: 100 }] }, 'clyde'), /one box/);
  assert.throws(() => deal(uid, { seats: [{ bet: 100, top3: 10 }] }, 'blackjack'), /only on the Clyde/);
  for (let i = 0; i < 60; i++) {
    const before = bal();
    let t = deal(uid, { seats: [{ bet: 100, pp: 20, t213: 20, top3: 20 }] }, 'clyde');
    let extra = 0;
    while (t.round.status === 'player') { const a = t.round.allowed.stand ? 'stand' : 'hit'; t = action(uid, { action: a }, 'clyde'); }
    assert.equal(bal(), before - 160 - extra + t.round.totalPayout);
  }
  assert.ok(getTable(uid, 'clyde').history.length > 0);
});

test('Clyde side-bet tables: Pairs 30/12/5, 21+3 flat 9:1; the classic table keeps its own', () => {
  assert.deepEqual(CLYDE_PP_PAYS, { perfect: 30, coloured: 12, mixed: 5 });
  for (const v of Object.values(CLYDE_T213_PAYS)) assert.equal(v, 9);
  assert.equal(PP_PAYS.perfect, 25);
});
