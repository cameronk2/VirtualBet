// Fortune Live: wheel make-up, exact returns, booster, bonus rules, the pick step and the ledger.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { spinRound, validateBets, playDrop, spinFrenzy, makeFrenzy, fortune } from '../server/games/fortune/engine.js';
import { BONUS_IDS, BONUS_MAX_X, DROP_SLOTS, FRENZY_SEGS, SPOTS, SPOT_IDS, TABLES, WHEEL, FLAPPER_OFFSET } from '../server/games/fortune/config.js';
import { spotRtp, boosterChance } from '../server/games/fortune/maths.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const idx = (spot) => WHEEL.indexOf(spot);
const ALL = Object.fromEntries(SPOT_IDS.map((id) => [id, 100]));

test('wheel: 54 segments: 21 × 1, 13 × 2, 7 × 5, 4 × 10, 4 / 2 / 2 / 1 bonuses', () => {
  assert.equal(WHEEL.length, 54);
  const n = (s) => WHEEL.filter((x) => x === s).length;
  assert.deepEqual(SPOT_IDS.map(n), [21, 13, 7, 4, 4, 2, 2, 1]);
  for (let i = 0; i < 54; i++) assert.ok(!(SPOTS[WHEEL[i]].kind === 'bonus' && SPOTS[WHEEL[(i + 1) % 54]].kind === 'bonus'), 'bonuses never touch');
});

test('every spot returns 96% exactly; the booster never lights two spots', () => {
  for (const id of SPOT_IDS) assert.ok(Math.abs(spotRtp(id) - 0.96) < 1e-9, id);
  assert.ok(boosterChance() < 1);
  for (const id of BONUS_IDS) assert.ok(TABLES[id].every(([v, w]) => v > 0 && w > 0), id);
});

test('bets are validated', () => {
  assert.throws(() => validateBets({}), /Place a bet/);
  assert.throws(() => validateBets({ n3: 100 }), /Unknown/);
  assert.throws(() => validateBets({ n1: 5 }), /at least/);
  assert.throws(() => validateBets({ n1: 10001 }), /at most/);
  assert.deepEqual(validateBets({ n1: 100, n2: 0 }), { n1: 100 });
});

test('numbers pay their number to 1 (times the booster when it lines up); other bets lose', () => {
  for (const id of ['n1', 'n2', 'n5', 'n10']) {
    for (let s = 1; s < 120; s++) {
      const r = spinRound(ALL, seeded(s), { segment: idx(id) });
      const m = r.booster.hit && r.booster.spot === id ? r.booster.mult : 1;
      assert.equal(r.boost, m);
      assert.equal(r.results[id].ret, 100 * (1 + SPOTS[id].pay * m));
      for (const o of SPOT_IDS) if (o !== id) assert.equal(r.results[o].ret, 0);
      assert.equal(r.payout, r.results[id].ret);
      assert.ok(r.done);
    }
  }
  const boosted = spinRound({ n10: 100 }, seeded(3), { segment: idx('n10'), booster: { spot: 'n10', mult: 50, hit: true } });
  assert.equal(boosted.results.n10.ret, 100 * (1 + 500));
  const miss = spinRound({ n10: 100 }, seeded(3), { segment: idx('n10'), booster: { spot: 'n10', mult: 50, hit: false } });
  assert.equal(miss.results.n10.ret, 1100);
});

test('Coin Toss pays the side that lands; Drop Zone doubles and drops again', () => {
  for (let s = 1; s < 200; s++) {
    const r = spinRound({ toss: 100 }, seeded(s), { segment: idx('toss') });
    assert.equal(r.toss.x, r.toss.side === 'red' ? r.toss.red : r.toss.blue);
    assert.equal(r.results.toss.ret, Math.floor(100 * (1 + r.x)));
    assert.equal(r.x, Math.min(BONUS_MAX_X, r.toss.x * r.boost));
  }
  let sawDouble = false;
  for (let s = 1; s < 3000; s++) {
    const d = playDrop(seeded(s));
    assert.equal(d.board.length, DROP_SLOTS);
    assert.equal(d.board.filter((v) => v === 'D').length, 2);
    for (const k of d.drops) { let c = k.start; for (const st of k.steps) { c += st; assert.ok(c >= 0 && c <= DROP_SLOTS - 1); } assert.equal(c, k.slot); }
    const last = d.drops.at(-1);
    d.drops.slice(0, -1).forEach((k, i) => { assert.equal(d.board[k.slot], 'D'); assert.equal(k.factor, 2 ** i); });
    if (d.drops.length > 1) sawDouble = true;
    if (d.board[last.slot] !== 'D') assert.equal(d.x, Math.min(BONUS_MAX_X, d.board[last.slot] * last.factor));
  }
  assert.ok(sawDouble);
});

test('Fortune Frenzy: each flapper reads its own segment; DOUBLE / TRIPLE respin', () => {
  for (let s = 1; s < 500; s++) {
    const w = makeFrenzy(seeded(s));
    assert.equal(w.length, FRENZY_SEGS);
    assert.equal(w.filter((v) => v === 'DBL').length, 2);
    assert.equal(w.filter((v) => v === 'TRP').length, 1);
    for (const f of ['green', 'blue', 'yellow']) {
      const r = spinFrenzy(w, f, seeded(s + 7));
      let factor = 1;
      for (const sp of r.spins) {
        assert.equal(sp.seg, (sp.stop + FLAPPER_OFFSET[f]) % FRENZY_SEGS);
        assert.equal(sp.factor, factor);
        if (sp.value === 'DBL') factor *= 2; else if (sp.value === 'TRP') factor *= 3;
      }
      const end = r.spins.at(-1);
      if (typeof end.value === 'number') assert.equal(r.x, Math.min(BONUS_MAX_X, end.value * end.factor));
    }
  }
});

test('Prize Wall waits for a pick and keeps the prizes hidden until then', () => {
  const state = fortune.init();
  const r = spinRound({ wall: 100, n1: 50 }, seeded(9), { segment: idx('wall') });
  assert.equal(r.done, false);
  assert.equal(r.results.n1.ret, 0);
  // a player who is not in the bonus just watches it
  const w = spinRound({ n1: 50 }, seeded(9), { segment: idx('wall') });
  assert.ok(w.done && w.watched && w.wall.values.length === 108);
  assert.equal(w.payout, 0);
  assert.ok(state);
});

// ── through the real casino handler and ledger ──
process.env.DATABASE_PATH = path.join(os.tmpdir(), `vb-fl-${process.pid}-${Date.now()}.db`);
const { openDb, q } = await import('../server/db.js');
openDb(process.env.DATABASE_PATH);
const { playCasino, getCasino } = await import('../server/casino.js');
const { credit } = await import('../server/wallet.js');
function user(name, funds) {
  q('INSERT INTO users (username, password_hash, balance, created_at) VALUES (?, ?, 0, 0)').run(name, 'x');
  const id = q('SELECT id FROM users WHERE username = ?').get(name).id;
  credit(id, 'DEPOSIT', funds, null, 'test funds');
  return id;
}
const balance = (id) => q('SELECT balance FROM users WHERE id = ?').get(id).balance;

test('a full round through the wallet: stake out, bonus paid on the pick, never twice', () => {
  const uid = user('fortune1', 1_000_000);
  let sawPending = 0;
  for (let i = 0; i < 400 && sawPending < 6; i++) {
    const before = balance(uid);
    const res = playCasino(uid, 'fortune', 'spin', { bets: { wall: 100, frenzy: 100, n1: 100 } });
    const out = res.out;
    if (out.done) { assert.equal(balance(uid), before - 300 + out.payout); continue; }
    sawPending++;
    assert.equal(balance(uid), before - 300);
    const v = getCasino(uid, 'fortune').view;
    assert.equal(v.pending.bonus, out.landed);
    assert.equal(JSON.stringify(v).includes('"values"'), false, 'prizes hidden');
    assert.throws(() => playCasino(uid, 'fortune', 'spin', { bets: { n1: 100 } }), /Finish the bonus/);
    if (out.landed === 'wall') assert.throws(() => playCasino(uid, 'fortune', 'pick', { pick: 500 }), /108/);
    const pick = out.landed === 'wall' ? { pick: 17 } : { pick: 'yellow' };
    const done = playCasino(uid, 'fortune', 'pick', pick).out;
    assert.equal(done.results[out.landed].ret, Math.floor(100 * (1 + done.x)));
    assert.equal(balance(uid), before - 300 + done.payout);
    if (out.landed === 'wall') assert.equal(done.wall.base, done.wall.values[17]);
    else assert.equal(done.frenzy.flapper, 'yellow');
    assert.throws(() => playCasino(uid, 'fortune', 'pick', pick), /no bonus/);
  }
  assert.ok(sawPending > 0, 'reached a picking bonus');
  const h = getCasino(uid, 'fortune').view;
  assert.ok(h.history.length > 0 && h.stats.rounds > 0);
});
