// Phoenix Ember Link: base game, eggs, Area Link, every upgrade alone and in every combination,
// Firestorm, jackpots, denominations and the money ledger.
import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { act, init } from '../server/games/phoenix/engine.js';
import { respin, settleBonus, startBonus, ALL_KEYS } from '../server/games/phoenix/bonus.js';
import { lineWins } from '../server/games/phoenix/reels.js';
import { EGG_CHANCE, FIRESTORM_CHANCE, JACKPOTS, LINES, PAYTABLE, RESPINS, STAKES, UPGRADES } from '../server/games/phoenix/config.js';

function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const never = () => 0.999999;
const G = (cols) => cols.map((col) => col.map((s) => (typeof s === 'string' ? { s } : s)));
// reel 1 and reel 2 share no symbol and there are no Wilds, so nothing pays
const NOWIN = (over = {}) => G([['A', 'K', 'Q'], ['J', 'T', 'N'], ['A', 'K', 'Q'], ['J', 'T', 'N'], ['A', 'K', 'Q']].map((col, c) => col.map((s, r) => over[`${c}-${r}`] || s)));
const fb = (c = 'yellow', v = 100, jp) => ({ s: 'FB', fb: { c, v, ...(jp ? { jp } : {}) } });
const combos = (arr) => arr.reduce((acc, x) => acc.concat(acc.map((s) => [...s, x])), [[]]).filter((s) => s.length);
const total = (b) => b.arrays.reduce((s, a) => s + Object.values(a.cells).reduce((t, x) => t + x.v, 0) + (a.full ? JACKPOTS.grand * b.bet : 0), 0);

test('only the six listed bets are accepted: 20p, 50p, £1, £2, £5, £10', () => {
  assert.deepEqual(STAKES, [20, 50, 100, 200, 500, 1000]);
  for (const bad of [10, 30, 99, 0, -20, 12.5, 2000, '100']) assert.throws(() => act(init(), 'spin', { stake: bad }, { rand: never }));
  for (const d of STAKES) assert.equal(act(init(), 'spin', { stake: d }, { rand: rng(d) }).stake, d);
});

test('20 fixed, distinct paylines', () => {
  assert.equal(LINES.length, 20);
  assert.equal(new Set(LINES.map((l) => l.join())).size, 20);
  for (const l of LINES) assert.ok(l.length === 5 && l.every((r) => r >= 0 && r <= 2));
});

test('every symbol pays 3, 4 and 5 of a kind left to right at every bet', () => {
  let n = 0;
  for (const d of STAKES) for (const [sym, pays] of Object.entries(PAYTABLE)) for (const len of [3, 4, 5]) {
    // the symbol along the middle line on reels 1..len; top and bottom rows can't connect
    const fill = ['A', 'K', 'Q', 'J', 'T', 'N', 'GREEN'].filter((x) => x !== sym);
    const grid = G([0, 1, 2, 3, 4].map((c) => [fill[c % 2], c < len ? sym : fill[2 + (c % 2)], fill[4 + (c % 2)]]));
    const wins = lineWins(grid, d);
    const w = wins.find((x) => x.line === 0);
    assert.ok(w, `${sym} x${len}`); assert.equal(w.symbol, sym); assert.equal(w.count, len);
    assert.equal(w.amount, Math.round((d * pays[len - 3]) / 100));
    const r = act(init(), 'spin', { stake: d }, { rand: never, inject: { grid, firestorm: false } });
    assert.equal(r.payout, wins.reduce((a, x) => a + x.amount, 0), 'payout = sum of line wins');
    n++;
  }
  assert.equal(n, STAKES.length * 11 * 3);
});

test('the Wild substitutes for paying symbols but never for Fireballs', () => {
  const grid = G([['K', 'FEATHER', 'K'], ['K', 'WILD', 'Q'], ['Q', 'WILD', 'Q'], ['J', 'FEATHER', 'J'], ['T', 'N', 'T']]);
  const w = lineWins(grid, 100).find((x) => x.line === 0);
  assert.equal(w.symbol, 'FEATHER'); assert.equal(w.count, 4);
  const g2 = G([[fb(), 'A', 'K'], ['WILD', 'J', 'Q'], ['WILD', 'T', 'N'], [fb(), 'K', 'Q'], ['A', 'J', 'T']]);
  assert.equal(lineWins(g2, 100).filter((x) => x.line === 1).length, 0, 'Fireball + Wilds is not a win');
});

test('coloured Fireballs light their eggs for that spin only; nothing builds up between spins', () => {
  const grid = NOWIN({ '0-0': fb('orange'), '1-1': fb('blue'), '2-2': fb('blue'), '3-0': fb('yellow') });
  const r = act(init(), 'spin', { stake: 100 }, { rand: never, inject: { grid, firestorm: false, hatch: [] } });
  assert.deepEqual(r.out.lit, ['orange', 'blue']);
  assert.equal(r.out.lights.length, 3, 'yellow Fireballs light nothing');
  assert.equal(r.state.mode, 'base');
  assert.equal(r.state.eggs, undefined, 'no egg progress is stored');
  const r2 = act(r.state, 'spin', { stake: 100 }, { rand: never, inject: { grid: NOWIN(), firestorm: false } });
  assert.deepEqual(r2.out.lit, []);
});

test('a lit egg can hatch at random and start Area Link with every lit egg\'s upgrade', () => {
  const grid = NOWIN({ '0-0': fb('orange', 300), '2-1': fb('green', 200), '4-2': fb('yellow', 100) });
  const r = act(init(), 'spin', { stake: 100 }, { rand: rng(3), inject: { grid, firestorm: false, hatch: ['green'] } });
  assert.equal(r.state.mode, 'bonus'); assert.equal(r.out.source, 'egg');
  assert.deepEqual(r.out.hatched, ['green']); assert.deepEqual(r.out.upgrades, ['orange', 'green']);
  const cells = r.state.bonus.arrays[0].cells;
  assert.equal(cells['0-0'].v, 300); assert.equal(cells['2-1'].v, 200); assert.equal(cells['4-2'].v, 100);
  assert.ok(Object.keys(cells).length >= 3);
  // only a lit colour can hatch
  const r2 = act(init(), 'spin', { stake: 100 }, { rand: rng(3), inject: { grid, firestorm: false, hatch: ['magenta'] } });
  assert.equal(r2.state.mode, 'base');
  // with the real chances, hatching is random and roughly EGG_CHANCE per coloured Fireball
  const rand = rng(77); let n = 0, h = 0;
  for (let i = 0; i < 20000; i++) { const x = act(init(), 'spin', { stake: 100 }, { rand, inject: { grid: NOWIN({ '0-0': fb('red') }), firestorm: false } }); n++; if (x.out.hatched.length) h++; }
  assert.ok(Math.abs(h / n - EGG_CHANCE) < 0.003, `hatch rate ${h / n}`);
});

test('5 Fireballs do nothing, 6 start Area Link with the Fireballs locked where they landed', () => {
  const five = NOWIN({ '0-0': fb(), '1-0': fb(), '2-0': fb(), '3-0': fb(), '4-0': fb() });
  assert.equal(act(init(), 'spin', { stake: 100 }, { rand: never, inject: { grid: five, firestorm: false } }).state.mode, 'base');
  const six = NOWIN({ '0-0': fb('yellow', 300), '1-0': fb('yellow', 200), '2-0': fb('yellow', 0, 'mini'), '3-0': fb('blue', 500), '4-0': fb(), '0-2': fb('red', 700) });
  six[2][0].fb.v = 1000;
  const r = act(init(), 'spin', { stake: 100 }, { rand: never, inject: { grid: six, firestorm: false } });
  assert.equal(r.state.mode, 'bonus'); assert.ok(r.out.started);
  const cells = r.state.bonus.arrays[0].cells;
  assert.deepEqual(Object.keys(cells).sort(), ['0-0', '0-2', '1-0', '2-0', '3-0', '4-0']);
  assert.deepEqual(cells['0-0'], { t: 'cash', v: 300 }); assert.deepEqual(cells['2-0'], { t: 'jp', jp: 'mini', v: 1000 });
  assert.equal(cells['3-0'].t, 'cash', 'coloured Fireballs lock as Yellow prizes');
  assert.equal(r.state.bonus.arrays[0].spinsLeft, RESPINS);
  assert.throws(() => act(r.state, 'spin', { stake: 100 }, { rand: never }), /Finish/);
});

test('Phoenix Firestorm: on any spin with a Fireball the Phoenix may fly out, with random upgrades plus every lit egg', () => {
  const grid = NOWIN({ '2-1': fb('yellow', 150), '0-0': fb('blue', 50) });
  const r = act(init(), 'spin', { stake: 50 }, { rand: rng(4), inject: { grid, firestorm: true, firestormUpgrades: ['magenta', 'green'], hatch: [] } });
  assert.ok(r.out.firestorm); assert.equal(r.state.mode, 'bonus'); assert.equal(r.out.source, 'firestorm');
  assert.deepEqual(r.out.upgrades, ['magenta', 'blue', 'green']);
  assert.equal(r.state.bonus.arrays.length, 2, 'Magenta adds the second array');
  assert.ok(Object.keys(r.state.bonus.arrays[0].cells).length >= 3 && r.state.bonus.arrays[0].cells['2-1'].v === 150);
  // no Fireball, no Firestorm
  const r2 = act(init(), 'spin', { stake: 50 }, { rand: rng(4), inject: { grid: NOWIN(), firestorm: true } });
  assert.equal(r2.state.mode, 'base');
  // random upgrades: 1 to 5, never repeated, and all five are possible
  const seen = new Set();
  for (let i = 0; i < 3000; i++) { const x = act(init(), 'spin', { stake: 50 }, { rand: rng(i + 9), inject: { grid: NOWIN({ '2-1': fb() }), firestorm: true, hatch: [] } }); const u = x.out.upgrades; assert.ok(u.length >= 1 && u.length <= 5 && new Set(u).size === u.length); seen.add(u.length); }
  assert.deepEqual([...seen].sort(), [1, 2, 3, 4, 5]);
  assert.ok(FIRESTORM_CHANCE > 0 && FIRESTORM_CHANCE < 0.01);
});

const mk = (ups, cells = { '0-0': { t: 'cash', v: 200 }, '1-0': { t: 'cash', v: 300 }, '2-0': { t: 'jp', jp: 'mini', v: 1000 } }, bet = 100) => {
  const b = startBonus({ bet, upgrades: ups, start: [], source: 'test', rand: rng(1), min: 0 });
  b.arrays[0].cells = structuredClone(cells);
  if (b.arrays[1]) b.arrays[1].cells = { '4-2': { t: 'cash', v: 100 } };
  return b;
};

test('respins: a landing resets the counter to 3, nothing landing counts down, 0 ends the array', () => {
  const b = mk([]);
  let r = respin(b, never, { 0: [] }); assert.equal(b.arrays[0].spinsLeft, 2); assert.equal(r.done, false);
  r = respin(b, never, { 0: [{ k: '3-1', type: 'yellow', v: 400 }] }); assert.equal(b.arrays[0].spinsLeft, 3);
  r = respin(b, never, { 0: [] }); r = respin(b, never, { 0: [] }); assert.equal(r.done, false);
  r = respin(b, never, { 0: [] }); assert.equal(r.done, true); assert.equal(b.arrays[0].spinsLeft, 0);
  assert.equal(settleBonus(b).total, 200 + 300 + 1000 + 400);
});

test('locked Fireballs never move, vanish or change value without an upgrade', () => {
  const b = mk([]); const rand = rng(9);
  const seen = {};
  for (let i = 0; i < 40 && !b.arrays[0].done; i++) {
    respin(b, rand);
    for (const [k, x] of Object.entries(b.arrays[0].cells)) { if (seen[k] != null) assert.equal(x.v, seen[k], `${k} kept its prize`); seen[k] = x.v; }
    assert.equal(Object.keys(b.arrays[0].cells).length, Object.keys(seen).length);
  }
});

test('filling all 15 spots wins the Grand (5,000x) on top of every prize', () => {
  const b = mk([]);
  const r = respin(b, never, { 0: ALL_KEYS.filter((k) => !b.arrays[0].cells[k]).map((k) => ({ k, type: 'yellow', v: 100 })) });
  assert.ok(r.done && b.arrays[0].full);
  const st = settleBonus(b);
  assert.equal(st.arrays[0].grand, 5000 * 100); assert.equal(st.total, 500000 + 1500 + 12 * 100);
  assert.ok(st.arrays[0].jackpots.includes('grand') && st.arrays[0].jackpots.includes('mini'));
});

test('Orange: a 2x/3x/5x multiplier each respin, applied to new Yellow cash prizes as they lock (not jackpots)', () => {
  for (const m of [2, 3, 5]) {
    const b = mk(['orange']);
    const r = respin(b, never, { mult: m, 0: [{ k: '0-1', type: 'yellow', v: 150 }, { k: '1-1', type: 'yellow', jp: 'minor' }] });
    assert.equal(r.mult, m);
    assert.equal(b.arrays[0].cells['0-1'].v, 150 * m);
    assert.equal(b.arrays[0].cells['1-1'].v, JACKPOTS.minor * 100);
    assert.equal(b.arrays[0].cells['0-0'].v, 200, 'already-locked prizes are not multiplied again');
  }
  const b = mk(['orange']); const seen = new Set();
  for (let i = 0; i < 200; i++) { respin(b, rng(i)); seen.add(b.mult); b.arrays[0].done = false; }
  assert.deepEqual([...seen].sort(), [2, 3, 5]);
  const nb = mk([]); respin(nb, never, { mult: 5, 0: [{ k: '0-1', type: 'yellow', v: 150 }] });
  assert.equal(nb.arrays[0].cells['0-1'].v, 150, 'no multiplier without Orange');
});

test('Magenta: two arrays with their own counters, both settle before the feature ends', () => {
  const b = mk(['magenta']);
  assert.equal(b.arrays.length, 2);
  let r = respin(b, never, { 0: [{ k: '0-1', type: 'yellow', v: 100 }], 1: [] });
  assert.equal(b.arrays[0].spinsLeft, 3); assert.equal(b.arrays[1].spinsLeft, 2);
  r = respin(b, never, { 0: [], 1: [] }); r = respin(b, never, { 0: [], 1: [] });
  assert.ok(b.arrays[1].done && !b.arrays[0].done && !r.done, 'array 2 stopped, array 1 still going');
  r = respin(b, never, { 0: [{ k: '4-1', type: 'yellow', v: 100 }], 1: [{ k: '0-0', type: 'yellow', v: 999 }] });
  assert.ok(!b.arrays[1].cells['0-0'], 'a stopped array never spins again');
  assert.ok(r.events[1].skipped);
  r = respin(b, never, { 0: [] }); r = respin(b, never, { 0: [] }); r = respin(b, never, { 0: [] });
  assert.ok(r.done);
  const st = settleBonus(b);
  assert.equal(st.arrays.length, 2); assert.equal(st.arrays[1].total, 100);
  assert.equal(st.total, 200 + 300 + 1000 + 100 + 100 + 100);
});

test('Red: collects every other prize on its array, becomes Yellow, and each prize is paid exactly once', () => {
  const b = mk(['red']);
  const r = respin(b, never, { 0: [{ k: '4-1', type: 'red', v: 50 }] });
  const red = r.events[0].reds[0];
  assert.equal(red.collected, 200 + 300 + 1000);
  assert.deepEqual(b.arrays[0].cells['4-1'], { t: 'cash', v: 50 + 1500 });
  assert.equal(b.arrays[0].cells['0-0'].v, 200, 'collected prizes stay as they were');
  respin(b, never, { 0: [] }); respin(b, never, { 0: [] }); const end = respin(b, never, { 0: [] });
  assert.ok(end.done);
  assert.equal(settleBonus(b).total, 1500 + 1550, 'every prize once + the Red total once');
  // two Reds on one respin don't collect each other
  const b2 = mk(['red']);
  respin(b2, never, { 0: [{ k: '3-1', type: 'red', v: 10 }, { k: '4-1', type: 'red', v: 20 }] });
  assert.equal(b2.arrays[0].cells['3-1'].v, 1510); assert.equal(b2.arrays[0].cells['4-1'].v, 1520);
});

test('Blue: adds its prize to random Yellow cash prizes (the same one can be hit twice), then becomes Yellow', () => {
  const b = mk(['blue'], { '0-0': { t: 'cash', v: 200 } });
  const r = respin(b, () => 0, { blueHits: 3, 0: [{ k: '4-1', type: 'blue', v: 70 }] });
  const blue = r.events[0].blues[0];
  assert.equal(blue.transfers.length, 3);
  assert.equal(b.arrays[0].cells['0-0'].v, 200 + 70 * 3, 'one target can take every transfer');
  assert.deepEqual(b.arrays[0].cells['4-1'], { t: 'cash', v: 70 });
  const b2 = mk(['blue']);
  const r2 = respin(b2, rng(3), { blueHits: 2, 0: [{ k: '4-1', type: 'blue', v: 70 }] });
  for (const t of r2.events[0].blues[0].transfers) assert.notEqual(b2.arrays[0].cells[t.k].t, 'jp', 'jackpots are not boosted');
});

test('Green: grows by a random amount every respin, and keeps every increase', () => {
  const b = mk(['green']);
  respin(b, never, { 0: [{ k: '4-2', type: 'green', v: 100 }] });
  let last = b.arrays[0].cells['4-2'].v; assert.equal(last, 100, 'a new Green starts growing on the next respin');
  for (let i = 0; i < 3; i++) {
    const r = respin(b, rng(i), { 0: [] });
    const g = r.events[0].greens.find((x) => x.k === '4-2');
    assert.ok(g.add >= 100, 'grows by at least 1x stake'); assert.equal(g.v, last + g.add); last = g.v;
  }
  assert.equal(b.arrays[0].cells['4-2'].t, 'green');
  assert.equal(settleBonus(b).total, 1500 + last);
});

test('every one of the 31 upgrade combinations plays out correctly', () => {
  const all = combos(UPGRADES);
  assert.equal(all.length, 31);
  for (const ups of all) for (let seed = 1; seed <= 25; seed++) {
    const rand = rng(seed * 101 + ups.length);
    const b = startBonus({ bet: 50, upgrades: ups, start: [{ k: '0-0', v: 100 }, { k: '1-1', v: 50 }, { k: '2-2', jp: 'mini', v: 500 }], source: 'test', rand, min: 6 });
    assert.equal(b.arrays.length, ups.includes('magenta') ? 2 : 1);
    let prev = b.arrays.map((a) => ({ ...a.cells }));
    for (let i = 0; i < 400; i++) {
      const r = respin(b, rand);
      if (!ups.includes('orange')) assert.equal(r.mult, null);
      else assert.ok([2, 3, 5].includes(r.mult));
      b.arrays.forEach((a, ai) => {
        for (const [k, x] of Object.entries(prev[ai])) {
          assert.ok(a.cells[k], `${ups}: locked ${k} stays`);
          assert.ok(a.cells[k].v >= x.v, `${ups}: prizes never shrink`);
          if (!ups.includes('blue') && !ups.includes('green')) assert.equal(a.cells[k].v, x.v, `${ups}: only Blue/Green change a locked prize`);
        }
        for (const x of Object.values(a.cells)) {
          assert.ok(['cash', 'jp', 'green'].includes(x.t), 'Red and Blue resolve the same respin');
          if (x.t === 'green') assert.ok(ups.includes('green'));
          assert.ok(Number.isSafeInteger(x.v) && x.v > 0);
        }
        assert.ok(a.spinsLeft >= 0 && a.spinsLeft <= 3);
      });
      prev = b.arrays.map((a) => structuredClone(a.cells));
      if (r.done) break;
    }
    assert.ok(b.arrays.every((a) => a.done), `${ups}: finished`);
    assert.equal(settleBonus(b).total, total(b), `${ups}: payout = every prize once + Grands`);
  }
});

test('jackpots and prizes scale with the stake (100x Major pays £50 at 50p)', () => {
  assert.deepEqual(JACKPOTS, { mini: 10, minor: 20, major: 100, grand: 5000 });
  for (const bet of STAKES) {
    const b = mk([], {}, bet);
    respin(b, never, { 0: [{ k: '0-0', type: 'yellow', jp: 'major' }, { k: '1-0', type: 'yellow', jp: 'mini' }, { k: '2-0', type: 'yellow', jp: 'minor' }] });
    assert.equal(b.arrays[0].cells['0-0'].v, 100 * bet);
    if (bet === 50) assert.equal(b.arrays[0].cells['0-0'].v, 5000, '£50');
    assert.equal(b.arrays[0].cells['1-0'].v, 10 * bet); assert.equal(b.arrays[0].cells['2-0'].v, 20 * bet);
  }
});

test('a whole bonus through the engine pays exactly once, at the end', () => {
  for (let seed = 1; seed <= 60; seed++) {
    const rand = rng(seed);
    const six = NOWIN({ '0-0': fb(), '1-0': fb(), '2-0': fb(), '3-0': fb(), '4-0': fb(), '0-2': fb() });
    let r = act(init(), 'spin', { stake: 200 }, { rand, inject: { grid: six, firestorm: seed % 2 === 1, hatch: [] } });
    let paid = 0, s = r.state, n = 0;
    while (s.mode === 'bonus') {
      const before = structuredClone(s.bonus);
      r = act(s, 'respin', {}, { rand }); s = r.state; paid += r.payout; n++;
      assert.equal(r.stake, 0, 'respins are free');
      if (!r.out.result) assert.equal(r.payout, 0, 'nothing is paid mid-feature');
      else assert.equal(r.payout, r.out.result.total);
      assert.ok(before);
    }
    assert.ok(n >= 3);
    assert.throws(() => act(s, 'respin', {}, { rand }), /no bonus/, 'a second settle is impossible');
  }
});

test('practice rounds cost nothing and pay nothing', () => {
  for (const ev of ['bonus', 'egg', 'firestorm', 'grand', 'all', ...UPGRADES]) {
    const s0 = init();
    let r = act(s0, 'dev', { stake: 100, event: ev }, { rand: rng(2) });
    assert.equal(r.stake, 0); let s = r.state, paid = 0, last;
    while (s.mode === 'bonus') { last = act(s, 'respin', {}, { rand: rng(3) }); s = last.state; paid += last.payout; }
    assert.equal(paid, 0); assert.ok(last.out.practice); assert.ok(last.out.result.total > 0, 'the practice tally is still shown');
    if (ev === 'grand') assert.ok(last.out.result.arrays.every((a) => a.grand > 0));
  }
});

test('payouts reach the balance through the real casino ledger, and a refresh resumes the bonus', async () => {
  process.env.DATABASE_PATH = path.join(os.tmpdir(), `vb-ph-${process.pid}-${Date.now()}.db`);
  const { openDb, q } = await import('../server/db.js');
  openDb(process.env.DATABASE_PATH);
  const { playCasino, getCasino } = await import('../server/casino.js');
  const { credit } = await import('../server/wallet.js');
  q("INSERT INTO users (username, password_hash, balance, created_at) VALUES ('phtest', 'x', 0, 0)").run();
  const uid = q("SELECT id FROM users WHERE username = 'phtest'").get().id;
  credit(uid, 'DEPOSIT', 1000000, null, 'test funds');
  const bal = () => q('SELECT balance FROM users WHERE id = ?').get(uid).balance;
  let paid = 0, staked = 0, bonuses = 0;
  for (let i = 0; i < 400; i++) {
    const r = playCasino(uid, 'phoenix', 'spin', { stake: 20 }); staked += r.out.staked; paid += r.out.win;
    if (r.view.mode === 'bonus') {
      bonuses++;
      assert.equal(getCasino(uid, 'phoenix').view.mode, 'bonus', 'reloading shows the bonus in progress');
      assert.throws(() => playCasino(uid, 'phoenix', 'spin', { stake: 20 }));
      let v = r.view; while (v.mode !== 'base') { const x = playCasino(uid, 'phoenix', 'respin', {}); paid += x.out.win; v = x.view; }
    }
  }
  assert.equal(bal(), 1000000 - staked + paid);
  assert.ok(bal() >= 0);
  const tx = q('SELECT amount, balance_before b0, balance_after b1 FROM wallet_tx WHERE user_id = ? ORDER BY id').all(uid);
  assert.ok(tx.every((t, i) => t.b1 === t.b0 + t.amount && (i === 0 || tx[i - 1].b1 === t.b0)));
});
