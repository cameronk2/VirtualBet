// Virtual horse racing: cards, the simulation, odds, every bet type's settlement (including dead
// heats), and full flows through the real wallet (quick races and the timetable).
import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { FORMATS, COURSES, buildHorses, placeTerms, seeded } from '../server/racing/data.js';
import { BET_TYPES, checkBet, makeCard, potential, priceBet, resultOf, settle, simulate, toFraction, marginLabel } from '../server/racing/core.js';

const H = buildHorses();
const R = seeded(7);

test('the horse database is fixed, unique and complete', () => {
  assert.equal(H.length, 240);
  assert.equal(new Set(H.map((h) => h.name)).size, 240);
  assert.deepEqual(buildHorses().map((h) => h.name), H.map((h) => h.name), 'same horses on every server');
  for (const h of H) {
    for (const k of ['speed', 'stamina', 'accel', 'finish', 'temperament']) assert.ok(h.ratings[k] >= 35 && h.ratings[k] <= 99, `${h.name} ${k}`);
    assert.ok(h.trainer && h.silks.c1 && h.style && h.age >= 3);
  }
});

test('each-way terms follow the usual UK rules', () => {
  assert.deepEqual(placeTerms(6, false), { places: 2, fraction: [1, 4] });
  assert.deepEqual(placeTerms(8, true), { places: 3, fraction: [1, 5] });
  assert.deepEqual(placeTerms(12, true), { places: 3, fraction: [1, 4] });
  assert.deepEqual(placeTerms(12, false), { places: 3, fraction: [1, 5] });
  assert.deepEqual(placeTerms(16, true), { places: 4, fraction: [1, 4] });
  assert.deepEqual(placeTerms(16, false), { places: 3, fraction: [1, 5] });
});

test('every format and field size makes a valid, priced card', () => {
  for (const f of FORMATS) for (const field of f.fields) {
    const c = makeCard({ pool: H, rand: R, courseId: COURSES[field % COURSES.length].id, formatId: f.id, field, sims: 120 });
    assert.equal(c.runners.length, field);
    assert.deepEqual(c.runners.map((r) => r.no), Array.from({ length: field }, (_, i) => i + 1));
    assert.deepEqual([...c.runners.map((r) => r.draw)].sort((a, b) => a - b), Array.from({ length: field }, (_, i) => i + 1));
    assert.equal(new Set(c.runners.map((r) => r.horseId)).size, field, 'no horse twice');
    assert.equal(new Set(c.runners.map((r) => r.jockey)).size, field, 'no jockey twice');
    const book = c.runners.reduce((a, r) => a + 1 / r.odds.dec, 0);
    assert.ok(book > 1.0 && book < 1.6, `${f.id}/${field} book ${book}`);
    assert.ok(f.furlongs.includes(c.furlongs));
  }
});

test('the simulation: times, order, margins and the trace agree', () => {
  for (let i = 0; i < 40; i++) {
    const f = FORMATS[i % FORMATS.length];
    const c = makeCard({ pool: H, rand: R, courseId: 'rivermead', formatId: f.id, sims: 40 });
    const sim = simulate(c, H, R);
    const res = resultOf(c, sim);
    assert.equal(res.positions.length, c.field);
    for (let k = 1; k < res.positions.length; k++) assert.ok(res.positions[k].time >= res.positions[k - 1].time, 'ordered by time');
    // the animation's frames show the same order: the frame each horse first reaches the line
    const crossAt = c.runners.map((_, idx) => sim.trace.frames.findIndex((fr) => fr[idx] >= c.distance));
    for (let k = 1; k < sim.order.length; k++) assert.ok(crossAt[sim.order[k]] >= crossAt[sim.order[k - 1]], 'trace agrees with result');
    for (let k = 1; k < sim.trace.frames.length; k++) sim.trace.frames[k].forEach((x, j) => assert.ok(x >= sim.trace.frames[k - 1][j], 'horses only move forward'));
    const secsPerFurlong = res.winTime / c.furlongs;
    assert.ok(secsPerFurlong > 11 && secsPerFurlong < 14.5, `realistic pace ${secsPerFurlong.toFixed(2)} s/f`);
  }
});

test('the favourite wins about as often as its price says', () => {
  const c = makeCard({ pool: H, rand: R, courseId: 'ashcombe', formatId: 'mile', field: 8, sims: 1500 });
  const fav = c.runners.reduce((a, r) => (r.chance > a.chance ? r : a));
  let w = 0; const N = 1500;
  for (let i = 0; i < N; i++) if (c.runners[simulate(c, H, R, { trace: false }).order[0]].no === fav.no) w++;
  assert.ok(Math.abs(w / N - fav.chance) < 0.06, `favourite won ${w / N} vs chance ${fav.chance}`);
  assert.ok(1 / fav.odds.dec < fav.chance + 0.2);
});

test('margins and odds format', () => {
  assert.equal(marginLabel(0.02), 'nse'); assert.equal(marginLabel(0.1), 'shd'); assert.equal(marginLabel(0.2), 'hd'); assert.equal(marginLabel(0.3), 'nk');
  assert.equal(marginLabel(0.5), '½'); assert.equal(marginLabel(1.25), '1¼'); assert.equal(marginLabel(2.75), '2¾'); assert.equal(marginLabel(40), 'dist');
  assert.deepEqual(toFraction(3.5), { num: 5, den: 2, dec: 3.5 });
  assert.deepEqual(toFraction(3.49), { num: 9, den: 4, dec: 3.25 }, 'rounded down to the ladder');
  assert.deepEqual(toFraction(2), { num: 1, den: 1, dec: 2 });
});

// A hand-made card and results for exact settlement checks
const CARD = { field: 8, handicap: false, terms: { places: 3, fraction: [1, 5] }, runners: [1, 2, 3, 4, 5, 6, 7, 8].map((no) => ({ no, chance: [0.3, 0.2, 0.15, 0.1, 0.1, 0.07, 0.05, 0.03][no - 1], odds: [{ num: 2, den: 1, dec: 3 }, { num: 4, den: 1, dec: 5 }, { num: 5, den: 1, dec: 6 }, { num: 8, den: 1, dec: 9 }, { num: 8, den: 1, dec: 9 }, { num: 12, den: 1, dec: 13 }, { num: 16, den: 1, dec: 17 }, { num: 33, den: 1, dec: 34 }][no - 1] })) };
const res = (order, ties = {}) => ({ positions: order.map((no, k) => ({ no, pos: ties[no] ?? k + 1 })) });
const bet = (type, picks, stake = 100) => { const price = priceBet(CARD, type, picks); const b = { type, picks, stake, lines: BET_TYPES[type].lines, price }; b.potential = potential(b); return b; };

test('settlement: win, place and each way', () => {
  const r = res([3, 1, 5, 2, 4, 6, 7, 8]);
  assert.equal(settle(bet('win', [3]), r), 600);           // 5/1: £1 → £6
  assert.equal(settle(bet('win', [1]), r), 0);
  assert.equal(bet('place', [1]).price.place.dec, 1.4);    // 2/1 at ⅕ odds = 2/5 → 1.4
  assert.equal(settle(bet('place', [1]), r), 140);
  assert.equal(settle(bet('place', [5]), r), Math.floor(100 * (1 + 8 / 5)));
  assert.equal(settle(bet('place', [2]), r), 0, '4th is out of the places');
  const ew = bet('each_way', [3]);
  assert.equal(ew.lines, 2);
  assert.equal(settle(ew, r), 600 + 200, 'win part 5/1 + place part 1/1');
  assert.equal(settle(bet('each_way', [5]), r), 260, 'placed only: place part pays');
  assert.equal(settle(bet('each_way', [8]), r), 0);
});

test('settlement: forecast, reverse forecast, tricast, trio', () => {
  const r = res([3, 1, 5, 2]);
  const fc = bet('forecast', [3, 1]);
  assert.equal(settle(fc, r), Math.floor(100 * fc.price.lines[0].dec));
  assert.equal(settle(bet('forecast', [1, 3]), r), 0, 'wrong order');
  const rf = bet('reverse_forecast', [1, 3]);
  assert.equal(rf.lines, 2);
  assert.equal(settle(rf, r), Math.floor(100 * rf.price.lines.find((l) => l.order[0] === 3).dec), 'one line wins');
  const tc = bet('tricast', [3, 1, 5]);
  assert.equal(settle(tc, r), Math.floor(100 * tc.price.lines[0].dec));
  assert.equal(settle(bet('tricast', [3, 5, 1]), r), 0);
  const trio = bet('trio', [5, 1, 3]);
  assert.equal(settle(trio, r), Math.floor(100 * trio.price.lines[0].dec), 'any order');
  assert.equal(settle(bet('trio', [5, 1, 2]), r), 0);
  assert.ok(trio.price.lines[0].dec < tc.price.lines[0].dec, 'a trio pays less than the exact tricast');
});

test('settlement: dead heats split the stake', () => {
  // 3 and 1 dead-heat for first
  const r = res([3, 1, 5, 2], { 3: 1, 1: 1, 5: 3, 2: 4 });
  assert.equal(settle(bet('win', [3]), r), 300, 'half the stake at 5/1');
  assert.equal(settle(bet('win', [1]), r), 150, 'half the stake at 2/1');
  // dead heat for third with three places: the two share one place
  const r2 = res([1, 2, 3, 4], { 1: 1, 2: 2, 3: 3, 4: 3 });
  assert.equal(settle(bet('place', [4]), r2), Math.floor(100 * (1 + 8 / 5) * 0.5));
  assert.equal(settle(bet('place', [3]), r2), Math.floor(100 * (1 + 5 / 5) * 0.5));
});

test('bet validation', () => {
  assert.match(checkBet(CARD, { type: 'win', picks: [1], stake: 5 }), /minimum/);
  assert.match(checkBet(CARD, { type: 'win', picks: [1], stake: -100 }), /minimum/);
  assert.match(checkBet(CARD, { type: 'win', picks: [1], stake: 10.5 }), /minimum/);
  assert.match(checkBet(CARD, { type: 'win', picks: [1], stake: 200000 }), /maximum/);
  assert.match(checkBet(CARD, { type: 'forecast', picks: [1, 1], stake: 100 }), /different/);
  assert.match(checkBet(CARD, { type: 'tricast', picks: [1, 2], stake: 100 }), /3 selections/);
  assert.match(checkBet(CARD, { type: 'win', picks: [9], stake: 100 }), /not in this race/);
  assert.match(checkBet(CARD, { type: 'lucky15', picks: [1], stake: 100 }), /bet type/);
  assert.equal(checkBet(CARD, { type: 'trio', picks: [1, 2, 3], stake: 100 }), null);
});

// ── through the real wallet ──
process.env.DATABASE_PATH = path.join(os.tmpdir(), `vb-rc-${process.pid}-${Date.now()}.db`);
const { openDb, q } = await import('../server/db.js');
openDb(process.env.DATABASE_PATH);
const { credit } = await import('../server/wallet.js');
const rc = await import('../server/racing/service.js');
rc.seedHorses();
const user = (name, funds) => { q('INSERT INTO users (username, password_hash, balance, created_at) VALUES (?, ?, 0, 0)').run(name, 'x'); const id = q('SELECT id FROM users WHERE username = ?').get(name).id; if (funds) credit(id, 'DEPOSIT', funds, null, 'test'); return id; };
const bal = (id) => q('SELECT balance FROM users WHERE id = ?').get(id).balance;
let nn = 0; const nonce = () => `n${Date.now().toString(36)}${nn++}xx`;

test('quick race: every bet type, debit, run, settle, records', () => {
  const uid = user('punter', 1_000_000);
  for (const f of FORMATS) {
    const race = rc.createQuick(uid, { format: f.id, field: f.fields[0] });
    assert.equal(race.phase, 'ready');
    assert.equal(race.trace, undefined, 'no run before the off');
    const nos = race.runners.map((r) => r.no);
    const slip = [
      { type: 'win', picks: [nos[0]], stake: 100 }, { type: 'each_way', picks: [nos[1]], stake: 50 }, { type: 'place', picks: [nos[2]], stake: 100 },
      { type: 'forecast', picks: [nos[0], nos[1]], stake: 20 }, { type: 'reverse_forecast', picks: [nos[2], nos[3]], stake: 20 },
      { type: 'tricast', picks: [nos[0], nos[1], nos[2]], stake: 10 }, { type: 'trio', picks: [nos[3], nos[4], nos[5]], stake: 10 },
    ];
    const before = bal(uid);
    const placed = rc.placeBets(uid, { raceId: race.id, bets: slip, nonce: nonce() });
    assert.equal(placed.total, 100 + 100 + 100 + 20 + 40 + 10 + 10);
    assert.equal(bal(uid), before - placed.total);
    const done = rc.startQuick(uid, race.id);
    assert.ok(done.trace && done.result);
    assert.ok(done.myBets.every((b) => b.status === 'running'), 'outcomes stay hidden while the run is being shown');
    const settled = rc.getRace(race.id, uid, Date.now() + 10 * 60 * 1000).myBets;
    const paid = settled.reduce((a, b) => a + b.returns, 0);
    assert.equal(bal(uid), before - placed.total + paid, `${f.id}: balance = start − stakes + returns`);
    for (const b of settled) {
      assert.notEqual(b.status, 'open');
      assert.equal(b.returns, settle({ ...b }, done.result), 'returns match the result');
    }
    assert.throws(() => rc.startQuick(uid, race.id), /already been run/);
    assert.throws(() => rc.placeBets(uid, { raceId: race.id, bets: slip, nonce: nonce() }), /closed/);
  }
  const tx = q('SELECT amount, balance_before b0, balance_after b1 FROM wallet_tx WHERE user_id = ? ORDER BY id').all(uid);
  assert.ok(tx.every((t, i) => t.b1 === t.b0 + t.amount && (i === 0 || tx[i - 1].b1 === t.b0)), 'ledger continuous');
  const st = rc.myStats(uid);
  assert.equal(st.bets, FORMATS.length * 7);
  assert.ok(st.favouriteHorses.length > 0);
});

test('refusals: balance, duplicates, other players’ races, bad input', () => {
  const poor = user('poor', 200);
  const r = rc.createQuick(poor, { format: 'sprint', field: 6 });
  assert.throws(() => rc.placeBets(poor, { raceId: r.id, bets: [{ type: 'win', picks: [1], stake: 500 }], nonce: nonce() }), /Not enough virtual balance/);
  assert.equal(bal(poor), 200);
  const n1 = nonce();
  rc.placeBets(poor, { raceId: r.id, bets: [{ type: 'win', picks: [1], stake: 100 }], nonce: n1 });
  assert.throws(() => rc.placeBets(poor, { raceId: r.id, bets: [{ type: 'win', picks: [1], stake: 100 }], nonce: n1 }), /already been placed/);
  assert.equal(bal(poor), 100, 'a repeated tap is not charged');
  const other = user('other', 10000);
  assert.throws(() => rc.placeBets(other, { raceId: r.id, bets: [{ type: 'win', picks: [1], stake: 100 }], nonce: nonce() }), /not found/);
  assert.throws(() => rc.startQuick(other, r.id), /not found/);
  assert.throws(() => rc.placeBets(poor, { raceId: r.id, bets: [{ type: 'win', picks: [1], stake: -10 }], nonce: nonce() }), /minimum/);
  assert.throws(() => rc.placeBets(poor, { raceId: r.id, bets: [], nonce: nonce() }), /between 1 and 20/);
  assert.throws(() => rc.placeBets(poor, { raceId: r.id, bets: [{ type: 'win', picks: [1], stake: 10 }] }), /reference/);
  assert.throws(() => rc.createQuick(poor, { format: 'mile', field: 16 }), /runners/);
  rc.createQuick(poor, { format: 'mile' }); rc.createQuick(poor, { format: 'mile' });
  assert.throws(() => rc.createQuick(poor, { format: 'mile' }), /up to 3/);
});

test('the timetable: races are created ahead, run at the off and settled after the broadcast', () => {
  const uid = user('regular', 100000);
  const t0 = Math.ceil(Date.now() / rc.SLOT_MS) * rc.SLOT_MS + 1000;
  rc.ensureSchedule(t0, 3);
  const ov = rc.overview(uid, t0);
  assert.ok(ov.upcoming.length >= 3);
  const race = ov.upcoming[0];
  assert.equal(race.phase, 'open');
  const card = rc.getRace(race.id, uid, t0);
  const nonceA = nonce();
  rc.placeBets(uid, { raceId: race.id, bets: [{ type: 'win', picks: [card.runners[0].no], stake: 500 }, { type: 'each_way', picks: [card.runners[1].no], stake: 200 }], nonce: nonceA });
  assert.equal(bal(uid), 100000 - 900);
  // at the off: the race runs, but nothing is settled until the run has been shown
  rc.runDue(race.off);
  const live = rc.getRace(race.id, uid, race.off + 1000);
  assert.equal(live.phase, 'live');
  assert.ok(live.myBets.every((b) => b.status === 'running'));
  assert.equal(bal(uid), 100000 - 900, 'no winnings paid during the broadcast');
  const end = race.off + live.duration * 1000 + 2000;
  rc.runDue(end);
  const after = rc.getRace(race.id, uid, end);
  assert.equal(after.phase, 'result');
  const paid = after.myBets.reduce((a, b) => a + b.returns, 0);
  assert.equal(bal(uid), 100000 - 900 + paid);
  for (const b of after.myBets) assert.equal(b.returns, settle(b, after.result));
  const lb = rc.leaderboard('week', end);
  assert.ok(lb.active.some((r) => r.name === 'regular'));
  const horse = rc.horseProfile(after.runners[0].horseId, uid);
  assert.ok(horse.runs >= 1);
  assert.throws(() => rc.placeBets(uid, { raceId: race.id, bets: [{ type: 'win', picks: [1], stake: 100 }], nonce: nonce() }), /closed/);
});
