// Bonus Buy on the server: settings (stored in app_settings, edited by admins), purchase records
// (bonus_buys), the player's purchase history and the admin statistics. The purchase itself is
// server/games/bonusbuy/buy.js, called from playCasino inside the same database transaction that
// takes the money, so the debit, the bonus and the record are all-or-nothing.
import { q, tx } from './db.js';
import { config } from './config.js';
import { HttpError, now } from './util.js';
import { ADAPTERS, NOT_SUPPORTED, defaultConfig, inBonus, mergeConfig, publicOptions, validateConfig } from './games/bonusbuy/buy.js';
import { PRICES } from './games/bonusbuy/prices.js';
import { GAMES } from './games/registry.js';

const KEY = 'bonusbuy';
export function getConfig() {
  const r = q('SELECT value FROM app_settings WHERE key = ?').get(KEY);
  let saved = null; try { saved = r ? JSON.parse(r.value) : null; } catch { saved = null; }
  return mergeConfig(saved);
}

export const isAdmin = (u) => !!u && config.adminUsers.includes(String(u.username).toLowerCase());
function requireAdmin(u) { if (!isAdmin(u)) throw new HttpError(403, 'Admins only.'); }

/** Options a player can buy in one game, plus their recent purchases there. */
export function playerOptions(userId, game) {
  if (!GAMES[game]) throw new HttpError(404, 'Unknown game.');
  const opts = publicOptions(game, getConfig());
  return { buy: opts, unsupported: opts ? null : (NOT_SUPPORTED[game] || (ADAPTERS[game] ? 'Bonus Buy is switched off for this game.' : 'This game has no bonus to buy.')), purchases: purchases(userId, game) };
}
export function purchases(userId, game = null, limit = 20) {
  const rows = game
    ? q('SELECT * FROM bonus_buys WHERE user_id = ? AND game = ? ORDER BY id DESC LIMIT ?').all(userId, game, limit)
    : q('SELECT * FROM bonus_buys WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit);
  return rows.map(pub);
}
const pub = (r) => ({ id: r.id, game: r.game, gameName: GAMES[r.game]?.label || r.game, option: r.option, name: r.name, bet: r.bet, costX: r.cost_x, cost: r.cost, payout: r.payout, net: r.payout - r.cost, status: r.status, at: r.created_at, settledAt: r.settled_at });

/** Before a purchase: refuse a nonce that was already used (a repeated tap or a resent request). */
export function checkNonce(userId, nonce) {
  if (typeof nonce !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(nonce)) throw new HttpError(400, 'Purchase reference missing. Please try again.');
  if (q('SELECT 1 FROM bonus_buys WHERE user_id = ? AND nonce = ?').get(userId, nonce)) throw new HttpError(409, 'That purchase has already been made.');
}
/** After the purchase's spin: record it (open until the bonus has been played). */
export function recordPurchase(userId, game, buy, nonce, payout, stateAfter) {
  const done = !inBonus(game, stateAfter);
  const t = now();
  const r = q(`INSERT INTO bonus_buys (user_id, game, option, name, bet, cost_x, cost, payout, status, nonce, created_at, settled_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(userId, game, buy.option, buy.name, buy.bet, buy.costX, buy.cost, payout, done ? 'settled' : 'open', nonce, t, done ? t : null);
  return Number(r.lastInsertRowid);
}
/** After any other action in the game: add its payout to an open purchase, and close it when the bonus ends. */
export function trackBonus(userId, game, payout, stateAfter) {
  const open = q("SELECT id FROM bonus_buys WHERE user_id = ? AND game = ? AND status = 'open' ORDER BY id DESC LIMIT 1").get(userId, game);
  if (!open) return null;
  const done = !inBonus(game, stateAfter);
  q(`UPDATE bonus_buys SET payout = payout + ?, status = ?, settled_at = ? WHERE id = ?`).run(payout || 0, done ? 'settled' : 'open', done ? now() : null, open.id);
  return done ? pub(q('SELECT * FROM bonus_buys WHERE id = ?').get(open.id)) : null;
}

/** Games whose purchases are tracked (any game with a Bonus Buy adapter). */
export const inBonusOf = (game) => !!ADAPTERS[game];

// ── admin ──
export function adminView(u) {
  requireAdmin(u);
  const cfg = getConfig();
  const stats = q(`SELECT game, option, COUNT(*) AS n, SUM(cost) AS staked, SUM(payout) AS paid, SUM(status = 'open') AS open, MAX(payout) AS best
                   FROM bonus_buys GROUP BY game, option`).all();
  const recent = q(`SELECT b.*, u.username FROM bonus_buys b JOIN users u ON u.id = b.user_id ORDER BY b.id DESC LIMIT 50`).all().map((r) => ({ ...pub(r), username: r.username }));
  const log = q("SELECT * FROM admin_log WHERE area = 'bonusbuy' ORDER BY id DESC LIMIT 50").all().map((r) => ({ ...r, change: JSON.parse(r.change) }));
  const games = Object.entries(ADAPTERS).map(([id, a]) => ({ id, name: GAMES[id]?.label || id, options: a.options.map((o) => ({ ...o, price: PRICES[id]?.[o.id] || null })) }));
  return { config: cfg, defaults: defaultConfig(), games, unsupported: NOT_SUPPORTED, stats, recent, log };
}
export function adminSave(u, next) {
  requireAdmin(u);
  const err = validateConfig(next);
  if (err) throw new HttpError(400, err);
  return tx(() => {
    const before = getConfig();
    const after = mergeConfig(next);
    q('INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(KEY, JSON.stringify(after));
    const diff = diffConfig(before, after);
    q('INSERT INTO admin_log (user_id, username, area, change, at) VALUES (?, ?, ?, ?, ?)').run(u.id, u.username, KEY, JSON.stringify(diff), now());
    return adminView(u);
  });
}
function diffConfig(a, b) {
  const d = [];
  if (a.enabled !== b.enabled) d.push(`Bonus Buy ${b.enabled ? 'on' : 'off'}`);
  if (a.minStake !== b.minStake) d.push(`Min stake ${a.minStake} → ${b.minStake}`);
  if (a.maxStake !== b.maxStake) d.push(`Max stake ${a.maxStake} → ${b.maxStake}`);
  for (const id of Object.keys(b.games)) {
    const ga = a.games[id], gb = b.games[id];
    if (ga.enabled !== gb.enabled) d.push(`${id} ${gb.enabled ? 'on' : 'off'}`);
    for (const oid of Object.keys(gb.options)) {
      const oa = ga.options[oid], ob = gb.options[oid];
      if (oa.enabled !== ob.enabled) d.push(`${id}/${oid} ${ob.enabled ? 'on' : 'off'}`);
      if (oa.cost !== ob.cost) d.push(`${id}/${oid} cost ${oa.cost}x → ${ob.cost}x`);
    }
  }
  return d.length ? d : ['No change'];
}
