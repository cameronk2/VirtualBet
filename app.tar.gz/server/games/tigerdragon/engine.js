// Gong Fortune – game flow (server-authoritative, persisted state).
//
// Modes: base -> tiger | dragon | combined -> base.
//   base      5 x 3, 243 ways. A spin with no regular win may award Mystery Gongs.
//   tiger     Hold & Respin on 5 x 3: 3 spins, every new gong locks and resets to 3.
//   dragon    exactly one spin on the 5 x 8 gong grid.
//   combined  5 x 8 with 3 rows open; rows open at 6/9/14/19/25 gongs; 3 spins that
//             reset on every new gong; 32 gongs wins the jackpot.
// Every result is decided here before anything animates. Gong values are drawn
// when a gong lands but are only shown when the round settles.
import { checkStake, fail } from '../common.js';
import {
  BONUS_ROWS, BUY_COMBINED_X, BUY_RANDOM_WEIGHTS, BUY_RANDOM_X, COMBINED_TRIGGER, DRAGON_TRIGGER,
  JACKPOT_GONGS, JACKPOT_X, MAX_WIN_X, RESPINS, REELS, ROWS, STAKE_MAX, STAKE_MIN, START_ROWS, TIGER_TRIGGER, TUNE, UNLOCKS,
} from './config.js';
import { drawGong, settle, weighted } from './gongs.js';
import { countOf, draw, evaluateWays, mysteryCells } from './reels.js';

export const init = () => ({ mode: 'base', bonus: null, recent: [], practice: false });

const rowsOf = (b) => (b.type === 'tiger' ? ROWS : BONUS_ROWS);
/** Rows a gong can land in: all of them, or for the combined bonus the bottom `open` rows. */
const openRow = (b, r) => b.type !== 'combined' || r >= BONUS_ROWS - b.open;
export const rowsFor = (count) => UNLOCKS.reduce((n, [at, rows]) => (count >= at ? rows : n), START_ROWS);

/** What the player may see. Locked gongs show as gongs; their values stay hidden until settlement. */
export function view(s) {
  const b = s.bonus;
  return {
    mode: s.mode, practice: !!s.practice,
    bonus: b && { type: b.type, bet: b.bet, source: b.source, spinsLeft: b.spinsLeft, open: b.open, count: Object.keys(b.cells).length, locked: Object.keys(b.cells), rows: rowsOf(b), spun: b.spun, capLeft: b.capLeft },
    recent: (s.recent || []).slice(0, 15),
  };
}

/**
 * Starts a bonus. [INT] The triggering Tiger (and Dragon) symbols become the
 * first locked gongs where they landed, as in IGT's Lock & Respin, which
 * "can start with three or more gongs". The 5 x 3 reels map onto the bottom
 * three rows of the 8-row grid. Bought bonuses get the same number of
 * starting gongs on random open spots. The Dragon Bonus starts empty: its
 * single spin decides everything.
 */
function startBonus(s, type, bet, source, rand, grid) {
  const b = { type, bet, source, cells: {}, spinsLeft: type === 'dragon' ? 1 : RESPINS, open: type === 'combined' ? START_ROWS : rowsOf({ type }), spun: 0 };
  if (type !== 'dragon') {
    const shift = type === 'combined' ? BONUS_ROWS - ROWS : 0;
    const want = type === 'combined' ? ['TIGER', 'DRAGON'] : ['TIGER'];
    let spots = grid ? grid.flatMap((col, c) => col.map((x, r) => (want.includes(x.s) ? `${c}-${r + shift}` : null)).filter(Boolean)) : [];
    if (!spots.length) {
      const need = type === 'combined' ? COMBINED_TRIGGER : TIGER_TRIGGER;
      const free = [];
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < REELS; c++) free.push(`${c}-${r + shift}`);
      while (spots.length < need) spots.push(free.splice(Math.floor(rand() * free.length), 1)[0]);
    }
    for (const k of spots) b.cells[k] = drawGong(rand);
    b.started = spots;
  }
  s.bonus = b;
  s.mode = type;
}

/** One bonus spin. `forced`: optional list of "c-r" keys that land (tests and practice). */
function bonusSpin(b, rand, forced) {
  const rows = rowsOf(b);
  const land = b.type === 'tiger' ? TUNE.tigerLand : b.type === 'dragon' ? TUNE.dragonLand : TUNE.combinedLand;
  const lands = [];
  for (let r = 0; r < rows; r++) {
    if (!openRow(b, r)) continue;
    for (let c = 0; c < REELS; c++) {
      const k = `${c}-${r}`;
      if (b.cells[k]) continue;
      const hit = forced ? forced.includes(k) : rand() < land;
      if (hit) { b.cells[k] = drawGong(rand); lands.push(k); }
    }
  }
  b.spun++;
  const before = b.open;
  const count = Object.keys(b.cells).length;
  if (b.type === 'combined') b.open = Math.max(b.open, rowsFor(count));
  const unlocked = b.open > before ? Array.from({ length: b.open - before }, (_, i) => before + i + 1) : [];
  if (b.type === 'dragon') b.spinsLeft = 0;
  else b.spinsLeft = lands.length ? RESPINS : b.spinsLeft - 1;
  const capacity = b.type === 'combined' ? BONUS_ROWS * REELS : rows * REELS;
  const full = count >= capacity;
  const jackpot = b.type === 'combined' && count >= JACKPOT_GONGS;
  const done = jackpot || full || b.spinsLeft <= 0;
  return { lands, count, unlocked, open: b.open, spinsLeft: b.spinsLeft, full, jackpot, done };
}

export function act(state, action, body, { rand, inject } = {}) {
  const s = { ...init(), ...structuredClone(state || {}) };
  const out = { action };
  const wasPractice = !!s.practice;
  let stake = 0, payout = 0, feature = false;
  const stakeOf = () => checkStake(body?.stake, { min: STAKE_MIN, max: STAKE_MAX });

  if (action === 'spin') {
    if (s.mode !== 'base') fail('Finish the bonus first.');
    const bet = stakeOf();
    stake = bet;
    const grid = inject?.grid || draw(rand);
    const wins = evaluateWays(grid, bet);
    const tigers = countOf(grid, 'TIGER'), dragons = countOf(grid, 'DRAGON');
    const lineWin = wins.reduce((a, w) => a + w.amount, 0);
    // Combined takes priority: 5+ of the two together, whatever the split
    const trigger = tigers + dragons >= COMBINED_TRIGGER ? 'combined' : tigers >= TIGER_TRIGGER ? 'tiger' : dragons >= DRAGON_TRIGGER ? 'dragon' : null;
    let mystery = null;
    // Mystery Gongs: only after a spin with no regular win
    if (!lineWin && !trigger) {
      const cells = inject?.mystery !== undefined ? inject.mystery : mysteryCells(grid, rand);
      if (cells) {
        const st = settle(cells, REELS, ROWS, bet);
        mystery = { cells, clusters: st.clusters, total: st.total };
      }
    }
    const raw = lineWin + (mystery?.total || 0);
    payout = Math.min(raw, bet * MAX_WIN_X);
    Object.assign(out, { grid, wins, tigers, dragons, lineWin, mystery, trigger, win: payout, bet, capped: payout < raw });
    if (trigger) { feature = true; startBonus(s, trigger, bet, 'base', rand, grid); s.bonus.capLeft = bet * MAX_WIN_X - payout; out.started = trigger; out.startCells = s.bonus.started || []; }
  } else if (action === 'buy') {
    if (s.mode !== 'base') fail('Finish the bonus first.');
    const bet = stakeOf();
    const option = body?.option;
    if (option !== 'random' && option !== 'combined') fail('Choose a bonus to buy.');
    stake = bet * (option === 'combined' ? BUY_COMBINED_X : BUY_RANDOM_X);
    const type = option === 'combined' ? 'combined' : (inject?.buyType || weighted(BUY_RANDOM_WEIGHTS, rand));
    startBonus(s, type, bet, 'buy', rand);
    out.startCells = s.bonus.started || [];
    feature = true;
    Object.assign(out, { bought: option, started: type, bet, cost: stake, win: 0 });
  } else if (action === 'respin') {
    if (!s.bonus) fail('There is no bonus in play.');
    const b = s.bonus;
    const forced = inject?.lands || (s.practice && b.forced?.length ? b.forced.shift() : undefined);
    const r = bonusSpin(b, rand, forced);
    Object.assign(out, r, { type: b.type, bet: b.bet });
    if (r.done) {
      const all = settle(b.cells, REELS, rowsOf(b), b.bet);
      const raw = r.jackpot ? b.bet * JACKPOT_X : all.total;
      payout = Math.min(raw, b.capLeft ?? b.bet * MAX_WIN_X);
      out.result = {
        type: b.type, jackpot: r.jackpot, gongs: r.count, cells: b.cells, clusters: r.jackpot ? [] : all.clusters,
        clusterTotal: all.total, win: payout, capped: payout < raw, source: b.source, spun: b.spun,
      };
      out.win = payout;
      s.bonus = null; s.mode = 'base';
    } else out.win = 0;
  } else if (action === 'dev') {
    // Practice triggers for testing every feature: cost nothing, pay nothing.
    if (s.mode !== 'base') fail('Finish the bonus first.');
    const bet = stakeOf();
    const ev = body?.event;
    s.practice = true;
    if (ev === 'tiger' || ev === 'dragon' || ev === 'combined') { startBonus(s, ev, bet, 'practice', rand); out.started = ev; out.startCells = s.bonus.started || []; }
    else if (ev === 'jackpot') {
      startBonus(s, 'combined', bet, 'practice', rand);
      // Every open spot lands each spin until 32 gongs are held
      const open = (n) => Array.from({ length: n * REELS }, (_, i) => `${i % REELS}-${BONUS_ROWS - 1 - Math.floor(i / REELS)}`);
      s.bonus.forced = [open(3), open(4), open(5), open(6), open(7), open(8)];
      out.started = 'combined';
    } else if (ev === 'mystery') {
      // A practice non-winning spin that shows Mystery Gongs: reel 1 and reel 2 share no symbol, so nothing pays
      s.practice = false;
      const grid = [['ENVELOPE', 'LOTUS', 'LANTERN'], ['FAN', 'BANGLE', 'ORNAMENT'], ['LOTUS', 'FAN', 'ENVELOPE'], ['BANGLE', 'LANTERN', 'ORNAMENT'], ['FAN', 'LOTUS', 'BANGLE']].map((col) => col.map((x) => ({ s: x })));
      const cells = { '0-1': { n: 5 }, '1-1': { n: 3 }, '2-1': { a: 5 }, '3-1': { n: 8 }, '4-0': { n: 7 } };
      const st = settle(cells, REELS, ROWS, bet);
      Object.assign(out, { grid, wins: evaluateWays(grid, bet), tigers: 0, dragons: 0, lineWin: 0, mystery: { cells, clusters: st.clusters, total: st.total }, trigger: null, bet, win: 0 });
      out.practice = true;
    } else fail('Unknown test event.');
  } else fail('Unknown action.');

  if (wasPractice || s.practice) { stake = 0; payout = 0; out.practice = true; out.win = 0; if (s.mode === 'base') s.practice = false; }
  out.payout = payout; out.mode = s.mode;
  if (stake || payout) s.recent = [{ bet: out.bet, win: payout, kind: action === 'respin' ? out.type : action }, ...(s.recent || [])].slice(0, 20);
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'slot', game: 'tigerdragon', x: out.bet ? payout / out.bet : 0, feature }] };
}

/** For the simulator and tests: a fresh bonus as if bought. */
export function bonusState(type, bet, rand) { const s = init(); startBonus(s, type, bet, 'sim', rand); return s; }

export const tigerdragon = { id: 'tigerdragon', label: 'Gong Fortune', init, view, act };
