// Gong values and cluster settlement (pure).
//
// A gong is { n } (a number 1-99) or { a } (an Arrow carrying a boost 1-90).
// Clusters: 2+ gongs side by side in the same row on neighbouring reels.
// Diagonal and vertical neighbours do not connect.
// A cluster's numbers are read left to right as one number (8, 5, 0 -> 850);
// each Arrow in the cluster adds its boost to the leftmost number first
// (1 -> 81 makes "1, 25" read 8125). The number is in credits.
import { ARROW_CHANCE, ARROW_WEIGHTS, CREDITS_PER_SPIN, NUMBER_WEIGHTS } from './config.js';

function weighted(pairs, rand) {
  let t = 0; for (const [, w] of pairs) t += w;
  let x = rand() * t;
  for (const [v, w] of pairs) if ((x -= w) < 0) return v;
  return pairs[pairs.length - 1][0];
}
const inRange = ([lo, hi], rand) => lo + Math.floor(rand() * (hi - lo + 1));

export function drawGong(rand) {
  if (rand() < ARROW_CHANCE) return { a: inRange(weighted(ARROW_WEIGHTS, rand), rand) };
  return { n: inRange(weighted(NUMBER_WEIGHTS, rand), rand) };
}

/** cells: { "col-row": gong }. Returns horizontal runs of 2+ gongs, row by row. */
export function findClusters(cells, cols, rows) {
  const out = [];
  for (let r = 0; r < rows; r++) {
    let run = [];
    const flush = () => { if (run.length >= 2) out.push(run); run = []; };
    for (let c = 0; c < cols; c++) {
      const g = cells[`${c}-${r}`];
      if (g) run.push({ c, r, ...g }); else flush();
    }
    flush();
  }
  return out;
}

/** Value of one cluster in credits (0 if it holds no numbers). */
export function clusterCredits(run) {
  const nums = run.filter((g) => g.n != null).map((g) => g.n);
  if (!nums.length) return { credits: 0, text: '', boost: 0 };
  const boost = run.reduce((a, g) => a + (g.a || 0), 0);
  nums[0] += boost;
  const text = nums.join('');
  return { credits: Number(text), text, boost };
}

/** Settles every cluster on a grid: pence per cluster and the total (before the max-win cap). */
export function settle(cells, cols, rows, bet) {
  const clusters = findClusters(cells, cols, rows).map((run) => {
    const { credits, text, boost } = clusterCredits(run);
    return { cells: run.map(({ c, r }) => [c, r]), gongs: run.map(({ n, a }) => (n != null ? { n } : { a })), credits, text, boost, win: Math.floor((credits * bet) / CREDITS_PER_SPIN) };
  });
  return { clusters, total: clusters.reduce((a, k) => a + k.win, 0) };
}

export { weighted };
