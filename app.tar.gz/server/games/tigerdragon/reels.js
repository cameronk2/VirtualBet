// Gong Fortune – base reels, 243 ways and Mystery Gong placement (pure).
import { LINE_SYMBOLS, MYSTERY_COUNT, MYSTERY_ROW_BIAS, PAYTABLE, REELS, ROWS, TUNE, WEIGHTS } from './config.js';
import { drawGong, weighted } from './gongs.js';

const TABLES = WEIGHTS.map((w) => Object.entries(w).filter(([, x]) => x > 0));

/** grid[reel][row] of { s }. Every visible cell is drawn independently. */
export function draw(rand) {
  return TABLES.map((t) => Array.from({ length: ROWS }, () => ({ s: weighted(t, rand) })));
}

export const countOf = (grid, sym) => grid.reduce((a, col) => a + col.filter((c) => c.s === sym).length, 0);

/**
 * 243 ways: a symbol pays when it is on reel 1 and on each neighbouring reel
 * after it (3, 4 or 5 reels). Each combination of positions is a way; the
 * pay is per way.
 */
export function evaluateWays(grid, bet) {
  const wins = [];
  for (const sym of LINE_SYMBOLS) {
    const reels = [];
    for (let r = 0; r < REELS; r++) {
      const rows = grid[r].map((c, row) => (c.s === sym ? row : -1)).filter((x) => x >= 0);
      if (!rows.length) break;
      reels.push(rows);
    }
    const count = reels.length;
    if (count < 3) continue;
    const ways = reels.reduce((a, x) => a * x.length, 1);
    const pay = PAYTABLE[sym][count - 3];
    const amount = Math.floor((bet * pay * ways) / 100);
    if (amount > 0) wins.push({ symbol: sym, count, ways, pay, amount, cells: reels.flatMap((rows, r) => rows.map((row) => [r, row])) });
  }
  return wins.sort((a, b) => b.amount - a.amount);
}

/**
 * Mystery Gongs after a non-winning spin: maybe nothing, otherwise 2-7 gongs on
 * random spots (often sharing a row, so they may connect). Returns { "c-r": gong } or null.
 */
export function mysteryCells(grid, rand) {
  if (rand() >= TUNE.mystery) return null;
  const n = weighted(MYSTERY_COUNT, rand);
  const cells = {};
  const row = Math.floor(rand() * ROWS);
  // pick from the spots still free, so placement always finishes
  const free = (inRow) => { const out = []; for (let r = 0; r < ROWS; r++) for (let c = 0; c < REELS; c++) if ((!inRow || r === row) && !cells[`${c}-${r}`]) out.push(`${c}-${r}`); return out; };
  for (let i = 0; i < n; i++) {
    let spots = rand() < MYSTERY_ROW_BIAS ? free(true) : free(false);
    if (!spots.length) spots = free(false);
    cells[spots[Math.floor(rand() * spots.length)]] = drawGong(rand);
  }
  return cells;
}
