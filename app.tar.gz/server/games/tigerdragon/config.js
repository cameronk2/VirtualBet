// Gong Fortune (Tiger & Dragon gong mechanics) – every tunable number.
//
// Each value is marked:
//   [REF]  published for the reference game (IGT's Tiger and Dragon – Cash
//          on Reels) and reproduced as stated
//   [INT]  our reading of a published rule where the sources are vague
//   [EST]  not published anywhere: chosen and tuned by simulation so the
//          whole game returns the target RTP. These are NOT IGT's numbers.
// Amounts are virtual pence; multipliers are multiples of the total stake.

export const REELS = 5;                       // [REF]
export const ROWS = 3;                        // [REF] 5 x 3, 243 ways
export const BONUS_ROWS = 8;                  // [REF] Dragon / Tiger & Dragon grid is 5 x 8
export const TARGET_RTP = 0.96;               // [REF] 96%
export const MAX_WIN_X = 2000;                // [REF] 2,000x, applied per spin / per bonus round

// [REF] bet range 0.75 - 90
export const STAKES = [75, 150, 300, 450, 750, 1500, 3000, 4500, 7500, 9000];
export const STAKE_MIN = 75;
export const STAKE_MAX = 9000;

// [INT] Gong numbers are credits. 75 credits per spin (0.75 minimum stake at 1p a credit),
// so a cluster reading "155" pays 155 x stake / 75.
export const CREDITS_PER_SPIN = 75;

// ── Base game ────────────────────────────────────────────────
// [REF] pays at the maximum stake of 90: high 36 / 72 / 108, low 18 / 54 / 90,
// i.e. 0.40 / 0.80 / 1.20 and 0.20 / 0.60 / 1.00 of the stake, per way.
export const HIGH = ['ENVELOPE', 'LOTUS', 'LANTERN'];
export const LOW = ['FAN', 'BANGLE', 'ORNAMENT'];
export const LINE_SYMBOLS = [...HIGH, ...LOW];
export const PAYTABLE = {                     // hundredths of the stake, for 3 / 4 / 5 of a kind
  ENVELOPE: [40, 80, 120], LOTUS: [40, 80, 120], LANTERN: [40, 80, 120],
  FAN: [20, 60, 100], BANGLE: [20, 60, 100], ORNAMENT: [20, 60, 100],
};

// [EST] symbol weights per reel (each visible cell is drawn independently)
export const WEIGHTS = [
  { ENVELOPE: 10, LOTUS: 11, LANTERN: 12, FAN: 15, BANGLE: 16, ORNAMENT: 17, TIGER: 1.95, DRAGON: 1.95 },
  { ENVELOPE: 10, LOTUS: 11, LANTERN: 12, FAN: 15, BANGLE: 16, ORNAMENT: 17, TIGER: 1.95, DRAGON: 1.95 },
  { ENVELOPE: 10, LOTUS: 11, LANTERN: 12, FAN: 15, BANGLE: 16, ORNAMENT: 17, TIGER: 1.95, DRAGON: 1.95 },
  { ENVELOPE: 10, LOTUS: 11, LANTERN: 12, FAN: 15, BANGLE: 16, ORNAMENT: 17, TIGER: 1.95, DRAGON: 1.95 },
  { ENVELOPE: 10, LOTUS: 11, LANTERN: 12, FAN: 15, BANGLE: 16, ORNAMENT: 17, TIGER: 1.95, DRAGON: 1.95 },
];

// [REF] triggers: 3+ Tiger, 3+ Dragon, 5+ Tiger and Dragon combined (combined takes priority)
export const TIGER_TRIGGER = 3;
export const DRAGON_TRIGGER = 3;
export const COMBINED_TRIGGER = 5;

// ── Gong values (all gong features) ──────────────────────────
// [REF] each gong reveals 1 - 99 or an Arrow. [REF/INT] an Arrow adds 1 - 90 to the
// cluster's leftmost number. [EST] how often each comes up:
export const ARROW_CHANCE = 0.05;
export const NUMBER_WEIGHTS = [               // [value range, weight]
  [[1, 1], 14], [[2, 2], 13], [[3, 3], 11], [[4, 4], 10], [[5, 5], 10], [[6, 6], 9], [[7, 7], 8], [[8, 8], 7], [[9, 9], 6],
  [[10, 19], 1.0], [[20, 49], 0.4], [[50, 99], 0.15],
];
export const ARROW_WEIGHTS = [[[1, 9], 16], [[10, 30], 3], [[31, 60], 0.8], [[61, 90], 0.3]];

// ── Mystery Gongs ("Cash on Reels" in the reference) ─────────
// [REF] only after a spin with no regular win. [EST] chance and how many gongs.
export const MYSTERY_CHANCE = 0.0271;
export const MYSTERY_COUNT = [[2, 46], [3, 34], [4, 15], [5, 5]];
// [EST] mystery gongs favour sharing a row so they often (not always) connect
export const MYSTERY_ROW_BIAS = 0.55;

// ── Tiger Bonus: Hold & Respin on 5 x 3 ──────────────────────
export const RESPINS = 3;                     // [REF] 3 spins, reset to 3 on every new gong
export const TIGER_LAND = 0.11;              // [EST] (tuned value lives in TUNE below)

// ── Dragon Bonus: one spin on 5 x 8 ──────────────────────────
export const DRAGON_LAND = 0.28;              // [EST] chance each of the 40 spots shows a gong

// ── Tiger & Dragon Bonus: 5 x 8, rows unlock ─────────────────
export const START_ROWS = 3;                  // [REF]
export const UNLOCKS = [[6, 4], [9, 5], [14, 6], [19, 7], [25, 8]]; // [REF] total gongs -> rows open
export const JACKPOT_GONGS = 32;              // [REF] 32 gongs wins the jackpot
export const JACKPOT_X = 2000;                // [EST] jackpot size not published; set to the 2,000x max win
export const COMBINED_LAND = 0.105;           // [EST] chance an open empty spot lands a gong on a respin

// ── Bonus buy ────────────────────────────────────────────────
export const BUY_RANDOM_X = 50;               // [REF] random Tiger / Dragon / Tiger & Dragon
export const BUY_COMBINED_X = 100;            // [REF] Tiger & Dragon Bonus
export const BUY_RANDOM_WEIGHTS = [['tiger', 45], ['dragon', 45], ['combined', 10]]; // [EST]

// [EST] Tuned by scripts/sim-tigerdragon.mjs (kept in one object so the simulator can search them).
// land: chance an empty open spot lands a gong on a bonus spin. mystery: chance a non-winning
// base spin gets Mystery Gongs.
export const TUNE = {
  tigerLand: 0.0400,
  dragonLand: 0.3366,
  combinedLand: 0.0340,
  mystery: MYSTERY_CHANCE,
};
