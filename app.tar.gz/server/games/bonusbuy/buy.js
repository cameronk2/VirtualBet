// Bonus Buy – the universal purchase. Shared by the server (server/casino.js) and the in-browser
// build (client/local/api.js), so the same rules apply everywhere.
//
//   cost = total bet × the option's cost multiplier (configurable by an administrator)
//
// The bought round is a genuine spin of the slot's own engine at the player's bet, drawn from the
// slot's normal reels until that spin triggers the chosen feature (a conditional draw: the spin is
// exactly as likely as any other triggering spin would be). Its line wins and the whole bonus that
// follows are paid by the slot's own code. The only change is the price: the player pays `cost`
// instead of the bet for that one spin.
import { ADAPTERS, NOT_SUPPORTED, triggered } from './adapters.js';
import { PRICES } from './prices.js';
import { GameError } from '../common.js';

const fail = (m) => { throw new GameError(m); };
export { ADAPTERS, NOT_SUPPORTED };

/** Default settings: everything on, cost = the simulated price for a ~96% return. */
export function defaultConfig() {
  const games = {};
  for (const [id, a] of Object.entries(ADAPTERS)) {
    games[id] = { enabled: true, options: Object.fromEntries(a.options.map((o) => [o.id, { enabled: true, cost: o.defaultCost ?? PRICES[id]?.[o.id]?.cost ?? 100 }])) };
  }
  return { enabled: true, minStake: 10, maxStake: 2000, games };
}

/** Saved admin settings on top of the defaults (unknown games/options are ignored). */
export function mergeConfig(saved) {
  const c = defaultConfig();
  if (!saved || typeof saved !== 'object') return c;
  if (typeof saved.enabled === 'boolean') c.enabled = saved.enabled;
  if (Number.isSafeInteger(saved.minStake) && saved.minStake > 0) c.minStake = saved.minStake;
  if (Number.isSafeInteger(saved.maxStake) && saved.maxStake >= c.minStake) c.maxStake = saved.maxStake;
  for (const [id, g] of Object.entries(saved.games || {})) {
    if (!c.games[id]) continue;
    if (typeof g.enabled === 'boolean') c.games[id].enabled = g.enabled;
    for (const [oid, o] of Object.entries(g.options || {})) {
      const t = c.games[id].options[oid]; if (!t) continue;
      if (typeof o.enabled === 'boolean') t.enabled = o.enabled;
      if (Number.isFinite(o.cost) && o.cost >= 1 && o.cost <= 5000) t.cost = Math.round(o.cost * 10) / 10;
    }
  }
  return c;
}

/** Validate an admin's edit; returns an error message or null. */
export function validateConfig(next) {
  if (!next || typeof next !== 'object') return 'Settings are missing.';
  if (typeof next.enabled !== 'boolean') return 'Choose whether Bonus Buy is on.';
  if (!Number.isSafeInteger(next.minStake) || next.minStake < 10) return 'Minimum stake must be at least 10p.';
  if (!Number.isSafeInteger(next.maxStake) || next.maxStake < next.minStake || next.maxStake > 100000) return 'Maximum stake must be between the minimum and £1,000.';
  for (const [id, g] of Object.entries(next.games || {})) {
    if (!ADAPTERS[id]) return `Unknown game: ${id}.`;
    for (const [oid, o] of Object.entries(g.options || {})) {
      if (!ADAPTERS[id].options.some((x) => x.id === oid)) return `Unknown option ${oid} for ${id}.`;
      if (!Number.isFinite(o.cost) || o.cost < 1 || o.cost > 5000) return `Cost for ${id} / ${oid} must be between 1x and 5,000x.`;
    }
  }
  return null;
}

/** What a player may see for one game: options, names, cost multipliers, theoretical return. */
export function publicOptions(id, cfg) {
  const a = ADAPTERS[id], g = cfg.games[id];
  if (!a || !cfg.enabled || !g?.enabled) return null;
  const options = a.options.filter((o) => g.options[o.id]?.enabled).map((o) => {
    const cost = g.options[o.id].cost, avg = PRICES[id]?.[o.id]?.avg;
    return { ...o, cost, rtp: avg ? Math.round((avg / cost) * 1000) / 10 : null };
  });
  return options.length ? { game: id, minStake: cfg.minStake, maxStake: cfg.maxStake, options } : null;
}

// A fast generator for the search, seeded with 128 bits from the secure RNG.
function sfc32(a, b, c, d) {
  return () => {
    a >>>= 0; b >>>= 0; c >>>= 0; d >>>= 0;
    const t = (a + b | 0) + d | 0; d = d + 1 | 0;
    a = b ^ b >>> 9; b = c + (c << 3) | 0; c = c << 21 | c >>> 11; c = c + t | 0;
    return (t >>> 0) / 4294967296;
  };
}
const MAX_TRIES = 400000;

/**
 * Buy a bonus. `engine` is the game's { act }. Returns the engine's normal result for the
 * triggering spin, with the stake replaced by the purchase cost and `out.bought` added.
 */
export function runBuy(id, engine, state, body, ctx, cfg) {
  const a = ADAPTERS[id];
  if (!a) fail(NOT_SUPPORTED[id] || 'This game has no bonus to buy.');
  if (!cfg.enabled || !cfg.games[id]?.enabled) fail('Bonus Buy is switched off for this game.');
  const option = body?.option;
  const meta = a.options.find((o) => o.id === option);
  const oc = cfg.games[id].options[option];
  if (!meta || !oc?.enabled) fail('Choose a bonus to buy.');
  if (state?.practice) fail('Finish the practice round first.');
  if (a.inBonus(state)) fail('Finish the bonus in play first.');
  const bet = body?.stake;
  if (!Number.isSafeInteger(bet) || bet < Math.max(cfg.minStake, ctx.minStake || 0)) fail(`Bonus Buy needs a bet of at least £${(Math.max(cfg.minStake, ctx.minStake || 0) / 100).toFixed(2)}.`);
  if (bet > cfg.maxStake) fail(`Bonus Buy is available up to a £${(cfg.maxStake / 100).toFixed(2)} bet.`);
  const cost = Math.round(bet * oc.cost);
  if (!Number.isSafeInteger(cost) || cost <= 0) fail('That purchase price is not valid.');

  let r = null, tries = 0;
  if (a.native) {
    r = engine.act(structuredClone(state), 'buy', { stake: bet, option }, ctx);
  } else {
    const seed = () => Math.floor(ctx.rand() * 4294967296);
    const rand = sfc32(seed(), seed(), seed(), seed());
    for (let i = 0; i < 12; i++) rand();
    const sctx = { ...ctx, rand };
    while (tries < MAX_TRIES) {
      tries++;
      const t = engine.act(structuredClone(state), 'spin', { stake: bet }, sctx);
      if (triggered(id, t.out || {}).includes(option)) { r = t; break; }
    }
    if (!r) fail('The bonus could not be started just now. You have not been charged; please try again.');
  }
  const paid = r.settled ? r.settled.payout : r.payout;
  return {
    ...r,
    stake: cost,
    settled: { staked: cost, payout: paid ?? r.payout ?? 0 },
    out: { ...r.out, bought: { option, name: meta.name, cost, costX: oc.cost, bet } },
    events: [...(r.events || []), { t: 'bonusbuy', game: id, option }],
    buy: { option, name: meta.name, cost, costX: oc.cost, bet, tries },
  };
}

/** True while the bonus from a purchase (or any bonus) is still being played. */
export const inBonus = (id, state) => !!ADAPTERS[id]?.inBonus(state);
