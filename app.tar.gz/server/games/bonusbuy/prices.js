// Written by scripts/sim-bonusbuy.mjs. avg = average return of a bought bonus (triggering spin +
// the whole bonus) in multiples of the bet; cost = the default price (avg / 0.96, rounded); se = standard
// error of avg; n = bought bonuses simulated.
export const PRICES = {
  phoenix: {
    arealink: {
      avg: 64.3,
      cost: 67,
      se: 1.32,
      n: 20000
    },
    firestorm: {
      avg: 84.27,
      cost: 88,
      se: 1.33,
      n: 20000
    }
  },
  tigerdragon: {
    random: {
      avg: 46.36,
      cost: 48,
      se: 1.4,
      n: 20000
    },
    combined: {
      avg: 94.47,
      cost: 98,
      se: 2.16,
      n: 20000
    }
  },
  genie: {
    free: {
      avg: 41.87,
      cost: 44,
      se: 0.42,
      n: 20000
    },
    treasure: {
      avg: 88.24,
      cost: 92,
      se: 1.46,
      n: 20000
    }
  },
  stampede: {
    hold: {
      avg: 28.08,
      cost: 29,
      se: 0.46,
      n: 20000
    },
    free: {
      avg: 27.17,
      cost: 28,
      se: 0.65,
      n: 20000
    }
  },
  brick: {
    hats: {
      avg: 49.1,
      cost: 51,
      se: 0.63,
      n: 20000
    },
    saws: {
      avg: 88.98,
      cost: 93,
      se: 1.39,
      n: 20000
    }
  },
  mummy: {
    free: {
      avg: 47.45,
      cost: 49,
      se: 0.43,
      n: 20000
    },
    cash: {
      avg: 48.28,
      cost: 50,
      se: 0.36,
      n: 20000
    }
  },
  moonridge: {
    free: {
      avg: 55.77,
      cost: 58,
      se: 1.3,
      n: 20000
    }
  },
  frost: {
    free: {
      avg: 23.31,
      cost: 24,
      se: 0.94,
      n: 20000
    }
  },
  atlantis: {
    treasure: {
      avg: 62.19,
      cost: 65,
      se: 0.58,
      n: 20000
    }
  },
  neon: {
    free: {
      avg: 42.18,
      cost: 44,
      se: 0.43,
      n: 20000
    }
  },
  dragon: {
    free: {
      avg: 19.31,
      cost: 20,
      se: 0.31,
      n: 20000
    }
  },
  cosmic: {
    free: {
      avg: 83.15,
      cost: 87,
      se: 0.72,
      n: 20000
    }
  },
  pharaoh: {
    free: {
      avg: 24.73,
      cost: 26,
      se: 0.18,
      n: 20000
    }
  },
  starlight: {
    free: {
      avg: 85.99,
      cost: 90,
      se: 0.7,
      n: 20000
    }
  },
  nebula: {
    free: {
      avg: 32.37,
      cost: 34,
      se: 0.23,
      n: 20000
    }
  },
  vault: {
    hold: {
      avg: 183.6,
      cost: 191,
      se: 2.57,
      n: 20000
    }
  }
};
