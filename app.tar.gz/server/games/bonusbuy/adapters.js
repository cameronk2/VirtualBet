// Bonus Buy – one adapter per slot. Each adapter says which bonus features the slot really has, how to
// recognise each one in that slot's own spin result, when a bonus is still in play, and (for the
// simulator and tests) how to play the bonus through to the end.
//
// A purchase plays the slot's own spin, from its own engine and reel weights, until that spin
// triggers the chosen feature (see buy.js). Nothing about the reels, paytable or bonus maths
// changes: the player gets a genuine triggering spin and the genuine bonus that follows it.
//
// To add a future slot: add an entry here (options + match + inBonus), run
// `node scripts/sim-bonusbuy.mjs <game>` to price it, and put the button on its screen
// (client/src/components/BonusBuy.jsx).

const modeBonus = (s) => !!s && ((s.mode && s.mode !== 'base') || (s.queue?.length > 0));
const freeBonus = (s) => !!s?.free;
const firstFree = (n, taken) => { for (let i = 0; i < n; i++) if (!taken(i)) return i; return 0; };

/** The usual "free spins from scatters" option for the simpler slots. */
const freeSpinsOnly = (name, desc, sym) => ({
  options: [{ id: 'free', name, desc, feature: `Triggered by ${sym}` }],
  match: (out) => (out.trigger?.freeSpins ? 'free' : null),
  inBonus: freeBonus,
});

export const ADAPTERS = {
  phoenix: {
    options: [
      { id: 'arealink', name: 'Area Link', desc: 'A real Area Link trigger: the Fireballs lock, 3 respins that reset with every landing, and any egg upgrades that spin lit.', feature: '6+ Fireballs, a hatching egg or the Firestorm' },
      { id: 'firestorm', name: 'Phoenix Firestorm', desc: 'The Phoenix sweeps the reels and starts Area Link with 1 to 5 random upgrades (Multiplier, Prize Increase, Prize Boost, Instant Collect, Second Array).', feature: 'Phoenix Firestorm' },
    ],
    match: (out) => (out.firestorm ? 'firestorm' : out.started ? 'arealink' : null),
    accepts: { arealink: ['arealink', 'firestorm'], firestorm: ['firestorm'] }, // a Firestorm is also an Area Link trigger
    inBonus: modeBonus,
    autoplay: () => ({ action: 'respin' }),
  },
  tigerdragon: {
    native: true, // the game has its own buy action (startBonus with the 'buy' source)
    options: [
      { id: 'random', defaultCost: 50, name: 'Random Bonus', desc: 'A Tiger, Dragon or Tiger & Dragon bonus, chosen at random (45 / 45 / 10).', feature: 'Tiger, Dragon or combined bonus' },
      { id: 'combined', defaultCost: 100, name: 'Tiger & Dragon Bonus', desc: 'Both bonuses together: the Tiger grid and the Dragon gongs.', feature: 'Tiger & Dragon Bonus' },
    ],
    inBonus: modeBonus,
    autoplay: () => ({ action: 'respin' }),
  },
  genie: {
    options: [
      { id: 'free', name: 'Free Spins', desc: 'A genuine Free Spins trigger: wishes, wild upgrades and retriggers as in the paytable.', feature: '3+ Lamps' },
      { id: 'treasure', name: "Genie's Treasure", desc: 'The jackpot pick: open treasures until you match three of a jackpot.', feature: "Genie's Treasure trigger" },
    ],
    matchAll: (out) => [out.triggers?.free && 'free', out.triggers?.treasure && 'treasure'].filter(Boolean),
    inBonus: modeBonus,
    autoplay: (s) => (s.mode === 'treasure' ? { action: 'pick', body: { tile: firstFree(64, (i) => s.treasure?.picks?.[i]) } } : { action: 'spin' }),
  },
  stampede: {
    options: [
      { id: 'hold', name: 'Hold & Spin', desc: 'Six or more Cash symbols lock and the respins begin, with all four jackpots in play.', feature: '6+ Cash symbols' },
      { id: 'free', name: 'Free Games', desc: 'A real Free Games trigger, with Gold Buffalo upgrades and retriggers.', feature: '3+ Coin scatters' },
    ],
    matchAll: (out) => [out.triggers?.hold && 'hold', out.triggers?.free && 'free'].filter(Boolean),
    inBonus: modeBonus,
    autoplay: (s) => (s.mode === 'hold' ? { action: 'respin' } : { action: 'spin' }),
  },
  brick: {
    options: [
      { id: 'hats', name: 'Hat Free Spins', desc: 'Hard-hat free spins exactly as triggered on the reels, with every hat feature.', feature: 'Hard-hat trigger' },
      { id: 'saws', name: 'Saw Wheel', desc: 'The Saw Wheel bonus, with its cash prizes and jackpots.', feature: 'Saw trigger' },
    ],
    matchAll: (out) => [out.triggers?.hats && 'hats', out.triggers?.saws && 'saws'].filter(Boolean),
    inBonus: modeBonus,
    autoplay: (s) => (s.mode === 'wheel' ? { action: 'wheel' } : { action: 'spin' }),
  },
  mummy: {
    options: [
      { id: 'free', name: 'Free Games', desc: 'A real Free Games trigger from three or more scatters, with retriggers.', feature: '3+ scatters' },
      { id: 'cash', name: 'Cash Collect', desc: 'The Mummy collects the gems: the Cash Collect respins with their level-ups.', feature: 'Mummy with gems' },
    ],
    matchAll: (out) => [out.triggers?.free?.spins && 'free', out.triggers?.cash && 'cash'].filter(Boolean),
    inBonus: modeBonus,
    autoplay: (s) => (s.mode === 'jackpot' ? { action: 'pick', body: { index: firstFree(15, (i) => s.jackpot?.opened?.some((o) => o.index === i)) } } : s.mode === 'cash' ? { action: 'respin' } : { action: 'spin' }),
  },
  moonridge: freeSpinsOnly('Free Spins', 'A genuine Free Spins trigger, with the delayed expanding wilds carried into the feature.', '3+ Moon scatters'),
  frost: freeSpinsOnly('Free Spins', 'Free spins with sticky expanding multiplier wilds, retriggers included.', '3+ Moons'),
  atlantis: {
    options: [{ id: 'treasure', name: 'Treasure Chests', desc: 'The chest pick: coins, tridents towards the 500x Poseidon Jackpot and possible free spins with the wild multiplier.', feature: '3+ Chests' }],
    match: (out) => (out.trigger?.treasure ? 'treasure' : null),
    inBonus: (s) => !!(s?.bonus || s?.free),
    autoplay: (s) => (s.bonus ? { action: 'pick', body: { index: firstFree(12, (i) => s.bonus.picked.includes(i)) } } : { action: 'spin' }),
  },
  neon: freeSpinsOnly('Overdrive Free Spins', 'Free spins with the ever-growing Overdrive multiplier meter.', '3+ Overdrive symbols'),
  dragon: freeSpinsOnly('Free Spins', 'Free spins with sticky Fire Wilds and Lucky Lanterns.', '3+ Pearls'),
  cosmic: freeSpinsOnly('Free Spins', 'Tumbling free spins with the growing gravity multiplier.', '4+ Black Holes'),
  pharaoh: freeSpinsOnly('Free Spins', 'Free spins where Scarabs add spins and upgrade the Ancient Multiplier reel.', '3+ Scarabs'),
  starlight: freeSpinsOnly('Free Spins', '10 free spins with a randomly chosen expanding symbol.', '3+ Telescopes'),
  nebula: freeSpinsOnly('Free Spins', 'Ten cascading free spins where the cluster multiplier never resets.', '4+ scatters'),
  vault: {
    options: [{ id: 'hold', name: 'Hold & Spin', desc: 'Six or more coins lock and the Hold & Spin plays out, with Mini, Minor, Major and the Grand for a full screen.', feature: '6+ coins' }],
    match: (out) => (out.feature ? 'hold' : null),
    inBonus: () => false, // the whole feature resolves in the triggering spin
  },
};

/** Which option(s) a spin result triggered. */
export function triggered(game, out) {
  const a = ADAPTERS[game];
  if (!a) return [];
  if (a.matchAll) return a.matchAll(out);
  const m = a.match?.(out);
  if (!m) return [];
  return a.accepts ? Object.keys(a.accepts).filter((k) => a.accepts[k].includes(m)) : [m];
}

/** Slots with no bonus feature that can be bought, and why (shown in the audit report). */
export const NOT_SUPPORTED = {
  fruit: 'Fruit Shack has no bonus round: its holds and nudges are offered on ordinary spins.',
  polarcatch: 'Polar Catch is a wheel game, not a slot: its fishing bonuses are bets on the wheel.',
};
