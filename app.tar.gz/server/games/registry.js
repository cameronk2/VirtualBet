// All casino games that run through the shared handler, plus the lobby
// catalogue (names, categories and published returns).
import { roulette } from './roulette.js';
import { baccarat } from './baccarat.js';
import { threecard } from './threecard.js';
import { crash, plinko, scratch } from './instant.js';
import { nebula, vault, fruit, starlight } from './slots2.js';
import { atlantis, neon, dragon, cosmic, pharaoh, frost } from './slots3.js';
import { moonridge } from './moonridge/index.js';
import { mummy } from './mummy/index.js';
import { polarcatch } from './polarcatch/engine.js';
import { brick } from './brick/engine.js';
import { stampede } from './stampede/engine.js';
import { chicken } from './chicken/engine.js';
import { mines } from './mines/engine.js';
import { keno } from './keno/engine.js';
import { genie } from './genie/engine.js';
import { tigerdragon } from './tigerdragon/engine.js';
import { GameError } from './common.js';

export const GAMES = { roulette, baccarat, threecard, crash, plinko, scratch, nebula, vault, fruit, starlight, atlantis, neon, dragon, cosmic, pharaoh, frost, moonridge, mummy, polarcatch, brick, stampede, chicken, mines, keno, genie, tigerdragon };

/** Lobby catalogue. `path` is the screen; `rtp` is the long-run return. */
import { CATALOGUE } from './catalogue.js';
export { CATALOGUE };

/**
 * Runs one game action without touching money. Returns the engine result;
 * the caller checks the stake against the balance, then applies it.
 */
export function runGame(id, state, action, body, ctx) {
  const g = GAMES[id];
  if (!g) throw new GameError('Unknown game.');
  const prev = state ?? g.init();
  const r = g.act(structuredClone(prev), action, body, ctx);
  return { ...r, stake: r.stake || 0, payout: r.payout || 0 };
}
export { GameError };
