// Phoenix Ember Link – the Area Link bonus manager (pure).
//
// One bonus = one or two independent 5 x 3 arrays (two when Magenta is active). Each array has
// its own respin counter (starts at 3, back to 3 whenever a Fireball lands on it, the array stops
// at 0). Every landed Fireball locks in place for the rest of the feature. The bonus ends when
// every array has stopped. Upgrades are applied by this one module, in a fixed order each respin:
//
//   1. Orange   a multiplier (2x/3x/5x) is drawn for the respin.
//   2. Green    every Green Fireball already locked grows by a random amount.
//   3. Land     empty spots may land a Fireball (Yellow, or Red/Blue/Green while that upgrade is on).
//               New Yellow cash prizes take the Orange multiplier as they lock (jackpots don't).
//   4. Blue     each new Blue adds its prize to 1-5 random Yellow cash prizes (repeats allowed),
//               then turns Yellow, keeping its own prize.
//   5. Red      each new Red collects the total of every other prize on its array (cash, jackpots,
//               Greens) as its own prize, then turns Yellow. The collected prizes stay where they
//               are and are paid once each; the Red's total is one new prize, paid once.
//   6. Counter  reset to 3 if anything landed, else down by 1. A full array wins the Grand.
//
// Payout when the bonus ends = every locked prize on every array + a Grand per full array.
import { BLUE_HITS, GREEN_STEP, JACKPOTS, MAGENTA_START, MULTIPLIERS, REELS, RESPINS, ROWS, SPECIAL_CHANCE, TUNE } from './config.js';
import { cashOf, drawPrize, weighted } from './reels.js';

export const SPOTS = REELS * ROWS;
const keys = () => { const k = []; for (let r = 0; r < ROWS; r++) for (let c = 0; c < REELS; c++) k.push(`${c}-${r}`); return k; };
export const ALL_KEYS = keys();

/** cells: { "c-r": { t: 'cash'|'jp'|'green', v, jp? } } */
function newArray(cells = {}) { return { cells, spinsLeft: RESPINS, done: false, full: false }; }

/** A Fireball locked at the start becomes a Yellow prize (whatever its base-game colour). */
const lockStart = (fb) => (fb.jp ? { t: 'jp', jp: fb.jp, v: fb.v } : { t: 'cash', v: fb.v });

/**
 * Starts a bonus. start: [{ k, v, jp? }] the Fireballs on the reels; upgrades: list of colours.
 * If fewer than `min` Fireballs are given (Firestorm or practice), random ones are added.
 */
export function startBonus({ bet, upgrades, start, source, rand, min = 3 }) {
  const cells = {};
  for (const f of start) cells[f.k] = lockStart(f);
  const free = ALL_KEYS.filter((k) => !cells[k]);
  while (Object.keys(cells).length < min) { const k = free.splice(Math.floor(rand() * free.length), 1)[0]; cells[k] = lockStart(drawPrize(bet, rand)); }
  const arrays = [newArray(cells)];
  if (upgrades.includes('magenta')) {
    const c2 = {}; const f2 = [...ALL_KEYS];
    for (let i = 0; i < MAGENTA_START; i++) { const k = f2.splice(Math.floor(rand() * f2.length), 1)[0]; c2[k] = lockStart(drawPrize(bet, rand)); }
    arrays.push(newArray(c2));
  }
  const order = ['orange', 'magenta', 'red', 'blue', 'green'];
  return { bet, upgrades: order.filter((u) => upgrades.includes(u)), arrays, spun: 0, source, mult: null };
}

/** What a landing Fireball is. */
function landType(up, rand) {
  for (const c of ['red', 'blue', 'green']) if (up.includes(c) && rand() < SPECIAL_CHANCE[c]) return c;
  return 'yellow';
}

const prizeSum = (cells, skip = new Set()) => Object.entries(cells).reduce((a, [k, x]) => a + (skip.has(k) ? 0 : x.v), 0);

/**
 * One respin of the whole bonus. forced: optional { arrayIndex: [{ k, type?, v?, jp? }] } to decide
 * exactly what lands (tests and practice); spots not listed stay empty on a forced array.
 */
export function respin(b, rand, forced) {
  const up = b.upgrades;
  const mult = up.includes('orange') ? (forced?.mult ?? weighted(MULTIPLIERS, rand)) : 1;
  b.mult = up.includes('orange') ? mult : null;
  b.spun++;
  const events = b.arrays.map((a, ai) => {
    const ev = { array: ai, mult: b.mult, greens: [], lands: [], blues: [], reds: [], spinsLeft: a.spinsLeft, full: a.full, done: a.done, skipped: a.done };
    if (a.done) return ev;
    // 2. Greens grow (only those locked before this respin)
    for (const [k, x] of Object.entries(a.cells)) if (x.t === 'green') { const add = cashOf(b.bet, rand, GREEN_STEP); x.v += add; ev.greens.push({ k, add, v: x.v }); }
    // 3. Land
    const f = forced?.[ai];
    const newRed = [], newBlue = [];
    for (const k of ALL_KEYS) {
      if (a.cells[k]) continue;
      let spec = null;
      if (f) { spec = f.find((x) => x.k === k); if (!spec) continue; }
      else if (rand() >= TUNE.land) continue;
      const type = spec?.type || landType(up, rand);
      let cell, base;
      if (type === 'yellow') {
        const p = spec?.v != null || spec?.jp ? (spec.jp ? { jp: spec.jp, v: JACKPOTS[spec.jp] * b.bet } : { v: spec.v }) : drawPrize(b.bet, rand);
        if (p.jp) cell = { t: 'jp', jp: p.jp, v: p.v };
        else { base = p.v; cell = { t: 'cash', v: p.v * mult }; }
      } else {
        const v = spec?.v ?? cashOf(b.bet, rand);
        cell = { t: type === 'green' ? 'green' : type, v };   // red / blue are temporary types
        if (type === 'red') newRed.push(k);
        if (type === 'blue') newBlue.push(k);
      }
      a.cells[k] = cell;
      ev.lands.push({ k, type, ...cell, base: base ?? cell.v, mult: type === 'yellow' && !cell.jp ? mult : 1 });
    }
    // 4. Blue: add its prize to random Yellow cash prizes, then turn Yellow
    for (const k of newBlue) {
      const x = a.cells[k];
      const targets = Object.entries(a.cells).filter(([, y]) => y.t === 'cash').map(([kk]) => kk);
      const hits = targets.length ? (forced?.blueHits ?? weighted(BLUE_HITS, rand)) : 0;
      const tr = [];
      for (let i = 0; i < hits; i++) { const t = targets[Math.floor(rand() * targets.length)]; a.cells[t].v += x.v; tr.push({ k: t, add: x.v, v: a.cells[t].v }); }
      x.t = 'cash';
      ev.blues.push({ k, v: x.v, transfers: tr });
    }
    // 5. Red: collect every other prize on the array (other new Reds excluded), then turn Yellow
    const redSet = new Set(newRed);
    for (const k of newRed) {
      const from = Object.entries(a.cells).filter(([kk]) => !redSet.has(kk)).map(([kk, y]) => ({ k: kk, v: y.v }));
      const got = from.reduce((s, x) => s + x.v, 0);
      a.cells[k].v += got; a.cells[k].t = 'cash';
      ev.reds.push({ k, v: a.cells[k].v, collected: got, from });
    }
    for (const k of newRed) redSet.delete(k);
    // 6. Counter and Grand
    const n = Object.keys(a.cells).length;
    a.spinsLeft = ev.lands.length ? RESPINS : a.spinsLeft - 1;
    a.full = n >= ALL_KEYS.length;
    a.done = a.full || a.spinsLeft <= 0;
    Object.assign(ev, { spinsLeft: a.spinsLeft, full: a.full, done: a.done, count: n });
    return ev;
  });
  const done = b.arrays.every((a) => a.done);
  return { events, done, mult: b.mult };
}

/** The final tally: every prize once, plus a Grand per full array. */
export function settleBonus(b) {
  const arrays = b.arrays.map((a, i) => {
    const prizes = prizeSum(a.cells);
    const grand = a.full ? JACKPOTS.grand * b.bet : 0;
    const jps = Object.values(a.cells).filter((x) => x.t === 'jp').map((x) => x.jp);
    return { array: i, prizes, grand, total: prizes + grand, count: Object.keys(a.cells).length, jackpots: a.full ? [...jps, 'grand'] : jps };
  });
  return { arrays, total: arrays.reduce((s, a) => s + a.total, 0) };
}
