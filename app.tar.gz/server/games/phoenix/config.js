// Phoenix Ember Link – every tunable number in one place.
//
// An original game in the style of an "egg-upgrade" hold-and-win slot. It borrows no names, art or
// numbers from any commercial game: the paytable, reel strips, fireball values and chances
// below are our own, tuned by scripts/sim-phoenix.mjs so the whole game returns the target RTP.
// Amounts are virtual pence. Pays and prizes are multiples of the TOTAL stake, so every feature
// scales with the bet (a 100x prize pays £50 at 50p).

export const REELS = 5;
export const ROWS = 3;
export const STAKES = [20, 50, 100, 200, 500, 1000];   // 20p, 50p, £1, £2, £5, £10
export const DEFAULT_STAKE = 100;

// 20 fixed lines (row index on each reel; 0 = top)
export const LINES = [
  [1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2],
  [1, 0, 0, 0, 1], [1, 2, 2, 2, 1], [0, 0, 1, 2, 2], [2, 2, 1, 0, 0], [1, 2, 1, 0, 1],
  [1, 0, 1, 2, 1], [0, 1, 1, 1, 0], [2, 1, 1, 1, 2], [0, 1, 0, 1, 0], [2, 1, 2, 1, 2],
  [1, 1, 0, 1, 1], [1, 1, 2, 1, 1], [0, 0, 2, 0, 0], [2, 2, 0, 2, 2], [0, 2, 0, 2, 0],
];

export const WILD = 'WILD';
export const FB = 'FB';                      // Fireball (colour and prize are drawn when it lands)
export const HIGH = ['FEATHER', 'ORANGE', 'RED', 'PURPLE', 'GREEN'];
export const LOW = ['A', 'K', 'Q', 'J', 'T', 'N'];  // T = 10, N = 9
export const LINE_SYMBOLS = [...HIGH, ...LOW];   // the Wild (reels 2-5 only) has no pay of its own

// Line pays for 3 / 4 / 5 of a kind, in hundredths of the TOTAL stake (pays are per line).
export const PAYTABLE = {
  FEATHER: [250, 1000, 5000],
  ORANGE: [150, 600, 3000],
  RED: [125, 500, 2000],
  PURPLE: [100, 400, 1500],
  GREEN: [80, 300, 1200],
  A: [50, 200, 600], K: [50, 200, 600],
  Q: [40, 150, 500], J: [40, 150, 500],
  T: [30, 100, 400], N: [30, 100, 400],
};

// Reel strips are built from these counts (see reels.js), shuffled once with a fixed seed. Wilds sit in
// stacks of 3 on reels 2-5 only. Fireballs are not on the strips: every visible spot can turn into a
// Fireball on its own (FB_CHANCE), which keeps the Area Link trigger rate smooth and easy to tune.
const STRIP = { FEATHER: 2, ORANGE: 3, RED: 3, PURPLE: 4, GREEN: 4, A: 9, K: 9, Q: 12, J: 12, T: 12, N: 12 };
export const STRIP_COUNTS = [0, 3, 3, 3, 3].map((w) => ({ ...STRIP, WILDSTACKS: w }));
export const FB_CHANCE = 0.115;

// ── Fireballs ─────────────────────────────────────────────────
export const TRIGGER = 6;                    // 6+ Fireballs anywhere start Area Link
export const RESPINS = 3;
export const UPGRADES = ['orange', 'magenta', 'red', 'blue', 'green'];
// Colour of a Fireball landing in the BASE game. Every Fireball carries a prize; a coloured one lights
// the egg of its colour for that spin.
export const BASE_COLOURS = [['yellow', 87], ['orange', 2.8], ['magenta', 2.0], ['red', 2.6], ['blue', 2.8], ['green', 2.8]];
// Each coloured Fireball has this chance to hatch its egg and start Area Link on the spot (random, no build-up).
export const EGG_CHANCE = 0.005;
// Phoenix Firestorm: on any spin with at least one Fireball, the Phoenix may fly out (random).
export const FIRESTORM_CHANCE = 0.0019;
// How many random upgrades Firestorm awards (any lit eggs on the reels are added too).
export const FIRESTORM_UPGRADES = [[1, 34], [2, 34], [3, 20], [4, 9], [5, 3]];

// Prize on a Yellow Fireball: [multiple of stake, weight]. Jackpot labels pay their tier.
export const CASH = [[1, 8], [2, 14], [3, 16], [4, 15], [5, 14], [6, 12], [7, 10], [8, 11]];   // all below the Mini
export const JACKPOTS = { mini: 10, minor: 20, major: 100, grand: 5000 };
export const JP_CHANCE = [['mini', 0.05], ['minor', 0.016], ['major', 0.0022]];   // per Yellow Fireball

// ── Area Link bonus ───────────────────────────────────────────
export const LAND = 0.0493;                 // chance an empty spot lands a Fireball on a respin
// Special Fireballs that can land while their upgrade is active (chance per landing Fireball).
export const SPECIAL_CHANCE = { red: 0.07, blue: 0.09, green: 0.10 };
export const MULTIPLIERS = [[2, 60], [3, 30], [5, 10]];   // Orange: one per respin
export const BLUE_HITS = [[1, 25], [2, 30], [3, 22], [4, 14], [5, 9]];   // prize transfers per Blue
export const GREEN_STEP = [[1, 35], [2, 30], [3, 15], [4, 10], [5, 7], [10, 3]];   // per respin per Green
export const MAGENTA_START = 3;              // Fireballs the second array starts with

// ── Configurable RTP and volatility ───────────────────────────
// Each profile is a full set of tuned numbers, measured by scripts/sim-phoenix.mjs.
// Choose with PHOENIX_RTP (96, 94 or 92; default 96 = the 96.45% design target) and
// PHOENIX_VOLATILITY (low, medium or high; default medium). Volatility moves weight between the small
// Fireball prizes and the jackpots; the land chance of each profile is re-tuned so the RTP holds.
export const TARGET_RTP = 0.9645;
export const VOLATILITY = {
  low: { cash: [[1, 4], [2, 10], [3, 16], [4, 18], [5, 17], [6, 14], [7, 10], [8, 11]], jp: [['mini', 0.04], ['minor', 0.010], ['major', 0.0012]] },
  medium: { cash: CASH, jp: JP_CHANCE },
  high: { cash: [[1, 14], [2, 18], [3, 16], [4, 14], [5, 12], [6, 10], [7, 7], [8, 9]], jp: [['mini', 0.055], ['minor', 0.022], ['major', 0.0042]] },
};
export const RTP_PROFILES = {
  medium: { 96: 0.0493, 94: 0.0474, 92: 0.0452 },
  low: { 96: 0.0483, 94: 0.0466, 92: 0.0444 },
  high: { 96: 0.0514, 94: 0.0486, 92: 0.0464 },
};
const env = (k) => (typeof process !== 'undefined' ? process.env?.[k] : undefined);
export const VOL = VOLATILITY[env('PHOENIX_VOLATILITY')] ? env('PHOENIX_VOLATILITY') : 'medium';
export const RTP_PROFILE = RTP_PROFILES[VOL][Number(env('PHOENIX_RTP'))] ? Number(env('PHOENIX_RTP')) : 96;
export const TUNE = { land: RTP_PROFILES[VOL][RTP_PROFILE], firestorm: FIRESTORM_CHANCE, egg: EGG_CHANCE, fb: FB_CHANCE, cash: VOLATILITY[VOL].cash, jp: VOLATILITY[VOL].jp };
/** Tools only: switch profile in-process (the simulator and tests). */
export function useProfile(vol = 'medium', rtp = 96) { Object.assign(TUNE, { land: RTP_PROFILES[vol][rtp], cash: VOLATILITY[vol].cash, jp: VOLATILITY[vol].jp }); }
