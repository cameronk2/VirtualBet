// Phoenix Ember Link – game flow (server-authoritative, persisted state).
//
// Modes: base -> bonus -> base.
//   base   5 x 3, 20 fixed lines. A coloured Fireball lights the egg of its colour for that spin and
//          may hatch it at random, starting Area Link. 6+ Fireballs always start Area Link. On any spin
//          with a Fireball the Phoenix may fly out (Firestorm): Area Link with 1-5 random upgrades.
//          Whatever starts it, every egg lit on the reels adds its upgrade. Nothing builds up between spins.
//   bonus  respins, one request each, until every array has stopped; paid in one go at the end.
// Every outcome is decided here before anything animates. Practice ("dev") rounds cost and pay nothing.
import { fail } from '../common.js';
import { RTP_PROFILE, VOL, DEFAULT_STAKE, FB, FIRESTORM_UPGRADES, JACKPOTS, STAKES, TRIGGER, TUNE, UPGRADES } from './config.js';
import { respin, settleBonus, startBonus, ALL_KEYS } from './bonus.js';
import { draw, drawPrize, fireballs, lineWins, weighted } from './reels.js';

export const init = () => ({ mode: 'base', bonus: null, recent: [], practice: false });

export function view(s) {
  const b = s.bonus;
  return {
    mode: s.mode, practice: !!s.practice, rtp: RTP_PROFILE, volatility: VOL, stakes: STAKES,
    bonus: b && { bet: b.bet, upgrades: b.upgrades, source: b.source, spun: b.spun, mult: b.mult, arrays: b.arrays },
    recent: (s.recent || []).slice(0, 15),
  };
}

const pickRandomUpgrades = (rand, have) => {
  const n = weighted(FIRESTORM_UPGRADES, rand);
  const pool = UPGRADES.filter((u) => !have.includes(u));
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rand() * pool.length), 1)[0]);
  return out;
};

export function act(state, action, body, { rand, inject } = {}) {
  const s = { ...init(), ...structuredClone(state || {}) };
  const out = { action };
  const wasPractice = !!s.practice;
  let stake = 0, payout = 0, feature = false;
  const stakeOf = () => {
    const v = body?.stake;
    if (!STAKES.includes(v)) fail('Choose one of the listed bets (20p, 50p, £1, £2, £5 or £10).');
    return v;
  };

  if (action === 'spin') {
    if (s.mode !== 'base') fail('Finish the Area Link bonus first.');
    const bet = stakeOf();
    stake = bet;
    const grid = inject?.grid || draw(bet, rand);
    const wins = lineWins(grid, bet);
    const lineWin = wins.reduce((a, w) => a + w.amount, 0);
    const fbs = fireballs(grid);
    // coloured Fireballs light their eggs; each may hatch at random
    const lights = fbs.filter((f) => UPGRADES.includes(f.c)).map((f) => ({ k: f.k, c: f.c }));
    const lit = UPGRADES.filter((u) => lights.some((l) => l.c === u));
    let hatched = [];
    if (inject?.hatch !== undefined) hatched = inject.hatch.filter((u) => lit.includes(u));
    else for (const l of lights) if (rand() < TUNE.egg && !hatched.includes(l.c)) hatched.push(l.c);
    // Phoenix Firestorm: any spin with a Fireball
    let firestorm = false;
    if (inject?.firestorm !== undefined) firestorm = !!inject.firestorm && fbs.length > 0;
    else if (fbs.length) firestorm = rand() < TUNE.firestorm;
    const trigger = fbs.length >= TRIGGER || hatched.length > 0 || firestorm;
    payout = lineWin;
    Object.assign(out, { grid, wins, lineWin, fireballs: fbs.length, lights, lit, hatched, bet, win: payout, firestorm });
    if (trigger) {
      feature = true;
      const extra = firestorm ? (inject?.firestormUpgrades || pickRandomUpgrades(rand, lit)) : [];
      const upgrades = [...new Set([...lit, ...extra])];
      const source = firestorm ? 'firestorm' : hatched.length ? 'egg' : 'base';
      s.bonus = startBonus({ bet, upgrades, start: fbs, source, rand, min: fbs.length >= TRIGGER ? TRIGGER : 3 });
      s.mode = 'bonus';
      Object.assign(out, { started: true, source, upgrades: s.bonus.upgrades, fromEggs: lit, firestormUpgrades: extra });
    }
  } else if (action === 'respin') {
    if (s.mode !== 'bonus' || !s.bonus) fail('There is no bonus in play.');
    const b = s.bonus;
    const forced = inject?.forced || (s.practice && b.forced?.length ? b.forced.shift() : undefined);
    const r = respin(b, rand, forced);
    Object.assign(out, r, { bet: b.bet, upgrades: b.upgrades });
    if (r.done) {
      const st = settleBonus(b);
      payout = st.total;
      out.result = { ...st, arrays: st.arrays.map((x, i) => ({ ...x, cells: b.arrays[i].cells })), upgrades: b.upgrades, source: b.source, spun: b.spun, bet: b.bet };
      out.win = payout;
      s.bonus = null; s.mode = 'base';
    } else out.win = 0;
  } else if (action === 'dev') {
    // Practice rounds for trying every feature: they cost nothing and pay nothing.
    if (s.mode !== 'base') fail('Finish the Area Link bonus first.');
    const bet = stakeOf();
    const ev = body?.event;
    s.practice = true;
    let ups = [];
    if (ev === 'egg') { const pool = [...UPGRADES].sort(() => rand() - 0.5); ups = pool.slice(0, 1 + Math.floor(rand() * 2)); }
    else if (ev === 'firestorm') ups = Array.isArray(body?.upgrades) ? body.upgrades.filter((u) => UPGRADES.includes(u)) : pickRandomUpgrades(rand, []);
    else if (ev === 'all' || ev === 'grand') ups = [...UPGRADES];
    else if (UPGRADES.includes(ev)) ups = [ev];
    else if (ev !== 'bonus') fail('Unknown test event.');
    const keys = [...ALL_KEYS].sort(() => rand() - 0.5).slice(0, 6);
    s.bonus = startBonus({ bet, upgrades: ups, start: keys.map((k) => ({ k, ...drawPrize(bet, rand) })), source: 'practice', rand, min: 6 });
    // practice rounds for Red / Blue / Green show their Fireball straight away (spin 1), and the
    // "All 5" round shows all three across its first respins
    const free = () => ALL_KEYS.filter((k) => !s.bonus.arrays[0].cells[k]).sort(() => rand() - 0.5);
    if (['red', 'blue', 'green'].includes(ev)) { const [k1, k2] = free(); s.bonus.forced = [{ 0: [{ k: k1, type: ev }, { k: k2, type: 'yellow' }] }]; }
    if (ev === 'all') { const f = free(); s.bonus.forced = [{ 0: [{ k: f[0], type: 'green' }, { k: f[1], type: 'yellow' }] }, { 0: [{ k: f[2], type: 'blue' }] }, { 0: [{ k: f[3], type: 'red' }] }]; }
    if (ev === 'grand') {
      // every empty spot lands on the first respin of each array: a full array and the Grand
      s.bonus.forced = [Object.fromEntries(s.bonus.arrays.map((a, i) => [i, ALL_KEYS.filter((k) => !a.cells[k]).map((k) => ({ k, type: 'yellow' }))]))];
    }
    s.mode = 'bonus'; feature = true;
    Object.assign(out, { started: true, practiceEvent: ev, source: ev === 'egg' ? 'egg' : ev === 'firestorm' ? 'firestorm' : 'practice', hatched: ev === 'egg' ? [ups[0]] : [], lit: ev === 'egg' ? ups : [], upgrades: s.bonus.upgrades, firestorm: ev === 'firestorm', firestormUpgrades: ev === 'firestorm' ? s.bonus.upgrades : [], fromEggs: [], bet, win: 0 });
  } else fail('Unknown action.');

  if (wasPractice || s.practice) { stake = 0; payout = 0; out.practice = true; out.win = 0; if (s.mode === 'base') s.practice = false; }
  out.payout = payout; out.mode = s.mode;
  if (stake || payout) s.recent = [{ bet: out.bet, win: payout, kind: action }, ...(s.recent || [])].slice(0, 20);
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'slot', game: 'phoenix', x: out.bet ? payout / out.bet : 0, feature }] };
}

export { JACKPOTS, DEFAULT_STAKE, FB };
export const phoenix = { id: 'phoenix', label: 'Phoenix Ember Link', init, view, act };
