// Phoenix Ember Link – reel strips, the visible window, line wins and Fireball draws (pure).
import { TUNE, BASE_COLOURS, FB, JACKPOTS, LINES, LINE_SYMBOLS, PAYTABLE, REELS, ROWS, STRIP_COUNTS, WILD } from './config.js';

export function weighted(pairs, rand) {
  let t = 0; for (const [, w] of pairs) t += w;
  let x = rand() * t;
  for (const [v, w] of pairs) if ((x -= w) < 0) return v;
  return pairs[pairs.length - 1][0];
}

/** Fixed strips: built once from STRIP_COUNTS with a seeded shuffle, so they never change between runs. */
function seeded(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
export function buildStrips(counts = STRIP_COUNTS) {
  return counts.map((c, reel) => {
    const r = seeded(1000 + reel);
    const blocks = [];
    for (const [s, n] of Object.entries(c)) {
      if (s === 'WILDSTACKS') continue;
      const size = 1;
      for (let left = n; left > 0; left -= size) blocks.push(Array(Math.min(size, left)).fill(s));
    }
    for (let i = blocks.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [blocks[i], blocks[j]] = [blocks[j], blocks[i]]; }
    const singles = blocks.flat();
    // drop the Wild stacks in at evenly spaced places
    const out = [...singles];
    for (let k = 0; k < (c.WILDSTACKS || 0); k++) {
      const at = Math.floor(((k + 0.5) / c.WILDSTACKS) * out.length);
      out.splice(at, 0, WILD, WILD, WILD);
    }
    return out;
  });
}
export let STRIPS = buildStrips();
/** Tuning tools only. */
export function setStrips(counts) { STRIPS = buildStrips(counts); }

/** A prize for a Yellow Fireball: cash (multiple of stake) or a jackpot label. */
export function drawPrize(bet, rand) {
  let x = rand();
  for (const [tier, p] of TUNE.jp) { if (x < p) return { jp: tier, v: JACKPOTS[tier] * bet }; x -= p; }
  return { v: Math.round(weighted(TUNE.cash, rand) * bet) };
}
export const cashOf = (bet, rand, table = TUNE.cash) => Math.round(weighted(table, rand) * bet);

/** grid[reel][row] of { s } – Fireball cells also get { fb: { c, v, jp? } }. */
export function draw(bet, rand) {
  return STRIPS.map((strip) => {
    const stop = Math.floor(rand() * strip.length);
    return Array.from({ length: ROWS }, (_, row) => {
      const s = rand() < TUNE.fb ? FB : strip[(stop + row) % strip.length];
      return s === FB ? { s, fb: { c: weighted(BASE_COLOURS, rand), ...drawPrize(bet, rand) } } : { s };
    });
  });
}

export const fireballs = (grid) => grid.flatMap((col, c) => col.map((x, r) => (x.s === FB ? { k: `${c}-${r}`, ...x.fb } : null)).filter(Boolean));

/**
 * 20 fixed lines, left to right from reel 1, 3+ in a row. The Wild stands in for every paying
 * symbol (never for a Fireball); a line of Wilds pays as Wilds or as the best symbol it completes.
 */
export function lineWins(grid, bet) {
  const wins = [];
  LINES.forEach((line, li) => {
    const syms = line.map((row, reel) => grid[reel][row].s);
    let best = null;
    for (const sym of LINE_SYMBOLS) {
      let n = 0;
      while (n < REELS && (syms[n] === sym || (syms[n] === WILD && sym !== FB))) n++;
      if (n < 3) continue;
      const pay = PAYTABLE[sym][n - 3];
      if (!best || pay > best.pay) best = { line: li, symbol: sym, count: n, pay };
    }
    if (best) {
      const amount = Math.round((bet * best.pay) / 100);
      if (amount > 0) wins.push({ ...best, amount, cells: line.slice(0, best.count).map((row, reel) => [reel, row]) });
    }
  });
  return wins;
}
