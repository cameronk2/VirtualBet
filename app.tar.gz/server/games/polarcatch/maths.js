// Polar Catch – exact long-run returns, computed from the config (no simulation).
import { BONUS_MULT, CASTS, CATCH, FLAKE_MULTS, SEGMENTS, SPOTS, TAIL_SCALE } from './config.js';

const mean = (pairs, f = (v) => v) => { const t = pairs.reduce((a, [, w]) => a + w, 0); return pairs.reduce((a, [v, w]) => a + f(v) * w, 0) / t; };

/** Catch table with the tail (values above the median value) scaled. */
export function catchTable(id, scale = TAIL_SCALE[id]) {
  const vals = CATCH[id].values;
  const mid = vals[Math.floor(vals.length / 2)][0];
  return vals.map(([v, w]) => [v, v > mid ? w * scale : w]);
}

/** Return-to-player of a flake bet, as a fraction. */
export function flakeRtp() {
  const p = 23 / SEGMENTS;
  const lit = mean(FLAKE_MULTS.count) / 46;            // chance the landing flake segment is lit
  const extra = mean(FLAKE_MULTS.values, (m) => m - 1); // extra winnings per lit hit
  return p * (2 + lit * extra);
}

/** Exact distribution of a round's total catch: the sum of CASTS[id] independent casts. Map value -> probability. */
export function totalDistribution(id, scale) {
  const table = catchTable(id, scale);
  const t = table.reduce((a, [, w]) => a + w, 0);
  const one = table.map(([v, w]) => [v, w / t]);
  let dist = new Map([[0, 1]]);
  for (let c = 0; c < CASTS[id]; c++) {
    const next = new Map();
    for (const [s, p] of dist) for (const [v, q] of one) next.set(s + v, (next.get(s + v) || 0) + p * q);
    dist = next;
  }
  return dist;
}

/** Return-to-player of a bonus bet (cap applied to the round total × multiplier). */
export function bonusRtp(id, scale) {
  const p = SPOTS[id].segments / SEGMENTS;
  const cap = SPOTS[id].maxPay;
  const mt = BONUS_MULT.values.reduce((a, [, x]) => a + x, 0);
  const mults = [[1, 1 - BONUS_MULT.chance], ...BONUS_MULT.values.map(([m, w]) => [m, (w / mt) * BONUS_MULT.chance])];
  let ex = 0;
  for (const [x, px] of totalDistribution(id, scale)) ex += px * mults.reduce((a, [m, pm]) => a + pm * Math.min(cap, x * m), 0);
  return p * (1 + ex);
}
