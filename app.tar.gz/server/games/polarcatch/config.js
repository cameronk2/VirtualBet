// Polar Catch – every number that defines the game.
//
// An original Arctic fishing wheel game. Its structure follows the popular
// "fishing wheel" game-show format: a 53-segment wheel with two even-money
// bets and three fishing bonus rounds, random pre-spin multipliers and a
// 5,000x cap. Names, art, sound, code and the exact catch tables are ours.

export const SPOTS = {
  blue: { name: 'Blue Flake', kind: 'flake', segments: 23 },
  white: { name: 'White Flake', kind: 'flake', segments: 23 },
  minnow: { name: 'Frost Minnows', kind: 'bonus', segments: 4, maxPay: 999 },
  salmon: { name: 'Amber Salmon', kind: 'bonus', segments: 2, maxPay: 1999 },
  king: { name: 'Ruby Kings', kind: 'bonus', segments: 1, maxPay: 4999 },
};
export const SPOT_IDS = Object.keys(SPOTS);
export const BONUS_IDS = ['minnow', 'salmon', 'king'];
export const SEGMENTS = 53;
export const MAX_WIN_X = 5000;          // per round, on the total stake
export const SPOT_MIN = 10;             // 10p
export const SPOT_MAX = 10000;          // £100 per spot

// The wheel, clockwise from the top. Flakes alternate; bonus segments are
// spread out. 23 + 23 + 4 + 2 + 1 = 53.
export const WHEEL = (() => {
  const w = [];
  const bonusAt = { 3: 'king', 10: 'minnow', 17: 'salmon', 24: 'minnow', 31: 'minnow', 38: 'salmon', 45: 'minnow' };
  let flip = 0;
  for (let i = 0; i < SEGMENTS; i++) w.push(bonusAt[i] || (flip++ % 2 ? 'white' : 'blue'));
  return w;
})();

// Flake multipliers: each spin, `count` flake segments light up with a
// multiplier. A flake win pays 1:1, or m:1 on a lit segment.
export const FLAKE_MULTS = {
  count: [[0, 0.1], [2, 0.2], [3, 0.3], [4, 0.25], [6, 0.15]],
  values: [[3, 40], [4, 25], [5, 18], [7, 12], [10, 4.535]],
};

// Bonus multipliers: each spin, each bonus category may be powered up as a
// whole (applies to every fish caught in that round).
export const BONUS_MULT = { chance: 0.25, values: [[2, 45], [3, 25], [5, 17], [7, 8], [10, 5]] };

// Fishing rounds: each bonus is a series of casts, and every cast lands one fish worth a multiple of
// the bet on that spot. The catches add up; the total is multiplied by that bonus's pre-spin
// multiplier and capped at the bonus's max pay. Paid "to 1" (the stake comes back too).
// Weights are tuned (scripts/tune-polarcatch.mjs, exact maths) so each bet returns its target.
export const CASTS = { minnow: 3, salmon: 4, king: 5 };
export const CATCH = {
  minnow: { target: 95.69, values: [[1, 520], [2, 320], [3, 180], [4, 100], [5, 60], [6, 35], [8, 20], [10, 10], [15, 5], [20, 2.5], [30, 1], [50, 0.4]] },
  salmon: { target: 95.6, values: [[1, 300], [2, 260], [3, 200], [4, 150], [5, 110], [6, 70], [8, 45], [10, 30], [15, 16], [20, 8], [30, 3.5], [50, 1.4], [75, 0.5]] },
  king: { target: 95.17, values: [[2, 200], [3, 190], [4, 160], [5, 130], [8, 110], [10, 85], [12, 60], [15, 40], [25, 24], [40, 9], [60, 3.5], [100, 1.4]] },
};
// Tuned scale on the tail weights per bonus (written by the tuner).
export const TAIL_SCALE = { minnow: 0.70219, salmon: 1.24282, king: 0.64387 };
export const FLAKE_TARGET = 97.1;
