// Game list shown in the casino lobby. Kept apart from the engines so the
// web app can show the lobby without downloading every game's maths.
// ALL_GAMES keeps every game ever offered (so old bets keep their names in your history);
// CATALOGUE is what the site offers now: a light casino beside racing and football.
export const ALL_GAMES = [
  { id: 'fortune', name: 'Fortune Live', cat: 'live', path: '/casino/fortune', rtp: '96%', tag: 'Game-show wheel · Fortune Booster · 4 bonus games', hue: 'from-fuchsia-500 via-red-600 to-amber-500', isNew: true, desc: 'Spin the wheel. Play the bonus games.' },
  { id: 'phoenix', name: 'Phoenix Ember Link', cat: 'slots', path: '/casino/phoenix', rtp: '96.4%', tag: '20 lines · Area Link hold & win · 5 egg upgrades · Phoenix Firestorm', hue: 'from-orange-500 via-red-700 to-stone-950', isNew: true, desc: 'Fill the eggs. Wake the firestorm.' },
  { id: 'tigerdragon', name: 'Gong Fortune', cat: 'slots', path: '/casino/tigerdragon', rtp: '96%', tag: '243 ways · Tiger, Dragon & Tiger and Dragon bonuses · Mystery Gongs', hue: 'from-red-500 via-red-800 to-amber-950', isNew: true, desc: 'Strike the gongs. Wake the tiger and the dragon.' },
  { id: 'genie', name: 'Golden Wishes', cat: 'slots', path: '/casino/genie', rtp: '96%', tag: '20 lines · wishes · free spins · 4 jackpots', hue: 'from-amber-300 via-fuchsia-800 to-indigo-950', isNew: true, desc: 'Rub the lamp. Make a wish.' },
  { id: 'stampede', name: 'Stampede Link', cat: 'slots', path: '/casino/stampede', rtp: '96%', tag: '1,024 ways · Hold & Spin · 4 jackpots', hue: 'from-amber-300 via-orange-700 to-stone-900', isNew: true, desc: 'Lock the herd. Fill the plains.' },
  { id: 'brick', name: 'Brick by Brick', cat: 'slots', path: '/casino/brick', rtp: '96%', tag: '6 hats · 3 saws · wheel · 4 jackpots', hue: 'from-amber-300 via-orange-600 to-red-900', isNew: true, desc: 'Build it. Blow it down.' },
  { id: 'polarcatch', name: 'Polar Catch', cat: 'instant', path: '/casino/polarcatch', rtp: 'Up to 97.1%', tag: '53-segment wheel · 3 fishing bonuses', hue: 'from-sky-200 via-sky-600 to-slate-950', isNew: true, desc: 'Spin, fish, win' },
  { id: 'mummy', name: 'Mystery of the Mummy', cat: 'slots', path: '/casino/mummy', rtp: '95%', tag: 'Cash Collect · Free Games · 5 jackpots', hue: 'from-amber-300 via-teal-700 to-stone-950', isNew: true, desc: 'The tomb is open' },
  { id: 'moonridge', name: 'Moonridge', cat: 'slots', path: '/casino/moonridge', rtp: '95%', tag: 'Delayed expanding wilds · 5 jackpots', hue: 'from-amber-300 via-slate-700 to-slate-950', isNew: true, desc: 'Where the pack howls' },
  { id: 'frost', name: 'Frostfang', cat: 'slots', path: '/casino/frost', rtp: '96%', tag: 'Sticky expanding multiplier wilds', hue: 'from-sky-300 via-indigo-800 to-slate-950', isNew: true, desc: 'Howl of the Northern Lights' },
  { id: 'atlantis', name: 'Atlantis', cat: 'slots', path: '/casino/atlantis', rtp: '96%', tag: "Treasure chests · Poseidon's Jackpot", hue: 'from-cyan-400 via-sky-800 to-blue-950', isNew: true, desc: 'Kingdom of the Deep' },
  { id: 'neon', name: 'Neon Overdrive', cat: 'slots', path: '/casino/neon', rtp: '96%', tag: '1,024 ways · multipliers', hue: 'from-fuchsia-500 via-purple-900 to-slate-950', isNew: true, desc: 'Cyberpunk city' },
  { id: 'dragon', name: "Dragon's Fortune", cat: 'slots', path: '/casino/dragon', rtp: '96%', tag: 'Fire wilds · Lucky Lanterns', hue: 'from-red-600 via-red-900 to-black', isNew: true, desc: 'The Golden Empire' },
  { id: 'cosmic', name: 'Cosmic Collapse', cat: 'slots', path: '/casino/cosmic', rtp: '96%', tag: 'Tumbles · gravity multipliers', hue: 'from-violet-500 via-indigo-900 to-black', isNew: true, desc: 'Galactic tumbles' },
  { id: 'pharaoh', name: "Pharaoh's Gold", cat: 'slots', path: '/casino/pharaoh', rtp: '96%', tag: 'Mystery stacks · multiplier reel', hue: 'from-amber-400 via-yellow-800 to-stone-950', isNew: true, desc: 'Secrets of Egypt' },
  { id: 'lakeside', name: 'Lakeside Lures', cat: 'slots', path: '/slots', rtp: '96%', tag: 'Fish collect · free spins', hue: 'from-amber-500 via-orange-700 to-sky-900' },
  { id: 'nebula', name: 'Nebula Clusters', cat: 'slots', path: '/casino/nebula', rtp: '96%', tag: 'Cluster pays · cascades', hue: 'from-fuchsia-600 via-violet-800 to-indigo-950' },
  { id: 'vault', name: 'Coin Vault', cat: 'slots', path: '/casino/vault', rtp: '96%', tag: 'Hold & Spin · 4 jackpots', hue: 'from-yellow-400 via-amber-600 to-stone-900' },
  { id: 'starlight', name: 'Starlight Observatory', cat: 'slots', path: '/casino/starlight', rtp: '96%', tag: 'Expanding symbol free spins', hue: 'from-sky-400 via-indigo-700 to-slate-950' },
  { id: 'fruit', name: 'Fruit Shack', cat: 'slots', path: '/casino/fruit', rtp: '96%', tag: 'Classic 3-reel · holds & nudges', hue: 'from-rose-500 via-red-700 to-red-950' },
  { id: 'clyde', name: 'Clyde Blackjack', cat: 'tables', path: '/clyde', rtp: '99.5%', tag: 'Glasgow casino · Pairs, 21+3 & Top 3', hue: 'from-emerald-600 via-emerald-900 to-stone-950', isNew: true, desc: 'Pull up a chair in the Clyde Room.' },
  { id: 'blackjack', name: 'Blackjack', cat: 'tables', path: '/blackjack', rtp: '99.5%', tag: 'Up to 3 hands · side bets', hue: 'from-emerald-500 via-emerald-800 to-emerald-950' },
  { id: 'spin21', name: 'Spin 21', cat: 'tables', path: '/spin21', rtp: '96% side bet', tag: 'Blackjack bonus wheel', hue: 'from-pink-500 via-purple-700 to-emerald-950' },
  { id: 'roulette', name: 'Roulette', cat: 'tables', path: '/casino/roulette', rtp: '97.3%', tag: 'European single zero', hue: 'from-red-600 via-red-900 to-zinc-950' },
  { id: 'baccarat', name: 'Baccarat', cat: 'tables', path: '/casino/baccarat', rtp: '98.9%', tag: 'Player · Banker · Tie', hue: 'from-sky-600 via-blue-900 to-slate-950' },
  { id: 'threecard', name: 'Three Card Poker', cat: 'tables', path: '/casino/threecard', rtp: '96.6%', tag: 'Ante, Play & Pair Plus', hue: 'from-teal-500 via-cyan-800 to-slate-950' },
  { id: 'keno', name: 'Keno 40', cat: 'instant', path: '/casino/keno', rtp: '97%', tag: 'Pick up to 10, watch the draw', hue: 'from-fuchsia-500 via-violet-800 to-slate-950', isNew: true, desc: 'Ten balls. Your numbers. Classic, Quick or High risk.' },
  { id: 'mines', name: 'Gem Mines', cat: 'instant', path: '/casino/mines', rtp: '97%', tag: 'Find gems, dodge mines, cash out', hue: 'from-violet-400 via-indigo-800 to-slate-950', isNew: true, desc: 'Every gem raises the stakes.' },
  { id: 'chicken', name: 'Cluck Crossing', cat: 'instant', path: '/casino/chicken', rtp: '97%', tag: 'Cross the road, cash out any time', hue: 'from-yellow-300 via-orange-500 to-slate-900', isNew: true, desc: 'Why did the chicken cross the road?' },
  { id: 'crash', name: 'Crash', cat: 'instant', path: '/casino/crash', rtp: '97%', tag: 'Cash out before it crashes', hue: 'from-lime-400 via-emerald-700 to-slate-950' },
  { id: 'plinko', name: 'Plinko', cat: 'instant', path: '/casino/plinko', rtp: '97%', tag: 'Drop the ball', hue: 'from-pink-500 via-rose-700 to-slate-950' },
  { id: 'scratch', name: 'Scratchcards', cat: 'instant', path: '/casino/scratch', rtp: '68%', tag: 'Match 3 to win', hue: 'from-yellow-300 via-lime-600 to-green-950' },
];

export const ACTIVE = ['clyde', 'roulette', 'polarcatch', 'phoenix', 'tigerdragon'];
export const CATALOGUE = ACTIVE.map((id) => ALL_GAMES.find((g) => g.id === id));
