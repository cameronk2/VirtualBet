// Fortune Live – an original money-wheel game show (virtual money, animated studio).
// All tables live here; maths.js derives the exact return of every bet spot from them.
//
// Main wheel: 54 equal segments.  Number spots pay their number to 1.
// Four bonus games pay a multiplier of the bet on that spot (plus the bet back).
// The Fortune Booster (two reels above the wheel) can lift one spot each round.

export const SEGMENTS = 54;
export const WHEEL = ['frenzy', 'n1', 'n2', 'n5', 'n1', 'n2', 'toss', 'n1', 'n10', 'n1', 'n2', 'n1', 'drop', 'n5', 'n1', 'n2', 'n1', 'n5', 'toss', 'n2', 'n1', 'n10', 'n1', 'n2', 'wall', 'n1', 'n5', 'n1', 'n2', 'n1', 'toss', 'n2', 'n1', 'n10', 'n1', 'n5', 'drop', 'n2', 'n1', 'n2', 'n1', 'n5', 'toss', 'n1', 'n2', 'n1', 'n10', 'n1', 'wall', 'n2', 'n1', 'n5', 'n2', 'n1'];

export const SPOTS = {
  n1: { name: '1', kind: 'number', pay: 1, colour: '#facc15' },
  n2: { name: '2', kind: 'number', pay: 2, colour: '#38bdf8' },
  n5: { name: '5', kind: 'number', pay: 5, colour: '#f472b6' },
  n10: { name: '10', kind: 'number', pay: 10, colour: '#a78bfa' },
  toss: { name: 'Coin Toss', kind: 'bonus', colour: '#3b82f6', blurb: 'Two sides, two multipliers. One flip.' },
  wall: { name: 'Prize Wall', kind: 'bonus', colour: '#22c55e', blurb: 'Pick one of 108 hidden prizes.' },
  drop: { name: 'Drop Zone', kind: 'bonus', colour: '#a855f7', blurb: 'A puck falls through the pegs. Doubles drop again.' },
  frenzy: { name: 'Fortune Frenzy', kind: 'bonus', colour: '#ef4444', blurb: 'Choose a flapper on the giant wheel.' },
};
export const SPOT_IDS = Object.keys(SPOTS);
export const NUMBER_IDS = ['n1', 'n2', 'n5', 'n10'];
export const BONUS_IDS = ['toss', 'wall', 'drop', 'frenzy'];

export const SPOT_MIN = 10;          // 10p
export const SPOT_MAX = 10000;       // £100 per spot
export const BONUS_MAX_X = 20000;    // a bonus pays at most 20,000x the bet on it
export const TARGET_RTP = 0.96;

// ── Fortune Booster ───────────────────────────────────────────────────────
// Each round the booster lights at most one spot with a multiplier (or misses).
export const BOOST_MULTS = [[2, 30], [3, 22], [4, 15], [5, 12], [7, 8], [10, 6], [15, 3], [20, 2], [25, 1.2], [50, 0.8]];
const mean = (t) => t.reduce((a, [v, w]) => a + v * w, 0) / t.reduce((a, [, w]) => a + w, 0);
export const BOOST_MEAN = mean(BOOST_MULTS);
// Chance the booster lights each bonus spot (bonus tables are tuned to include it).
const BONUS_BOOST = { toss: 0.05, wall: 0.04, drop: 0.04, frenzy: 0.04 };
// Number spots: the booster chance is set so each number returns TARGET_RTP exactly.
//   RTP = P(seg) * (1 + pay * E[mult]),  E[mult] = 1 + p * (BOOST_MEAN - 1)
const count = (id) => WHEEL.filter((s) => s === id).length;
export const BOOST_CHANCE = {};
for (const id of NUMBER_IDS) {
  const needM = (TARGET_RTP * SEGMENTS / count(id) - 1) / SPOTS[id].pay;
  BOOST_CHANCE[id] = (needM - 1) / (BOOST_MEAN - 1);
}
Object.assign(BOOST_CHANCE, BONUS_BOOST);
export const boostFactor = (id) => 1 + BOOST_CHANCE[id] * (BOOST_MEAN - 1);

// ── Bonus tables ──────────────────────────────────────────────────────────
// Each table's first weight is solved so the bonus (with the booster) returns TARGET_RTP.
// `k` is how the bonus's own mechanics scale the table's average (doubles etc).
//   Drop Zone: 16 slots, 2 of them DOUBLE; a puck on DOUBLE doubles every slot and drops again.
//     E = (14/16) E[v] / (1 - (2/16) * 2) = 7/6 E[v]
//   Fortune Frenzy: 64 segments, 2 DOUBLE and 1 TRIPLE; same rule.
//     E = (61/64) E[v] / (1 - (2*2 + 3)/64) = 61/57 E[v]
export const DROP_SLOTS = 16, DROP_DOUBLES = 2, DROP_ROWS = 12;
export const FRENZY_SEGS = 64, FRENZY_DBL = 2, FRENZY_TRP = 1, FLAPPERS = ['green', 'blue', 'yellow'];
export const FLAPPER_OFFSET = { green: 0, blue: 21, yellow: 43 };   // segments between the three flappers
const K = { toss: 1, wall: 1, drop: (DROP_SLOTS - DROP_DOUBLES) / DROP_SLOTS / (1 - (DROP_DOUBLES / DROP_SLOTS) * 2), frenzy: (FRENZY_SEGS - FRENZY_DBL - FRENZY_TRP) / FRENZY_SEGS / (1 - (FRENZY_DBL * 2 + FRENZY_TRP * 3) / FRENZY_SEGS) };

const RAW = {
  toss: [[2, 0], [3, 26], [4, 26], [5, 24], [6, 20], [8, 18], [10, 16], [12, 12], [15, 10], [20, 8], [25, 6], [50, 4], [100, 2]],
  wall: [[5, 0], [7, 40], [10, 36], [15, 28], [20, 22], [25, 16], [30, 10], [40, 8], [50, 7], [75, 4], [100, 3], [150, 1.2], [200, 0.8], [500, 0.25]],
  drop: [[5, 0], [7, 34], [10, 32], [15, 26], [20, 20], [25, 14], [30, 10], [40, 8], [50, 6], [75, 3], [100, 2.2], [150, 1], [200, 0.6], [500, 0.2]],
  frenzy: [[10, 0], [15, 30], [20, 28], [25, 24], [30, 18], [40, 14], [50, 12], [75, 8], [100, 6], [150, 3.5], [200, 2.5], [300, 1.2], [500, 0.6], [1000, 0.2]],
};
function solveFirst(table, target) {
  const [v0] = table[0];
  const rest = table.slice(1).reduce((a, [v, w]) => a + w * (v - target), 0);
  const w0 = rest / (target - v0);
  if (!(w0 > 0)) throw new Error('bonus table cannot reach its target');
  return [[v0, w0], ...table.slice(1)];
}
const segCount = (id) => WHEEL.filter((s) => s === id).length;
export const BONUS_TARGET = Object.fromEntries(BONUS_IDS.map((id) => [id, TARGET_RTP * SEGMENTS / segCount(id) - 1]));   // mean multiplier needed (to 1)
// Coin Toss draws two DIFFERENT multipliers (red from the table, blue from the table without red's
// value) and a fair flip picks one, so its average is not the plain table mean:
//   E = Σ_r p_r · ( v_r + E[v | v ≠ v_r] ) / 2,   E[v | v ≠ v_r] = (E[v] − p_r v_r) / (1 − p_r)
export function tossMean(t) {
  const tot = t.reduce((a, [, w]) => a + w, 0), E = mean(t);
  return t.reduce((a, [v, w]) => { const p = w / tot; return a + p * (v + (E - p * v) / (1 - p)) / 2; }, 0);
}
/** Solves the first weight by bisection for any average function (the average falls as it grows). */
function solveFirstBy(table, target, f) {
  let lo = 1e-6, hi = 1e6;
  const at = (w0) => f([[table[0][0], w0], ...table.slice(1)]);
  if (!(at(lo) > target && at(hi) < target)) throw new Error('bonus table cannot reach its target');
  for (let i = 0; i < 200; i++) { const mid = Math.sqrt(lo * hi); if (at(mid) > target) lo = mid; else hi = mid; }
  return [[table[0][0], (lo + hi) / 2], ...table.slice(1)];
}
export const TABLES = Object.fromEntries(BONUS_IDS.map((id) => [id, id === 'toss'
  ? solveFirstBy(RAW[id], BONUS_TARGET[id] / boostFactor(id), tossMean)
  : solveFirst(RAW[id], BONUS_TARGET[id] / boostFactor(id) / K[id])]));
export const BONUS_K = K;
export const tableMean = mean;
/** The average result of each bonus game (before the booster). */
export const bonusMean = (id) => (id === 'toss' ? tossMean(TABLES.toss) : mean(TABLES[id]) * K[id]);
