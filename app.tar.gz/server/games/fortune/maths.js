// Exact return of every Fortune Live bet spot, from the tables in config.js.
// (The 20,000x bonus cap shifts these by less than 0.05%; scripts/sim-fortune.mjs measures the real figures.)
import { BOOST_CHANCE, BOOST_MEAN, SEGMENTS, SPOTS, WHEEL, boostFactor, bonusMean } from './config.js';

const P = (id) => WHEEL.filter((s) => s === id).length / SEGMENTS;

export function spotRtp(id) {
  const s = SPOTS[id];
  if (s.kind === 'number') return P(id) * (1 + s.pay * (1 + BOOST_CHANCE[id] * (BOOST_MEAN - 1)));
  return P(id) * (1 + bonusMean(id) * boostFactor(id));
}
export const segmentsOf = (id) => WHEEL.filter((s) => s === id).length;
export const boosterChance = () => Object.values(BOOST_CHANCE).reduce((a, b) => a + b, 0);
