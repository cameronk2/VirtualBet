// Exact return of every Fortune Live bet spot, from the tables in config.js.
// (The 20,000x bonus cap and the Coin Toss "no matching sides" redraw shift these
// by less than 0.05%; scripts/sim-fortune.mjs measures the real figures.)
import { BONUS_K, BOOST_CHANCE, BOOST_MEAN, SEGMENTS, SPOTS, TABLES, WHEEL, boostFactor, tableMean } from './config.js';

const P = (id) => WHEEL.filter((s) => s === id).length / SEGMENTS;

export function spotRtp(id) {
  const s = SPOTS[id];
  if (s.kind === 'number') return P(id) * (1 + s.pay * (1 + BOOST_CHANCE[id] * (BOOST_MEAN - 1)));
  return P(id) * (1 + tableMean(TABLES[id]) * BONUS_K[id] * boostFactor(id));
}
export const segmentsOf = (id) => WHEEL.filter((s) => s === id).length;
export const boosterChance = () => Object.values(BOOST_CHANCE).reduce((a, b) => a + b, 0);
