// Fortune Live – one round per request, settled by the server.
//   spin:  booster → wheel → (numbers settle at once; Coin Toss and Drop Zone play out in full)
//          Prize Wall and Fortune Frenzy wait for the player's choice when they bet on them.
//   pick:  the player's tile (Prize Wall) or flapper (Fortune Frenzy); the bonus is settled.
// Hidden Prize Wall values stay in the saved state and are never sent before the pick.
import { checkStake, fail, pickWeighted } from '../common.js';
import {
  BONUS_IDS, BONUS_MAX_X, BOOST_CHANCE, BOOST_MULTS, DROP_DOUBLES, DROP_ROWS, DROP_SLOTS, FLAPPERS, FLAPPER_OFFSET,
  FRENZY_DBL, FRENZY_SEGS, FRENZY_TRP, SEGMENTS, SPOTS, SPOT_IDS, SPOT_MAX, SPOT_MIN, TABLES, WHEEL,
} from './config.js';

const draw = (id, rand) => pickWeighted(TABLES[id], rand);
const shuffle = (a, rand) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

export function validateBets(bets) {
  if (!bets || typeof bets !== 'object' || Array.isArray(bets)) fail('Place a bet first.');
  const clean = {};
  for (const [k, v] of Object.entries(bets)) {
    if (!SPOT_IDS.includes(k)) fail('Unknown bet spot.');
    if (v === 0 || v == null) continue;
    clean[k] = checkStake(v, { min: SPOT_MIN, max: SPOT_MAX, label: `${SPOTS[k].name} bet` });
  }
  if (!Object.keys(clean).length) fail('Place a bet first.');
  return clean;
}

/** The Fortune Booster: at most one spot lit with a multiplier, or a miss. */
export function drawBooster(rand) {
  let r = rand();
  for (const id of SPOT_IDS) {
    if ((r -= BOOST_CHANCE[id]) < 0) return { spot: id, mult: pickWeighted(BOOST_MULTS, rand), hit: true };
  }
  // a miss still shows reels: a spot and a multiplier that don't line up
  return { spot: SPOT_IDS[Math.floor(rand() * SPOT_IDS.length)], mult: pickWeighted(BOOST_MULTS, rand), hit: false };
}

// ── bonus games ───────────────────────────────────────────────────────────
export function playToss(rand) {
  // each side gets its own multiplier (they can match)
  const red = draw('toss', rand);
  const blue = draw('toss', rand);
  const side = rand() < 0.5 ? 'red' : 'blue';
  return { red, blue, side, x: side === 'red' ? red : blue };
}

export function makeWall(rand) {
  return Array.from({ length: 108 }, () => draw('wall', rand));
}

/** One puck: a drop column, then a bounce left or right on every row (walls reflect). */
function dropPath(rand) {
  const start = Math.floor(rand() * DROP_SLOTS);
  let c = start;
  const steps = [];
  for (let r = 0; r < DROP_ROWS; r++) {
    let d = rand() < 0.5 ? -0.5 : 0.5;
    if (c + d < 0 || c + d > DROP_SLOTS - 1) d = -d;
    c += d; steps.push(d);
  }
  return { start, steps, slot: c };
}
export function playDrop(rand) {
  const slots = Array.from({ length: DROP_SLOTS }, () => draw('drop', rand));
  const dbl = shuffle([...Array(DROP_SLOTS).keys()], rand).slice(0, DROP_DOUBLES);
  const board = slots.map((v, i) => (dbl.includes(i) ? 'D' : v));
  const drops = [];
  let factor = 1;
  for (let k = 0; k < 40; k++) {
    const p = dropPath(rand);
    drops.push({ ...p, factor });
    if (board[p.slot] !== 'D') return { board, drops, x: Math.min(BONUS_MAX_X, board[p.slot] * factor) };
    factor *= 2;
    if (factor * 5 >= BONUS_MAX_X) break;
  }
  // only reachable after many doubles: the cap applies
  return { board, drops, x: BONUS_MAX_X };
}

export function makeFrenzy(rand) {
  const wheel = Array.from({ length: FRENZY_SEGS }, () => draw('frenzy', rand));
  const spots = shuffle([...Array(FRENZY_SEGS).keys()], rand);
  spots.slice(0, FRENZY_DBL).forEach((i) => { wheel[i] = 'DBL'; });
  spots.slice(FRENZY_DBL, FRENZY_DBL + FRENZY_TRP).forEach((i) => { wheel[i] = 'TRP'; });
  return wheel;
}
/** Spins the giant wheel for the chosen flapper until it lands on a prize. */
export function spinFrenzy(wheel, flapper, rand) {
  const off = FLAPPER_OFFSET[flapper];
  const spins = [];
  let factor = 1;
  for (let k = 0; k < 30; k++) {
    const stop = Math.floor(rand() * FRENZY_SEGS);          // segment under the green flapper
    const seg = (stop + off) % FRENZY_SEGS;
    const v = wheel[seg];
    spins.push({ stop, seg, value: v, factor });
    if (v === 'DBL' || v === 'TRP') { factor *= v === 'DBL' ? 2 : 3; if (factor * 10 >= BONUS_MAX_X) return { spins, x: BONUS_MAX_X }; continue; }
    return { spins, x: Math.min(BONUS_MAX_X, v * factor) };
  }
  return { spins, x: BONUS_MAX_X };
}

// ── round ─────────────────────────────────────────────────────────────────
const ret = (bet, x) => Math.floor(bet * (1 + x));

/** Settles every bet once the landed spot's multiple (to 1, booster included) is known. */
function settle(bets, landed, x) {
  const results = {};
  let payout = 0, staked = 0;
  for (const [spot, bet] of Object.entries(bets)) {
    staked += bet;
    const r = spot === landed ? ret(bet, x) : 0;
    results[spot] = { bet, ret: r };
    payout += r;
  }
  return { results, payout, staked };
}

export function spinRound(bets, rand, force = {}) {
  const booster = force.booster ?? drawBooster(rand);
  const segment = force.segment ?? Math.floor(rand() * SEGMENTS);
  const landed = WHEEL[segment];
  const boost = booster.hit && booster.spot === landed ? booster.mult : 1;
  const out = { booster, segment, landed, boost };
  const s = SPOTS[landed];
  if (s.kind === 'number') return { ...out, x: s.pay * boost, ...settle(bets, landed, s.pay * boost), done: true };
  if (landed === 'toss') { const toss = playToss(rand); const x = Math.min(BONUS_MAX_X, toss.x * boost); return { ...out, toss, x, ...settle(bets, landed, x), done: true }; }
  if (landed === 'drop') { const drop = playDrop(rand); const x = Math.min(BONUS_MAX_X, drop.x * boost); return { ...out, drop, x, ...settle(bets, landed, x), done: true }; }
  // Prize Wall / Fortune Frenzy: wait for a choice if the player is in the bonus
  const pending = landed === 'wall' ? { bonus: 'wall', values: makeWall(rand), boost } : { bonus: 'frenzy', wheel: makeFrenzy(rand), boost };
  if (!bets[landed]) {
    // not in it: the bonus is played for the show with a random choice
    const shown = landed === 'wall' ? finishWall(pending, Math.floor(rand() * 108)) : finishFrenzy(pending, FLAPPERS[Math.floor(rand() * 3)], rand);
    return { ...out, [landed]: shown, x: shown.x, ...settle(bets, landed, shown.x), done: true, watched: true };
  }
  return { ...out, pending, ...settle(bets, landed, 0), done: false };
}

export function finishWall(p, pick) {
  if (!Number.isInteger(pick) || pick < 0 || pick >= 108) fail('Choose one of the 108 prizes.');
  const base = p.values[pick];
  return { pick, values: p.values, base, x: Math.min(BONUS_MAX_X, base * p.boost) };
}
export function finishFrenzy(p, flapper, rand) {
  if (!FLAPPERS.includes(flapper)) fail('Choose a flapper.');
  const r = spinFrenzy(p.wheel, flapper, rand);
  return { flapper, wheel: p.wheel, spins: r.spins, base: r.x, x: Math.min(BONUS_MAX_X, r.x * p.boost) };
}

// public view of a waiting bonus (Prize Wall values stay hidden)
const pendingView = (p) => p && ({ bonus: p.bonus, boost: p.boost, bets: p.bets, segment: p.segment, booster: p.booster, wheel: p.bonus === 'frenzy' ? p.wheel : undefined, tiles: p.bonus === 'wall' ? 108 : undefined, at: p.at });

function record(state, r, extra = {}) {
  const top = r.landed === 'toss' ? r.toss?.x : r.landed === 'drop' ? r.drop?.x : r.landed === 'wall' ? r.wall?.base : r.landed === 'frenzy' ? r.frenzy?.base : null;
  const history = [{ landed: r.landed, boost: r.boost, x: top ?? null, total: r.landed.startsWith('n') ? null : r.x, ...extra }, ...(state.history || [])].slice(0, 60);
  const stats = { ...(state.stats || {}) };
  stats[r.landed] = (stats[r.landed] || 0) + 1;
  stats.rounds = (stats.rounds || 0) + 1;
  return { ...state, history, stats };
}

export const fortune = {
  id: 'fortune', label: 'Fortune Live',
  init: () => ({ history: [], stats: {}, pending: null }),
  view: (s) => ({ history: (s.history || []).slice(0, 40), stats: s.stats || {}, pending: pendingView(s.pending) }),
  act(state, action, body, { rand, now }) {
    if (action === 'spin') {
      if (state.pending) fail('Finish the bonus first.');
      const bets = validateBets(body?.bets);
      const force = process.env.NODE_ENV !== 'production' && process.env.FORTUNE_FORCE_SEGMENT ? { segment: Number(process.env.FORTUNE_FORCE_SEGMENT) } : {};
      const r = spinRound(bets, rand, force);
      if (!r.done) {
        // stake taken now; the bonus is paid on the pick
        const pending = { ...r.pending, bets, segment: r.segment, booster: r.booster, landed: r.landed, at: now };
        const pub = { ...r, pending: pendingView(pending) };
        return { stake: r.staked, payout: 0, state: { ...state, pending }, out: { ...pub, win: 0, bet: r.staked }, events: [] };
      }
      const st = record(state, r);
      return {
        stake: r.staked, payout: r.payout, state: st,
        out: { ...r, win: r.payout, bet: r.staked },
        settled: { staked: r.staked, payout: r.payout },
        events: [{ t: 'slot', game: 'fortune', x: r.payout / r.staked, feature: SPOTS[r.landed].kind === 'bonus' && !!bets[r.landed] }],
      };
    }
    if (action === 'pick') {
      const p = state.pending;
      if (!p) fail('There is no bonus waiting.');
      const shown = p.bonus === 'wall' ? finishWall(p, Number(body?.pick)) : finishFrenzy(p, body?.pick, rand);
      const s = settle(p.bets, p.landed, shown.x);
      const r = { booster: p.booster, segment: p.segment, landed: p.landed, boost: p.boost, [p.bonus]: shown, x: shown.x, ...s, done: true };
      const st = record({ ...state, pending: null }, r);
      return {
        stake: 0, payout: s.payout, state: st,
        out: { ...r, win: s.payout, bet: s.staked },
        settled: { staked: s.staked, payout: s.payout },
        events: [{ t: 'slot', game: 'fortune', x: s.payout / s.staked, feature: true }],
      };
    }
    fail('Unknown action.');
  },
};
