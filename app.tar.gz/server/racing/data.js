// Virtual horse racing – fixed reference data. Every racecourse, horse, jockey and trainer here is
// fictional (any likeness to a real name is coincidental). Nothing here describes real racing.

export const FURLONG = 201.168; // metres

/** Fictional racecourses. `scene` drives the 3D course (colours, backdrop, layout). */
export const COURSES = [
  { id: 'ashcombe', name: 'Ashcombe Park', region: 'Berkshire Downs', hand: 'left', desc: 'A wide, galloping left-handed oval in old parkland, with a long run-in that rewards stamina.', features: ['Galloping', 'Long straight', 'Parkland'],
    scene: { grass: '#3f7d34', grass2: '#4a8c3c', sky: ['#7fb2e5', '#dcecf8'], hills: '#5f8a59', far: '#9bb7a8', time: 'day', stand: '#f1ede4', roof: '#2e4d3a', layout: 'oval', size: 1.0 } },
  { id: 'kingsbury', name: 'Kingsbury Downs', region: 'Wiltshire', hand: 'right', desc: 'Undulating right-handed downland track beneath chalk hills, with a stiff climb to the line.', features: ['Undulating', 'Uphill finish', 'Downland'],
    scene: { grass: '#4b7f2f', grass2: '#568c38', sky: ['#8cb8de', '#eef4f8'], hills: '#7a9a5c', far: '#c9d6c2', time: 'day', stand: '#e9e4d8', roof: '#3a3a52', layout: 'oval', size: 1.15 } },
  { id: 'rivermead', name: 'Rivermead', region: 'Thames Valley', hand: 'right', desc: 'Flat, fair riverside course where front-runners love the tight bend into the straight.', features: ['Flat', 'Riverside', 'Sharp bend'],
    scene: { grass: '#3d7a3a', grass2: '#479044', sky: ['#9cc3e8', '#f2f6f9'], hills: '#6f936a', far: '#a8c2c7', water: true, time: 'day', stand: '#efe9dc', roof: '#1f3b5a', layout: 'oval', size: 0.9 } },
  { id: 'harrowgate', name: 'Harrowgate Heath', region: 'North Yorkshire', hand: 'left', desc: 'Exposed moorland track with a punishing uphill finish; stamina counts here.', features: ['Stiff', 'Moorland', 'Uphill finish'],
    scene: { grass: '#4f7a3a', grass2: '#5b8843', sky: ['#a6b6c8', '#e7ebef'], hills: '#7d6f5a', far: '#a99a8a', time: 'overcast', stand: '#e2ddd2', roof: '#4a2f2a', layout: 'oval', size: 1.05 } },
  { id: 'marlow', name: 'Marlow Vale', region: 'Buckinghamshire', hand: 'left', desc: 'Tight, turning track that suits nimble, quick-starting horses drawn low.', features: ['Tight', 'Turning', 'Draw bias'],
    scene: { grass: '#3c8139', grass2: '#469343', sky: ['#86b9e8', '#f0f6fb'], hills: '#5e8a4f', far: '#9fb59a', time: 'day', stand: '#f4efe6', roof: '#6b1f2a', layout: 'oval', size: 0.8 } },
  { id: 'castleton', name: 'Castleton', region: 'Northumberland', hand: 'left', desc: 'A historic course beneath a ruined castle, with a straight six furlongs and a round mile.', features: ['Straight course', 'Historic', 'Castle'],
    scene: { grass: '#457a33', grass2: '#4f883b', sky: ['#9bb4cf', '#ecf0f4'], hills: '#6c7f5a', far: '#8f9a88', castle: true, time: 'day', stand: '#e6e1d6', roof: '#2a3340', layout: 'oval', size: 1.0 } },
  { id: 'saltmarsh', name: 'Saltmarsh Sands', region: 'Norfolk Coast', hand: 'right', desc: 'Breezy seaside track on the marshes; quick ground and a fast-run finish.', features: ['Seaside', 'Fast ground', 'Breezy'],
    scene: { grass: '#5a8a3e', grass2: '#64974a', sky: ['#7ec2ec', '#f6fbfe'], hills: '#c8b98d', far: '#7fb8d6', sea: true, time: 'day', stand: '#f7f3ea', roof: '#1c5d7a', layout: 'oval', size: 1.1 } },
  { id: 'northbridge', name: 'Northbridge', region: 'West Midlands', hand: 'left', desc: 'Floodlit evening venue: racing under the lights on a sharp, fair circuit.', features: ['Floodlit', 'Evening', 'Sharp'],
    scene: { grass: '#2f6a32', grass2: '#387a3b', sky: ['#0f1a33', '#3a4b72'], hills: '#1d2c22', far: '#26324a', time: 'night', stand: '#d8d4cc', roof: '#16161e', layout: 'oval', size: 0.95 } },
];
export const courseById = Object.fromEntries(COURSES.map((c) => [c.id, c]));

export const GOINGS = [
  { id: 'firm', name: 'Firm', speed: 1.012 }, { id: 'gf', name: 'Good to Firm', speed: 1.006 }, { id: 'good', name: 'Good', speed: 1.0 },
  { id: 'gs', name: 'Good to Soft', speed: 0.992 }, { id: 'soft', name: 'Soft', speed: 0.982 }, { id: 'heavy', name: 'Heavy', speed: 0.968 },
];
export const goingById = Object.fromEntries(GOINGS.map((g) => [g.id, g]));

/**
 * Race formats. `furlongs` is the list of distances the format uses; `fields` the field sizes;
 * handicap races weight horses by rating so the field finishes closer together.
 */
export const FORMATS = [
  { id: 'sprint', name: 'Sprint', type: 'Flat', furlongs: [5, 6], fields: [6, 8, 10, 12, 16], handicap: false, title: ['Sprint Stakes', 'Dash', 'Flying Five', 'Sprint'] },
  { id: 'sprint_h', name: 'Sprint Handicap', type: 'Handicap', furlongs: [5, 6, 7], fields: [8, 10, 12, 16], handicap: true, title: ['Sprint Handicap', 'Handicap'] },
  { id: 'mile', name: 'Mile', type: 'Flat', furlongs: [7, 8], fields: [6, 8, 10, 12], handicap: false, title: ['Mile Stakes', 'Mile', 'Conditions Stakes'] },
  { id: 'middle', name: 'Middle Distance', type: 'Flat', furlongs: [10, 11, 12], fields: [6, 8, 10, 12], handicap: false, title: ['Stakes', 'Cup', 'Trophy'] },
  { id: 'middle_h', name: 'Middle-Distance Handicap', type: 'Handicap', furlongs: [9, 10, 12], fields: [8, 10, 12, 16], handicap: true, title: ['Handicap', 'Heritage Handicap'] },
  { id: 'staying', name: 'Long Distance', type: 'Flat', furlongs: [14, 16, 18], fields: [6, 8, 10], handicap: false, title: ['Cup', 'Stayers Stakes', 'Marathon'] },
  { id: 'champ', name: 'Championship', type: 'Championship', furlongs: [8, 10, 12], fields: [8, 10, 12], handicap: false, title: ['Championship', 'Gold Cup', 'Crown Stakes'], elite: true },
];
export const formatById = Object.fromEntries(FORMATS.map((f) => [f.id, f]));

/**
 * Each-way / place terms (configurable). The usual UK terms: 5–7 runners ¼ odds 2 places; 8–11 ⅕ odds
 * 3 places; 12–15 handicaps ¼ odds 3 places, otherwise ⅕ odds 3 places; 16+ handicaps ¼ odds 4 places.
 */
export const PLACE_TERMS = [
  { min: 5, max: 7, handicap: null, places: 2, fraction: [1, 4] },
  { min: 8, max: 11, handicap: null, places: 3, fraction: [1, 5] },
  { min: 12, max: 15, handicap: true, places: 3, fraction: [1, 4] },
  { min: 12, max: 99, handicap: false, places: 3, fraction: [1, 5] },
  { min: 16, max: 99, handicap: true, places: 4, fraction: [1, 4] },
];
export function placeTerms(field, handicap) {
  const t = PLACE_TERMS.find((x) => field >= x.min && field <= x.max && (x.handicap === null || x.handicap === !!handicap));
  return t ? { places: t.places, fraction: t.fraction } : null;
}

export const JOCKEYS = [
  'Tom Ashford', 'Ella Brennan', 'Callum Doyle', 'Priya Sandhu', 'Rhys Morgan', 'Niamh Gallagher', 'Ollie Whitcombe', 'Sasha Kerr', 'Jack Penrose', 'Molly Hale',
  'Dan Okafor', 'Kieran Walsh', 'Grace Harlow', 'Finn Mulcahy', 'Hollie Barr', 'Luca Romano', 'Ben Carver', 'Aoife Lynch', 'Sam Thackeray', 'Isla Pendle',
  'Joe Fairweather', 'Tara Quinlan', 'Harvey Stone', 'Megan Royce', 'Liam Courtney', 'Zara Ellwood', 'Connor Bligh', 'Ruby Ashdown', 'Will Hathersage', 'Nadia Fenwick',
];
export const TRAINERS = [
  'Harriet Langley', 'George Ashworth', 'Declan Murphy-Hayes', 'Sophie Wainwright', 'Charles Venn', 'Ann-Marie Cole', 'Patrick Delaney', 'Robert Halsey', 'Fiona Garside', 'Martin Pryce',
  'Lucy Hargreaves', 'James Thornbury', 'Siobhan Keane', 'Edward Mallory', 'Karen Whitlock', 'Alistair Brodie', 'Helen Marchant', 'Nick Lowther', 'Clare Penhaligon', 'Stuart Rennison',
  'Victoria Ames', 'Owen Pritchard', 'Bethany Sowerby', 'Rory Fitzalan', 'Jonathan Crewe',
];
export const OWNERS = ['Hartwell Racing', 'The Copper Beech Partnership', 'Mrs J. Pennington', 'Saltire Bloodstock', 'Blue Ridge Syndicate', 'Mr & Mrs D. Ferris', 'The Lark Rise Club', 'Highmoor Stud', 'Kestrel Thoroughbreds', 'The Old Quay Partnership', 'Ms A. Rutherford', 'Greenwood Racing'];

// Horse names are built from these parts (deterministic, so every server has the same horses).
const NAME_A = ['Silver', 'Midnight', 'Copper', 'Velvet', 'Distant', 'Harbour', 'Crimson', 'Northern', 'Quiet', 'Golden', 'Hidden', 'Western', 'Amber', 'Storm', 'Cobalt', 'Willow',
  'Brave', 'Lucky', 'Wild', 'Royal', 'Paper', 'Iron', 'Cloud', 'Morning', 'Painted', 'Restless', 'Gentle', 'Saffron', 'Scarlet', 'Highland', 'Rapid', 'Secret', 'Starlit', 'Copperfield', 'Jasper', 'Indigo'];
const NAME_B = ['Tempest', 'Regent', 'Lantern', 'Comet', 'Harvest', 'Sparrow', 'Voyage', 'Echo', 'Thistle', 'Meridian', 'Pilgrim', 'Falconer', 'Cascade', 'Juniper', 'Ember', 'Rambler',
  'Gambit', 'Sonnet', 'Quarry', 'Ballad', 'Monarch', 'Spirit', 'Harmony', 'Signal', 'Drummer', 'Lighthouse', 'Kestrel', 'Outlaw', 'Verse', 'Mariner', 'Orchard', 'Paragon', 'Rumour', 'Shilling', 'Tinker', 'Waltz'];
const SINGLE = ['Bramblewick', 'Corrigan', 'Dashwood', 'Ellwand', 'Fennimore', 'Galloglass', 'Halcyon Bay', 'Inchcape', 'Jolly Roger Jim', 'Kittiwake', 'Larkspur Lane', 'Mistral Song', 'Nightjar', 'Oakhurst', 'Pennywhistle',
  'Quickthorn', 'Riverrun', 'Sandpiper Sky', 'Tamarisk', 'Umberleigh', 'Vantage Point', 'Wychwood', 'Yarrow Gold', 'Zephyrine', 'Ballyhoo Boy', 'Cantering Kate', 'Dunmore Dancer', 'Fiddler\'s Green', 'Glenfinnan', 'Hopscotch Harry'];
// Famous real racehorse names to avoid if the generator happens to build one.
const AVOID = new Set(['Golden Horn', 'Royal Ascot', 'Silver Arrow', 'Storm Cat', 'Lucky Spirit', 'Brave Spirit', 'Golden Comet', 'Midnight Comet']);

export const COATS = [
  { id: 'bay', name: 'Bay', main: '#5a2e14', dark: '#3a1d0c', light: '#7a4220', hair: '#141110', muzzle: '#2b1a10' },
  { id: 'dbay', name: 'Dark bay', main: '#3a1e10', dark: '#24120a', light: '#4f2a16', hair: '#0e0b0a', muzzle: '#1d120b' },
  { id: 'chestnut', name: 'Chestnut', main: '#8a4019', dark: '#5f2b10', light: '#a8541f', hair: '#7a3412', muzzle: '#4a2410' },
  { id: 'grey', name: 'Grey', main: '#b8b6ae', dark: '#8d8b84', light: '#d6d4cc', hair: '#e8e6e0', muzzle: '#6b6862' },
  { id: 'black', name: 'Black', main: '#1c1a19', dark: '#121110', light: '#2a2725', hair: '#0a0909', muzzle: '#151312' },
  { id: 'roan', name: 'Roan', main: '#7a5a4a', dark: '#5a4034', light: '#9a7a6a', hair: '#2a2220', muzzle: '#3a2a22' },
];

const SILK_COLOURS = ['#c8102e', '#0b3d91', '#ffd100', '#00843d', '#ffffff', '#111111', '#7d3c98', '#f28c28', '#00a3e0', '#e4007c', '#8b5a2b', '#5c7f2f', '#b5121b', '#1e2a78', '#f5e1a4', '#00635a'];
const SILK_PATTERNS = ['plain', 'hoops', 'stripes', 'sash', 'chevrons', 'quartered', 'star', 'braces', 'diamond', 'spots', 'halved', 'cross'];

/** Deterministic small generator for the reference data (not for outcomes). */
export function seeded(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

/** The horse population (stable across servers): ratings, coat, silks, trainer and preferences. */
export function buildHorses(n = 240) {
  const r = seeded(20261118);
  const names = new Set();
  const pick = (a) => a[Math.floor(r() * a.length)];
  for (const s of SINGLE) names.add(s);
  while (names.size < n) { const nm = `${pick(NAME_A)} ${pick(NAME_B)}`; if (!AVOID.has(nm)) names.add(nm); }
  const list = [...names].slice(0, n);
  for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
  return list.map((name, i) => {
    // a quality level per horse, then each attribute around it; some are specialists
    const q = 52 + r() * 36 + (r() < 0.08 ? 8 : 0);
    const kind = r();
    const sprinter = kind < 0.3, stayer = kind > 0.72;
    const rnd = (bias = 0, spread = 9) => Math.round(Math.max(35, Math.min(99, q + bias + (r() - 0.5) * 2 * spread)));
    const ratings = {
      speed: rnd(sprinter ? 6 : stayer ? -4 : 0),
      stamina: rnd(sprinter ? -14 : stayer ? 12 : 0, 8),
      accel: rnd(sprinter ? 8 : stayer ? -6 : 0),
      finish: rnd(0, 11),
      temperament: Math.round(40 + r() * 58),
    };
    const goingPref = pick(['firm', 'gf', 'good', 'good', 'gs', 'soft']);
    const style = ratings.accel - ratings.finish > 6 ? 'Front-runner' : ratings.finish - ratings.accel > 6 ? 'Hold-up' : ratings.accel > 70 ? 'Prominent' : 'Midfield';
    const c1 = pick(SILK_COLOURS); let c2 = pick(SILK_COLOURS); if (c2 === c1) c2 = c1 === '#ffffff' ? '#111111' : '#ffffff';
    return {
      id: i + 1, name, sex: pick(['g', 'g', 'c', 'f', 'm', 'h']), age: 3 + Math.floor(r() * 6), coat: pick(COATS).id,
      trainer: pick(TRAINERS), owner: pick(OWNERS),
      silks: { c1, c2, cap: r() < 0.5 ? c1 : c2, pattern: pick(SILK_PATTERNS) },
      ratings, goingPref, style,
      sire: `${pick(NAME_A)} ${pick(NAME_B)}`, dam: `${pick(NAME_A)} ${pick(NAME_B)}`,
    };
  });
}
export const SEX = { g: 'Gelding', c: 'Colt', f: 'Filly', m: 'Mare', h: 'Horse' };

/** "1m 2f", "6f", "2m". */
export function distanceLabel(f) {
  const m = Math.floor(f / 8), r = f % 8;
  return m ? `${m}m${r ? ` ${r}f` : ''}` : `${r}f`;
}
