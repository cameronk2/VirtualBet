// Virtual horse racing on the server: the persistent horse database, the race timetable, running
// races, bets and settlement, statistics and leaderboards. All money moves inside a database
// transaction with the existing wallet; every outcome comes from the server's secure RNG.
import crypto from 'node:crypto';
import { q, tx } from '../db.js';
import { HttpError, now } from '../util.js';
import { credit, debit } from '../wallet.js';
import { checkBreak, effectiveLimit, stakedLast24h } from '../bets.js';
import { gbp } from '../money.js';
import { award } from '../progress.js';
import { COURSES, FORMATS, buildHorses, courseById, formatById } from './data.js';
import { BET_TYPES, checkBet, composite, fracLabel, makeCard, outcome, potential, priceBet, resultOf, settle, simulate } from './core.js';

const rand = () => crypto.randomInt(0, 2 ** 32) / 2 ** 32;
export const SLOT_MS = 3 * 60 * 1000;          // a scheduled race every 3 minutes
export const AHEAD_MS = 45 * 60 * 1000;        // keep the timetable filled this far ahead
export const CLOSE_MS = 5000;                  // betting closes 5 s before the off
const REST_MS = 25 * 60 * 1000;                // a horse runs at most once in this window
const RACE_LIST = ['sprint', 'sprint_h', 'mile', 'sprint', 'middle', 'mile', 'middle_h', 'staying', 'sprint_h', 'champ'];

// ── horses ────────────────────────────────────────────────────────────────────
export function seedHorses() {
  if (q('SELECT COUNT(*) AS n FROM rc_horses').get().n) return;
  tx(() => { for (const h of buildHorses()) q('INSERT INTO rc_horses (id, name, data) VALUES (?, ?, ?)').run(h.id, h.name, JSON.stringify(h)); });
}
const horseRow = (r) => r && { ...JSON.parse(r.data), runs: r.runs, wins: r.wins, places: r.places, earnings: r.earnings, form: r.form, lastRunAt: r.last_run_at };
export const allHorses = () => q('SELECT * FROM rc_horses').all().map(horseRow);
const horsesByIds = (ids) => ids.map((id) => horseRow(q('SELECT * FROM rc_horses WHERE id = ?').get(id)));

// ── the timetable ─────────────────────────────────────────────────────────────
/** What runs in timetable slot k (slot = off time / SLOT_MS): a 5-race meeting at each course in turn. */
export function slotPlan(k) {
  const course = COURSES[Math.floor(k / 5) % COURSES.length];
  const format = RACE_LIST[(k * 7 + Math.floor(k / 5)) % RACE_LIST.length];
  return { course: course.id, format };
}
function busyHorseIds(off) {
  const ids = new Set();
  for (const r of q("SELECT card FROM rc_races WHERE off_at BETWEEN ? AND ? OR (kind = 'quick' AND status = 'open')").all(off - REST_MS, off + REST_MS)) for (const x of JSON.parse(r.card).runners) ids.add(x.horseId);
  return ids;
}
function createSlot(k) {
  const off = k * SLOT_MS;
  const plan = slotPlan(k);
  const busy = busyHorseIds(off);
  const pool = allHorses().filter((h) => !busy.has(h.id));
  const card = makeCard({ pool, rand, courseId: plan.course, formatId: plan.format, off, sims: 500 });
  q('INSERT OR IGNORE INTO rc_races (kind, slot, course, off_at, status, card, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run('sched', k, plan.course, off, 'open', JSON.stringify(card), now());
}
/** Fill the timetable up to `limit` new races (cheap to call often). */
export function ensureSchedule(t = now(), limit = 2) {
  const first = Math.floor(t / SLOT_MS) + 1, last = Math.floor((t + AHEAD_MS) / SLOT_MS);
  let made = 0;
  for (let k = first; k <= last && made < limit; k++) {
    if (!q('SELECT 1 FROM rc_races WHERE slot = ?').get(k)) { createSlot(k); made++; }
  }
  return made;
}

// ── running a race ────────────────────────────────────────────────────────────
function runRace(row, t = now()) {
  const card = JSON.parse(row.card);
  const horses = horsesByIds(card.runners.map((r) => r.horseId));
  const sim = simulate(card, horses, rand, { trace: true });
  const result = resultOf(card, sim);
  const duration = sim.trace.frames.length * sim.trace.every;
  const off = row.off_at ?? t;
  tx(() => {
    q("UPDATE rc_races SET status = 'finished', result = ?, trace = ?, duration = ?, off_at = ? WHERE id = ? AND status = 'open'")
      .run(JSON.stringify(result), JSON.stringify({ ...sim.trace, order: sim.order.map((i) => card.runners[i].no) }), duration, off, row.id);
  });
  return { card, result, duration };
}
/**
 * Settle a finished race: bets, horse records and run history. Scheduled races settle when the
 * broadcast of the run has finished, so balances and results never spoil the race while it is shown.
 */
function settleFinished(row, t = now()) {
  const card = JSON.parse(row.card), result = JSON.parse(row.result), off = row.off_at;
  tx(() => {
    if (!q('UPDATE rc_races SET settled_at = ? WHERE id = ? AND settled_at IS NULL').run(t, row.id).changes) return;
    // horses: form figures, record and (fictional) prize money; one row per run for the profiles
    const prize = [0.6, 0.2, 0.1, 0.05, 0.03, 0.02];
    for (const p of result.positions) {
      const r = card.runners.find((x) => x.no === p.no);
      const fig = p.pos <= 9 ? String(p.pos) : '0';
      q(`UPDATE rc_horses SET runs = runs + 1, wins = wins + ?, places = places + ?, earnings = earnings + ?, form = substr(? || form, 1, 12), last_run_at = ? WHERE id = ?`)
        .run(p.pos === 1 ? 1 : 0, p.pos <= 3 ? 1 : 0, Math.round((card.prize * (prize[p.pos - 1] || 0))), fig, off, r.horseId);
      q('INSERT OR REPLACE INTO rc_runs (race_id, horse_id, no, jockey, pos, time, margin, odds, off_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
        .run(row.id, r.horseId, r.no, r.jockey, p.pos, p.time, p.margin, fracLabel(r.odds), off);
    }
    settleRace(row.id, card, result);
  });
}
function settleRace(raceId, card, result) {
  for (const b of q("SELECT * FROM rc_bets WHERE race_id = ? AND status = 'open'").all(raceId)) {
    const bet = betRow(b);
    const ret = settle(bet, result);
    const status = outcome(bet, result, ret);
    q('UPDATE rc_bets SET status = ?, returns = ?, settled_at = ? WHERE id = ?').run(status, ret, now(), b.id);
    if (ret > 0) credit(b.user_id, 'RACING_WIN', ret, 'racing', `Racing return · ${card.name} · ${BET_TYPES[bet.type].name}`);
  }
}
/** Run every scheduled race whose off time has passed. */
export function runDue(t = now()) {
  let n = 0;
  for (const r of q("SELECT * FROM rc_races WHERE kind = 'sched' AND status = 'open' AND off_at <= ? ORDER BY off_at").all(t)) { runRace(r, t); n++; }
  for (const r of q("SELECT * FROM rc_races WHERE status = 'finished' AND settled_at IS NULL AND off_at + duration * 1000 <= ?").all(t)) settleFinished(r, t);
  return n;
}
let ticker = null;
export function startRacing() {
  seedHorses();
  runDue();
  ensureSchedule(now(), 3);
  ticker = setInterval(() => { try { runDue(); ensureSchedule(now(), 1); } catch (e) { console.error('[racing]', e); } }, 4000);
  ticker.unref?.();
}
export function stopRacing() { clearInterval(ticker); }

// ── views ─────────────────────────────────────────────────────────────────────
function phase(r, t) {
  if (r.status === 'open') return r.kind === 'quick' ? 'ready' : t < r.off_at - CLOSE_MS ? 'open' : 'closing';
  return t < r.off_at + (r.duration || 0) * 1000 + 1500 ? 'live' : 'result';
}
/** A race as the player sees it. The run itself is only sent once the race is off. */
export function raceView(r, t = now(), { full = true } = {}) {
  const card = JSON.parse(r.card);
  const ph = phase(r, t);
  const out = {
    id: r.id, kind: r.kind, owner: r.owner_id || null, off: r.off_at, phase: ph, course: card.course, courseName: card.courseName, name: card.name,
    type: card.type, format: card.format, formatName: formatById[card.format]?.name, handicap: card.handicap, distance: card.distance, distanceLabel: card.distanceLabel, furlongs: card.furlongs,
    going: card.going, goingName: card.goingName, field: card.field, terms: card.terms, prize: card.prize, duration: r.duration,
    runners: card.runners.map((x) => ({ ...x, oddsLabel: fracLabel(x.odds), chance: undefined, placeChance: undefined })),
  };
  if (ph === 'live' || ph === 'result') {
    out.result = JSON.parse(r.result);
    if (full) out.trace = JSON.parse(r.trace);
    const fav = [...card.runners].sort((a, b) => a.odds.dec - b.odds.dec)[0];
    out.favourite = fav.no;
  }
  if (!full) delete out.runners;
  return out;
}
const summary = (r, t) => { const v = raceView(r, t, { full: false }); const card = JSON.parse(r.card); v.top = card.runners.slice().sort((a, b) => a.odds.dec - b.odds.dec).slice(0, 3).map((x) => ({ no: x.no, name: x.name, odds: fracLabel(x.odds), silks: x.silks })); if (v.result) v.winner = card.runners.find((x) => x.no === v.result.positions[0].no)?.name; return v; };

export function overview(userId, t = now()) {
  const upcoming = q("SELECT * FROM rc_races WHERE kind = 'sched' AND status = 'open' ORDER BY off_at LIMIT 12").all().map((r) => summary(r, t));
  const recent = q("SELECT * FROM rc_races WHERE kind = 'sched' AND status = 'finished' AND off_at > ? ORDER BY off_at DESC LIMIT 30").all(t - 86400000).map((r) => summary(r, t));
  const live = recent.filter((r) => r.phase === 'live');
  const results = recent.filter((r) => r.phase === 'result').slice(0, 20);
  const day = new Date(t); day.setHours(0, 0, 0, 0);
  const today = q("SELECT * FROM rc_races WHERE kind = 'sched' AND off_at >= ? AND off_at < ? ORDER BY off_at").all(day.getTime(), day.getTime() + 86400000).map((r) => summary(r, t));
  const quick = userId ? q("SELECT * FROM rc_races WHERE kind = 'quick' AND owner_id = ? ORDER BY id DESC LIMIT 5").all(userId).map((r) => summary(r, t)) : [];
  return { now: t, slotMs: SLOT_MS, next: upcoming[0] || null, live, upcoming, results, today, quick, courses: COURSES.map(({ scene, ...c }) => ({ ...c, next: upcoming.find((u) => u.course === c.id)?.off || null })), formats: FORMATS.map((f) => ({ id: f.id, name: f.name, type: f.type, furlongs: f.furlongs, fields: f.fields })) };
}
export function getRace(id, userId, t = now()) {
  const r = q('SELECT * FROM rc_races WHERE id = ?').get(id);
  if (!r || (r.kind === 'quick' && r.owner_id !== userId)) throw new HttpError(404, 'Race not found.');
  const v = raceView(r, t);
  v.myBets = userId ? q('SELECT * FROM rc_bets WHERE race_id = ? AND user_id = ? ORDER BY id').all(id, userId).map(betView) : [];
  if (v.phase === 'live') for (const b of v.myBets) { b.status = 'running'; b.returns = 0; }
  return v;
}
export function listRaces({ status, course, limit = 50 }, t = now()) {
  let rows;
  if (status === 'results') rows = q("SELECT * FROM rc_races WHERE kind = 'sched' AND status = 'finished' ORDER BY off_at DESC LIMIT ?").all(Math.min(200, limit + 10));
  else rows = q("SELECT * FROM rc_races WHERE kind = 'sched' AND status = 'open' ORDER BY off_at LIMIT ?").all(Math.min(200, limit));
  return rows.map((r) => summary(r, t)).filter((r) => (!course || r.course === course) && (status !== 'results' || r.phase === 'result')).slice(0, limit);
}

// ── quick races (run on demand) ───────────────────────────────────────────────
export function createQuick(userId, { format, field, course, going } = {}) {
  if (!formatById[format]) throw new HttpError(400, 'Choose a race type.');
  const fmt = formatById[format];
  if (field != null && !fmt.fields.includes(field)) throw new HttpError(400, `${fmt.name} races have ${fmt.fields.join(', ')} runners.`);
  if (course && !courseById[course]) throw new HttpError(400, 'Choose a racecourse.');
  return tx(() => {
    const open = q("SELECT COUNT(*) AS n FROM rc_races WHERE kind = 'quick' AND owner_id = ? AND status = 'open'").get(userId).n;
    if (open >= 3) throw new HttpError(400, 'Run or finish one of your virtual races first (up to 3 can be waiting).');
    const t = now();
    const busy = busyHorseIds(t);
    const pool = allHorses().filter((h) => !busy.has(h.id));
    const card = makeCard({ pool, rand, courseId: course || COURSES[Math.floor(rand() * COURSES.length)].id, formatId: format, field: field || undefined, going, sims: 500 });
    const r = q('INSERT INTO rc_races (kind, owner_id, course, off_at, status, card, created_at) VALUES (?, ?, ?, NULL, ?, ?, ?)').run('quick', userId, card.course, 'open', JSON.stringify(card), t);
    return getRace(Number(r.lastInsertRowid), userId, t);
  });
}
export function startQuick(userId, id) {
  const r = q("SELECT * FROM rc_races WHERE id = ? AND kind = 'quick'").get(id);
  if (!r || r.owner_id !== userId) throw new HttpError(404, 'Race not found.');
  if (r.status !== 'open') throw new HttpError(400, 'This race has already been run.');
  checkBreak(userId);
  const t = now();
  runRace(r, t);
  settleFinished(q('SELECT * FROM rc_races WHERE id = ?').get(id), t);
  return getRace(id, userId, t);
}

// ── bets ──────────────────────────────────────────────────────────────────────
const betRow = (b) => ({ id: b.id, raceId: b.race_id, type: b.type, picks: JSON.parse(b.picks), stake: b.stake, lines: b.lines, total: b.total, price: JSON.parse(b.price), potential: b.potential, status: b.status, returns: b.returns, at: b.created_at, settledAt: b.settled_at, userId: b.user_id });
function betView(b) {
  const x = betRow(b);
  delete x.userId;
  x.ref = `R${String(x.id).padStart(6, '0')}`;
  x.typeName = BET_TYPES[x.type].name;
  return x;
}

/**
 * Place one or more bets on a race (the slip). `nonce` makes a repeated submission harmless.
 * Each bet: { type, picks: [runner numbers], stake (pence per line), expect? (decimal shown) }.
 */
export function placeBets(userId, { raceId, bets, nonce }) {
  if (typeof nonce !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(nonce)) throw new HttpError(400, 'Bet reference missing. Please try again.');
  if (!Array.isArray(bets) || !bets.length || bets.length > 20) throw new HttpError(400, 'Add between 1 and 20 bets to the slip.');
  return tx(() => {
    const r = q('SELECT * FROM rc_races WHERE id = ?').get(raceId);
    if (!r || (r.kind === 'quick' && r.owner_id !== userId)) throw new HttpError(404, 'Race not found.');
    const t = now();
    if (r.status !== 'open' || (r.kind === 'sched' && t >= r.off_at - CLOSE_MS)) throw new HttpError(400, 'Betting on this race has closed.');
    if (q('SELECT 1 FROM rc_bets WHERE user_id = ? AND nonce = ? LIMIT 1').get(userId, nonce)) throw new HttpError(409, 'These bets have already been placed.');
    const card = JSON.parse(r.card);
    const priced = bets.map((b) => {
      const picks = Array.isArray(b?.picks) ? b.picks.map(Number) : [];
      const stake = b?.stake;
      const err = checkBet(card, { type: b?.type, picks, stake });
      if (err) throw new HttpError(400, err);
      const price = priceBet(card, b.type, picks);
      if (!price) throw new HttpError(400, 'That bet is not available on this race.');
      const lines = BET_TYPES[b.type].lines;
      const bet = { type: b.type, picks, stake, lines, total: stake * lines, price };
      bet.potential = potential(bet);
      return bet;
    });
    const total = priced.reduce((a, b) => a + b.total, 0);
    checkBreak(userId);
    const { limit } = effectiveLimit(userId);
    if (limit !== null && stakedLast24h(userId) + total > limit) throw new HttpError(400, 'This would exceed your daily stake limit.');
    const bal = q('SELECT balance FROM users WHERE id = ?').get(userId).balance;
    if (total > bal) throw new HttpError(400, `Not enough virtual balance: these bets cost ${gbp(total)}.`);
    debit(userId, 'RACING_BET', total, 'racing', `Racing · ${card.name} · ${priced.length} bet${priced.length > 1 ? 's' : ''}`);
    const ids = priced.map((b) => Number(q(`INSERT INTO rc_bets (user_id, race_id, type, picks, stake, lines, total, price, potential, nonce, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(userId, raceId, b.type, JSON.stringify(b.picks), b.stake, b.lines, b.total, JSON.stringify(b.price), b.potential, nonce, t).lastInsertRowid));
    award(userId, [{ t: 'played', game: 'racing' }]);
    return { placed: ids.map((id) => betView(q('SELECT * FROM rc_bets WHERE id = ?').get(id))), total };
  });
}
/** Prices a slip without placing it (the slip shows these odds and potential returns). */
export function quote({ raceId, bets }, userId) {
  const r = q('SELECT * FROM rc_races WHERE id = ?').get(raceId);
  if (!r || (r.kind === 'quick' && r.owner_id !== userId)) throw new HttpError(404, 'Race not found.');
  const card = JSON.parse(r.card);
  return { bets: (Array.isArray(bets) ? bets.slice(0, 20) : []).map((b) => {
    const picks = Array.isArray(b?.picks) ? b.picks.map(Number) : [];
    const err = checkBet(card, { type: b?.type, picks, stake: b?.stake });
    const price = err ? null : priceBet(card, b.type, picks);
    const lines = BET_TYPES[b?.type]?.lines || 1;
    const bet = price ? { type: b.type, picks, stake: b.stake, lines, total: b.stake * lines, price } : null;
    return { error: err || (price ? null : 'Not available'), price, lines, total: bet?.total ?? 0, potential: bet ? potential(bet) : 0 };
  }) };
}
export function myBets(userId, { status = 'all', limit = 100 } = {}) {
  const rows = status === 'open' ? q("SELECT * FROM rc_bets WHERE user_id = ? AND status = 'open' ORDER BY id DESC LIMIT ?").all(userId, limit)
    : status === 'settled' ? q("SELECT * FROM rc_bets WHERE user_id = ? AND status != 'open' ORDER BY id DESC LIMIT ?").all(userId, limit)
      : q('SELECT * FROM rc_bets WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit);
  const races = new Map();
  return rows.map((b) => {
    const v = betView(b);
    if (!races.has(b.race_id)) { const r = q('SELECT * FROM rc_races WHERE id = ?').get(b.race_id); races.set(b.race_id, r && summary(r, now())); }
    const race = races.get(b.race_id);
    const card = race && JSON.parse(q('SELECT card FROM rc_races WHERE id = ?').get(b.race_id).card);
    v.race = race && { id: race.id, name: race.name, courseName: race.courseName, off: race.off, phase: race.phase, kind: race.kind };
    v.names = card ? v.picks.map((no) => card.runners.find((x) => x.no === no)?.name) : [];
    if (race && race.phase === 'live') { v.status = 'running'; v.returns = 0; }
    return v;
  });
}

// ── statistics and leaderboards ───────────────────────────────────────────────
export function myStats(userId) {
  const s = q(`SELECT COUNT(*) AS bets, COALESCE(SUM(total), 0) AS staked, COALESCE(SUM(returns), 0) AS returned, SUM(returns > 0) AS winners, MAX(returns - total) AS best
               FROM rc_bets WHERE user_id = ? AND status != 'open'`).get(userId);
  const open = q("SELECT COUNT(*) AS n, COALESCE(SUM(total), 0) AS t FROM rc_bets WHERE user_id = ? AND status = 'open'").get(userId);
  const favs = new Map();
  for (const b of q('SELECT race_id, picks FROM rc_bets WHERE user_id = ? ORDER BY id DESC LIMIT 500').all(userId)) {
    const card = JSON.parse(q('SELECT card FROM rc_races WHERE id = ?').get(b.race_id).card);
    for (const no of JSON.parse(b.picks)) { const r = card.runners.find((x) => x.no === no); if (r) favs.set(r.horseId, { id: r.horseId, name: r.name, n: (favs.get(r.horseId)?.n || 0) + 1 }); }
  }
  return {
    bets: s.bets, staked: s.staked, returned: s.returned, profit: s.returned - s.staked, winRate: s.bets ? (s.winners || 0) / s.bets : 0, best: s.best && s.best > 0 ? s.best : 0,
    open: open.n, openStake: open.t, favouriteHorses: [...favs.values()].sort((a, b) => b.n - a.n).slice(0, 5), recent: myBets(userId, { limit: 10 }),
  };
}
export function leaderboard(period = 'week', t = now()) {
  const since = period === 'all' ? 0 : t - (period === 'month' ? 30 : 7) * 86400000;
  const rows = q(`SELECT u.username AS name, COUNT(*) AS bets, SUM(b.total) AS staked, SUM(b.returns) AS returned, SUM(b.returns > 0) AS winners, MAX(b.returns - b.total) AS best
                  FROM rc_bets b JOIN users u ON u.id = b.user_id WHERE b.status != 'open' AND b.created_at >= ? GROUP BY b.user_id`).all(since)
    .map((r) => ({ name: r.name, bets: r.bets, profit: r.returned - r.staked, winners: r.winners || 0, winRate: r.bets ? (r.winners || 0) / r.bets : 0, best: Math.max(0, r.best || 0) }));
  const top = (key, filter = () => true) => rows.filter(filter).sort((a, b) => b[key] - a[key]).slice(0, 20);
  return { period, profit: top('profit'), winners: top('winners'), best: top('best', (r) => r.best > 0), winRate: top('winRate', (r) => r.bets >= 10), active: top('bets') };
}

// ── horses, courses, favourites ───────────────────────────────────────────────
export function horseProfile(id, userId) {
  const h = horseRow(q('SELECT * FROM rc_horses WHERE id = ?').get(id));
  if (!h) throw new HttpError(404, 'Horse not found.');
  const runs = q(`SELECT r.race_id, r.no, r.jockey, r.pos, r.time, r.margin, r.odds, r.off_at, x.card, x.kind FROM rc_runs r JOIN rc_races x ON x.id = r.race_id
                  WHERE r.horse_id = ? AND x.kind = 'sched' ORDER BY r.off_at DESC LIMIT 25`).all(id).map((r) => {
    const c = JSON.parse(r.card);
    return { raceId: r.race_id, race: c.name, course: c.courseName, distance: c.distanceLabel, going: c.goingName, field: c.field, pos: r.pos, margin: r.margin, odds: r.odds, jockey: r.jockey, time: r.time, off: r.off_at };
  }).filter((r) => r.off + 60000 < now());
  const jockeys = [...runs.reduce((m, r) => m.set(r.jockey, (m.get(r.jockey) || 0) + 1), new Map())].map(([name, n]) => ({ name, n }));
  const next = q("SELECT * FROM rc_races WHERE status = 'open' AND kind = 'sched' ORDER BY off_at").all().find((r) => JSON.parse(r.card).runners.some((x) => x.horseId === id));
  const fav = userId ? !!q("SELECT 1 FROM rc_favs WHERE user_id = ? AND kind = 'horse' AND ref = ?").get(userId, String(id)) : false;
  return { ...h, rating: composite(h), runsList: runs, jockeys, next: next ? summary(next, now()) : null, favourite: fav };
}
export function searchHorses(qs = '', limit = 30) {
  const s = `%${String(qs).slice(0, 40).replace(/[%_]/g, '')}%`;
  return q('SELECT * FROM rc_horses WHERE name LIKE ? ORDER BY wins DESC, name LIMIT ?').all(s, limit).map(horseRow).map((h) => ({ id: h.id, name: h.name, age: h.age, sex: h.sex, coat: h.coat, trainer: h.trainer, form: h.form, runs: h.runs, wins: h.wins, places: h.places, rating: composite(h), silks: h.silks }));
}
export function favourites(userId) {
  const rows = q('SELECT kind, ref FROM rc_favs WHERE user_id = ?').all(userId);
  return { horses: rows.filter((r) => r.kind === 'horse').map((r) => Number(r.ref)), courses: rows.filter((r) => r.kind === 'course').map((r) => r.ref) };
}
export function setFavourite(userId, { kind, ref, on }) {
  if (kind === 'horse') { if (!q('SELECT 1 FROM rc_horses WHERE id = ?').get(Number(ref))) throw new HttpError(404, 'Horse not found.'); }
  else if (kind === 'course') { if (!courseById[ref]) throw new HttpError(404, 'Racecourse not found.'); }
  else throw new HttpError(400, 'Unknown favourite.');
  if (on) q('INSERT OR IGNORE INTO rc_favs (user_id, kind, ref) VALUES (?, ?, ?)').run(userId, kind, String(ref));
  else q('DELETE FROM rc_favs WHERE user_id = ? AND kind = ? AND ref = ?').run(userId, kind, String(ref));
  return favourites(userId);
}
export function courseView(id) {
  const c = courseById[id];
  if (!c) throw new HttpError(404, 'Racecourse not found.');
  const t = now();
  const upcoming = q("SELECT * FROM rc_races WHERE kind = 'sched' AND course = ? AND status = 'open' ORDER BY off_at LIMIT 6").all(id).map((r) => summary(r, t));
  const results = q("SELECT * FROM rc_races WHERE kind = 'sched' AND course = ? AND status = 'finished' ORDER BY off_at DESC LIMIT 12").all(id).map((r) => summary(r, t)).filter((r) => r.phase === 'result');
  const runs = q("SELECT COUNT(*) AS n FROM rc_races WHERE kind = 'sched' AND course = ? AND status = 'finished'").get(id).n;
  const { scene, ...pub } = c;
  return { ...pub, scene, upcoming, results, races: runs };
}

// ── authorised live streams (none are configured by default) ──────────────────
/**
 * RACING_STREAMS: a JSON list of streams you are licensed to show, e.g.
 * [{"name":"Course TV","course":"Example Park","type":"hls","url":"https://…/index.m3u8"}]
 * Only https URLs are accepted. With none set, the site shows no live video and offers virtual racing.
 */
export function streams() {
  let list = [];
  try { list = JSON.parse(process.env.RACING_STREAMS || '[]'); } catch { list = []; }
  return (Array.isArray(list) ? list : []).filter((s) => s && typeof s.url === 'string' && /^https:\/\//.test(s.url) && ['hls', 'iframe', 'mp4'].includes(s.type))
    .slice(0, 10).map((s, i) => ({ id: i + 1, name: String(s.name || 'Live racing').slice(0, 60), course: String(s.course || '').slice(0, 60), type: s.type, url: s.url, qualities: Array.isArray(s.qualities) ? s.qualities.slice(0, 6) : null }));
}
