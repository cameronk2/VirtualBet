// Virtual horse racing – the pure engine, shared by the server and the in-browser build:
// race cards, the race simulation, odds, bet pricing and settlement. No database access here.
//
// A race is simulated step by step: each horse accelerates from the stalls, settles at a pace set by
// its speed rating, the going, its weight and its running style, tires according to its stamina and
// the distance, finds a finishing kick, and varies a little all the way (temperament). The finishing
// order comes from the moment each horse crosses the line. The same run (the "trace") drives the 3D
// animation, the result, the replay and bet settlement, so they always agree.
import { FORMATS, FURLONG, GOINGS, JOCKEYS, courseById, formatById, goingById, placeTerms, distanceLabel } from './data.js';

export const DT = 0.15;          // seconds per simulation step
export const TRACE_EVERY = 0.5;  // seconds between recorded positions
export const LENGTH_M = 2.4;     // one length, in metres
export const MIN_STAKE = 10, MAX_STAKE = 100000; // pence per line (10p – £1,000)

const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
function gauss(rand) { let u = 0, v = 0; while (u === 0) u = rand(); while (v === 0) v = rand(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }

/** Fast generator for the odds simulations, seeded with 128 bits from the secure RNG. */
export function sfc32(a, b, c, d) {
  return () => { a >>>= 0; b >>>= 0; c >>>= 0; d >>>= 0; const t = (a + b | 0) + d | 0; d = d + 1 | 0; a = b ^ b >>> 9; b = c + (c << 3) | 0; c = c << 21 | c >>> 11; c = c + t | 0; return (t >>> 0) / 4294967296; };
}
export const fastRand = (rand) => { const s = () => Math.floor(rand() * 4294967296); const r = sfc32(s(), s(), s(), s()); for (let i = 0; i < 12; i++) r(); return r; };

/** One overall rating for a horse (shown as its "rating" on the card). */
export const composite = (h) => Math.round(0.4 * h.ratings.speed + 0.2 * h.ratings.accel + 0.2 * h.ratings.finish + 0.2 * h.ratings.stamina);

// ── odds ──────────────────────────────────────────────────────────────────────
// The bookmaker ladder of fractional prices.
export const LADDER = [[1, 10], [1, 8], [1, 6], [1, 5], [2, 9], [1, 4], [2, 7], [3, 10], [1, 3], [4, 11], [2, 5], [4, 9], [1, 2], [8, 15], [4, 7], [8, 13], [4, 6], [8, 11], [4, 5], [5, 6], [10, 11], [1, 1],
  [11, 10], [6, 5], [5, 4], [11, 8], [6, 4], [13, 8], [7, 4], [15, 8], [2, 1], [9, 4], [5, 2], [11, 4], [3, 1], [10, 3], [7, 2], [4, 1], [9, 2], [5, 1], [11, 2], [6, 1], [13, 2], [7, 1], [15, 2], [8, 1], [17, 2], [9, 1],
  [10, 1], [11, 1], [12, 1], [14, 1], [16, 1], [18, 1], [20, 1], [22, 1], [25, 1], [28, 1], [33, 1], [40, 1], [50, 1], [66, 1], [80, 1], [100, 1], [125, 1], [150, 1], [200, 1], [250, 1], [300, 1], [500, 1]];
/** The biggest ladder price not above `dec` (a bookmaker rounds in its own favour). */
export function toFraction(dec) {
  let best = LADDER[0];
  for (const f of LADDER) if (1 + f[0] / f[1] <= dec + 1e-9) best = f;
  return { num: best[0], den: best[1], dec: Math.round((1 + best[0] / best[1]) * 100) / 100 };
}
export const fracLabel = ({ num, den }) => (num === den ? 'Evs' : `${num}/${den}`);
/** Decimal → a fraction for display of exotic prices (whole numbers above 10/1). */
export function exoticFraction(dec) { const x = dec - 1; return x >= 10 ? { num: Math.round(x), den: 1, dec } : toFraction(dec); }

// ── race cards ────────────────────────────────────────────────────────────────
const GOING_W = [['firm', 6], ['gf', 22], ['good', 34], ['gs', 22], ['soft', 11], ['heavy', 5]];
function pickW(list, rand) { const t = list.reduce((a, x) => a + x[1], 0); let r = rand() * t; for (const x of list) if ((r -= x[1]) <= 0) return x[0]; return list[list.length - 1][0]; }

/**
 * Builds a race card. `pool` is the horses that may run (already excluding horses running elsewhere
 * soon); `rand` is the secure RNG. Odds come from simulating this exact field many times.
 */
export function makeCard({ pool, rand, courseId, formatId, field, going, furlongs, off = null, sims = 900 }) {
  const course = courseById[courseId] || courseById.ashcombe;
  const fmt = formatById[formatId] || FORMATS[0];
  const f = furlongs || fmt.furlongs[Math.floor(rand() * fmt.furlongs.length)];
  const n = Math.min(field || fmt.fields[Math.floor(rand() * fmt.fields.length)], pool.length);
  const g = going || pickW(GOING_W, rand);
  // championship races take the best horses on offer; others a fair mix
  // a field of similar class: horses within a few points of a randomly chosen class level
  const ranked = [...pool].sort((a, b) => composite(b) - composite(a));
  const top = fmt.elite ? ranked.slice(0, Math.max(n * 2, Math.ceil(ranked.length * 0.3))) : ranked;
  const anchor = composite(top[Math.floor(rand() * top.length)]);
  let band = 5, candidates = [];
  while (candidates.length < n * 1.5 && band < 60) { candidates = top.filter((h) => Math.abs(composite(h) - anchor) <= band); band += 2; }
  const chosen = [];
  const bag = [...candidates];
  while (chosen.length < n && bag.length) chosen.push(bag.splice(Math.floor(rand() * bag.length), 1)[0]);
  const meanQ = chosen.reduce((a, h) => a + composite(h), 0) / chosen.length;
  const jockeys = [...JOCKEYS];
  const draws = Array.from({ length: n }, (_, i) => i + 1); for (let i = n - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [draws[i], draws[j]] = [draws[j], draws[i]]; }
  const runners = chosen.map((h, i) => {
    const q = composite(h);
    let weight = fmt.handicap ? Math.round(clamp(126 + (q - meanQ) * 1.1, 112, 140)) : 126 - (['f', 'm'].includes(h.sex) ? 3 : 0) + (fmt.elite ? 0 : 0);
    if (h.age === 3 && !fmt.handicap) weight -= 4;
    return { no: i + 1, horseId: h.id, name: h.name, draw: draws[i], jockey: jockeys.splice(Math.floor(rand() * jockeys.length), 1)[0], trainer: h.trainer, age: h.age, sex: h.sex, weight, rating: q, silks: h.silks, coat: h.coat, form: h.form || '' };
  });
  const card = {
    course: course.id, courseName: course.name, format: fmt.id, type: fmt.type, handicap: fmt.handicap, furlongs: f, distance: Math.round(f * FURLONG), distanceLabel: distanceLabel(f),
    going: g, goingName: goingById[g].name, field: n, terms: placeTerms(n, fmt.handicap), off,
    name: `${fmt.elite ? 'The ' : ''}${course.name.split(' ')[0]} ${fmt.title[Math.floor(rand() * fmt.title.length)]}${fmt.elite ? '' : fmt.handicap ? ` (Class ${2 + Math.floor(rand() * 4)})` : ''}`,
    prize: fmt.elite ? 250000 + Math.floor(rand() * 10) * 25000 : fmt.handicap ? 15000 + Math.floor(rand() * 20) * 1000 : 25000 + Math.floor(rand() * 30) * 1000, // fictional, whole pounds
    runners,
  };
  priceCard(card, chosen, fastRand(rand), sims);
  return card;
}

/** Simulates the field `sims` times to find each horse's chance, then prices win, place and exotics. */
export function priceCard(card, horses, rand, sims = 900) {
  const n = card.runners.length;
  const wins = new Array(n).fill(0.5), placed = new Array(n).fill(0.5);
  const places = card.terms?.places || 3;
  for (let s = 0; s < sims; s++) {
    const r = simulate(card, horses, rand, { trace: false });
    wins[r.order[0]]++;
    for (let k = 0; k < places; k++) placed[r.order[k]]++;
  }
  const tw = wins.reduce((a, x) => a + x, 0);
  const p = wins.map((w) => w / tw);
  // a book of about 112–125%; each price is also kept low enough that an each-way bet on the horse
  // (at the race's place terms) returns no more than about 95%
  const book = 1.09 + 0.004 * n;
  const f = card.terms ? card.terms.fraction[0] / card.terms.fraction[1] : 0;
  card.runners.forEach((r, i) => {
    const pw = p[i], pp = placed[i] / (sims + n * 0.5);
    let dec = 1 / (pw * book);
    if (card.terms) dec = Math.min(dec, (1.9 - pp * (1 - f)) / (pw + pp * f));
    r.chance = Math.round(pw * 10000) / 10000;
    r.placeChance = Math.round(pp * 10000) / 10000;
    r.odds = toFraction(Math.max(1.1, dec));
  });
  card.priced = { sims, book };
  return card;
}

// ── the race ──────────────────────────────────────────────────────────────────
const STYLE_PACE = { 'Front-runner': [0.006, -0.004], Prominent: [0.003, 0], Midfield: [0, 0.002], 'Hold-up': [-0.005, 0.006] };
const GOING_INDEX = Object.fromEntries(GOINGS.map((g, i) => [g.id, i]));

/** Per-runner constants for one running of the race (includes this run's form on the day). */
function setup(card, horses, rand) {
  const byId = new Map(horses.map((h) => [h.id, h]));
  const going = goingById[card.going] || goingById.good;
  return card.runners.map((r) => {
    const h = byId.get(r.horseId);
    const R = h.ratings;
    const temper = R.temperament / 100;
    const goingFit = h.goingPref === card.going ? 1.004 : Math.abs(GOING_INDEX[h.goingPref] - GOING_INDEX[card.going]) >= 2 ? 0.995 : 1;
    const form = 1 + gauss(rand) * 0.008 * (1.45 - temper);
    const weight = 1 - (r.weight - 126) * 0.0006;
    const drawFit = card.field > 10 && courseById[card.course]?.features?.includes('Draw bias') ? 1 + (card.field / 2 - r.draw) * 0.0006 : 1;
    const cruise = 16.2 * (1 + (R.speed - 70) * 0.0007) * going.speed * goingFit * form * weight * drawFit;
    const reserve = 900 + R.stamina * 24 * (h.style === 'Front-runner' ? 0.97 : 1) * (1 + (going.speed - 1) * 2);
    return {
      cruise, reserve, pace: STYLE_PACE[h.style] || [0, 0], kick: (R.finish - 70) * 0.0004,
      tau: clamp(2.2 - (R.accel - 70) * 0.025, 1.3, 3.2), delay: 0.05 + rand() * 0.35 * (1.1 - temper),
      sd: 0.009 * (1.3 - temper), x: 0, v: 0, n: 0, t: null, vf: 0,
    };
  });
}

/**
 * Runs the race. Returns the finishing order (runner indexes), each runner's time, speed at the line,
 * and (with trace) positions every TRACE_EVERY seconds until everyone has pulled up.
 */
export function simulate(card, horses, rand, { trace = true } = {}) {
  const D = card.distance;
  const st = setup(card, horses, rand);
  const n = st.length;
  const frames = [];
  let t = 0, finished = 0, nextRec = 0, after = 0;
  const sq = Math.sqrt(DT);
  while (true) {
    for (const s of st) {
      if (t < s.delay) continue;
      const fx = s.x / D;
      let f = 1;
      if (fx < 0.55) f += s.pace[0]; else if (fx > 0.75) f += s.pace[1];
      const tire = clamp((s.x - 0.6 * s.reserve) / (0.8 * s.reserve), 0, 1);
      f -= 0.03 * tire ** 1.3;
      if (s.x > D - 320) f += s.kick * clamp((s.x - (D - 320)) / 160, 0, 1);
      s.n += (-s.n / 1.5) * DT + s.sd * sq * gauss(rand);
      let target = s.cruise * f * (1 + s.n);
      if (s.t !== null) target = Math.max(4, s.v * (1 - 0.35 * DT)); // pulling up after the line
      s.v += (target - s.v) * Math.min(1, DT / s.tau);
      const x0 = s.x;
      s.x += s.v * DT;
      if (s.t === null && s.x >= D) { s.t = t + ((D - x0) / (s.x - x0)) * DT; s.vf = s.v; finished++; }
    }
    t += DT;
    if (trace && t >= nextRec - 1e-9) { frames.push(st.map((s) => Math.round(s.x * 10) / 10)); nextRec += TRACE_EVERY; }
    if (finished === n) { after += DT; if (!trace || after > 4) break; }
    if (t > 600) break; // safety
  }
  const order = st.map((s, i) => i).sort((a, b) => st[a].t - st[b].t);
  return { order, times: st.map((s) => Math.round(s.t * 1000) / 1000), vf: st.map((s) => s.vf), trace: trace ? { every: TRACE_EVERY, frames } : null };
}

/** "nose", "shd", "hd", "nk", "½", "1¼", "dist"… for a gap in lengths. */
export function marginLabel(l) {
  if (l < 0.04) return 'nse';
  if (l < 0.12) return 'shd';
  if (l < 0.22) return 'hd';
  if (l < 0.32) return 'nk';
  if (l >= 30) return 'dist';
  const q = l < 3 ? Math.round(l * 4) / 4 : l < 10 ? Math.round(l * 2) / 2 : Math.round(l);
  const whole = Math.floor(q), frac = q - whole;
  const fs = frac === 0.25 ? '¼' : frac === 0.5 ? '½' : frac === 0.75 ? '¾' : '';
  return `${whole || ''}${fs}` || '¼';
}

/** The official result from a simulation: positions, times, distances and any dead heats. */
export function resultOf(card, sim) {
  const rows = sim.order.map((idx, k) => {
    const prev = k ? sim.order[k - 1] : null;
    const gap = prev === null ? 0 : (sim.times[idx] - sim.times[prev]) * sim.vf[idx] / LENGTH_M;
    return { no: card.runners[idx].no, idx, time: sim.times[idx], gap: Math.max(0, gap) };
  });
  // dead heat when two horses cross the line within a thousandth of a second
  let pos = 1;
  rows.forEach((r, k) => { if (k && Math.abs(r.time - rows[k - 1].time) < 0.001) r.pos = rows[k - 1].pos; else r.pos = pos; pos++; });
  rows.forEach((r, k) => { r.margin = k ? marginLabel(r.gap) : null; r.behind = k ? Math.round(rows.slice(1, k + 1).reduce((a, x) => a + x.gap, 0) * 100) / 100 : 0; });
  const photo = rows.length > 1 && rows[1].gap < 0.12;
  return { positions: rows.map(({ no, pos, time, margin, behind }) => ({ no, pos, time, margin, behind })), winTime: rows[0].time, photo };
}
export const timeLabel = (s) => `${Math.floor(s / 60)}m ${(s % 60).toFixed(2)}s`;

// ── bets ─────────────────────────────────────────────────────────────────────
export const BET_TYPES = {
  win: { name: 'Win', picks: 1, lines: 1 },
  each_way: { name: 'Each Way', picks: 1, lines: 2 },
  place: { name: 'Place', picks: 1, lines: 1 },
  forecast: { name: 'Forecast', picks: 2, lines: 1, ordered: true },
  reverse_forecast: { name: 'Reverse Forecast', picks: 2, lines: 2 },
  tricast: { name: 'Tricast', picks: 3, lines: 1, ordered: true },
  trio: { name: 'Trio', picks: 3, lines: 1 },
};

// The chance of an exact finishing order from the win chances. Plain Harville over-rates favourites
// for the minor places, so 2nd and 3rd use discounted chances (Lo & Bacon-Shone: p^0.81, p^0.65).
const LAMBDA = [1, 0.81, 0.65];
function harville(p, seq) {
  let pr = 1; const used = new Set();
  seq.forEach((i, k) => {
    const l = LAMBDA[k] ?? 0.6;
    let den = 0; for (let j = 0; j < p.length; j++) if (!used.has(j)) den += Math.max(p[j], 1e-6) ** l;
    pr *= Math.max(p[i], 1e-6) ** l / den; used.add(i);
  });
  return pr;
}
const EXOTIC_MARGIN = { forecast: 0.85, tricast: 1.08, trio: 0.78 }; // set so each returns about 80–85% (scripts/sim-racing.mjs)
const round05 = (x) => Math.min(10001, Math.max(1.5, Math.floor(x * 20) / 20)); // exotic prices are capped at 10,000/1

/** The price a bet would be struck at now (stored on the bet and never changed). */
export function priceBet(card, type, picks) {
  const T = BET_TYPES[type];
  if (!T) return null;
  const idx = picks.map((no) => card.runners.findIndex((r) => r.no === no));
  const p = card.runners.map((r) => r.chance);
  if (type === 'win') return { win: card.runners[idx[0]].odds };
  if (type === 'place' || type === 'each_way') {
    if (!card.terms) return null;
    const w = card.runners[idx[0]].odds, [fn, fd] = card.terms.fraction;
    const placeDec = Math.round((1 + (w.num / w.den) * (fn / fd)) * 10000) / 10000;
    if (type === 'each_way') return { win: w, place: { dec: placeDec, places: card.terms.places, fraction: card.terms.fraction, from: w } };
    // a place-only bet is priced on the horse's own chance of placing (from the same simulations)
    const pc = card.runners[idx[0]].placeChance;
    const dec = pc ? Math.max(1.05, Math.min(placeDec * 1.5, Math.floor((0.86 / pc) * 20) / 20)) : placeDec;
    return { place: { dec, places: card.terms.places } };
  }
  if (type === 'forecast') { const d = round05(EXOTIC_MARGIN.forecast / harville(p, idx)); return { lines: [{ order: picks, dec: d }] }; }
  if (type === 'reverse_forecast') {
    const a = [picks[0], picks[1]], b = [picks[1], picks[0]];
    return { lines: [a, b].map((o) => ({ order: o, dec: round05(EXOTIC_MARGIN.forecast / harville(p, o.map((no) => card.runners.findIndex((r) => r.no === no)))) })) };
  }
  if (type === 'tricast') return { lines: [{ order: picks, dec: round05(EXOTIC_MARGIN.tricast / harville(p, idx)) }] };
  if (type === 'trio') {
    const perms = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]].map((o) => o.map((k) => idx[k]));
    const pr = perms.reduce((a, o) => a + harville(p, o), 0);
    return { lines: [{ set: picks, dec: round05(EXOTIC_MARGIN.trio / pr) }] };
  }
  return null;
}

/** Validates a bet against a card. Returns an error message or null. */
export function checkBet(card, { type, picks, stake }) {
  const T = BET_TYPES[type];
  if (!T) return 'Choose a bet type.';
  if (!Array.isArray(picks) || picks.length !== T.picks) return `${T.name} needs ${T.picks} selection${T.picks > 1 ? 's' : ''}.`;
  if (new Set(picks).size !== picks.length) return 'Choose different horses for each position.';
  if (picks.some((no) => !card.runners.some((r) => r.no === no))) return 'That horse is not in this race.';
  if ((type === 'each_way' || type === 'place') && !card.terms) return 'Each way and place bets need at least 5 runners.';
  if (type === 'tricast' || type === 'trio') { if (card.field < 6) return 'Tricast and trio need at least 6 runners.'; }
  if (!Number.isSafeInteger(stake) || stake < MIN_STAKE) return `The minimum stake is £${(MIN_STAKE / 100).toFixed(2)} per line.`;
  if (stake > MAX_STAKE) return `The maximum stake is £${(MAX_STAKE / 100).toFixed(2)} per line.`;
  return null;
}

/** Potential return if every line of the bet wins (shown on the slip). */
export function potential(bet) {
  const s = bet.stake, p = bet.price;
  switch (bet.type) {
    case 'win': return Math.floor(s * p.win.dec);
    case 'place': return Math.floor(s * p.place.dec);
    case 'each_way': return Math.floor(s * p.win.dec) + Math.floor(s * p.place.dec);
    case 'reverse_forecast': return Math.max(...p.lines.map((l) => Math.floor(s * l.dec)));
    default: return Math.floor(s * p.lines[0].dec);
  }
}

/**
 * What a settled bet returns, given the official result. Dead heats: the stake on a dead-heated
 * win or place is split by the number of horses sharing the paying places (UK rules). Exotics are
 * settled on the official order.
 */
export function settle(bet, result) {
  const s = bet.stake, p = bet.price;
  const pos = new Map(result.positions.map((r) => [r.no, r.pos]));
  const order = result.positions.map((r) => r.no);
  const share = (no, paying) => {
    const at = pos.get(no); if (at == null || at > paying) return 0;
    const tied = result.positions.filter((r) => r.pos === at).length;
    if (tied === 1) return 1;
    return Math.min(tied, paying - at + 1) / tied;
  };
  const a = bet.picks[0];
  switch (bet.type) {
    case 'win': return Math.floor(s * p.win.dec * share(a, 1));
    case 'place': return Math.floor(s * p.place.dec * share(a, p.place.places));
    case 'each_way': return Math.floor(s * p.win.dec * share(a, 1)) + Math.floor(s * p.place.dec * share(a, p.place.places));
    case 'forecast': return order[0] === bet.picks[0] && order[1] === bet.picks[1] ? Math.floor(s * p.lines[0].dec) : 0;
    case 'reverse_forecast': return p.lines.reduce((t, l) => t + (order[0] === l.order[0] && order[1] === l.order[1] ? Math.floor(s * l.dec) : 0), 0);
    case 'tricast': return order.slice(0, 3).every((no, k) => no === bet.picks[k]) ? Math.floor(s * p.lines[0].dec) : 0;
    case 'trio': return bet.picks.every((no) => order.slice(0, 3).includes(no)) ? Math.floor(s * p.lines[0].dec) : 0;
    default: return 0;
  }
}
/** Did a settled bet win anything (for "won / placed / lost" labels)? */
export function outcome(bet, result, ret) {
  if (ret <= 0) return 'lost';
  if (bet.type === 'each_way') { const p1 = result.positions.find((r) => r.no === bet.picks[0])?.pos; return p1 === 1 ? 'won' : 'placed'; }
  return bet.type === 'place' ? 'placed' : 'won';
}
