// Builds the standalone single-file version (runs entirely in the browser,
// e.g. inside the Claude app on a phone). Output: dist-standalone/virtualbet.html
// React is loaded from cdnjs; everything else is inlined.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import * as esbuild from 'esbuild';
import { compile } from 'tailwindcss';

const require = createRequire(import.meta.url);
const ROOT = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
const SRC = path.join(ROOT, 'client');
const OUT = path.join(ROOT, 'dist-standalone');
const TW_DIR = path.dirname(require.resolve('tailwindcss/package.json'));

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (/\.(jsx?|html)$/.test(e.name)) out.push(p);
  }
  return out;
}

async function buildCss() {
  const compiler = await compile(fs.readFileSync(path.join(SRC, 'src', 'styles.css'), 'utf8'), {
    base: path.join(SRC, 'src'),
    async loadStylesheet(id, base) {
      let file = id === 'tailwindcss' ? path.join(TW_DIR, 'index.css') : path.resolve(base, id);
      if (!path.extname(file)) file += '.css';
      return { path: file, base: path.dirname(file), content: fs.readFileSync(file, 'utf8') };
    },
  });
  const candidates = new Set();
  for (const f of [...walk(SRC), ...walk(path.join(ROOT, 'server', 'games'))]) for (const tok of fs.readFileSync(f, 'utf8').split(/[\s"'`{}<>;=]+/)) if (tok && tok.length < 120) candidates.add(tok);
  return (await esbuild.transform(compiler.build([...candidates]), { loader: 'css', minify: true })).code;
}

const standalonePlugin = {
  name: 'standalone',
  setup(build) {
    // Swap the HTTP API client for the in-browser backend
    const httpApi = path.join(SRC, 'src', 'lib', 'api.js');
    build.onResolve({ filter: /api\.js$/ }, (a) => (path.resolve(a.resolveDir, a.path) === httpApi ? { path: path.join(SRC, 'local', 'api.js') } : undefined));
    // React comes from the cdnjs UMD globals
    build.onResolve({ filter: /^react(-dom)?(\/.*)?$/ }, (a) => ({ path: a.path, namespace: 'react-global' }));
    build.onLoad({ filter: /.*/, namespace: 'react-global' }, (a) => {
      if (a.path === 'react/jsx-runtime') {
        return {
          contents: `const R = window.React; export const Fragment = R.Fragment;
            export function jsx(type, props, key) { return R.createElement(type, key === undefined ? props : { ...props, key }); }
            export const jsxs = jsx;`,
          loader: 'js',
        };
      }
      return { contents: `module.exports = ${a.path.startsWith('react-dom') ? 'window.ReactDOM' : 'window.React'};`, loader: 'js' };
    });
  },
};

const js = await esbuild.build({
  entryPoints: [path.join(SRC, 'src', 'main.jsx')],
  bundle: true, minify: !process.env.DEBUG, format: 'iife', target: ['es2020'], jsx: 'automatic',
  define: { 'process.env.NODE_ENV': '"production"', __AUDIO__: JSON.stringify({ base: 'audio/', files: fs.existsSync(path.join(SRC, 'audio')) ? fs.readdirSync(path.join(SRC, 'audio'), { recursive: true }).filter((f) => /\.(mp3|m4a|ogg)$/.test(f)).map((f) => f.split(path.sep).join('/')) : [] }) },
  loader: { '.webp': 'dataurl', '.jpg': 'dataurl', '.png': 'dataurl' }, plugins: [standalonePlugin], write: false, logLevel: 'error',
});
const css = await buildCss();
const code = js.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');

const html = `<title>VirtualBet</title>
<meta name="claude:viewport-fit-sides" content="cover">
<meta name="theme-color" content="#0b1520">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800&family=Barlow+Condensed:ital,wght@0,600;0,700;0,800;1,800&family=Lilita+One&family=Rye&family=Cinzel:wght@700;800&display=swap">
<style>${css}</style>
<div id="root"><div style="padding:48px 16px;text-align:center;color:#94a3b8;font:14px system-ui,sans-serif">Loading VirtualBet…</div></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
<script>window.__VB_STANDALONE__ = true;</script>
<script>${code}</script>
`;
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'virtualbet.html'), html);
console.log(`[build-artifact] dist-standalone/virtualbet.html (${(html.length / 1024).toFixed(0)}kB)`);
