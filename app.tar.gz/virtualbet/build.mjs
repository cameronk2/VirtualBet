// Frontend build: esbuild (React/JSX) + Tailwind CSS v4 compiler.
// Usage: node build.mjs [--watch]
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import * as esbuild from 'esbuild';
import { compile } from 'tailwindcss';

const require = createRequire(import.meta.url);
const ROOT = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
const SRC = path.join(ROOT, 'client');
const DIST = path.join(ROOT, 'dist');
const watch = process.argv.includes('--watch');
const TW_DIR = path.dirname(require.resolve('tailwindcss/package.json'));

/** Music files under client/audio (e.g. genie/base.mp3), shipped beside the app. */
function audioFiles() {
  const dir = path.join(SRC, 'audio');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { recursive: true }).filter((f) => /\.(mp3|m4a|ogg)$/.test(f)).map((f) => f.split(path.sep).join('/'));
}

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (/\.(jsx?|html)$/.test(e.name)) out.push(p);
  }
  return out;
}

async function buildCss() {
  const input = fs.readFileSync(path.join(SRC, 'src', 'styles.css'), 'utf8');
  const compiler = await compile(input, {
    base: path.join(SRC, 'src'),
    async loadStylesheet(id, base) {
      let file;
      if (id === 'tailwindcss') file = path.join(TW_DIR, 'index.css');
      else if (id.startsWith('tailwindcss/')) file = path.join(TW_DIR, id.slice('tailwindcss/'.length));
      else file = path.resolve(base, id);
      if (!path.extname(file)) file += '.css';
      return { path: file, base: path.dirname(file), content: fs.readFileSync(file, 'utf8') };
    },
  });
  // Collect candidate class names from all source files
  const candidates = new Set();
  for (const f of [...walk(SRC), ...walk(path.join(ROOT, 'server', 'games'))]) {
    for (const tok of fs.readFileSync(f, 'utf8').split(/[\s"'`{}<>;=]+/)) {
      if (tok && tok.length < 120) candidates.add(tok);
    }
  }
  let css = compiler.build([...candidates]);
  const result = await esbuild.transform(css, { loader: 'css', minify: !watch });
  return result.code;
}

const hash = (s) => crypto.createHash('sha1').update(s).digest('hex').slice(0, 10);

async function buildAll() {
  const t0 = Date.now();
  const js = await esbuild.build({
    entryPoints: [path.join(SRC, 'src', 'main.jsx')],
    bundle: true,
    minify: !watch,
    sourcemap: watch ? 'inline' : false,
    format: 'esm',
    target: ['es2020'],
    jsx: 'automatic',
    loader: { '.js': 'jsx', '.webp': 'dataurl', '.jpg': 'dataurl', '.png': 'dataurl' },
    define: { 'process.env.NODE_ENV': watch ? '"development"' : '"production"', __AUDIO__: JSON.stringify({ base: '/audio/', files: audioFiles() }), __PWA__: 'true' },
    write: false,
    logLevel: 'error',
  });
  const jsCode = js.outputFiles[0].text;
  const cssCode = await buildCss();
  fs.rmSync(DIST, { recursive: true, force: true });
  fs.mkdirSync(path.join(DIST, 'assets'), { recursive: true });
  const jsName = `assets/app-${hash(jsCode)}.js`;
  const cssName = `assets/app-${hash(cssCode)}.css`;
  fs.writeFileSync(path.join(DIST, jsName), jsCode);
  fs.writeFileSync(path.join(DIST, cssName), cssCode);
  const html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8')
    .replace('<!--CSS-->', `<link rel="stylesheet" href="/${cssName}">`)
    .replace('<!--JS-->', `<script type="module" src="/${jsName}"></script>`);
  fs.writeFileSync(path.join(DIST, 'index.html'), html);
  fs.copyFileSync(path.join(SRC, 'favicon.svg'), path.join(DIST, 'favicon.svg'));
  // Installable-app files: manifest and service worker at the root, icons under /pwa/
  fs.cpSync(path.join(SRC, 'pwa'), path.join(DIST, 'pwa'), { recursive: true });
  for (const f of ['manifest.webmanifest', 'sw.js']) fs.renameSync(path.join(DIST, 'pwa', f), path.join(DIST, f));
  if (fs.existsSync(path.join(SRC, 'audio'))) fs.cpSync(path.join(SRC, 'audio'), path.join(DIST, 'audio'), { recursive: true });
  console.log(`[build] dist/ ready in ${Date.now() - t0}ms (js ${(jsCode.length / 1024).toFixed(0)}kB, css ${(cssCode.length / 1024).toFixed(0)}kB)`);
}

try {
  await buildAll();
} catch (e) {
  console.error('[build] failed:', e.message);
  if (!watch) process.exit(1);
}
if (watch) {
  let timer;
  fs.watch(SRC, { recursive: true }, () => {
    clearTimeout(timer);
    timer = setTimeout(() => buildAll().catch((e) => console.error('[build] failed:', e.message)), 150);
  });
  console.log('[build] watching client/ for changes…');
}
