// Frontend build: esbuild (React/JSX) + Tailwind CSS v4 compiler.
// Usage: node build.mjs [--watch]
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import * as esbuild from 'esbuild';
import { compile } from 'tailwindcss';

const require = createRequire(import.meta.url);
const ROOT = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
const SRC = path.join(ROOT, 'client');
const DIST = path.join(ROOT, 'dist');
const watch = process.argv.includes('--watch');
const TW_DIR = path.dirname(require.resolve('tailwindcss/package.json'));

/** Music files under client/audio (e.g. genie/base.mp3), shipped beside the app. */
function audioFiles() {
  const dir = path.join(SRC, 'audio');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { recursive: true }).filter((f) => /\.(mp3|m4a|ogg)$/.test(f)).map((f) => f.split(path.sep).join('/'));
}

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (/\.(jsx?|html)$/.test(e.name)) out.push(p);
  }
  return out;
}

async function buildCss() {
  const input = fs.readFileSync(path.join(SRC, 'src', 'styles.css'), 'utf8');
  const compiler = await compile(input, {
    base: path.join(SRC, 'src'),
    async loadStylesheet(id, base) {
      let file;
      if (id === 'tailwindcss') file = path.join(TW_DIR, 'index.css');
      else if (id.startsWith('tailwindcss/')) file = path.join(TW_DIR, id.slice('tailwindcss/'.length));
      else file = path.resolve(base, id);
      if (!path.extname(file)) file += '.css';
      return { path: file, base: path.dirname(file), content: fs.readFileSync(file, 'utf8') };
    },
  });
  // Collect candidate class names from all source files
  const candidates = new Set();
  for (const f of [...walk(SRC), ...walk(path.join(ROOT, 'server', 'games'))]) {
    for (const tok of fs.readFileSync(f, 'utf8').split(/[\s"'`{}<>;=]+/)) {
      if (tok && tok.length < 120) candidates.add(tok);
    }
  }
  let css = compiler.build([...candidates]);
  const result = await esbuild.transform(css, { loader: 'css', minify: !watch });
  return result.code;
}

const hash = (s) => crypto.createHash('sha1').update(s).digest('hex').slice(0, 10);

async function buildAll() {
  const t0 = Date.now();
  fs.rmSync(DIST, { recursive: true, force: true });
  fs.mkdirSync(path.join(DIST, 'assets'), { recursive: true });
  // Code-split: the sports app loads first; each casino game downloads only
  // when opened. Images become separate cacheable files instead of inline data.
  const js = await esbuild.build({
    entryPoints: [path.join(SRC, 'src', 'main.jsx')],
    bundle: true,
    splitting: !watch,
    minify: !watch,
    sourcemap: watch ? 'inline' : false,
    format: 'esm',
    target: ['es2020', 'safari15'],
    jsx: 'automatic',
    loader: { '.js': 'jsx', '.webp': 'file', '.jpg': 'file', '.png': 'file' },
    outdir: path.join(DIST, 'assets'),
    entryNames: 'app-[hash]',
    chunkNames: 'chunk-[hash]',
    assetNames: 'img-[hash]',
    publicPath: '/assets/',
    define: { 'process.env.NODE_ENV': watch ? '"development"' : '"production"', __AUDIO__: JSON.stringify({ base: '/audio/', files: audioFiles() }), __PWA__: 'true' },
    metafile: true,
    write: true,
    logLevel: 'error',
  });
  const outputs = js.metafile.outputs;
  const entry = Object.keys(outputs).find((f) => outputs[f].entryPoint?.endsWith('main.jsx'));
  const jsName = path.relative(DIST, entry).split(path.sep).join('/');
  // Everything the first screen needs, so the browser can fetch it all at once
  const initial = new Set();
  const walk = (f) => { if (initial.has(f)) return; initial.add(f); for (const im of outputs[f].imports) if (im.kind === 'import-statement' && outputs[im.path]) walk(im.path); };
  walk(entry);
  const jsSize = [...initial].reduce((a, f) => a + outputs[f].bytes, 0);
  const preload = [...initial].map((f) => `<link rel="modulepreload" href="/${path.relative(DIST, f).split(path.sep).join('/')}">`).join('');
  const totalJs = Object.entries(outputs).filter(([f]) => f.endsWith('.js')).reduce((a, [, o]) => a + o.bytes, 0);
  const cssCode = await buildCss();
  const cssName = `assets/app-${hash(cssCode)}.css`;
  fs.writeFileSync(path.join(DIST, cssName), cssCode);
  const html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8')
    .replace('<!--CSS-->', `<link rel="stylesheet" href="/${cssName}">`)
    .replace('<!--JS-->', `${preload}<script type="module" src="/${jsName}"></script>`);
  fs.writeFileSync(path.join(DIST, 'index.html'), html);
  fs.copyFileSync(path.join(SRC, 'favicon.svg'), path.join(DIST, 'favicon.svg'));
  // Installable-app files: manifest and service worker at the root, icons under /pwa/
  fs.cpSync(path.join(SRC, 'pwa'), path.join(DIST, 'pwa'), { recursive: true });
  for (const f of ['manifest.webmanifest', 'sw.js']) fs.renameSync(path.join(DIST, 'pwa', f), path.join(DIST, f));
  if (fs.existsSync(path.join(SRC, 'audio'))) fs.cpSync(path.join(SRC, 'audio'), path.join(DIST, 'audio'), { recursive: true });
  console.log(`[build] dist/ ready in ${Date.now() - t0}ms (first load js ${(jsSize / 1024).toFixed(0)}kB of ${(totalJs / 1024).toFixed(0)}kB, css ${(cssCode.length / 1024).toFixed(0)}kB)`);
}

try {
  await buildAll();
} catch (e) {
  console.error('[build] failed:', e.message);
  if (!watch) process.exit(1);
}
if (watch) {
  let timer;
  fs.watch(SRC, { recursive: true }, () => {
    clearTimeout(timer);
    timer = setTimeout(() => buildAll().catch((e) => console.error('[build] failed:', e.message)), 150);
  });
  console.log('[build] watching client/ for changes…');
}
