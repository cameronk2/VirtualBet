// Stampede Link – reproducible RTP simulation with breakdown.
//   node scripts/tune-stampede.mjs <spins> [seed]
import { act, init } from '../server/games/stampede/engine.js';
const [N = 200000, seed = 1] = process.argv.slice(2).map(Number);
const xs = (s) => () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
const rand = xs(seed || 1), ctx = { rand, minStake: 10 }, BET = 100;
let st = init(), paid = 0, n = 0, hits = 0, maxX = 0;
const src = { base: 0, scatter: 0, free: 0, holdBase: 0, holdFree: 0 }, cnt = { hold: 0, free: 0, grand: 0, filled: 0, holdX: 0 };
while (n < N || st.mode !== 'base') {
  let r;
  if (st.mode === 'hold') { r = act(st, 'respin', {}, ctx); if (r.out.holdDone) { src[r.out.holdDone.source === 'free' ? 'holdFree' : 'holdBase'] += r.payout; cnt.hold++; cnt.filled += r.out.holdDone.filled; cnt.holdX += r.out.holdDone.totalX; if (r.out.holdDone.grand) cnt.grand++; } }
  else if (st.mode === 'free') { r = act(st, 'spin', {}, ctx); src.free += r.payout; }
  else { r = act(st, 'spin', { stake: BET }, ctx); n++; src.base += r.payout - r.out.scatterWin; src.scatter += Math.min(r.payout, r.out.scatterWin); if (r.payout) hits++; if (r.out.triggers.free) cnt.free++; }
  paid += r.stake; maxX = Math.max(maxX, r.payout / BET); st = r.state;
}
const p = (x) => +(x / paid * 100).toFixed(2);
console.log(JSON.stringify({ rtp: p(Object.values(src).reduce((a, b) => a + b, 0)), hit: +(hits / N * 100).toFixed(1), ...Object.fromEntries(Object.entries(src).map(([k, v]) => [k, p(v)])), holdEvery: Math.round(N / Math.max(1, cnt.hold)), freeEvery: Math.round(N / Math.max(1, cnt.free)), avgFilled: +(cnt.filled / cnt.hold).toFixed(2), avgHoldX: +(cnt.holdX / cnt.hold).toFixed(1), grands: cnt.grand, maxX }));
