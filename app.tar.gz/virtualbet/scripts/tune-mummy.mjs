// Mystery of the Mummy – reproducible RTP simulation with a breakdown.
//   node scripts/tune-mummy.mjs <spins> [seed]
import { act, init } from '../server/games/mummy/engine.js';

const [N = 200000, seed = 1] = process.argv.slice(2).map(Number);
const xs = (s) => () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
const rand = xs(seed || 1), ctx = { rand, minStake: 10 }, BET = 100;
let st = init(), paid = 0, hits = 0, n = 0;
const src = { lines: 0, scatter: 0, free: 0, cash: 0, jackpot: 0 }, count = { free: 0, cash: 0, jackpot: 0, freeRandom: 0, cashRandom: 0 };
let maxX = 0, roundWin = 0;
while (n < N || st.mode !== 'base') {
  let r;
  if (st.mode === 'jackpot') { const used = new Set(st.jackpot.opened.map((o) => o.index)); r = act(st, 'pick', { index: [...Array(15).keys()].find((i) => !used.has(i)) }, ctx); if (r.out.done) { src.jackpot += r.payout; count.jackpot++; } }
  else if (st.mode === 'cash') { r = act(st, 'respin', {}, ctx); if (r.out.done) { src.cash += r.payout; count.cash++; } }
  else {
    const inFree = st.mode === 'free';
    r = act(st, 'spin', { stake: BET }, ctx);
    const lw = r.out.wins.reduce((a, w) => a + w.amount, 0);
    if (inFree) src.free += r.payout; else { src.lines += lw; src.scatter += r.out.scatter.win; n++; if (r.payout) hits++; }
    if (r.out.triggers.free?.spins) { count.free++; if (r.out.triggers.free.random) count.freeRandom++; }
    if (r.out.triggers.cash?.random) count.cashRandom++;
  }
  if (r.out.started?.type === 'free' || st.mode === 'base') roundWin = 0;
  roundWin += r.payout; maxX = Math.max(maxX, roundWin / BET);
  paid += r.stake; st = r.state;
}
const p = (x) => +(x / paid * 100).toFixed(2);
const total = Object.values(src).reduce((a, b) => a + b, 0);
console.log(JSON.stringify({ rtp: p(total), hitRate: +(hits / N * 100).toFixed(1), lines: p(src.lines), scatter: p(src.scatter), free: p(src.free), cash: p(src.cash), jackpot: p(src.jackpot),
  freeEvery: Math.round(N / count.free), cashEvery: Math.round(N / count.cash), jackpotEvery: Math.round(N / count.jackpot), randomTriggers: { free: count.freeRandom, cash: count.cashRandom }, maxX: +maxX.toFixed(1), spins: N }));
