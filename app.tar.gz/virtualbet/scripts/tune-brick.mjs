// Brick by Brick – reproducible RTP simulation with breakdown.
//   node scripts/tune-brick.mjs <spins> [seed]
import { act, init } from '../server/games/brick/engine.js';
const [N = 200000, seed = 1] = process.argv.slice(2).map(Number);
const xs = (s) => () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
const rand = xs(seed || 1), ctx = { rand, minStake: 10 }, BET = 100;
const { HOUSE, JACKPOTS: JPS } = await import('../server/games/brick/config.js');
const EH = (t, w) => { const tw = HOUSE[t].reduce((a, [, x]) => a + x, 0); return HOUSE[t].reduce((a, [v, x]) => a + x * (typeof v === 'number' ? v : v === 'WHEEL' ? (w ? 0 : 10) : JPS[v]), 0) / tw; };
let houseSmooth = 0;
let st = init(), paid = 0, n = 0, hits = 0, maxX = 0;
const src = { base: 0, hats: 0, buzzsaw: 0, mansions: 0, megahat: 0, wheelJp: 0 }, cnt = { hats: 0, saws: 0, buzzsaw: 0, mansions: 0, megahat: 0, jp: 0 };
while (n < N || st.mode !== 'base') {
  let r;
  if (st.mode === 'wheel') { r = act(st, 'wheel', {}, ctx); if (r.out.jackpot) { src.wheelJp += r.payout; cnt.jp++; } else cnt[r.out.started.kind]++; }
  else if (st.mode === 'free') { const kind = st.free.kind; r = act(st, 'spin', {}, ctx); if (r.out.finished) { src[kind] += r.payout; houseSmooth += (r.out.reveal.prizesX + r.out.reveal.houses.reduce((a, h) => a + EH(h.tier, kind === 'hats'), 0)) * BET - r.payout; } }
  else { r = act(st, 'spin', { stake: BET }, ctx); n++; src.base += r.payout; if (r.payout) hits++; if (r.out.triggers.hats) cnt.hats++; if (r.out.triggers.saws) cnt.saws++; }
  paid += r.stake; maxX = Math.max(maxX, r.payout / BET); st = r.state;
}
const p = (x) => +(x / paid * 100).toFixed(2);
// variance reduction: the wheel's jackpot wedges at their expected value
const { WHEEL, JACKPOTS } = await import('../server/games/brick/config.js');
const wt = WHEEL.reduce((a, [, w]) => a + w, 0), ejp = WHEEL.reduce((a, [k, w]) => a + (JACKPOTS[k] || 0) * w, 0) / wt;
const wheels = cnt.jp + cnt.buzzsaw + cnt.mansions + cnt.megahat;
const smooth = Object.values(src).reduce((a, b) => a + b, 0) - src.wheelJp + wheels * ejp * BET + houseSmooth;
console.log(JSON.stringify({ rtpSmoothed: p(smooth), rtp: p(Object.values(src).reduce((a, b) => a + b, 0)), hit: +(hits / N * 100).toFixed(1), ...Object.fromEntries(Object.entries(src).map(([k, v]) => [k, p(v)])), hatsEvery: Math.round(N / cnt.hats), sawsEvery: Math.round(N / cnt.saws), wheel: cnt, maxX }));
