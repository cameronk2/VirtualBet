// Golden Wishes – reproducible RTP simulation with a breakdown by source.
//   node scripts/tune-genie.mjs <spins> [seed]
import { act, init } from '../server/games/genie/engine.js';
import { TARGET_RTP } from '../server/games/genie/config.js';
const [N = 500000, seed = 1] = process.argv.slice(2).map(Number);
const xs = (s) => () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
const rand = xs(seed || 1), ctx = { rand, minStake: 10 }, BET = 10000;
let st = init(), paid = 0, n = 0, hits = 0, maxX = 0;
const src = { lines: 0, stars: 0, wishCash: 0, free: 0, treasure: 0 };
const cnt = { free: 0, wish: 0, treasure: 0, MINI: 0, MINOR: 0, MAJOR: 0, GRAND: 0, freeX: 0, big: 0 };
const wishType = {};
while (n < N || st.mode !== 'base') {
  let r;
  if (st.mode === 'treasure') {
    const open = new Set(st.treasure.order);
    let tile = 0; while (open.has(tile)) tile++;
    r = act(st, 'pick', { tile }, ctx);
    if (r.out.treasureDone) { src.treasure += r.payout; cnt.treasure++; cnt[r.out.treasureDone.won]++; }
  } else if (st.mode === 'free') { r = act(st, 'spin', {}, ctx); src.free += r.payout; if (r.out.finished) cnt.freeX += r.out.finished.total / BET; }
  else {
    r = act(st, 'spin', { stake: BET }, ctx); n++;
    const w = r.out;
    const lw = Math.min(r.payout, w.lineWin), sw = Math.min(r.payout - lw, w.scatterWin);
    src.lines += lw; src.stars += sw; src.wishCash += r.payout - lw - sw;
    if (r.payout) hits++; if (r.payout >= BET * 10) cnt.big++;
    if (w.stars.length >= 3) cnt.free++;
    if (w.wish) { cnt.wish++; wishType[w.wish.type] = (wishType[w.wish.type] || 0) + 1; }
  }
  if (st.mode === 'free' && r.out.wish) { src.free -= 0; }
  paid += r.stake; maxX = Math.max(maxX, r.payout / BET); st = r.state;
}
const p = (x) => +(x / paid * 100).toFixed(2);
const every = (k) => Math.round(N / Math.max(1, k));
console.log(JSON.stringify({ target: TARGET_RTP * 100, rtp: p(Object.values(src).reduce((a, b) => a + b, 0)), hit: +(hits / N * 100).toFixed(1), ...Object.fromEntries(Object.entries(src).map(([k, v]) => [k, p(v)])),
  freeEvery: every(cnt.free), wishEvery: every(cnt.wish), treasureEvery: every(cnt.treasure), bigWinEvery: every(cnt.big), avgFreeX: +(cnt.freeX / Math.max(1, cnt.free + (wishType.FREE || 0))).toFixed(1),
  jackpots: { MINI: cnt.MINI, MINOR: cnt.MINOR, MAJOR: cnt.MAJOR, GRAND: cnt.GRAND }, wishType, maxX }));
