// Moonridge RTP tuner / verifier.
//   node scripts/tune-moonridge.mjs free <profile> <freeScale> <rounds> [seed]
//   node scripts/tune-moonridge.mjs base <profile> <baseScale> <freeScale> <roundValueX> <spins> [seed]
//   node scripts/tune-moonridge.mjs full <profile> <spins> [seed]      (uses SOLVED)
// "base" replaces each free-spins round with its measured average value
// (variance reduction); "full" plays everything for real.
import { resolveSpin } from '../server/games/moonridge/engine.js';
import { SOLVED } from '../server/games/moonridge/config.js';

const [mode, profile = 'high', ...a] = process.argv.slice(2);
const lehmer = (seed) => { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; };
const BET = 100;
const step = (st, rand, scales) => resolveSpin(st, { bet: BET, rand, profile, scales });
const carry = (st, r) => ({ wilds: r.wilds, nextId: r.nextId, spin: r.spinNo, free: r.next && r.next.remaining > 0 ? r.next : null });

if (mode === 'free') {
  const [fs, rounds, seed = 1] = a.map(Number);
  const rand = lehmer(seed), scales = { base: 0, free: fs };
  let sum = 0, sq = 0, spins = 0;
  for (let i = 0; i < rounds; i++) {
    let st = { wilds: [], nextId: 1, spin: 0, free: { bet: BET, remaining: 20, total: 0, played: 0 } }, tot = 0;
    while (st.free) { const r = step(st, rand, scales); tot += r.win; spins++; st = carry(st, r); }
    sum += tot / BET; sq += (tot / BET) ** 2;
  }
  const m = sum / rounds, se = Math.sqrt((sq / rounds - m * m) / rounds);
  console.log(JSON.stringify({ profile, freeScale: fs, roundX: +m.toFixed(3), se: +se.toFixed(3), spinsPerRound: +(spins / rounds).toFixed(2) }));
} else if (mode === 'base' || mode === 'full') {
  const full = mode === 'full';
  const [bs, fs, fv, N, seed = 1] = full ? [SOLVED[profile].base, SOLVED[profile].free, 0, +a[0], +(a[1] || 1)] : a.map(Number);
  const rand = lehmer(seed), scales = { base: bs, free: fs };
  let st = { wilds: [], nextId: 1, spin: 0, free: null };
  let paid = 0, won = 0, hits = 0, trig = 0, lines = 0, scat = 0, jp = 0, freeWon = 0, maxX = 0, landed = 0, jps = [0, 0, 0, 0, 0];
  for (let i = 0; i < N || st.free;) {
    const wasFree = !!st.free;
    const r = step(st, rand, scales);
    if (!wasFree) { i++; paid += BET; if (r.win) hits++; landed += r.out.landed.length; }
    else freeWon += r.win;
    won += r.win; maxX = Math.max(maxX, r.win / BET);
    if (!wasFree) { lines += r.out.wins.reduce((x, w) => x + w.amount, 0); scat += r.out.scatter.win; if (r.out.jackpot) { jp += r.out.jackpot.win; jps[r.out.jackpot.tier]++; } }
    st = carry(st, r);
    if (r.trigger?.freeSpins) { trig++; if (!full) { won += fv * BET; freeWon += fv * BET; st = { ...st, free: null, wilds: [] }; } }
  }
  const p = (x) => +(x / paid * 100).toFixed(3);
  console.log(JSON.stringify({ profile, mode, scales, rtp: p(won), hitRate: +(hits / N * 100).toFixed(2), lines: p(lines), scatter: p(scat), jackpot: p(jp), free: p(freeWon), freeEvery: Math.round(N / trig), wildsPer100: +(landed / N * 100).toFixed(1), jackpots: jps, maxX: +maxX.toFixed(1), spins: N }));
}
