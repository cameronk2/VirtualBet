// Polar Catch: solves each bonus table's tail scale for its target return
// (exact maths, no simulation) and prints every bet's return.
//   node scripts/tune-polarcatch.mjs
import { BONUS_IDS, CATCH } from '../server/games/polarcatch/config.js';
import { bonusRtp, flakeRtp } from '../server/games/polarcatch/maths.js';

const solved = {};
for (const id of BONUS_IDS) {
  let lo = 0.01, hi = 50;
  for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2; if (bonusRtp(id, m) * 100 < CATCH[id].target) lo = m; else hi = m; }
  solved[id] = +((lo + hi) / 2).toFixed(5);
}
console.log('TAIL_SCALE =', JSON.stringify(solved));
console.log('flake', (flakeRtp() * 100).toFixed(3) + '%');
for (const id of BONUS_IDS) console.log(id, (bonusRtp(id, solved[id]) * 100).toFixed(3) + '%');
