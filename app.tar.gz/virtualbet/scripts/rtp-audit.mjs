// Long-run return check for every server-side casino game (seeded RNG).
//   node scripts/rtp-audit.mjs [rounds] [game ...]
import { runGame } from '../server/games/registry.js';

const [N = 200000, ...only] = process.argv.slice(2).map((x, i) => (i === 0 ? Number(x) : x));
const xs = (s) => () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
const ctx = (rand) => ({ rand, now: 0, minStake: 10, maxStake: 50000 });

function slot(id, n, rand) {
  let st = null, paid = 0, won = 0, i = 0, guard = 0;
  while (i < n || (st && (st.free || st.bonus || (st.mode && st.mode !== 'base')))) {
    if (guard++ > n * 50) throw new Error(`${id} did not finish`);
    let r;
    if (st?.bonus) { const left = [...Array(12).keys()].filter((k) => !st.bonus.picked.includes(k)); r = runGame(id, st, 'pick', { index: left[0] }, ctx(rand)); }
    else if (st?.mode === 'jackpot') r = runGame(id, st, 'pick', { index: st.jackpot.opened.length }, ctx(rand));
    else if (st?.mode === 'cash') r = runGame(id, st, 'respin', {}, ctx(rand));
    else { const paidSpin = !(st?.free) && !(st?.mode === 'free'); r = runGame(id, st, 'spin', { stake: 100 }, ctx(rand)); if (paidSpin) i++; }
    paid += r.stake; won += r.payout; st = r.state;
  }
  return won / paid;
}
const RED = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const table = {
  roulette: (n, rand) => { let p = 0, w = 0, st = null; for (let i = 0; i < n; i++) { const r = runGame('roulette', st, 'spin', { bets: [{ nums: RED, amount: 100 }] }, ctx(rand)); p += r.stake; w += r.payout; st = r.state; } return w / p; },
  baccarat: (n, rand) => { let p = 0, w = 0, st = null; for (let i = 0; i < n; i++) { const r = runGame('baccarat', st, 'deal', { banker: 100 }, ctx(rand)); p += r.stake; w += r.payout; st = r.state; } return w / p; },
  threecard: (n, rand) => { let p = 0, w = 0, st = null; for (let i = 0; i < n; i++) { let r = runGame('threecard', st, 'deal', { ante: 100 }, ctx(rand)); p += r.stake; w += r.payout; st = r.state; r = runGame('threecard', st, st.hand && r.out?.hint === 'fold' ? 'fold' : 'play', {}, ctx(rand)); p += r.stake; w += r.payout; st = r.state; } return w / p; },
  plinko: (n, rand) => { let p = 0, w = 0, st = null; for (let i = 0; i < n; i++) { const r = runGame('plinko', st, 'drop', { stake: 100, risk: 'medium' }, ctx(rand)); p += r.stake; w += r.payout; st = r.state; } return w / p; },
  scratch: (n, rand) => { let p = 0, w = 0, st = null; for (let i = 0; i < n; i++) { const r = runGame('scratch', st, 'buy', { price: 200 }, ctx(rand)); p += r.stake; w += r.payout; st = r.state; } return w / p; },
};
const SLOTS = ['atlantis', 'neon', 'dragon', 'cosmic', 'pharaoh', 'frost', 'moonridge', 'mummy', 'nebula', 'vault', 'starlight'];
for (const id of [...SLOTS, ...Object.keys(table)]) {
  if (only.length && !only.includes(id)) continue;
  const rand = xs(12345);
  try {
    const t0 = Date.now();
    const rtp = table[id] ? table[id](N, rand) : slot(id, N, rand);
    console.log(id.padEnd(10), (rtp * 100).toFixed(2) + '%', `${Date.now() - t0}ms`);
  } catch (e) { console.log(id.padEnd(10), 'ERROR', e.message); }
}
