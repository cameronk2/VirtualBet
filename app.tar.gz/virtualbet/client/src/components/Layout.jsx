import { lockScroll } from '../lib/scrollLock.js';
import { useEffect, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { Link, useLocation } from '../lib/router.jsx';
import { combinedOdds, duration, money, odds as fmtOdds } from '../lib/format.js';
import { useNow, usePolling } from '../lib/hooks.js';
import BetSlip from './BetSlip.jsx';
import DepositModal from './DepositModal.jsx';
import RealityCheck from './RealityCheck.jsx';
import { Icon } from './ui.jsx';
import { FavSync } from '../lib/favs.jsx';
import PullToRefresh from './PullToRefresh.jsx';

const SPORTS_NAV = [
  { to: '/', label: 'Home' },
  { to: '/live', label: 'Live', dot: true },
  { to: '/upcoming', label: 'Fixtures' },
  { to: '/results', label: 'Results' },
  { to: '/my-bets', label: 'My Bets' },
  { to: '/history', label: 'History & Stats' },
];
const CASINO_NAV = [
  { to: '/casino', label: 'Lobby', exact: true },
  { to: '/casino?cat=slots', label: 'Slots', cat: 'slots' },
  { to: '/casino?cat=tables', label: 'Tables', cat: 'tables' },
  { to: '/casino?cat=instant', label: 'Instant', cat: 'instant' },
];
const CASINO_PATHS = ['/casino', '/blackjack', '/spin21', '/slots'];
export const isCasinoPath = (p) => CASINO_PATHS.some((c) => p === c || p.startsWith(`${c}/`));
const OTHER_PATHS = ['/account', '/leaderboard', '/achievements', '/login', '/register'];

/** Segmented control used at the top of a section (Fixtures/Live/Results, Open/Settled/Stats). */
export function Segmented({ items, className = '' }) {
  return (
    <div className={`grid gap-1 rounded-xl bg-navy-900 p-1 ring-1 ring-navy-700 ${className}`} style={{ gridTemplateColumns: `repeat(${items.length}, minmax(0, 1fr))` }} role="tablist">
      {items.map((it) => (
        <Link key={it.to} to={it.to} role="tab" aria-selected={it.on} replace="true"
          className={`flex h-9 items-center justify-center gap-1.5 rounded-lg text-[13px] font-bold transition-colors ${it.on ? 'bg-navy-600 text-white shadow-sm' : 'text-slate-400 active:bg-navy-800'}`}>
          {it.dot && <span className={`h-1.5 w-1.5 rounded-full ${it.on ? 'bg-red-500' : 'bg-red-500/70'} animate-pulse`} />}
          {it.label}
          {it.count > 0 && <span className="rounded-full bg-brand-500 px-1.5 text-[10px] leading-4 text-navy-950">{it.count}</span>}
        </Link>
      ))}
    </div>
  );
}

export function SportsNav() {
  const { pathname } = useLocation();
  return <Segmented className="mb-4" items={[
    { to: '/upcoming', label: 'Fixtures', on: pathname.startsWith('/upcoming') },
    { to: '/live', label: 'Live', dot: true, on: pathname.startsWith('/live') },
    { to: '/results', label: 'Results', on: pathname.startsWith('/results') },
  ]} />;
}

export function BetsNav() {
  const { pathname, query } = useLocation();
  const { user } = useApp();
  const tab = query.get('tab');
  return <Segmented className="mb-4" items={[
    { to: '/my-bets?tab=open', label: 'Open', count: user?.openBets, on: pathname === '/my-bets' && (!tab || tab === 'open') },
    { to: '/history', label: 'Settled', on: (pathname === '/history' && tab !== 'stats') || (pathname === '/my-bets' && (tab === 'settled' || tab === 'all')) },
    { to: '/history?tab=stats', label: 'Stats', on: pathname === '/history' && tab === 'stats' },
  ]} />;
}

export function Logo() {
  return (
    <Link to="/" className="flex shrink-0 items-center gap-2" aria-label="VirtualBet home">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 text-navy-950 shadow-[0_0_18px_rgba(25,195,125,0.35)]"><Icon.ball className="h-6 w-6" /></span>
      <span className="font-cond text-xl font-extrabold uppercase italic leading-none tracking-tight text-white min-[400px]:text-2xl">Virtual<span className="text-brand-400">Bet</span></span>
    </Link>
  );
}

function SessionTimer() {
  const { sessionStart } = useApp();
  const now = useNow(1000);
  return (
    <span className="hidden items-center gap-1 text-xs text-slate-400 tabular-nums md:flex" title="Time on VirtualBet this session">
      <Icon.clock className="h-3.5 w-3.5" /> {duration(now - sessionStart)}
    </span>
  );
}

function SectionTabs({ casino }) {
  return (
    <div className="flex rounded-full bg-navy-950/70 p-1 ring-1 ring-navy-700">
      {[['Sports', '/', !casino], ['Casino', '/casino', casino]].map(([label, to, on]) => (
        <Link key={label} to={to} className={`rounded-full px-4 py-1.5 font-cond text-sm font-bold uppercase tracking-wide transition-colors ${on ? 'bg-brand-500 text-navy-950' : 'text-slate-300 hover:text-white'}`}>{label}</Link>
      ))}
    </div>
  );
}

function SubNav() {
  const { pathname, query } = useLocation();
  const casino = isCasinoPath(pathname);
  const other = OTHER_PATHS.some((p) => pathname.startsWith(p));
  const items = casino ? CASINO_NAV : SPORTS_NAV;
  const active = (n) => {
    if (casino) return n.cat ? pathname === '/casino' && query.get('cat') === n.cat : pathname === '/casino' && !query.get('cat');
    return n.to === '/' ? pathname === '/' : pathname.startsWith(n.to);
  };
  if (other) return null;
  return (
    <nav className="vb-gutter scrollbar-none mx-auto hidden max-w-[1440px] gap-1 overflow-x-auto py-1.5 md:flex" aria-label={casino ? 'Casino' : 'Sports'}>
      {items.map((n) => (
        <Link key={n.to} to={n.to} className={`whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-colors ${active(n) ? 'bg-white/10 text-white ring-1 ring-white/15' : 'text-slate-400 hover:text-white'}`}>
          {n.label}{n.dot && <span className="ml-1.5 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-red-500 align-middle" />}
        </Link>
      ))}
      <Link to="/achievements" className={`ml-auto hidden whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-semibold md:block ${pathname === '/achievements' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'}`}>Achievements</Link>
      <Link to="/leaderboard" className="hidden whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-semibold text-slate-400 hover:text-white md:block">Leaderboard</Link>
    </nav>
  );
}

function Header() {
  const { user, setDepositOpen } = useApp();
  const { pathname } = useLocation();
  const casino = isCasinoPath(pathname);
  return (
    <header style={{ top: 'env(safe-area-inset-top, 0px)' }} className="sticky z-40 border-b border-white/5 bg-navy-900/95 backdrop-blur-md">
      <div className="vb-gutter mx-auto flex h-14 max-w-[1440px] items-center gap-2 md:h-16 md:gap-3">
        <Logo />
        <div className="ml-4 hidden md:block"><SectionTabs casino={casino} /></div>
        <div className="ml-auto flex min-w-0 items-center gap-2 sm:gap-3">
          {user ? (
            <>
              <SessionTimer />
              <div className="flex h-10 items-center rounded-full bg-navy-800 pl-3.5 ring-1 ring-white/10">
                <Link to="/account?tab=wallet" className="flex flex-col items-end pr-2 leading-none" title="Virtual balance - no cash value">
                  <span key={user.balance} className="animate-fade-in font-cond text-[17px] font-bold text-white tabular-nums">{money(user.balance)}</span>
                  <span className="mt-0.5 text-[9px] font-bold uppercase tracking-[0.12em] text-brand-400">Virtual</span>
                </Link>
                <button onClick={() => setDepositOpen(true)} aria-label="Add virtual funds" className="mr-1 flex h-8 w-8 items-center justify-center rounded-full bg-brand-500 text-navy-950 active:scale-95 md:w-auto md:px-3">
                  <svg viewBox="0 0 20 20" className="h-4 w-4 md:hidden" fill="currentColor" aria-hidden="true"><path d="M10 4a1 1 0 011 1v4h4a1 1 0 110 2h-4v4a1 1 0 11-2 0v-4H5a1 1 0 110-2h4V5a1 1 0 011-1z" /></svg>
                  <span className="hidden text-sm font-bold md:inline">Deposit</span>
                </button>
              </div>
              <Link to="/account" className="hidden h-10 w-10 items-center justify-center rounded-full bg-navy-700 text-slate-300 hover:text-white md:flex" aria-label="Account">
                <Icon.user className="h-5 w-5" />
              </Link>
            </>
          ) : user === null ? (
            <>
              <Link to="/login" className="btn-ghost h-9 px-3">Log in</Link>
              <Link to="/register" className="btn-primary h-9 px-3">Join</Link>
            </>
          ) : null}
        </div>
      </div>
      <div className="hidden border-t border-white/5 bg-navy-950/40 md:block"><SubNav /></div>
    </header>
  );
}

const TabIcon = {
  sports: (p) => <Icon.ball {...p} />,
  live: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><circle cx="12" cy="12" r="3" fill="currentColor" /><path d="M6.3 6.3a8 8 0 000 11.4M17.7 6.3a8 8 0 010 11.4M3.5 3.5a12 12 0 000 17M20.5 3.5a12 12 0 010 17" strokeLinecap="round" /></svg>),
  casino: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><rect x="3" y="3" width="18" height="18" rx="4" /><circle cx="8" cy="8" r="1.5" fill="currentColor" /><circle cx="16" cy="16" r="1.5" fill="currentColor" /><circle cx="12" cy="12" r="1.5" fill="currentColor" /><circle cx="16" cy="8" r="1.5" fill="currentColor" /><circle cx="8" cy="16" r="1.5" fill="currentColor" /></svg>),
  bets: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M6 3h9l4 4v14H6z" strokeLinejoin="round" /><path d="M9 11h7M9 15h7M9 7h4" strokeLinecap="round" /></svg>),
  account: (p) => <Icon.user {...p} />,
  home: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M4 10.5L12 4l8 6.5V20a1 1 0 01-1 1h-4.5v-6h-5v6H5a1 1 0 01-1-1z" strokeLinejoin="round" /></svg>),
};

function BottomTabs() {
  const { pathname } = useLocation();
  const { user } = useApp();
  const tabs = [
    { to: '/', label: 'Home', icon: 'home', on: pathname === '/' },
    { to: '/upcoming', label: 'Sports', icon: 'sports', on: ['/upcoming', '/live', '/results', '/match'].some((p) => pathname.startsWith(p)) },
    { to: '/my-bets', label: 'My Bets', icon: 'bets', badge: user?.openBets, on: pathname.startsWith('/my-bets') || pathname.startsWith('/history') },
    { to: '/casino', label: 'Casino', icon: 'casino', on: isCasinoPath(pathname) },
    { to: '/account', label: 'Account', icon: 'account', on: ['/account', '/achievements', '/leaderboard', '/login', '/register'].some((p) => pathname.startsWith(p)) },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-navy-900/95 backdrop-blur-md md:hidden" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)', paddingLeft: 'env(safe-area-inset-left, 0px)', paddingRight: 'env(safe-area-inset-right, 0px)' }} aria-label="Main">
      <div className="grid h-[58px] grid-cols-5">
        {tabs.map((t) => {
          const I = TabIcon[t.icon];
          return (
            <Link key={t.to} to={t.to} aria-current={t.on ? 'page' : undefined} className={`relative flex select-none flex-col items-center justify-center gap-0.5 text-[10.5px] font-semibold transition-colors ${t.on ? 'text-brand-400' : 'text-slate-400 active:text-slate-200'}`}>
              <span className={`relative flex h-7 w-12 items-center justify-center rounded-full transition-colors ${t.on ? 'bg-brand-500/15' : ''}`}>
                <I className="h-[22px] w-[22px]" />
                {t.badge > 0 && <span className="absolute -right-0.5 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand-500 px-1 text-[10px] font-extrabold leading-none text-navy-950 ring-2 ring-navy-900">{t.badge > 99 ? '99+' : t.badge}</span>}
              </span>
              {t.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

function Sidebar() {
  const { data } = usePolling('/api/leagues', 30000);
  const { pathname, query } = useLocation();
  const current = pathname === '/upcoming' ? query.get('league') : null;
  return (
    <aside className="hidden lg:block">
      <div className="sticky top-[124px] space-y-3">
        <div className="card overflow-hidden">
          <div className="border-b border-navy-700 px-3 py-2.5 font-cond text-sm font-bold uppercase tracking-wider text-slate-300">Competitions</div>
          <nav className="max-h-[calc(100vh-260px)] overflow-y-auto py-1">
            {(data?.leagues || []).map((l) => (
              <Link key={l.code} to={`/upcoming?league=${l.code}`} className={`flex items-center justify-between px-3 py-2 text-sm transition-colors ${current === l.code ? 'bg-navy-700 text-white' : 'text-slate-300 hover:bg-navy-800 hover:text-white'}`}>
                <span className="truncate">{l.name}</span>
                <span className="flex items-center gap-1.5 text-[11px]">
                  {l.live > 0 && <span className="rounded bg-red-600 px-1 font-bold text-white">{l.live}</span>}
                  <span className="text-slate-500">{l.upcoming}</span>
                </span>
              </Link>
            ))}
            {data && !data.leagues.length && <p className="px-3 py-4 text-xs text-slate-500">No competitions with fixtures right now.</p>}
          </nav>
        </div>
        <Link to="/casino" className="group block overflow-hidden rounded-xl bg-gradient-to-br from-fuchsia-600 via-violet-800 to-navy-900 p-3">
          <div className="font-cond text-lg font-extrabold uppercase leading-tight text-white">Casino</div>
          <div className="text-xs text-white/75">Slots, roulette, blackjack & more - all virtual</div>
          <div className="mt-2 inline-block rounded-full bg-white/15 px-3 py-1 text-xs font-bold text-white group-hover:bg-white/25">Open lobby →</div>
        </Link>
        <ResponsibleCard />
      </div>
    </aside>
  );
}

function ResponsibleCard() {
  return (
    <div className="rounded-lg border border-navy-700/70 bg-navy-900 p-3 text-[11px] leading-relaxed text-slate-400">
      <p className="mb-1 font-bold text-slate-300">Practise, don't chase</p>
      VirtualBet uses virtual money with no real value. If real-money gambling is affecting you, free confidential help is available from{' '}
      <a href="https://www.begambleaware.org" target="_blank" rel="noreferrer" className="text-brand-400 underline">BeGambleAware</a> and{' '}
      <a href="https://www.gamcare.org.uk" target="_blank" rel="noreferrer" className="text-brand-400 underline">GamCare</a>.
    </div>
  );
}

function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="pointer-events-none fixed inset-x-0 z-[60] flex flex-col items-center gap-2 px-4" style={{ top: 'calc(env(safe-area-inset-top, 0px) + 64px)' }} role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`animate-fade-in pointer-events-auto rounded-xl px-4 py-2.5 text-sm font-semibold shadow-xl ${t.type === 'error' ? 'bg-red-600 text-white' : t.type === 'success' ? 'bg-brand-500 text-navy-950' : t.type === 'badge' ? 'bg-gradient-to-r from-gold-400 to-amber-500 text-navy-950' : 'bg-navy-600 text-white'}`}>
          {t.message}
        </div>
      ))}
    </div>
  );
}

function MobileSlip() {
  const { slip, slipOpen, setSlipOpen } = useApp();
  const { pathname } = useLocation();
  useEffect(() => { setSlipOpen(false); }, [pathname, setSlipOpen]);
  useEffect(() => {
    if (!slipOpen) return undefined;
    return lockScroll();
  }, [slipOpen]);
  return (
    <div className="lg:hidden">
      {slip.length > 0 && !slipOpen && !isCasinoPath(pathname) && (() => {
        const acca = slip.length >= 2 && new Set(slip.map((s) => s.matchId)).size === slip.length;
        const combined = combinedOdds(slip.map((s) => s.odds));
        return (
          <button onClick={() => setSlipOpen(true)} className="animate-slide-up fixed inset-x-3 bottom-[68px] z-40 flex h-14 items-center justify-between gap-3 rounded-2xl bg-brand-500 px-4 text-navy-950 shadow-2xl shadow-black/50 active:scale-[.99] md:bottom-3" style={{ marginBottom: 'env(safe-area-inset-bottom)' }}>
            <span className="flex min-w-0 items-center gap-2.5">
              <span className="flex h-7 min-w-7 items-center justify-center rounded-full bg-navy-950 px-1.5 text-sm font-bold text-brand-400">{slip.length}</span>
              <span className="min-w-0 text-left leading-tight">
                <span className="block text-sm font-extrabold">{acca ? `${slip.length}-fold accumulator` : slip.length > 1 ? 'Singles' : 'Bet Slip'}</span>
                <span className="block truncate text-[11px] font-semibold text-navy-900/80">{slip[slip.length - 1].selectionLabel} @ {fmtOdds(slip[slip.length - 1].odds)}</span>
              </span>
            </span>
            <span key={combined} className="animate-fade-in shrink-0 rounded-lg bg-navy-950 px-3 py-1.5 text-right leading-tight">
              <span className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400">{acca ? 'Acca odds' : 'Odds'}</span>
              <span className="block text-base font-extrabold tabular-nums text-brand-400">{fmtOdds(acca || slip.length === 1 ? combined : slip[slip.length - 1].odds)}</span>
            </span>
          </button>
        );
      })()}
      {slipOpen && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/60 backdrop-blur-[2px]" onMouseDown={(e) => e.target === e.currentTarget && setSlipOpen(false)}>
          <div className="animate-slide-up flex max-h-[92dvh] min-h-[55dvh] w-full flex-col overflow-hidden rounded-t-3xl border-t border-navy-600 bg-navy-850 shadow-2xl" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
            <button type="button" onClick={() => setSlipOpen(false)} className="flex h-5 shrink-0 items-center justify-center" aria-label="Close bet slip"><span className="h-1 w-10 rounded-full bg-slate-500/60" /></button>
            <BetSlip onClose={() => setSlipOpen(false)} />
          </div>
        </div>
      )}
    </div>
  );
}

export default function Layout({ children }) {
  const { config, user } = useApp();
  const { pathname } = useLocation();
  const [dismissedNotice, setDismissed] = useState(() => { try { return localStorage.getItem('vb_notice') === '1'; } catch { return false; } });
  const hide = () => { setDismissed(true); try { localStorage.setItem('vb_notice', '1'); } catch { /* ignore */ } };
  const casino = isCasinoPath(pathname);
  const { slip, slipOpen } = useApp();
  const slipBar = slip.length > 0 && !casino && !slipOpen;
  const wide = casino || OTHER_PATHS.some((p) => pathname.startsWith(p));
  return (
    <div className="min-h-screen md:pb-0" style={{ paddingBottom: `calc(${slipBar ? 140 : 76}px + env(safe-area-inset-bottom, 0px))` }}>
      <Header />
      {user?.breakUntil && (
        <div className="border-b border-sky-400/20 bg-sky-400/10 px-4 py-2 text-center text-xs text-sky-200" role="status">
          You're taking a break until <b>{new Date(user.breakUntil).toLocaleString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</b>. Bets and games are paused.
        </div>
      )}
      {config?.localMode && !dismissedNotice && !casino && (
        <div className="border-b border-sky-400/20 bg-sky-400/10 px-4 py-2 text-center text-xs text-sky-200">
          <b>Real fixtures, simulated odds.</b> <span className="hidden sm:inline">Odds are modelled from real win probabilities, betting closes at kick-off, and bets settle on the verified full-time score.</span><span className="sm:hidden">Bets settle on verified full-time scores.</span>
          <button onClick={hide} className="ml-2 underline opacity-80 hover:opacity-100">Hide</button>
        </div>
      )}
      {!config?.localMode && config?.demoEnabled && config?.provider === 'none' && !dismissedNotice && !casino && (
        <div className="border-b border-gold-500/20 bg-gold-500/10 px-4 py-2 text-center text-xs text-gold-400">
          <b>Demo mode:</b> matches, scores and odds are <b>simulated</b><span className="hidden sm:inline"> (accelerated: 1 match minute = {config.demoSecondsPerMinute}s). Connect a football data API to show real fixtures</span>.
          <button onClick={hide} className="ml-2 underline opacity-80 hover:opacity-100">Hide</button>
        </div>
      )}
      {wide ? (
        <div className="vb-gutter mx-auto max-w-[1180px] py-4">
          <main key={pathname} className="vb-page min-w-0">{children}</main>
        </div>
      ) : (
        <div className="vb-gutter mx-auto grid max-w-[1440px] grid-cols-1 gap-4 py-4 lg:grid-cols-[220px_minmax(0,1fr)_340px]">
          <Sidebar />
          <main key={pathname} className="vb-page min-w-0">{children}</main>
          <aside className="hidden lg:block">
            <div className="card sticky top-[124px] flex max-h-[calc(100vh-140px)] flex-col overflow-hidden">
              <BetSlip />
            </div>
          </aside>
        </div>
      )}
      <footer className="vb-gutter mt-8 border-t border-navy-800 py-6 text-center text-xs leading-relaxed text-slate-500">
        <p><b className="text-slate-400">Virtual play only - no real-money wagering.</b> VirtualBet is a free-play simulator: balances have no cash value and odds are modelled, not bookmaker prices.</p>
      </footer>
      <BottomTabs />
      <FavSync />
      <PullToRefresh disabled={casino} />
      <MobileSlip />
      <DepositModal />
      <RealityCheck />
      <Toasts />
    </div>
  );
}
