import { useEffect, useRef, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';

// Pull down from the top of a page to refresh it. The installed iPhone app
// has no browser reload button, so this is how people refresh. Pages using
// usePolling listen for the 'vb:refresh' event.
const TRIGGER = 72;
export const REFRESH_EVENT = 'vb:refresh';

export default function PullToRefresh({ disabled }) {
  const { refreshUser } = useApp();
  const [pull, setPull] = useState(0);
  const [busy, setBusy] = useState(false);
  const start = useRef(null);
  const pullRef = useRef(0);

  useEffect(() => {
    if (disabled) return undefined;
    const blocked = (e) => document.body.style.overflow === 'hidden' || e.target.closest?.('[role="dialog"], .vb-pop, input, textarea, select, [data-no-ptr]');
    const onStart = (e) => {
      if (busy || window.scrollY > 0 || e.touches.length !== 1 || blocked(e)) { start.current = null; return; }
      start.current = { y: e.touches[0].clientY, x: e.touches[0].clientX };
    };
    const onMove = (e) => {
      if (!start.current) return;
      const dy = e.touches[0].clientY - start.current.y;
      const dx = Math.abs(e.touches[0].clientX - start.current.x);
      if (dy <= 0 || dx > dy || window.scrollY > 0) { if (pullRef.current) { pullRef.current = 0; setPull(0); } return; }
      const d = Math.min(120, dy * 0.5); // resistance
      pullRef.current = d;
      setPull(d);
    };
    const onEnd = async () => {
      if (!start.current) return;
      start.current = null;
      const d = pullRef.current;
      pullRef.current = 0;
      if (d < TRIGGER) { setPull(0); return; }
      setBusy(true);
      setPull(TRIGGER * 0.75);
      try { navigator.vibrate?.(8); } catch { /* not on iOS */ }
      window.dispatchEvent(new Event(REFRESH_EVENT));
      await Promise.all([refreshUser?.(), new Promise((r) => setTimeout(r, 650))]);
      setBusy(false);
      setPull(0);
    };
    window.addEventListener('touchstart', onStart, { passive: true });
    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('touchend', onEnd);
    window.addEventListener('touchcancel', onEnd);
    return () => {
      window.removeEventListener('touchstart', onStart);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onEnd);
      window.removeEventListener('touchcancel', onEnd);
    };
  }, [disabled, busy, refreshUser]);

  if (!pull && !busy) return null;
  const ready = pull >= TRIGGER || busy;
  return (
    <div className="pointer-events-none fixed inset-x-0 z-[45] flex justify-center md:hidden" style={{ top: `calc(env(safe-area-inset-top, 0px) + 56px + ${Math.max(0, pull - 28)}px)`, transition: start.current ? 'none' : 'top .2s ease-out' }} aria-live="polite">
      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-navy-700 shadow-lg ring-1 ring-white/10">
        <svg viewBox="0 0 24 24" className={`h-5 w-5 ${ready ? 'text-brand-400' : 'text-slate-400'} ${busy ? 'animate-spin' : ''}`} style={busy ? undefined : { transform: `rotate(${pull * 3}deg)` }} fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" aria-hidden="true">
          <path d="M20 12a8 8 0 11-2.34-5.66" /><path d="M20 4v5h-5" />
        </svg>
        <span className="sr-only">{busy ? 'Refreshing' : ready ? 'Release to refresh' : 'Pull to refresh'}</span>
      </div>
    </div>
  );
}
