// Gem Mines art: faceted gemstone, spiked sea-mine with a glowing core,
// logo and lobby emblem. Gradients: <MinesDefs />.
export function MinesDefs() {
  const lg = (id, stops, x1 = 0, y1 = 0, x2 = 0, y2 = 1) => <linearGradient id={id} x1={x1} y1={y1} x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  const rg = (id, stops, cx = '50%', cy = '50%') => <radialGradient id={id} cx={cx} cy={cy} r="60%">{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {lg('mnGemA', [[0, '#e0f2fe'], [0.45, '#38bdf8'], [1, '#1e3a8a']], 0, 0, 1, 1)}
        {lg('mnGemB', [[0, '#a5f3fc'], [1, '#0e7490']], 1, 0, 0, 1)}
        {lg('mnGemC', [[0, '#c4b5fd'], [1, '#4c1d95']])}
        {lg('mnGemD', [[0, '#f0abfc'], [0.5, '#a855f7'], [1, '#312e81']], 0, 1, 1, 0)}
        {rg('mnGlow', [[0, 'rgba(125,211,252,0.85)'], [0.5, 'rgba(129,140,248,0.35)'], [1, 'rgba(129,140,248,0)']])}
        {rg('mnBomb', [[0, '#64748b'], [0.55, '#1e293b'], [1, '#020617']], '38%', '34%')}
        {rg('mnCore', [[0, '#fff7ed'], [0.35, '#fb923c'], [1, '#dc2626']])}
        {rg('mnFire', [[0, '#fffbeb'], [0.3, '#fde047'], [0.6, '#f97316'], [1, 'rgba(220,38,38,0)']])}
        {lg('mnGold', [[0, '#fffbeb'], [0.4, '#fde047'], [0.75, '#f59e0b'], [1, '#92400e']])}
        {lg('mnTile', [[0, '#3b3f7a'], [1, '#1b1c3d']])}
      </defs>
    </svg>
  );
}

/** A brilliant-cut gemstone. */
export function Gem({ glow = true }) {
  return (
    <g>
      {glow && <circle cx="50" cy="52" r="46" fill="url(#mnGlow)" />}
      <path d="M26 32L38 20H62L74 32L50 84Z" fill="url(#mnGemA)" stroke="#e0f2fe" strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M26 32H74L50 84Z" fill="url(#mnGemD)" opacity=".55" />
      <path d="M38 20L44 32L50 20L56 32L62 20" fill="none" stroke="#f0f9ff" strokeWidth="1.2" opacity=".8" />
      <path d="M26 32H74" stroke="#f0f9ff" strokeWidth="1.4" />
      <path d="M44 32L50 84L56 32" fill="url(#mnGemB)" opacity=".75" />
      <path d="M26 32L44 32L50 84Z" fill="#1e3a8a" opacity=".35" />
      <path d="M38 20L44 32H26Z" fill="#fff" opacity=".55" />
      <path d="M50 20L44 32H56Z" fill="#bae6fd" opacity=".7" />
      <g className="mn-twinkle"><path d="M66 18L68 24L74 26L68 28L66 34L64 28L58 26L64 24Z" fill="#fff" /></g>
    </g>
  );
}

/** A spiked mine with a glowing core and a sparking fuse. */
export function Mine({ lit = true }) {
  return (
    <g>
      {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => <rect key={a} x="47" y="10" width="6" height="16" rx="2" fill="#475569" stroke="#0f172a" strokeWidth="1.2" transform={`rotate(${a} 50 52)`} />)}
      <circle cx="50" cy="52" r="28" fill="url(#mnBomb)" stroke="#020617" strokeWidth="2" />
      <ellipse cx="41" cy="42" rx="9" ry="5" fill="#fff" opacity=".22" transform="rotate(-30 41 42)" />
      <circle className={lit ? 'mn-core' : ''} cx="50" cy="54" r="9" fill="url(#mnCore)" />
      <circle cx="50" cy="54" r="13" fill="none" stroke="#f97316" strokeWidth="1.2" opacity=".5" />
      <path d="M62 30Q70 20 78 22" stroke="#a16207" strokeWidth="3" fill="none" strokeLinecap="round" />
      {lit && <g className="mn-spark"><circle cx="79" cy="21" r="4" fill="#fde047" /><path d="M79 13V17M79 25V29M71 21H75M83 21H87M73 15L76 18M85 15L82 18" stroke="#fde68a" strokeWidth="1.5" strokeLinecap="round" /></g>}
    </g>
  );
}

export function MinesLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 320 96" className={className} aria-label="Gem Mines">
      <g transform="translate(-2 2) scale(.92)"><Gem /></g>
      <text x="200" y="52" textAnchor="middle" fontFamily="'Cinzel', 'Lilita One', Georgia, serif" fontWeight="800" fontSize="40" textLength="196" lengthAdjust="spacingAndGlyphs" fill="url(#mnGold)" stroke="#1e1b4b" strokeWidth="4" paintOrder="stroke">GEM</text>
      <text x="200" y="86" textAnchor="middle" fontFamily="'Cinzel', 'Lilita One', Georgia, serif" fontWeight="800" fontSize="28" textLength="196" lengthAdjust="spacingAndGlyphs" fill="#e0e7ff" stroke="#1e1b4b" strokeWidth="4" paintOrder="stroke">MINES</text>
    </svg>
  );
}

export const MINES_LOBBY = (
  <g>
    <rect width="100" height="100" fill="#1e1b4b" />
    {Array.from({ length: 9 }, (_, i) => {
      const x = 6 + (i % 3) * 31, y = 6 + Math.floor(i / 3) * 31;
      return <g key={i}><rect x={x} y={y} width="27" height="27" rx="5" fill="url(#mnTile)" stroke="#6366f1" strokeWidth=".8" />
        {i === 4 ? <g transform={`translate(${x} ${y}) scale(.27)`}><Mine /></g> : [0, 2, 7].includes(i) ? <g transform={`translate(${x} ${y}) scale(.27)`}><Gem /></g> : null}</g>;
    })}
  </g>
);
