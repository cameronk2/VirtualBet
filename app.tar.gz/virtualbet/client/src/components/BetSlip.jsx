import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useApp, selKey } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { navigate } from '../lib/router.jsx';
import { cleanAmount, combinedOdds, odds as fmtOdds, penceToInput, potentialReturn, money, toPence } from '../lib/format.js';
import { Icon, Spinner } from './ui.jsx';

const QUICK = [100, 500, 1000, 2000]; // pence: +£1, +£5, +£10, +£20
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);

function StakeInput({ value, onChange, id }) {
  return (
    <div className="relative">
      <input
        id={id}
        type="text"
        inputMode="decimal"
        autoComplete="off"
        placeholder="0.00"
        value={value}
        onChange={(e) => onChange(cleanAmount(e.target.value))}
        className="input h-9 pl-7 text-right font-semibold tabular-nums"
      />
      <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">£</span>
    </div>
  );
}

export default function BetSlip({ onClose }) {
  const { slip, removeSelection, updateSelections, clearSlip, user, setUser, config, toast } = useApp();
  const rules = config?.rules || { minStake: 10, maxStake: 5000 };
  const [mode, setMode] = useState('singles');
  const [stakes, setStakes] = useState({});
  const [accaStake, setAccaStake] = useState('');
  const [allStake, setAllStake] = useState('');
  const [quotes, setQuotes] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [receipt, setReceipt] = useState(null);
  const idemKey = useRef(null);

  const distinctMatches = new Set(slip.map((s) => s.matchId)).size;
  const accaAllowed = slip.length >= 2 && distinctMatches === slip.length;

  useEffect(() => {
    if (mode === 'acca' && !accaAllowed) setMode('singles');
  }, [accaAllowed, mode]);

  // Any change to the slip means a new submission
  useEffect(() => { idemKey.current = null; setError(null); }, [slip, stakes, accaStake, mode]);

  // Live odds for slip selections
  const fetchQuotes = useCallback(async () => {
    if (!slip.length) return;
    try {
      const d = await api.post('/api/bets/quote', { selections: slip.map((s) => ({ matchId: s.matchId, market: s.market, selection: s.selection })) });
      const map = {};
      for (const qt of d.quotes) map[selKey(qt)] = qt;
      setQuotes(map);
    } catch { /* keep last quotes */ }
  }, [slip]);
  useEffect(() => {
    fetchQuotes();
    const t = setInterval(() => { if (document.visibilityState === 'visible') fetchQuotes(); }, 3000);
    return () => clearInterval(t);
  }, [fetchQuotes]);

  const rows = slip.map((s) => {
    const k = selKey(s);
    const qt = quotes[k];
    const unavailable = qt && !qt.available;
    const suspended = qt?.suspended;
    const changed = qt?.available && qt.odds !== s.odds ? { from: s.odds, to: qt.odds } : null;
    return { s, k, qt, unavailable, suspended, changed };
  });
  const anyChanged = rows.some((r) => r.changed);
  const anyBlocked = rows.some((r) => r.unavailable || r.suspended);

  const acceptChanges = () => {
    updateSelections((cur) => cur.map((s) => {
      const qt = quotes[selKey(s)];
      return qt?.available ? { ...s, odds: qt.odds } : s;
    }));
  };

  const toInt = toPence; // stake inputs are pounds; maths is in pence
  const bets = useMemo(() => {
    if (mode === 'acca') {
      const stake = toInt(accaStake);
      return stake ? [{ type: 'ACCA', stake, selections: slip }] : [];
    }
    return slip.filter((s) => toInt(stakes[selKey(s)]) > 0).map((s) => ({ type: 'SINGLE', stake: toInt(stakes[selKey(s)]), selections: [s] }));
  }, [mode, accaStake, stakes, slip]);

  const totalStake = bets.reduce((a, b) => a + b.stake, 0);
  const totalReturn = bets.reduce((a, b) => a + potentialReturn(b.stake, b.selections.map((s) => s.odds)), 0);
  const accaOdds = combinedOdds(slip.map((s) => s.odds));

  let validation = null;
  if (!bets.length) validation = 'Enter a stake to place a bet.';
  else if (bets.some((b) => b.stake < rules.minStake)) validation = `Minimum stake is ${money(rules.minStake)} per bet.`;
  else if (bets.some((b) => b.stake > rules.maxStake)) validation = `Maximum stake is ${money(rules.maxStake)} per bet.`;
  else if (user && totalStake > user.balance) validation = `Total stake is more than your balance (${money(user.balance)}).`;
  else if (user?.dailyStakeLimit != null && user.stakedLast24h + totalStake > user.dailyStakeLimit) {
    validation = `Exceeds your daily limit - ${money(Math.max(0, user.dailyStakeLimit - user.stakedLast24h))} left in the current 24 hours.`;
  } else if (anyBlocked) validation = 'Remove suspended or unavailable selections to continue.';

  const place = async () => {
    if (!user) { onClose?.(); navigate('/login?next=bets'); return; }
    if (validation || submitting) return;
    if (anyChanged) { setError('Odds have changed. Review and accept the new odds.'); return; }
    setSubmitting(true);
    setError(null);
    if (!idemKey.current) idemKey.current = uuid();
    try {
      const d = await api.post('/api/bets', {
        idempotencyKey: idemKey.current,
        bets: bets.map((b) => ({ type: b.type, stake: b.stake, selections: b.selections.map((s) => ({ matchId: s.matchId, market: s.market, selection: s.selection, odds: s.odds })) })),
      });
      setUser(d.user);
      setReceipt(d);
      idemKey.current = null;
      toast(`${d.refs.length > 1 ? `${d.refs.length} bets` : 'Bet'} placed`, 'success');
    } catch (e) {
      if (e.body?.code === 'ODDS_CHANGED') {
        await fetchQuotes();
        setError('Odds changed while placing your bet. Review and accept the new odds.');
      } else if (e.body?.code === 'SUSPENDED' || e.body?.code === 'UNAVAILABLE') {
        await fetchQuotes();
        setError(e.message);
      } else setError(e.message);
      if (e.status && e.status !== 0) idemKey.current = null; // server answered: next attempt is a new submission
    } finally {
      setSubmitting(false);
    }
  };

  const done = (keep) => {
    setReceipt(null);
    setStakes({});
    setAccaStake('');
    setAllStake('');
    if (!keep) { clearSlip(); onClose?.(); }
  };

  // ── Receipt ──
  if (receipt) {
    return (
      <div className="flex h-full flex-col">
        <div className="flex flex-col items-center gap-2 border-b border-navy-700 px-4 py-6 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-500 text-navy-950"><Icon.check className="h-7 w-7" /></div>
          <div className="text-lg font-bold text-white">Bet{receipt.refs.length > 1 ? 's' : ''} placed</div>
          <div className="text-xs text-slate-400">Balance: <span className="font-semibold text-white">{money(receipt.balance)}</span></div>
        </div>
        <div className="flex-1 space-y-2 overflow-y-auto p-3">
          {receipt.bets.map((b) => (
            <div key={b.ref} className="rounded-md border border-navy-600 bg-navy-800 p-3 text-sm">
              <div className="flex justify-between text-xs"><span className="font-mono text-brand-400">{b.ref}</span><span className="text-slate-400">{b.type === 'ACCA' ? `${b.selections.length}-fold acca` : 'Single'}</span></div>
              {b.selections.map((s, i) => <div key={i} className="mt-1 truncate text-slate-200">{s.selection} <span className="text-slate-500">· {s.match}</span></div>)}
              <div className="mt-2 flex justify-between text-xs text-slate-400">
                <span>Stake {money(b.stake)} @ {fmtOdds(b.totalOdds)}</span>
                <span>Returns <b className="text-white">{money(b.potentialReturn)}</b></span>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2 border-t border-navy-700 p-3">
          <button className="btn-ghost" onClick={() => done(true)}>Keep selections</button>
          <button className="btn-primary" onClick={() => done(false)}>Done</button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-navy-700 px-4 py-3">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-bold uppercase tracking-wider text-white">Bet Slip</h2>
          <span className="rounded-full bg-brand-500 px-2 py-0.5 text-xs font-bold text-navy-950">{slip.length}</span>
        </div>
        <div className="flex items-center gap-1">
          {slip.length > 0 && <button onClick={clearSlip} className="rounded px-2 py-1 text-xs font-semibold text-slate-400 hover:bg-navy-700 hover:text-white">Clear all</button>}
          {onClose && <button onClick={onClose} className="rounded p-1 text-slate-400 hover:bg-navy-700 hover:text-white" aria-label="Close bet slip"><Icon.x className="h-5 w-5" /></button>}
        </div>
      </div>

      {slip.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 py-10 text-center">
          <Icon.ball className="h-10 w-10 text-slate-600" />
          <p className="text-sm font-semibold text-slate-300">Your bet slip is empty</p>
          <p className="text-xs text-slate-500">Tap any odds to add a selection. Build an accumulator by picking from different matches.</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-1 border-b border-navy-700 p-2">
            <button className={`rounded py-1.5 text-xs font-bold ${mode === 'singles' ? 'bg-navy-600 text-white' : 'text-slate-400 hover:text-white'}`} onClick={() => setMode('singles')}>
              Singles ({slip.length})
            </button>
            <button
              className={`rounded py-1.5 text-xs font-bold ${mode === 'acca' ? 'bg-navy-600 text-white' : 'text-slate-400 hover:text-white'} disabled:opacity-40`}
              onClick={() => setMode('acca')}
              disabled={!accaAllowed}
              title={accaAllowed ? '' : 'Accumulators need 2+ selections, each from a different match'}
            >
              Accumulator {accaAllowed ? `@ ${fmtOdds(accaOdds)}` : ''}
            </button>
          </div>
          {!accaAllowed && slip.length >= 2 && (
            <p className="border-b border-navy-700 bg-navy-800/60 px-3 py-2 text-[11px] text-slate-400">
              Selections from the same match can only be placed as singles - their outcomes are linked, so they can't be combined in an accumulator.
            </p>
          )}

          <div className="flex-1 divide-y divide-navy-700 overflow-y-auto">
            {rows.map(({ s, k, qt, unavailable, suspended, changed }) => {
              const stake = stakes[k] ?? '';
              const ret = potentialReturn(toInt(stake), [s.odds]);
              return (
                <div key={k} className={`p-3 ${unavailable ? 'opacity-60' : ''}`}>
                  <div className="flex items-start gap-2">
                    <button onClick={() => removeSelection(k)} className="mt-0.5 rounded text-slate-500 hover:text-white" aria-label="Remove selection"><Icon.x className="h-4 w-4" /></button>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="truncate text-sm font-bold text-white">{s.selectionLabel}</div>
                          <div className="truncate text-xs text-slate-400">{s.marketName}</div>
                        </div>
                        <div className="text-right">
                          {changed && <div className="text-[11px] text-slate-500 line-through tabular-nums">{fmtOdds(changed.from)}</div>}
                          <div className={`text-sm font-bold tabular-nums ${changed ? (changed.to > changed.from ? 'text-brand-400' : 'text-red-400') : 'text-brand-400'}`}>
                            {fmtOdds(changed ? changed.to : s.odds)}
                          </div>
                        </div>
                      </div>
                      <div className="mt-0.5 flex items-center gap-1.5 truncate text-[11px] text-slate-500">
                        {(qt?.live ?? s.live) && <span className="rounded bg-red-600 px-1 text-[9px] font-bold text-white">LIVE{qt?.score ? ` ${qt.score}` : ''}</span>}
                        <span className="truncate">{s.matchLabel}</span>
                      </div>
                      {suspended && <div className="mt-1 text-[11px] font-semibold text-gold-400">Suspended - waiting for the market to reopen</div>}
                      {unavailable && <div className="mt-1 text-[11px] font-semibold text-red-400">No longer available - remove to continue</div>}
                      {mode === 'singles' && !unavailable && (
                        <div className="mt-2 flex items-center gap-2">
                          <div className="w-32"><StakeInput id={`stake-${k}`} value={stake} onChange={(v) => setStakes((st) => ({ ...st, [k]: v }))} /></div>
                          <div className="flex-1 text-right text-[11px] leading-tight text-slate-400">
                            <div>Return <b className="text-white tabular-nums">{money(ret)}</b></div>
                            <div>Profit <span className="tabular-nums">{money(Math.max(0, ret - toInt(stake)))}</span></div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="space-y-2 border-t border-navy-700 bg-navy-900/60 p-3">
            {mode === 'singles' && slip.length > 1 && (
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-slate-400">Same stake on all</span>
                <div className="w-32"><StakeInput id="stake-all" value={allStake} onChange={(v) => { setAllStake(v); setStakes(Object.fromEntries(slip.map((s) => [selKey(s), v]))); }} /></div>
              </div>
            )}
            {mode === 'acca' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>{slip.length}-fold accumulator</span>
                  <span>Combined odds <b className="text-brand-400 tabular-nums">{fmtOdds(accaOdds)}</b></span>
                </div>
                <StakeInput id="stake-acca" value={accaStake} onChange={setAccaStake} />
              </div>
            )}
            <div className="flex gap-1">
              {QUICK.map((qv) => (
                <button
                  key={qv}
                  className="flex-1 rounded bg-navy-700 py-1 text-xs font-semibold text-slate-300 hover:bg-navy-600"
                  onClick={() => {
                    if (mode === 'acca') setAccaStake(penceToInput(toInt(accaStake) + qv));
                    else setStakes(Object.fromEntries(slip.map((s) => [selKey(s), penceToInput(toInt(stakes[selKey(s)]) + qv)])));
                  }}
                >+£{qv / 100}</button>
              ))}
            </div>
            <div className="space-y-1 rounded-md bg-navy-800 p-2.5 text-xs">
              <div className="flex justify-between text-slate-400"><span>Total stake</span><span className="font-semibold text-white tabular-nums">{money(totalStake)}</span></div>
              <div className="flex justify-between text-slate-400"><span>Potential return</span><span className="font-bold text-brand-400 tabular-nums">{money(totalReturn)}</span></div>
              <div className="flex justify-between text-slate-400"><span>Potential profit</span><span className="tabular-nums text-slate-200">{money(Math.max(0, totalReturn - totalStake))}</span></div>
            </div>
            {anyChanged && (
              <button onClick={acceptChanges} className="btn w-full bg-gold-500 text-navy-950 hover:bg-gold-400">Accept odds changes</button>
            )}
            {error && <p className="rounded bg-red-500/10 px-2 py-1.5 text-xs text-red-300">{error}</p>}
            {!error && validation && bets.length > 0 && <p className="text-xs text-gold-400">{validation}</p>}
            <button
              onClick={place}
              disabled={submitting || (user && (!!validation || anyChanged))}
              className="btn-primary h-11 w-full text-base"
            >
              {submitting ? <><Spinner className="h-4 w-4 border-navy-900/40 border-t-navy-950" /> Placing…</> :
                !user ? 'Log in to place bets' :
                  `Place bet${bets.length > 1 ? 's' : ''}${totalStake ? ` · ${money(totalStake)}` : ''}`}
            </button>
            <p className="text-center text-[10px] leading-snug text-slate-500">
              Simulated odds · min {money(rules.minStake)}, max {money(rules.maxStake)} per bet
            </p>
          </div>
        </>
      )}
    </div>
  );
}
