// Brick by Brick art: original cartoon builder pigs, a scruffy wolf, hard
// hat, buzz saw, tools, wooden-sign letters, the three house tiers, logo and
// lobby emblem. Gradients: <BrickDefs />.

import PaintedSym from './PaintedSym.jsx';
import { SLOT_IMG } from '../assets/slots/index.js';
export function BrickDefs() {
  const lg = (id, stops, x2 = 0, y2 = 1) => <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  const rg = (id, stops) => <radialGradient id={id} cx="42%" cy="36%" r="65%">{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {lg('bkHat', [[0, '#fff7ae'], [0.45, '#facc15'], [1, '#b45309']])}
        {lg('bkSaw', [[0, '#ffffff'], [0.5, '#cbd5e1'], [1, '#475569']])}
        {lg('bkWood', [[0, '#e7b77a'], [0.5, '#b7793f'], [1, '#6b3d18']])}
        {lg('bkStraw', [[0, '#fef3c7'], [0.5, '#fcd34d'], [1, '#ca8a04']])}
        {lg('bkBrick', [[0, '#fca5a5'], [0.5, '#dc2626'], [1, '#7f1d1d']])}
        {lg('bkGold', [[0, '#fffbeb'], [0.4, '#fde047'], [1, '#a16207']])}
        {lg('bkSky', [[0, '#38bdf8'], [0.7, '#bae6fd'], [1, '#fef9c3']])}
        {lg('bkGrass', [[0, '#86efac'], [1, '#15803d']])}
        {lg('bkFur', [[0, '#94a3b8'], [1, '#475569']])}
        {lg('bkRed', [[0, '#fca5a5'], [0.5, '#ef4444'], [1, '#991b1b']])}
        {lg('bkBlue', [[0, '#93c5fd'], [0.5, '#2563eb'], [1, '#1e3a8a']])}
        {lg('bkGreen', [[0, '#86efac'], [0.5, '#16a34a'], [1, '#14532d']])}
        {lg('bkPurple', [[0, '#d8b4fe'], [0.5, '#9333ea'], [1, '#581c87']])}
        {rg('bkPink', [[0, '#fde2ea'], [0.6, '#f9a8d4'], [1, '#db2777']])}
        {rg('bkGlow', [[0, 'rgba(250,204,21,0.6)'], [1, 'rgba(250,204,21,0)']])}
      </defs>
    </svg>
  );
}

const T = (t, y, size, fill, stroke = '#3b1d06', len) => <text x="50" y={y} textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize={size} fill={fill} stroke={stroke} strokeWidth={size / 9} paintOrder="stroke" {...(len ? { textLength: len, lengthAdjust: 'spacingAndGlyphs' } : {})}>{t}</text>;

/** A builder pig's head (headwear varies). */
function Pig({ hat }) {
  return (
    <g>
      <path d="M22 34L14 16L34 26Z M78 34L86 16L66 26Z" fill="url(#bkPink)" stroke="#9d174d" strokeWidth="1.8" />
      <ellipse cx="50" cy="56" rx="34" ry="30" fill="url(#bkPink)" stroke="#9d174d" strokeWidth="2" />
      <ellipse cx="50" cy="66" rx="14" ry="10" fill="#f472b6" stroke="#9d174d" strokeWidth="1.8" />
      <ellipse cx="45" cy="66" rx="2.6" ry="4" fill="#831843" /><ellipse cx="55" cy="66" rx="2.6" ry="4" fill="#831843" />
      <circle cx="38" cy="48" r="5.5" fill="#fff" /><circle cx="62" cy="48" r="5.5" fill="#fff" />
      <circle cx="39" cy="49" r="3" fill="#1f2937" /><circle cx="61" cy="49" r="3" fill="#1f2937" />
      <circle cx="40" cy="48" r="1" fill="#fff" /><circle cx="62" cy="48" r="1" fill="#fff" />
      <path d="M40 78Q50 84 60 78" stroke="#831843" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      <ellipse cx="26" cy="64" rx="5" ry="3" fill="#fb7185" opacity=".5" /><ellipse cx="74" cy="64" rx="5" ry="3" fill="#fb7185" opacity=".5" />
      {hat}
    </g>
  );
}

export function HardHat({ glow = true }) {
  return (
    <g>
      {glow && <circle cx="50" cy="54" r="44" fill="url(#bkGlow)" />}
      <path d="M14 66C14 34 32 20 50 20C68 20 86 34 86 66Z" fill="url(#bkHat)" stroke="#78350f" strokeWidth="2.5" />
      <path d="M44 22H56V66H44Z" fill="#fde047" stroke="#a16207" strokeWidth="1.5" />
      <path d="M6 66H94Q96 76 86 76H14Q4 76 6 66Z" fill="#eab308" stroke="#78350f" strokeWidth="2.5" />
      <path d="M24 40Q32 28 44 26" stroke="#fff" strokeWidth="4" opacity=".55" fill="none" strokeLinecap="round" />
    </g>
  );
}

export function BuzzSaw() {
  const teeth = Array.from({ length: 16 }, (_, i) => i * 22.5);
  return (
    <g>
      <circle cx="50" cy="50" r="46" fill="url(#bkGlow)" opacity=".7" />
      <g className="bk-sawspin">
        {teeth.map((a) => <path key={a} d="M50 6L58 16L46 16Z" fill="url(#bkSaw)" stroke="#334155" strokeWidth="1.2" transform={`rotate(${a} 50 50)`} />)}
        <circle cx="50" cy="50" r="36" fill="url(#bkSaw)" stroke="#334155" strokeWidth="2.5" />
        <circle cx="50" cy="50" r="24" fill="none" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" />
        <path d="M30 34Q40 24 54 22" stroke="#fff" strokeWidth="3" opacity=".7" fill="none" strokeLinecap="round" />
      </g>
      <circle cx="50" cy="50" r="10" fill="#ef4444" stroke="#7f1d1d" strokeWidth="2" />
      <circle cx="50" cy="50" r="3" fill="#fff" />
    </g>
  );
}

export function WolfFace({ mood = 'idle' }) {
  const mouth = { idle: 'M38 72Q50 78 62 72', happy: 'M34 68Q50 88 66 68', wow: 'M44 70Q50 84 56 70Z', sad: 'M38 78Q50 70 62 78' }[mood] || 'M38 72Q50 78 62 72';
  return (
    <g>
      <path d="M20 30L12 2L40 20Z M80 30L88 2L60 20Z" fill="url(#bkFur)" stroke="#1e293b" strokeWidth="2" />
      <path d="M22 18L32 22L20 28Z M78 18L68 22L80 28Z" fill="#f9a8d4" />
      <path d="M50 14C74 14 90 32 88 56L76 78L60 92H40L24 78L12 56C10 32 26 14 50 14Z" fill="url(#bkFur)" stroke="#1e293b" strokeWidth="2.2" />
      <path d="M50 46C62 46 70 56 70 66C70 80 60 88 50 88C40 88 30 80 30 66C30 56 38 46 50 46Z" fill="#e2e8f0" />
      <path d="M28 38L44 44M72 38L56 44" stroke="#1e293b" strokeWidth="3.5" strokeLinecap="round" />
      <ellipse cx="38" cy="48" rx="6" ry={mood === 'wow' ? 7 : 5} fill="#fde047" stroke="#1e293b" strokeWidth="1.5" /><ellipse cx="62" cy="48" rx="6" ry={mood === 'wow' ? 7 : 5} fill="#fde047" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="39" cy="49" r="2.6" fill="#111" /><circle cx="61" cy="49" r="2.6" fill="#111" />
      <ellipse cx="50" cy="60" rx="7" ry="5" fill="#111" />
      <path d={mouth} stroke="#111" strokeWidth="3" fill={mood === 'happy' || mood === 'wow' ? '#7f1d1d' : 'none'} strokeLinecap="round" />
      {mood === 'happy' && <path d="M42 70L44 76L46 70M54 70L56 76L58 70" fill="#fff" />}
    </g>
  );
}

const Sign = ({ ch, fill }) => (
  <g>
    <path d="M10 22H90L86 82H14Z" fill="url(#bkWood)" stroke="#5b2d0c" strokeWidth="2.5" />
    <path d="M14 38H88M15 56H87M16 72H86" stroke="#5b2d0c" strokeOpacity=".25" strokeWidth="1.5" />
    <circle cx="18" cy="28" r="2.2" fill="#5b2d0c" /><circle cx="82" cy="28" r="2.2" fill="#5b2d0c" />
    {T(ch, 74, ch.length > 1 ? 46 : 58, fill, '#3b1d06', ch.length > 1 ? 58 : undefined)}
  </g>
);

export function House({ tier }) {
  if (tier === 1) return (
    <g>
      <path d="M14 50L50 16L86 50Z" fill="url(#bkStraw)" stroke="#a16207" strokeWidth="2.5" />
      {[24, 34, 44, 56, 66, 76].map((x) => <path key={x} d={`M${x} ${50 - Math.abs(50 - x) * 0.7}L${x - 4} 52`} stroke="#ca8a04" strokeWidth="1.5" />)}
      <rect x="20" y="50" width="60" height="40" fill="url(#bkStraw)" stroke="#a16207" strokeWidth="2.5" />
      {[28, 38, 48, 58, 68].map((x) => <path key={x} d={`M${x} 52V88`} stroke="#ca8a04" strokeWidth="1.5" />)}
      <rect x="42" y="64" width="16" height="26" rx="6" fill="#92400e" />
    </g>
  );
  if (tier === 2) return (
    <g>
      <path d="M12 50L50 14L88 50Z" fill="url(#bkWood)" stroke="#5b2d0c" strokeWidth="2.5" />
      <rect x="18" y="50" width="64" height="40" fill="url(#bkWood)" stroke="#5b2d0c" strokeWidth="2.5" />
      {[58, 66, 74, 82].map((y) => <path key={y} d={`M18 ${y}H82`} stroke="#5b2d0c" strokeOpacity=".4" strokeWidth="1.5" />)}
      <rect x="26" y="58" width="14" height="12" fill="#bae6fd" stroke="#5b2d0c" strokeWidth="2" />
      <rect x="54" y="62" width="16" height="28" rx="2" fill="#78350f" stroke="#3b1d06" strokeWidth="1.5" />
    </g>
  );
  return (
    <g>
      <circle cx="50" cy="50" r="48" fill="url(#bkGlow)" />
      <path d="M10 48L50 10L90 48Z" fill="#7f1d1d" stroke="#450a0a" strokeWidth="2.5" />
      <rect x="66" y="16" width="10" height="20" fill="url(#bkBrick)" stroke="#450a0a" strokeWidth="1.5" />
      <rect x="16" y="48" width="68" height="44" fill="url(#bkBrick)" stroke="#450a0a" strokeWidth="2.5" />
      {[56, 64, 72, 80, 88].map((y, i) => <g key={y}><path d={`M16 ${y}H84`} stroke="#fecaca" strokeOpacity=".45" strokeWidth="1.2" />{[0, 1, 2, 3].map((k) => <path key={k} d={`M${24 + k * 16 + (i % 2) * 8} ${y - 8}V${y}`} stroke="#fecaca" strokeOpacity=".45" strokeWidth="1.2" />)}</g>)}
      <rect x="24" y="58" width="14" height="12" fill="#fde68a" stroke="#450a0a" strokeWidth="2" />
      <rect x="44" y="64" width="14" height="28" rx="6" fill="#422006" stroke="#1c0a02" strokeWidth="1.5" />
      <rect x="64" y="58" width="12" height="12" fill="#fde68a" stroke="#450a0a" strokeWidth="2" />
    </g>
  );
}

export const BRICK_ART = {
  P1: <Pig hat={<g><path d="M20 30C20 8 80 8 80 30Z" fill="url(#bkHat)" stroke="#78350f" strokeWidth="2" /><path d="M12 30H88V36H12Z" fill="#eab308" stroke="#78350f" strokeWidth="2" /></g>} />,
  P2: <Pig hat={<g><path d="M22 32C22 12 78 12 78 32Z" fill="url(#bkBlue)" stroke="#1e3a8a" strokeWidth="2" /><path d="M60 30H94V36H60Z" fill="#1e40af" stroke="#1e3a8a" strokeWidth="1.5" /><path d="M86 52L96 92" stroke="#b45309" strokeWidth="4" strokeLinecap="round" /><path d="M88 46H100V54H88Z" fill="#64748b" /></g>} />,
  P3: <Pig hat={<g><ellipse cx="44" cy="22" rx="30" ry="10" fill="url(#bkPurple)" stroke="#581c87" strokeWidth="2" /><circle cx="48" cy="12" r="3" fill="#581c87" /><path d="M86 90L94 56" stroke="#a16207" strokeWidth="4" /><path d="M90 52L98 56L96 64L88 60Z" fill="#ef4444" /></g>} />,
  TOOLBOX: (
    <g>
      <path d="M30 34Q30 18 50 18Q70 18 70 34" stroke="#334155" strokeWidth="6" fill="none" />
      <rect x="10" y="34" width="80" height="50" rx="6" fill="url(#bkRed)" stroke="#7f1d1d" strokeWidth="2.5" />
      <rect x="10" y="48" width="80" height="8" fill="#991b1b" />
      <rect x="44" y="46" width="12" height="12" rx="2" fill="url(#bkGold)" stroke="#78350f" />
      <path d="M22 28L34 12L38 16L28 30Z" fill="#94a3b8" stroke="#334155" />
    </g>
  ),
  TAPE: (
    <g>
      <rect x="12" y="22" width="62" height="62" rx="16" fill="url(#bkHat)" stroke="#78350f" strokeWidth="2.5" />
      <circle cx="43" cy="53" r="18" fill="#1f2937" stroke="#facc15" strokeWidth="3" />
      <circle cx="43" cy="53" r="6" fill="#facc15" />
      <path d="M70 70H94V80H70Z" fill="#fef08a" stroke="#a16207" strokeWidth="1.5" />
      {[74, 78, 82, 86, 90].map((x) => <path key={x} d={`M${x} 70V${x % 8 === 2 ? 76 : 73}`} stroke="#1f2937" strokeWidth="1" />)}
    </g>
  ),
  A: <Sign ch="A" fill="url(#bkRed)" />, K: <Sign ch="K" fill="url(#bkBlue)" />, Q: <Sign ch="Q" fill="url(#bkPurple)" />, J: <Sign ch="J" fill="url(#bkGreen)" />,
  T: <Sign ch="10" fill="url(#bkHat)" />, N: <Sign ch="9" fill="#e2e8f0" />,
  WILD: <g><rect x="4" y="4" width="92" height="92" rx="12" fill="url(#bkSky)" /><g transform="translate(10 0) scale(.8)"><WolfFace mood="happy" /></g><rect x="14" y="74" width="72" height="20" rx="6" fill="#7f1d1d" stroke="url(#bkGold)" strokeWidth="2.5" />{T('WILD', 90, 17, 'url(#bkGold)', '#3b0a0a', 50)}</g>,
  HAT: <HardHat />,
  SAW: <BuzzSaw />,
};
export const BRICK_NAMES = { P1: 'Foreman Pig', P2: 'Carpenter Pig', P3: 'Painter Pig', TOOLBOX: 'Toolbox', TAPE: 'Tape measure', A: 'A', K: 'K', Q: 'Q', J: 'J', T: '10', N: '9', WILD: 'Wolf Wild', HAT: 'Hard hat', SAW: 'Buzz saw' };

export function BrickSym({ s, className = '' }) {
  if (!s) return null;
  if (SLOT_IMG.brick[s]) {
    const tier = ['HAT', 'SAW', 'WILD'].includes(s) ? 'special' : ['A', 'K', 'Q', 'J', 'T', 'N'].includes(s) ? 'low' : ['TOOLBOX', 'TAPE'].includes(s) ? 'mid' : 'premium';
    return <PaintedSym src={SLOT_IMG.brick[s]} alt={BRICK_NAMES[s] || s} tier={tier} glow={{ HAT: '#facc15', SAW: '#f87171', WILD: '#a78bfa' }[s]} className={className} />;
  }
  const hi = s === 'HAT' || s === 'SAW' || s === 'WILD', pig = s[0] === 'P';
  return (
    <div className={`relative h-full w-full rounded-lg ${hi ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(253,224,71,0.45),rgba(120,53,15,0.92))] ring-2 ring-amber-300/80' : pig ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(253,242,248,0.9),rgba(190,24,93,0.55))] ring-1 ring-pink-300/60' : 'bg-[radial-gradient(circle_at_50%_35%,rgba(255,251,235,0.95),rgba(214,170,110,0.85))] ring-1 ring-amber-900/30'} ${className}`}>
      <svg viewBox="0 0 100 100" className="h-full w-full p-[6%]" role="img" aria-label={BRICK_NAMES[s] || s}>{BRICK_ART[s]}</svg>
    </div>
  );
}

export function BrickLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 320 96" className={className} aria-label="Brick by Brick">
      <g transform="translate(8 14) scale(.62)"><House tier={3} /></g>
      <g transform="translate(250 14) scale(.62)"><HardHat glow={false} /></g>
      <text x="160" y="52" textAnchor="middle" fontFamily="'Lilita One'" fontSize="40" textLength="200" lengthAdjust="spacingAndGlyphs" fill="url(#bkBrick)" stroke="#fff" strokeWidth="5" paintOrder="stroke">BRICK</text>
      <text x="160" y="84" textAnchor="middle" fontFamily="'Lilita One'" fontSize="30" textLength="170" lengthAdjust="spacingAndGlyphs" fill="url(#bkHat)" stroke="#78350f" strokeWidth="4" paintOrder="stroke">BY BRICK</text>
    </svg>
  );
}

export const BRICK_LOBBY = (
  <g>
    <rect width="100" height="100" fill="url(#bkSky)" />
    <path d="M0 76H100V100H0Z" fill="url(#bkGrass)" />
    <g transform="translate(6 34) scale(.42)"><House tier={1} /></g>
    <g transform="translate(34 28) scale(.48)"><House tier={2} /></g>
    <g transform="translate(62 22) scale(.54)"><House tier={3} /></g>
    <g transform="translate(36 62) scale(.3)"><HardHat glow={false} /></g>
  </g>
);
