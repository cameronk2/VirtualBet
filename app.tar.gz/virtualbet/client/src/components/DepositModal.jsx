import { useEffect, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { duration, money } from '../lib/format.js';
import { useNow } from '../lib/hooks.js';
import { Icon, Modal, Spinner } from './ui.jsx';

export function DailyBonusButton({ className = '' }) {
  const { user, setUser, toast } = useApp();
  const now = useNow(1000);
  const [busy, setBusy] = useState(false);
  if (!user) return null;
  const next = user.dailyBonus?.nextAvailableAt;
  const available = !next || next <= now;
  const claim = async () => {
    setBusy(true);
    try {
      const d = await api.post('/api/wallet/daily-bonus');
      setUser(d.user);
      toast(`+${money(user.dailyBonus.amount)} free virtual daily bonus added`, 'success');
    } catch (e) {
      toast(e.message, 'error');
    } finally { setBusy(false); }
  };
  return (
    <button onClick={claim} disabled={!available || busy} className={`btn bg-gold-500 text-navy-950 hover:bg-gold-400 disabled:bg-navy-700 disabled:text-slate-400 disabled:opacity-100 ${className}`}>
      <Icon.gift className="h-4 w-4" />
      {available ? `Claim free daily bonus (+${money(user.dailyBonus?.amount ?? 500)})` : `Next daily bonus in ${duration(next - now)}`}
    </button>
  );
}

export default function DepositModal() {
  const { depositOpen, setDepositOpen, config, user, setUser } = useApp();
  const [step, setStep] = useState('choose');
  const [pkg, setPkg] = useState(null);
  const [amount, setAmount] = useState(2000);
  const [ack, setAck] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  useEffect(() => {
    if (depositOpen) { setStep('choose'); setPkg(null); setAck(false); setError(null); setResult(null); }
  }, [depositOpen]);

  if (!user) return null;
  const packages = config?.rules?.depositPackages || [];
  const min = config?.rules?.depositMin ?? 500, max = config?.rules?.depositMax ?? 100000, inc = config?.rules?.depositStep ?? 100;
  const clamp = (v) => Math.min(max, Math.max(min, Math.round(v / inc) * inc));
  const pct = ((amount - min) / (max - min)) * 100;

  const confirm = async () => {
    setBusy(true);
    setError(null);
    try {
      const before = user.balance;
      const d = await api.post('/api/wallet/deposit', { amount: pkg, acknowledged: true });
      setUser(d.user);
      setResult({ before, after: d.user.balance });
      setStep('done');
    } catch (e) {
      setError(e.message);
    } finally { setBusy(false); }
  };

  return (
    <Modal open={depositOpen} onClose={() => setDepositOpen(false)} title={step === 'confirm' ? 'Confirm free deposit' : step === 'done' ? 'Deposit added' : 'Deposit (virtual money)'}>
      {step === 'choose' && (
        <div className="space-y-4">
          <div className="rounded-md border border-gold-500/30 bg-gold-500/10 p-3 text-xs leading-relaxed text-gold-400">
            These deposits are <b>free virtual money</b> to practise with realistic amounts. VirtualBet never takes real money - there are no card details, payments, withdrawals or prizes.
          </div>
          <div className="flex items-center justify-between rounded-md bg-navy-800 px-3 py-2 text-sm">
            <span className="text-slate-400">Current balance</span>
            <span className="font-bold text-white tabular-nums">{money(user.balance)}</span>
          </div>
          <div className="rounded-xl border border-navy-600 bg-navy-800 p-4">
            <div className="flex items-center justify-between gap-3">
              <button type="button" onClick={() => setAmount((a) => clamp(a - inc))} disabled={amount <= min}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-navy-700 text-2xl font-bold text-white hover:bg-navy-600 disabled:opacity-40" aria-label="£1 less">−</button>
              <div className="text-center">
                <div className="font-cond text-4xl font-extrabold tabular-nums text-white">{money(amount).replace('.00', '')}</div>
                <div className="text-[11px] font-semibold uppercase tracking-wider text-brand-400">Free · virtual</div>
              </div>
              <button type="button" onClick={() => setAmount((a) => clamp(a + inc))} disabled={amount >= max}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-navy-700 text-2xl font-bold text-white hover:bg-navy-600 disabled:opacity-40" aria-label="£1 more">+</button>
            </div>
            <input type="range" min={min / 100} max={max / 100} step={5} value={amount / 100}
              onChange={(e) => setAmount(clamp(Number(e.target.value) * 100))} /* slider snaps to £5; −/+ fine-tune by £1 */
              className="vb-range mt-4 w-full" style={{ '--pct': `${pct}%` }}
              aria-label="Deposit amount" aria-valuetext={money(amount)} />
            <div className="mt-1 flex justify-between text-[11px] font-semibold text-slate-500"><span>{money(min).replace('.00', '')}</span><span>{money(max).replace('.00', '')}</span></div>
            <div className="mt-3 flex flex-wrap justify-center gap-1.5">
              {packages.map((p) => (
                <button key={p} type="button" onClick={() => setAmount(p)} className={`chip ${amount === p ? 'chip-active' : ''}`}>{money(p).replace('.00', '').replace('£1,000', '£1k')}</button>
              ))}
            </div>
          </div>
          <button className="btn-primary h-12 w-full text-base" onClick={() => { setPkg(amount); setStep('confirm'); }}>Continue · {money(amount)}</button>
          <div className="border-t border-navy-700 pt-4">
            <DailyBonusButton className="w-full" />
          </div>
        </div>
      )}

      {step === 'confirm' && (
        <div className="space-y-4">
          <div className="rounded-lg bg-navy-800 p-4 text-center">
            <div className="text-xs uppercase tracking-wider text-slate-400">You are adding</div>
            <div className="mt-1 text-3xl font-extrabold text-white tabular-nums">{money(pkg)}</div>
            <div className="text-sm text-slate-400">virtual money · You pay: <b className="text-brand-400">nothing</b></div>
          </div>
          <ul className="space-y-1.5 text-sm text-slate-300">
            <li>• This is <b>not real money</b> and has no value.</li>
            <li>• It can't be withdrawn, exchanged for cash or prizes, or transferred.</li>
            <li>• This transaction will be recorded in your wallet history.</li>
          </ul>
          <label className="flex cursor-pointer items-start gap-2 rounded-md border border-navy-600 p-3 text-sm text-slate-200">
            <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="mt-0.5 h-4 w-4 accent-brand-500" />
            I understand this is virtual money and worth nothing.
          </label>
          {error && <p className="text-sm text-red-400">{error}</p>}
          <div className="grid grid-cols-2 gap-2">
            <button className="btn-ghost" onClick={() => setStep('choose')}>Back</button>
            <button className="btn-primary" disabled={!ack || busy} onClick={confirm}>
              {busy ? <Spinner className="h-4 w-4" /> : 'Add free virtual deposit'}
            </button>
          </div>
        </div>
      )}

      {step === 'done' && result && (
        <div className="space-y-4 text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand-500 text-navy-950"><Icon.check className="h-8 w-8" /></div>
          <div>
            <div className="text-lg font-bold text-white">+{money(pkg)} virtual deposit added</div>
            <div className="mt-1 text-sm text-slate-400">{money(result.before)} → <b className="text-white">{money(result.after)}</b></div>
          </div>
          <p className="text-xs text-slate-500">Remember: practising with realistic virtual amounts shows how quickly real losses would build up. Take breaks.</p>
          <button className="btn-primary w-full" onClick={() => setDepositOpen(false)}>Done</button>
        </div>
      )}
    </Modal>
  );
}
