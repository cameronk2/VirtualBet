import { useMemo } from 'react';
import { Sym, SYMBOLS } from './SlotArt2.jsx';

const strip = (game, n) => Array.from({ length: n }, () => {
  const list = SYMBOLS[game];
  const s = list[Math.floor(Math.random() * list.length)];
  return s === 'COIN' ? { s, v: [100, 200, 500][Math.floor(Math.random() * 3)] } : { s };
});

function Reel({ game, cells, spinning, index, bet, lit, dim, overlay, rows, turbo }) {
  const fake = useMemo(() => strip(game, 10), [spinning, game]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div style={{ aspectRatio: `1 / ${rows}` }} className="relative overflow-hidden rounded-lg bg-black/35 ring-1 ring-white/10">
      {spinning ? (
        <div className={`${turbo ? 'animate-reel-spin-fast' : 'animate-reel-spin'} will-change-transform`} style={{ animationDelay: `${-index * 50}ms` }}>
          {[...fake, ...fake].map((c, i) => <div key={i} className="aspect-square p-1 opacity-80 blur-[1.5px]"><Sym {...c} bet={bet} game={game} /></div>)}
        </div>
      ) : (
        <div className="animate-reel-stop">
          {cells.map((c, row) => {
            const k = `${index}-${row}`;
            const on = lit?.has(k);
            return (
              <div key={row} className={`relative aspect-square p-1 transition-opacity duration-300 ${dim && !on ? 'opacity-35' : ''}`}>
                {on && <div className="animate-win-pulse absolute inset-0.5 rounded-md bg-gold-400/20 ring-2 ring-gold-400" />}
                <div className={`relative h-full w-full ${on ? 'animate-symbol-pop' : ''}`}>{c ? <Sym {...c} bet={bet} game={game} /> : null}</div>
              </div>
            );
          })}
        </div>
      )}
      {overlay}
    </div>
  );
}

/** A reels x rows window. `stopped[i]` controls each reel's spin. */
export default function Reels({ game, grid, stopped, bet, lit, overlays = [], rows = 3, turbo }) {
  const dim = lit && lit.size > 0;
  return (
    <div className="mx-auto grid gap-1.5" style={{ gridTemplateColumns: `repeat(${grid.length}, minmax(0, 1fr))`, maxWidth: `min(100%, calc((100dvh - 430px) * ${grid.length / rows}))` }}>
      {grid.map((col, i) => <Reel key={i} index={i} game={game} cells={col} spinning={!stopped[i]} bet={bet} lit={lit} dim={dim} overlay={overlays[i]} rows={rows} turbo={turbo} />)}
    </div>
  );
}

/** Runs the spin animation: reels stop left to right, then `onDone`. */
export function runReels({ setStopped, reels = 5, base = 600, gap = 220, turbo, onDone, timers }) {
  const b = turbo ? 250 : base, g = turbo ? 90 : gap;
  setStopped(Array(reels).fill(false));
  for (let i = 0; i < reels; i++) timers.push(setTimeout(() => setStopped((s) => s.map((x, j) => (j === i ? true : x))), b + i * g));
  timers.push(setTimeout(onDone, b + (reels - 1) * g + 250));
}
