// Full-screen ("pop-out") play for phones. Every game page can render its
// play area inside <PopoutFrame>, which covers the whole screen (above the
// site's header and tab bar) and scales the game to fit the visible height, so
// nothing needs scrolling. Every game opens this way on every device.
import { lockScroll } from '../lib/scrollLock.js';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../state/AppContext.jsx';
import { money } from '../lib/format.js';


/** [on, setOn]: every game opens full screen on every device; ✕ leaves it for this visit only. */
export function usePopout() {
  const [on, setOn] = useState(true);
  const set = (v) => { setOn(v); window.dispatchEvent(new CustomEvent('vb-pop', { detail: v })); };
  useEffect(() => { const h = (e) => setOn(e.detail); window.addEventListener('vb-pop', h); return () => window.removeEventListener('vb-pop', h); }, []);
  return [on, set];
}

/**
 * Scales its content down (never up) to fit the space available. It keeps the
 * largest height it has seen, so the game doesn't pulse in size when a result
 * banner appears; very tall content falls back to scrolling below 60%.
 */
function FitBox({ children }) {
  const outer = useRef(null), inner = useRef(null), maxH = useRef(0), lastW = useRef(0);
  const [t, setT] = useState({ s: 1, x: 0, y: 0, scroll: false, h: 0 });
  useLayoutEffect(() => {
    const o = outer.current, i = inner.current;
    if (!o || !i) return undefined;
    const fit = () => {
      const W = o.clientWidth, H = o.clientHeight;
      if (W !== lastW.current) { lastW.current = W; maxH.current = 0; }
      maxH.current = Math.max(maxH.current, i.offsetHeight);
      const h = maxH.current || 1;
      let s = Math.min(1, H / h);
      const scroll = s < 0.6;
      if (scroll) s = 0.6;
      setT({ s, x: (W - W * s) / 2, y: scroll ? 0 : Math.max(0, (H - h * s) / 2), scroll, h });
    };
    const ro = new ResizeObserver(fit); ro.observe(o); ro.observe(i); fit();
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={outer} className={`relative min-h-0 flex-1 ${t.scroll ? 'overflow-y-auto overscroll-contain' : 'overflow-hidden'}`}>
      <div style={{ height: t.scroll ? t.h * t.s : undefined }} />
      <div ref={inner} className="absolute left-0 top-0 w-full origin-top-left" style={{ transform: `translate(${t.x}px, ${t.y}px) scale(${t.s})`, transition: 'transform .25s ease-out' }}>{children}</div>
    </div>
  );
}

/** The full-screen frame: a slim header (exit, title, balance, extras) and the game, fitted. */
export function PopoutFrame({ title, label, onExit, extras, children, bg = 'bg-navy-950' }) {
  const { user } = useApp();
  useEffect(() => lockScroll(), []); // the page behind can't scroll while the game is full screen
  return createPortal(
    <div className={`vb-pop fixed inset-0 z-[45] flex flex-col px-2 ${bg}`} role="dialog" aria-label={`${label || (typeof title === 'string' ? title : 'Game')} full screen`}
      style={{ paddingTop: 'max(8px, env(safe-area-inset-top))', paddingBottom: 'max(6px, env(safe-area-inset-bottom))', height: '100dvh' }}>
      <div className="mx-auto mb-1.5 flex w-full max-w-[640px] shrink-0 items-center gap-2 lg:max-w-[860px]">
        <button type="button" onClick={onExit} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-black/40 text-lg text-white ring-1 ring-white/15" aria-label="Exit full screen">✕</button>
        <div className="min-w-0 truncate font-display text-base leading-none tracking-wide text-white min-[380px]:text-lg">{title}</div>
        <div className="ml-auto shrink-0 text-right leading-tight"><div className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Balance</div><div className="font-cond text-base font-bold tabular-nums text-white">{money(user?.balance ?? 0)}</div></div>
        {extras}
      </div>
      <div className="mx-auto flex min-h-0 w-full max-w-[640px] flex-1 flex-col lg:max-w-[860px]"><FitBox>{children}</FitBox></div>
    </div>,
    document.body,
  );
}

/** Shown on the page while the game is open full screen. */
export function PopoutPlaceholder({ title, onOpen }) {
  return (
    <div className="card flex flex-col items-center gap-3 px-4 py-10 text-center">
      <p className="text-sm text-slate-300">{title} is open in full screen.</p>
      <button type="button" onClick={onOpen} className="btn-primary px-6">Return to the game</button>
    </div>
  );
}

/** Small button to switch to full screen (desktop and phones that turned it off). */
export function PopoutButton({ onOpen }) {
  return <button type="button" onClick={onOpen} className="rounded-md bg-black/40 px-2.5 py-1 text-xs font-semibold text-slate-200 ring-1 ring-white/15 hover:bg-black/60" aria-label="Play full screen">⤢ Full screen</button>;
}

/** Header button that opens full screen (shares state with PopoutWrap on the same page). */
export function PopoutToggle() {
  const [on, set] = usePopout();
  return on ? null : <PopoutButton onOpen={() => set(true)} />;
}

/** Wraps a page's play area: rendered in place, or full screen when switched on. */
export function PopoutWrap({ title, extras, bg, children }) {
  const [on, set] = usePopout();
  if (!on) return children;
  return (
    <>
      <PopoutPlaceholder title={title} onOpen={() => set(true)} />
      <PopoutFrame title={title} extras={extras} bg={bg} onExit={() => set(false)}><div className="space-y-3">{children}</div></PopoutFrame>
    </>
  );
}
