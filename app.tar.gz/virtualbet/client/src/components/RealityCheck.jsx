import { useEffect, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { duration, signed } from '../lib/format.js';
import { Modal } from './ui.jsx';

// A neutral, user-configured reality check: shows time spent and the
// session's virtual profit/loss. It never encourages more betting.
export default function RealityCheck() {
  const { user, sessionStart, logout } = useApp();
  const [shown, setShown] = useState(null);
  const minutes = user?.realityCheckMinutes || 0;

  useEffect(() => {
    if (!user || !minutes) return undefined;
    const interval = minutes * 60000;
    const elapsed = Date.now() - sessionStart;
    const nextIn = interval - (elapsed % interval);
    const t = setTimeout(async () => {
      let session = null;
      try { session = (await api.get(`/api/stats?sessionStart=${sessionStart}`)).session; } catch { /* ignore */ }
      setShown({ at: Date.now(), session });
    }, nextIn);
    return () => clearTimeout(t);
  }, [user?.id, minutes, sessionStart, shown]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!shown) return null;
  const pl = shown.session?.p ?? 0;
  return (
    <Modal open title="Reality check" onClose={() => setShown(null)}>
      <div className="space-y-4">
        <p className="text-sm text-slate-300">You've been on VirtualBet for <b className="text-white">{duration(shown.at - sessionStart)}</b>.</p>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-md bg-navy-800 p-3">
            <div className="text-[11px] uppercase text-slate-400">Session P/L</div>
            <div className={`text-xl font-bold ${pl > 0 ? 'text-brand-400' : pl < 0 ? 'text-red-400' : 'text-white'}`}>{signed(pl)}</div>
          </div>
          <div className="rounded-md bg-navy-800 p-3">
            <div className="text-[11px] uppercase text-slate-400">Bets settled</div>
            <div className="text-xl font-bold text-white">{shown.session?.n ?? 0}</div>
          </div>
        </div>
        <p className="text-xs text-slate-500">This is virtual money. With real money, the same results would be real gains or losses.</p>
        <div className="grid grid-cols-2 gap-2">
          <button className="btn-ghost" onClick={() => { setShown(null); logout(); }}>Take a break</button>
          <button className="btn-ghost" onClick={() => setShown(null)}>Continue</button>
        </div>
      </div>
    </Modal>
  );
}
