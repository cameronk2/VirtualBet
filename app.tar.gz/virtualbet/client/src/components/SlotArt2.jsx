// Original symbol artwork for Nebula Clusters, Coin Vault, Fruit Shack
// and Starlight Observatory (inline SVG; no third-party assets).
import { JACKPOTS } from '../../../server/games/slots2.js';

const Svg = ({ children }) => <svg viewBox="0 0 64 64" className="h-full w-full" aria-hidden="true">{children}</svg>;

function Letter({ ch, a, b }) {
  const id = `l${ch}${a.slice(1)}`;
  return (
    <Svg>
      <defs><linearGradient id={id} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient></defs>
      <text x="32" y="45" textAnchor="middle" fontSize={ch === '10' ? 30 : 38} fontWeight="900" fontFamily="'Barlow Condensed', system-ui, sans-serif" fill={`url(#${id})`} stroke="#0b1520" strokeWidth="2.5" paintOrder="stroke">{ch}</text>
    </Svg>
  );
}
const LETTERS = { 10: ['#7dd3fc', '#0369a1'], J: ['#86efac', '#15803d'], Q: ['#f9a8d4', '#be185d'], K: ['#fcd34d', '#b45309'], A: ['#c4b5fd', '#6d28d9'] };

// ── Nebula gems ──
const GEM = {
  RED: ['#fb7185', '#be123c', 'M32 6l22 14v24L32 58 10 44V20z'],
  ORG: ['#fdba74', '#c2410c', 'M32 6l24 26-24 26L8 32z'],
  YEL: ['#fde047', '#a16207', 'M32 4l8 18 20 2-15 13 5 20-18-11-18 11 5-20L4 24l20-2z'],
  GRN: ['#86efac', '#15803d', 'M16 10h32l10 22-10 22H16L6 32z'],
  BLU: ['#7dd3fc', '#1d4ed8', 'M32 6c14 0 26 12 26 26S46 58 32 58 6 46 6 32 18 6 32 6z'],
  PUR: ['#e9d5ff', '#7e22ce', 'M32 4l10 14 18 4-12 14 2 18-18-8-18 8 2-18L4 22l18-4z'],
};
function Gem({ s }) {
  const [a, b, d] = GEM[s];
  return (
    <Svg>
      <defs><radialGradient id={`g${s}`} cx=".35" cy=".3" r=".8"><stop offset="0" stopColor="#fff" /><stop offset=".25" stopColor={a} /><stop offset="1" stopColor={b} /></radialGradient></defs>
      <path d={d} fill={`url(#g${s})`} stroke="#fff" strokeOpacity=".55" strokeWidth="2" strokeLinejoin="round" />
      <path d={d} fill="none" stroke="#0b1520" strokeOpacity=".35" strokeWidth="1" transform="translate(32 32) scale(.6) translate(-32 -32)" />
    </Svg>
  );
}
const Comet = () => (
  <Svg>
    <path d="M8 56C18 40 30 28 44 20" stroke="#a5f3fc" strokeWidth="7" strokeLinecap="round" opacity=".35" />
    <path d="M14 52C22 40 32 30 44 22" stroke="#e0f2fe" strokeWidth="3" strokeLinecap="round" opacity=".7" />
    <circle cx="46" cy="18" r="11" fill="#e0f2fe" stroke="#38bdf8" strokeWidth="3" />
    <circle cx="43" cy="15" r="3" fill="#fff" />
    <rect x="8" y="50" width="48" height="12" rx="3" fill="#0b1520" stroke="#38bdf8" strokeWidth="1.5" />
    <text x="32" y="59" textAnchor="middle" fontSize="8.5" fontWeight="900" fill="#7dd3fc" fontFamily="system-ui">COMET</text>
  </Svg>
);

// ── Coin Vault ──
const Bell = () => (<Svg><path d="M32 8c-11 0-16 9-16 20v10l-6 8h44l-6-8V28c0-11-5-20-16-20z" fill="#facc15" stroke="#854d0e" strokeWidth="2.5" /><circle cx="32" cy="52" r="5" fill="#ca8a04" stroke="#854d0e" strokeWidth="2" /><path d="M24 20c2-4 5-6 8-6" stroke="#fef9c3" strokeWidth="3" strokeLinecap="round" /></Svg>);
const Bar = () => (<Svg><rect x="6" y="20" width="52" height="24" rx="5" fill="#111827" stroke="#facc15" strokeWidth="3" /><text x="32" y="39" textAnchor="middle" fontSize="18" fontWeight="900" fill="#facc15" fontFamily="'Barlow Condensed', system-ui">BAR</text></Svg>);
const Seven = ({ c = '#ef4444' }) => (<Svg><path d="M14 12h36v8L30 56H18l18-34H14z" fill={c} stroke="#450a0a" strokeWidth="3" strokeLinejoin="round" /><path d="M18 15h28" stroke="#fecaca" strokeWidth="2" /></Svg>);
const VaultWild = () => (<Svg><circle cx="32" cy="30" r="24" fill="#1f2937" stroke="#facc15" strokeWidth="3" /><circle cx="32" cy="30" r="14" fill="none" stroke="#9ca3af" strokeWidth="3" />{[0, 60, 120, 180, 240, 300].map((a) => <rect key={a} x="30" y="4" width="4" height="10" fill="#facc15" transform={`rotate(${a} 32 30)`} />)}<rect x="10" y="48" width="44" height="13" rx="3" fill="#0b1520" stroke="#facc15" strokeWidth="1.5" /><text x="32" y="58" textAnchor="middle" fontSize="9" fontWeight="900" fill="#facc15" fontFamily="system-ui">WILD</text></Svg>);
export function Coin({ v, bet }) {
  const jack = typeof v === 'string';
  const label = jack ? v : (() => { const p = Math.floor(((bet || 100) * v) / 100); return `£${p % 100 === 0 ? p / 100 : (p / 100).toFixed(2)}`; })();
  const fill = jack ? { MINI: '#38bdf8', MINOR: '#a78bfa', MAJOR: '#f43f5e', GRAND: '#facc15' }[v] : '#fbbf24';
  return (
    <Svg>
      <defs><radialGradient id={`c${jack ? v : 'n'}`} cx=".35" cy=".3" r=".8"><stop offset="0" stopColor="#fff7c2" /><stop offset=".4" stopColor={fill} /><stop offset="1" stopColor="#78350f" /></radialGradient></defs>
      <circle cx="32" cy="32" r="27" fill={`url(#c${jack ? v : 'n'})`} stroke="#78350f" strokeWidth="2.5" />
      <circle cx="32" cy="32" r="21" fill="none" stroke="#fff" strokeOpacity=".4" strokeWidth="1.5" strokeDasharray="3 3" />
      <text x="32" y={jack ? 36 : 37} textAnchor="middle" fontSize={jack ? 11 : label.length > 5 ? 11 : 14} fontWeight="900" fill="#451a03" fontFamily="'Barlow Condensed', system-ui">{label}</text>
    </Svg>
  );
}
export const jackpotLabel = (v) => (typeof v === 'string' ? `${v} ${JACKPOTS[v] / 100}x` : null);

// ── Fruit Shack ──
const FRUIT = {
  CHERRY: (<Svg><path d="M26 34c2-12 8-20 16-26M38 36c0-10 2-18 4-28" stroke="#15803d" strokeWidth="3" fill="none" /><path d="M40 10c6-4 12-2 14 2-6 2-10 2-14-2z" fill="#22c55e" /><circle cx="24" cy="44" r="12" fill="#dc2626" stroke="#7f1d1d" strokeWidth="2" /><circle cx="42" cy="46" r="12" fill="#dc2626" stroke="#7f1d1d" strokeWidth="2" /><circle cx="20" cy="39" r="3" fill="#fecaca" /><circle cx="38" cy="41" r="3" fill="#fecaca" /></Svg>),
  LEMON: (<Svg><ellipse cx="32" cy="34" rx="24" ry="17" fill="#fde047" stroke="#a16207" strokeWidth="2.5" /><path d="M8 34l-4 0M56 34h4" stroke="#a16207" strokeWidth="3" strokeLinecap="round" /><ellipse cx="24" cy="28" rx="7" ry="3" fill="#fef9c3" /></Svg>),
  ORANGE: (<Svg><circle cx="32" cy="36" r="22" fill="#fb923c" stroke="#9a3412" strokeWidth="2.5" /><path d="M32 14c2-5 6-7 11-6-2 4-6 6-11 6z" fill="#16a34a" /><circle cx="25" cy="29" r="4" fill="#fed7aa" />{[[40, 40], [30, 44], [38, 30]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="1" fill="#c2410c" />)}</Svg>),
  PLUM: (<Svg><path d="M32 12c14 0 22 10 22 24S44 58 32 58 10 50 10 36s8-24 22-24z" fill="#7e22ce" stroke="#3b0764" strokeWidth="2.5" /><path d="M32 14c0 14 0 28 0 42" stroke="#581c87" strokeWidth="1.5" opacity=".6" /><path d="M32 12c2-4 6-6 10-5" stroke="#15803d" strokeWidth="3" fill="none" /><ellipse cx="22" cy="28" rx="4" ry="7" fill="#d8b4fe" opacity=".6" /></Svg>),
  BELL: <Bell />, BAR: <Bar />, SEVEN: <Seven />,
};

// ── Starlight Observatory ──
const STAR = {
  MOON: (<Svg><circle cx="32" cy="32" r="22" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" /><circle cx="24" cy="26" r="4" fill="#cbd5e1" /><circle cx="38" cy="38" r="6" fill="#cbd5e1" /><circle cx="40" cy="22" r="2.5" fill="#cbd5e1" /></Svg>),
  SATURN: (<Svg><ellipse cx="32" cy="34" rx="28" ry="8" fill="none" stroke="#fde68a" strokeWidth="3" transform="rotate(-18 32 34)" /><circle cx="32" cy="32" r="15" fill="#f59e0b" stroke="#92400e" strokeWidth="2" /><path d="M18 28h28M18 36h28" stroke="#fbbf24" strokeWidth="2" opacity=".7" /><path d="M6 40c8-6 44-18 52-22" stroke="#fde68a" strokeWidth="3" transform="rotate(-2 32 34)" opacity=".9" /></Svg>),
  ROCKET: (<Svg><path d="M32 4c10 8 12 20 8 34H24C20 24 22 12 32 4z" fill="#f1f5f9" stroke="#334155" strokeWidth="2" /><circle cx="32" cy="20" r="5" fill="#38bdf8" stroke="#334155" strokeWidth="2" /><path d="M24 30l-8 10 8 2zM40 30l8 10-8 2z" fill="#ef4444" stroke="#7f1d1d" strokeWidth="1.5" /><path d="M26 40h12l-6 18z" fill="#fb923c" /><path d="M29 40h6l-3 10z" fill="#fde047" /></Svg>),
  ASTRO: (<Svg><circle cx="32" cy="28" r="20" fill="#f8fafc" stroke="#334155" strokeWidth="2.5" /><rect x="18" y="18" width="28" height="18" rx="9" fill="#1e3a8a" stroke="#334155" strokeWidth="2" /><path d="M22 24c4-3 10-3 14 0" stroke="#93c5fd" strokeWidth="2" strokeLinecap="round" /><rect x="16" y="46" width="32" height="14" rx="6" fill="#e2e8f0" stroke="#334155" strokeWidth="2" /><circle cx="44" cy="12" r="3" fill="#f43f5e" /></Svg>),
  SCOPE: (<Svg><rect x="14" y="14" width="32" height="12" rx="4" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2" transform="rotate(-28 30 20)" /><rect x="40" y="6" width="10" height="16" rx="3" fill="#94a3b8" stroke="#1e293b" strokeWidth="2" transform="rotate(-28 45 14)" /><path d="M28 30L18 50M28 30l10 20M28 30v20" stroke="#cbd5e1" strokeWidth="3" strokeLinecap="round" /><rect x="7" y="48" width="50" height="13" rx="3" fill="#0b1520" stroke="#fde68a" strokeWidth="1.5" /><text x="32" y="58" textAnchor="middle" fontSize="8.5" fontWeight="900" fill="#fde68a" fontFamily="system-ui">WILD ✦ SCATTER</text></Svg>),
};

/** Render any symbol from the four games. `game` picks the art style. */
export function Sym({ s, v, bet, game }) {
  if (LETTERS[s]) { const [a, b] = LETTERS[s]; return <Letter ch={s} a={a} b={b} />; }
  if (game === 'nebula') return s === 'SCAT' ? <Comet /> : <Gem s={s} />;
  if (game === 'vault') { if (s === 'COIN') return <Coin v={v} bet={bet} />; if (s === 'WILD') return <VaultWild />; return { BELL: <Bell />, BAR: <Bar />, SEVEN: <Seven /> }[s] || null; }
  if (game === 'fruit') return FRUIT[s] || null;
  if (game === 'starlight') return STAR[s] || null;
  return null;
}
export const SYMBOLS = {
  vault: ['10', 'J', 'Q', 'K', 'A', 'BELL', 'BAR', 'SEVEN', 'WILD', 'COIN'],
  starlight: ['10', 'J', 'Q', 'K', 'A', 'MOON', 'SATURN', 'ROCKET', 'ASTRO', 'SCOPE'],
  nebula: ['RED', 'ORG', 'YEL', 'GRN', 'BLU', 'PUR'],
  fruit: ['CHERRY', 'LEMON', 'ORANGE', 'PLUM', 'BELL', 'BAR', 'SEVEN'],
};
