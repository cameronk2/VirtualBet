// Polar Catch art: original SVG fish (three species, four sizes), flake
// emblems, the logo and lobby emblem. Gradients: <PolarDefs />.

export function PolarDefs() {
  const lg = (id, stops, x2 = 0, y2 = 1) => <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {lg('pcBlue', [[0, '#bae6fd'], [0.5, '#38bdf8'], [1, '#0369a1']])}
        {lg('pcWhite', [[0, '#ffffff'], [0.6, '#e2e8f0'], [1, '#94a3b8']])}
        {lg('pcMinnow', [[0, '#a5f3fc'], [0.5, '#06b6d4'], [1, '#155e75']])}
        {lg('pcSalmon', [[0, '#fed7aa'], [0.5, '#f97316'], [1, '#9a3412']])}
        {lg('pcKing', [[0, '#fecdd3'], [0.5, '#e11d48'], [1, '#881337']])}
        {lg('pcIce', [[0, '#f0f9ff'], [0.5, '#bae6fd'], [1, '#7dd3fc']])}
        {lg('pcSky', [[0, '#020617'], [0.5, '#0c1e3d'], [1, '#164e63']])}
        {lg('pcGold', [[0, '#fff7c2'], [0.5, '#facc15'], [1, '#b45309']])}
        {lg('pcWater', [[0, '#0e7490'], [1, '#042f2e']])}
      </defs>
    </svg>
  );
}

export const SPECIES = { minnow: 'url(#pcMinnow)', salmon: 'url(#pcSalmon)', king: 'url(#pcKing)' };
const FIN = { minnow: '#155e75', salmon: '#7c2d12', king: '#4c0519' };

/** A fish (viewBox 0 0 120 60), facing right. */
export function Fish({ species = 'minnow' }) {
  const body = SPECIES[species], fin = FIN[species];
  return (
    <g>
      <path d="M8 30L0 14L4 30L0 46Z" fill={fin} />
      <path d="M8 30C24 8 70 4 98 18C110 24 116 28 118 30C116 32 110 36 98 42C70 56 24 52 8 30Z" fill={body} stroke={fin} strokeWidth="2" />
      <path d="M44 12C52 4 64 2 72 8L64 14Z M48 48C54 54 62 56 68 52L60 46Z" fill={fin} opacity=".85" />
      <path d="M30 22C50 18 80 18 100 26" stroke="#fff" strokeOpacity=".45" strokeWidth="3" fill="none" strokeLinecap="round" />
      {species === 'king' && <path d="M40 30H96M46 36H92" stroke="#fecdd3" strokeOpacity=".5" strokeWidth="1.5" />}
      {species === 'salmon' && [40, 52, 64, 76].map((x) => <circle key={x} cx={x} cy={24 + (x % 3)} r="1.6" fill="#7c2d12" opacity=".6" />)}
      <path d="M84 20C86 30 86 34 84 42" stroke={fin} strokeWidth="2" fill="none" />
      <circle cx="102" cy="26" r="4.5" fill="#fff" /><circle cx="103" cy="26" r="2.4" fill="#0b1220" />
      <path d="M112 32Q108 34 104 33" stroke={fin} strokeWidth="1.6" fill="none" />
    </g>
  );
}

export function Flake({ fill = '#fff', stroke = '#0369a1' }) {
  return (
    <g stroke={stroke} strokeWidth="1.6" strokeLinecap="round">
      {[0, 60, 120].map((r) => <g key={r} transform={`rotate(${r} 12 12)`}><path d="M12 2V22M12 5L9 3M12 5L15 3M12 19L9 21M12 19L15 21" fill="none" stroke={fill} strokeWidth="2.2" /></g>)}
      <circle cx="12" cy="12" r="2" fill={fill} stroke="none" />
    </g>
  );
}

export function PolarLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 320 90" className={className} aria-label="Polar Catch">
      <g transform="translate(118 2) scale(.7)"><Fish species="king" /></g>
      <path d="M160 46Q170 30 186 28" stroke="#e2e8f0" strokeWidth="1.5" fill="none" />
      <text x="160" y="72" textAnchor="middle" fontFamily="'Lilita One'" fontSize="44" textLength="260" lengthAdjust="spacingAndGlyphs" letterSpacing="4" fill="url(#pcIce)" stroke="#0c4a6e" strokeWidth="3.5" paintOrder="stroke">POLAR CATCH</text>
      <text x="160" y="88" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="12" letterSpacing="6" fill="#7dd3fc">SPIN · FISH · WIN</text>
    </svg>
  );
}

export const POLAR_LOBBY = (
  <g>
    <rect width="100" height="100" fill="url(#pcSky)" />
    <path d="M0 30Q30 10 60 26T100 18" stroke="#34d399" strokeWidth="6" opacity=".35" fill="none" />
    <path d="M0 40Q35 22 70 36T100 30" stroke="#a78bfa" strokeWidth="4" opacity=".3" fill="none" />
    <path d="M0 70L100 64V100H0Z" fill="url(#pcIce)" />
    <ellipse cx="50" cy="78" rx="16" ry="5" fill="url(#pcWater)" />
    <g transform="translate(22 40) scale(.48) rotate(-20 60 30)"><Fish species="king" /></g>
    <circle cx="50" cy="56" r="2" fill="#fff" />
  </g>
);
