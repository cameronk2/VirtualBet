// Shared building blocks for the five premium slots: reels with themed
// motion, win tiers, big-win overlay, particles, sound menu, info panel and
// the stake/spin bar. Outcomes always come from the server; these only animate.
import { SLOT_BG } from '../assets/slots/index.js';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from '../lib/router.jsx';
import { money } from '../lib/format.js';
import { isFxOn, isMusicOn, isMuted, onSoundChange, setFxOn, setMusicOn, setMuted, startAmbience, stopAmbience, themeSfx } from '../lib/sound.js';
import { STAKES, useGame, WinAmount, netOutcome } from './GameShell.jsx';
import { Modal } from './ui.jsx';
import { Logo3, Sym3, SYMS3, SlotDefs3 } from './SlotArt3.jsx';

export const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
export const sleep = (ms) => new Promise((r) => setTimeout(r, reduceMotion ? Math.min(ms, 120) : ms));

/** Win tier: 0 none/partial return, 1 small, 2 medium, 3 big, 4 mega, 5 epic. */
export function tierOf(win, staked, bet) {
  if (!win || netOutcome(win, staked) !== 'win') return 0;
  const x = win / bet;
  return x >= 50 ? 5 : x >= 25 ? 4 : x >= 10 ? 3 : x >= 2 ? 2 : 1;
}

/** Game state, themed sound, ambience and a hard lock against double spins. */
export function usePremium(game) {
  const g = useGame(game);
  const fx = useMemo(() => themeSfx(game), [game]);
  const lock = useRef(false);
  const [shake, setShake] = useState('');
  useEffect(() => () => stopAmbience(), []);
  const guard = useCallback(async (fn) => {
    if (lock.current) return;
    lock.current = true;
    startAmbience(game);
    try { await fn(); } finally { lock.current = false; }
  }, [game]);
  const doShake = useCallback((big) => { setShake(''); requestAnimationFrame(() => setShake(big ? 'p3-shake-big' : 'p3-shake')); setTimeout(() => setShake(''), 1000); }, []);
  return { ...g, fx, guard, shake, doShake, locked: lock };
}

/** Staggered reel stops; `tease` reels wait longer (scatter suspense). */
export function useReelStops(cols) {
  const [stopped, setStopped] = useState(() => Array(cols).fill(true));
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const start = useCallback(() => setStopped(Array(cols).fill(false)), [cols]);
  const stopAll = useCallback(({ turbo = false, tease = [], onStop, base = 620, gap = 230 } = {}) => new Promise((res) => {
    let t = reduceMotion ? 80 : turbo ? 260 : base;
    for (let i = 0; i < cols; i++) {
      if (tease.includes(i) && !turbo && !reduceMotion) t += 900;
      const at = t;
      timers.current.push(setTimeout(() => { setStopped((s) => s.map((x, j) => (j === i ? true : x))); onStop?.(i); }, at));
      t += reduceMotion ? 20 : turbo ? 80 : gap;
    }
    timers.current.push(setTimeout(res, t + 220));
  }), [cols]);
  const stopNow = useCallback(() => setStopped(Array(cols).fill(true)), [cols]);
  return { stopped, start, stopAll, stopNow };
}

const PALETTE = { atlantis: ['#facc15', '#22d3ee', '#a5f3fc', '#fde68a'], neon: ['#f472b6', '#22d3ee', '#a78bfa', '#4ade80'], dragon: ['#facc15', '#f97316', '#dc2626', '#fde68a'], cosmic: ['#f0abfc', '#a78bfa', '#fff', '#38bdf8'], pharaoh: ['#facc15', '#5eead4', '#fde68a', '#f59e0b'], frost: ['#e0f2fe', '#7dd3fc', '#a5b4fc', '#ffffff'], moonridge: ['#fbbf24', '#fde68a', '#f87171', '#ffffff'], mummy: ['#fcd34d', '#2dd4bf', '#34d399', '#fff8d6'], polarcatch: ['#e0f2fe', '#38bdf8', '#fb7185', '#ffffff'], brick: ['#facc15', '#f97316', '#ef4444', '#ffffff'], stampede: ['#fde047', '#f59e0b', '#b45309', '#fff7ed'], chicken: ['#fde047', '#4ade80', '#f97316', '#ffffff'], mines: ['#7dd3fc', '#a78bfa', '#fde047', '#ffffff'], keno: ['#fde047', '#a78bfa', '#60a5fa', '#f472b6'], genie: ['#fde047', '#5eead4', '#e879f9', '#ffffff'] };
export const GLOW = { atlantis: '#22d3ee', neon: '#f472b6', dragon: '#facc15', cosmic: '#c084fc', pharaoh: '#fbbf24', frost: '#7dd3fc', moonridge: '#fbbf24', mummy: '#fcd34d', polarcatch: '#7dd3fc', brick: '#facc15', stampede: '#f59e0b', chicken: '#fde047', mines: '#818cf8', keno: '#c084fc', genie: '#facc15' };

export function Burst({ game, n = 12, spread = 70, className = '' }) {
  const parts = useMemo(() => Array.from({ length: reduceMotion ? 0 : n }, (_, i) => {
    const a = (i / n) * Math.PI * 2 + Math.random() * 0.5, d = spread * (0.5 + Math.random() * 0.6);
    return { dx: `${Math.cos(a) * d}px`, dy: `${Math.sin(a) * d}px`, c: PALETTE[game][i % 4], t: `${0.6 + Math.random() * 0.5}s` };
  }), [game, n, spread]);
  return <div className={`pointer-events-none absolute left-1/2 top-1/2 ${className}`}>{parts.map((p, i) => <span key={i} className="p3-particle" style={{ '--dx': p.dx, '--dy': p.dy, '--c': p.c, '--t': p.t }} />)}</div>;
}

/**
 * Reels for line/ways games. grid: reels x rows of { s, v }.
 * landing: bounce | thud | glitch | warp. lit: Set of "reel-row".
 */
export function PremiumReels({ game, grid, stopped, lit, landing = 'bounce', overlays = [], turbo, spinId = 0, cellExtra }) {
  const rows = grid[0].length;
  const dim = lit && lit.size > 0;
  const pool = SYMS3[game].filter((s) => !['MULT', 'GRAVITY'].includes(s));
  return (
    <div className="mx-auto grid gap-1 sm:gap-1.5" style={{ gridTemplateColumns: `repeat(${grid.length}, minmax(0, 1fr))`, maxWidth: `min(100%, calc((100dvh - 480px) * ${grid.length / rows}))` }}>
      {grid.map((col, i) => (
        <div key={i} style={{ aspectRatio: `1 / ${rows}` }} className="relative overflow-hidden rounded-lg bg-black/30">
          {!stopped[i] ? (
            <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-i * 40}ms` }}>
              {Array.from({ length: rows * 4 }, (_, k) => <div key={k} className="aspect-square p-0.5 opacity-80 blur-[1.5px]"><Sym3 game={game} s={pool[(k * 7 + i * 3 + spinId) % pool.length]} /></div>)}
            </div>
          ) : (
            <div key={`${spinId}-${i}`} className={`p3-land-${landing}`}>
              {col.map((c, row) => {
                const k = `${i}-${row}`, on = lit?.has(k);
                return (
                  <div key={row} className={`relative aspect-square p-0.5 ${dim && !on ? 'p3-dim' : ''}`}>
                    <div className={`h-full w-full ${on ? 'p3-win' : ''}`} style={{ '--glow': GLOW[game] }}><Sym3 game={game} s={c.s} v={c.v} /></div>
                    {on && <Burst key={spinId} game={game} n={8} spread={40} />}
                    {cellExtra?.(i, row, c)}
                  </div>
                );
              })}
            </div>
          )}
          {overlays[i]}
        </div>
      ))}
    </div>
  );
}

/** Big / mega / epic win overlay with count-up and a themed cinematic layer. */
/** Big win presentation: the shared tiered celebration, themed per game. */
export function BigWin(props) { return <WinCelebration {...props} />; }

/** Full-stage intro for a bonus round. */
export function FeatureIntro({ title, subtitle, art, onStart, className = '', cta = 'Tap to start' }) {
  return (
    <button type="button" onClick={onStart} className={`animate-fade-in absolute inset-0 z-40 flex flex-col items-center justify-center overflow-hidden rounded-2xl bg-black/75 px-4 pb-20 text-center md:pb-0 ${className}`}>
      {art}
      <div className="p3-stamp relative font-display text-4xl tracking-wide text-white drop-shadow-[0_0_14px_rgba(255,255,255,0.6)] sm:text-5xl">{title}</div>
      {subtitle && <div className="relative mt-2 max-w-xs text-sm text-white/85">{subtitle}</div>}
      <div className="relative mt-4 rounded-full bg-white/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-white">{cta}</div>
    </button>
  );
}

export function WinLine({ res, spinning, idle = 'Set your stake and spin', busyText = 'Spinning…', detail }) {
  return (
    <div className="flex min-h-14 flex-col items-center justify-center rounded-xl bg-black/45 px-2 py-1.5 text-center leading-tight backdrop-blur-sm">
      {res?.win ? <><WinAmount win={res.win} staked={res.staked} />{detail && <div className="mt-0.5 text-[11px] text-white/75">{detail}</div>}</>
        : <div className="text-sm text-white/65">{spinning ? busyText : res ? (detail || 'No win this time') : idle}</div>}
    </div>
  );
}

function Toggle({ on, onChange, label }) {
  return (
    <button type="button" onClick={() => onChange(!on)} className="flex w-full items-center justify-between gap-4 rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-navy-700" aria-pressed={on}>
      {label}<span className={`relative h-5 w-9 rounded-full transition-colors ${on ? 'bg-brand-500' : 'bg-navy-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
    </button>
  );
}
import SoundMenu from './SoundMenu.jsx';
import { PopoutButton, PopoutFrame, PopoutPlaceholder, usePopout } from './Popout.jsx';
export { SoundMenu };
import WinCelebration from './WinCelebration.jsx';

/** Header, themed stage, side panel, info modal and the definitions for all art. */
/** Themed loading splash: logo and a filling bar, once per game per session. */
function Splash({ game, onDone }) {
  useEffect(() => { const id = setTimeout(onDone, reduceMotion ? 50 : 1100); return () => clearTimeout(id); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="animate-fade-in absolute inset-0 z-50 flex flex-col items-center justify-center gap-3 rounded-2xl bg-black/80 backdrop-blur-sm" role="status" aria-label="Loading game">
      <Logo3 game={game} className="h-20 w-auto max-w-[80%] p3-stamp" />
      <div className="h-1.5 w-40 overflow-hidden rounded-full bg-white/15"><div className="vb-load h-full rounded-full" style={{ background: GLOW[game] || '#facc15' }} /></div>
    </div>
  );
}

export function PremiumShell({ game, rtp, tagline, stageClass, bg, shake, children, side, info, below, popout = true, title }) {
  const [infoOpen, setInfoOpen] = useState(false);
  const [splash, setSplash] = useState(() => { try { const k = `vb_splash_${game}`; if (sessionStorage.getItem(k)) return false; sessionStorage.setItem(k, '1'); return true; } catch { return false; } });
  const [pop, setPop] = usePopout();
  const full = popout && pop;
  const stage = (
    <section className={`relative isolate overflow-hidden rounded-2xl shadow-2xl ${stageClass} ${shake}`}>
      <div className="pointer-events-none absolute inset-0 -z-10">{SLOT_BG[game] ? <><img src={SLOT_BG[game]} alt="" className="h-full w-full object-cover" /><div className="absolute inset-0 bg-black/30" /></> : bg}</div>
      <div className="relative p-2 sm:p-4">{children}</div>
      {splash && <Splash game={game} onDone={() => setSplash(false)} />}
    </section>
  );
  return (
    <div className="space-y-3">
      <SlotDefs3 />
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <Link to="/casino" className="text-xs font-semibold text-slate-400 hover:text-white">‹ Casino lobby</Link>
          <Logo3 game={game} className="mt-0.5 h-12 w-auto max-w-[62vw] sm:h-14" />
          <p className="text-[11px] text-slate-400">{tagline}</p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1.5">
          <div className="flex gap-1.5">
            {popout && !full && <PopoutButton onOpen={() => setPop(true)} />}
            <SoundMenu game={game} />
            <button onClick={() => setInfoOpen(true)} className="flex h-8 w-8 items-center justify-center rounded-md bg-navy-700 text-sm font-bold text-slate-200 hover:bg-navy-600" aria-label="Game info and paytable">i</button>
          </div>
          <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-slate-400 ring-1 ring-white/10">RTP {rtp}</span>
        </div>
      </div>
      <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_260px] lg:items-start lg:gap-4">
        {full ? <PopoutPlaceholder title={title || 'The game'} onOpen={() => setPop(true)} /> : stage}
        <aside className="mt-3 hidden space-y-3 lg:mt-0 lg:block">{side}</aside>
      </div>
      {!full && below}
      {full && (
        <PopoutFrame title={<Logo3 game={game} className="h-8 w-auto max-w-[44vw]" />} label={title || game} onExit={() => setPop(false)} bg="bg-[#070b18]"
          extras={<><SoundMenu game={game} /><button onClick={() => setInfoOpen(true)} className="flex h-8 w-8 items-center justify-center rounded-md bg-navy-700 text-sm font-bold text-slate-200" aria-label="Game info and paytable">i</button></>}>
          <div className="space-y-2">{stage}{below}</div>
        </PopoutFrame>
      )}
      <Modal open={infoOpen} onClose={() => setInfoOpen(false)} title="Game info">
        <div className="space-y-4 text-sm text-slate-300">{info}</div>
      </Modal>
    </div>
  );
}

/** Stake, spin and (for free spins only) auto-play. Pinned above the tab bar on phones. */
export function SpinBar({ stake, setStake, onSpin, spinning, free, disabled, balance, turbo, setTurbo, auto, setAuto, accent = 'bg-brand-500 text-navy-950 hover:bg-brand-400', label = 'Spin' }) {
  const i = Math.max(0, STAKES.indexOf(stake));
  const low = !free && balance != null && stake > balance;
  return (
    <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <button className="btn-ghost h-12 w-11 p-0 text-xl" disabled={spinning || !!free || i <= 0} onClick={() => setStake(STAKES[i - 1])} aria-label="Lower stake">−</button>
          <div className="w-[4.6rem] text-center leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{free ? 'Free spin' : 'Stake'}</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(free ? free.bet : stake)}</div></div>
          <button className="btn-ghost h-12 w-11 p-0 text-xl" disabled={spinning || !!free || i >= STAKES.length - 1} onClick={() => setStake(STAKES[i + 1])} aria-label="Raise stake">+</button>
        </div>
        <button onClick={onSpin} disabled={spinning || disabled || low}
          className={`btn h-14 flex-1 rounded-full text-lg font-extrabold shadow-lg transition-transform active:scale-95 ${free ? 'bg-gold-500 text-navy-950 hover:bg-gold-400' : accent}`}>
          {spinning ? 'Spinning…' : free ? `Free spin · ${free.remaining} left` : low ? 'Not enough balance' : label}
        </button>
      </div>
      <div className="flex items-center justify-between gap-2 px-1 text-xs text-slate-400">
        <button onClick={() => setTurbo((t) => !t)} className={`rounded-md px-2 py-1 font-semibold ${turbo ? 'bg-gold-500 text-navy-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Turbo</button>
        {free ? <label className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-brand-500" checked={auto} onChange={(e) => setAuto(e.target.checked)} />Auto-play free spins</label>
          : <span>Balance <b className="tabular-nums text-slate-200">{money(balance ?? 0)}</b></span>}
      </div>
    </div>
  );
}

/** Paytable grid built from engine values (already scaled), so it is always accurate. */
export function Paytable({ game, rows, heads = ['3×', '4×', '5×'], bet }) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {rows.map(([s, pays]) => (
        <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
          <div className="h-11 w-11 shrink-0"><Sym3 game={game} s={s} /></div>
          <div className="min-w-0 text-[11px] leading-tight text-slate-300">
            {pays.map((p, k) => <div key={k} className="whitespace-nowrap"><span className="text-slate-500">{heads[k]}</span> <b className="text-white">{bet ? money(Math.floor((bet * p) / 100)) : `${+(p / 100).toFixed(2)}x`}</b></div>)}
          </div>
        </div>
      ))}
    </div>
  );
}

export function SidePanel({ title, children }) {
  return <div className="card p-3"><div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">{title}</div>{children}</div>;
}

export function RecentList({ history }) {
  if (!history?.length) return <p className="text-xs text-slate-500">No spins yet.</p>;
  const net = history.reduce((a, h) => a + h.payout - h.staked, 0);
  return (
    <div className="space-y-1 text-xs">
      {history.slice(0, 8).map((h, i) => <div key={i} className="flex justify-between"><span className="text-slate-500">{h.staked ? `Stake ${money(h.staked)}` : 'Feature'}</span><span className={h.payout > h.staked ? 'font-bold text-brand-400' : 'text-slate-400'}>{money(h.payout)}</span></div>)}
      <div className="mt-1 flex justify-between border-t border-navy-700 pt-1"><span className="text-slate-400">Net (last {history.length})</span><b className={net >= 0 ? 'text-brand-400' : 'text-red-400'}>{net >= 0 ? '+' : '−'}{money(Math.abs(net))}</b></div>
    </div>
  );
}
