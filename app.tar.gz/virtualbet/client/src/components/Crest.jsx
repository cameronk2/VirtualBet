import { useState } from 'react';

// Generated shield badge (no club crests are bundled). If the live data
// provider supplies a crest URL it is shown instead.
function luminance(hex) {
  const h = (hex || '#888888').replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
}

export default function Crest({ team, size = 24 }) {
  const [broken, setBroken] = useState(false);
  if (team.crest && !broken) {
    return <img src={team.crest} alt="" width={size} height={size} loading="lazy" onError={() => setBroken(true)} className="shrink-0 object-contain" style={{ width: size, height: size }} />;
  }
  const color = team.color || '#3b4f66';
  const text = luminance(color) > 0.6 ? '#0b1520' : '#ffffff';
  const raw = team.short || team.name || '?';
  const label = (raw.length > 3 ? raw.replace(/\d+$/, '') : raw).slice(0, 3);
  return (
    <svg width={size} height={size} viewBox="0 0 32 36" className="shrink-0" aria-hidden="true">
      <path d="M16 1L30 6v11c0 9-6.2 15.4-14 18C8.2 32.4 2 26 2 17V6z" fill={color} stroke="rgba(255,255,255,0.35)" strokeWidth="1.5" />
      <path d="M16 1L30 6v11c0 9-6.2 15.4-14 18z" fill="rgba(0,0,0,0.12)" />
      <text x="16" y="21.5" textAnchor="middle" fontSize="9.5" fontWeight="800" fill={text} fontFamily="system-ui, sans-serif">{label}</text>
    </svg>
  );
}
