// Keno 40 art: glossy numbered balls (colour by decade), the glass ball
// machine, logo and lobby emblem. Gradients: <KenoDefs />.
export const BALL_COLOURS = [['#fecaca', '#ef4444', '#7f1d1d'], ['#bfdbfe', '#3b82f6', '#1e3a8a'], ['#bbf7d0', '#22c55e', '#14532d'], ['#fde68a', '#f59e0b', '#78350f']];
export const ballColour = (n) => BALL_COLOURS[Math.min(3, Math.floor((n - 1) / 10))];

export function KenoDefs() {
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {BALL_COLOURS.map(([a, b, c], i) => <radialGradient key={i} id={`knBall${i}`} cx="35%" cy="30%" r="75%"><stop offset="0" stopColor={a} /><stop offset=".45" stopColor={b} /><stop offset="1" stopColor={c} /></radialGradient>)}
        <radialGradient id="knGlass" cx="40%" cy="30%" r="75%"><stop offset="0" stopColor="rgba(255,255,255,.28)" /><stop offset=".6" stopColor="rgba(147,197,253,.10)" /><stop offset="1" stopColor="rgba(167,139,250,.35)" /></radialGradient>
        <linearGradient id="knGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fffbeb" /><stop offset=".4" stopColor="#fde047" /><stop offset=".75" stopColor="#f59e0b" /><stop offset="1" stopColor="#92400e" /></linearGradient>
        <linearGradient id="knChrome" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#e2e8f0" /><stop offset=".5" stopColor="#64748b" /><stop offset="1" stopColor="#1e293b" /></linearGradient>
      </defs>
    </svg>
  );
}

/** A glossy keno ball (viewBox 0 0 100 100). */
export function Ball({ n, shadow = true }) {
  const i = Math.min(3, Math.floor((n - 1) / 10));
  return (
    <g>
      {shadow && <ellipse cx="50" cy="94" rx="30" ry="5" fill="#000" opacity=".3" />}
      <circle cx="50" cy="48" r="44" fill={`url(#knBall${i})`} />
      <circle cx="50" cy="48" r="24" fill="#fff" />
      <circle cx="50" cy="48" r="24" fill="none" stroke="#000" strokeOpacity=".12" strokeWidth="2" />
      <text x="50" y="58" textAnchor="middle" fontFamily="'Lilita One', system-ui, sans-serif" fontSize="28" fill="#0f172a">{n}</text>
      <ellipse cx="34" cy="26" rx="14" ry="8" fill="#fff" opacity=".55" transform="rotate(-30 34 26)" />
    </g>
  );
}

export function KenoLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 320 96" className={className} aria-label="Keno 40">
      {[7, 22, 33].map((n, i) => <g key={n} transform={`translate(${4 + i * 30} ${i === 1 ? 6 : 26}) scale(.6)`}><Ball n={n} /></g>)}
      <text x="214" y="64" textAnchor="middle" fontFamily="'Cinzel', 'Lilita One', Georgia, serif" fontWeight="800" fontSize="52" textLength="170" lengthAdjust="spacingAndGlyphs" fill="url(#knGold)" stroke="#1e1b4b" strokeWidth="5" paintOrder="stroke">KENO</text>
      <rect x="250" y="70" width="48" height="22" rx="6" fill="#7c3aed" stroke="#fde047" strokeWidth="2" />
      <text x="274" y="87" textAnchor="middle" fontFamily="'Lilita One', system-ui, sans-serif" fontSize="16" fill="#fff">40</text>
    </svg>
  );
}

export const KENO_LOBBY = (
  <g>
    <circle cx="50" cy="42" r="36" fill="url(#knGlass)" stroke="url(#knChrome)" strokeWidth="3" />
    {[[36, 50, 12], [56, 58, 31], [62, 36, 5], [42, 30, 27], [30, 38, 40]].map(([x, y, n]) => <g key={n} transform={`translate(${x - 9} ${y - 9}) scale(.18)`}><Ball n={n} shadow={false} /></g>)}
    <rect x="44" y="76" width="12" height="10" fill="url(#knChrome)" />
    <g transform="translate(36 76) scale(.28)"><Ball n={7} /></g>
  </g>
);
