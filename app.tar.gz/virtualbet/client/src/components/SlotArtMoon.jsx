// Moonridge art: original inline-SVG symbols (dusk mountains, harvest moon,
// three wolves, eagle, amulet, carved letters, jackpot coins), the tall
// expanding-wild scene, logo and lobby emblem. Gradients: <MoonDefs />.

import PaintedSym from './PaintedSym.jsx';
import { SLOT_IMG } from '../assets/slots/index.js';
export function MoonDefs() {
  const lg = (id, stops, x2 = 0, y2 = 1) => <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  const rg = (id, stops, cx = '42%', cy = '38%') => <radialGradient id={id} cx={cx} cy={cy} r="65%">{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {lg('mrGold', [[0, '#fff7d6'], [0.4, '#fbbf24'], [0.75, '#d97706'], [1, '#78350f']])}
        {lg('mrSilver', [[0, '#ffffff'], [0.5, '#cbd5e1'], [1, '#475569']])}
        {lg('mrBronze', [[0, '#fde3c4'], [0.5, '#c2763a'], [1, '#5c2d0e']])}
        {lg('mrEmerald', [[0, '#d1fae5'], [0.5, '#10b981'], [1, '#064e3b']])}
        {lg('mrRuby', [[0, '#ffe4e6'], [0.5, '#e11d48'], [1, '#4c0519']])}
        {lg('mrSky', [[0, '#0b0a24'], [0.45, '#2a1f4f'], [0.75, '#7c2d4a'], [1, '#d97706']])}
        {lg('mrNight', [[0, '#060814'], [1, '#1b1538']])}
        {lg('mrPine', [[0, '#14532d'], [1, '#04140b']])}
        {lg('mrRock', [[0, '#3f3a52'], [1, '#0d0b17']])}
        {lg('mrStone', [[0, '#57534e'], [1, '#1c1917']])}
        {lg('mrLetA', [[0, '#fecaca'], [0.5, '#dc2626'], [1, '#7f1d1d']])}
        {lg('mrLetK', [[0, '#bbf7d0'], [0.5, '#16a34a'], [1, '#14532d']])}
        {lg('mrLetQ', [[0, '#ddd6fe'], [0.5, '#7c3aed'], [1, '#3b0764']])}
        {lg('mrFurGray', [[0, '#c3cad6'], [0.6, '#7b8597'], [1, '#3f4756']])}
        {lg('mrFurBlack', [[0, '#4b5563'], [0.6, '#1f2937'], [1, '#030712']])}
        {lg('mrFurWhite', [[0, '#ffffff'], [0.6, '#e2e8f0'], [1, '#94a3b8']])}
        {lg('mrFeather', [[0, '#a16207'], [1, '#3f2a10']])}
        {lg('mrTurq', [[0, '#a5f3fc'], [0.5, '#14b8a6'], [1, '#134e4a']])}
        {rg('mrMoon', [[0, '#fffbeb'], [0.6, '#fde68a'], [1, '#d97706']])}
        {rg('mrMoonSilver', [[0, '#ffffff'], [0.6, '#e2e8f0'], [1, '#94a3b8']])}
        {rg('mrMoonBlood', [[0, '#fecaca'], [0.55, '#ef4444'], [1, '#7f1d1d']])}
        {rg('mrMoonGold', [[0, '#fffbeb'], [0.45, '#facc15'], [1, '#a16207']])}
        {rg('mrHalo', [[0.5, 'rgba(253,230,138,0.6)'], [1, 'rgba(253,230,138,0)']], '50%', '50%')}
        {rg('mrTileHi', [[0, 'rgba(251,191,36,0.35)'], [1, 'rgba(12,10,30,0.95)']], '50%', '30%')}
        <filter id="mrGlow" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.2" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
    </svg>
  );
}

const T = (t, y, size, fill, stroke = '#1c1917', len) => (
  <text x="50" y={y} textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize={size} fill={fill} stroke={stroke} strokeWidth={size / 9} paintOrder="stroke" {...(len ? { textLength: len, lengthAdjust: 'spacingAndGlyphs' } : {})}>{t}</text>
);

/** Front-facing wolf head; colours vary per wolf. */
function WolfHead({ fur, dark, light, eye, ring }) {
  return (
    <g>
      <circle cx="50" cy="54" r="44" fill="none" stroke={ring} strokeWidth="2.5" opacity=".75" />
      <path d="M20 8L42 36L14 44Z" fill={fur} stroke={dark} strokeWidth="1.5" />
      <path d="M23 17L36 35L19 40Z" fill={dark} opacity=".75" />
      <path d="M80 8L58 36L86 44Z" fill={fur} stroke={dark} strokeWidth="1.5" />
      <path d="M77 17L64 35L81 40Z" fill={dark} opacity=".75" />
      <path d="M50 24C67 24 80 34 85 47L93 63L77 66L71 81L58 91L50 96L42 91L29 81L23 66L7 63L15 47C20 34 33 24 50 24Z" fill={fur} stroke={dark} strokeWidth="1.8" />
      <path d="M15 47L29 58L23 66L7 63Z M85 47L71 58L77 66L93 63Z" fill={dark} opacity=".45" />
      <path d="M29 81L40 72L42 91Z M71 81L60 72L58 91Z" fill={dark} opacity=".35" />
      <path d="M50 28C57 28 61 40 59 55L50 61L41 55C39 40 43 28 50 28Z" fill={light} opacity=".85" />
      <path d="M27 46L44 49M73 46L56 49" stroke={dark} strokeWidth="2.6" strokeLinecap="round" />
      <path d="M29 52Q36 46 44 52Q36 57 29 52Z" fill={eye} stroke="#0b0a12" strokeWidth="1.2" />
      <path d="M71 52Q64 46 56 52Q64 57 71 52Z" fill={eye} stroke="#0b0a12" strokeWidth="1.2" />
      <ellipse cx="37" cy="52" rx="1.6" ry="2.8" fill="#0b0a12" /><ellipse cx="63" cy="52" rx="1.6" ry="2.8" fill="#0b0a12" />
      <circle cx="35.6" cy="50.6" r=".9" fill="#fff" /><circle cx="61.6" cy="50.6" r=".9" fill="#fff" />
      <path d="M39 60Q50 55 61 60L59 77Q50 86 41 77Z" fill={light} />
      <path d="M43 64Q50 60 57 64Q56 71 50 72Q44 71 43 64Z" fill="#0b0a12" />
      <path d="M46 63.5Q50 62.5 53 63.5" stroke="#fff" strokeWidth="1" opacity=".5" />
      <path d="M50 72V76M44 78Q50 82 56 78" stroke="#0b0a12" strokeWidth="1.6" fill="none" strokeLinecap="round" />
    </g>
  );
}

/** Sitting wolf howling up and to the left (silhouette). */
export function Howler({ fill = '#0b0a12' }) {
  return (
    <g fill={fill}>
      <path d="M30 90L34 71C31 62 33 54 39 48L35 37L29 23L24 13L33 18L40 24L44 22L43 13L49 21C53 26 55 32 57 38C65 42 71 50 73 60L77 73L81 90Z" />
      <path d="M73 80C85 78 92 70 90 58C88 71 81 76 73 74Z" />
    </g>
  );
}

const MOON_FILL = { WILD: 'url(#mrMoon)', W2: 'url(#mrMoonSilver)', W3: 'url(#mrMoonBlood)', WG: 'url(#mrMoonGold)' };
const FRAME = { WILD: '#fbbf24', W2: '#e2e8f0', W3: '#f87171', WG: '#facc15' };
const BADGE = { W2: ['#1d4ed8', 'x2'], W3: ['#b91c1c', 'x3'], WG: ['#a16207', 'GOLD'] };

function WildSym({ kind }) {
  const b = BADGE[kind];
  return (
    <g>
      <rect x="4" y="4" width="92" height="92" rx="10" fill="url(#mrNight)" />
      <circle cx="56" cy="40" r="34" fill="url(#mrHalo)" />
      <circle cx="56" cy="40" r="25" fill={MOON_FILL[kind]} />
      <circle cx="48" cy="34" r="3.5" fill="#000" opacity=".08" /><circle cx="62" cy="46" r="5" fill="#000" opacity=".08" />
      <g transform="translate(6 6) scale(.8)"><Howler /></g>
      <path d="M4 86L18 76L34 80L54 74L74 79L96 72V96H4Z" fill="url(#mrRock)" />
      <rect x="18" y="74" width="64" height="18" rx="5" fill="#1c1205" stroke={FRAME[kind]} strokeWidth="2" />
      {T('WILD', 89, 16, 'url(#mrGold)', '#1c1205', 46)}
      {b && <g><path d="M72 4h20a4 4 0 014 4v16l-14 8l-14-8V8a4 4 0 014-4z" fill={b[0]} stroke="#fff" strokeWidth="1.5" /><text x="82" y={b[1].length > 2 ? 18 : 20} textAnchor="middle" fontFamily="'Lilita One'" fontSize={b[1].length > 2 ? 8 : 12} fill="#fff">{b[1]}</text></g>}
      <rect x="4" y="4" width="92" height="92" rx="10" fill="none" stroke={FRAME[kind]} strokeWidth={kind === 'WILD' ? 2 : 3.5} />
    </g>
  );
}

const pawPrint = (fill) => (
  <g fill={fill}>
    <ellipse cx="50" cy="60" rx="13" ry="11" />
    <ellipse cx="34" cy="44" rx="5.5" ry="7" transform="rotate(-20 34 44)" />
    <ellipse cx="45" cy="36" rx="5.5" ry="7.5" transform="rotate(-6 45 36)" />
    <ellipse cx="56" cy="36" rx="5.5" ry="7.5" transform="rotate(6 56 36)" />
    <ellipse cx="66" cy="44" rx="5.5" ry="7" transform="rotate(20 66 44)" />
  </g>
);

const COINS = { J1: ['url(#mrBronze)', 'MINI', '#5c2d0e'], J2: ['url(#mrSilver)', 'MINOR', '#334155'], J3: ['url(#mrGold)', 'MAXI', '#78350f'], J4: ['url(#mrEmerald)', 'MAJOR', '#064e3b'], J5: ['url(#mrRuby)', 'GRAND', '#4c0519'] };
const Coin = ({ k }) => {
  const [fill, label, dark] = COINS[k];
  return (
    <g>
      <circle cx="50" cy="50" r="42" fill={fill} stroke={dark} strokeWidth="3" />
      <circle cx="50" cy="50" r="34" fill="none" stroke="#fff" strokeOpacity=".45" strokeWidth="1.5" strokeDasharray="3 3" />
      <g transform="translate(15 4) scale(.7)">{pawPrint(dark)}</g>
      {T(label, 80, 15, '#fff', dark, label.length > 4 ? 44 : 36)}
      <path d="M22 30Q36 14 58 12" stroke="#fff" strokeOpacity=".5" strokeWidth="3" fill="none" strokeLinecap="round" />
    </g>
  );
};

const Letter = ({ ch, fill }) => (
  <g>
    <path d="M14 82L22 70L38 74L54 66L72 72L88 66L88 86Q50 94 14 86Z" fill="url(#mrStone)" opacity=".9" />
    <path d="M78 64l5-14l5 14zM74 70l9-18l9 18z" fill="url(#mrPine)" />
    {T(ch, 72, 70, fill, '#1c1917')}
    <path d="M30 22Q40 18 50 20" stroke="#fff" strokeWidth="3" opacity=".35" fill="none" strokeLinecap="round" />
  </g>
);

export const MOON_ART = {
  Q: <Letter ch="Q" fill="url(#mrLetQ)" />,
  K: <Letter ch="K" fill="url(#mrLetK)" />,
  A: <Letter ch="A" fill="url(#mrLetA)" />,
  AMULET: (
    <g>
      <path d="M22 8Q50 40 78 8" stroke="#78350f" strokeWidth="2.5" fill="none" />
      {[[28, 16], [36, 23], [64, 23], [72, 16]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="3.2" fill={i % 2 ? 'url(#mrTurq)' : '#fef3c7'} stroke="#78350f" strokeWidth=".8" />)}
      <path d="M26 60l-8 30l6-4l2 8l6-30z" fill="url(#mrFeather)" stroke="#1c1205" strokeWidth=".8" />
      <path d="M74 60l8 30l-6-4l-2 8l-6-30z" fill="url(#mrFeather)" stroke="#1c1205" strokeWidth=".8" />
      <circle cx="50" cy="56" r="26" fill="url(#mrSilver)" stroke="#334155" strokeWidth="2.5" />
      <circle cx="50" cy="56" r="20" fill="none" stroke="#475569" strokeWidth="1.2" strokeDasharray="2 2.5" />
      <ellipse cx="50" cy="56" rx="11" ry="14" fill="url(#mrTurq)" stroke="#0f3b3b" strokeWidth="1.5" />
      <path d="M45 48Q48 45 52 46" stroke="#fff" strokeWidth="2" opacity=".7" fill="none" strokeLinecap="round" />
    </g>
  ),
  EAGLE: (
    <g>
      <path d="M58 68L48 94L62 84L68 96L76 82L88 92L86 58Z" fill="url(#mrFeather)" stroke="#1c1205" strokeWidth="1.2" />
      <path d="M68 16C48 12 30 22 26 40L19 50L34 49C37 62 47 72 62 76L84 82L82 38C82 28 77 20 68 16Z" fill="url(#mrFurWhite)" stroke="#475569" strokeWidth="1.5" />
      <path d="M26 40C13 42 9 53 15 62C18 56 26 53 34 49Z" fill="url(#mrGold)" stroke="#78350f" strokeWidth="1.5" />
      <path d="M15 62C14 66 16 68 19 67" stroke="#78350f" strokeWidth="2" fill="none" />
      <path d="M30 34L48 30" stroke="#334155" strokeWidth="3" strokeLinecap="round" />
      <circle cx="42" cy="38" r="4.5" fill="#f59e0b" stroke="#1c1205" strokeWidth="1" /><circle cx="41" cy="38" r="2" fill="#0b0a12" />
      <path d="M50 52Q62 58 74 54M54 62Q66 68 78 64" stroke="#94a3b8" strokeWidth="1.4" fill="none" />
    </g>
  ),
  WHITE: <WolfHead fur="url(#mrFurWhite)" dark="#64748b" light="#ffffff" eye="#38bdf8" ring="#bae6fd" />,
  BLACK: <WolfHead fur="url(#mrFurBlack)" dark="#000" light="#6b7280" eye="#facc15" ring="#f59e0b" />,
  GRAY: <WolfHead fur="url(#mrFurGray)" dark="#334155" light="#e5e7eb" eye="#f59e0b" ring="#e2e8f0" />,
  WILD: <WildSym kind="WILD" />,
  W2: <WildSym kind="W2" />,
  W3: <WildSym kind="W3" />,
  WG: <WildSym kind="WG" />,
  BONUS: (
    <g>
      <circle cx="50" cy="50" r="44" fill="url(#mrHalo)" />
      <circle cx="50" cy="46" r="34" fill="url(#mrStone)" stroke="url(#mrGold)" strokeWidth="4" />
      <path d="M62 22a20 20 0 1 0 0 30a16 16 0 1 1 0-30z" fill="#fde68a" opacity=".25" />
      <g filter="url(#mrGlow)" transform="translate(9 4) scale(.82)">{pawPrint('#fbbf24')}</g>
      <rect x="14" y="74" width="72" height="20" rx="6" fill="#7c2d12" stroke="url(#mrGold)" strokeWidth="2" />
      {T('BONUS', 90, 16, 'url(#mrGold)', '#1c1205', 56)}
    </g>
  ),
  J1: <Coin k="J1" />, J2: <Coin k="J2" />, J3: <Coin k="J3" />, J4: <Coin k="J4" />, J5: <Coin k="J5" />,
};

export const MOON_NAMES = {
  Q: 'Q', K: 'K', A: 'A', AMULET: 'Moonstone Amulet', EAGLE: 'Eagle', WHITE: 'White Wolf', BLACK: 'Black Wolf', GRAY: 'Grey Wolf',
  WILD: 'Wild', W2: 'x2 Expanding Wild', W3: 'x3 Expanding Wild', WG: 'Gold Expanding Wild', BONUS: 'Bonus',
  J1: 'Mini coin', J2: 'Minor coin', J3: 'Maxi coin', J4: 'Major coin', J5: 'Grand coin',
};

const SPECIALS = new Set(['WILD', 'W2', 'W3', 'WG', 'BONUS']);
export function MoonSym({ s, className = '' }) {
  if (!s) return null;
  if (SLOT_IMG.moonridge[s]) {
    const tier = SPECIALS.has(s) || s[0] === 'J' ? 'special' : ['Q', 'K', 'A'].includes(s) ? 'low' : s === 'AMULET' ? 'mid' : 'premium';
    const glow = s === 'BONUS' ? '#f472b6' : s === 'W2' ? '#60a5fa' : s === 'W3' ? '#f87171' : s === 'WG' || s === 'WILD' ? '#fbbf24' : { J1: '#d97706', J2: '#cbd5e1', J3: '#facc15', J4: '#34d399', J5: '#fb7185' }[s];
    return <PaintedSym src={SLOT_IMG.moonridge[s]} alt={MOON_NAMES[s] || s} tier={tier} glow={glow} className={className} />;
  }
  const hi = SPECIALS.has(s) || s[0] === 'J', wolf = ['GRAY', 'BLACK', 'WHITE', 'EAGLE'].includes(s);
  return (
    <div className={`relative h-full w-full rounded-md ${hi ? 'bg-[radial-gradient(circle_at_50%_30%,rgba(251,191,36,0.28),rgba(12,10,30,0.94))] ring-1 ring-amber-300/60' : wolf ? 'bg-[radial-gradient(circle_at_50%_30%,rgba(148,163,184,0.22),rgba(12,10,30,0.94))] ring-1 ring-slate-300/25' : 'bg-[radial-gradient(circle_at_50%_30%,rgba(76,29,149,0.35),rgba(8,6,20,0.94))] ring-1 ring-violet-900/50'} ${className}`}>
      <svg viewBox="0 0 100 100" className="h-full w-full p-[6%]" role="img" aria-label={MOON_NAMES[s] || s}>{MOON_ART[s]}</svg>
    </div>
  );
}

/**
 * The full-height expanding-wild scene (viewBox 60x240). The reel shows the
 * slice that the wild currently occupies, so it is revealed as it grows.
 */
export function MoonColumn({ kind = 'W2', className = '' }) {
  const moon = MOON_FILL[kind];
  return (
    <svg viewBox="0 0 60 240" preserveAspectRatio="none" className={className} aria-hidden="true">
      <rect width="60" height="240" fill="url(#mrSky)" />
      {[[8, 12], [50, 8], [14, 40], [46, 34], [6, 70], [54, 64], [28, 6], [36, 96], [10, 104]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r=".8" fill="#fff" className="fr-twinkle" style={{ animationDelay: `${i * 0.37}s` }} />)}
      <circle cx="31" cy="58" r="34" fill="url(#mrHalo)" />
      <circle cx="31" cy="58" r="22" fill={moon} />
      <circle cx="24" cy="52" r="3.5" fill="#000" opacity=".08" /><circle cx="37" cy="64" r="4.5" fill="#000" opacity=".08" />
      <path d="M0 150l8-26l8 26zM-2 162l10-34l10 34z" fill="url(#mrPine)" />
      <path d="M44 150l8-30l8 30zM42 164l10-38l10 38z" fill="url(#mrPine)" />
      <g transform="translate(2 86) scale(.62)"><Howler /></g>
      <path d="M0 152L14 142L26 146L42 138L60 146V240H0Z" fill="url(#mrRock)" />
      <path d="M0 180L18 170L34 178L60 168V240H0Z" fill="#0b0917" opacity=".8" />
      <rect x="8" y="196" width="44" height="16" rx="4" fill="#1c1205" stroke={FRAME[kind]} strokeWidth="1.4" />
      <text x="30" y="208.5" textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize="12" textLength="32" lengthAdjust="spacingAndGlyphs" fill="url(#mrGold)">WILD</text>
      <rect x="1" y="1" width="58" height="238" rx="3" fill="none" stroke={FRAME[kind]} strokeWidth="2" />
    </svg>
  );
}

export function MoonLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 300 90" className={className} aria-label="Moonridge – Where the Pack Howls">
      <circle cx="150" cy="30" r="22" fill="url(#mrMoon)" />
      <path d="M96 52L122 26L140 42L156 22L180 46L204 30L224 52Z" fill="url(#mrRock)" opacity=".9" />
      <g transform="translate(138 4) scale(.3)"><Howler /></g>
      <text x="150" y="66" textAnchor="middle" fontFamily="'Lilita One'" fontSize="42" textLength="270" lengthAdjust="spacingAndGlyphs" letterSpacing="4" fill="url(#mrGold)" stroke="#1c1205" strokeWidth="3" paintOrder="stroke">MOONRIDGE</text>
      <text x="150" y="86" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="13" letterSpacing="6" fill="#fcd34d">WHERE THE PACK HOWLS</text>
    </svg>
  );
}

export const MOON_LOBBY = (
  <g>
    <circle cx="54" cy="38" r="32" fill="url(#mrHalo)" />
    <circle cx="54" cy="38" r="22" fill="url(#mrMoon)" />
    <path d="M0 100L0 70L22 52L36 64L52 46L72 66L88 56L100 66V100Z" fill="url(#mrRock)" />
    <path d="M4 100l7-26l7 26zM82 100l7-30l7 30z" fill="url(#mrPine)" />
    <g transform="translate(20 22) scale(.55)"><Howler /></g>
  </g>
);
