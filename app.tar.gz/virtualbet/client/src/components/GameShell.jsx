import { useCallback, useEffect, useRef, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { Link } from '../lib/router.jsx';
import { money, signed } from '../lib/format.js';
import { setSoundTheme, startAmbience, stopAmbience } from '../lib/sound.js';
import SoundMenu from './SoundMenu.jsx';
import { LoginPrompt } from '../pages/MyBets.jsx';
import { Modal, Spinner } from './ui.jsx';
import { PopoutButton, PopoutFrame, PopoutPlaceholder, usePopout } from './Popout.jsx';

/**
 * Loads a casino game's saved state and runs its actions. The balance in
 * the header is only updated when `commit` is called, so games can reveal
 * the result with an animation first.
 */
export function useGame(id) {
  const { user, setUser, toast } = useApp();
  const [view, setView] = useState(null);
  const [history, setHistory] = useState([]);
  const [busy, setBusy] = useState(false);
  const pendingUser = useRef(null);
  const music = useGameSound(id);

  useEffect(() => {
    if (!user) return;
    api.get(`/api/casino/${id}`).then((d) => { setView(d.view); setHistory(d.history); }).catch((e) => toast(e.message, 'error'));
  }, [id, user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const inflight = useRef(false);
  const play = useCallback(async (action, body = {}, { quiet = false, silent = false } = {}) => {
    // Rapid taps can't send a second request while one is in flight
    if (!silent) { if (inflight.current) return null; inflight.current = true; setBusy(true); }
    music();
    try {
      const d = await api.post(`/api/casino/${id}/${action}`, body);
      setView(d.view);
      setHistory(d.history);
      pendingUser.current = d.user;
      // Show the stake leaving the balance straight away; winnings land on commit()
      if (d.user && d.out?.staked > 0 && typeof d.out.win === 'number') setUser({ ...d.user, balance: d.user.balance - d.out.win });
      return d.out;
    } catch (e) {
      if (!quiet) toast(e.message, 'error');
      return null;
    } finally {
      if (!silent) { inflight.current = false; setBusy(false); }
    }
  }, [id, toast, setUser, music]);

  const commit = useCallback(() => { if (pendingUser.current) { setUser(pendingUser.current); pendingUser.current = null; } }, [setUser]);
  return { user, view, history, busy, play, commit };
}

export function StakePicker({ value, onChange, options, disabled, label = 'Stake' }) {
  const i = Math.max(0, options.indexOf(value));
  return (
    <div className="flex items-center gap-1">
      <button className="btn-ghost h-11 w-11 p-0 text-lg" disabled={disabled || i <= 0} onClick={() => onChange(options[i - 1])} aria-label={`Lower ${label}`}>−</button>
      <div className="w-20 text-center">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{label}</div>
        <div className="font-cond text-lg font-bold tabular-nums text-white">{money(value)}</div>
      </div>
      <button className="btn-ghost h-11 w-11 p-0 text-lg" disabled={disabled || i >= options.length - 1} onClick={() => onChange(options[i + 1])} aria-label={`Raise ${label}`}>+</button>
    </div>
  );
}

/** Sound settings for a game (kept under its old name for existing pages). */
export function SoundToggle({ game }) { return <SoundMenu game={game} />; }

/** Gives a page its game's sound theme and soundtrack (music starts on the first action). */
export function useGameSound(id) {
  useEffect(() => { setSoundTheme(id); return () => { stopAmbience(); setSoundTheme(null); }; }, [id]);
  return useCallback(() => startAmbience(id), [id]);
}

/** Shared title bar for every casino game. */
export function GameHeader({ title, subtitle, rtp, extra, game }) {
  return (
    <div className="flex items-end justify-between gap-3">
      <div className="min-w-0">
        <Link to="/casino" className="text-xs font-semibold text-slate-400 hover:text-white">‹ Casino lobby</Link>
        <h1 className="font-cond text-3xl font-extrabold uppercase leading-none tracking-tight text-white">{title}</h1>
        {subtitle && <p className="mt-0.5 text-xs text-slate-400">{subtitle}</p>}
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1.5">
        <div className="flex gap-1.5">{extra}<SoundToggle game={game} /></div>
        {rtp && <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-slate-400 ring-1 ring-white/10" title="Long-run return to player">RTP {rtp}</span>}
      </div>
    </div>
  );
}

export default function GameShell({ title, subtitle, rtp, children, rules, history, game, popout = true }) {
  const { user } = useApp();
  const [pop, setPop] = usePopout();
  const [rulesOpen, setRulesOpen] = useState(false);
  if (user === null) return <LoginPrompt what={title} />;
  if (!user) return <div className="flex justify-center py-16"><Spinner /></div>;
  const net = (history || []).reduce((a, h) => a + h.payout - h.staked, 0);
  const full = popout && pop;
  return (
    <div className="space-y-3">
      <GameHeader title={title} subtitle={subtitle} rtp={rtp} game={game} extra={popout && !full ? <PopoutButton onOpen={() => setPop(true)} /> : null} />
      {full ? <PopoutPlaceholder title={title} onOpen={() => setPop(true)} /> : children}
      {full && (
        <PopoutFrame title={title} onExit={() => setPop(false)}
          extras={<>{rules && <button type="button" onClick={() => setRulesOpen(true)} className="flex h-8 w-8 items-center justify-center rounded-md bg-navy-700 text-sm font-bold text-slate-200" aria-label="Rules and payouts">i</button>}<SoundMenu game={game} /></>}>
          <div className="space-y-3">{children}</div>
        </PopoutFrame>
      )}
      {rules && <Modal open={rulesOpen} onClose={() => setRulesOpen(false)} title="Rules & payouts"><div className="space-y-2 text-xs leading-relaxed text-slate-300">{rules}</div></Modal>}
      {history && (
        <div className="flex items-center justify-between px-1 text-xs text-slate-400">
          <span>Last {history.length} {game === 'slot' ? 'spins' : 'rounds'}</span>
          <span className={`font-bold tabular-nums ${net > 0 ? 'text-brand-400' : net < 0 ? 'text-red-400' : 'text-slate-200'}`}>{signed(net)}</span>
        </div>
      )}
      {rules && (
        <details className="card overflow-hidden">
          <summary className="cursor-pointer px-4 py-3 text-sm font-bold text-white hover:bg-navy-800">Rules & payouts</summary>
          <div className="space-y-2 border-t border-navy-700 p-4 text-xs leading-relaxed text-slate-300">{rules}</div>
        </details>
      )}
    </div>
  );
}

export const SUIT = { S: '♠', H: '♥', D: '♦', C: '♣' };
export function PlayingCard({ code, small, anim, className = '' }) {
  const dims = small ? 'h-[62px] w-11 text-[11px]' : 'h-24 w-16 text-sm sm:h-28 sm:w-20';
  const animCls = anim === 'flip' ? 'animate-card-flip' : anim === 'deal' ? 'animate-card-deal' : '';
  if (!code || code === '??') {
    return (
      <div className={`${animCls} relative ${dims} shrink-0 rounded-md border-2 border-white/85 bg-gradient-to-br from-red-800 to-red-950 shadow-[0_3px_8px_rgba(0,0,0,0.5)] ${className}`}>
        <div className="absolute inset-1 rounded-sm border border-white/25 bg-[repeating-linear-gradient(45deg,rgba(255,255,255,0.10)_0_4px,transparent_4px_8px)]" />
      </div>
    );
  }
  const rank = code.slice(0, -1), suit = code.slice(-1);
  const red = suit === 'H' || suit === 'D';
  return (
    <div className={`${animCls} relative ${dims} shrink-0 rounded-md bg-white shadow-[0_3px_8px_rgba(0,0,0,0.5)] ${red ? 'text-red-600' : 'text-navy-950'} ${className}`}>
      <div className="absolute left-1 top-0.5 font-extrabold leading-none">{rank}<div className="text-[0.9em] leading-none">{SUIT[suit]}</div></div>
      <div className={`absolute inset-0 flex items-center justify-center ${small ? 'text-xl' : 'text-3xl'}`}>{SUIT[suit]}</div>
      <div className="absolute bottom-0.5 right-1 rotate-180 font-extrabold leading-none">{rank}<div className="text-[0.9em] leading-none">{SUIT[suit]}</div></div>
    </div>
  );
}

export const STAKES = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000];

/**
 * Honest outcome of one paid spin/round. A return smaller than the stake is a
 * loss, so it is never styled or sounded as a win. Free spins (staked 0) are wins.
 */
export function netOutcome(win, staked) {
  if (!win) return 'none';
  if (!staked) return 'win';
  return win > staked ? 'win' : win === staked ? 'even' : 'partial';
}
export const isRealWin = (win, staked) => netOutcome(win, staked) === 'win';

export function WinAmount({ win, staked }) {
  const k = netOutcome(win, staked);
  if (k === 'win') {
    return (
      <div className="font-cond text-3xl font-extrabold tabular-nums text-gold-400">
        {money(win)}{staked ? <span className="ml-2 align-middle text-base font-bold text-brand-400">+{money(win - staked)}</span> : null}
      </div>
    );
  }
  return (
    <div>
      <div className="font-cond text-xl font-bold tabular-nums text-slate-200">{k === 'even' ? `Stake returned · ${money(win)}` : `Returned ${money(win)} of ${money(staked)}`}</div>
      {k === 'partial' && <div className="text-[11px] font-semibold text-red-300">Net {signed(win - staked)} on this spin</div>}
    </div>
  );
}
