import { signed, money } from '../lib/format.js';

export function PLChart({ series }) {
  if (!series?.length) return <div className="flex h-48 items-center justify-center text-sm text-slate-500">No settled bets yet</div>;
  const pts = [{ t: series[0].t - 1, pl: 0 }, ...series];
  const W = 600, H = 200, P = 28;
  const min = Math.min(0, ...pts.map((p) => p.pl));
  const max = Math.max(0, ...pts.map((p) => p.pl));
  const span = max - min || 1;
  const x = (i) => P + (i / (pts.length - 1)) * (W - P * 2);
  const y = (v) => H - P - ((v - min) / span) * (H - P * 2);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.pl).toFixed(1)}`).join(' ');
  const last = pts[pts.length - 1].pl;
  const color = last >= 0 ? '#19c37d' : '#ef4444';
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-52 w-full" role="img" aria-label={`Profit and loss over time, now ${signed(last)} virtual`}>
      <defs>
        <linearGradient id="plfill" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity="0.25" />
          <stop offset="1" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <line x1={P} x2={W - P} y1={y(0)} y2={y(0)} stroke="#34495f" strokeDasharray="4 4" />
      <text x={4} y={y(max) + 4} fill="#64748b" fontSize="11">{signed(max)}</text>
      <text x={4} y={y(min) + 4} fill="#64748b" fontSize="11">{signed(min)}</text>
      <path d={`${d} L${x(pts.length - 1)},${y(0)} L${x(0)},${y(0)} Z`} fill="url(#plfill)" />
      <path d={d} fill="none" stroke={color} strokeWidth="2.5" strokeLinejoin="round" />
      <circle cx={x(pts.length - 1)} cy={y(last)} r="4" fill={color} />
    </svg>
  );
}

export function WinLossDonut({ won, lost, voided }) {
  const total = won + lost + voided;
  const R = 52, C = 2 * Math.PI * R;
  const parts = [[won, '#19c37d', 'Won'], [lost, '#ef4444', 'Lost'], [voided, '#f5c518', 'Void']];
  let offset = 0;
  return (
    <div className="flex items-center gap-6">
      <svg viewBox="0 0 140 140" className="h-36 w-36 shrink-0 -rotate-90" role="img" aria-label={`${won} won, ${lost} lost, ${voided} void`}>
        <circle cx="70" cy="70" r={R} fill="none" stroke="#1b2d40" strokeWidth="18" />
        {total > 0 && parts.map(([v, c]) => {
          const len = (v / total) * C;
          const el = <circle key={c} cx="70" cy="70" r={R} fill="none" stroke={c} strokeWidth="18" strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-offset} />;
          offset += len;
          return el;
        })}
      </svg>
      <div className="space-y-2 text-sm">
        {parts.map(([v, c, l]) => (
          <div key={l} className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-sm" style={{ background: c }} />
            <span className="w-10 text-slate-400">{l}</span>
            <span className="font-bold text-white tabular-nums">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function MarketBars({ markets }) {
  if (!markets?.length) return <div className="py-8 text-center text-sm text-slate-500">Settle some bets to see performance by market</div>;
  const maxAbs = Math.max(1, ...markets.map((m) => Math.abs(m.profit)));
  return (
    <div className="space-y-2.5">
      {markets.map((m) => (
        <div key={m.market} className="grid grid-cols-[minmax(0,9rem)_1fr_4.5rem] items-center gap-3 text-xs sm:grid-cols-[minmax(0,12rem)_1fr_5rem]">
          <div className="truncate text-slate-300" title={m.market}>{m.market} <span className="text-slate-500">({m.bets})</span></div>
          <div className="relative h-4 rounded bg-navy-800">
            <div className="absolute inset-y-0 left-1/2 w-px bg-navy-500" />
            <div
              className={`absolute inset-y-0 rounded ${m.profit >= 0 ? 'left-1/2 bg-brand-500' : 'right-1/2 bg-red-500'}`}
              style={{ width: `${(Math.abs(m.profit) / maxAbs) * 50}%` }}
            />
          </div>
          <div className={`text-right font-bold tabular-nums ${m.profit > 0 ? 'text-brand-400' : m.profit < 0 ? 'text-red-400' : 'text-slate-300'}`}>{signed(m.profit)}</div>
        </div>
      ))}
      <p className="pt-1 text-[11px] text-slate-500">Singles grouped by market; accumulators shown together. Staked {money(markets.reduce((a, m) => a + m.staked, 0))} in total (virtual).</p>
    </div>
  );
}
