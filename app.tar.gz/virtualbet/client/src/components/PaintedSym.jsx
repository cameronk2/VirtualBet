// A painted symbol tile (generated art) with a tier treatment, so the symbols
// that matter stand out: specials get a glowing coloured frame and a gentle
// pulse; card letters are smaller and muted; mid symbols slightly smaller.
// `badge` overlays live text (for example a wild's ×3 multiplier).
export default function PaintedSym({ src, alt, tier = 'premium', glow = '#facc15', badge, className = '' }) {
  const img = tier === 'low' ? 'scale-[.86] brightness-[.8] saturate-[.7]' : tier === 'mid' ? 'scale-[.94]' : '';
  return (
    <div className={`relative h-full w-full ${className}`}>
      <img src={src} alt={alt} draggable="false"
        className={`h-full w-full select-none rounded-lg object-cover ${img} ${tier === 'special' ? 'ps-special ring-[3px]' : ''}`}
        style={tier === 'special' ? { '--g': glow, '--tw-ring-color': glow } : undefined} />
      {badge != null && <span className="pointer-events-none absolute right-[6%] top-[6%] rounded-full bg-black/80 px-1.5 font-cond text-[clamp(9px,2.6vw,15px)] font-extrabold leading-tight text-white ring-2" style={{ '--tw-ring-color': glow }}>{badge}</span>}
    </div>
  );
}
