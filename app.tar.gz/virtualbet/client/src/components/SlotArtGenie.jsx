// Golden Wishes art: an original genie (symbol and full stage character with
// poses), magic lamp, wishing star, princess, palace, treasure chest, crown,
// three cut gems, jewelled card letters, treasure-pick objects, logo and lobby
// emblem. All hand-drawn SVG. Gradients and filters: <GenieDefs />.

import { GENIE_IMG } from '../assets/genie/index.js';

export function GenieDefs() {
  const lg = (id, stops, x2 = 0, y2 = 1) => <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  const rg = (id, stops, cx = '42%', cy = '36%', r = '65%') => <radialGradient id={id} cx={cx} cy={cy} r={r}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {rg('gnSkin', [[0, '#a5f3fc'], [0.5, '#22b8cf'], [1, '#0e5a74']])}
        {lg('gnSkinL', [[0, '#67e8f9'], [1, '#0e7490']], 1, 1)}
        {lg('gnGold', [[0, '#fffbeb'], [0.3, '#fde047'], [0.65, '#d97706'], [1, '#78350f']])}
        {lg('gnGoldH', [[0, '#92400e'], [0.25, '#fde047'], [0.5, '#fffbeb'], [0.75, '#fbbf24'], [1, '#92400e']], 1, 0)}
        {lg('gnPurple', [[0, '#f0abfc'], [0.4, '#a21caf'], [1, '#3b0764']])}
        {lg('gnViolet', [[0, '#c4b5fd'], [0.5, '#7c3aed'], [1, '#2e1065']])}
        {lg('gnRose', [[0, '#fecdd3'], [0.5, '#e11d48'], [1, '#4c0519']])}
        {lg('gnEmerald', [[0, '#bbf7d0'], [0.45, '#10b981'], [1, '#064e3b']])}
        {lg('gnTurq', [[0, '#ccfbf1'], [0.5, '#14b8a6'], [1, '#134e4a']])}
        {lg('gnSapph', [[0, '#bfdbfe'], [0.5, '#2563eb'], [1, '#172554']])}
        {lg('gnRuby', [[0, '#fecaca'], [0.45, '#e11d48'], [1, '#4c0519']])}
        {lg('gnAmeth', [[0, '#f5d0fe'], [0.45, '#9333ea'], [1, '#2e1065']])}
        {lg('gnWood', [[0, '#a16207'], [0.5, '#713f12'], [1, '#3b1d06']])}
        {lg('gnHair', [[0, '#3f2a1d'], [1, '#0c0705']])}
        {lg('gnSkinW', [[0, '#fde7d3'], [1, '#d6a27a']])}
        {lg('gnTallBg', [[0, '#4c1d95'], [0.5, '#0e7490'], [1, '#12052b']])}
        {lg('gnNight', [[0, '#1e0b3b'], [0.55, '#4c1d95'], [1, '#be185d']])}
        {lg('gnSmoke', [[0, '#a5f3fc'], [0.6, '#5eead4'], [1, 'rgba(94,234,212,0)']])}
        {rg('gnGlow', [[0, 'rgba(253,224,71,.9)'], [0.5, 'rgba(250,204,21,.35)'], [1, 'rgba(250,204,21,0)']], '50%', '50%', '50%')}
        {rg('gnStarBg', [[0, '#fef9c3'], [0.4, '#facc15'], [1, '#7c2d12']], '50%', '45%')}
        <filter id="gnShine" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="1.2" /></filter>
      </defs>
    </svg>
  );
}

const sparkle = (x, y, s = 1, fill = '#fff') => <path d={`M${x} ${y - 5 * s}l${1.2 * s} ${3.8 * s} ${3.8 * s} ${1.2 * s}-${3.8 * s} ${1.2 * s}-${1.2 * s} ${3.8 * s}-${1.2 * s}-${3.8 * s}-${3.8 * s}-${1.2 * s} ${3.8 * s}-${1.2 * s}z`} fill={fill} />;

/** The genie. pose: crossed | up | magic | wow. Used on the reels (crossed) and on stage. */
export function GenieFigure({ pose = 'crossed', blink = false }) {
  const mouth = pose === 'wow' ? <ellipse cx="50" cy="49.5" rx="3.2" ry="3.6" fill="#3b0764" />
    : pose === 'up' || pose === 'magic' ? <path d="M43.5 47.5Q50 55 56.5 47.5Z" fill="#3b0764" stroke="#fff" strokeWidth=".8" />
      : <path d="M45 48.5Q50 52.5 55 48.5" fill="none" stroke="#3b0764" strokeWidth="1.8" strokeLinecap="round" />;
  const eyes = blink ? <g stroke="#0b3b4b" strokeWidth="1.6" strokeLinecap="round"><path d="M41 36h6M53 36h6" /></g> : (
    <g>
      <ellipse cx="44" cy="35.5" rx="3.6" ry={pose === 'wow' ? 4.8 : 4.2} fill="#fff" /><ellipse cx="56" cy="35.5" rx="3.6" ry={pose === 'wow' ? 4.8 : 4.2} fill="#fff" />
      <circle cx="44.6" cy="36.2" r="2" fill="#1e1b4b" /><circle cx="55.4" cy="36.2" r="2" fill="#1e1b4b" />
      <circle cx="45.3" cy="35.3" r=".7" fill="#fff" /><circle cx="56.1" cy="35.3" r=".7" fill="#fff" />
    </g>
  );
  const browY = pose === 'wow' ? 27.5 : 29.5;
  const cuff = (x, y, r = 0) => <rect x={x - 4} y={y - 2.4} width="8" height="4.8" rx="1.6" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".6" transform={`rotate(${r} ${x} ${y})`} />;
  return (
    <g>
      {/* smoke tail */}
      <path d="M38 78C28 86 34 96 46 95C58 94 66 99 72 92C64 95 56 90 60 86C64 82 62 78 60 78Z" fill="url(#gnSkinL)" opacity=".9" />
      <path d="M44 86C40 92 50 94 56 92" fill="none" stroke="#a5f3fc" strokeWidth="1.6" strokeLinecap="round" opacity=".8" />
      {/* torso */}
      <path d="M28 62C30 55 38 53 50 53C62 53 70 55 72 62L66 80H34Z" fill="url(#gnSkin)" />
      <path d="M33 58C38 66 40 74 39 80H34L28 62C29 60 31 58.5 33 58ZM67 58C62 66 60 74 61 80H66L72 62C71 60 69 58.5 67 58Z" fill="url(#gnPurple)" stroke="url(#gnGold)" strokeWidth="1.2" />
      <path d="M36 77H64L62 83H38Z" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".6" /><circle cx="50" cy="80" r="2.4" fill="url(#gnRuby)" stroke="#fde047" strokeWidth=".6" />
      {/* arms */}
      {pose === 'crossed' && <g>
        <path d="M29 62C24 70 32 74 42 72L62 70C66 69 66 65 62 65L42 66C38 66 36 63 34 60Z" fill="url(#gnSkinL)" stroke="#0e5a74" strokeWidth=".6" />
        <path d="M71 62C76 70 68 75 58 73L38 72C34 71.5 34 67.5 38 67.5L58 68C62 68 64 64 66 60Z" fill="url(#gnSkin)" stroke="#0e5a74" strokeWidth=".6" />
        {cuff(41, 69.5, -4)}{cuff(59, 70.5, 4)}
      </g>}
      {pose === 'up' && <g>
        <path d="M30 60C22 52 18 40 20 28C21 25 25 25 26 28C27 38 30 46 36 54Z" fill="url(#gnSkinL)" stroke="#0e5a74" strokeWidth=".6" />
        <path d="M70 60C78 52 82 40 80 28C79 25 75 25 74 28C73 38 70 46 64 54Z" fill="url(#gnSkinL)" stroke="#0e5a74" strokeWidth=".6" />
        {cuff(22.6, 34, 80)}{cuff(77.4, 34, -80)}
        <circle cx="22" cy="23" r="4.2" fill="url(#gnSkinL)" /><circle cx="78" cy="23" r="4.2" fill="url(#gnSkinL)" />
        {sparkle(14, 16, 1, '#fde047')}{sparkle(86, 14, 1.1, '#fde047')}
      </g>}
      {pose === 'magic' && <g>
        <path d="M29 62C24 70 30 76 38 74C40 73 40 70 38 69C34 70 33 66 34 60Z" fill="url(#gnSkinL)" stroke="#0e5a74" strokeWidth=".6" />
        <path d="M70 60C78 56 84 48 88 40C89 37 86 35 84 37C80 43 74 50 66 54Z" fill="url(#gnSkinL)" stroke="#0e5a74" strokeWidth=".6" />
        {cuff(80, 46.5, -50)}<circle cx="87" cy="37" r="3.8" fill="url(#gnSkinL)" />
        <circle cx="92" cy="30" r="7" fill="url(#gnGlow)" />{sparkle(92, 30, 1.2, '#fff')}{sparkle(84, 24, 0.6, '#fde047')}{sparkle(97, 40, 0.5, '#fde047')}
      </g>}
      {pose === 'wow' && <g>
        <path d="M30 60C22 58 18 50 22 44C24 42 27 43 27 46C26 50 29 53 36 55Z" fill="url(#gnSkinL)" stroke="#0e5a74" strokeWidth=".6" />
        <path d="M70 60C78 58 82 50 78 44C76 42 73 43 73 46C74 50 71 53 64 55Z" fill="url(#gnSkinL)" stroke="#0e5a74" strokeWidth=".6" />
        <circle cx="24" cy="42" r="3.8" fill="url(#gnSkinL)" /><circle cx="76" cy="42" r="3.8" fill="url(#gnSkinL)" />
        {cuff(26, 50, 60)}{cuff(74, 50, -60)}
      </g>}
      {/* head */}
      <rect x="45" y="47" width="10" height="8" fill="#0e7490" />
      <ellipse cx="34.5" cy="38" rx="3.2" ry="5" fill="url(#gnSkinL)" /><ellipse cx="65.5" cy="38" rx="3.2" ry="5" fill="url(#gnSkinL)" />
      <circle cx="34.5" cy="45" r="2.6" fill="none" stroke="url(#gnGold)" strokeWidth="1.4" /><circle cx="65.5" cy="45" r="2.6" fill="none" stroke="url(#gnGold)" strokeWidth="1.4" />
      <ellipse cx="50" cy="38" rx="15.5" ry="16" fill="url(#gnSkin)" />
      {/* turban */}
      <path d="M31 30C30 18 40 10 50 10C60 10 70 18 69 30C64 25 57 24 50 24C43 24 36 25 31 30Z" fill="url(#gnViolet)" stroke="#2e1065" strokeWidth=".7" />
      <path d="M33 25C40 20 60 20 67 25M35 19C42 15 58 15 65 19" fill="none" stroke="#c4b5fd" strokeWidth="1" opacity=".6" />
      <path d="M31 29.5C36 25 44 24 50 24C56 24 64 25 69 29.5L68 32C62 28 56 27.5 50 27.5C44 27.5 38 28 32 32Z" fill="url(#gnGoldH)" />
      <path d="M51 18C54 10 60 6 64 2C62 8 60 12 54 18Z" fill="url(#gnRose)" />
      <path d="M50 15l5 6-5 6-5-6z" fill="url(#gnRuby)" stroke="url(#gnGold)" strokeWidth="1.3" /><circle cx="48.6" cy="19.5" r=".9" fill="#fff" opacity=".9" />
      {/* face */}
      <path d={`M39 ${browY + 1}Q44 ${browY - 2} 48 ${browY + 0.5}M52 ${browY + 0.5}Q56 ${browY - 2} 61 ${browY + 1}`} fill="none" stroke="#0b3b4b" strokeWidth="1.8" strokeLinecap="round" />
      {eyes}
      <path d="M50 37C48.6 40 48 42 50 43C51.6 43 52 42 51.6 41" fill="none" stroke="#0b5568" strokeWidth="1.1" strokeLinecap="round" />
      <path d="M50 44.6C46 43 41 44 38.5 41.5C38 44.5 41 47 44.5 46.6C47 46.3 49 45.6 50 45.2C51 45.6 53 46.3 55.5 46.6C59 47 62 44.5 61.5 41.5C59 44 54 43 50 44.6Z" fill="#1e1b4b" />
      {mouth}
      <ellipse cx="40" cy="42" rx="2.4" ry="1.4" fill="#f472b6" opacity=".35" /><ellipse cx="60" cy="42" rx="2.4" ry="1.4" fill="#f472b6" opacity=".35" />
    </g>
  );
}

export function Lamp({ glow = true }) {
  return (
    <g>
      {glow && <circle cx="50" cy="56" r="40" fill="url(#gnGlow)" opacity=".55" />}
      <path d="M55 40C52 30 58 24 54 16C60 22 62 30 58 40Z" fill="url(#gnSmoke)" opacity=".85" />
      <path d="M48 36C46 30 50 26 48 20" fill="none" stroke="#a5f3fc" strokeWidth="1.6" strokeLinecap="round" opacity=".7" />
      <ellipse cx="50" cy="80" rx="18" ry="4.5" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".8" />
      <path d="M40 76H60L57 70H43Z" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".8" />
      <path d="M14 58C20 58 26 60 32 62C30 54 38 44 52 44C64 44 72 52 72 60C78 56 84 54 88 56C84 58 80 64 76 66C72 72 64 74 52 74C38 74 30 70 28 66C22 64 16 62 14 58Z" fill="url(#gnGold)" stroke="#78350f" strokeWidth="1" />
      <path d="M72 54C82 46 92 50 88 60C86 64 80 64 78 62" fill="none" stroke="url(#gnGold)" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M38 46C42 40 48 38 52 38C56 38 62 40 66 46Z" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".8" /><circle cx="52" cy="36" r="3.2" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".6" />
      <path d="M34 62C42 64 60 64 70 62" fill="none" stroke="#78350f" strokeWidth=".8" opacity=".6" />
      <circle cx="52" cy="57" r="4" fill="url(#gnRuby)" stroke="#fde047" strokeWidth="1" /><circle cx="42" cy="58" r="2.2" fill="url(#gnEmerald)" /><circle cx="62" cy="58" r="2.2" fill="url(#gnSapph)" />
      <path d="M30 56C36 50 44 48 50 48" fill="none" stroke="#fffbeb" strokeWidth="2" strokeLinecap="round" opacity=".75" />
      {sparkle(24, 42, 0.9)}{sparkle(76, 30, 0.6, '#fde047')}
    </g>
  );
}

export function WishStar({ label = 'FREE' }) {
  const pts = Array.from({ length: 16 }, (_, i) => { const a = (i / 16) * Math.PI * 2 - Math.PI / 2, r = i % 2 ? 17 : 34; return `${50 + Math.cos(a) * r},${46 + Math.sin(a) * r}`; }).join(' ');
  return (
    <g>
      <circle cx="50" cy="46" r="40" fill="url(#gnGlow)" opacity=".6" />
      <polygon points={pts} fill="url(#gnGold)" stroke="#7c2d12" strokeWidth="1.2" />
      <circle cx="50" cy="46" r="15" fill="url(#gnNight)" stroke="url(#gnGold)" strokeWidth="2" />
      <path d="M55 38A9 9 0 1 0 55 54A7 7 0 1 1 55 38Z" fill="url(#gnGold)" />
      {sparkle(44, 42, 0.5, '#fef9c3')}
      <rect x="22" y="78" width="56" height="16" rx="8" fill="#4c1d95" stroke="url(#gnGold)" strokeWidth="1.6" />
      {label && <text x="50" y="90.5" textAnchor="middle" fontFamily="'Cinzel', Georgia, serif" fontWeight="800" fontSize="12" fill="#fde047" letterSpacing="1">{label}</text>}
    </g>
  );
}

function Princess() {
  return (
    <g>
      <path d="M22 100C22 80 34 72 50 72C66 72 78 80 78 100Z" fill="url(#gnEmerald)" />
      <path d="M38 74C44 84 56 84 62 74" fill="none" stroke="url(#gnGold)" strokeWidth="2.4" /><circle cx="50" cy="82" r="3" fill="url(#gnRuby)" stroke="#fde047" strokeWidth=".8" />
      <path d="M26 46C22 66 26 82 34 90L38 60ZM74 46C78 66 74 82 66 90L62 60Z" fill="url(#gnHair)" />
      <rect x="45" y="58" width="10" height="14" fill="#d6a27a" />
      <ellipse cx="50" cy="46" rx="15" ry="17" fill="url(#gnSkinW)" />
      <path d="M34 44C34 28 42 22 50 22C58 22 66 28 66 44C62 36 56 32 50 33C44 32 38 36 34 44Z" fill="url(#gnHair)" />
      <path d="M33 38C38 30 62 30 67 38" fill="none" stroke="url(#gnGoldH)" strokeWidth="2.6" /><path d="M50 30l3.6 4.4L50 39l-3.6-4.6z" fill="url(#gnEmerald)" stroke="#fde047" strokeWidth=".8" />
      <path d="M30 36C24 50 28 70 36 76C30 64 30 50 34 40Z" fill="url(#gnRose)" opacity=".75" /><path d="M70 36C76 50 72 70 64 76C70 64 70 50 66 40Z" fill="url(#gnRose)" opacity=".75" />
      <path d="M41.5 44Q44 42.5 46.5 44M53.5 44Q56 42.5 58.5 44" fill="none" stroke="#1c0f08" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M41.5 44.5l-1.5-1M58.5 44.5l1.5-1" stroke="#1c0f08" strokeWidth="1" />
      <path d="M50 46.5v4.5" stroke="#b07a55" strokeWidth="1" strokeLinecap="round" />
      <path d="M46 54.5Q50 57.5 54 54.5" fill="#be123c" stroke="#9f1239" strokeWidth=".8" />
      <ellipse cx="42" cy="51" rx="2.4" ry="1.3" fill="#fb7185" opacity=".35" /><ellipse cx="58" cy="51" rx="2.4" ry="1.3" fill="#fb7185" opacity=".35" />
      <circle cx="35" cy="52" r="2" fill="url(#gnGold)" /><circle cx="65" cy="52" r="2" fill="url(#gnGold)" />
    </g>
  );
}

function Palace() {
  const dome = (x, y, w, h) => <g><path d={`M${x - w} ${y}C${x - w} ${y - h * 0.6} ${x - w * 0.2} ${y - h * 0.7} ${x} ${y - h}C${x + w * 0.2} ${y - h * 0.7} ${x + w} ${y - h * 0.6} ${x + w} ${y}Z`} fill="url(#gnGold)" stroke="#78350f" strokeWidth=".8" /><path d={`M${x} ${y - h}v-5`} stroke="#fde047" strokeWidth="1.4" /><circle cx={x} cy={y - h - 6} r="1.6" fill="#fde047" /></g>;
  return (
    <g>
      <circle cx="74" cy="20" r="9" fill="#fef9c3" opacity=".9" /><circle cx="78" cy="17" r="8" fill="#1e0b3b" opacity=".0" />
      {sparkle(20, 16, 0.6)}{sparkle(32, 8, 0.4)}
      <rect x="12" y="44" width="8" height="46" fill="url(#gnTurq)" />{dome(16, 44, 6, 12)}
      <rect x="80" y="44" width="8" height="46" fill="url(#gnTurq)" />{dome(84, 44, 6, 12)}
      <rect x="22" y="56" width="56" height="34" fill="#f5f0e1" stroke="#a16207" strokeWidth=".8" />
      {dome(50, 56, 22, 30)}
      {dome(30, 58, 7, 12)}{dome(70, 58, 7, 12)}
      <path d="M42 90V74C42 68 58 68 58 74V90Z" fill="#4c1d95" stroke="url(#gnGold)" strokeWidth="1.6" />
      {[28, 66].map((x) => <path key={x} d={`M${x} 80v-6c0-3 6-3 6 0v6z`} fill="#0e7490" stroke="#a16207" strokeWidth=".6" />)}
      <rect x="8" y="90" width="84" height="5" rx="1" fill="url(#gnGold)" />
    </g>
  );
}

function Chest() {
  return (
    <g>
      <circle cx="50" cy="40" r="34" fill="url(#gnGlow)" opacity=".5" />
      <path d="M18 50C18 30 82 30 82 50Z" fill="url(#gnWood)" stroke="#3b1d06" strokeWidth="1" />
      <path d="M26 46C34 36 66 36 74 46" fill="none" stroke="url(#gnGoldH)" strokeWidth="3" />
      {[[30, 34, 'gnRuby'], [42, 26, 'gnEmerald'], [56, 25, 'gnSapph'], [68, 33, 'gnAmeth']].map(([x, y, g], i) => <circle key={i} cx={x} cy={y} r={4} fill={`url(#${g})`} stroke="#fde047" strokeWidth=".8" />)}
      {[[36, 30], [50, 22], [62, 28], [46, 30], [58, 32]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="4.5" fill="url(#gnGold)" stroke="#92400e" strokeWidth=".6" />)}
      <rect x="16" y="50" width="68" height="38" rx="3" fill="url(#gnWood)" stroke="#3b1d06" strokeWidth="1" />
      <rect x="16" y="50" width="68" height="6" fill="url(#gnGoldH)" /><rect x="16" y="82" width="68" height="6" fill="url(#gnGoldH)" />
      <rect x="24" y="50" width="6" height="38" fill="url(#gnGold)" opacity=".9" /><rect x="70" y="50" width="6" height="38" fill="url(#gnGold)" opacity=".9" />
      <rect x="43" y="58" width="14" height="16" rx="2" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".8" /><circle cx="50" cy="64" r="2.6" fill="#3b1d06" /><path d="M49 66h2l1 5h-4z" fill="#3b1d06" />
      <circle cx="37" cy="69" r="3" fill="url(#gnRuby)" stroke="#fde047" strokeWidth=".7" /><circle cx="63" cy="69" r="3" fill="url(#gnEmerald)" stroke="#fde047" strokeWidth=".7" />
      {sparkle(80, 22, 0.8)}{sparkle(22, 26, 0.6, '#fde047')}
    </g>
  );
}

function Crown() {
  return (
    <g>
      <path d="M16 74L12 32L32 50L50 22L68 50L88 32L84 74Z" fill="url(#gnGold)" stroke="#78350f" strokeWidth="1.2" strokeLinejoin="round" />
      {[[12, 32], [50, 22], [88, 32]].map(([x, y], i) => <circle key={i} cx={x} cy={y - 3} r="4.5" fill="url(#gnGold)" stroke="#78350f" strokeWidth=".8" />)}
      <rect x="14" y="70" width="72" height="14" rx="3" fill="url(#gnGoldH)" stroke="#78350f" strokeWidth="1" />
      <path d="M50 46l6 8-6 8-6-8z" fill="url(#gnRuby)" stroke="#fde047" strokeWidth="1" />
      <circle cx="30" cy="62" r="4" fill="url(#gnSapph)" stroke="#fde047" strokeWidth=".8" /><circle cx="70" cy="62" r="4" fill="url(#gnEmerald)" stroke="#fde047" strokeWidth=".8" />
      {[24, 38, 50, 62, 76].map((x, i) => <circle key={x} cx={x} cy="77" r="2.4" fill={i % 2 ? 'url(#gnRuby)' : 'url(#gnEmerald)'} />)}
      <path d="M20 40L30 52" stroke="#fffbeb" strokeWidth="1.6" opacity=".7" strokeLinecap="round" />
      {sparkle(84, 14, 0.7)}
    </g>
  );
}

// Three cuts: round brilliant (amethyst), emerald cut (emerald), trillion/heart (ruby).
function Amethyst() {
  return (
    <g>
      <path d="M50 12L80 30L80 64L50 88L20 64L20 30Z" fill="url(#gnAmeth)" stroke="#2e1065" strokeWidth="1" />
      <path d="M50 12L62 34L80 30M62 34L80 64M62 34L50 60L38 34L50 12M38 34L20 30M38 34L20 64M50 60L80 64M50 60L20 64M50 60L50 88" fill="none" stroke="#f5d0fe" strokeWidth=".9" opacity=".7" />
      <path d="M50 12L62 34H38Z" fill="#f5d0fe" opacity=".45" />
      {sparkle(34, 24, 0.8)}
    </g>
  );
}
function Emerald() {
  return (
    <g>
      <path d="M30 14H70L84 28V72L70 86H30L16 72V28Z" fill="url(#gnEmerald)" stroke="#064e3b" strokeWidth="1" />
      <path d="M36 24H64L74 34V66L64 76H36L26 66V34Z" fill="#34d399" opacity=".45" stroke="#bbf7d0" strokeWidth=".8" />
      <path d="M42 34H58L64 40V60L58 66H42L36 60V40Z" fill="#6ee7b7" opacity=".5" stroke="#bbf7d0" strokeWidth=".6" />
      <path d="M30 14L36 24M70 14L64 24M84 28L74 34M84 72L74 66M70 86L64 76M30 86L36 76M16 72L26 66M16 28L26 34" stroke="#bbf7d0" strokeWidth=".7" opacity=".7" />
      {sparkle(66, 22, 0.8)}
    </g>
  );
}
function Ruby() {
  return (
    <g>
      <path d="M50 88L12 40L26 18H74L88 40Z" fill="url(#gnRuby)" stroke="#4c0519" strokeWidth="1" />
      <path d="M12 40H88M26 18L36 40L50 18L64 40L74 18M36 40L50 88L64 40" fill="none" stroke="#fecaca" strokeWidth=".9" opacity=".7" />
      <path d="M26 18L36 40H12Z" fill="#fecaca" opacity=".35" />
      {sparkle(70, 28, 0.8)}
    </g>
  );
}

const LETTER_FILL = { A: 'url(#gnRuby)', K: 'url(#gnSapph)', Q: 'url(#gnAmeth)', J: 'url(#gnEmerald)', T: 'url(#gnTurq)' };
export function Letter({ ch, noText = false }) {
  const txt = ch === 'T' ? '10' : ch;
  return (
    <g>
      <path d="M50 8C58 16 70 16 78 14C76 24 80 32 88 36C80 42 80 58 88 64C80 68 76 76 78 86C70 84 58 84 50 92C42 84 30 84 22 86C24 76 20 68 12 64C20 58 20 42 12 36C20 32 24 24 22 14C30 16 42 16 50 8Z" fill="#1e0b3b" stroke="url(#gnGold)" strokeWidth="2" opacity=".85" />
      {!noText && <text x="50" y={ch === 'T' ? 66 : 68} textAnchor="middle" fontFamily="'Cinzel', Georgia, serif" fontWeight="900" fontSize={ch === 'T' ? 38 : 50} fill={LETTER_FILL[ch]} stroke="#fde047" strokeWidth="2" paintOrder="stroke" {...(ch === 'T' ? { textLength: 52, lengthAdjust: 'spacingAndGlyphs' } : {})}>{txt}</text>}
    </g>
  );
}

/** The expanding wild for the canvas renderer: a full-reel genie rising from smoke (viewBox 100 x 300). */
export function TallGenie() {
  return (
    <g>
      <rect width="100" height="300" rx="8" fill="url(#gnTallBg)" />
      <path d="M50 300C20 280 30 250 46 236C30 220 40 196 50 188C60 196 70 220 54 236C70 250 80 280 50 300Z" fill="url(#gnSmoke)" opacity=".85" />
      {[[22, 250, 18], [78, 262, 16], [36, 284, 20], [66, 222, 14]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill="#a5f3fc" opacity=".25" />)}
      <g transform="translate(-30 30) scale(1.6)"><GenieFigure pose="up" /></g>
      <path d="M8 6H92" stroke="url(#gnGoldH)" strokeWidth="3" /><path d="M8 294H92" stroke="url(#gnGoldH)" strokeWidth="3" />
      <text x="50" y="286" textAnchor="middle" fontFamily="Georgia, serif" fontWeight="900" fontSize="15" fill="#fde047" stroke="#3b0764" strokeWidth="3" paintOrder="stroke" letterSpacing="2">WILD</text>
    </g>
  );
}

export const GENIE_ART = {
  GENIE: <GenieFigure />, LAMP: <Lamp />, STAR: <WishStar />,
  PRINCESS: <Princess />, PALACE: <Palace />, CHEST: <Chest />, CROWN: <Crown />,
  AMETHYST: <Amethyst />, EMERALD: <Emerald />, RUBY: <Ruby />,
  A: <Letter ch="A" />, K: <Letter ch="K" />, Q: <Letter ch="Q" />, J: <Letter ch="J" />, T: <Letter ch="T" />,
};
export const GENIE_NAMES = { GENIE: 'Genie (wild)', LAMP: 'Magic Lamp', STAR: 'Wishing Star', PRINCESS: 'Princess', PALACE: 'Golden Palace', CHEST: 'Treasure Chest', CROWN: 'Golden Crown', AMETHYST: 'Purple Gem', EMERALD: 'Emerald', RUBY: 'Ruby', A: 'A', K: 'K', Q: 'Q', J: 'J', T: '10' };
const PREMIUM = new Set(['PRINCESS', 'PALACE', 'CHEST', 'CROWN']);

export function GenieSym({ s, className = '' }) {
  if (GENIE_IMG[s]) {
    // tiers: specials get a neon frame and label, card letters are smaller and muted
    const sp = { GENIE: ['ring-cyan-300 shadow-[0_0_14px_rgba(34,211,238,0.9)]', 'WILD', 'bg-cyan-700'], LAMP: ['ring-yellow-300 shadow-[0_0_14px_rgba(250,204,21,0.9)]', 'BONUS', 'bg-amber-800'], STAR: ['ring-pink-400 shadow-[0_0_14px_rgba(244,114,182,0.9)]', null] }[s];
    const low = ['A', 'K', 'Q', 'J', 'T'].includes(s), gem = ['AMETHYST', 'EMERALD', 'RUBY'].includes(s);
    return (
      <div className={`relative h-full w-full ${className}`}>
        <img src={GENIE_IMG[s]} alt={GENIE_NAMES[s] || s} draggable="false"
          className={`h-full w-full select-none rounded-lg object-cover ${sp ? `gn-special ring-[3px] ${sp[0]}` : ''} ${low ? 'scale-[.86] brightness-[.78] saturate-[.65]' : gem ? 'scale-[.93] saturate-[.9]' : ''}`} />
        {sp?.[1] && <span className={`pointer-events-none absolute inset-x-[14%] bottom-[5%] rounded-full ${sp[2]} py-[1px] text-center font-[Cinzel,Georgia,serif] text-[clamp(7px,2.4vw,13px)] font-extrabold leading-tight tracking-wider text-white ring-1 ring-white/60`}>{sp[1]}</span>}
      </div>
    );
  }
  const bg = s === 'GENIE' ? 'bg-[radial-gradient(circle_at_50%_40%,rgba(103,232,249,0.55),rgba(30,11,59,0.95))] ring-2 ring-cyan-300/80'
    : s === 'LAMP' ? 'bg-[radial-gradient(circle_at_50%_55%,rgba(253,224,71,0.5),rgba(59,7,100,0.95))] ring-2 ring-yellow-300/80'
      : s === 'STAR' ? 'bg-[radial-gradient(circle_at_50%_45%,rgba(244,114,182,0.45),rgba(30,11,59,0.95))] ring-2 ring-pink-300/70'
        : PREMIUM.has(s) ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(250,204,21,0.35),rgba(46,16,101,0.92))] ring-1 ring-amber-300/60'
          : ['AMETHYST', 'EMERALD', 'RUBY'].includes(s) ? 'bg-[radial-gradient(circle_at_50%_40%,rgba(94,234,212,0.22),rgba(23,8,46,0.9))] ring-1 ring-teal-300/30'
            : 'bg-[radial-gradient(circle_at_50%_40%,rgba(124,58,237,0.25),rgba(15,6,30,0.85))] ring-1 ring-violet-400/20';
  return (
    <div className={`relative h-full w-full rounded-lg ${bg} ${className}`}>
      <svg viewBox="0 0 100 100" className="h-full w-full p-[5%]" role="img" aria-label={GENIE_NAMES[s] || s}>{GENIE_ART[s]}</svg>
    </div>
  );
}

/** Genie's Treasure objects (face down). */
export const TREASURE_OBJECTS = [
  // vase
  <g key="v"><path d="M38 20H62L58 30C72 38 74 64 62 80H38C26 64 28 38 42 30Z" fill="url(#gnTurq)" stroke="url(#gnGold)" strokeWidth="2" /><path d="M34 52H66" stroke="url(#gnGoldH)" strokeWidth="4" /><circle cx="50" cy="52" r="3.5" fill="url(#gnRuby)" /><rect x="36" y="80" width="28" height="6" rx="2" fill="url(#gnGold)" /></g>,
  // little chest
  <g key="c"><path d="M22 46C22 30 78 30 78 46Z" fill="url(#gnWood)" stroke="url(#gnGold)" strokeWidth="1.6" /><rect x="22" y="46" width="56" height="34" rx="2" fill="url(#gnWood)" stroke="url(#gnGold)" strokeWidth="1.6" /><rect x="44" y="52" width="12" height="13" rx="2" fill="url(#gnGold)" /><path d="M22 52H78" stroke="url(#gnGoldH)" strokeWidth="3" /></g>,
  // orb
  <g key="o"><circle cx="50" cy="46" r="24" fill="url(#gnAmeth)" stroke="url(#gnGold)" strokeWidth="2" /><ellipse cx="42" cy="38" rx="8" ry="5" fill="#fff" opacity=".35" /><path d="M34 70H66L60 82H40Z" fill="url(#gnGold)" />{sparkle(58, 50, 0.8, '#f5d0fe')}</g>,
  // jar
  <g key="j"><path d="M40 18H60V26C76 30 80 50 74 66C70 78 30 78 26 66C20 50 24 30 40 26Z" fill="url(#gnRose)" stroke="url(#gnGold)" strokeWidth="2" /><path d="M28 44Q50 54 72 44" stroke="url(#gnGoldH)" strokeWidth="3" fill="none" /><rect x="38" y="14" width="24" height="6" rx="2" fill="url(#gnGold)" /></g>,
];

export function GenieLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 340 96" className={className} aria-label="Golden Wishes">
      <g transform="translate(0 6) scale(.86)"><Lamp /></g>
      <text x="206" y="44" textAnchor="middle" fontFamily="'Cinzel', Georgia, serif" fontWeight="900" fontSize="36" textLength="222" lengthAdjust="spacingAndGlyphs" fill="url(#gnGold)" stroke="#3b0764" strokeWidth="4" paintOrder="stroke">GOLDEN</text>
      <text x="206" y="84" textAnchor="middle" fontFamily="'Cinzel', Georgia, serif" fontWeight="900" fontSize="36" textLength="222" lengthAdjust="spacingAndGlyphs" fill="url(#gnGold)" stroke="#3b0764" strokeWidth="4" paintOrder="stroke">WISHES</text>
      <path d="M100 54H312" stroke="url(#gnGoldH)" strokeWidth="2" /><path d="M206 49l5 5-5 5-5-5z" fill="url(#gnRuby)" />
      {sparkle(322, 18, 1.2, '#fde047')}{sparkle(96, 20, 0.8, '#fff')}
    </svg>
  );
}

export const GENIE_LOBBY = (
  <g>
    <rect width="100" height="100" fill="url(#gnNight)" />
    {[[12, 14], [86, 10], [70, 26], [24, 34], [92, 40]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r=".9" fill="#fff" />)}
    <path d="M0 78H100V100H0Z" fill="#1e0b3b" />
    <g transform="translate(64 50) scale(.38)" opacity=".8"><Palace /></g>
    <g transform="translate(14 4) scale(.74)"><GenieFigure pose="magic" /></g>
    <g transform="translate(-2 62) scale(.4)"><Lamp /></g>
  </g>
);
