import { Link } from '../lib/router.jsx';
import { dayLabel, kickoffTime } from '../lib/format.js';
import Crest from './Crest.jsx';
import OddsButton from './OddsButton.jsx';
import { Icon, LiveBadge, SimBadge } from './ui.jsx';

function TimeCell({ m, hideDay }) {
  if (m.live) {
    return (
      <div className="flex flex-col items-start gap-1">
        <LiveBadge />
        <span className="text-xs font-bold text-red-400 tabular-nums">{m.minuteLabel}</span>
        {m.simulated && <span className="text-[9px] font-bold uppercase tracking-wider text-gold-400" title="Simulated match">Sim</span>}
      </div>
    );
  }
  if (m.status === 'SCHEDULED') {
    return (
      <div className="leading-tight">
        <div className="text-sm font-bold text-white tabular-nums">{kickoffTime(m.kickoff)}</div>
        {!hideDay && <div className="text-[10px] text-slate-500">{dayLabel(m.kickoff).replace(/ \d+ \w+$/, '')}</div>}
        {m.simulated && <div className="mt-0.5 text-[9px] font-bold uppercase tracking-wider text-gold-400" title="Simulated match">Sim</div>}
      </div>
    );
  }
  return (
    <div className="leading-tight">
      <span className="text-xs font-bold uppercase text-slate-400">{m.minuteLabel}</span>
      {m.simulated && <div className="mt-0.5 text-[9px] font-bold uppercase tracking-wider text-gold-400" title="Simulated match">Sim</div>}
    </div>
  );
}

export function MatchRow({ m, market = '1X2', showLeague = false, hideDay = false }) {
  const mk = m.quick?.[market];
  const keys = market === '1X2' ? ['1', 'X', '2'] : market === 'BTTS' ? ['Y', 'N'] : ['O', 'U'];
  const labels = market === '1X2' ? ['1', 'X', '2'] : market === 'BTTS' ? ['Yes', 'No'] : ['Over', 'Under'];
  const score = m.score;
  return (
    <div className="group flex items-center gap-2 border-b border-navy-700/60 px-2.5 py-2.5 transition-colors last:border-b-0 sm:px-3 hover:bg-navy-800/60 sm:gap-3">
      <div className="w-10 shrink-0 sm:w-14">
        <TimeCell m={m} hideDay={hideDay} />
      </div>
      <Link to={`/match/${encodeURIComponent(m.id)}`} className="min-w-0 flex-1">
        {showLeague && <div className="mb-0.5 truncate text-[10px] font-semibold uppercase tracking-wide text-slate-500">{m.league.name}</div>}
        {[m.home, m.away].map((t, i) => (
          <div key={i} className="flex items-center gap-2 py-0.5">
            <Crest team={t} size={16} />
            <span className="truncate text-sm font-medium text-slate-100 group-hover:text-white">{t.name}</span>
            {score && <span className={`ml-auto pl-2 text-sm font-bold tabular-nums ${m.live ? 'text-gold-400' : 'text-slate-300'}`}>{i === 0 ? score.home : score.away}</span>}
          </div>
        ))}
      </Link>
      <div className={`grid shrink-0 gap-1 ${keys.length === 3 ? 'w-[141px] grid-cols-3 sm:w-[198px]' : 'w-[96px] grid-cols-2 sm:w-[132px]'}`}>
        {mk ? keys.map((k, i) => (
          <OddsButton key={k} match={m} market={mk} sel={mk.selections.find((s) => s.key === k)} label={labels[i]} compact />
        )) : (
          <div className={`flex h-11 items-center justify-center rounded bg-navy-800/60 text-[11px] font-medium text-slate-500 ${keys.length === 3 ? 'col-span-3' : 'col-span-2'}`}>
            {m.bettingOpen ? 'Market closed' : m.status === 'SCHEDULED' || m.live ? 'Suspended' : 'Betting closed'}
          </div>
        )}
      </div>
      <Link to={`/match/${encodeURIComponent(m.id)}`} className="hidden w-10 shrink-0 items-center justify-end text-xs font-semibold text-slate-400 hover:text-brand-400 sm:flex" aria-label="All markets">
        {m.marketCount ? `+${m.marketCount}` : ''}<Icon.chevron className="h-4 w-4" />
      </Link>
    </div>
  );
}

export function groupByLeague(matches) {
  const groups = new Map();
  for (const m of matches) {
    const k = m.league.code;
    if (!groups.has(k)) groups.set(k, { league: m.league, matches: [] });
    groups.get(k).matches.push(m);
  }
  return [...groups.values()];
}

export function MatchList({ matches, market = '1X2', grouped = true, showLeague = false, hideDay = false }) {
  const header = (
    <div className="flex items-center gap-2 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 sm:gap-3">
      <div className="flex-1" />
      <div className={`grid shrink-0 gap-1 text-center ${market === '1X2' ? 'w-[141px] grid-cols-3 sm:w-[198px]' : 'w-[96px] grid-cols-2 sm:w-[132px]'}`}>
        {(market === '1X2' ? ['1', 'X', '2'] : market === 'BTTS' ? ['Yes', 'No'] : ['O 2.5', 'U 2.5']).map((l) => <span key={l}>{l}</span>)}
      </div>
      <div className="hidden w-10 sm:block" />
    </div>
  );
  if (!grouped) {
    return (
      <div className="card overflow-hidden">
        <div className="flex items-center border-b border-navy-700 bg-navy-800 py-2">{matches.some((m) => m.simulated) && <SimBadge className="ml-3" />}<div className="flex-1">{header}</div></div>
        {matches.map((m) => <MatchRow key={m.id} m={m} market={market} showLeague={showLeague} hideDay={hideDay} />)}
      </div>
    );
  }
  return (
    <div className="space-y-3">
      {groupByLeague(matches).map((g) => (
        <section key={g.league.code} className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-navy-700 bg-navy-800 py-2 pl-3">
            <div className="min-w-0">
              <span className="text-xs font-bold text-white">{g.league.name}</span>
              {g.league.country && <span className="ml-2 text-[11px] text-slate-500">{g.league.country}</span>}
              {g.matches.every((m) => m.simulated) && <SimBadge className="ml-2" />}
            </div>
            <div className="shrink-0">{header}</div>
          </div>
          {g.matches.map((m) => <MatchRow key={m.id} m={m} market={market} hideDay={hideDay} />)}
        </section>
      ))}
    </div>
  );
}
