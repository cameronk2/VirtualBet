// Original symbol artwork for "Lakeside Lures" (no third-party assets).
const LETTER = {
  10: ['#7dd3fc', '#0369a1'], J: ['#86efac', '#15803d'], Q: ['#f9a8d4', '#be185d'],
  K: ['#fcd34d', '#b45309'], A: ['#c4b5fd', '#6d28d9'],
};

function Letter({ s }) {
  const [a, b] = LETTER[s];
  const id = `g-${s}`;
  return (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <defs><linearGradient id={id} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient></defs>
      <text x="32" y="45" textAnchor="middle" fontSize={s === '10' ? 30 : 38} fontWeight="900" fontFamily="Georgia, 'Times New Roman', serif" fill={`url(#${id})`} stroke="#0b1520" strokeWidth="2.5" paintOrder="stroke">{s}</text>
    </svg>
  );
}

const ART = {
  BOX: (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <path d="M24 18v-4h16v4" fill="none" stroke="#cbd5e1" strokeWidth="3" strokeLinecap="round" />
      <rect x="10" y="18" width="44" height="34" rx="4" fill="#16a34a" stroke="#052e16" strokeWidth="2" />
      <rect x="10" y="18" width="44" height="12" rx="4" fill="#22c55e" stroke="#052e16" strokeWidth="2" />
      <rect x="28" y="26" width="8" height="7" rx="1.5" fill="#fbbf24" stroke="#78350f" strokeWidth="1.5" />
      <path d="M16 40h10M38 40h10M16 46h10M38 46h10" stroke="#052e16" strokeWidth="2" opacity=".5" />
    </svg>
  ),
  FLY: (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <ellipse cx="20" cy="24" rx="15" ry="6" fill="#a5f3fc" fillOpacity=".75" stroke="#0e7490" strokeWidth="1.5" transform="rotate(-18 20 24)" />
      <ellipse cx="44" cy="24" rx="15" ry="6" fill="#a5f3fc" fillOpacity=".75" stroke="#0e7490" strokeWidth="1.5" transform="rotate(18 44 24)" />
      <ellipse cx="21" cy="34" rx="12" ry="5" fill="#a5f3fc" fillOpacity=".6" stroke="#0e7490" strokeWidth="1.5" transform="rotate(14 21 34)" />
      <ellipse cx="43" cy="34" rx="12" ry="5" fill="#a5f3fc" fillOpacity=".6" stroke="#0e7490" strokeWidth="1.5" transform="rotate(-14 43 34)" />
      <path d="M32 22v34" stroke="#2563eb" strokeWidth="5" strokeLinecap="round" />
      <circle cx="32" cy="19" r="5" fill="#1d4ed8" />
    </svg>
  ),
  ROD: (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <path d="M12 56L52 8" stroke="#92400e" strokeWidth="4" strokeLinecap="round" />
      <path d="M12 56l9-11" stroke="#1f2937" strokeWidth="6" strokeLinecap="round" />
      <circle cx="24" cy="44" r="6" fill="#d1d5db" stroke="#374151" strokeWidth="2" />
      <path d="M52 8C58 24 50 40 46 52" fill="none" stroke="#e5e7eb" strokeWidth="1.2" />
      <path d="M46 52c-3 4-7 2-6-1" fill="none" stroke="#e5e7eb" strokeWidth="1.8" />
    </svg>
  ),
  BOAT: (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <path d="M8 38h48l-7 13H15z" fill="#dc2626" stroke="#450a0a" strokeWidth="2" strokeLinejoin="round" />
      <path d="M8 38h48" stroke="#fef2f2" strokeWidth="3" />
      <rect x="22" y="24" width="18" height="14" rx="2" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
      <rect x="26" y="27" width="10" height="5" rx="1" fill="#38bdf8" />
      <path d="M4 56c6-3 10 3 16 0s10 3 16 0 10 3 16 0 8 2 8 2" fill="none" stroke="#7dd3fc" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  ),
  WILD: (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <circle cx="32" cy="34" r="15" fill="#fcd9b6" stroke="#7c2d12" strokeWidth="2" />
      <path d="M17 38c2 12 28 12 30 0-4 3-8 4-15 4s-11-1-15-4z" fill="#d6d3d1" stroke="#57534e" strokeWidth="1.5" />
      <path d="M12 24c4-2 36-2 40 0l-4 4H16z" fill="#65a30d" stroke="#1a2e05" strokeWidth="2" strokeLinejoin="round" />
      <path d="M20 24c0-10 24-10 24 0" fill="#84cc16" stroke="#1a2e05" strokeWidth="2" />
      <circle cx="26" cy="33" r="2" fill="#1c1917" /><circle cx="38" cy="33" r="2" fill="#1c1917" />
      <rect x="11" y="49" width="42" height="12" rx="3" fill="#0b1520" stroke="#fbbf24" strokeWidth="1.5" />
      <text x="32" y="58.5" textAnchor="middle" fontSize="9" fontWeight="900" fill="#fbbf24" fontFamily="system-ui, sans-serif">WILD</text>
    </svg>
  ),
  SCAT: (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <path d="M32 4v12" stroke="#f8fafc" strokeWidth="3" strokeLinecap="round" />
      <circle cx="32" cy="30" r="15" fill="#f8fafc" stroke="#7f1d1d" strokeWidth="2" />
      <path d="M17 30a15 15 0 0130 0z" fill="#ef4444" />
      <path d="M17 30h30" stroke="#7f1d1d" strokeWidth="2" />
      <path d="M32 45v6" stroke="#f8fafc" strokeWidth="3" strokeLinecap="round" />
      <rect x="9" y="50" width="46" height="12" rx="3" fill="#0b1520" stroke="#ef4444" strokeWidth="1.5" />
      <text x="32" y="59.5" textAnchor="middle" fontSize="8.5" fontWeight="900" fill="#fca5a5" fontFamily="system-ui, sans-serif">SCATTER</text>
    </svg>
  ),
};

function Fish({ value }) {
  return (
    <svg viewBox="0 0 64 64" className="h-full w-full">
      <defs><linearGradient id="fishg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#bef264" /><stop offset=".55" stopColor="#4d7c0f" /><stop offset="1" stopColor="#fef08a" /></linearGradient></defs>
      <path d="M50 27l11-9v20z" fill="#4d7c0f" stroke="#1a2e05" strokeWidth="1.8" strokeLinejoin="round" />
      <ellipse cx="29" cy="27" rx="23" ry="13" fill="url(#fishg)" stroke="#1a2e05" strokeWidth="2" />
      <path d="M12 26c3 1 6 1 8-1" fill="none" stroke="#1a2e05" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="15" cy="22" r="2.6" fill="#fff" /><circle cx="15" cy="22" r="1.3" fill="#111" />
      <path d="M28 15c4 3 4 21 0 24" fill="none" stroke="#365314" strokeWidth="1.5" opacity=".6" />
      <rect x="6" y="45" width="52" height="15" rx="4" fill="#0b1520" stroke="#facc15" strokeWidth="1.5" />
      <text x="32" y="56.5" textAnchor="middle" fontSize={value.length > 6 ? 9 : 11} fontWeight="900" fill="#facc15" fontFamily="system-ui, sans-serif">{value}</text>
    </svg>
  );
}

export function SlotSymbol({ cell, bet }) {
  if (!cell) return null;
  if (LETTER[cell.s]) return <Letter s={cell.s} />;
  if (cell.s === 'FISH') {
    const pence = Math.floor(((bet || 100) * (cell.v || 200)) / 100);
    const v = `£${(pence / 100).toFixed(pence % 100 === 0 ? 0 : 2)}`;
    return <Fish value={v} />;
  }
  return ART[cell.s] || null;
}

export const ALL_SYMBOLS = ['10', 'J', 'Q', 'K', 'A', 'BOX', 'FLY', 'ROD', 'BOAT', 'FISH', 'WILD', 'SCAT'];
