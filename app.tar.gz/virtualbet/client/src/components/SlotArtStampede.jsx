// Stampede Link art: original buffalo, golden buffalo, eagle, cougar, wolf
// and elk heads; branded-wood card letters; sunset wild; gold coin
// scatter; buffalo cash coins (values, jackpots, multipliers); logo and
// lobby emblem. Gradients: <StampedeDefs />.

import PaintedSym from './PaintedSym.jsx';
import { SLOT_IMG } from '../assets/slots/index.js';
export function StampedeDefs() {
  const lg = (id, stops, x2 = 0, y2 = 1) => <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  const rg = (id, stops, cx = '42%', cy = '36%') => <radialGradient id={id} cx={cx} cy={cy} r="65%">{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {rg('stFur', [[0, '#8b5a2b'], [0.55, '#5a3416'], [1, '#2a1607']])}
        {rg('stMane', [[0, '#6b4220'], [1, '#1f1006']])}
        {rg('stGoldFur', [[0, '#fff7c2'], [0.45, '#facc15'], [1, '#92400e']])}
        {lg('stHorn', [[0, '#fefce8'], [0.6, '#d6c7a1'], [1, '#57534e']])}
        {lg('stGold', [[0, '#fffbeb'], [0.35, '#fde047'], [0.7, '#d97706'], [1, '#78350f']])}
        {lg('stBronze', [[0, '#fde3c4'], [0.4, '#d08a4a'], [1, '#5b2f12']])}
        {lg('stWood', [[0, '#c48a4f'], [0.5, '#8a5527'], [1, '#4a2a10']])}
        {lg('stSunset', [[0, '#f97316'], [0.45, '#fb923c'], [0.75, '#fcd34d'], [1, '#7c2d12']])}
        {lg('stSky', [[0, '#1e1b4b'], [0.45, '#9d174d'], [0.75, '#f97316'], [1, '#fcd34d']])}
        {lg('stEagle', [[0, '#f8fafc'], [1, '#cbd5e1']])}
        {lg('stBrown', [[0, '#a16207'], [1, '#422006']])}
        {lg('stCougar', [[0, '#f5d0a0'], [0.6, '#d29a5c'], [1, '#7c4a1e']])}
        {lg('stWolf', [[0, '#e2e8f0'], [0.6, '#94a3b8'], [1, '#334155']])}
        {lg('stElk', [[0, '#d6a46b'], [0.6, '#9a6332'], [1, '#4a2a10']])}
        {lg('stTurq', [[0, '#99f6e4'], [0.5, '#14b8a6'], [1, '#134e4a']])}
        {lg('stRed', [[0, '#fecaca'], [0.5, '#dc2626'], [1, '#7f1d1d']])}
        {lg('stPurple', [[0, '#e9d5ff'], [0.5, '#9333ea'], [1, '#4c1d95']])}
        {lg('stBlue', [[0, '#bfdbfe'], [0.5, '#2563eb'], [1, '#1e3a8a']])}
        {lg('stGreen', [[0, '#bbf7d0'], [0.5, '#16a34a'], [1, '#14532d']])}
        {rg('stGlow', [[0, 'rgba(253,224,71,0.7)'], [1, 'rgba(253,224,71,0)']], '50%', '50%')}
      </defs>
    </svg>
  );
}

const T = (t, y, size, fill, stroke = '#2a1405', len) => <text x="50" y={y} textAnchor="middle" fontFamily="'Rye', 'Lilita One', Georgia, serif" fontWeight="700" fontSize={size} fill={fill} stroke={stroke} strokeWidth={size / 10} paintOrder="stroke" {...(len ? { textLength: len, lengthAdjust: 'spacingAndGlyphs' } : {})}>{t}</text>;

/** The buffalo head; `gold` for the Golden Buffalo. */
export function BuffaloHead({ gold = false }) {
  const fur = gold ? 'url(#stGoldFur)' : 'url(#stFur)', mane = gold ? 'url(#stGold)' : 'url(#stMane)', line = gold ? '#78350f' : '#160b03';
  return (
    <g>
      {gold && <circle cx="50" cy="52" r="48" fill="url(#stGlow)" />}
      {/* horns */}
      <path d="M26 34C12 34 6 22 10 10C14 20 20 24 30 26Z" fill="url(#stHorn)" stroke="#3f3a33" strokeWidth="1.6" />
      <path d="M74 34C88 34 94 22 90 10C86 20 80 24 70 26Z" fill="url(#stHorn)" stroke="#3f3a33" strokeWidth="1.6" />
      {/* shaggy crown and mane */}
      <path d="M18 44C14 26 30 14 50 14C70 14 86 26 82 44C90 52 88 66 80 70C76 84 64 94 50 94C36 94 24 84 20 70C12 66 10 52 18 44Z" fill={mane} stroke={line} strokeWidth="2" />
      {[24, 34, 44, 56, 66, 76].map((x, i) => <path key={x} d={`M${x} ${22 + (i % 2) * 3}q3 6 -1 11`} stroke={gold ? '#fef3c7' : '#8b5a2b'} strokeWidth="2" fill="none" strokeLinecap="round" opacity=".7" />)}
      {/* face */}
      <path d="M32 42C32 34 40 30 50 30C60 30 68 34 68 42L66 70C64 80 58 86 50 86C42 86 36 80 34 70Z" fill={fur} stroke={line} strokeWidth="1.8" />
      <path d="M40 66C40 60 45 58 50 58C55 58 60 60 60 66C60 74 56 80 50 80C44 80 40 74 40 66Z" fill={gold ? '#b45309' : '#2a1607'} />
      <ellipse cx="45" cy="70" rx="2.6" ry="3.4" fill={gold ? '#451a03' : '#000'} /><ellipse cx="55" cy="70" rx="2.6" ry="3.4" fill={gold ? '#451a03' : '#000'} />
      {/* eyes */}
      <ellipse cx="39" cy="48" rx="4.6" ry="3.4" fill="#fff" /><ellipse cx="61" cy="48" rx="4.6" ry="3.4" fill="#fff" />
      <circle cx="40" cy="48.5" r="2.4" fill="#1c0f05" /><circle cx="60" cy="48.5" r="2.4" fill="#1c0f05" />
      <circle cx="41" cy="47.6" r=".8" fill="#fff" /><circle cx="61" cy="47.6" r=".8" fill="#fff" />
      <path d="M33 43L45 45M67 43L55 45" stroke={line} strokeWidth="2.4" strokeLinecap="round" />
      {/* beard */}
      <path d="M40 84Q50 98 60 84Q56 92 50 94Q44 92 40 84Z" fill={mane} stroke={line} strokeWidth="1.2" />
      <path d="M34 36Q42 32 50 34" stroke={gold ? '#fff' : '#b07a45'} strokeWidth="2.5" fill="none" opacity=".5" strokeLinecap="round" />
    </g>
  );
}

function Eagle() {
  return (
    <g>
      <path d="M22 88C14 70 16 46 30 32C40 22 56 18 68 24C80 30 86 42 84 54L70 58L62 88Z" fill="url(#stBrown)" stroke="#1c0f05" strokeWidth="2" />
      <path d="M32 54C30 38 40 24 56 22C70 22 82 32 84 46L72 50C68 42 60 38 52 40Z" fill="url(#stEagle)" stroke="#475569" strokeWidth="1.8" />
      <path d="M72 44C82 42 94 46 96 56C92 54 86 54 82 58L74 56Z" fill="url(#stGold)" stroke="#78350f" strokeWidth="1.8" />
      <path d="M82 58C86 60 90 62 92 66L84 64Z" fill="#b45309" />
      <circle cx="66" cy="38" r="4" fill="#fde047" stroke="#1c0f05" strokeWidth="1.2" /><circle cx="67" cy="38" r="1.8" fill="#000" />
      <path d="M58 33L72 34" stroke="#1c0f05" strokeWidth="2.4" strokeLinecap="round" />
      {[40, 50, 60].map((y) => <path key={y} d={`M26 ${y + 20}q10 -4 20 2`} stroke="#3b1d06" strokeWidth="1.6" fill="none" opacity=".6" />)}
    </g>
  );
}

function Cougar() {
  return (
    <g>
      <path d="M22 30L28 12L40 26Z M78 30L72 12L60 26Z" fill="url(#stCougar)" stroke="#4a2a10" strokeWidth="1.8" />
      <path d="M26 24L30 16L36 24Z M74 24L70 16L64 24Z" fill="#f9a8d4" opacity=".6" />
      <path d="M18 50C18 30 32 20 50 20C68 20 82 30 82 50C82 72 68 90 50 90C32 90 18 72 18 50Z" fill="url(#stCougar)" stroke="#4a2a10" strokeWidth="2" />
      <path d="M36 62C36 56 42 54 50 54C58 54 64 56 64 62C64 74 58 82 50 82C42 82 36 74 36 62Z" fill="#fdf2e0" />
      <path d="M44 58L56 58L50 66Z" fill="#7c2d12" />
      <path d="M50 66V72M50 72Q44 76 40 72M50 72Q56 76 60 72" stroke="#4a2a10" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <ellipse cx="38" cy="44" rx="6" ry="4.4" fill="#fde68a" stroke="#4a2a10" strokeWidth="1.2" /><ellipse cx="62" cy="44" rx="6" ry="4.4" fill="#fde68a" stroke="#4a2a10" strokeWidth="1.2" />
      <ellipse cx="38" cy="44" rx="1.6" ry="3.8" fill="#000" /><ellipse cx="62" cy="44" rx="1.6" ry="3.8" fill="#000" />
      <path d="M38 50Q36 58 40 62M62 50Q64 58 60 62" stroke="#7c4a1e" strokeWidth="1.4" fill="none" opacity=".6" />
      {[[30, 66], [70, 66]].map(([x, y]) => <path key={x} d={`M${x} ${y}h-12M${x} ${y + 4}h-11`} transform={x > 50 ? `scale(-1 1) translate(-100 0)` : ''} stroke="#fff" strokeWidth=".9" opacity=".7" />)}
    </g>
  );
}

function Wolf() {
  return (
    <g>
      <path d="M24 34L26 8L42 26Z M76 34L74 8L58 26Z" fill="url(#stWolf)" stroke="#1e293b" strokeWidth="1.8" />
      <path d="M18 48C18 30 32 22 50 22C68 22 82 30 82 48C82 58 76 66 70 70L60 90H40L30 70C24 66 18 58 18 48Z" fill="url(#stWolf)" stroke="#1e293b" strokeWidth="2" />
      <path d="M38 60L50 56L62 60L58 84Q50 92 42 84Z" fill="#f1f5f9" stroke="#475569" strokeWidth="1.2" />
      <ellipse cx="50" cy="84" rx="6" ry="4" fill="#0f172a" />
      <path d="M32 44L44 46L38 50Z M68 44L56 46L62 50Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.2" />
      <circle cx="39" cy="47" r="1.6" fill="#000" /><circle cx="61" cy="47" r="1.6" fill="#000" />
      <path d="M28 40L44 43M72 40L56 43" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
    </g>
  );
}

function Elk() {
  return (
    <g>
      <path d="M38 30C30 22 26 14 28 4M30 16L20 12M32 22L22 22M62 30C70 22 74 14 72 4M70 16L80 12M68 22L78 22" stroke="url(#stHorn)" strokeWidth="4.5" fill="none" strokeLinecap="round" />
      <path d="M38 30C30 22 26 14 28 4M62 30C70 22 74 14 72 4" stroke="#57534e" strokeWidth="1" fill="none" />
      <path d="M26 40L14 34L30 46Z M74 40L86 34L70 46Z" fill="url(#stElk)" stroke="#2a1405" strokeWidth="1.5" />
      <path d="M32 40C32 32 40 28 50 28C60 28 68 32 68 40L64 76C62 86 56 92 50 92C44 92 38 86 36 76Z" fill="url(#stElk)" stroke="#2a1405" strokeWidth="2" />
      <path d="M42 76C42 72 46 70 50 70C54 70 58 72 58 76C58 84 54 88 50 88C46 88 42 84 42 76Z" fill="#3b1d06" />
      <circle cx="41" cy="48" r="3.4" fill="#1c0f05" /><circle cx="59" cy="48" r="3.4" fill="#1c0f05" />
      <circle cx="42" cy="47" r="1" fill="#fff" /><circle cx="60" cy="47" r="1" fill="#fff" />
      <path d="M44 56L50 66L56 56" stroke="#fde3c4" strokeWidth="2" fill="none" opacity=".5" />
    </g>
  );
}

const Letter = ({ ch, fill }) => (
  <g>
    <path d="M14 18L86 14L90 82L10 86Z" fill="url(#stWood)" stroke="#2a1405" strokeWidth="2.5" />
    {[30, 46, 62].map((y) => <path key={y} d={`M14 ${y}Q50 ${y + 3} 88 ${y - 2}`} stroke="#3b1d06" strokeWidth="1" opacity=".35" fill="none" />)}
    <circle cx="18" cy="22" r="2" fill="#57534e" /><circle cx="82" cy="20" r="2" fill="#57534e" /><circle cx="15" cy="80" r="2" fill="#57534e" /><circle cx="84" cy="78" r="2" fill="#57534e" />
    {T(ch, 70, ch.length > 1 ? 44 : 54, fill, '#1c0f05', ch.length > 1 ? 56 : undefined)}
  </g>
);

export function GoldCoin({ label = 'FREE' }) {
  return (
    <g>
      <circle cx="50" cy="50" r="44" fill="url(#stGlow)" />
      <circle cx="50" cy="50" r="38" fill="url(#stGold)" stroke="#78350f" strokeWidth="3" />
      <circle cx="50" cy="50" r="30" fill="none" stroke="#fef3c7" strokeWidth="1.6" strokeDasharray="3 3" />
      <g transform="translate(29 20) scale(.42)"><BuffaloHead gold /></g>
      {T(label, 78, 15, '#fff7ed', '#78350f', 44)}
    </g>
  );
}

/** A buffalo cash coin: credit value (x bet), jackpot or multiplier. */
export function CashCoin({ v, bet, money }) {
  const jp = v === 'MINI' || v === 'MINOR' || v === 'MAJOR' || v === 'GRAND', mult = v === 'X2' || v === 'X3';
  const ring = jp ? { MINI: 'url(#stTurq)', MINOR: 'url(#stBlue)', MAJOR: 'url(#stPurple)', GRAND: 'url(#stRed)' }[v] : mult ? 'url(#stRed)' : typeof v === 'number' && v >= 8 ? 'url(#stGold)' : 'url(#stBronze)';
  const label = jp ? v : mult ? v.replace('X', '×') : bet && money ? money(Math.floor(v * bet)) : `${v}x`;
  return (
    <g>
      {(jp || mult || v >= 8) && <circle cx="50" cy="50" r="48" fill="url(#stGlow)" />}
      <circle cx="50" cy="50" r="42" fill={ring} stroke="#3b1d06" strokeWidth="2.5" />
      <circle cx="50" cy="50" r="34" fill="url(#stFur)" stroke="#fde68a" strokeWidth="2" />
      <g transform="translate(30 6) scale(.4)" opacity={jp || mult ? 0.55 : 0.9}><BuffaloHead gold={jp || v >= 8} /></g>
      <rect x="4" y="52" width="92" height="34" rx="10" fill="#1c0f05" stroke={jp || mult ? '#fde68a' : '#d08a4a'} strokeWidth="2.5" opacity=".94" />
      {T(label, 78, label.length > 6 ? 22 : 27, jp || mult ? 'url(#stGold)' : '#fff7ed', '#000', label.length > 4 ? 84 : undefined)}
    </g>
  );
}

function Wild({ m }) {
  return (
    <g>
      <rect x="4" y="4" width="92" height="92" rx="12" fill="url(#stSky)" stroke="url(#stGold)" strokeWidth="3" />
      <circle cx="50" cy="58" r="22" fill="#fde047" opacity=".9" />
      <path d="M4 66L22 48L34 58L52 38L70 56L82 46L96 60V88Q96 96 88 96H12Q4 96 4 88Z" fill="#431407" />
      <path d="M18 74C18 66 28 62 40 62L58 60C68 60 76 64 78 70L82 80H74L70 74L66 82H58L56 76H40L38 82H30L28 76Z" fill="#1c0a02" />
      <path d="M72 62Q80 56 86 60" stroke="#1c0a02" strokeWidth="3" fill="none" />
      <rect x="10" y="10" width="80" height="26" rx="6" fill="#7f1d1d" stroke="url(#stGold)" strokeWidth="2" />
      {T('WILD', 31, 22, 'url(#stGold)', '#3b0a0a', 60)}
      {m > 1 && <g><circle cx="78" cy="78" r="15" fill="url(#stRed)" stroke="#fde68a" strokeWidth="2.5" />{T(`×${m}`, 84, 15, '#fff', '#450a0a')}</g>}
    </g>
  );
}

export const STAMPEDE_ART = {
  BUFFALO: <BuffaloHead />,
  GOLD: <BuffaloHead gold />,
  EAGLE: <Eagle />, COUGAR: <Cougar />, WOLF: <Wolf />, ELK: <Elk />,
  A: <Letter ch="A" fill="url(#stRed)" />, K: <Letter ch="K" fill="url(#stTurq)" />, Q: <Letter ch="Q" fill="url(#stPurple)" />, J: <Letter ch="J" fill="url(#stGreen)" />,
  T: <Letter ch="10" fill="url(#stBlue)" />, N: <Letter ch="9" fill="url(#stGold)" />,
  COIN: <GoldCoin />,
};
export const STAMPEDE_NAMES = { BUFFALO: 'Buffalo', GOLD: 'Golden Buffalo', EAGLE: 'Eagle', COUGAR: 'Cougar', WOLF: 'Wolf', ELK: 'Elk', A: 'A', K: 'K', Q: 'Q', J: 'J', T: '10', N: '9', WILD: 'Buffalo Wild', COIN: 'Gold coin', CASH: 'Buffalo cash' };

export function StampedeSym({ cell, bet, money, className = '' }) {
  if (!cell) return null;
  const s = cell.s;
  const img = s !== 'CASH' && SLOT_IMG.stampede[s];
  if (img) {
    const tier = ['WILD', 'GOLD', 'COIN'].includes(s) ? 'special' : ['A', 'K', 'Q', 'J', 'T', 'N'].includes(s) ? 'low' : ['ELK', 'WOLF'].includes(s) ? 'mid' : 'premium';
    return <PaintedSym src={img} alt={STAMPEDE_NAMES[s] || s} tier={tier} glow={{ WILD: '#fb923c', GOLD: '#fde047', COIN: '#facc15' }[s]} badge={s === 'WILD' && cell.m > 1 ? `×${cell.m}` : undefined} className={className} />;
  }
  const bg = s === 'BUFFALO' ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(254,215,170,0.55),rgba(67,20,7,0.95))] ring-1 ring-amber-700/70'
    : s === 'GOLD' ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(254,240,138,0.85),rgba(146,64,14,0.95))] ring-2 ring-yellow-300'
      : s === 'CASH' ? 'bg-[radial-gradient(circle_at_50%_40%,rgba(251,191,36,0.35),rgba(28,10,2,0.9))] ring-1 ring-amber-400/70'
        : s === 'COIN' ? 'bg-[radial-gradient(circle_at_50%_40%,rgba(253,224,71,0.45),rgba(66,32,6,0.92))] ring-2 ring-yellow-300/80'
          : s === 'WILD' ? '' : ['EAGLE', 'COUGAR', 'WOLF', 'ELK'].includes(s) ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(253,230,138,0.5),rgba(68,30,8,0.92))] ring-1 ring-amber-800/60'
            : 'bg-[radial-gradient(circle_at_50%_35%,rgba(120,72,30,0.35),rgba(28,12,3,0.85))] ring-1 ring-black/30';
  const art = s === 'CASH' ? <CashCoin v={cell.v} bet={bet} money={money} /> : s === 'WILD' ? <Wild m={cell.m} /> : STAMPEDE_ART[s];
  const label = s === 'CASH' ? `Buffalo cash ${cell.v}` : s === 'WILD' && cell.m ? `Buffalo Wild ×${cell.m}` : STAMPEDE_NAMES[s] || s;
  return (
    <div className={`relative h-full w-full rounded-lg ${bg} ${className}`}>
      <svg viewBox="0 0 100 100" className="h-full w-full p-[5%]" role="img" aria-label={label}>{art}</svg>
    </div>
  );
}

export function StampedeLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 320 96" className={className} aria-label="Stampede Link">
      <g transform="translate(4 8) scale(.8)"><BuffaloHead gold /></g>
      <text x="186" y="50" textAnchor="middle" fontFamily="'Rye', 'Lilita One', Georgia, serif" fontWeight="700" fontSize="38" textLength="200" lengthAdjust="spacingAndGlyphs" fill="url(#stGold)" stroke="#2a1405" strokeWidth="5" paintOrder="stroke">STAMPEDE</text>
      <rect x="128" y="58" width="116" height="30" rx="8" fill="#7f1d1d" stroke="url(#stGold)" strokeWidth="3" />
      <text x="186" y="81" textAnchor="middle" fontFamily="'Rye', 'Lilita One', Georgia, serif" fontWeight="700" fontSize="24" textLength="80" lengthAdjust="spacingAndGlyphs" fill="#fff7ed" stroke="#2a1405" strokeWidth="3" paintOrder="stroke">LINK</text>
    </svg>
  );
}

export const STAMPEDE_LOBBY = (
  <g>
    <rect width="100" height="100" fill="url(#stSky)" />
    <circle cx="50" cy="66" r="18" fill="#fde047" opacity=".85" />
    <path d="M0 70L18 52L30 62L48 44L66 60L80 50L100 64V100H0Z" fill="#431407" />
    <g transform="translate(22 30) scale(.56)"><BuffaloHead gold /></g>
    <g transform="translate(4 70) scale(.26)"><CashCoin v="MAJOR" /></g>
    <g transform="translate(70 70) scale(.26)"><CashCoin v={5} /></g>
  </g>
);
