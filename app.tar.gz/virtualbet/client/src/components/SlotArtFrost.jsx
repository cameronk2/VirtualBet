// Frostfang art: low-poly "carved crystal" symbols, the expanded wolf reel,
// logo and lobby emblem. All inline SVG; gradients come from <FrostDefs />.

export function FrostDefs() {
  const lg = (id, stops, x1 = 0, y1 = 0, x2 = 0, y2 = 1) => (
    <linearGradient id={id} x1={x1} y1={y1} x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>
  );
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {lg('frIce', [[0, '#f0f9ff'], [0.45, '#bae6fd'], [1, '#38bdf8']])}
        {lg('frIceDeep', [[0, '#7dd3fc'], [1, '#0c4a6e']])}
        {lg('frSilver', [[0, '#ffffff'], [0.5, '#cbd5e1'], [1, '#64748b']])}
        {lg('frNight', [[0, '#020617'], [0.5, '#1e1b4b'], [1, '#0f172a']])}
        {lg('frSky', [[0, '#0b1026'], [0.55, '#1e3a5f'], [1, '#0f172a']])}
        {lg('frAurora', [[0, 'rgba(45,212,191,0)'], [0.3, 'rgba(45,212,191,0.75)'], [0.6, 'rgba(129,140,248,0.6)'], [1, 'rgba(236,72,153,0)']], 0, 0, 1, 0)}
        {lg('frGold', [[0, '#fff7c2'], [0.5, '#fbbf24'], [1, '#b45309']])}
        {lg('frRuneB', [[0, '#e0f2fe'], [1, '#0369a1']])}
        {lg('frRuneG', [[0, '#dcfce7'], [1, '#047857']])}
        {lg('frRuneP', [[0, '#f3e8ff'], [1, '#6d28d9']])}
        {lg('frRuneR', [[0, '#ffe4e6'], [1, '#be123c']])}
        {lg('frSnow', [[0, '#ffffff'], [1, '#cbd5e1']])}
        {lg('frRock', [[0, '#475569'], [1, '#0f172a']])}
        <radialGradient id="frMoon" cx="40%" cy="38%" r="65%"><stop offset="0" stopColor="#ffffff" /><stop offset=".6" stopColor="#e2e8f0" /><stop offset="1" stopColor="#94a3b8" /></radialGradient>
        <radialGradient id="frMoonGlow" cx="50%" cy="50%" r="50%"><stop offset=".55" stopColor="rgba(186,230,253,0.55)" /><stop offset="1" stopColor="rgba(186,230,253,0)" /></radialGradient>
        <filter id="frGlow" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.4" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        <filter id="frSoft" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="0.6" /></filter>
      </defs>
    </svg>
  );
}

// Low-poly helper: polygons with facet edges
const F = ({ p, c, o }) => <polygon points={p} fill={c} stroke="#0b1220" strokeOpacity=".35" strokeWidth=".6" strokeLinejoin="round" opacity={o} />;
const label = (t, y, size, fill, stroke) => (
  <text x="50" y={y} textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize={size} fill={fill} stroke={stroke} strokeWidth={size / 8} paintOrder="stroke" letterSpacing="1">{t}</text>
);

/** Ice rune stone: hexagonal crystal with a carved, glowing glyph. */
const Rune = ({ grad, glow, glyph }) => (
  <g>
    <polygon points="50,6 88,28 88,72 50,94 12,72 12,28" fill={`url(#${grad})`} />
    <F p="50,6 88,28 50,50" c="#ffffff" o=".28" /><F p="88,28 88,72 50,50" c="#000" o=".12" /><F p="88,72 50,94 50,50" c="#000" o=".25" />
    <F p="50,94 12,72 50,50" c="#000" o=".18" /><F p="12,72 12,28 50,50" c="#ffffff" o=".1" /><F p="12,28 50,6 50,50" c="#ffffff" o=".2" />
    <path d={glyph} stroke="#fff" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round" filter="url(#frGlow)" />
    <path d={glyph} stroke={glow} strokeWidth="2.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </g>
);

const WolfFront = () => (
  <g>
    <F p="22,8 36,34 16,40" c="#94a3b8" /><F p="78,8 64,34 84,40" c="#94a3b8" />
    <F p="24,15 32,32 20,36" c="#334155" /><F p="76,15 68,32 80,36" c="#334155" />
    <F p="36,34 50,26 64,34 50,48" c="#e2e8f0" />
    <F p="16,40 36,34 50,48 30,58" c="#cbd5e1" /><F p="84,40 64,34 50,48 70,58" c="#94a3b8" />
    <F p="16,40 30,58 25,74 10,58" c="#64748b" /><F p="84,40 70,58 75,74 90,58" c="#475569" />
    <F p="30,58 50,48 50,80 38,78" c="#f1f5f9" /><F p="70,58 50,48 50,80 62,78" c="#cbd5e1" />
    <F p="25,74 38,78 50,92" c="#94a3b8" /><F p="75,74 62,78 50,92" c="#64748b" />
    <F p="43,72 57,72 50,81" c="#0f172a" />
    <polygon points="33,49 44,52 36,55" fill="#67e8f9" filter="url(#frGlow)" /><polygon points="67,49 56,52 64,55" fill="#67e8f9" filter="url(#frGlow)" />
  </g>
);

/** Howling wolf in profile (used for the WOLF symbol and the expanded reel). */
const WolfHowl = () => (
  <g>
    <path d="M24 9L38 16 50 19 56 6 61 23 71 43 77 71 73 97 41 97 42 89 39 66 33 41z" fill="none" stroke="#e0f2fe" strokeWidth="3.5" strokeLinejoin="round" opacity=".55" filter="url(#frGlow)" />
    <F p="24,9 38,16 33,25" c="#f1f5f9" /><F p="38,16 50,19 44,30 33,25" c="#cbd5e1" />
    <F p="50,19 56,6 61,23" c="#64748b" /><F p="50,19 61,23 58,36 44,30" c="#94a3b8" />
    <F p="33,25 44,30 39,41" c="#e2e8f0" /><F p="44,30 58,36 52,50 39,41" c="#94a3b8" />
    <F p="58,36 71,43 65,62 52,50" c="#475569" /><F p="39,41 52,50 45,66" c="#cbd5e1" />
    <F p="52,50 65,62 58,80 45,66" c="#64748b" /><F p="65,62 77,71 73,97 58,80" c="#334155" />
    <F p="45,66 58,80 52,97 41,92" c="#94a3b8" /><F p="58,80 73,97 52,97" c="#475569" />
    <polygon points="44,24 49,25 45,28" fill="#67e8f9" filter="url(#frGlow)" />
    <F p="24,9 30,12 27,14" c="#0f172a" />
  </g>
);

export const FROST_ART = {
  RUNE_B: <Rune grad="frRuneB" glow="#38bdf8" glyph="M50 26v48M50 40l14-10M50 54l14-10" />,
  RUNE_G: <Rune grad="frRuneG" glow="#34d399" glyph="M36 28v44M36 50l28-22M36 50l28 22" />,
  RUNE_P: <Rune grad="frRuneP" glow="#a78bfa" glyph="M50 26v48M36 38l28 24M64 38L36 62" />,
  RUNE_R: <Rune grad="frRuneR" glow="#fb7185" glyph="M36 28l14 22-14 22M64 28L50 50l14 22" />,
  OWL: (
    <g>
      <F p="24,14 38,26 30,34" c="#a16207" /><F p="76,14 62,26 70,34" c="#a16207" />
      <F p="30,34 38,26 50,30 62,26 70,34 50,44" c="#ca8a04" />
      <F p="18,50 30,34 50,44 34,72" c="#92400e" /><F p="82,50 70,34 50,44 66,72" c="#78350f" />
      <F p="34,72 50,44 66,72 50,92" c="#fef3c7" /><F p="34,72 50,92 28,84" c="#d6d3d1" /><F p="66,72 72,84 50,92" c="#a8a29e" />
      <circle cx="38" cy="46" r="9" fill="#fef3c7" /><circle cx="62" cy="46" r="9" fill="#fef3c7" />
      <circle cx="38" cy="46" r="5" fill="#f59e0b" /><circle cx="62" cy="46" r="5" fill="#f59e0b" /><circle cx="38" cy="46" r="2.5" fill="#000" /><circle cx="62" cy="46" r="2.5" fill="#000" />
      <F p="46,52 54,52 50,62" c="#334155" />
    </g>
  ),
  ELK: (
    <g>
      <path d="M38 34C30 24 22 22 14 12M24 22l-8 4M30 28l-12 10M62 34c8-10 16-12 24-22M76 22l8 4M70 28l12 10" stroke="#e7e5e4" strokeWidth="5" strokeLinecap="round" fill="none" />
      <F p="38,34 50,30 62,34 56,48 44,48" c="#a16207" />
      <F p="28,40 38,34 44,48 36,54" c="#78350f" /><F p="72,40 62,34 56,48 64,54" c="#57534e" />
      <F p="44,48 56,48 58,74 42,74" c="#92400e" /><F p="36,54 44,48 42,74" c="#713f12" /><F p="64,54 56,48 58,74" c="#57534e" />
      <F p="42,74 58,74 54,90 46,90" c="#44403c" /><F p="46,84 54,84 50,90" c="#0c0a09" />
      <polygon points="41,52 45,54 42,56" fill="#0c0a09" /><polygon points="59,52 55,54 58,56" fill="#0c0a09" />
    </g>
  ),
  BEAR: (
    <g>
      <circle cx="26" cy="24" r="10" fill="#57534e" /><circle cx="74" cy="24" r="10" fill="#44403c" />
      <F p="26,30 50,18 74,30 62,46 38,46" c="#78716c" />
      <F p="14,46 26,30 38,46 30,70" c="#57534e" /><F p="86,46 74,30 62,46 70,70" c="#44403c" />
      <F p="38,46 62,46 70,70 50,90 30,70" c="#78716c" />
      <F p="38,62 62,62 58,80 42,80" c="#d6d3d1" /><F p="44,62 56,62 50,70" c="#0c0a09" />
      <polygon points="38,48 44,50 39,52" fill="#0c0a09" /><polygon points="62,48 56,50 61,52" fill="#0c0a09" />
    </g>
  ),
  EAGLE: (
    <g>
      <F p="20,40 42,16 70,20 64,40 40,52" c="#f8fafc" /><F p="42,16 70,20 56,28" c="#ffffff" />
      <F p="20,40 40,52 28,70 10,56" c="#e2e8f0" /><F p="40,52 64,40 66,64 46,72" c="#cbd5e1" />
      <F p="28,70 46,72 54,92 30,90" c="#78350f" /><F p="46,72 66,64 74,90 54,92" c="#57534e" />
      <F p="64,40 88,44 76,54 66,52" c="#fbbf24" /><F p="76,54 88,44 84,58" c="#d97706" />
      <polygon points="54,32 60,30 58,36" fill="#0f172a" /><path d="M50 30l12-4" stroke="#475569" strokeWidth="2" />
    </g>
  ),
  WOLF: <g><circle cx="50" cy="44" r="46" fill="url(#frMoonGlow)" /><circle cx="50" cy="40" r="34" fill="url(#frMoon)" opacity=".55" /><g transform="translate(2 4) scale(.96)"><WolfFront /></g></g>,
  WILD: (
    <g>
      <polygon points="50,2 94,26 94,74 50,98 6,74 6,26" fill="url(#frIceDeep)" stroke="url(#frIce)" strokeWidth="3" />
      <g transform="translate(14 4) scale(.72)"><WolfFront /></g>
      <rect x="18" y="76" width="64" height="18" rx="5" fill="#0c4a6e" stroke="#bae6fd" strokeWidth="1.5" />
      {label('WILD', 91, 17, '#f0f9ff', '#075985')}
    </g>
  ),
  MOON: (
    <g>
      <circle cx="50" cy="44" r="40" fill="url(#frMoonGlow)" />
      <circle cx="50" cy="44" r="28" fill="url(#frMoon)" />
      <circle cx="40" cy="36" r="5" fill="#cbd5e1" /><circle cx="58" cy="52" r="7" fill="#cbd5e1" /><circle cx="60" cy="32" r="3" fill="#cbd5e1" />
      <path d="M14 70c20-10 52-10 72 0" stroke="url(#frAurora)" strokeWidth="6" fill="none" filter="url(#frGlow)" />
      {label('FREE', 94, 18, '#e0f2fe', '#1e3a8a')}
    </g>
  ),
};
export const FROST_NAMES = { RUNE_B: 'Blue rune', RUNE_G: 'Green rune', RUNE_P: 'Violet rune', RUNE_R: 'Red rune', OWL: 'Owl', ELK: 'Elk', BEAR: 'Bear', EAGLE: 'Eagle', WOLF: 'Wolf', WILD: 'Frostfang Wild', MOON: 'Full Moon' };
export const FROST_TILE = (s) => `rounded-md ${s === 'WILD' || s === 'MOON' ? 'bg-[radial-gradient(circle_at_50%_30%,rgba(56,189,248,0.35),rgba(15,23,42,0.92))] ring-1 ring-sky-300/70' : ['WOLF', 'EAGLE', 'BEAR'].includes(s) ? 'bg-[radial-gradient(circle_at_50%_30%,rgba(148,163,184,0.25),rgba(15,23,42,0.92))] ring-1 ring-slate-300/30' : 'bg-[radial-gradient(circle_at_50%_30%,rgba(30,58,95,0.6),rgba(2,6,23,0.92))] ring-1 ring-sky-900/60'}`;

/** The expanded Frostfang Wild: a full-height night scene with a howling wolf. */
export function WolfReel({ className = '' }) {
  return (
    <svg viewBox="0 0 60 240" preserveAspectRatio="xMidYMid slice" className={className} aria-hidden="true">
      <rect width="60" height="240" fill="url(#frSky)" />
      <path d="M-10 74C10 52 30 96 70 62" stroke="url(#frAurora)" strokeWidth="18" fill="none" opacity=".85" filter="url(#frGlow)" className="fr-aurora-svg" />
      <path d="M-10 110C20 88 40 120 70 98" stroke="url(#frAurora)" strokeWidth="10" fill="none" opacity=".55" filter="url(#frGlow)" />
      {[[8, 16], [52, 12], [10, 130], [50, 122], [5, 90], [55, 84], [30, 8]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r=".9" fill="#fff" className="fr-twinkle" style={{ animationDelay: `${i * 0.4}s` }} />)}
      <circle cx="34" cy="62" r="34" fill="url(#frMoonGlow)" />
      <circle cx="34" cy="62" r="21" fill="url(#frMoon)" />
      <circle cx="28" cy="56" r="3.5" fill="#cbd5e1" /><circle cx="40" cy="68" r="4.5" fill="#cbd5e1" /><circle cx="41" cy="53" r="2" fill="#cbd5e1" />
      <g transform="translate(-6 74) scale(.86)"><WolfHowl /></g>
      <polygon points="0,240 0,178 12,166 24,172 36,158 60,170 60,240" fill="url(#frRock)" />
      <polygon points="12,166 24,172 18,180 4,176" fill="url(#frSnow)" opacity=".9" /><polygon points="36,158 60,170 46,176 30,168" fill="url(#frSnow)" opacity=".9" />
      <rect x="9" y="188" width="42" height="15" rx="4" fill="#0c4a6e" stroke="#e0f2fe" strokeWidth="1.2" />
      <text x="30" y="200" textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize="12" textLength="34" lengthAdjust="spacingAndGlyphs" fill="#f0f9ff">WILD</text>
      <rect x="1" y="1" width="58" height="238" rx="3" fill="none" stroke="url(#frIce)" strokeWidth="2" />
    </svg>
  );
}

export function FrostLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 300 90" className={className} aria-label="Frostfang – Howl of the Northern Lights">
      <path d="M20 66c40-18 80 6 130-6s90-20 130-2" stroke="url(#frAurora)" strokeWidth="8" fill="none" opacity=".7" filter="url(#frGlow)" />
      <text x="150" y="56" textAnchor="middle" fontFamily="'Lilita One'" fontSize="50" textLength="260" lengthAdjust="spacingAndGlyphs" fill="url(#frIce)" stroke="#0c4a6e" strokeWidth="3" paintOrder="stroke">FROSTFANG</text>
      <path d="M58 14l6 10 6-10M232 14l6 10 6-10" stroke="#e0f2fe" strokeWidth="2" fill="none" />
      <text x="150" y="84" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="13" textLength="240" lengthAdjust="spacingAndGlyphs" fill="#bae6fd">HOWL OF THE NORTHERN LIGHTS</text>
    </svg>
  );
}

export const FROST_LOBBY = (
  <g>
    <circle cx="66" cy="28" r="18" fill="url(#frMoon)" /><circle cx="66" cy="28" r="26" fill="url(#frMoonGlow)" />
    <path d="M0 40C25 26 55 52 100 32" stroke="url(#frAurora)" strokeWidth="9" fill="none" filter="url(#frGlow)" />
    <polygon points="0,100 0,78 18,62 34,72 52,54 72,70 100,58 100,100" fill="url(#frRock)" />
    <polygon points="18,62 34,72 26,76 12,70" fill="#e2e8f0" /><polygon points="52,54 72,70 60,72 44,64" fill="#e2e8f0" />
    <g transform="translate(22 22) scale(.52)"><WolfHowl /></g>
  </g>
);
