// Tiered, themed win celebration shared by every game.
//
//   BIG WIN (10x+)  →  MEGA WIN (25x+)  →  SUPER WIN (50x+)
//
// The counter climbs through the tiers: each time it passes a threshold the
// title restamps, the backdrop intensifies and the music steps up. Every
// game has its own look (title gradient, glow, particle style, ray colours)
// and its own fanfare voiced by the game's sound theme.
// First tap skips to the final amount; the next tap closes.
import { useEffect, useMemo, useRef, useState } from 'react';
import { money } from '../lib/format.js';
import { winFanfare } from '../lib/sound.js';

const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

export const WIN_TIERS = [{ x: 10, label: 'BIG WIN' }, { x: 25, label: 'MEGA WIN' }, { x: 50, label: 'SUPER WIN' }];
const tierAt = (x) => (x >= 50 ? 3 : x >= 25 ? 2 : 1);

// title gradient, glow colour, particle style, ray colours (a, b)
const THEME = {
  atlantis: { grad: 'linear-gradient(180deg,#ecfeff,#22d3ee 50%,#0e7490)', glow: '#22d3ee', p: 'bubble', ray: ['rgba(34,211,238,.35)', 'rgba(14,116,144,.1)'] },
  neon: { grad: 'linear-gradient(180deg,#fdf4ff,#f0abfc 40%,#22d3ee)', glow: '#f0abfc', p: 'spark', ray: ['rgba(240,171,252,.35)', 'rgba(34,211,238,.15)'] },
  dragon: { grad: 'linear-gradient(180deg,#fff7ed,#fb923c 45%,#b91c1c)', glow: '#f97316', p: 'ember', ray: ['rgba(249,115,22,.35)', 'rgba(185,28,28,.15)'] },
  cosmic: { grad: 'linear-gradient(180deg,#f5f3ff,#a78bfa 45%,#4c1d95)', glow: '#a78bfa', p: 'star', ray: ['rgba(167,139,250,.35)', 'rgba(76,29,149,.15)'] },
  pharaoh: { grad: 'linear-gradient(180deg,#fffbeb,#fbbf24 45%,#92400e)', glow: '#fbbf24', p: 'sand', ray: ['rgba(251,191,36,.35)', 'rgba(146,64,14,.15)'] },
  frost: { grad: 'linear-gradient(180deg,#ffffff,#bae6fd 45%,#38bdf8)', glow: '#7dd3fc', p: 'snow', ray: ['rgba(186,230,253,.4)', 'rgba(56,189,248,.12)'] },
  moonridge: { grad: 'linear-gradient(180deg,#fffbeb,#fde68a 40%,#d97706)', glow: '#fbbf24', p: 'firefly', ray: ['rgba(253,230,138,.35)', 'rgba(124,45,74,.18)'] },
  mummy: { grad: 'linear-gradient(180deg,#fff8d6,#fcd34d 40%,#0d9488)', glow: '#fcd34d', p: 'gem', ray: ['rgba(252,211,77,.35)', 'rgba(45,212,191,.18)'] },
  lakeside: { grad: 'linear-gradient(180deg,#f0fdf4,#4ade80 45%,#0e7490)', glow: '#4ade80', p: 'bubble', ray: ['rgba(74,222,128,.3)', 'rgba(14,116,144,.15)'] },
  nebula: { grad: 'linear-gradient(180deg,#fdf2f8,#f472b6 45%,#6d28d9)', glow: '#f472b6', p: 'star', ray: ['rgba(244,114,182,.35)', 'rgba(109,40,217,.15)'] },
  vault: { grad: 'linear-gradient(180deg,#fefce8,#facc15 45%,#a16207)', glow: '#facc15', p: 'coin', ray: ['rgba(250,204,21,.35)', 'rgba(161,98,7,.15)'] },
  starlight: { grad: 'linear-gradient(180deg,#ffffff,#c7d2fe 45%,#6366f1)', glow: '#a5b4fc', p: 'star', ray: ['rgba(199,210,254,.35)', 'rgba(99,102,241,.15)'] },
  fruit: { grad: 'linear-gradient(180deg,#fff1f2,#fb7185 45%,#be123c)', glow: '#fb7185', p: 'coin', ray: ['rgba(251,113,133,.35)', 'rgba(250,204,21,.15)'] },
  roulette: { grad: 'linear-gradient(180deg,#f0fdf4,#facc15 45%,#15803d)', glow: '#facc15', p: 'coin', ray: ['rgba(250,204,21,.3)', 'rgba(21,128,61,.18)'] },
  crash: { grad: 'linear-gradient(180deg,#fff7ed,#fdba74 40%,#ea580c)', glow: '#fb923c', p: 'ember', ray: ['rgba(251,146,60,.35)', 'rgba(52,211,153,.12)'] },
  plinko: { grad: 'linear-gradient(180deg,#fdf4ff,#e879f9 45%,#86198f)', glow: '#e879f9', p: 'star', ray: ['rgba(232,121,249,.35)', 'rgba(134,25,143,.15)'] },
  scratch: { grad: 'linear-gradient(180deg,#f7fee7,#a3e635 45%,#3f6212)', glow: '#a3e635', p: 'coin', ray: ['rgba(163,230,53,.3)', 'rgba(63,98,18,.15)'] },
  polarcatch: { grad: 'linear-gradient(180deg,#ffffff,#7dd3fc 45%,#0369a1)', glow: '#7dd3fc', p: 'snow', ray: ['rgba(125,211,252,.35)', 'rgba(52,211,153,.15)'] },
  brick: { grad: 'linear-gradient(180deg,#fffbeb,#fde047 40%,#dc2626)', glow: '#facc15', p: 'coin', ray: ['rgba(250,204,21,.35)', 'rgba(220,38,38,.15)'] },
  keno: { grad: 'linear-gradient(180deg,#fffbeb,#fde047 40%,#a855f7)', glow: '#c084fc', p: 'coin', ray: ['rgba(192,132,252,.35)', 'rgba(253,224,71,.15)'] },
  mines: { grad: 'linear-gradient(180deg,#f0f9ff,#a5b4fc 40%,#7c3aed)', glow: '#818cf8', p: 'coin', ray: ['rgba(129,140,248,.35)', 'rgba(253,224,71,.15)'] },
  chicken: { grad: 'linear-gradient(180deg,#ffffff,#fde047 45%,#f97316)', glow: '#fde047', p: 'coin', ray: ['rgba(253,224,71,.35)', 'rgba(74,222,128,.15)'] },
  genie: { grad: 'linear-gradient(180deg,#fffbeb,#fde047 35%,#d946ef 75%,#5b21b6)', glow: '#facc15', p: 'star', ray: ['rgba(250,204,21,.32)', 'rgba(217,70,239,.18)'] },
  stampede: { grad: 'linear-gradient(180deg,#fff7ed,#fbbf24 40%,#9a3412)', glow: '#f59e0b', p: 'coin', ray: ['rgba(251,191,36,.35)', 'rgba(154,52,18,.18)'] },
  default: { grad: 'linear-gradient(180deg,#fff7c2,#facc15 50%,#c2410c)', glow: '#facc15', p: 'coin', ray: ['rgba(250,204,21,.32)', 'rgba(194,65,12,.12)'] },
};
export const winTheme = (game) => THEME[game] || THEME.default;

function Rain({ shape, n }) {
  const parts = useMemo(() => Array.from({ length: reduceMotion ? 0 : n }, (_, i) => ({
    x: (i * 37 + 11) % 100, d: `${-((i * 0.29) % 2.4)}s`, t: `${1.8 + (i % 5) * 0.35}s`, s: 0.7 + ((i * 13) % 7) / 10, r: `${(i * 47) % 360}deg`,
  })), [n]);
  return <div className="pointer-events-none absolute inset-0 overflow-hidden">{parts.map((p, i) => <span key={i} className={`wc-p wc-${shape}`} style={{ left: `${p.x}%`, animationDelay: p.d, animationDuration: p.t, '--s': p.s, '--r': p.r }} />)}</div>;
}

function Burst({ colour, n = 24, spread = 160 }) {
  const parts = useMemo(() => Array.from({ length: reduceMotion ? 0 : n }, (_, i) => {
    const a = (i / n) * Math.PI * 2 + Math.random() * 0.4, d = spread * (0.5 + Math.random() * 0.6);
    return { dx: `${Math.cos(a) * d}px`, dy: `${Math.sin(a) * d}px`, t: `${0.7 + Math.random() * 0.5}s` };
  }), [n, spread]);
  return <div className="pointer-events-none absolute left-1/2 top-1/2">{parts.map((p, i) => <span key={i} className="p3-particle" style={{ '--dx': p.dx, '--dy': p.dy, '--c': i % 3 ? colour : '#fff', '--t': p.t }} />)}</div>;
}

export default function WinCelebration({ game, amount, bet, title, cinematic, onDone, subtitle, labels, className = 'absolute inset-0 rounded-2xl' }) {
  const th = winTheme(game);
  const x = bet ? amount / bet : 0;
  const finalTier = tierAt(x);
  const [shown, setShown] = useState(reduceMotion ? amount : 0);
  const [tier, setTier] = useState(reduceMotion ? finalTier : 1);
  const [done, setDone] = useState(reduceMotion);
  const fan = useRef(null);
  const raf = useRef(0);

  useEffect(() => {
    fan.current = winFanfare(game, 1);
    if (reduceMotion) { fan.current.finish(); return () => fan.current?.stop(); }
    const dur = [0, 2300, 3700, 5200][finalTier], t0 = performance.now();
    let lastTier = 1;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur);
      const v = Math.floor(amount * (1 - (1 - k) ** 2.4));
      setShown(v);
      const nt = title ? finalTier : tierAt(bet ? v / bet : 0);
      if (nt > lastTier) { lastTier = nt; setTier(nt); fan.current?.up(); }
      if (k < 1) raf.current = requestAnimationFrame(step);
      else { setShown(amount); setTier(finalTier); setDone(true); fan.current?.finish(); }
    };
    raf.current = requestAnimationFrame(step);
    return () => { cancelAnimationFrame(raf.current); fan.current?.stop(); };
  }, [amount]); // eslint-disable-line react-hooks/exhaustive-deps

  // auto-close a while after the count finishes
  useEffect(() => { if (!done) return undefined; const id = setTimeout(onDone, 2600 + finalTier * 400); return () => clearTimeout(id); }, [done]); // eslint-disable-line react-hooks/exhaustive-deps

  const tap = () => {
    if (!done) { cancelAnimationFrame(raf.current); setShown(amount); setTier(finalTier); setDone(true); fan.current?.finish(); return; }
    onDone();
  };
  const label = title || labels?.[tier - 1] || WIN_TIERS[tier - 1].label;
  return (
    <button type="button" onClick={tap} className={`animate-fade-in z-40 flex flex-col items-center justify-center overflow-hidden bg-black/75 pb-16 text-center backdrop-blur-[2px] md:pb-0 ${className}`} aria-live="polite" aria-label={`${label} ${money(amount)}. Tap to ${done ? 'continue' : 'skip'}`}>
      {/* backdrop layers grow with the tier */}
      <div className="wc-vignette pointer-events-none absolute inset-0" style={{ '--g': th.glow }} />
      {tier >= 2 && <div className="wc-rays pointer-events-none absolute left-1/2 top-1/2 h-[220%] w-[220%]" style={{ background: `repeating-conic-gradient(${th.ray[0]} 0deg 10deg, ${th.ray[1]} 10deg 20deg)` }} />}
      {tier >= 3 && <div className="wc-rays wc-rays-rev pointer-events-none absolute left-1/2 top-1/2 h-[220%] w-[220%] opacity-60" style={{ background: `repeating-conic-gradient(transparent 0deg 14deg, ${th.ray[0]} 14deg 18deg)` }} />}
      {tier >= 3 && <div key={`f${tier}`} className="wc-flash pointer-events-none absolute inset-0" />}
      {cinematic}
      {/* a soft dark plate keeps the title and amount readable over busy art */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-56 w-[85%] max-w-xl -translate-x-1/2 -translate-y-1/2 rounded-full bg-black/55 blur-2xl" />
      <Rain shape={th.p} n={[0, 14, 26, 40][tier]} />
      <Burst key={`b${tier}`} colour={th.glow} n={[0, 22, 32, 46][tier]} spread={[0, 140, 190, 240][tier]} />
      {tier >= 2 && <div key={`r${tier}`} className="wc-ring pointer-events-none absolute left-1/2 top-1/2 h-40 w-40 rounded-full border-4" style={{ borderColor: th.glow }} />}
      <div key={label} className={`p3-stamp relative font-display tracking-wide text-transparent ${tier >= 3 ? 'wc-pulse text-6xl sm:text-7xl' : tier >= 2 ? 'text-6xl sm:text-[4.25rem]' : 'text-5xl sm:text-6xl'}`}
        style={{ backgroundImage: th.grad, WebkitBackgroundClip: 'text', backgroundClip: 'text', filter: `drop-shadow(0 0 ${8 + tier * 8}px ${th.glow})` }}>{label}</div>
      {subtitle && <div className="relative mt-1 text-sm font-semibold text-white/85">{subtitle}</div>}
      <div className={`relative mt-2 font-cond font-extrabold tabular-nums text-white ${tier >= 3 ? 'text-5xl sm:text-6xl' : 'text-4xl sm:text-5xl'}`} style={{ textShadow: `0 0 18px ${th.glow}` }}>{money(shown)}</div>
      {bet > 0 && <div className="relative mt-1 text-xs font-bold text-white/70">{x.toFixed(x >= 100 ? 0 : 1)}x your stake</div>}
      <div className="relative mt-4 text-[11px] uppercase tracking-widest text-white/60">{done ? 'Tap to continue' : 'Tap to skip'}</div>
    </button>
  );
}
