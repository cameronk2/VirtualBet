import { useEffect, useRef, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { odds as fmtOdds } from '../lib/format.js';
import { Icon } from './ui.jsx';

export default function OddsButton({ match, market, sel, label, compact = false, className = '' }) {
  const { inSlip, toggleSelection } = useApp();
  const prev = useRef(sel?.odds);
  const [flash, setFlash] = useState(null);

  useEffect(() => {
    if (sel?.odds && prev.current && sel.odds !== prev.current) {
      setFlash(sel.odds > prev.current ? 'up' : 'down');
      const t = setTimeout(() => setFlash(null), 1600);
      prev.current = sel.odds;
      return () => clearTimeout(t);
    }
    prev.current = sel?.odds;
    return undefined;
  }, [sel?.odds]);

  if (!market || !sel) {
    return <div className={`flex h-11 items-center justify-center rounded-lg bg-navy-800/60 text-xs text-slate-600 ${className}`}>–</div>;
  }
  const disabled = market.suspended || !sel.odds;
  const selected = inSlip(match.id, market.key, sel.key);

  const onClick = () => {
    if (disabled) return;
    toggleSelection({
      matchId: match.id,
      matchLabel: `${match.home.name} v ${match.away.name}`,
      league: match.league.name,
      simulated: match.simulated,
      market: market.key,
      marketName: market.name,
      selection: sel.key,
      selectionLabel: sel.label,
      odds: sel.odds,
      live: match.live,
    });
  };

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={selected}
      title={disabled ? 'Suspended' : `${sel.label} @ ${fmtOdds(sel.odds)}`}
      className={`group relative flex w-full min-w-0 items-center rounded-lg transition-all duration-150 active:scale-[.96] ${compact ? 'h-11 flex-col justify-center px-1' : 'h-11 justify-between gap-2 px-3'}
        ${selected ? 'bg-brand-500 text-navy-950 shadow-[0_0_0_1px_rgba(25,195,125,0.8)]' : 'bg-navy-700 text-slate-100 hover:bg-navy-600'}
        ${disabled ? 'opacity-60' : ''}
        ${flash === 'up' && !selected ? 'animate-flash-up' : ''} ${flash === 'down' && !selected ? 'animate-flash-down' : ''} ${className}`}
    >
      {label !== false && (
        <span className={`truncate ${compact ? 'text-[10px] leading-tight' : 'text-xs'} ${selected ? 'text-navy-900' : 'text-slate-400 group-hover:text-slate-300'}`}>
          {label ?? sel.label}
        </span>
      )}
      <span className="flex items-center gap-0.5 text-sm font-bold tabular-nums">
        {disabled ? <Icon.lock className="h-3.5 w-3.5 text-slate-400" /> : fmtOdds(sel.odds)}
        {flash === 'up' && <Icon.up className={`h-3 w-3 ${selected ? 'text-navy-900' : 'text-brand-400'}`} />}
        {flash === 'down' && <Icon.down className={`h-3 w-3 ${selected ? 'text-navy-900' : 'text-red-400'}`} />}
      </span>
    </button>
  );
}
