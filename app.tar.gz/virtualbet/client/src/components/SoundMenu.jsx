// One sound menu for every game: all sound, music, effects, and a volume
// slider for each. Music can be muted on its own, separately from effects.
import { useEffect, useRef, useState } from 'react';
import { getSoundTheme, getVolume, isFxOn, isMusicOn, isMuted, onSoundChange, setFxOn, setMusicOn, setMuted, setVolume, startAmbience } from '../lib/sound.js';

function Row({ label, on, onToggle, which }) {
  return (
    <div className="rounded-lg px-3 py-2 hover:bg-navy-700/60">
      <button type="button" onClick={() => onToggle(!on)} className="flex w-full items-center justify-between gap-4 text-sm text-slate-200" aria-pressed={on}>
        {label}<span className={`relative h-5 w-9 rounded-full transition-colors ${on ? 'bg-brand-500' : 'bg-navy-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
      </button>
      {which && (
        <input type="range" min="0" max="100" step="5" value={Math.round(getVolume(which) * 100)} disabled={!on}
          onChange={(e) => setVolume(which, Number(e.target.value) / 100)} aria-label={`${label} volume`}
          className="vb-range mt-1.5 w-full disabled:opacity-40" />
      )}
    </div>
  );
}

export default function SoundMenu({ game }) {
  const [, force] = useState(0);
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => onSoundChange(() => force((n) => n + 1)), []);
  useEffect(() => {
    if (!open) return undefined;
    const close = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('pointerdown', close);
    return () => document.removeEventListener('pointerdown', close);
  }, [open]);
  const master = !isMuted();
  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => setOpen((o) => !o)} className="flex h-8 items-center gap-1 rounded-md bg-navy-700 px-2 text-xs font-semibold text-slate-200 hover:bg-navy-600" aria-expanded={open} aria-label="Sound settings">
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4z" />{master ? <path d="M16 8.5a5 5 0 010 7" stroke="currentColor" strokeWidth="1.8" fill="none" /> : <path d="M16 9l5 6m0-6l-5 6" stroke="currentColor" strokeWidth="2" />}</svg>
        {master ? 'Sound' : 'Muted'}
      </button>
      {open && (
        <div className="absolute right-0 top-10 z-50 w-64 rounded-xl border border-navy-600 bg-navy-850 p-1.5 shadow-2xl">
          <Row label="All sound" on={master} onToggle={(v) => setMuted(!v)} which="master" />
          <Row label="Music" on={isMusicOn()} onToggle={(v) => { setMusicOn(v); if (v && master && (game || getSoundTheme())) startAmbience(game || getSoundTheme()); }} which="music" />
          <Row label="Sound effects" on={isFxOn()} onToggle={setFxOn} which="fx" />
          <p className="px-3 pb-1.5 pt-1 text-[10px] text-slate-500">Each game has its own soundtrack. Sound starts after your first tap.</p>
        </div>
      )}
    </div>
  );
}
