import { lockScroll } from '../lib/scrollLock.js';
import { createPortal } from 'react-dom';
import { useEffect } from 'react';

export const Icon = {
  lock: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path fillRule="evenodd" d="M10 2a4 4 0 00-4 4v2H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-1V6a4 4 0 00-4-4zm2 6V6a2 2 0 10-4 0v2h4z" clipRule="evenodd" /></svg>),
  x: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" /></svg>),
  chevron: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path fillRule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.17 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clipRule="evenodd" /></svg>),
  up: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path d="M10 5l5 7H5z" /></svg>),
  down: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path d="M10 15l-5-7h10z" /></svg>),
  ball: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}><circle cx="12" cy="12" r="9" /><path d="M12 7l4 3-1.5 4.5h-5L8 10z" fill="currentColor" /><path d="M12 3v4M16 10l4.5-1.5M14.5 14.5l2.5 4M9.5 14.5L7 18.5M8 10L3.5 8.5" /></svg>),
  user: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path d="M10 10a4 4 0 100-8 4 4 0 000 8zM3 18a7 7 0 0114 0H3z" /></svg>),
  clock: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.75-12.5a.75.75 0 00-1.5 0V10c0 .2.08.39.22.53l2.5 2.5a.75.75 0 101.06-1.06l-2.28-2.28V5.5z" clipRule="evenodd" /></svg>),
  gift: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path d="M3 9h14v2H3zM4 11h5v7H5a1 1 0 01-1-1v-6zM11 11h5v6a1 1 0 01-1 1h-4v-7zM9 6h2v3H9zM10 6c-1-3-5-3-5-1s5 1 5 1zm0 0c1-3 5-3 5-1s-5 1-5 1z" /></svg>),
  card: (p) => (<svg viewBox="0 0 12 16" {...p}><rect x="1" y="1" width="10" height="14" rx="1.5" fill="currentColor" /></svg>),
  check: (p) => (<svg viewBox="0 0 20 20" fill="currentColor" {...p}><path fillRule="evenodd" d="M16.7 5.3a1 1 0 010 1.4l-8 8a1 1 0 01-1.4 0l-4-4a1 1 0 111.4-1.4L8 12.58l7.3-7.3a1 1 0 011.4 0z" clipRule="evenodd" /></svg>),
};

export function Spinner({ className = '' }) {
  return <div className={`h-5 w-5 animate-spin rounded-full border-2 border-navy-500 border-t-brand-500 ${className}`} role="status" aria-label="Loading" />;
}

export function Loading({ label = 'Loading…' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-12 text-sm text-slate-400">
      <Spinner /> {label}
    </div>
  );
}

/** Placeholder rows shown while a list loads (keeps the layout from jumping). */
export function Skeleton({ rows = 3, className = '' }) {
  return (
    <div className={`card divide-y divide-navy-700 overflow-hidden ${className}`} aria-busy="true" aria-label="Loading">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="flex items-center gap-3 px-3 py-3">
          <div className="vb-skel h-9 w-9 shrink-0 rounded-full" />
          <div className="flex-1 space-y-1.5"><div className="vb-skel h-3 w-2/3 rounded" /><div className="vb-skel h-2.5 w-1/3 rounded" /></div>
          <div className="vb-skel h-9 w-16 rounded-lg" />
        </div>
      ))}
    </div>
  );
}

export function Empty({ title, children, icon }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-12 text-center">
      <div className="mb-1 text-slate-600">{icon || <Icon.ball className="h-10 w-10" />}</div>
      <p className="font-semibold text-slate-200">{title}</p>
      {children && <div className="max-w-sm text-sm text-slate-400">{children}</div>}
    </div>
  );
}

export function ErrorBox({ error, onRetry }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-200" role="alert">
      <span>{error?.status === 0 ? 'No connection - check your signal and try again.' : error?.message || 'Something went wrong.'}</span>
      {onRetry && <button className="h-9 shrink-0 rounded-lg bg-red-500/20 px-3 font-semibold text-white active:scale-95" onClick={onRetry}>Retry</button>}
    </div>
  );
}

const STATUS_STYLES = {
  WON: 'bg-brand-500/15 text-brand-400 border-brand-500/40',
  LOST: 'bg-red-500/15 text-red-400 border-red-500/40',
  OPEN: 'bg-slate-500/15 text-slate-300 border-slate-500/40',
  VOID: 'bg-gold-500/15 text-gold-400 border-gold-500/40',
  CASHED_OUT: 'bg-sky-500/15 text-sky-300 border-sky-500/40',
};
const STATUS_TEXT = { WON: 'Won', LOST: 'Lost', OPEN: 'Pending', VOID: 'Void', CASHED_OUT: 'Cashed out' };

export function StatusBadge({ status }) {
  return (
    <span className={`inline-flex items-center rounded border px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide ${STATUS_STYLES[status] || STATUS_STYLES.OPEN}`}>
      {STATUS_TEXT[status] || status}
    </span>
  );
}

export function SimBadge({ className = '' }) {
  return (
    <span title="This match, its score and its events are simulated. Not a real fixture." className={`inline-flex items-center rounded bg-gold-500/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-gold-400 ${className}`}>
      Simulated
    </span>
  );
}

export function LiveBadge({ className = '' }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded bg-red-600 px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white ${className}`}>
      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> Live
    </span>
  );
}

export function Modal({ open, onClose, title, children, wide = false }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onClose?.();
    document.addEventListener('keydown', onKey);
    const release = lockScroll();
    return () => { document.removeEventListener('keydown', onKey); release(); };
  }, [open, onClose]);
  if (!open) return null;
  // Rendered at the top of the page so it is never trapped inside a game frame.
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={`animate-slide-up sm:animate-fade-in max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border border-navy-600 bg-navy-850 shadow-2xl sm:rounded-xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'}`}>
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-navy-700 bg-navy-850 px-5 py-3.5">
          <h2 className="text-base font-bold text-white">{title}</h2>
          {onClose && (
            <button onClick={onClose} className="rounded p-1 text-slate-400 hover:bg-navy-700 hover:text-white" aria-label="Close">
              <Icon.x className="h-5 w-5" />
            </button>
          )}
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

export function Tabs({ tabs, value, onChange, className = '' }) {
  return (
    <div className={`flex gap-1 overflow-x-auto scrollbar-none border-b border-navy-700 ${className}`} role="tablist">
      {tabs.map((t) => (
        <button
          key={t.value}
          role="tab"
          aria-selected={value === t.value}
          onClick={() => onChange(t.value)}
          className={`relative whitespace-nowrap px-4 py-3 text-sm font-semibold transition-colors ${value === t.value ? 'text-white' : 'text-slate-400 hover:text-slate-200'}`}
        >
          {t.label}
          {t.count != null && <span className="ml-1.5 rounded-full bg-navy-600 px-1.5 py-0.5 text-[10px]">{t.count}</span>}
          {value === t.value && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded bg-brand-500" />}
        </button>
      ))}
    </div>
  );
}

export function StatTile({ label, value, sub, tone }) {
  const color = tone === 'pos' ? 'text-brand-400' : tone === 'neg' ? 'text-red-400' : 'text-white';
  return (
    <div className="rounded-lg border border-navy-700/70 bg-navy-850 p-3.5">
      <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">{label}</div>
      <div className={`mt-1 text-xl font-bold tabular-nums ${color}`}>{value}</div>
      {sub && <div className="mt-0.5 text-xs text-slate-500">{sub}</div>}
    </div>
  );
}
