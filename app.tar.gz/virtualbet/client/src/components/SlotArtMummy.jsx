// Mystery of the Mummy art: original inline-SVG symbols in gold and
// turquoise (scarab wild, relic scatter, mummy, emerald gems, coins,
// pharaoh, Anubis, Book of the Dead, Eye of Horus, ankh, carved letters),
// the Cash Collect mummy, logo and lobby emblem. Gradients: <MummyDefs />.

import PaintedSym from './PaintedSym.jsx';
import { SLOT_IMG } from '../assets/slots/index.js';
export function MummyDefs() {
  const lg = (id, stops, x2 = 0, y2 = 1) => <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  const rg = (id, stops, cx = '42%', cy = '36%') => <radialGradient id={id} cx={cx} cy={cy} r="65%">{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {lg('mmGold', [[0, '#fff8d6'], [0.35, '#fcd34d'], [0.7, '#d97706'], [1, '#713f12']])}
        {lg('mmGoldH', [[0, '#713f12'], [0.3, '#fcd34d'], [0.5, '#fff8d6'], [0.7, '#fcd34d'], [1, '#713f12']], 1, 0)}
        {lg('mmTurq', [[0, '#ccfbf1'], [0.45, '#14b8a6'], [1, '#134e4a']])}
        {lg('mmLapis', [[0, '#93c5fd'], [0.5, '#1d4ed8'], [1, '#172554']])}
        {lg('mmStone', [[0, '#e7c98f'], [0.55, '#b98a4b'], [1, '#6b4a24']])}
        {lg('mmDark', [[0, '#3b2a17'], [1, '#120c05']])}
        {lg('mmJackal', [[0, '#3f3f46'], [0.6, '#18181b'], [1, '#000']])}
        {lg('mmSkin', [[0, '#e0a96d'], [1, '#8a5a2b']])}
        {lg('mmWrap', [[0, '#f5ecd7'], [0.6, '#cdbb92'], [1, '#7c6a45']])}
        {lg('mmPapyrus', [[0, '#fef3c7'], [1, '#d6b16a']])}
        {lg('mmLetA', [[0, '#fecaca'], [0.5, '#dc2626'], [1, '#7f1d1d']])}
        {lg('mmLetK', [[0, '#a5f3fc'], [0.5, '#0891b2'], [1, '#164e63']])}
        {lg('mmLetQ', [[0, '#e9d5ff'], [0.5, '#9333ea'], [1, '#3b0764']])}
        {lg('mmLetJ', [[0, '#bbf7d0'], [0.5, '#16a34a'], [1, '#14532d']])}
        {rg('mmEmerald', [[0, '#d1fae5'], [0.35, '#34d399'], [0.75, '#047857'], [1, '#022c22']])}
        {rg('mmCoin', [[0, '#fffbeb'], [0.45, '#fbbf24'], [0.85, '#b45309'], [1, '#78350f']])}
        {rg('mmGlow', [[0.3, 'rgba(252,211,77,0.55)'], [1, 'rgba(252,211,77,0)']], '50%', '50%')}
        {rg('mmGreenGlow', [[0.3, 'rgba(52,211,153,0.6)'], [1, 'rgba(52,211,153,0)']], '50%', '50%')}
        <filter id="mmSoft" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
    </svg>
  );
}

const T = (t, y, size, fill, stroke = '#2a1a08', len) => (
  <text x="50" y={y} textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize={size} fill={fill} stroke={stroke} strokeWidth={size / 9} paintOrder="stroke" {...(len ? { textLength: len, lengthAdjust: 'spacingAndGlyphs' } : {})}>{t}</text>
);

// A row of tiny hieroglyphs (decoration on tablets and the logo).
export const Glyphs = ({ y = 0, fill = '#fcd34d', w = 100 }) => (
  <g fill={fill} transform={`translate(0 ${y})`} opacity=".85">
    {Array.from({ length: Math.floor(w / 12) }, (_, i) => {
      const x = 4 + i * 12, k = i % 5;
      return k === 0 ? <path key={i} d={`M${x} 6a3 3 0 106 0a3 3 0 10-6 0M${x + 3} 9v4`} stroke={fill} strokeWidth="1.2" fill="none" />
        : k === 1 ? <path key={i} d={`M${x} 12l3-8l3 8z`} />
          : k === 2 ? <path key={i} d={`M${x} 9q3-6 6 0q-3 4-6 0z`} />
            : k === 3 ? <rect key={i} x={x + 1} y="4" width="4" height="9" rx="1" />
              : <path key={i} d={`M${x} 13c0-6 6-6 6 0M${x + 3} 4v3`} stroke={fill} strokeWidth="1.2" fill="none" />;
    })}
  </g>
);

const Letter = ({ ch, fill }) => (
  <g>
    <rect x="12" y="10" width="76" height="80" rx="8" fill="url(#mmStone)" stroke="#6b4a24" strokeWidth="2" />
    <rect x="16" y="14" width="68" height="72" rx="6" fill="none" stroke="#fcd34d" strokeOpacity=".5" strokeWidth="1.2" />
    <g transform="translate(14 14) scale(.72)"><Glyphs fill="#7c5a2b" /></g>
    {T(ch, 74, 62, fill, '#2a1a08')}
  </g>
);

export function Scarab({ glow = true }) {
  return (
    <g>
      {glow && <circle cx="50" cy="44" r="42" fill="url(#mmGlow)" />}
      {/* wings */}
      <path d="M44 44C30 30 12 30 4 38C12 40 18 46 24 54C30 54 38 52 44 50Z" fill="url(#mmTurq)" stroke="#713f12" strokeWidth="1.5" className="mm-wing-l" />
      <path d="M56 44C70 30 88 30 96 38C88 40 82 46 76 54C70 54 62 52 56 50Z" fill="url(#mmTurq)" stroke="#713f12" strokeWidth="1.5" className="mm-wing-r" />
      <path d="M10 38C20 36 30 40 40 46M90 38C80 36 70 40 60 46M16 44C24 44 32 48 40 50M84 44C76 44 68 48 60 50" stroke="#fcd34d" strokeWidth="1.2" fill="none" />
      {/* sun disk */}
      <circle cx="50" cy="16" r="9" fill="#ef4444" stroke="url(#mmGold)" strokeWidth="2.5" />
      {/* body */}
      <path d="M50 24C42 24 38 30 38 36L40 62C42 72 46 76 50 76C54 76 58 72 60 62L62 36C62 30 58 24 50 24Z" fill="url(#mmGold)" stroke="#713f12" strokeWidth="2" />
      <path d="M50 38V76M40 46H60" stroke="#713f12" strokeWidth="1.5" />
      <path d="M42 30Q50 26 58 30" stroke="#fff8d6" strokeWidth="2" fill="none" opacity=".7" />
      <path d="M38 52L28 58M38 60L30 68M62 52L72 58M62 60L70 68" stroke="#713f12" strokeWidth="2.5" strokeLinecap="round" />
    </g>
  );
}

function MummyHead() {
  return (
    <g>
      <circle cx="50" cy="50" r="44" fill="url(#mmGreenGlow)" />
      <path d="M22 30C22 12 78 12 78 30V70C78 88 22 88 22 70Z" fill="url(#mmWrap)" stroke="#5b4a2a" strokeWidth="2" />
      {[24, 34, 44, 58, 68, 78].map((y, i) => <path key={i} d={`M22 ${y}Q50 ${y + (i % 2 ? 7 : -5)} 78 ${y + (i % 2 ? -3 : 4)}`} stroke="#8a7650" strokeWidth="2" fill="none" />)}
      <path d="M30 46H70V56H30Z" fill="#1c1408" />
      <ellipse cx="40" cy="51" rx="5.5" ry="3.5" fill="#4ade80" filter="url(#mmSoft)" className="mm-eyes" />
      <ellipse cx="60" cy="51" rx="5.5" ry="3.5" fill="#4ade80" filter="url(#mmSoft)" className="mm-eyes" />
      <path d="M62 76Q78 84 84 96" stroke="url(#mmWrap)" strokeWidth="5" fill="none" />
    </g>
  );
}

const Pharaoh = () => (
  <g>
    <path d="M18 92L24 44C24 18 76 18 76 44L82 92Z" fill="url(#mmLapis)" stroke="#713f12" strokeWidth="2" />
    {[52, 60, 68, 76, 84].map((y, i) => <path key={i} d={`M${20 + (92 - y) * 0.06} ${y}H${80 - (92 - y) * 0.06}`} stroke="url(#mmGoldH)" strokeWidth="3.5" />)}
    <path d="M24 44C24 20 76 20 76 44" fill="none" stroke="url(#mmGoldH)" strokeWidth="4" />
    <path d="M34 34C34 24 66 24 66 34V60C66 74 58 80 50 80C42 80 34 74 34 60Z" fill="url(#mmSkin)" stroke="#5b3a14" strokeWidth="1.8" />
    <path d="M38 46L46 47M62 46L54 47" stroke="#1c1408" strokeWidth="2.4" strokeLinecap="round" />
    <path d="M38 50Q42 48 46 50Q42 52 38 50ZM54 50Q58 48 62 50Q58 52 54 50Z" fill="#1c1408" />
    <path d="M36 51L32 54M64 51L68 54" stroke="#1c1408" strokeWidth="1.5" />
    <path d="M50 52V62L47 64" stroke="#5b3a14" strokeWidth="1.5" fill="none" />
    <path d="M45 69Q50 71 55 69" stroke="#7f1d1d" strokeWidth="2" fill="none" />
    <path d="M46 78H54L52 94H48Z" fill="url(#mmGoldH)" stroke="#713f12" strokeWidth="1" />
    <path d="M46 24L50 14L54 24Z" fill="url(#mmGold)" stroke="#713f12" strokeWidth="1" />
    <circle cx="50" cy="28" r="2.5" fill="#ef4444" />
  </g>
);

const Anubis = () => (
  <g>
    <path d="M28 6L40 34L22 36Z" fill="url(#mmJackal)" stroke="#fcd34d" strokeWidth="1.5" />
    <path d="M58 4L66 32L50 30Z" fill="url(#mmJackal)" stroke="#fcd34d" strokeWidth="1.5" />
    <path d="M24 92L28 56C26 42 30 30 44 28C56 26 64 34 66 42L90 54C92 58 90 62 86 62L66 62C66 72 70 82 74 92Z" fill="url(#mmJackal)" stroke="#fcd34d" strokeWidth="2" />
    <path d="M26 66H72M27 74H73M28 82H74" stroke="url(#mmGoldH)" strokeWidth="3.5" />
    <path d="M26 66C30 62 40 62 46 66" fill="none" stroke="url(#mmTurq)" strokeWidth="3" />
    <path d="M48 42Q54 38 60 42Q54 45 48 42Z" fill="#fcd34d" />
    <circle cx="54" cy="42" r="1.6" fill="#000" />
    <path d="M86 56L92 58" stroke="#71717a" strokeWidth="3" strokeLinecap="round" />
    <path d="M64 50L84 56" stroke="#fcd34d" strokeWidth="1.2" opacity=".7" />
  </g>
);

const Book = () => (
  <g>
    <path d="M8 26L50 34L92 26V84L50 92L8 84Z" fill="url(#mmDark)" stroke="url(#mmGold)" strokeWidth="2.5" />
    <path d="M14 30L48 37V86L14 80Z" fill="url(#mmPapyrus)" />
    <path d="M86 30L52 37V86L86 80Z" fill="url(#mmPapyrus)" />
    <g transform="translate(16 42) scale(.3)"><Glyphs fill="#7c5a2b" w={100} /></g>
    <g transform="translate(16 54) scale(.3)"><Glyphs fill="#7c5a2b" w={100} /></g>
    <g transform="translate(16 66) scale(.3)"><Glyphs fill="#7c5a2b" w={100} /></g>
    <path d="M58 56Q68 48 78 56Q68 63 58 56Z" fill="#fff" stroke="#1c1408" strokeWidth="1.5" />
    <circle cx="68" cy="56" r="3.5" fill="#1d4ed8" />
    <path d="M60 60L58 70M66 61Q70 66 74 64" stroke="#1c1408" strokeWidth="1.5" fill="none" />
    <path d="M50 34V92" stroke="#713f12" strokeWidth="2" />
    <circle cx="50" cy="16" r="10" fill="url(#mmGlow)" />
  </g>
);

const Eye = () => (
  <g>
    <rect x="10" y="16" width="80" height="68" rx="10" fill="url(#mmTurq)" stroke="url(#mmGold)" strokeWidth="3" />
    <path d="M18 48Q50 18 82 48Q50 70 18 48Z" fill="#fff8d6" stroke="#1c1408" strokeWidth="3" />
    <circle cx="50" cy="46" r="11" fill="url(#mmLapis)" stroke="#1c1408" strokeWidth="2" />
    <circle cx="47" cy="43" r="3" fill="#fff" />
    <path d="M14 34Q50 14 86 34" stroke="#1c1408" strokeWidth="4" fill="none" />
    <path d="M42 62L38 78M52 64Q60 74 70 70Q74 66 70 62" stroke="#1c1408" strokeWidth="3.5" fill="none" strokeLinecap="round" />
  </g>
);

const Ankh = () => (
  <g>
    <circle cx="50" cy="50" r="40" fill="url(#mmGlow)" opacity=".6" />
    <path d="M50 8C36 8 32 22 38 34C41 39 45 42 47 44H18V56H44V94H56V56H82V44H53C55 42 59 39 62 34C68 22 64 8 50 8ZM50 18C57 18 57 28 53 34L50 38L47 34C43 28 43 18 50 18Z" fill="url(#mmGold)" stroke="#713f12" strokeWidth="2" fillRule="evenodd" />
    <path d="M22 48H44M56 48H78" stroke="#fff8d6" strokeWidth="1.5" opacity=".7" />
    <circle cx="50" cy="50" r="4" fill="url(#mmTurq)" stroke="#713f12" />
  </g>
);

const Relic = () => (
  <g>
    <circle cx="50" cy="44" r="44" fill="url(#mmGlow)" />
    <path d="M4 40C18 30 30 34 40 40M96 40C82 30 70 34 60 40" stroke="url(#mmGold)" strokeWidth="5" fill="none" strokeLinecap="round" />
    <path d="M8 48C20 40 30 44 40 48M92 48C80 40 70 44 60 48" stroke="url(#mmTurq)" strokeWidth="4" fill="none" strokeLinecap="round" />
    <path d="M50 12L68 34L50 72L32 34Z" fill="url(#mmTurq)" stroke="url(#mmGold)" strokeWidth="3.5" />
    <path d="M50 12L56 34L50 72L44 34Z" fill="#ccfbf1" opacity=".5" />
    <path d="M32 34H68" stroke="#fff" strokeWidth="1.5" opacity=".7" />
    <rect x="10" y="72" width="80" height="22" rx="6" fill="#134e4a" stroke="url(#mmGold)" strokeWidth="2.5" />
    {T('FREE GAMES', 88, 13, 'url(#mmGold)', '#022c22', 70)}
  </g>
);

export function GemArt({ v, label }) {
  return (
    <g>
      <circle cx="50" cy="46" r="40" fill="url(#mmGreenGlow)" />
      <path d="M50 10L80 32L70 74H30L20 32Z" fill="url(#mmEmerald)" stroke="#fcd34d" strokeWidth="3" />
      <path d="M50 10L60 32L50 74L40 32Z M20 32H80" stroke="#d1fae5" strokeOpacity=".55" strokeWidth="1.5" fill="none" />
      <path d="M32 26L44 18" stroke="#fff" strokeWidth="3" strokeLinecap="round" opacity=".8" />
      {v != null && <><rect x="14" y="70" width="72" height="24" rx="7" fill="#022c22" stroke="url(#mmGold)" strokeWidth="2" />{T(label || `${v}x`, 89, label ? 15 : 18, label ? '#fde68a' : '#fff', '#022c22', label ? 54 : undefined)}</>}
    </g>
  );
}

export function CoinArt({ v }) {
  return (
    <g>
      <circle cx="50" cy="50" r="42" fill="url(#mmCoin)" stroke="#78350f" strokeWidth="3" />
      <circle cx="50" cy="50" r="33" fill="none" stroke="#fff8d6" strokeOpacity=".6" strokeWidth="1.5" strokeDasharray="2 3" />
      <g transform="translate(29 17) scale(.42)"><Ankh /></g>
      {v != null && T(`${v}x`, 80, 20, '#fff', '#78350f')}
    </g>
  );
}

export const MUMMY_ART = {
  J: <Letter ch="J" fill="url(#mmLetJ)" />,
  Q: <Letter ch="Q" fill="url(#mmLetQ)" />,
  K: <Letter ch="K" fill="url(#mmLetK)" />,
  A: <Letter ch="A" fill="url(#mmLetA)" />,
  ANKH: <Ankh />, EYE: <Eye />, BOOK: <Book />, ANUBIS: <Anubis />, PHARAOH: <Pharaoh />,
  WILD: <g><Scarab /><rect x="20" y="76" width="60" height="20" rx="6" fill="#422006" stroke="url(#mmGold)" strokeWidth="2" />{T('WILD', 92, 16, 'url(#mmGold)', '#2a1a08', 44)}</g>,
  FS: <Relic />,
  MUMMY: <MummyHead />,
  GEM: <GemArt />,
};

export const MUMMY_NAMES = {
  J: 'J', Q: 'Q', K: 'K', A: 'A', ANKH: 'Golden Ankh', EYE: 'Eye of Horus', BOOK: 'Book of the Dead', ANUBIS: 'Anubis', PHARAOH: 'Pharaoh',
  WILD: 'Scarab Wild', FS: 'Free Games relic', MUMMY: 'Mummy', GEM: 'Green gem', COIN: 'Gold coin',
};

const HI = new Set(['WILD', 'FS', 'MUMMY', 'GEM']);
const PREMIUM = new Set(['PHARAOH', 'ANUBIS', 'BOOK', 'EYE', 'ANKH']);
export const gemLabel = (v) => (v === 20 ? 'MINI' : v === 60 ? 'MINOR' : null);

export function MummySym({ cell, className = '' }) {
  if (!cell) return null;
  const s = cell.s;
  const img = s !== 'GEM' && SLOT_IMG.mummy[s];
  if (img) {
    const tier = ['WILD', 'FS', 'MUMMY', 'COIN'].includes(s) ? 'special' : ['J', 'Q', 'K', 'A'].includes(s) ? 'low' : ['ANKH', 'EYE'].includes(s) ? 'mid' : 'premium';
    return <PaintedSym src={img} alt={MUMMY_NAMES[s] || s} tier={tier} glow={{ WILD: '#fbbf24', FS: '#f472b6', MUMMY: '#34d399', COIN: '#fde047' }[s]} className={className} />;
  }
  const art = s === 'GEM' ? <GemArt v={cell.v} label={gemLabel(cell.v)} /> : MUMMY_ART[s];
  return (
    <div className={`relative h-full w-full rounded-md ${s === 'GEM' || s === 'MUMMY' ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(52,211,153,0.3),rgba(6,10,8,0.95))] ring-1 ring-emerald-300/50' : HI.has(s) ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(252,211,77,0.32),rgba(20,12,4,0.95))] ring-1 ring-amber-300/60' : PREMIUM.has(s) ? 'bg-[radial-gradient(circle_at_50%_35%,rgba(20,184,166,0.22),rgba(12,10,6,0.95))] ring-1 ring-teal-300/25' : 'bg-[radial-gradient(circle_at_50%_35%,rgba(185,138,75,0.2),rgba(14,10,5,0.95))] ring-1 ring-amber-900/40'} ${className}`}>
      <svg viewBox="0 0 100 100" className={`h-full w-full p-[6%] ${s === 'WILD' ? 'mm-scarab' : s === 'FS' ? 'mm-relic' : ''}`} role="img" aria-label={s === 'GEM' ? `Green gem ${cell.v}x` : MUMMY_NAMES[s] || s}>{art}</svg>
    </div>
  );
}

/** The big mummy that fills the Cash Collect zone (viewBox 100x100, stretches). */
export function MummyFigure() {
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" className="h-full w-full" aria-hidden="true">
      <circle cx="50" cy="50" r="48" fill="url(#mmGreenGlow)" />
      <path d="M8 60C14 50 26 48 32 52L34 60L16 74Z" fill="url(#mmWrap)" stroke="#5b4a2a" strokeWidth="1.5" />
      <path d="M92 60C86 50 74 48 68 52L66 60L84 74Z" fill="url(#mmWrap)" stroke="#5b4a2a" strokeWidth="1.5" />
      <path d="M30 98L32 50C32 40 68 40 68 50L70 98Z" fill="url(#mmWrap)" stroke="#5b4a2a" strokeWidth="2" />
      {[56, 64, 72, 80, 88].map((y, i) => <path key={i} d={`M31 ${y}Q50 ${y + (i % 2 ? 5 : -4)} 69 ${y + 2}`} stroke="#8a7650" strokeWidth="1.8" fill="none" />)}
      <path d="M34 26C34 8 66 8 66 26V40C66 50 34 50 34 40Z" fill="url(#mmWrap)" stroke="#5b4a2a" strokeWidth="2" />
      {[18, 26, 36, 44].map((y, i) => <path key={i} d={`M34 ${y}Q50 ${y + (i % 2 ? 4 : -3)} 66 ${y + 1}`} stroke="#8a7650" strokeWidth="1.6" fill="none" />)}
      <path d="M38 29H62V35H38Z" fill="#1c1408" />
      <ellipse cx="44" cy="32" rx="3.5" ry="2.2" fill="#4ade80" filter="url(#mmSoft)" className="mm-eyes" />
      <ellipse cx="56" cy="32" rx="3.5" ry="2.2" fill="#4ade80" filter="url(#mmSoft)" className="mm-eyes" />
    </svg>
  );
}

export function MummyLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 320 96" className={className} aria-label="Mystery of the Mummy">
      <path d="M128 40L160 6L192 40Z" fill="url(#mmGold)" opacity=".9" />
      <g transform="translate(140 2) scale(.4)"><Scarab glow={false} /></g>
      <text x="160" y="40" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="15" letterSpacing="7" fill="#5eead4">MYSTERY OF THE</text>
      <text x="160" y="80" textAnchor="middle" fontFamily="'Lilita One'" fontSize="46" textLength="250" lengthAdjust="spacingAndGlyphs" letterSpacing="6" fill="url(#mmGold)" stroke="#2a1a08" strokeWidth="3" paintOrder="stroke">MUMMY</text>
      <g transform="translate(30 84) scale(2.6 .9)"><Glyphs fill="#fcd34d" w={100} /></g>
    </svg>
  );
}

export const MUMMY_LOBBY = (
  <g>
    <rect width="100" height="100" fill="url(#mmDark)" />
    <path d="M0 100L50 20L100 100Z" fill="url(#mmStone)" opacity=".55" />
    <circle cx="50" cy="52" r="34" fill="url(#mmGreenGlow)" />
    <g transform="translate(22 22) scale(.56)"><MummyHead /></g>
    <g transform="translate(4 70) scale(.28)"><Scarab glow={false} /></g>
    <g transform="translate(70 70) scale(.28)"><GemArt /></g>
  </g>
);
