// Cluck Crossing art: original chicken (posable parts for CSS animation),
// top-down vehicles (car, taxi, van, truck, bus, sports car), manhole lane
// markers, barrier, logo and lobby emblem. Gradients: <ChickenDefs />.

export function ChickenDefs() {
  const lg = (id, stops, x2 = 0, y2 = 1) => <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>;
  const rg = (id, stops) => <radialGradient id={id} cx="40%" cy="35%" r="70%">{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {rg('ckBody', [[0, '#ffffff'], [0.6, '#fef3c7'], [1, '#e5c79a']])}
        {lg('ckComb', [[0, '#fb7185'], [1, '#be123c']])}
        {lg('ckBeak', [[0, '#fde047'], [1, '#f59e0b']])}
        {lg('ckGold', [[0, '#fffbeb'], [0.4, '#fde047'], [0.75, '#f59e0b'], [1, '#92400e']])}
        {lg('ckSteel', [[0, '#f1f5f9'], [0.5, '#94a3b8'], [1, '#334155']])}
        {lg('ckGlass', [[0, '#bae6fd'], [1, '#0c4a6e']])}
        {rg('ckManhole', [[0, '#64748b'], [0.7, '#334155'], [1, '#1e293b']])}
      </defs>
    </svg>
  );
}

/** The chicken, facing right. Parts carry ck-* classes the CSS animates per pose. */
export function Chicken({ goldHat = false }) {
  return (
    <g>
      <ellipse className="ck-shadow" cx="50" cy="94" rx="24" ry="5" fill="#000" opacity=".28" />
      <g className="ck-legs">
        <g className="ck-legL"><path d="M44 74L42 90M42 90L35 92M42 90L46 93M42 90L40 94" stroke="#f59e0b" strokeWidth="3.4" strokeLinecap="round" fill="none" /></g>
        <g className="ck-legR"><path d="M56 74L58 90M58 90L52 92M58 90L63 93M58 90L60 94" stroke="#f59e0b" strokeWidth="3.4" strokeLinecap="round" fill="none" /></g>
      </g>
      <g className="ck-body">
        {/* tail */}
        <path d="M22 50C12 40 12 28 18 22C20 32 24 36 30 40C26 30 28 22 34 18C34 30 36 36 40 42Z" fill="url(#ckBody)" stroke="#b08a5a" strokeWidth="1.8" strokeLinejoin="round" />
        {/* body */}
        <path d="M26 52C26 38 38 32 52 34C60 26 62 18 66 14C74 10 84 14 84 24C84 30 80 34 78 40C82 50 80 62 72 70C64 78 50 80 40 76C30 72 26 62 26 52Z" fill="url(#ckBody)" stroke="#b08a5a" strokeWidth="2" strokeLinejoin="round" />
        {/* wing */}
        <g className="ck-wing"><path d="M38 50C42 44 54 44 60 50C62 58 56 66 46 66C40 66 36 62 36 58C38 58 40 58 42 56C38 56 36 54 38 50Z" fill="#fde9c4" stroke="#b08a5a" strokeWidth="1.8" strokeLinejoin="round" /><path d="M42 58Q50 60 56 56M42 62Q50 64 54 60" stroke="#c9a676" strokeWidth="1.2" fill="none" /></g>
        {/* head details */}
        <path d="M66 14C66 6 72 4 74 8C76 2 82 2 82 8C86 6 90 10 86 14C84 16 80 14 78 14Z" fill="url(#ckComb)" stroke="#9f1239" strokeWidth="1.2" />
        <path d="M84 22L95 25L84 29Z" fill="url(#ckBeak)" stroke="#b45309" strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M82 30C86 32 86 38 82 39C79 38 79 33 82 30Z" fill="url(#ckComb)" stroke="#9f1239" strokeWidth="1" />
        <g className="ck-eye"><ellipse cx="76" cy="20" rx="4.2" ry="4.6" fill="#fff" stroke="#1f2937" strokeWidth="1.1" /><circle cx="77.4" cy="20.4" r="2.4" fill="#111827" /><circle cx="78.2" cy="19.4" r=".8" fill="#fff" /></g>
        <g className="ck-sweat"><path d="M68 10Q66 14 68 16Q70 14 68 10Z" fill="#7dd3fc" stroke="#0369a1" strokeWidth=".6" /></g>
        <ellipse cx="72" cy="27" rx="3" ry="1.6" fill="#fb7185" opacity=".45" />
        {goldHat && <g transform="translate(62 -6)"><path d="M2 14L4 4L10 10L14 0L18 10L24 4L26 14Z" fill="url(#ckGold)" stroke="#78350f" strokeWidth="1.2" /></g>}
      </g>
    </g>
  );
}

const Wheels = ({ len, w }) => [[-w / 2 - 1, len * 0.22], [w / 2 + 1, len * 0.22], [-w / 2 - 1, len * 0.78], [w / 2 + 1, len * 0.78]].map(([x, y], i) => <rect key={i} x={x - 2.5} y={y - 6} width="5" height="12" rx="2" fill="#111827" />);
const Lights = ({ len, w }) => <><rect x={-w / 2 + 3} y={len - 3} width="6" height="3" rx="1" fill="#fef9c3" /><rect x={w / 2 - 9} y={len - 3} width="6" height="3" rx="1" fill="#fef9c3" /><rect x={-w / 2 + 3} y="0" width="6" height="2.5" rx="1" fill="#ef4444" /><rect x={w / 2 - 9} y="0" width="6" height="2.5" rx="1" fill="#ef4444" /></>;

/** Top-down vehicles, drawn nose-down (pointing +y) centred on x = 0. */
export const VEHICLES = {
  car: { len: 56, w: 30, draw: (c) => (
    <g><Wheels len={56} w={30} /><rect x="-15" y="0" width="30" height="56" rx="9" fill={c} stroke="#0f172a" strokeWidth="1.6" />
      <rect x="-11" y="34" width="22" height="11" rx="3" fill="url(#ckGlass)" /><rect x="-11" y="10" width="22" height="8" rx="3" fill="url(#ckGlass)" opacity=".85" />
      <rect x="-11" y="19" width="22" height="14" rx="2" fill="#000" opacity=".12" /><Lights len={56} w={30} /></g>
  ) },
  taxi: { len: 58, w: 30, draw: () => (
    <g><Wheels len={58} w={30} /><rect x="-15" y="0" width="30" height="58" rx="9" fill="#facc15" stroke="#0f172a" strokeWidth="1.6" />
      <rect x="-11" y="36" width="22" height="11" rx="3" fill="url(#ckGlass)" /><rect x="-11" y="10" width="22" height="8" rx="3" fill="url(#ckGlass)" opacity=".85" />
      <rect x="-7" y="24" width="14" height="6" rx="1.5" fill="#111827" /><text x="0" y="29" textAnchor="middle" fontSize="4.6" fontWeight="900" fill="#fde047">TAXI</text><Lights len={58} w={30} /></g>
  ) },
  van: { len: 70, w: 34, draw: (c) => (
    <g><Wheels len={70} w={34} /><rect x="-17" y="0" width="34" height="70" rx="7" fill={c} stroke="#0f172a" strokeWidth="1.6" />
      <rect x="-13" y="52" width="26" height="10" rx="3" fill="url(#ckGlass)" /><rect x="-13" y="6" width="26" height="42" rx="3" fill="#fff" opacity=".18" />
      <path d="M-13 18H13M-13 30H13" stroke="#000" strokeOpacity=".15" /><Lights len={70} w={34} /></g>
  ) },
  truck: { len: 104, w: 38, draw: (c) => (
    <g><Wheels len={104} w={38} /><rect x="-19" y="0" width="38" height="74" rx="3" fill="url(#ckSteel)" stroke="#0f172a" strokeWidth="1.6" />
      {[12, 24, 36, 48, 60].map((y) => <path key={y} d={`M-19 ${y}H19`} stroke="#475569" strokeWidth="1" />)}
      <rect x="-17" y="76" width="34" height="28" rx="6" fill={c} stroke="#0f172a" strokeWidth="1.6" /><rect x="-13" y="92" width="26" height="8" rx="2" fill="url(#ckGlass)" />
      <rect x="-14" y="101" width="6" height="3" rx="1" fill="#fef9c3" /><rect x="8" y="101" width="6" height="3" rx="1" fill="#fef9c3" /></g>
  ) },
  bus: { len: 118, w: 38, draw: () => (
    <g><Wheels len={118} w={38} /><rect x="-19" y="0" width="38" height="118" rx="7" fill="#dc2626" stroke="#0f172a" strokeWidth="1.6" />
      <rect x="-14" y="6" width="28" height="98" rx="4" fill="#fecaca" opacity=".25" />{[18, 40, 62, 84].map((y) => <rect key={y} x="-10" y={y} width="20" height="10" rx="2" fill="#fff" opacity=".35" />)}
      <rect x="-15" y="106" width="30" height="8" rx="2" fill="url(#ckGlass)" /><Lights len={118} w={38} /></g>
  ) },
  sport: { len: 54, w: 28, draw: (c) => (
    <g><Wheels len={54} w={28} /><path d="M-14 6Q-14 0 -8 0H8Q14 0 14 6V48Q14 54 6 54H-6Q-14 54 -14 48Z" fill={c} stroke="#0f172a" strokeWidth="1.6" />
      <rect x="-10" y="30" width="20" height="10" rx="4" fill="url(#ckGlass)" /><path d="M-3 0V54M3 0V54" stroke="#fff" strokeWidth="2.2" opacity=".85" /><Lights len={54} w={28} /></g>
  ) },
};
export const VEHICLE_KINDS = ['car', 'car', 'taxi', 'van', 'truck', 'car', 'sport', 'bus', 'van', 'car'];
export const VEHICLE_COLOURS = ['#2563eb', '#16a34a', '#9333ea', '#f97316', '#0ea5e9', '#e11d48', '#64748b', '#14b8a6'];

export function Vehicle({ kind = 'car', colour = '#2563eb', up = false }) {
  const v = VEHICLES[kind];
  return (
    <svg viewBox={`${-v.w / 2 - 4} -2 ${v.w + 8} ${v.len + 4}`} width={v.w + 8} height={v.len + 4} className="block overflow-visible drop-shadow-[0_4px_4px_rgba(0,0,0,0.45)]" style={up ? { transform: 'rotate(180deg)' } : undefined} aria-hidden="true">
      {v.draw(colour)}
    </svg>
  );
}

export function Manhole({ label, state = 'ahead' }) {
  const ring = state === 'next' ? '#fde047' : state === 'done' ? '#4ade80' : '#94a3b8';
  return (
    <svg viewBox="0 0 100 100" className="h-full w-full" aria-hidden="true">
      <circle cx="50" cy="50" r="46" fill={state === 'done' ? '#166534' : 'url(#ckManhole)'} stroke={ring} strokeWidth={state === 'next' ? 6 : 4} />
      <circle cx="50" cy="50" r="38" fill="none" stroke="#000" strokeOpacity=".25" strokeWidth="2" strokeDasharray="4 4" />
      <text x="50" y="58" textAnchor="middle" fontFamily="'Lilita One', system-ui, sans-serif" fontSize={label.length > 7 ? 18 : label.length > 5 ? 22 : 26} fill="#fff" stroke="#000" strokeWidth="3" paintOrder="stroke">{label}</text>
    </svg>
  );
}

export function Barrier() {
  return (
    <svg viewBox="0 0 100 40" className="h-full w-full" aria-hidden="true">
      <rect x="6" y="10" width="88" height="16" rx="3" fill="#fff" stroke="#111827" strokeWidth="2" />
      {[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${10 + i * 18} 10L${22 + i * 18} 26H${14 + i * 18}L${2 + i * 18} 10Z`} fill="#dc2626" />)}
      <rect x="10" y="26" width="6" height="12" fill="#334155" /><rect x="84" y="26" width="6" height="12" fill="#334155" />
      <circle cx="13" cy="7" r="4" fill="#f59e0b" /><circle cx="87" cy="7" r="4" fill="#f59e0b" />
    </svg>
  );
}

export function ChickenLogo({ className = '' }) {
  return (
    <svg viewBox="0 0 320 96" className={className} aria-label="Cluck Crossing">
      <g transform="translate(0 4) scale(.9)"><Chicken /></g>
      <text x="196" y="46" textAnchor="middle" fontFamily="'Lilita One', system-ui, sans-serif" fontSize="40" textLength="200" lengthAdjust="spacingAndGlyphs" fill="url(#ckGold)" stroke="#111827" strokeWidth="5" paintOrder="stroke">CLUCK</text>
      <rect x="104" y="54" width="184" height="30" rx="6" fill="#111827" stroke="#fde047" strokeWidth="2.5" />
      {[0, 1, 2, 3, 4, 5].map((i) => <rect key={i} x={112 + i * 30} y="67" width="16" height="4" fill="#fde047" />)}
      <text x="196" y="80" textAnchor="middle" fontFamily="'Lilita One', system-ui, sans-serif" fontSize="22" textLength="150" lengthAdjust="spacingAndGlyphs" fill="#fff" stroke="#111827" strokeWidth="4" paintOrder="stroke">CROSSING</text>
    </svg>
  );
}

export const CHICKEN_LOBBY = (
  <g>
    <rect width="100" height="100" fill="#334155" />
    <rect width="12" height="100" fill="#4ade80" /><rect x="88" width="12" height="100" fill="#4ade80" />
    {[30, 50, 70].map((x) => <g key={x}>{[6, 30, 54, 78].map((y) => <rect key={y} x={x - 1} y={y} width="2" height="12" fill="#f8fafc" opacity=".8" />)}</g>)}
    <g transform="translate(40 4) scale(.55)">{VEHICLES.car.draw('#2563eb')}</g>
    <g transform="translate(70 60) scale(.5) rotate(180)"><g transform="translate(-19 -60)">{VEHICLES.taxi.draw()}</g></g>
    <g transform="translate(16 40) scale(.5)"><Chicken /></g>
  </g>
);
