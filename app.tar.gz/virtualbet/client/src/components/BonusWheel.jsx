import { useEffect, useRef, useState } from 'react';
import { WHEEL } from '../../../server/blackjack.js';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';

const N = WHEEL.length;
const SEG = 360 / N;
const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

function segFill(w, i) {
  if (w.respin) return '#7c3aed';
  if (w.label === 'GRAND') return '#facc15';
  if (w.label === 'MAJOR') return '#f97316';
  if (w.label === 'MINI') return '#ec4899';
  return i % 2 ? '#0e7490' : '#155e75';
}
const segText = (w) => (w.respin ? 'RESPIN' : w.label ? `${w.label}` : `${w.x}x`);

function polar(r, deg) {
  const a = ((deg - 90) * Math.PI) / 180;
  return [150 + r * Math.cos(a), 150 + r * Math.sin(a)];
}

function WheelSvg({ rotation, spinning }) {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[300px]">
      {/* pointer */}
      <svg viewBox="0 0 40 40" className="absolute left-1/2 top-[-6px] z-10 h-9 w-9 -translate-x-1/2 drop-shadow-[0_3px_4px_rgba(0,0,0,0.6)]" aria-hidden="true">
        <path d="M20 38L6 8h28z" fill="#f8fafc" stroke="#0b1520" strokeWidth="2.5" strokeLinejoin="round" />
      </svg>
      <svg
        viewBox="0 0 300 300"
        className="h-full w-full"
        style={{ transform: `rotate(${rotation}deg)`, transition: spinning ? `transform ${reduceMotion ? 0 : 4.6}s cubic-bezier(0.12, 0.8, 0.18, 1)` : 'none' }}
        role="img"
        aria-label="Bonus wheel"
      >
        <circle cx="150" cy="150" r="148" fill="#0b1520" stroke="#facc15" strokeWidth="4" />
        {WHEEL.map((w, i) => {
          const a0 = i * SEG - SEG / 2, a1 = a0 + SEG;
          const [x0, y0] = polar(138, a0), [x1, y1] = polar(138, a1);
          const [tx, ty] = polar(86, i * SEG);
          return (
            <g key={i}>
              <path d={`M150 150L${x0} ${y0}A138 138 0 0 1 ${x1} ${y1}z`} fill={segFill(w, i)} stroke="#0b1520" strokeWidth="1.5" />
              <text x={tx} y={ty} transform={`rotate(${i * SEG - 90} ${tx} ${ty})`} textAnchor="middle" dominantBaseline="middle"
                fontSize={w.label || w.respin ? 12 : 16} fontWeight="900" fill={w.label === 'GRAND' ? '#0b1520' : '#ffffff'} fontFamily="system-ui, sans-serif">
                {segText(w)}
              </text>
            </g>
          );
        })}
        {/* rim lights */}
        {WHEEL.map((_, i) => { const [x, y] = polar(143, i * SEG - SEG / 2); return <circle key={i} cx={x} cy={y} r="2.6" fill="#fef3c7" />; })}
        <circle cx="150" cy="150" r="30" fill="#0b1520" stroke="#facc15" strokeWidth="3" />
        <text x="150" y="146" textAnchor="middle" fontSize="11" fontWeight="900" fill="#facc15" fontFamily="system-ui, sans-serif">SPIN</text>
        <text x="150" y="160" textAnchor="middle" fontSize="11" fontWeight="900" fill="#facc15" fontFamily="system-ui, sans-serif">21</text>
      </svg>
    </div>
  );
}

/**
 * Plays out one triggered wheel: each recorded spin in order (respins
 * double the prize), then shows the payout. The result was decided by the
 * game when the cards were dealt; the animation only reveals it.
 */
export default function BonusWheel({ spin, stake, handLabel, onDone }) {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [step, setStep] = useState(-1); // index into spin.spins that has landed
  const [started, setStarted] = useState(false);
  const rotRef = useRef(0);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const spinTo = (k) => {
    const idx = spin.spins[k];
    const jitter = (Math.random() - 0.5) * SEG * 0.6;
    const target = 360 - idx * SEG + jitter;
    const base = rotRef.current - (rotRef.current % 360);
    const next = base + 360 * (reduceMotion ? 1 : 6) + target;
    rotRef.current = next;
    setSpinning(true);
    setRotation(next);
    if (!reduceMotion) for (let t = 0; t < 22; t++) timers.current.push(setTimeout(() => sfx.chip(), 120 + t * t * 9));
    timers.current.push(setTimeout(() => {
      setSpinning(false);
      setStep(k);
      const w = WHEEL[idx];
      if (w.respin) { sfx.tease(); timers.current.push(setTimeout(() => spinTo(k + 1), 1300)); }
      else if (w.label) sfx.bigWin();
      else sfx.win();
    }, reduceMotion ? 50 : 4700));
  };

  const start = () => { if (started) return; setStarted(true); sfx.splash(); spinTo(0); };
  const landed = step >= 0 ? WHEEL[spin.spins[step]] : null;
  const finished = landed && !landed.respin;
  const respins = spin.spins.slice(0, step + 1).filter((i) => WHEEL[i].respin).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="animate-fade-in w-full max-w-sm rounded-2xl border-2 border-gold-500/60 bg-gradient-to-b from-navy-800 to-navy-950 p-5 text-center shadow-2xl">
        <div className="font-display text-2xl tracking-wide text-gold-400">BLACKJACK BONUS!</div>
        <div className="mb-3 text-xs text-slate-300">{handLabel} · Spin bet {money(stake)}</div>
        <WheelSvg rotation={rotation} spinning={spinning} />
        <div className="mt-4 min-h-16">
          {!started ? (
            <button className="btn h-12 w-full bg-gold-500 text-base font-extrabold text-navy-950 hover:bg-gold-400" onClick={start}>Spin the wheel</button>
          ) : spinning ? (
            <div className="text-sm text-slate-300">{respins ? `Respin! Prize ×${2 ** respins}` : 'Spinning…'}</div>
          ) : landed?.respin ? (
            <div className="animate-fade-in text-lg font-extrabold text-violet-300">RESPIN - next prize doubled!</div>
          ) : finished ? (
            <div className="animate-fade-in space-y-2">
              <div className="text-sm text-slate-300">
                {landed.label ? <b className="text-gold-400">{landed.label} </b> : null}
                {landed.x}x{spin.mult > 1 ? ` × ${spin.mult} = ${spin.x}x` : ''}
              </div>
              <div className="font-display text-4xl text-gold-400">+{money(spin.payout)}</div>
              <button className="btn-primary h-11 w-full" onClick={onDone}>Collect</button>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
