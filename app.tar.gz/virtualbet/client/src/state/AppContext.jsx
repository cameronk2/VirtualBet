import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { api, apiEvents } from '../lib/api.js';

const AppCtx = createContext(null);
export const useApp = () => useContext(AppCtx);

const SLIP_KEY = 'vb_betslip_v1';
const selKey = (s) => `${s.matchId}|${s.market}|${s.selection}`;
export { selKey };

function loadSlip() {
  try {
    const v = JSON.parse(localStorage.getItem(SLIP_KEY) || '[]');
    return Array.isArray(v) ? v : [];
  } catch { return []; }
}

function sessionStartValue() {
  try {
    let v = Number(sessionStorage.getItem('vb_session_start'));
    if (!v) { v = Date.now(); sessionStorage.setItem('vb_session_start', String(v)); }
    return v;
  } catch { return Date.now(); }
}

export function AppProvider({ children }) {
  const [config, setConfig] = useState(null);
  const [user, setUser] = useState(undefined); // undefined = loading, null = logged out
  const [toasts, setToasts] = useState([]);
  const [slip, setSlip] = useState(loadSlip);
  const [slipOpen, setSlipOpen] = useState(false);
  const [depositOpen, setDepositOpen] = useState(false);
  const [sessionStart, setSessionStart] = useState(sessionStartValue);
  const toastId = useRef(0);

  useEffect(() => {
    api.get('/api/config').then(setConfig).catch(() => setConfig({ rules: { minStake: 10, maxStake: 5000, maxSelections: 20, depositPackages: [] } }));
    // A dropped connection (or a server waking up) must not look like being
    // logged out: retry network failures, only treat a real answer as final.
    let stop = false;
    const loadMe = (attempt = 0) => api.get('/api/me').then((d) => { if (!stop) setUser(d.user); }).catch((e) => {
      if (stop) return;
      if (e.status === 0 && attempt < 6) setTimeout(() => loadMe(attempt + 1), Math.min(8000, 800 * 2 ** attempt));
      else setUser(e.status === 401 ? null : (u) => (u === undefined ? null : u));
    });
    loadMe();
    return () => { stop = true; };
  }, []);

  useEffect(() => {
    try { localStorage.setItem(SLIP_KEY, JSON.stringify(slip)); } catch { /* ignore */ }
  }, [slip]);

  // Keep balance fresh (settlements happen in the background)
  const refreshUser = useCallback(async () => {
    try {
      const d = await api.get('/api/me');
      setUser(d.user);
      return d.user;
    } catch { return null; } // network blip: keep the current session on screen
  }, []);
  useEffect(() => {
    if (!user) return undefined;
    const t = setInterval(() => { if (document.visibilityState === 'visible') refreshUser(); }, 10000);
    // Back from another app: balance and bets may have settled meanwhile
    const wake = () => { if (document.visibilityState === 'visible') refreshUser(); };
    document.addEventListener('visibilitychange', wake);
    window.addEventListener('online', wake);
    return () => { clearInterval(t); document.removeEventListener('visibilitychange', wake); window.removeEventListener('online', wake); };
  }, [!!user, refreshUser]); // eslint-disable-line react-hooks/exhaustive-deps

  const toast = useCallback((message, type = 'info') => {
    const id = ++toastId.current;
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  }, []);

  // Achievement badges (no prizes) announce themselves once
  useEffect(() => {
    const on = (e) => e.detail.forEach((b) => toast(`Achievement unlocked: ${b.name}`, 'badge'));
    apiEvents.addEventListener('unlocked', on);
    return () => apiEvents.removeEventListener('unlocked', on);
  }, [toast]);

  const startSession = useCallback(() => {
    const v = Date.now();
    try { sessionStorage.setItem('vb_session_start', String(v)); } catch { /* ignore */ }
    setSessionStart(v);
  }, []);

  const logout = useCallback(async () => {
    try { await api.post('/api/auth/logout'); } catch { /* ignore */ }
    setUser(null);
    try { sessionStorage.removeItem('vb_session_start'); } catch { /* ignore */ }
  }, []);

  // ── Bet slip ──
  const toggleSelection = useCallback((sel) => {
    const max = config?.rules?.maxSelections || 20;
    const k0 = selKey(sel);
    if (!slip.some((s) => selKey(s) === k0) && slip.filter((s) => !(s.matchId === sel.matchId && s.market === sel.market)).length >= max) {
      toast(`Your bet slip is full (${max} selections max).`, 'error');
      return;
    }
    setSlip((cur) => {
      const k = selKey(sel);
      if (cur.some((s) => selKey(s) === k)) return cur.filter((s) => selKey(s) !== k);
      // One selection per market per match: picking another option replaces it
      const without = cur.filter((s) => !(s.matchId === sel.matchId && s.market === sel.market));
      if (without.length >= (config?.rules?.maxSelections || 20)) return cur;
      return [...without, sel];
    });
  }, [config, slip]); // eslint-disable-line react-hooks/exhaustive-deps
  const removeSelection = useCallback((k) => setSlip((cur) => cur.filter((s) => selKey(s) !== k)), []);
  const updateSelections = useCallback((fn) => setSlip((cur) => fn(cur)), []);
  const clearSlip = useCallback(() => setSlip([]), []);
  const inSlip = useCallback((matchId, market, selection) => slip.some((s) => s.matchId === matchId && s.market === market && s.selection === selection), [slip]);

  const value = useMemo(() => ({
    config, user, setUser, refreshUser, logout, toast, toasts,
    slip, toggleSelection, removeSelection, updateSelections, clearSlip, inSlip,
    slipOpen, setSlipOpen, depositOpen, setDepositOpen, sessionStart, startSession,
  }), [config, user, refreshUser, logout, toast, toasts, slip, toggleSelection, removeSelection, updateSelections, clearSlip, inSlip, slipOpen, depositOpen, sessionStart, startSession]);

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
