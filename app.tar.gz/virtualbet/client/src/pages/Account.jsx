import { useEffect, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { usePolling, useNow } from '../lib/hooks.js';
import { Link, navigate, useLocation } from '../lib/router.jsx';
import { cleanAmount, dateTime, duration, signed, money, toPence, TX_LABELS } from '../lib/format.js';
import { DailyBonusButton } from '../components/DepositModal.jsx';
import { ErrorBox, Loading, Modal, Spinner, StatTile, Tabs } from '../components/ui.jsx';
import { LoginPrompt } from './MyBets.jsx';
import { LifetimeTotals } from './Progress.jsx';

function Profile() {
  const { user, setUser, toast, logout } = useApp();
  const [name, setName] = useState(user.username);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const save = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const d = await api.patch('/api/me', { username: name.trim() });
      setUser(d.user);
      toast('Username updated', 'success');
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <section className="card p-4">
        <h2 className="mb-3 text-sm font-bold text-white">Profile</h2>
        <dl className="mb-4 grid grid-cols-2 gap-3 text-sm">
          <div><dt className="text-xs text-slate-500">Username</dt><dd className="font-semibold text-white">{user.username}</dd></div>
          <div><dt className="text-xs text-slate-500">Member since</dt><dd className="text-white">{dateTime(user.createdAt)}</dd></div>
          <div><dt className="text-xs text-slate-500">Virtual balance</dt><dd className="font-semibold text-white tabular-nums">{money(user.balance)}</dd></div>
          <div><dt className="text-xs text-slate-500">Account type</dt><dd className="text-white">Virtual play only</dd></div>
        </dl>
        <form onSubmit={save} className="space-y-2">
          <label className="label" htmlFor="uname">Change username</label>
          <div className="flex gap-2">
            <input id="uname" className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={20} />
            <button className="btn-primary" disabled={busy || name.trim() === user.username}>{busy ? <Spinner className="h-4 w-4" /> : 'Save'}</button>
          </div>
          <p className="text-xs text-slate-500">3–20 characters: letters, numbers and underscores.</p>
          {error && <p className="text-sm text-red-400">{error}</p>}
        </form>
      </section>
      <section className="card flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="text-sm text-slate-300">Quick links: <Link to="/my-bets" className="text-brand-400 underline">My bets</Link> · <Link to="/history" className="text-brand-400 underline">Bet history</Link> · <Link to="/history?tab=stats" className="text-brand-400 underline">Statistics</Link> · <Link to="/achievements" className="text-brand-400 underline">Badges</Link></div>
        <button className="btn-ghost" onClick={async () => { await logout(); navigate('/'); }}>Log out</button>
      </section>
    </div>
  );
}

function Wallet() {
  const { user, setDepositOpen } = useApp();
  const [extra, setExtra] = useState([]);
  const [more, setMore] = useState(true);
  const { data, loading, error, reload } = usePolling('/api/wallet', 10000, [user.balance]);
  useEffect(() => { setExtra([]); setMore(true); }, [user.balance]);
  const txs = [...(data?.transactions || []), ...extra];
  const loadMore = async () => {
    const last = txs[txs.length - 1];
    if (!last) return;
    const d = await api.get(`/api/wallet?before=${last.id}`);
    setExtra((e) => [...e, ...d.transactions]);
    if (d.transactions.length < 50) setMore(false);
  };
  return (
    <div className="space-y-4">
      <section className="card flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">Virtual balance</div>
          <div className="text-3xl font-extrabold text-white tabular-nums">{money(user.balance)}</div>
          <div className="text-xs text-slate-500">It has no real value and cannot be withdrawn, exchanged or transferred.</div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn-primary" onClick={() => setDepositOpen(true)}>Deposit (free, virtual)</button>
          <DailyBonusButton />
        </div>
      </section>
      <section className="card overflow-hidden">
        <h2 className="border-b border-navy-700 px-4 py-3 text-sm font-bold text-white">Transaction history</h2>
        {loading && !data ? <Loading /> : error && !data ? <ErrorBox error={error} onRetry={reload} /> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] text-sm">
              <thead className="bg-navy-800 text-left text-[11px] uppercase tracking-wider text-slate-400">
                <tr><th className="px-3 py-2">Date</th><th className="px-3 py-2">Type</th><th className="px-3 py-2 text-right">Amount</th><th className="px-3 py-2 text-right">Previous balance</th><th className="px-3 py-2 text-right">New balance</th></tr>
              </thead>
              <tbody className="divide-y divide-navy-700">
                {txs.map((t) => (
                  <tr key={t.id}>
                    <td className="whitespace-nowrap px-3 py-2 text-xs text-slate-400">{dateTime(t.createdAt)}</td>
                    <td className="px-3 py-2">
                      <div className="font-medium text-slate-100">{TX_LABELS[t.type] || t.type}</div>
                      {(t.reference || t.note) && <div className="text-xs text-slate-500">{t.reference && <span className="font-mono">{t.reference} </span>}{t.note}</div>}
                    </td>
                    <td className={`px-3 py-2 text-right font-bold tabular-nums ${t.amount > 0 ? 'text-brand-400' : t.amount < 0 ? 'text-red-400' : 'text-slate-300'}`}>{signed(t.amount)}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-slate-400">{money(t.balanceBefore)}</td>
                    <td className="px-3 py-2 text-right font-semibold tabular-nums text-white">{money(t.balanceAfter)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {more && txs.length >= 50 && <div className="p-3 text-center"><button className="btn-ghost" onClick={loadMore}>Load older transactions</button></div>}
          </div>
        )}
      </section>
    </div>
  );
}

function PlaySafely() {
  const { user, setUser, toast, sessionStart } = useApp();
  const now = useNow(1000);
  const stats = usePolling(`/api/stats?sessionStart=${sessionStart}`, 15000);
  const [limit, setLimit] = useState(user.dailyStakeLimit != null ? String(user.dailyStakeLimit / 100) : '');
  const [busy, setBusy] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [breakHours, setBreakHours] = useState(null);
  const s = stats.data?.stats;
  const startBreak = async () => {
    setBusy(true);
    try {
      const d = await api.put('/api/settings', { takeBreakHours: breakHours });
      setUser(d.user);
      setBreakHours(null);
      toast('Break started. Take care.', 'success');
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  const saveLimit = async (value) => {
    setBusy(true);
    try {
      const d = await api.put('/api/settings', { dailyStakeLimit: value });
      setUser(d.user);
      toast(d.limitResult?.applied ? 'Daily limit saved' : 'Limit change scheduled - it takes effect after 24 hours', 'success');
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const saveReality = async (m) => {
    try {
      const d = await api.put('/api/settings', { realityCheckMinutes: m });
      setUser(d.user);
      toast('Reality check updated', 'success');
    } catch (e) { toast(e.message, 'error'); }
  };
  const reset = async () => {
    setBusy(true);
    try {
      const d = await api.post('/api/wallet/reset', { confirm: true });
      setUser(d.user);
      setResetOpen(false);
      toast('Wallet reset to £100.00', 'success');
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const tone = (v) => (v > 0 ? 'pos' : v < 0 ? 'neg' : null);

  return (
    <div className="space-y-4">
      <section>
        <h2 className="mb-2 text-sm font-bold text-white">Profit / loss tracker</h2>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <StatTile label="Session time" value={duration(now - sessionStart)} />
          <StatTile label="This session" value={signed(stats.data?.session?.p ?? 0)} tone={tone(stats.data?.session?.p)} />
          <StatTile label="Today" value={s ? signed(s.profitToday) : '–'} tone={tone(s?.profitToday)} />
          <StatTile label="All time" value={s ? signed(s.profit) : '–'} tone={tone(s?.profit)} />
        </div>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Daily stake limit</h2>
        <p className="text-xs text-slate-400">Caps the total you can stake in any rolling 24 hours. Lowering a limit applies immediately; raising or removing it only takes effect after a 24-hour cooling-off period.</p>
        <div className="text-sm text-slate-300">
          Current limit: <b className="text-white">{user.dailyStakeLimit != null ? money(user.dailyStakeLimit) : 'None'}</b>
          {user.dailyStakeLimit != null && <span className="text-slate-500"> · {money(user.stakedLast24h)} staked in the last 24h</span>}
        </div>
        {user.pendingStakeLimit != null && (
          <div className="rounded bg-gold-500/10 px-3 py-2 text-xs text-gold-400">
            Pending change to {user.pendingStakeLimit === 'none' ? 'no limit' : money(user.pendingStakeLimit)} from {dateTime(user.pendingLimitAt)}
          </div>
        )}
        <form className="flex flex-wrap gap-2" onSubmit={(e) => { e.preventDefault(); const v = toPence(limit); if (v) saveLimit(v); }}>
          <div className="relative max-w-[180px]"><span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">£</span><input id="daily-limit" className="input pl-7" type="text" inputMode="decimal" placeholder="e.g. 20" value={limit} onChange={(e) => setLimit(cleanAmount(e.target.value))} /></div>
          <button className="btn-primary" disabled={busy || !toPence(limit)}>Set limit</button>
          {user.dailyStakeLimit != null && <button type="button" className="btn-ghost" disabled={busy} onClick={() => saveLimit(null)}>Remove limit</button>}
        </form>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Reality check</h2>
        <p className="text-xs text-slate-400">Shows a reminder of how long you've been playing and your session P/L.</p>
        <div className="flex flex-wrap gap-2">
          {[0, 15, 30, 60, 90, 120].map((m) => (
            <button key={m} className={`chip ${user.realityCheckMinutes === m ? 'chip-active' : ''}`} onClick={() => saveReality(m)}>{m ? `Every ${m} min` : 'Off'}</button>
          ))}
        </div>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Take a break</h2>
        {user.breakUntil ? (
          <p className="rounded bg-sky-500/10 px-3 py-2 text-sm text-sky-200">You're on a break until <b>{dateTime(user.breakUntil)}</b>. Bets and games are paused, and the break can't be ended early.</p>
        ) : (
          <>
            <p className="text-xs text-slate-400">Pause all betting and casino games for a while. You can still look around, and open bets settle normally. Once started, a break can't be cancelled early.</p>
            <div className="flex flex-wrap gap-2">
              {[[24, '24 hours'], [72, '3 days'], [168, '1 week'], [720, '30 days']].map(([h, l]) => <button key={h} className="chip" onClick={() => setBreakHours(h)}>{l}</button>)}
            </div>
          </>
        )}
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Reset virtual wallet</h2>
        <p className="text-xs text-slate-400">Sets your virtual balance back to £100.00. Your bet history and statistics are kept, and any open bets still settle normally.</p>
        <button className="btn-danger" onClick={() => setResetOpen(true)}>Reset wallet</button>
      </section>

      <section className="rounded-lg border border-navy-700 bg-navy-900 p-4 text-xs leading-relaxed text-slate-400">
        <p className="mb-1 font-bold text-slate-300">Need support with real-money gambling?</p>
        In the UK, the National Gambling Helpline is free and confidential: call <b className="text-slate-200">0808 8020 133</b> (24/7) or visit{' '}
        <a href="https://www.gamcare.org.uk" target="_blank" rel="noreferrer" className="text-brand-400 underline">GamCare</a>, which runs the helpline and live chat.{' '}
        <a href="https://www.gamstop.co.uk" target="_blank" rel="noreferrer" className="text-brand-400 underline">GAMSTOP</a> lets you self-exclude from all UK-licensed gambling sites at once.
      </section>

      <Modal open={!!breakHours} onClose={() => setBreakHours(null)} title="Start a break?">
        <p className="text-sm text-slate-300">Betting and all casino games will be paused for <b>{{ 24: '24 hours', 72: '3 days', 168: '1 week', 720: '30 days' }[breakHours]}</b>. You won't be able to end the break early.</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn-ghost" onClick={() => setBreakHours(null)}>Cancel</button>
          <button className="btn-primary" disabled={busy} onClick={startBreak}>Start break</button>
        </div>
      </Modal>

      <Modal open={resetOpen} onClose={() => setResetOpen(false)} title="Reset wallet?">
        <p className="text-sm text-slate-300">Your virtual balance will be set to <b>£100.00</b> (currently {money(user.balance)}). This is recorded in your transaction history.</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn-ghost" onClick={() => setResetOpen(false)}>Cancel</button>
          <button className="btn-danger" disabled={busy} onClick={reset}>Reset</button>
        </div>
      </Modal>
    </div>
  );
}

export default function Account() {
  const { user } = useApp();
  const { query } = useLocation();
  const tab = query.get('tab') || 'profile';
  if (user === null) return <LoginPrompt what="your account" />;
  if (!user) return <Loading />;
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold text-white">Account</h1>
      <Tabs tabs={[{ value: 'profile', label: 'Profile' }, { value: 'wallet', label: 'Wallet' }, { value: 'totals', label: 'Real-money check' }, { value: 'safety', label: 'Play safely' }]} value={tab} onChange={(t) => navigate(`/account?tab=${t}`)} />
      {tab === 'wallet' ? <Wallet /> : tab === 'totals' ? <LifetimeTotals /> : tab === 'safety' ? <PlaySafely /> : <Profile />}
    </div>
  );
}
