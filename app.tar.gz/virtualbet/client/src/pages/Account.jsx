import { useEffect, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { usePolling, useNow } from '../lib/hooks.js';
import { Link, navigate, useLocation } from '../lib/router.jsx';
import { cleanAmount, dateTime, duration, signed, money, toPence, TX_LABELS } from '../lib/format.js';
import { DailyBonusButton } from '../components/DepositModal.jsx';
import { ErrorBox, Icon, Loading, Modal, Spinner, StatTile } from '../components/ui.jsx';
import { useFavourites } from '../lib/favs.jsx';
import { currentSubscription, disablePush, enablePush, isInstalled, isIOS, pushStatus } from '../lib/push.js';
import { LoginPrompt } from './MyBets.jsx';
import { LifetimeTotals } from './Progress.jsx';

function Profile() {
  const { user, setUser, toast } = useApp();
  const [name, setName] = useState(user.username);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const save = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const d = await api.patch('/api/me', { username: name.trim() });
      setUser(d.user);
      toast('Username updated', 'success');
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <section className="card p-4">
        <h2 className="mb-3 text-sm font-bold text-white">Profile</h2>
        <dl className="mb-4 grid grid-cols-2 gap-3 text-sm">
          <div><dt className="text-xs text-slate-500">Username</dt><dd className="font-semibold text-white">{user.username}</dd></div>
          <div><dt className="text-xs text-slate-500">Member since</dt><dd className="text-white">{dateTime(user.createdAt)}</dd></div>
          <div><dt className="text-xs text-slate-500">Virtual balance</dt><dd className="font-semibold text-white tabular-nums">{money(user.balance)}</dd></div>
          <div><dt className="text-xs text-slate-500">Account type</dt><dd className="text-white">Virtual play only</dd></div>
        </dl>
        <form onSubmit={save} className="space-y-2">
          <label className="label" htmlFor="uname">Change username</label>
          <div className="flex gap-2">
            <input id="uname" className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={20} />
            <button className="btn-primary" disabled={busy || name.trim() === user.username}>{busy ? <Spinner className="h-4 w-4" /> : 'Save'}</button>
          </div>
          <p className="text-xs text-slate-500">3–20 characters: letters, numbers and underscores.</p>
          {error && <p className="text-sm text-red-400">{error}</p>}
        </form>
      </section>
    </div>
  );
}

function Wallet() {
  const { user, setDepositOpen } = useApp();
  const [extra, setExtra] = useState([]);
  const [more, setMore] = useState(true);
  const { data, loading, error, reload } = usePolling('/api/wallet', 10000, [user.balance]);
  useEffect(() => { setExtra([]); setMore(true); }, [user.balance]);
  const txs = [...(data?.transactions || []), ...extra];
  const loadMore = async () => {
    const last = txs[txs.length - 1];
    if (!last) return;
    const d = await api.get(`/api/wallet?before=${last.id}`);
    setExtra((e) => [...e, ...d.transactions]);
    if (d.transactions.length < 50) setMore(false);
  };
  return (
    <div className="space-y-4">
      <section className="card flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">Virtual balance</div>
          <div className="text-3xl font-extrabold text-white tabular-nums">{money(user.balance)}</div>
          <div className="text-xs text-slate-500">It has no real value and cannot be withdrawn, exchanged or transferred.</div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn-primary" onClick={() => setDepositOpen(true)}>Deposit (free, virtual)</button>
          <DailyBonusButton />
        </div>
      </section>
      <section className="card overflow-hidden">
        <h2 className="border-b border-navy-700 px-4 py-3 text-sm font-bold text-white">Transaction history</h2>
        {loading && !data ? <Loading /> : error && !data ? <ErrorBox error={error} onRetry={reload} /> : (
          <div>
            <ul className="divide-y divide-navy-700 md:hidden">
              {txs.map((t) => (
                <li key={t.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium text-slate-100">{TX_LABELS[t.type] || t.type}</div>
                    <div className="truncate text-xs text-slate-500">{dateTime(t.createdAt)}{t.reference ? ` · ${t.reference}` : ''}</div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className={`text-sm font-bold tabular-nums ${t.amount > 0 ? 'text-brand-400' : t.amount < 0 ? 'text-red-400' : 'text-slate-300'}`}>{signed(t.amount)}</div>
                    <div className="text-[11px] text-slate-500 tabular-nums">{money(t.balanceAfter)}</div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="hidden overflow-x-auto md:block">
            <table className="w-full min-w-[620px] text-sm">
              <thead className="bg-navy-800 text-left text-[11px] uppercase tracking-wider text-slate-400">
                <tr><th className="px-3 py-2">Date</th><th className="px-3 py-2">Type</th><th className="px-3 py-2 text-right">Amount</th><th className="px-3 py-2 text-right">Previous balance</th><th className="px-3 py-2 text-right">New balance</th></tr>
              </thead>
              <tbody className="divide-y divide-navy-700">
                {txs.map((t) => (
                  <tr key={t.id}>
                    <td className="whitespace-nowrap px-3 py-2 text-xs text-slate-400">{dateTime(t.createdAt)}</td>
                    <td className="px-3 py-2">
                      <div className="font-medium text-slate-100">{TX_LABELS[t.type] || t.type}</div>
                      {(t.reference || t.note) && <div className="text-xs text-slate-500">{t.reference && <span className="font-mono">{t.reference} </span>}{t.note}</div>}
                    </td>
                    <td className={`px-3 py-2 text-right font-bold tabular-nums ${t.amount > 0 ? 'text-brand-400' : t.amount < 0 ? 'text-red-400' : 'text-slate-300'}`}>{signed(t.amount)}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-slate-400">{money(t.balanceBefore)}</td>
                    <td className="px-3 py-2 text-right font-semibold tabular-nums text-white">{money(t.balanceAfter)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
            {more && txs.length >= 50 && <div className="p-3 text-center"><button className="btn-ghost" onClick={loadMore}>Load older transactions</button></div>}
          </div>
        )}
      </section>
    </div>
  );
}

function PlaySafely() {
  const { user, setUser, toast, sessionStart } = useApp();
  const now = useNow(1000);
  const stats = usePolling(`/api/stats?sessionStart=${sessionStart}`, 15000);
  const [limit, setLimit] = useState(user.dailyStakeLimit != null ? String(user.dailyStakeLimit / 100) : '');
  const [busy, setBusy] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [breakHours, setBreakHours] = useState(null);
  const s = stats.data?.stats;
  const startBreak = async () => {
    setBusy(true);
    try {
      const d = await api.put('/api/settings', { takeBreakHours: breakHours });
      setUser(d.user);
      setBreakHours(null);
      toast('Break started. Take care.', 'success');
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  const saveLimit = async (value) => {
    setBusy(true);
    try {
      const d = await api.put('/api/settings', { dailyStakeLimit: value });
      setUser(d.user);
      toast(d.limitResult?.applied ? 'Daily limit saved' : 'Limit change scheduled - it takes effect after 24 hours', 'success');
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const saveReality = async (m) => {
    try {
      const d = await api.put('/api/settings', { realityCheckMinutes: m });
      setUser(d.user);
      toast('Reality check updated', 'success');
    } catch (e) { toast(e.message, 'error'); }
  };
  const reset = async () => {
    setBusy(true);
    try {
      const d = await api.post('/api/wallet/reset', { confirm: true });
      setUser(d.user);
      setResetOpen(false);
      toast('Wallet reset to £100.00', 'success');
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const tone = (v) => (v > 0 ? 'pos' : v < 0 ? 'neg' : null);

  return (
    <div className="space-y-4">
      <section>
        <h2 className="mb-2 text-sm font-bold text-white">Profit / loss tracker</h2>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <StatTile label="Session time" value={duration(now - sessionStart)} />
          <StatTile label="This session" value={signed(stats.data?.session?.p ?? 0)} tone={tone(stats.data?.session?.p)} />
          <StatTile label="Today" value={s ? signed(s.profitToday) : '–'} tone={tone(s?.profitToday)} />
          <StatTile label="All time" value={s ? signed(s.profit) : '–'} tone={tone(s?.profit)} />
        </div>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Daily stake limit</h2>
        <p className="text-xs text-slate-400">Caps the total you can stake in any rolling 24 hours. Lowering a limit applies immediately; raising or removing it only takes effect after a 24-hour cooling-off period.</p>
        <div className="text-sm text-slate-300">
          Current limit: <b className="text-white">{user.dailyStakeLimit != null ? money(user.dailyStakeLimit) : 'None'}</b>
          {user.dailyStakeLimit != null && <span className="text-slate-500"> · {money(user.stakedLast24h)} staked in the last 24h</span>}
        </div>
        {user.pendingStakeLimit != null && (
          <div className="rounded bg-gold-500/10 px-3 py-2 text-xs text-gold-400">
            Pending change to {user.pendingStakeLimit === 'none' ? 'no limit' : money(user.pendingStakeLimit)} from {dateTime(user.pendingLimitAt)}
          </div>
        )}
        <form className="flex flex-wrap gap-2" onSubmit={(e) => { e.preventDefault(); const v = toPence(limit); if (v) saveLimit(v); }}>
          <div className="relative max-w-[180px]"><span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">£</span><input id="daily-limit" className="input pl-7" type="text" inputMode="decimal" placeholder="e.g. 20" value={limit} onChange={(e) => setLimit(cleanAmount(e.target.value))} /></div>
          <button className="btn-primary" disabled={busy || !toPence(limit)}>Set limit</button>
          {user.dailyStakeLimit != null && <button type="button" className="btn-ghost" disabled={busy} onClick={() => saveLimit(null)}>Remove limit</button>}
        </form>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Reality check</h2>
        <p className="text-xs text-slate-400">Shows a reminder of how long you've been playing and your session P/L.</p>
        <div className="flex flex-wrap gap-2">
          {[0, 15, 30, 60, 90, 120].map((m) => (
            <button key={m} className={`chip ${user.realityCheckMinutes === m ? 'chip-active' : ''}`} onClick={() => saveReality(m)}>{m ? `Every ${m} min` : 'Off'}</button>
          ))}
        </div>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Take a break</h2>
        {user.breakUntil ? (
          <p className="rounded bg-sky-500/10 px-3 py-2 text-sm text-sky-200">You're on a break until <b>{dateTime(user.breakUntil)}</b>. Bets and games are paused, and the break can't be ended early.</p>
        ) : (
          <>
            <p className="text-xs text-slate-400">Pause all betting and casino games for a while. You can still look around, and open bets settle normally. Once started, a break can't be cancelled early.</p>
            <div className="flex flex-wrap gap-2">
              {[[24, '24 hours'], [72, '3 days'], [168, '1 week'], [720, '30 days']].map(([h, l]) => <button key={h} className="chip" onClick={() => setBreakHours(h)}>{l}</button>)}
            </div>
          </>
        )}
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="text-sm font-bold text-white">Reset virtual wallet</h2>
        <p className="text-xs text-slate-400">Sets your virtual balance back to £100.00. Your bet history and statistics are kept, and any open bets still settle normally.</p>
        <button className="btn-danger" onClick={() => setResetOpen(true)}>Reset wallet</button>
      </section>

      <section className="rounded-lg border border-navy-700 bg-navy-900 p-4 text-xs leading-relaxed text-slate-400">
        <p className="mb-1 font-bold text-slate-300">Need support with real-money gambling?</p>
        In the UK, the National Gambling Helpline is free and confidential: call <b className="text-slate-200">0808 8020 133</b> (24/7) or visit{' '}
        <a href="https://www.gamcare.org.uk" target="_blank" rel="noreferrer" className="text-brand-400 underline">GamCare</a>, which runs the helpline and live chat.{' '}
        <a href="https://www.gamstop.co.uk" target="_blank" rel="noreferrer" className="text-brand-400 underline">GAMSTOP</a> lets you self-exclude from all UK-licensed gambling sites at once.
      </section>

      <Modal open={!!breakHours} onClose={() => setBreakHours(null)} title="Start a break?">
        <p className="text-sm text-slate-300">Betting and all casino games will be paused for <b>{{ 24: '24 hours', 72: '3 days', 168: '1 week', 720: '30 days' }[breakHours]}</b>. You won't be able to end the break early.</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn-ghost" onClick={() => setBreakHours(null)}>Cancel</button>
          <button className="btn-primary" disabled={busy} onClick={startBreak}>Start break</button>
        </div>
      </Modal>

      <Modal open={resetOpen} onClose={() => setResetOpen(false)} title="Reset wallet?">
        <p className="text-sm text-slate-300">Your virtual balance will be set to <b>£100.00</b> (currently {money(user.balance)}). This is recorded in your transaction history.</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn-ghost" onClick={() => setResetOpen(false)}>Cancel</button>
          <button className="btn-danger" disabled={busy} onClick={reset}>Reset</button>
        </div>
      </Modal>
    </div>
  );
}

// ── Settings hub (iOS-style grouped list) ─────────────────────
function Group({ title, children, footer }) {
  return (
    <section>
      {title && <h2 className="mb-1.5 px-1 text-[11px] font-bold uppercase tracking-wider text-slate-500">{title}</h2>}
      <div className="card divide-y divide-navy-700/80 overflow-hidden rounded-2xl">{children}</div>
      {footer && <p className="mt-1.5 px-1 text-[11px] leading-snug text-slate-500">{footer}</p>}
    </section>
  );
}

const ICON_BG = { green: 'bg-brand-500/15 text-brand-400', gold: 'bg-gold-500/15 text-gold-400', sky: 'bg-sky-500/15 text-sky-300', violet: 'bg-violet-500/15 text-violet-300', red: 'bg-red-500/15 text-red-300', slate: 'bg-navy-700 text-slate-300' };
function Row({ to, onClick, icon, tone = 'slate', label, value, danger, right, chevron = true }) {
  const inner = (
    <>
      {icon && <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${ICON_BG[tone]}`}>{icon}</span>}
      <span className={`min-w-0 flex-1 truncate text-[15px] font-medium ${danger ? 'text-red-400' : 'text-slate-100'}`}>{label}</span>
      {value != null && <span className="shrink-0 truncate text-sm text-slate-400 tabular-nums">{value}</span>}
      {right}
      {chevron && (to || onClick) && !right && <Icon.chevron className="h-5 w-5 shrink-0 text-slate-600" />}
    </>
  );
  const cls = 'flex min-h-[52px] w-full items-center gap-3 px-4 py-2 text-left active:bg-navy-800';
  if (to) return <Link to={to} className={cls}>{inner}</Link>;
  if (onClick) return <button type="button" onClick={onClick} className={cls}>{inner}</button>;
  return <div className={cls}>{inner}</div>;
}

function Switch({ on, onChange, disabled, label }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled} onClick={() => onChange(!on)}
      className={`relative h-[31px] w-[51px] shrink-0 rounded-full transition-colors disabled:opacity-50 ${on ? 'bg-brand-500' : 'bg-navy-600'}`}>
      <span className={`absolute left-0 top-[2px] h-[27px] w-[27px] rounded-full bg-white shadow transition-transform ${on ? 'translate-x-[22px]' : 'translate-x-[2px]'}`} />
    </button>
  );
}

const svg = (d) => (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-[18px] w-[18px]" aria-hidden="true" {...p}>{d}</svg>;
const I = {
  wallet: svg(<><rect x="3" y="6" width="18" height="14" rx="2" /><path d="M16 13h2M3 10h18M7 6V4h10v2" /></>),
  plus: svg(<path d="M12 5v14M5 12h14" />),
  bets: svg(<><path d="M6 3h9l4 4v14H6z" /><path d="M9 11h7M9 15h7" /></>),
  history: svg(<><path d="M3 12a9 9 0 109-9 9 9 0 00-6.4 2.6L3 8" /><path d="M3 3v5h5M12 7v5l3 2" /></>),
  chart: svg(<path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />),
  badge: svg(<><circle cx="12" cy="9" r="6" /><path d="M8.5 14L7 22l5-3 5 3-1.5-8" /></>),
  trophy: svg(<><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0z" /><path d="M17 5h3v2a3 3 0 01-3 3M7 5H4v2a3 3 0 003 3" /></>),
  star: svg(<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z" />),
  bell: svg(<><path d="M6 8a6 6 0 0112 0c0 7 3 8 3 8H3s3-1 3-8" /><path d="M10.3 21a1.9 1.9 0 003.4 0" /></>),
  shield: svg(<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" />),
  scale: svg(<><path d="M12 3v18M5 21h14M5 7h14M5 7l-3 7a3 3 0 006 0zM19 7l-3 7a3 3 0 006 0z" /></>),
  user: svg(<><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0116 0" /></>),
  phone: svg(<><rect x="6" y="2" width="12" height="20" rx="3" /><path d="M11 18h2" /></>),
  out: svg(<><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4M10 17l5-5-5-5M15 12H3" /></>),
};

function NotificationsGroup() {
  const { user, setUser, toast } = useApp();
  const [status] = useState(pushStatus);
  const [sub, setSub] = useState(null);
  const [busy, setBusy] = useState(false);
  const [help, setHelp] = useState(false);
  useEffect(() => { currentSubscription().then(setSub).catch(() => {}); }, []);
  const on = !!sub && user.notifySettled !== false;
  const toggle = async (want) => {
    if (status === 'install' || status === 'unsupported') { setHelp(true); return; }
    setBusy(true);
    try {
      const u = want ? await enablePush() : await disablePush();
      if (u) setUser(u);
      setSub(await currentSubscription());
      toast(want ? 'You\'ll get a notification when bets settle' : 'Bet notifications turned off on this device', 'success');
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const test = async () => {
    try { const r = await api.post('/api/push/test'); toast(r.sent ? 'Test notification sent' : 'The notification service did not accept it - try turning notifications off and on', r.sent ? 'success' : 'error'); } catch (e) { toast(e.message, 'error'); }
  };
  const footer = status === 'install' ? 'On iPhone, add VirtualBet to your Home Screen first (Share > Add to Home Screen), then open it from there to turn this on.'
    : status === 'blocked' ? 'Notifications are blocked for VirtualBet. Allow them in your phone or browser settings.'
      : status === 'unsupported' ? 'Notifications are not available in this browser.'
        : 'Get a notification on this device when a bet wins, loses or is made void.';
  return (
    <>
      <Group title="Notifications" footer={footer}>
        <Row icon={<I.bell />} tone="gold" label="Bet results" right={busy ? <Spinner className="h-5 w-5" /> : <Switch on={on} onChange={toggle} disabled={status === 'blocked'} label="Bet result notifications" />} />
        {on && <Row onClick={test} icon={<I.bell />} tone="slate" label="Send a test notification" />}
      </Group>
      <Modal open={help} onClose={() => setHelp(false)} title="Turn on notifications">
        {status === 'install' ? (
          <ol className="list-decimal space-y-2 pl-5 text-sm text-slate-300">
            <li>Tap the <b>Share</b> button in Safari.</li>
            <li>Choose <b>Add to Home Screen</b>, then <b>Add</b>.</li>
            <li>Open VirtualBet from its new icon, go to <b>Account</b> and turn on <b>Bet results</b>.</li>
          </ol>
        ) : <p className="text-sm text-slate-300">This browser can't show web notifications. Try Safari on iPhone (added to the Home Screen) or Chrome.</p>}
        <button className="btn-primary mt-4 h-11 w-full rounded-xl" onClick={() => setHelp(false)}>OK</button>
      </Modal>
    </>
  );
}

function FavouriteTeams() {
  const { favs, toggle } = useFavourites();
  return (
    <div className="space-y-3">
      <p className="px-1 text-sm text-slate-400">Fixtures for teams you follow appear on your home screen. Follow a team from any match page.</p>
      {favs.length ? (
        <div className="card divide-y divide-navy-700/80 overflow-hidden rounded-2xl">
          {favs.map((n) => (
            <div key={n} className="flex min-h-[52px] items-center gap-3 px-4">
              <span className="flex-1 truncate text-[15px] text-slate-100">{n}</span>
              <button className="h-9 rounded-lg px-3 text-sm font-semibold text-red-400 active:bg-navy-800" onClick={() => toggle(n)}>Unfollow</button>
            </div>
          ))}
        </div>
      ) : <div className="card rounded-2xl px-4 py-6 text-center text-sm text-slate-400">You're not following any teams yet. <Link to="/upcoming" className="text-brand-400">Browse fixtures</Link></div>}
    </div>
  );
}

function InstallHelp({ open, onClose }) {
  return (
    <Modal open={open} onClose={onClose} title="Install VirtualBet">
      {isIOS() ? (
        <ol className="list-decimal space-y-2 pl-5 text-sm text-slate-300">
          <li>In Safari, tap the <b>Share</b> button (the square with an arrow).</li>
          <li>Scroll down and tap <b>Add to Home Screen</b>.</li>
          <li>Tap <b>Add</b>. VirtualBet opens full screen from its own icon.</li>
        </ol>
      ) : (
        <p className="text-sm text-slate-300">In Chrome, open the menu (⋮) and choose <b>Install app</b> or <b>Add to Home screen</b>.</p>
      )}
      <button className="btn-primary mt-4 h-11 w-full rounded-xl" onClick={onClose}>Got it</button>
    </Modal>
  );
}

function Hub() {
  const { user, logout, setDepositOpen } = useApp();
  const [install, setInstall] = useState(false);
  const [confirmOut, setConfirmOut] = useState(false);
  const installed = typeof window !== 'undefined' && (isInstalled() || window.__VB_STANDALONE__);
  return (
    <div className="space-y-5">
      <section className="flex items-center gap-3.5 px-1">
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-400 to-brand-700 text-2xl font-extrabold uppercase text-navy-950">{user.username[0]}</span>
        <div className="min-w-0">
          <div className="truncate text-xl font-extrabold text-white">{user.username}</div>
          <div className="text-xs text-slate-400">Member since {new Date(user.createdAt).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })} · virtual play only</div>
        </div>
      </section>

      <Group title="Wallet" footer="Virtual money has no cash value and can't be withdrawn or transferred.">
        <Row to="/account?tab=wallet" icon={<I.wallet />} tone="green" label="Balance & transactions" value={money(user.balance)} />
        <Row onClick={() => setDepositOpen(true)} icon={<I.plus />} tone="green" label="Add virtual funds" />
      </Group>

      <Group title="Your betting">
        <Row to="/my-bets" icon={<I.bets />} tone="sky" label="My bets" value={user.openBets ? `${user.openBets} open` : null} />
        <Row to="/history" icon={<I.history />} tone="sky" label="Bet history" />
        <Row to="/history?tab=stats" icon={<I.chart />} tone="sky" label="Statistics" />
        <Row to="/account?tab=teams" icon={<I.star />} tone="gold" label="Favourite teams" value={user.favourites?.length ? user.favourites.length : null} />
        <Row to="/achievements" icon={<I.badge />} tone="violet" label="Badges" />
        <Row to="/leaderboard" icon={<I.trophy />} tone="violet" label="Leaderboard" />
      </Group>

      <NotificationsGroup />

      <Group title="Play safely">
        <Row to="/account?tab=safety" icon={<I.shield />} tone="green" label="Limits, breaks & reality check" value={user.dailyStakeLimit != null ? `${money(user.dailyStakeLimit)}/day` : null} />
        <Row to="/account?tab=totals" icon={<I.scale />} tone="gold" label="Real-money check" />
      </Group>

      <Group title="Account">
        <Row to="/account?tab=profile" icon={<I.user />} tone="slate" label="Profile & username" />
        {!installed && <Row onClick={() => setInstall(true)} icon={<I.phone />} tone="slate" label="Install on your phone" />}
        <Row onClick={() => setConfirmOut(true)} icon={<I.out />} tone="red" label="Log out" danger chevron={false} />
      </Group>

      <InstallHelp open={install} onClose={() => setInstall(false)} />
      <Modal open={confirmOut} onClose={() => setConfirmOut(false)} title="Log out?">
        <p className="text-sm text-slate-300">Your bets, balance and settings are saved to your account.</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn-ghost h-11 rounded-xl" onClick={() => setConfirmOut(false)}>Cancel</button>
          <button className="btn-danger h-11 rounded-xl" onClick={async () => { setConfirmOut(false); await logout(); navigate('/'); }}>Log out</button>
        </div>
      </Modal>
    </div>
  );
}

const SUB = { wallet: 'Wallet', totals: 'Real-money check', safety: 'Play safely', profile: 'Profile', teams: 'Favourite teams' };

export default function Account() {
  const { user } = useApp();
  const { query } = useLocation();
  const tab = query.get('tab');
  if (user === null) return <LoginPrompt what="your account" />;
  if (!user) return <Loading />;
  if (!SUB[tab]) return <Hub />;
  return (
    <div className="space-y-3">
      <Link to="/account" replace className="-ml-1 inline-flex h-9 items-center gap-0.5 pr-2 text-sm font-semibold text-brand-400"><Icon.chevron className="h-5 w-5 rotate-180" />Account</Link>
      <h1 className="text-xl font-extrabold text-white">{SUB[tab]}</h1>
      {tab === 'wallet' ? <Wallet /> : tab === 'totals' ? <LifetimeTotals /> : tab === 'safety' ? <PlaySafely /> : tab === 'teams' ? <FavouriteTeams /> : <Profile />}
    </div>
  );
}
