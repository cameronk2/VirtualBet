import { useEffect, useRef, useState } from 'react';
import GameShell, { StakePicker, useGame } from '../components/GameShell.jsx';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import WinCelebration from '../components/WinCelebration.jsx';
import { PLINKO, PLINKO_ROWS } from '../../../server/games/instant.js';

const STAKES = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000];
const ROW_MS = 150;
const W = 340, TOP = 24, DY = 24, DX = 24;
const H = TOP + PLINKO_ROWS * DY + 40;
const slotColour = (m) => (m >= 10 ? '#f43f5e' : m >= 3 ? '#fb923c' : m >= 1.5 ? '#facc15' : m >= 1 ? '#a3e635' : '#38bdf8');

export default function Plinko() {
  const { history, busy, play, commit } = useGame('plinko');
  const [stake, setStake] = useState(100);
  const [risk, setRisk] = useState('medium');
  const [balls, setBalls] = useState([]); // { id, path, start, slot, mult, payout }
  const [lastHit, setLastHit] = useState(null);
  const [big, setBig] = useState(null);
  const [now, setNow] = useState(0);
  const raf = useRef(0);
  const id = useRef(0);

  useEffect(() => {
    if (!balls.length) return undefined;
    const loop = () => { setNow(performance.now()); raf.current = requestAnimationFrame(loop); };
    raf.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf.current);
  }, [balls.length]);

  // Ball position: x moves half a peg per row, with a small bounce arc
  const pos = (b) => {
    const t = (now - b.start) / ROW_MS;
    const row = Math.min(PLINKO_ROWS, Math.max(0, t));
    const i = Math.floor(row), f = row - i;
    const rights = b.path.slice(0, i).reduce((a, x) => a + x, 0);
    const x0 = (rights - i / 2) * DX;
    const x1 = i < PLINKO_ROWS ? x0 + (b.path[i] ? DX / 2 : -DX / 2) : x0;
    const x = x0 + (x1 - x0) * f;
    const y = TOP - 14 + row * DY - Math.sin(f * Math.PI) * 6;
    return { x: W / 2 + x, y };
  };

  useEffect(() => {
    const landed = balls.filter((b) => now - b.start >= PLINKO_ROWS * ROW_MS + 60 && !b.done);
    if (!landed.length) return;
    landed.forEach((b) => { b.done = true; setLastHit({ slot: b.slot, mult: b.mult, payout: b.payout, key: b.id }); if (b.mult >= 10) setBig({ amount: b.payout, bet: Math.round(b.payout / b.mult) }); else if (b.mult >= 1) sfx.win(); else sfx.stop(1); });
    commit();
    setBalls((bs) => bs.filter((b) => now - b.start < PLINKO_ROWS * ROW_MS + 400));
  }, [now]); // eslint-disable-line react-hooks/exhaustive-deps

  const drop = async () => {
    if (balls.length >= 10) return;
    const out = await play('drop', { stake, risk });
    if (!out) return;
    sfx.chip();
    setBalls((bs) => [...bs, { id: ++id.current, path: out.path, slot: out.slot, mult: out.mult, payout: out.payout, start: performance.now() }]);
  };

  const mults = PLINKO[risk];
  return (
    <GameShell title="Plinko" subtitle="Drop the ball through 12 rows of pegs" rtp="97%" history={history}
      rules={<>
        <p>Each drop bounces left or right at every peg with equal chance, so it usually lands near the middle. The slot it lands in multiplies your stake.</p>
        <p>Low risk: 0.5x to 10x. Medium: 0.3x to 33x. High: 0.2x to 170x. All three return about 97% over the long run; higher risk just means bigger, rarer wins and more small losses.</p>
        <p className="text-slate-500">The edge slots are reached about once in every 4,096 drops each. Up to 10 balls can be in play at once.</p>
      </>}>
      <section className="relative overflow-hidden rounded-2xl bg-[radial-gradient(ellipse_at_top,#4a044e_0%,#1e0b2e_55%,#0b1520_100%)] p-3 ring-1 ring-fuchsia-950">
        {big && <WinCelebration game="plinko" amount={big.amount} bet={big.bet} onDone={() => setBig(null)} className="absolute inset-0 z-30 rounded-2xl" />}
        <svg viewBox={`0 0 ${W} ${H}`} className="mx-auto h-auto w-full max-w-md" aria-label="Plinko board">
          {Array.from({ length: PLINKO_ROWS }, (_, r) => Array.from({ length: r + 3 }, (_, c) => (
            <circle key={`${r}-${c}`} cx={W / 2 + (c - (r + 2) / 2) * DX} cy={TOP + r * DY} r="3" fill="#f5d0fe" opacity=".85" />
          )))}
          {mults.map((m, k) => {
            const x = W / 2 + (k - PLINKO_ROWS / 2) * DX;
            const hit = lastHit && lastHit.slot === k;
            return (
              <g key={`${k}-${hit ? lastHit.key : 0}`} className={hit ? 'animate-symbol-pop' : ''} style={{ transformOrigin: `${x}px ${TOP + PLINKO_ROWS * DY + 12}px` }}>
                <rect x={x - DX / 2 + 1.5} y={TOP + PLINKO_ROWS * DY} width={DX - 3} height="22" rx="4" fill={slotColour(m)} opacity={hit ? 1 : 0.85} />
                <text x={x} y={TOP + PLINKO_ROWS * DY + 15} textAnchor="middle" fontSize={String(m).length >= 4 ? 6.5 : String(m).length === 3 ? 7.5 : 8.5} fontWeight="900" fill="#0b1520" fontFamily="system-ui">{m < 1 ? String(m).replace(/^0/, '') : m}x</text>
              </g>
            );
          })}
          {balls.map((b) => { const p = pos(b); return <circle key={b.id} cx={p.x} cy={p.y} r="6" fill="#fbcfe8" stroke="#fff" strokeWidth="1.5" style={{ filter: 'drop-shadow(0 0 6px rgba(244,114,182,0.9))' }} />; })}
        </svg>
        <div className="mt-1 flex min-h-8 items-center justify-center">
          {lastHit && <div key={lastHit.key} className={`animate-fade-in font-cond text-2xl font-extrabold ${lastHit.mult >= 1 ? 'text-gold-400' : 'text-slate-300'}`}>{lastHit.mult}x · {money(lastHit.payout)}</div>}
        </div>
      </section>

      <div className="card flex flex-wrap items-center gap-3 p-3">
        <StakePicker value={stake} onChange={setStake} options={STAKES} />
        <div className="flex gap-1 rounded-lg bg-navy-800 p-1">
          {['low', 'medium', 'high'].map((r) => <button key={r} onClick={() => setRisk(r)} className={`rounded-md px-3 py-1.5 text-sm font-bold capitalize ${risk === r ? 'bg-fuchsia-500 text-white' : 'text-slate-300'}`}>{r}</button>)}
        </div>
        <button className="btn ml-auto h-14 min-w-36 rounded-full bg-fuchsia-500 text-lg font-extrabold text-white hover:bg-fuchsia-400" disabled={busy || balls.length >= 10} onClick={drop}>Drop · {money(stake)}</button>
      </div>
    </GameShell>
  );
}
