import { useMemo } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { Link, navigate, useLocation } from '../lib/router.jsx';
import { usePolling } from '../lib/hooks.js';
import { money, signed } from '../lib/format.js';
import { CATALOGUE } from '../../../server/games/registry.js';
import { LOBBY_ART3, Logo3, SlotDefs3 } from '../components/SlotArt3.jsx';

// Small original emblems for each game tile
const ART = {
  lakeside: (
    <g><circle cx="50" cy="38" r="16" fill="#fde68a" opacity=".9" /><path d="M10 62c10-6 20 6 30 0s20 6 30 0 20 6 30 0v38H10z" fill="#0c4a6e" opacity=".85" />
      <path d="M38 70c8-8 22-8 30 0-8 8-22 8-30 0z" fill="#84cc16" stroke="#1a2e05" strokeWidth="2" /><path d="M68 70l9-7v14z" fill="#4d7c0f" /><circle cx="44" cy="68" r="1.8" fill="#111" /></g>
  ),
  nebula: (
    <g>{[[30, 30, '#f43f5e'], [52, 26, '#a855f7'], [72, 40, '#38bdf8'], [40, 54, '#facc15'], [62, 62, '#22c55e'], [28, 72, '#fb923c']].map(([x, y, c], i) => (
      <polygon key={i} points={`${x},${y - 11} ${x + 10},${y} ${x},${y + 11} ${x - 10},${y}`} fill={c} stroke="#fff" strokeOpacity=".7" strokeWidth="1.5" />))}
      <circle cx="80" cy="18" r="2" fill="#fff" /><circle cx="18" cy="48" r="1.5" fill="#fff" /></g>
  ),
  vault: (
    <g><circle cx="50" cy="50" r="30" fill="#78350f" stroke="#fbbf24" strokeWidth="4" /><circle cx="50" cy="50" r="20" fill="#fbbf24" stroke="#92400e" strokeWidth="3" />
      <text x="50" y="57" textAnchor="middle" fontSize="20" fontWeight="900" fill="#78350f" fontFamily="system-ui">£</text>
      {[0, 60, 120, 180, 240, 300].map((a) => <rect key={a} x="48" y="14" width="4" height="8" fill="#fbbf24" transform={`rotate(${a} 50 50)`} />)}</g>
  ),
  starlight: (
    <g><circle cx="66" cy="32" r="14" fill="#e2e8f0" /><circle cx="61" cy="28" r="14" fill="#1e1b4b" />
      <path d="M24 76l26-30 6 5-26 30z" fill="#cbd5e1" stroke="#0f172a" strokeWidth="2" /><path d="M30 84l8-10M40 84l-6-8" stroke="#cbd5e1" strokeWidth="3" />
      {[[20, 22], [40, 14], [84, 60], [78, 80]].map(([x, y], i) => <path key={i} d={`M${x} ${y - 5}l1.5 3.5 3.5 1.5-3.5 1.5-1.5 3.5-1.5-3.5-3.5-1.5 3.5-1.5z`} fill="#fde68a" />)}</g>
  ),
  fruit: (
    <g><path d="M44 30c4 14 14 22 18 30M56 30c-4 10-14 18-20 30" stroke="#15803d" strokeWidth="3" fill="none" /><path d="M46 26c6-6 14-4 18 2-8 2-12 2-18-2z" fill="#22c55e" />
      <circle cx="36" cy="66" r="13" fill="#dc2626" stroke="#7f1d1d" strokeWidth="2" /><circle cx="64" cy="66" r="13" fill="#dc2626" stroke="#7f1d1d" strokeWidth="2" />
      <circle cx="32" cy="61" r="3" fill="#fecaca" /><circle cx="60" cy="61" r="3" fill="#fecaca" /></g>
  ),
  blackjack: (
    <g><rect x="22" y="22" width="34" height="48" rx="4" fill="#fff" transform="rotate(-12 39 46)" /><rect x="44" y="26" width="34" height="48" rx="4" fill="#fff" transform="rotate(10 61 50)" />
      <text x="34" y="44" fontSize="14" fontWeight="900" fill="#0b1520" transform="rotate(-12 39 46)">A</text><text x="58" y="48" fontSize="14" fontWeight="900" fill="#dc2626" transform="rotate(10 61 50)">K</text>
      <text x="58" y="66" fontSize="16" fill="#dc2626" transform="rotate(10 61 50)">♥</text><text x="31" y="62" fontSize="16" fill="#0b1520" transform="rotate(-12 39 46)">♠</text></g>
  ),
  spin21: (
    <g>{Array.from({ length: 12 }, (_, i) => <path key={i} d="M50 50L50 18A32 32 0 0 1 66 22.3z" fill={['#facc15', '#0e7490', '#ec4899', '#155e75', '#7c3aed', '#0e7490'][i % 6]} transform={`rotate(${i * 30} 50 50)`} />)}
      <circle cx="50" cy="50" r="32" fill="none" stroke="#facc15" strokeWidth="3" /><circle cx="50" cy="50" r="10" fill="#0b1520" stroke="#facc15" strokeWidth="2" /><path d="M50 12l-5-8h10z" fill="#fff" /></g>
  ),
  roulette: (
    <g>{Array.from({ length: 18 }, (_, i) => <path key={i} d="M50 50L50 16A34 34 0 0 1 61.6 18z" fill={i === 0 ? '#16a34a' : i % 2 ? '#111827' : '#dc2626'} transform={`rotate(${i * 20} 50 50)`} />)}
      <circle cx="50" cy="50" r="34" fill="none" stroke="#b45309" strokeWidth="4" /><circle cx="50" cy="50" r="16" fill="#92400e" stroke="#fbbf24" strokeWidth="2" /><circle cx="50" cy="24" r="4" fill="#fff" /></g>
  ),
  baccarat: (
    <g><rect x="16" y="30" width="30" height="42" rx="4" fill="#fff" /><rect x="54" y="30" width="30" height="42" rx="4" fill="#fff" />
      <text x="31" y="58" textAnchor="middle" fontSize="18" fontWeight="900" fill="#1d4ed8">9</text><text x="69" y="58" textAnchor="middle" fontSize="18" fontWeight="900" fill="#dc2626">8</text>
      <text x="31" y="86" textAnchor="middle" fontSize="8" fontWeight="800" fill="#bfdbfe">PLAYER</text><text x="69" y="86" textAnchor="middle" fontSize="8" fontWeight="800" fill="#fecaca">BANKER</text></g>
  ),
  threecard: (
    <g>{[-16, 0, 16].map((r, i) => <rect key={i} x="36" y="22" width="28" height="42" rx="4" fill="#fff" stroke="#0f172a" strokeWidth="1" transform={`rotate(${r} 50 80)`} />)}
      <text x="50" y="50" textAnchor="middle" fontSize="16" fill="#0b1520">♣</text><text x="50" y="86" textAnchor="middle" fontSize="9" fontWeight="800" fill="#99f6e4">3 CARD</text></g>
  ),
  crash: (
    <g><path d="M12 84C40 82 60 66 82 20" stroke="#a3e635" strokeWidth="4" fill="none" strokeLinecap="round" />
      <path d="M78 16l10-4-3 10z" fill="#fff" /><text x="18" y="40" fontSize="18" fontWeight="900" fill="#ecfccb" fontFamily="system-ui">2.4x</text></g>
  ),
  plinko: (
    <g>{Array.from({ length: 5 }, (_, r) => Array.from({ length: r + 2 }, (_, c) => <circle key={`${r}${c}`} cx={50 - (r + 1) * 7 + c * 14} cy={22 + r * 13} r="2.5" fill="#fff" opacity=".8" />))}
      <circle cx="53" cy="16" r="5" fill="#f472b6" stroke="#fff" strokeWidth="1.5" />
      {['#f43f5e', '#fb923c', '#facc15', '#fb923c', '#f43f5e'].map((c, i) => <rect key={i} x={17 + i * 14} y="86" width="12" height="7" rx="2" fill={c} />)}</g>
  ),
  scratch: (
    <g><rect x="18" y="20" width="64" height="60" rx="6" fill="#fef9c3" stroke="#a16207" strokeWidth="2" />
      {[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={24 + c * 19} y={26 + r * 17} width="15" height="13" rx="2" fill={r === 1 && c === 2 ? '#fde68a' : '#a3a3a3'} />))}
      <text x="70.5" y="57" textAnchor="middle" fontSize="8" fontWeight="900" fill="#78350f">£5</text></g>
  ),
};

function Tile({ g, stats }) {
  return (
    <Link to={g.path} className={`group relative flex aspect-[4/5] flex-col overflow-hidden rounded-2xl bg-gradient-to-br ${g.hue} p-3 shadow-lg ring-1 ring-white/10 transition-transform duration-200 hover:-translate-y-1 hover:ring-white/30`}>
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.25),transparent_55%)]" />
      <svg viewBox="0 0 100 100" className="relative mx-auto h-[58%] w-auto drop-shadow-[0_6px_10px_rgba(0,0,0,0.45)] transition-transform duration-300 group-hover:scale-105" aria-hidden="true">{ART[g.id] || LOBBY_ART3[g.id]}</svg>
      {g.isNew && <span className="absolute right-2 top-2 rounded-full bg-gold-400 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-navy-950 shadow">New</span>}
      <div className="relative mt-auto">
        <div className="font-cond text-lg font-extrabold uppercase leading-none text-white drop-shadow sm:text-xl">{g.name}</div>
        <div className="mt-0.5 line-clamp-1 text-[11px] text-white/75">{g.tag}</div>
        <div className="mt-1.5 flex items-center justify-between text-[10px] font-semibold">
          <span className="rounded-full bg-black/30 px-2 py-0.5 text-white/80">RTP {g.rtp}</span>
          {stats && <span className={stats > 0 ? 'text-brand-300' : 'text-white/60'}>{signed(stats)}</span>}
        </div>
      </div>
    </Link>
  );
}

function Featured({ g }) {
  return (
    <Link to={g.path} className={`group relative flex w-72 shrink-0 flex-col overflow-hidden rounded-2xl bg-gradient-to-br ${g.hue} p-3 shadow-xl ring-1 ring-white/15 transition-transform duration-200 hover:-translate-y-1 sm:w-80`}>
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_80%_10%,rgba(255,255,255,0.22),transparent_55%)]" />
      <div className="relative flex items-center gap-2">
        <svg viewBox="0 0 100 100" className="h-24 w-24 shrink-0 drop-shadow-[0_6px_10px_rgba(0,0,0,0.5)] transition-transform duration-300 group-hover:scale-110" aria-hidden="true">{LOBBY_ART3[g.id]}</svg>
        <div className="min-w-0"><Logo3 game={g.id} className="h-12 w-full" /><div className="mt-1 text-[11px] text-white/80">{g.desc}</div></div>
      </div>
      <div className="relative mt-2 flex items-center justify-between gap-2">
        <div className="min-w-0"><div className="line-clamp-1 text-xs font-semibold text-white/90">{g.tag}</div><div className="text-[10px] text-white/60">RTP {g.rtp} · up to {g.id === 'moonridge' ? '5,666' : g.id === 'mummy' ? '2,118' : g.id === 'brick' ? '5,500' : g.id === 'stampede' ? '5,000' : g.id === 'chicken' ? '10,000' : g.id === 'mines' ? '5,044,291' : g.id === 'keno' ? '100,000' : g.id === 'genie' ? '10,000' : '5,000'}x</div></div>
        <span className="shrink-0 rounded-full bg-white px-4 py-1.5 text-sm font-extrabold text-navy-950 shadow transition-transform group-hover:scale-105">Play</span>
      </div>
    </Link>
  );
}

const CATS = [['all', 'All games'], ['slots', 'Slots'], ['tables', 'Table games'], ['instant', 'Instant wins']];

export default function Casino() {
  const { user } = useApp();
  const { query } = useLocation();
  const cat = query.get('cat') || 'all';
  const { data: life } = usePolling(user ? '/api/lifetime' : null, 30000, [user?.id]);
  const byId = useMemo(() => Object.fromEntries((life?.products || []).map((p) => [p.id, p.net])), [life]);
  const games = CATALOGUE.filter((g) => cat === 'all' || g.cat === cat);
  const played = CATALOGUE.filter((g) => byId[g.id] !== undefined);

  return (
    <div className="space-y-5">
      <SlotDefs3 />
      <section className="relative overflow-hidden rounded-3xl bg-[linear-gradient(120deg,#4c1d95_0%,#1e1b4b_45%,#082f49_100%)] p-5 ring-1 ring-white/10 sm:p-8">
        <div className="pointer-events-none absolute -right-10 -top-10 h-56 w-56 rounded-full bg-fuchsia-500/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-16 left-1/3 h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="relative max-w-xl">
          <div className="text-[11px] font-bold uppercase tracking-[0.25em] text-fuchsia-200/80">VirtualBet Casino</div>
          <h1 className="mt-1 font-cond text-4xl font-extrabold uppercase italic leading-[0.95] text-white sm:text-5xl">{CATALOGUE.length} games.<br /><span className="text-gold-400">Zero real money.</span></h1>
          <p className="mt-2 text-sm text-white/75">Slots, table games and instant wins, all playing from one balance. Every game shows its long-run return, so you can see the house edge for yourself.</p>
          {user && <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-black/30 px-3 py-1.5 text-sm text-white">Balance <b className="font-cond text-lg tabular-nums">{money(user.balance)}</b></div>}
        </div>
      </section>

      <div className="scrollbar-none -mx-1 flex gap-2 overflow-x-auto px-1">
        {CATS.map(([k, label]) => (
          <button key={k} onClick={() => navigate(k === 'all' ? '/casino' : `/casino?cat=${k}`)} className={`chip px-4 py-1.5 text-sm ${cat === k ? 'chip-active' : ''}`}>{label}</button>
        ))}
      </div>

      {(cat === 'all' || cat === 'slots') && (
        <section>
          <h2 className="mb-2 flex items-center gap-2 font-cond text-lg font-bold uppercase text-white"><span className="rounded bg-gold-400 px-1.5 text-xs text-navy-950">New</span>Premium slots</h2>
          <div className="scrollbar-none -mx-3 flex gap-3 overflow-x-auto px-3 pb-2 sm:mx-0 sm:px-0">
            {CATALOGUE.filter((g) => g.isNew).map((g) => <Featured key={g.id} g={g} />)}
          </div>
        </section>
      )}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {games.map((g) => <Tile key={g.id} g={g} stats={byId[g.id]} />)}
      </div>

      {user && played.length > 0 && cat === 'all' && (
        <section className="card p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-cond text-lg font-bold uppercase text-white">Your casino so far</h2>
            <Link to="/account?tab=totals" className="text-xs font-semibold text-brand-400">Full breakdown ›</Link>
          </div>
          <p className="mb-3 text-xs text-slate-400">Net result per game since you started.</p>
          <div className="grid gap-1.5 sm:grid-cols-2">
            {played.map((g) => (
              <div key={g.id} className="flex items-center justify-between rounded-lg bg-navy-800 px-3 py-2 text-sm">
                <span className="text-slate-200">{g.name}</span>
                <span className={`font-bold tabular-nums ${byId[g.id] > 0 ? 'text-brand-400' : byId[g.id] < 0 ? 'text-red-400' : 'text-slate-300'}`}>{signed(byId[g.id])}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
