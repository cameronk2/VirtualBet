import { useEffect, useRef, useState } from 'react';
import GameShell, { StakePicker, STAKES, useGame } from '../components/GameShell.jsx';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import WinCelebration from '../components/WinCelebration.jsx';
import { CRASH_RATE } from '../../../server/games/instant.js';

const multAt = (ms) => Math.exp((CRASH_RATE * Math.max(0, ms)) / 1000);

export default function Crash() {
  const { view, history, busy, play, commit } = useGame('crash');
  const [stake, setStake] = useState(100);
  const [auto, setAuto] = useState('');
  const [round, setRound] = useState(null); // { startAt, offset }
  const [mult, setMult] = useState(1);
  const [result, setResult] = useState(null);
  const [big, setBig] = useState(null);
  const [points, setPoints] = useState([]);
  const raf = useRef(0);
  const tick = useRef(0);
  const running = !!round;

  // Resume a round that was in progress when the page was opened
  useEffect(() => {
    if (view?.round && !round && !result) setRound({ startAt: view.round.startAt, offset: Date.now() - view.round.now, auto: view.round.auto });
  }, [view]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!round) return undefined;
    const draw = () => {
      const t = Date.now() - round.offset - round.startAt;
      const m = t < 0 ? 1 : multAt(t);
      setMult(m);
      if (t >= 0) setPoints((p) => (p.length && Date.now() - p[p.length - 1].at < 80 ? p : [...p, { t, m, at: Date.now() }]));
      raf.current = requestAnimationFrame(draw);
    };
    raf.current = requestAnimationFrame(draw);
    const finish = (out) => {
      cancelAnimationFrame(raf.current);
      clearInterval(tick.current);
      setRound(null);
      setResult(out);
      setMult(out.cashedAt || out.crashedAt);
      commit();
      if (out.cashedAt >= 10) setBig({ amount: out.payout, bet: out.stake }); else if (out.cashedAt) sfx.win(); else sfx.lose();
    };
    tick.current = setInterval(async () => {
      const out = await play('tick', {}, { quiet: true, silent: true });
      if (out?.done) finish(out);
    }, 250);
    round.finish = finish;
    return () => { cancelAnimationFrame(raf.current); clearInterval(tick.current); };
  }, [round]); // eslint-disable-line react-hooks/exhaustive-deps

  const start = async () => {
    setResult(null); setPoints([]); setMult(1);
    const a = auto ? Number(auto) : null;
    const out = await play('start', { stake, auto: a });
    if (out?.started) { sfx.spin(); setRound({ startAt: out.startAt, offset: Date.now() - out.now, auto: out.auto }); }
  };
  const cashout = async () => {
    const out = await play('cashout', {}, { silent: true });
    if (out?.done && round?.finish) round.finish(out);
  };

  // Graph scaled to the current flight
  const maxT = Math.max(8000, ...points.map((p) => p.t));
  const maxM = Math.max(2, mult * 1.15);
  const W = 400, H = 200;
  const xy = (p) => `${(p.t / maxT) * W},${H - ((p.m - 1) / (maxM - 1)) * H}`;
  const path = points.length ? `M0,${H} L${points.map(xy).join(' L')}` : '';
  const last = points[points.length - 1];
  const crashed = result && !result.cashedAt;
  const waiting = running && Date.now() - round.offset < round.startAt;
  const recent = view?.recent || [];

  return (
    <GameShell title="Crash" subtitle="Cash out before the rocket crashes" rtp="97%" history={history}
      rules={<>
        <p>Place your stake and watch the multiplier climb from 1.00x. Cash out any time to win your stake times the multiplier. If the rocket crashes before you cash out, you lose the stake.</p>
        <p>Set an auto cash-out to bank automatically when that multiplier is reached. The crash point is decided when the round starts, and is fair: there's a 97% ÷ M chance of reaching M (for example about 48.5% for 2x and 9.7% for 10x).</p>
        <p className="text-slate-500">About 3% of rounds crash instantly at 1.00x. The house edge is 3% whatever you do; waiting longer only changes how often and how much you win.</p>
      </>}>
      <section className={`relative overflow-hidden rounded-2xl p-4 ring-1 transition-colors ${crashed ? 'bg-[linear-gradient(180deg,#450a0a,#0b1520)] ring-red-900' : 'bg-[linear-gradient(180deg,#052e16,#0b1520)] ring-emerald-900'}`}>
        {big && <WinCelebration game="crash" amount={big.amount} bet={big.bet} onDone={() => setBig(null)} className="absolute inset-0 z-30 rounded-2xl" />}
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(transparent_95%,rgba(255,255,255,0.04)_95%),linear-gradient(90deg,transparent_95%,rgba(255,255,255,0.04)_95%)] bg-[length:100%_40px,40px_100%]" />
        <svg viewBox={`0 0 ${W} ${H}`} className="relative h-56 w-full" preserveAspectRatio="none" aria-hidden="true">
          <defs><linearGradient id="crashfill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={crashed ? '#ef4444' : '#a3e635'} stopOpacity=".35" /><stop offset="1" stopColor={crashed ? '#ef4444' : '#a3e635'} stopOpacity="0" /></linearGradient></defs>
          {path && <path d={`${path} L${last ? (last.t / maxT) * W : 0},${H} Z`} fill="url(#crashfill)" />}
          {path && <path d={path} fill="none" stroke={crashed ? '#ef4444' : '#a3e635'} strokeWidth="3" vectorEffect="non-scaling-stroke" strokeLinejoin="round" />}
        </svg>
        {!running && !result && (
          <svg width="34" height="34" viewBox="0 0 26 26" className="pointer-events-none absolute bottom-3 left-3" aria-hidden="true"><path d="M13 2c5 4 6 10 4 16H9C7 12 8 6 13 2z" fill="#f8fafc" /><circle cx="13" cy="10" r="2.5" fill="#38bdf8" /><path d="M9 18l-3 4h4zM17 18l3 4h-4z" fill="#f97316" /></svg>
        )}
        {last && !crashed && (
          <div className="pointer-events-none absolute" style={{ left: `calc(${(last.t / maxT) * 100}% - 4px)`, top: `calc(${(1 - (last.m - 1) / (maxM - 1)) * 224}px + 2px)` }}>
            <svg width="26" height="26" viewBox="0 0 26 26" className="-translate-x-1/2 -translate-y-1/2 -rotate-45"><path d="M13 2c5 4 6 10 4 16H9C7 12 8 6 13 2z" fill="#f8fafc" /><circle cx="13" cy="10" r="2.5" fill="#38bdf8" /><path d="M9 18l-3 4h4zM17 18l3 4h-4z" fill="#f97316" /><path d="M11 18h4l-2 6z" fill="#facc15" /></svg>
          </div>
        )}
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <div className={`font-cond text-6xl font-extrabold tabular-nums drop-shadow-lg ${crashed ? 'text-red-400' : result?.cashedAt ? 'text-gold-400' : 'text-white'}`}>{waiting ? 'Ready…' : `${mult.toFixed(2)}x`}</div>
          {result && <div className="animate-fade-in mt-1 rounded-full bg-black/50 px-4 py-1 text-sm font-semibold text-white">{result.cashedAt ? `Cashed out at ${result.cashedAt.toFixed(2)}x · +${money(result.payout)}` : `Crashed at ${result.crashedAt.toFixed(2)}x`}</div>}
          {running && !waiting && <div className="mt-1 text-sm text-white/80">Cash out now: {money(Math.floor(stake * mult))}</div>}
          {!running && !result && <div className="mt-1 text-sm text-white/60">Set a stake, optionally an auto cash-out, then launch</div>}
        </div>
      </section>

      <div className="scrollbar-none flex gap-1 overflow-x-auto">
        {recent.map((m, i) => <span key={i} className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-bold tabular-nums ${m >= 10 ? 'bg-gold-500/20 text-gold-400' : m >= 2 ? 'bg-brand-500/15 text-brand-400' : 'bg-red-500/15 text-red-300'}`}>{m.toFixed(2)}x</span>)}
      </div>

      <div className="card flex flex-wrap items-center gap-3 p-3">
        <StakePicker value={stake} onChange={setStake} options={STAKES} disabled={running} />
        <label className="flex items-center gap-2 text-sm text-slate-300">Auto cash-out
          <input type="text" inputMode="decimal" placeholder="off" value={auto} disabled={running} onChange={(e) => setAuto(e.target.value.replace(/[^\d.]/g, '').slice(0, 7))} className="input h-10 w-20 text-right" />x
        </label>
        <div className="flex gap-1" role="group" aria-label="Auto cash-out presets">
          {['', '1.5', '2', '5', '10'].map((v) => <button key={v || 'off'} disabled={running} onClick={() => setAuto(v)} className={`rounded-md px-2 py-1 text-xs font-bold ${auto === v ? 'bg-brand-500 text-navy-950' : 'bg-navy-700 text-slate-300'}`}>{v ? `${v}x` : 'Off'}</button>)}
        </div>
        {running ? (
          <button className="btn ml-auto h-14 min-w-44 rounded-full bg-gold-500 text-lg font-extrabold text-navy-950 hover:bg-gold-400" disabled={waiting} onClick={cashout}>{waiting ? 'Starting…' : `Cash out ${money(Math.floor(stake * mult))}`}</button>
        ) : (
          <button className="btn-primary ml-auto h-14 min-w-44 rounded-full text-lg" disabled={busy} onClick={start}>Launch · {money(stake)}</button>
        )}
      </div>
    </GameShell>
  );
}
