import { useApp } from '../state/AppContext.jsx';
import { usePolling } from '../lib/hooks.js';
import { Link } from '../lib/router.jsx';
import { dateTime, money, signed } from '../lib/format.js';
import { ErrorBox, Loading } from '../components/ui.jsx';
import { LoginPrompt } from './MyBets.jsx';

const GROUP_HUE = { Sports: 'from-emerald-500 to-teal-700', Tables: 'from-rose-500 to-red-800', Slots: 'from-amber-400 to-orange-700', Instant: 'from-fuchsia-500 to-purple-800', Explorer: 'from-sky-400 to-indigo-700', 'Play safely': 'from-lime-400 to-green-700' };

function Badge({ a }) {
  const on = !!a.unlockedAt;
  return (
    <div className={`relative flex items-center gap-3 rounded-xl border p-3 ${on ? 'border-gold-500/40 bg-navy-800' : 'border-navy-700/70 bg-navy-900/60'}`}>
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br shadow-inner ${on ? GROUP_HUE[a.group] : 'from-navy-700 to-navy-800 grayscale'}`}>
        <svg viewBox="0 0 24 24" className={`h-6 w-6 ${on ? 'text-white' : 'text-navy-500'}`} fill="currentColor" aria-hidden="true">
          {on ? <path d="M12 2l2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 17l-6.1 3.4 1.5-6.8L2.2 9l6.9-.7z" /> : <path d="M17 10V8a5 5 0 00-10 0v2H5v12h14V10h-2zm-8 0V8a3 3 0 016 0v2H9z" />}
        </svg>
      </div>
      <div className="min-w-0">
        <div className={`font-cond text-base font-bold leading-tight ${on ? 'text-white' : 'text-slate-400'}`}>{a.name}</div>
        <div className="text-xs text-slate-400">{a.desc}</div>
        {on && <div className="mt-0.5 text-[10px] text-gold-400">Earned {dateTime(a.unlockedAt)}</div>}
      </div>
    </div>
  );
}

export function Achievements() {
  const { user } = useApp();
  const { data, error } = usePolling(user ? '/api/achievements' : null, 0, [user?.id]);
  if (user === null) return <LoginPrompt what="your badges" />;
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const list = data.achievements;
  const got = list.filter((a) => a.unlockedAt).length;
  const groups = [...new Set(list.map((a) => a.group))];
  return (
    <div className="space-y-4">
      <section className="card overflow-hidden">
        <div className="bg-[radial-gradient(ellipse_at_top_left,#854d0e_0%,#1e293b_60%)] p-4">
          <h1 className="font-display text-2xl tracking-wide text-white">Badges</h1>
          <p className="mt-1 text-sm text-slate-300">{got} of {list.length} earned · {data.played} games tried</p>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-black/40"><div className="h-full rounded-full bg-gradient-to-r from-gold-400 to-amber-600" style={{ width: `${(got / list.length) * 100}%` }} /></div>
        </div>
        <p className="border-t border-navy-700 px-4 py-2.5 text-xs text-slate-400">Badges are just for fun. They carry no prizes or bonuses, and there are no streaks or daily targets, so there's never a reason to play more to keep one.</p>
      </section>
      {groups.map((g) => (
        <section key={g}>
          <h2 className="section-title mb-2">{g}</h2>
          <div className="grid gap-2 sm:grid-cols-2">{list.filter((a) => a.group === g).map((a) => <Badge key={a.id} a={a} />)}</div>
        </section>
      ))}
    </div>
  );
}

/** "What this would have cost": lifetime staked vs returned, per product. */
export function LifetimeTotals({ compact }) {
  const { user } = useApp();
  const { data, error } = usePolling(user ? '/api/lifetime' : null, compact ? 30000 : 0, [user?.id]);
  if (!user) return null;
  if (error) return compact ? null : <ErrorBox error={error} />;
  if (!data) return compact ? null : <Loading />;
  const neg = data.net < 0;
  if (compact) {
    if (!data.staked) return null;
    return (
      <Link to="/account?tab=totals" className="card block p-4 hover:border-navy-600">
        <div className="flex items-center justify-between"><h2 className="section-title">If this had been real money</h2><span className="text-xs font-semibold text-brand-400">Details ›</span></div>
        <div className="mt-2 grid grid-cols-3 gap-2 text-center">
          <div><div className="text-[11px] uppercase text-slate-500">Staked</div><div className="font-cond text-xl font-bold text-white tabular-nums">{money(data.staked)}</div></div>
          <div><div className="text-[11px] uppercase text-slate-500">Returned</div><div className="font-cond text-xl font-bold text-white tabular-nums">{money(data.returned)}</div></div>
          <div><div className="text-[11px] uppercase text-slate-500">{neg ? 'You’d be down' : 'You’d be up'}</div><div className={`font-cond text-xl font-bold tabular-nums ${neg ? 'text-red-400' : 'text-brand-400'}`}>{money(Math.abs(data.net))}</div></div>
        </div>
      </Link>
    );
  }
  const max = Math.max(1, ...data.products.map((p) => p.staked));
  return (
    <div className="space-y-4">
      <section className="card p-4">
        <h2 className="text-sm font-bold text-white">What this would have cost</h2>
        <p className="mt-1 text-sm text-slate-400">Everything you've staked and won{data.since ? ` since ${dateTime(data.since)}` : ''}. Deposits, bonuses and wallet resets aren't counted.</p>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <div className="rounded-lg bg-navy-850 p-3"><div className="text-[11px] uppercase text-slate-500">Total staked</div><div className="font-cond text-xl font-bold whitespace-nowrap sm:text-2xl text-white tabular-nums">{money(data.staked)}</div></div>
          <div className="rounded-lg bg-navy-850 p-3"><div className="text-[11px] uppercase text-slate-500">Total returned</div><div className="font-cond text-xl font-bold whitespace-nowrap sm:text-2xl text-white tabular-nums">{money(data.returned)}</div></div>
          <div className="rounded-lg bg-navy-850 p-3"><div className="text-[11px] uppercase text-slate-500">Net</div><div className={`font-cond text-xl font-bold whitespace-nowrap sm:text-2xl tabular-nums ${neg ? 'text-red-400' : 'text-brand-400'}`}>{signed(data.net)}</div></div>
        </div>
        {data.staked > 0 && (
          <p className={`mt-3 rounded-lg p-3 text-sm ${neg ? 'bg-red-500/10 text-red-200' : 'bg-brand-500/10 text-brand-200'}`}>
            {neg ? <>With real money you would be <b>{money(-data.net)}</b> worse off, about <b>{Math.round((-data.net / data.staked) * 100)}p</b> lost for every £1 staked.</>
              : <>You're ahead for now. Every game here has a built-in house edge, so over enough play the total tends to drift below zero.</>}
          </p>
        )}
      </section>
      <section className="card divide-y divide-navy-700/70">
        {data.products.length === 0 && <div className="p-4 text-sm text-slate-400">Nothing staked yet.</div>}
        {data.products.map((p) => (
          <div key={p.id} className="p-3">
            <div className="flex items-baseline justify-between gap-2"><span className="font-semibold text-white">{p.name}</span><span className={`font-cond text-lg font-bold tabular-nums ${p.net < 0 ? 'text-red-400' : 'text-brand-400'}`}>{signed(p.net)}</span></div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-navy-800"><div className="h-full rounded-full bg-slate-500" style={{ width: `${(p.staked / max) * 100}%` }} /></div>
            <div className="mt-1 text-xs text-slate-500">Staked {money(p.staked)} · returned {money(p.returned)}</div>
          </div>
        ))}
      </section>
    </div>
  );
}
