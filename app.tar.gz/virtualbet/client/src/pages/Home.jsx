import { useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { Link } from '../lib/router.jsx';
import { usePolling } from '../lib/hooks.js';
import { dateTime, dayLabel, kickoffTime, odds, pct, signed, money } from '../lib/format.js';
import { MatchList } from '../components/MatchRow.jsx';
import Crest from '../components/Crest.jsx';
import OddsButton from '../components/OddsButton.jsx';
import { DailyBonusButton } from '../components/DepositModal.jsx';
import { CATALOGUE } from '../../../server/games/catalogue.js';
import { LifetimeTotals } from './Progress.jsx';
import { Empty, ErrorBox, Icon, LiveBadge, SimBadge, Skeleton, StatTile, StatusBadge } from '../components/ui.jsx';
import { useFavourites } from '../lib/favs.jsx';

function SectionHeader({ title, to, linkLabel = 'View all', live }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <h2 className="section-title">{live && <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" />}{title}</h2>
      {to && <Link to={to} className="flex items-center text-xs font-semibold text-brand-400 hover:text-brand-300">{linkLabel}<Icon.chevron className="h-4 w-4" /></Link>}
    </div>
  );
}

function FeaturedCard({ m }) {
  const mk = m.quick['1X2'];
  return (
    <div className="card w-[82vw] max-w-[300px] shrink-0 overflow-hidden rounded-2xl sm:w-auto sm:max-w-none">
      <Link to={`/match/${encodeURIComponent(m.id)}`} className="block bg-gradient-to-br from-navy-700 to-navy-800 p-3 hover:from-navy-600">
        <div className="mb-2 flex items-center justify-between text-[11px]">
          <span className="truncate font-semibold text-slate-300">{m.league.name}</span>
          {m.live ? <span className="flex items-center gap-1.5"><LiveBadge /><span className="font-bold text-red-400">{m.minuteLabel}</span></span>
            : <span className="text-slate-400">{dayLabel(m.kickoff)} {kickoffTime(m.kickoff)}</span>}
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex min-w-0 flex-1 flex-col items-center gap-1 text-center">
            <Crest team={m.home} size={36} />
            <span className="w-full truncate text-xs font-semibold text-white">{m.home.name}</span>
          </div>
          <div className="text-xl font-extrabold text-gold-400 tabular-nums">{m.score ? `${m.score.home} - ${m.score.away}` : 'v'}</div>
          <div className="flex min-w-0 flex-1 flex-col items-center gap-1 text-center">
            <Crest team={m.away} size={36} />
            <span className="w-full truncate text-xs font-semibold text-white">{m.away.name}</span>
          </div>
        </div>
        {m.simulated && <div className="mt-2 text-center"><SimBadge /></div>}
      </Link>
      <div className="grid grid-cols-3 gap-1 p-2">
        {mk ? ['1', 'X', '2'].map((k, i) => <OddsButton key={k} match={m} market={mk} sel={mk.selections.find((s) => s.key === k)} label={['Home', 'Draw', 'Away'][i]} compact />)
          : <div className="col-span-3 py-3 text-center text-xs text-slate-500">Market suspended</div>}
      </div>
    </div>
  );
}

const POPULAR = [
  { key: '1X2', label: 'Match Result' },
  { key: 'BTTS', label: 'Both Teams To Score' },
  { key: 'OU25', label: 'Over/Under 2.5 Goals' },
];

function PopularMarkets({ matches }) {
  const [mk, setMk] = useState('BTTS');
  const list = matches.filter((m) => m.quick[mk]).slice(0, 8);
  return (
    <section>
      <SectionHeader title="Popular markets" />
      <div className="mb-2 flex gap-2 overflow-x-auto scrollbar-none">
        {POPULAR.map((p) => <button key={p.key} onClick={() => setMk(p.key)} className={`chip ${mk === p.key ? 'chip-active' : ''}`}>{p.label}</button>)}
      </div>
      {list.length ? <MatchList matches={list} market={mk} grouped={false} showLeague /> : <div className="card"><Empty title="No open markets right now" /></div>}
    </section>
  );
}

function Welcome() {
  return (
    <section className="overflow-hidden rounded-2xl border border-brand-500/30 bg-gradient-to-br from-brand-700/35 via-navy-800 to-navy-850 p-5">
      <span className="inline-block rounded-full bg-brand-500/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-brand-300">Virtual play only · no real money</span>
      <h1 className="mt-3 text-2xl font-extrabold leading-tight text-white">Practise football betting.<br /><span className="text-brand-400">Risk nothing.</span></h1>
      <p className="mt-2 max-w-lg text-sm text-slate-300">Start with £100 of free virtual money. Bet pre-match and in-play, build accumulators and track how you do.</p>
      <div className="mt-4 grid grid-cols-2 gap-2 sm:flex">
        <Link to="/register" className="btn-primary h-11 rounded-xl">Join free</Link>
        <Link to="/login" className="btn-ghost h-11 rounded-xl">Log in</Link>
      </div>
    </section>
  );
}

function BalanceCard({ stats }) {
  const { user, setDepositOpen } = useApp();
  const s = stats;
  return (
    <section className="rounded-2xl border border-navy-700 bg-gradient-to-br from-navy-800 to-navy-850 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Hi {user.username} · virtual balance</div>
          <div key={user.balance} className="animate-fade-in mt-0.5 font-cond text-4xl font-bold leading-none text-white tabular-nums">{money(user.balance)}</div>
          <div className="mt-1.5 text-xs text-slate-400">
            Today <span className={s?.profitToday > 0 ? 'text-brand-400' : s?.profitToday < 0 ? 'text-red-400' : 'text-slate-300'}>{s ? signed(s.profitToday) : '–'}</span>
            <span className="mx-1.5 text-slate-600">·</span>
            All-time <span className={s?.profit > 0 ? 'text-brand-400' : s?.profit < 0 ? 'text-red-400' : 'text-slate-300'}>{s ? signed(s.profit) : '–'}</span>
          </div>
        </div>
        <button className="btn-primary h-10 shrink-0 rounded-xl px-3" onClick={() => setDepositOpen(true)}>Add funds</button>
      </div>
      <DailyBonusButton className="mt-3 h-10 w-full rounded-xl" />
    </section>
  );
}

function BetRow({ b, open }) {
  const live = b.selections.find((x) => ['LIVE_1H', 'HT', 'LIVE_2H'].includes(x.matchStatus));
  return (
    <Link to={`/my-bets?tab=${open ? 'open' : 'settled'}&bet=${b.ref}`} className="flex items-center gap-3 px-3 py-3 active:bg-navy-800">
      {open ? (live ? <span className="rounded bg-red-600 px-1.5 py-0.5 text-[10px] font-bold text-white">LIVE {live.liveScore}</span> : <StatusBadge status={b.status} />) : <StatusBadge status={b.status} />}
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-semibold text-slate-100">{b.type === 'ACCA' ? `${b.selections.length}-fold accumulator` : b.selections[0].selection}</div>
        <div className="truncate text-xs text-slate-500">{b.type === 'ACCA' ? b.selections.map((x) => x.selection).join(', ') : b.selections[0].match}{!open && b.settledAt ? ` · ${dateTime(b.settledAt)}` : ''}</div>
      </div>
      <div className="shrink-0 text-right text-xs">
        <div className="text-slate-400 tabular-nums">{money(b.stake)} @ {odds(b.totalOdds)}</div>
        {open ? <div className="font-bold text-white tabular-nums">→ {money(b.potentialReturn)}</div>
          : <div className={`font-bold tabular-nums ${b.profit > 0 ? 'text-brand-400' : b.profit < 0 ? 'text-red-400' : 'text-gold-400'}`}>{signed(b.profit)}</div>}
      </div>
    </Link>
  );
}

function MyBetsBlock() {
  const { user } = useApp();
  const openBets = usePolling(user ? '/api/bets?status=open' : null, 10000, [user?.id, user?.openBets]);
  const settled = usePolling(user ? '/api/bets?status=settled&limit=3' : null, 30000, [user?.id, user?.openBets]);
  const list = openBets.data?.bets || [];
  return (
    <>
      <section>
        <SectionHeader title={`Open bets${list.length ? ` (${list.length})` : ''}`} to="/my-bets?tab=open" />
        {openBets.loading && !openBets.data ? <Skeleton rows={2} /> : list.length ? (
          <div className="card divide-y divide-navy-700 overflow-hidden">{list.slice(0, 3).map((b) => <BetRow key={b.ref} b={b} open />)}</div>
        ) : (
          <div className="card flex items-center justify-between gap-3 px-4 py-3.5 text-sm text-slate-400">
            <span>No open bets. Tap any odds to start a bet slip.</span>
            <Link to="/upcoming" className="shrink-0 font-semibold text-brand-400">Fixtures</Link>
          </div>
        )}
      </section>
      {settled.data?.bets?.length > 0 && (
        <section>
          <SectionHeader title="Recently settled" to="/history" />
          <div className="card divide-y divide-navy-700 overflow-hidden">{settled.data.bets.map((b) => <BetRow key={b.ref} b={b} />)}</div>
        </section>
      )}
    </>
  );
}

function StatsStrip({ s }) {
  if (!s) return null;
  return (
    <section>
      <SectionHeader title="Your performance" to="/history?tab=stats" linkLabel="Full stats" />
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <StatTile label="Bets placed" value={s.totalBets} sub={`${s.openBets} open`} />
        <StatTile label="Win rate" value={pct(s.winRate)} sub={`${s.won} won · ${s.lost} lost`} />
        <StatTile label="Staked" value={money(s.staked)} />
        <StatTile label="Profit / loss" value={signed(s.profit)} tone={s.profit > 0 ? 'pos' : s.profit < 0 ? 'neg' : null} />
      </div>
    </section>
  );
}

function YourTeams({ matches }) {
  const { favs } = useFavourites();
  if (!favs.length) {
    return (
      <section>
        <SectionHeader title="Your teams" />
        <div className="card flex items-center gap-3 px-4 py-3.5 text-sm text-slate-400">
          <svg viewBox="0 0 20 20" className="h-5 w-5 shrink-0 text-gold-400" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="M10 2.5l2.3 4.8 5.2.7-3.8 3.6.9 5.2L10 14.3l-4.6 2.5.9-5.2L2.5 8l5.2-.7z" strokeLinejoin="round" /></svg>
          <span>Open any match and tap <b className="text-slate-200">Follow</b> on a team to see its fixtures here.</span>
        </div>
      </section>
    );
  }
  const mine = matches.filter((m) => favs.includes(m.home.name) || favs.includes(m.away.name)).slice(0, 4);
  return (
    <section>
      <SectionHeader title="Your teams" />
      {mine.length ? <MatchList matches={mine} /> : (
        <div className="card px-4 py-3.5 text-sm text-slate-400">No fixtures right now for {favs.slice(0, 3).join(', ')}{favs.length > 3 ? ` and ${favs.length - 3} more` : ''}.</div>
      )}
    </section>
  );
}

function CasinoRow() {
  return (
    <section>
      <SectionHeader title="Casino games" to="/casino" linkLabel="Lobby" />
      <div className="scrollbar-none -mx-4 flex gap-2.5 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        {CATALOGUE.map((g) => (
          <Link key={g.id} to={g.path} className={`group relative flex h-24 w-32 shrink-0 flex-col justify-end overflow-hidden rounded-xl bg-gradient-to-br p-2.5 ring-1 ring-white/10 transition hover:ring-white/30 ${g.hue}`}>
            <span className="absolute right-2 top-2 rounded bg-black/40 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white/80">{g.cat}</span>
            <span className="font-cond text-[15px] font-extrabold leading-tight text-white drop-shadow">{g.name}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

export default function Home() {
  const { config, user } = useApp();
  const all = usePolling('/api/matches?view=all', 8000);
  const featured = usePolling('/api/matches/featured', 15000);
  const results = usePolling('/api/matches?view=results', 60000);
  const stats = usePolling(user ? '/api/stats' : null, 30000, [user?.id, user?.openBets]);
  const matches = all.data?.matches || [];
  const live = matches.filter((m) => m.live);
  const upcoming = matches.filter((m) => m.status === 'SCHEDULED' && m.bettingOpen);
  const loadingMatches = all.loading && !all.data;

  return (
    <div className="space-y-6">
      {user ? <BalanceCard stats={stats.data?.stats} /> : user === null ? <Welcome /> : <div className="vb-skel h-32 rounded-2xl" />}
      {user && <MyBetsBlock />}
      {config?.provider !== 'none' && config?.providerStatus?.lastError && (
        <div className="rounded-md border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-300">Live data issue: {config.providerStatus.lastError}</div>
      )}
      {all.error && !all.data ? <ErrorBox error={all.error} onRetry={all.reload} /> : (
        <>
          {(live.length > 0 || loadingMatches) && (
            <section>
              <SectionHeader title="Live now" to="/live" live />
              {loadingMatches ? <Skeleton rows={2} /> : <MatchList matches={live.slice(0, 4)} />}
            </section>
          )}
          {featured.data?.matches?.length > 0 && (
            <section>
              <SectionHeader title="Featured" />
              <div className="scrollbar-none -mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-1 sm:mx-0 sm:grid sm:grid-cols-2 sm:px-0 xl:grid-cols-3">
                {featured.data.matches.map((m) => <div key={m.id} className="snap-start"><FeaturedCard m={m} /></div>)}
              </div>
            </section>
          )}
          {user && !loadingMatches && <YourTeams matches={matches.filter((m) => m.status !== 'FINISHED')} />}
          <section>
            <SectionHeader title="Upcoming fixtures" to="/upcoming" />
            {loadingMatches ? <Skeleton rows={4} /> : upcoming.length ? <MatchList matches={upcoming.slice(0, 6)} /> : <div className="card"><Empty title="No upcoming fixtures">New fixtures will appear here automatically.</Empty></div>}
          </section>
          {results.data?.matches?.length > 0 && (
            <section>
              <SectionHeader title="Recent results" to="/results" />
              <MatchList matches={results.data.matches.slice(0, 4)} />
            </section>
          )}
          {!live.length && !loadingMatches && (
            <section>
              <SectionHeader title="Live now" to="/live" live />
              <div className="card px-4 py-3.5 text-sm text-slate-400">
                {config?.localMode ? <>Real matches close for betting at kick-off. <Link to="/live" className="text-brand-400 underline">Try simulated in-play practice</Link>.</> : 'No matches in play right now - in-play markets open at kick-off.'}
              </div>
            </section>
          )}
          {user && <StatsStrip s={stats.data?.stats} />}
          <PopularMarkets matches={matches.filter((m) => m.bettingOpen)} />
          <CasinoRow />
          <LifetimeTotals compact />
        </>
      )}
    </div>
  );
}
