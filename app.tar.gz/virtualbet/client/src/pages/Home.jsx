import { useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { Link } from '../lib/router.jsx';
import { usePolling } from '../lib/hooks.js';
import { dateTime, dayLabel, kickoffTime, odds, pct, signed, money } from '../lib/format.js';
import { MatchList } from '../components/MatchRow.jsx';
import Crest from '../components/Crest.jsx';
import OddsButton from '../components/OddsButton.jsx';
import { DailyBonusButton } from '../components/DepositModal.jsx';
import { CATALOGUE } from '../../../server/games/registry.js';
import { LifetimeTotals } from './Progress.jsx';
import { Empty, ErrorBox, Icon, LiveBadge, Loading, SimBadge, StatTile, StatusBadge } from '../components/ui.jsx';

function SectionHeader({ title, to, linkLabel = 'View all', live }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <h2 className="section-title">{live && <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" />}{title}</h2>
      {to && <Link to={to} className="flex items-center text-xs font-semibold text-brand-400 hover:text-brand-300">{linkLabel}<Icon.chevron className="h-4 w-4" /></Link>}
    </div>
  );
}

function FeaturedCard({ m }) {
  const mk = m.quick['1X2'];
  return (
    <div className="card w-[280px] shrink-0 overflow-hidden sm:w-auto">
      <Link to={`/match/${encodeURIComponent(m.id)}`} className="block bg-gradient-to-br from-navy-700 to-navy-800 p-3 hover:from-navy-600">
        <div className="mb-2 flex items-center justify-between text-[11px]">
          <span className="truncate font-semibold text-slate-300">{m.league.name}</span>
          {m.live ? <span className="flex items-center gap-1.5"><LiveBadge /><span className="font-bold text-red-400">{m.minuteLabel}</span></span>
            : <span className="text-slate-400">{dayLabel(m.kickoff)} {kickoffTime(m.kickoff)}</span>}
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex min-w-0 flex-1 flex-col items-center gap-1 text-center">
            <Crest team={m.home} size={36} />
            <span className="w-full truncate text-xs font-semibold text-white">{m.home.name}</span>
          </div>
          <div className="text-xl font-extrabold text-gold-400 tabular-nums">{m.score ? `${m.score.home} - ${m.score.away}` : 'v'}</div>
          <div className="flex min-w-0 flex-1 flex-col items-center gap-1 text-center">
            <Crest team={m.away} size={36} />
            <span className="w-full truncate text-xs font-semibold text-white">{m.away.name}</span>
          </div>
        </div>
        {m.simulated && <div className="mt-2 text-center"><SimBadge /></div>}
      </Link>
      <div className="grid grid-cols-3 gap-1 p-2">
        {mk ? ['1', 'X', '2'].map((k, i) => <OddsButton key={k} match={m} market={mk} sel={mk.selections.find((s) => s.key === k)} label={['Home', 'Draw', 'Away'][i]} compact />)
          : <div className="col-span-3 py-3 text-center text-xs text-slate-500">Market suspended</div>}
      </div>
    </div>
  );
}

const POPULAR = [
  { key: '1X2', label: 'Match Result' },
  { key: 'BTTS', label: 'Both Teams To Score' },
  { key: 'OU25', label: 'Over/Under 2.5 Goals' },
];

function PopularMarkets({ matches }) {
  const [mk, setMk] = useState('BTTS');
  const list = matches.filter((m) => m.quick[mk]).slice(0, 8);
  return (
    <section>
      <SectionHeader title="Popular markets" />
      <div className="mb-2 flex gap-2 overflow-x-auto scrollbar-none">
        {POPULAR.map((p) => <button key={p.key} onClick={() => setMk(p.key)} className={`chip ${mk === p.key ? 'chip-active' : ''}`}>{p.label}</button>)}
      </div>
      {list.length ? <MatchList matches={list} market={mk} grouped={false} showLeague /> : <div className="card"><Empty title="No open markets right now" /></div>}
    </section>
  );
}

function AccountSummary() {
  const { user, setDepositOpen } = useApp();
  const { data } = usePolling(user ? '/api/stats' : null, 15000, [user?.id]);
  const settled = usePolling(user ? '/api/bets?status=settled&limit=5' : null, 15000, [user?.id]);
  if (!user) {
    return (
      <section className="overflow-hidden rounded-xl border border-brand-500/30 bg-gradient-to-r from-brand-700/40 via-navy-800 to-navy-850 p-5 sm:p-6">
        <h1 className="text-2xl font-extrabold text-white sm:text-3xl">Practise football betting.<br /><span className="text-brand-400">Risk nothing.</span></h1>
        <p className="mt-2 max-w-lg text-sm text-slate-300">Get £100 of free virtual money, bet on pre-match and in-play football, build accumulators and track your performance - without spending a penny.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Link to="/register" className="btn-primary">Join free - get £100 virtual</Link>
          <Link to="/login" className="btn-ghost">Log in</Link>
        </div>
      </section>
    );
  }
  const s = data?.stats;
  return (
    <section className="space-y-3">
      <div className="flex flex-col gap-3 rounded-xl border border-navy-700 bg-gradient-to-r from-navy-800 to-navy-850 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">Welcome back, {user.username}</div>
          <div className="mt-0.5 text-3xl font-extrabold text-white tabular-nums">{money(user.balance)} <span className="text-base font-semibold text-slate-400">virtual</span></div>
          {s && <div className="mt-1 text-xs text-slate-400">Today's P/L <span className={s.profitToday > 0 ? 'text-brand-400' : s.profitToday < 0 ? 'text-red-400' : ''}>{signed(s.profitToday)}</span> · All-time <span className={s.profit > 0 ? 'text-brand-400' : s.profit < 0 ? 'text-red-400' : ''}>{signed(s.profit)}</span></div>}
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn-primary" onClick={() => setDepositOpen(true)}>Deposit (free, virtual)</button>
          <DailyBonusButton />
        </div>
      </div>
      {s && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <StatTile label="Bets placed" value={s.totalBets} sub={`${s.openBets} open`} />
          <StatTile label="Win rate" value={pct(s.winRate)} sub={`${s.won} won · ${s.lost} lost`} />
          <StatTile label="Staked" value={money(s.staked)} />
          <StatTile label="Profit / loss" value={signed(s.profit)} tone={s.profit > 0 ? 'pos' : s.profit < 0 ? 'neg' : null} />
        </div>
      )}
      {settled.data?.bets?.length > 0 && (
        <div>
          <SectionHeader title="Recently settled bets" to="/my-bets?tab=settled" />
          <div className="card divide-y divide-navy-700">
            {settled.data.bets.map((b) => (
              <Link key={b.ref} to={`/my-bets?tab=settled&bet=${b.ref}`} className="flex items-center gap-3 px-3 py-2.5 text-sm hover:bg-navy-800">
                <StatusBadge status={b.status} />
                <div className="min-w-0 flex-1">
                  <div className="truncate font-semibold text-slate-100">{b.type === 'ACCA' ? `${b.selections.length}-fold accumulator` : b.selections[0].selection}</div>
                  <div className="truncate text-xs text-slate-500">{b.type === 'ACCA' ? b.selections.map((x) => x.selection).join(', ') : b.selections[0].match} · {dateTime(b.settledAt)}</div>
                </div>
                <div className="text-right text-xs">
                  <div className="text-slate-400">{money(b.stake)} @ {odds(b.totalOdds)}</div>
                  <div className={`font-bold tabular-nums ${b.profit > 0 ? 'text-brand-400' : b.profit < 0 ? 'text-red-400' : 'text-gold-400'}`}>{signed(b.profit)}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

function CasinoRow() {
  return (
    <section>
      <SectionHeader title="Casino games" to="/casino" linkLabel="Lobby" />
      <div className="scrollbar-none -mx-3 flex gap-2.5 overflow-x-auto px-3 pb-1 sm:mx-0 sm:px-0">
        {CATALOGUE.map((g) => (
          <Link key={g.id} to={g.path} className={`group relative flex h-24 w-32 shrink-0 flex-col justify-end overflow-hidden rounded-xl bg-gradient-to-br p-2.5 ring-1 ring-white/10 transition hover:ring-white/30 ${g.hue}`}>
            <span className="absolute right-2 top-2 rounded bg-black/40 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white/80">{g.cat}</span>
            <span className="font-cond text-[15px] font-extrabold leading-tight text-white drop-shadow">{g.name}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

export default function Home() {
  const { config } = useApp();
  const all = usePolling('/api/matches?view=all', 4000);
  const featured = usePolling('/api/matches/featured', 5000);
  const matches = all.data?.matches || [];
  const live = matches.filter((m) => m.live);
  const upcoming = matches.filter((m) => m.status === 'SCHEDULED' && m.bettingOpen);

  return (
    <div className="space-y-6">
      <AccountSummary />
      <LifetimeTotals compact />
      {config?.provider !== 'none' && config?.providerStatus?.lastError && (
        <div className="rounded-md border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-300">Live data issue: {config.providerStatus.lastError}</div>
      )}
      {all.loading && !all.data ? <Loading label="Loading matches…" /> : all.error && !all.data ? <ErrorBox error={all.error} onRetry={all.reload} /> : (
        <>
          {featured.data?.matches?.length > 0 && (
            <section>
              <SectionHeader title="Featured matches" />
              <div className="scrollbar-none -mx-3 flex gap-3 overflow-x-auto px-3 pb-1 sm:mx-0 sm:grid sm:grid-cols-2 sm:px-0 xl:grid-cols-3">
                {featured.data.matches.map((m) => <FeaturedCard key={m.id} m={m} />)}
              </div>
            </section>
          )}
          <section>
            <SectionHeader title="Live now" to="/live" live />
            {live.length ? <MatchList matches={live.slice(0, 8)} /> : (
              <div className="card"><Empty title={config?.localMode ? 'In-play betting uses simulated practice matches' : 'No live matches right now'}>
                {config?.localMode ? <>Real matches close for betting at kick-off in this version. <Link to="/live" className="text-brand-400 underline">Try simulated in-play practice</Link>.</> : 'Upcoming matches are listed below - in-play markets open at kick-off.'}
              </Empty></div>
            )}
          </section>
          <CasinoRow />
          <PopularMarkets matches={matches.filter((m) => m.bettingOpen)} />
          <section>
            <SectionHeader title="Upcoming fixtures" to="/upcoming" />
            {upcoming.length ? <MatchList matches={upcoming.slice(0, 12)} /> : <div className="card"><Empty title="No upcoming fixtures">New fixtures will appear here automatically.</Empty></div>}
          </section>
        </>
      )}
    </div>
  );
}
