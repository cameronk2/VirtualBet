import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { usePopout } from '../components/Popout.jsx';
import GameShell, { useGame } from '../components/GameShell.jsx';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import WinCelebration from '../components/WinCelebration.jsx';
import { colourOf, RED, WHEEL_ORDER } from '../../../server/games/roulette.js';

const CHIPS = [10, 100, 500, 2500, 10000, 50000, 100000];
const chipLabel = (v) => (v < 100 ? `${v}p` : v >= 100000 ? `£${v / 100000}k` : `£${v / 100}`);
const CHIP_CLS = { 10: 'bg-slate-200 text-navy-950', 50: 'bg-sky-500 text-white', 100: 'bg-red-600 text-white', 500: 'bg-emerald-600 text-white', 2500: 'bg-zinc-900 text-gold-400 ring-gold-500', 10000: 'bg-violet-700 text-white', 50000: 'bg-amber-500 text-navy-950', 100000: 'bg-gradient-to-br from-gold-400 to-amber-700 text-navy-950' };
const key = (nums) => [...nums].sort((a, b) => a - b).join('-');
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
const PAYS = { 1: '35:1', 2: '17:1', 3: '11:1', 4: '8:1', 6: '5:1', 12: '2:1', 18: '1:1' };
const betName = (nums) => {
  const n = nums.length;
  if (n === 1) return `Straight ${nums[0]}`;
  const s = [...nums].sort((a, b) => a - b).join('/');
  if (n === 2) return `Split ${s}`;
  if (n === 3) return nums.includes(0) ? `Trio ${s}` : `Street ${s}`;
  if (n === 4) return nums.includes(0) ? 'First four 0/1/2/3' : `Corner ${s}`;
  if (n === 6) return `Six line ${Math.min(...nums)}-${Math.max(...nums)}`;
  const k = key(nums);
  const named = [...OUTSIDE, ...DOZENS].find((o) => key(o.nums) === k);
  if (named) return named.label === '1st 12' || named.label === '2nd 12' || named.label === '3rd 12' ? `${named.label} dozen` : named.label;
  const ci = COLUMNS.findIndex((c) => key(c.nums) === k);
  return ci >= 0 ? `Column ${ci + 1}` : s;
};
const SEG = 360 / 37;
const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

const OUTSIDE = [
  { label: '1-18', nums: range(1, 18) }, { label: 'EVEN', nums: range(1, 36).filter((n) => n % 2 === 0) },
  { label: 'RED', nums: [...RED], cls: 'bg-red-700' }, { label: 'BLACK', nums: range(1, 36).filter((n) => !RED.has(n)), cls: 'bg-zinc-900' },
  { label: 'ODD', nums: range(1, 36).filter((n) => n % 2 === 1) }, { label: '19-36', nums: range(19, 36) },
];
const DOZENS = [{ label: '1st 12', nums: range(1, 12) }, { label: '2nd 12', nums: range(13, 24) }, { label: '3rd 12', nums: range(25, 36) }];
const COLUMNS = [1, 2, 3].map((c) => ({ label: '2:1', nums: range(1, 36).filter((n) => (n - 1) % 3 === c - 1) }));

// Racetrack "call bets": each is a list of standard bets, in chip units
const CALL_BETS = {
  Voisins: [[[0, 2, 3], 2], [[4, 7], 1], [[12, 15], 1], [[18, 21], 1], [[19, 22], 1], [[32, 35], 1], [[25, 26, 28, 29], 2]],
  Tiers: [[[5, 8], 1], [[10, 11], 1], [[13, 16], 1], [[23, 24], 1], [[27, 30], 1], [[33, 36], 1]],
  Orphelins: [[[1], 1], [[6, 9], 1], [[14, 17], 1], [[17, 20], 1], [[31, 34], 1]],
  'Jeu 0': [[[0, 3], 1], [[12, 15], 1], [[32, 35], 1], [[26], 1]],
};
const neighbours = (n) => { const i = WHEEL_ORDER.indexOf(n); return [-2, -1, 0, 1, 2].map((d) => WHEEL_ORDER[(i + d + 37) % 37]); };

function Wheel({ rotation, spinning, ball }) {
  return (
    <div className="rl-wheel relative mx-auto aspect-square w-full max-w-[260px]">
      <div className="absolute left-1/2 top-0 z-10 -translate-x-1/2"><svg width="18" height="16" viewBox="0 0 18 16"><path d="M9 16L0 0h18z" fill="#fbbf24" /></svg></div>
      <svg viewBox="0 0 200 200" className="h-full w-full drop-shadow-[0_10px_20px_rgba(0,0,0,0.6)]"
        style={{ transform: `rotate(${rotation}deg)`, transition: spinning ? `transform ${reduceMotion ? 0 : 5}s cubic-bezier(0.15, 0.75, 0.15, 1)` : 'none' }}>
        <circle cx="100" cy="100" r="98" fill="#78350f" stroke="#fbbf24" strokeWidth="2" />
        {WHEEL_ORDER.map((n, i) => {
          const a0 = ((i * SEG - SEG / 2 - 90) * Math.PI) / 180, a1 = ((i * SEG + SEG / 2 - 90) * Math.PI) / 180;
          const p = (r, a) => `${100 + r * Math.cos(a)} ${100 + r * Math.sin(a)}`;
          const ta = ((i * SEG - 90) * Math.PI) / 180;
          return (
            <g key={n}>
              <path d={`M${p(90, a0)}A90 90 0 0 1 ${p(90, a1)}L${p(62, a1)}A62 62 0 0 0 ${p(62, a0)}z`} fill={n === 0 ? '#15803d' : RED.has(n) ? '#b91c1c' : '#111827'} stroke="#d4a017" strokeWidth=".6" />
              <text x={100 + 80 * Math.cos(ta)} y={100 + 80 * Math.sin(ta)} transform={`rotate(${i * SEG} ${100 + 80 * Math.cos(ta)} ${100 + 80 * Math.sin(ta)})`} textAnchor="middle" dominantBaseline="middle" fontSize="7.5" fontWeight="800" fill="#fff" fontFamily="system-ui">{n}</text>
            </g>
          );
        })}
        <circle cx="100" cy="100" r="62" fill="#4a2508" stroke="#d4a017" strokeWidth="1.5" />
        <circle cx="100" cy="100" r="40" fill="#92400e" stroke="#fbbf24" strokeWidth="1.5" />
        {[0, 45, 90, 135].map((a) => <rect key={a} x="97" y="62" width="6" height="76" rx="3" fill="#d4a017" transform={`rotate(${a} 100 100)`} />)}
        <circle cx="100" cy="100" r="9" fill="#fbbf24" />
      </svg>
      {ball && <div className="animate-ball-drop absolute left-1/2 top-[7.5%] h-3 w-3 -translate-x-1/2 rounded-full bg-white shadow-[0_0_6px_rgba(255,255,255,0.9)]" />}
    </div>
  );
}

export default function Roulette() {
  const { view, history, busy, play, commit } = useGame('roulette');
  const [chip, setChip] = useState(100);
  const [lastAdd, setLastAdd] = useState(null);
  const [lastStraight, setLastStraight] = useState(null);
  const [boardEl, setBoardEl] = useState(null);
  const cellRefs = useRef({});
  const [geo, setGeo] = useState(null);
  const [bets, setBets] = useState([]); // [{nums, amount}] in placement order
  const [last, setLast] = useState(null);
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState(null);
  const rot = useRef(0);
  const [full] = usePopout();
  const [showWheel, setShowWheel] = useState(false);
  const [hideNewest, setHideNewest] = useState(false); // don't reveal the number in the history before the ball lands
  const wheelTimer = useRef(0);
  useEffect(() => () => clearTimeout(wheelTimer.current), []);

  const merged = useMemo(() => {
    const m = new Map();
    for (const b of bets) { const k = key(b.nums); m.set(k, { nums: b.nums, amount: (m.get(k)?.amount || 0) + b.amount }); }
    return [...m.values()];
  }, [bets]);
  const total = merged.reduce((a, b) => a + b.amount, 0);
  const onKey = useMemo(() => Object.fromEntries(merged.map((b) => [key(b.nums), b.amount])), [merged]);
  const add = (nums, units = 1, quiet = false) => {
    if (spinning) return;
    setResult(null); sfx.chip();
    setBets((b) => [...b, { nums, amount: chip * units }]);
    if (!quiet) setLastAdd({ name: betName(nums), pays: PAYS[nums.length], amount: chip * units });
  };
  const addMany = (list, name) => { if (spinning) return; list.forEach(([nums, u]) => add(nums, u, true)); setLastAdd({ name, pays: 'several bets', amount: chip * list.reduce((a, x) => a + x[1], 0) }); };
  const removeBet = (k) => { if (spinning) return; setBets((b) => b.filter((x) => key(x.nums) !== k)); setLastAdd(null); };
  const tapNumber = (n) => { setLastStraight(n); add([n]); };

  // Measure the number cells so the split / corner / street spots sit exactly on the lines between them
  useLayoutEffect(() => {
    const el = boardEl;
    if (!el) return undefined;
    // offset* ignores CSS transforms, so this stays right inside the scaled full-screen frame
    const measure = () => {
      const g = {};
      for (let n = 0; n <= 36; n++) {
        const c = cellRefs.current[n];
        if (!c) return;
        g[n] = { l: c.offsetLeft, r: c.offsetLeft + c.offsetWidth, t: c.offsetTop, b: c.offsetTop + c.offsetHeight };
      }
      setGeo((old) => (JSON.stringify(old) === JSON.stringify(g) ? old : g));
    };
    measure();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
    ro?.observe(el);
    window.addEventListener('resize', measure);
    return () => { ro?.disconnect(); window.removeEventListener('resize', measure); };
  }, [boardEl, full]);
  const spots = useMemo(() => {
    if (!geo) return [];
    const out = [];
    const mx = (n) => (geo[n].l + geo[n].r) / 2, my = (n) => (geo[n].t + geo[n].b) / 2;
    for (let n = 1; n <= 36; n++) {
      const col = (n - 1) % 3;
      const below = (geo[n].b + (geo[n + 3]?.t ?? geo[n].b)) / 2;
      if (col < 2) out.push({ nums: [n, n + 1], x: (geo[n].r + geo[n + 1].l) / 2, y: my(n) });
      if (n <= 33) out.push({ nums: [n, n + 3], x: mx(n), y: below });
      if (col < 2 && n <= 32) out.push({ nums: [n, n + 1, n + 3, n + 4], x: (geo[n].r + geo[n + 1].l) / 2, y: below });
      if (col === 0) {
        out.push({ nums: [n, n + 1, n + 2], x: geo[n].l, y: my(n), edge: true });
        if (n <= 31) out.push({ nums: range(n, n + 5), x: geo[n].l, y: below, edge: true });
      }
    }
    const zy = (geo[0].b + geo[1].t) / 2;
    [1, 2, 3].forEach((c) => out.push({ nums: [0, c], x: mx(c), y: zy }));
    out.push({ nums: [0, 1, 2], x: (geo[1].r + geo[2].l) / 2, y: zy });
    out.push({ nums: [0, 2, 3], x: (geo[2].r + geo[3].l) / 2, y: zy });
    out.push({ nums: [0, 1, 2, 3], x: geo[1].l, y: zy, edge: true });
    return out;
  }, [geo]);

  const spin = async () => {
    if (!merged.length || spinning) return;
    setResult(null);
    setSpinning(true); setShowWheel(true); setLastAdd(null); clearTimeout(wheelTimer.current);
    sfx.spin();
    const out = await play('spin', { bets: merged });
    if (!out) { setSpinning(false); setShowWheel(false); return; }
    setHideNewest(true);
    const idx = WHEEL_ORDER.indexOf(out.number);
    const base = rot.current - (rot.current % 360);
    const next = base + 360 * 5 - idx * SEG;
    rot.current = next;
    setRotation(next);
    if (!reduceMotion) for (let t = 0; t < 26; t++) setTimeout(() => sfx.chip(), 100 + t * t * 7);
    setTimeout(() => {
      setSpinning(false); setHideNewest(false);
      setResult(out);
      wheelTimer.current = setTimeout(() => setShowWheel(false), 1900);
      setLast(merged);
      commit();
      if (out.payout >= out.staked * 10 && out.staked > 0) setBig({ amount: out.payout, bet: out.staked }); else if (out.payout > 0) sfx.win(); else sfx.lose();
    }, reduceMotion ? 100 : 5100);
  };

  const histAll = view?.history || [];
  const hist = hideNewest ? histAll.slice(1) : histAll;
  const [big, setBig] = useState(null);
  const stats = useMemo(() => {
    const h = hist.slice(0, 100);
    const counts = new Map(range(0, 36).map((n) => [n, 0]));
    h.forEach((n) => counts.set(n, counts.get(n) + 1));
    const sorted = [...counts].sort((a, b) => b[1] - a[1] || a[0] - b[0]);
    const pct = (f) => (h.length ? Math.round((h.filter(f).length / h.length) * 100) : 0);
    return { n: h.length, hot: sorted.slice(0, 5), cold: sorted.slice(-5).reverse(), red: pct((n) => colourOf(n) === 'red'), black: pct((n) => colourOf(n) === 'black'), zero: pct((n) => n === 0) };
  }, [hist]);
  const win = result?.number;
  const outcomeText = (r) => (r.payout <= 0 ? 'No win' : r.payout > r.staked ? `Won ${money(r.payout - r.staked)}` : r.payout === r.staked ? 'Stake back' : `${money(r.payout)} back`);
  const statusText = spinning ? 'No more bets…'
    : result ? `${result.number} · ${result.payout > 0 ? `Paid ${money(result.payout)} · ${result.payout >= result.staked ? '+' : '−'}${money(Math.abs(result.payout - result.staked))}` : 'No win'}`
      : lastAdd ? `${lastAdd.name} · ${money(lastAdd.amount)} · pays ${lastAdd.pays}` : 'Place your bets';
  const numCls = (n) => `${n === 0 ? 'bg-green-700' : RED.has(n) ? 'bg-red-700' : 'bg-zinc-900'} ${win === n ? 'ring-2 ring-gold-400 z-10 animate-win-pulse' : ''} `;
  const ChipBadge = ({ amt }) => (amt ? <span className="pointer-events-none absolute left-0.5 top-1/2 z-10 -translate-y-1/2 rounded-full border-2 border-dashed border-white/70 bg-gold-400 px-1 text-[9px] font-black leading-[14px] text-navy-950 shadow">{money(amt).replace('£', '').replace('.00', '')}</span> : null);

  const wheelBox = (overlay) => (
    <div className={overlay
      ? `absolute inset-0 z-20 flex flex-col items-center justify-center rounded-xl bg-[radial-gradient(ellipse_at_center,rgba(20,83,45,0.97)_0%,rgba(5,46,22,0.97)_70%)] p-3 transition-opacity duration-300 ${showWheel ? 'opacity-100' : 'pointer-events-none opacity-0'}`
      : 'relative overflow-hidden rounded-2xl bg-[radial-gradient(ellipse_at_center,#14532d_0%,#052e16_70%)] p-4 ring-1 ring-emerald-900'}>
            {big && !overlay && <WinCelebration game="roulette" amount={big.amount} bet={big.bet} onDone={() => setBig(null)} className="absolute inset-0 z-30 rounded-2xl" />}
            <div className={overlay ? "w-[min(62vw,240px)]" : "w-full"}><Wheel rotation={rotation} spinning={spinning} ball={spinning || result} /></div>
            <div className="rl-result mt-3 flex min-h-14 flex-col items-center justify-center text-center">
              {result ? (
                <div className="animate-fade-in">
                  <div className="flex items-center justify-center gap-2">
                    <span className={`flex h-12 w-12 items-center justify-center rounded-full font-cond text-2xl font-extrabold text-white ${result.colour === 'red' ? 'bg-red-700' : result.colour === 'green' ? 'bg-green-700' : 'bg-zinc-900 ring-1 ring-white/20'}`}>{result.number}</span>
                    <span className={`font-cond text-2xl font-extrabold ${result.payout > result.staked ? 'text-gold-400' : 'text-slate-300'}`}>{outcomeText(result)}</span>
                  </div>
                  {result.wins?.length > 0 && <div className="mt-1 space-y-0.5 text-[11px] text-emerald-100/80">{result.wins.slice(0, 4).map((w) => <div key={key(w.nums)}>{betName(w.nums)} · {money(w.amount)} at {PAYS[w.nums.length]} → {money(w.payout)}</div>)}</div>}
                </div>
              ) : <div className="text-sm text-emerald-100/70">{spinning ? 'No more bets…' : 'Place your bets'}</div>}
              <div className="rl-last mt-2 hidden gap-1">{hist.slice(0, 6).map((n, i) => <span key={i} className={`flex h-6 min-w-6 items-center justify-center rounded text-[11px] font-bold text-white ${n === 0 ? 'bg-green-700' : RED.has(n) ? 'bg-red-700' : 'bg-zinc-900 ring-1 ring-white/15'}`}>{n}</span>)}</div>
            </div>
              </div>
  );

  return (
    <GameShell title="Roulette" subtitle="European single zero · straight up pays 35:1" rtp="97.3%" history={history}
      rules={<>
        <p>One green zero and 36 numbers. A winning bet returns your stake plus the odds, so £1 on a corner (8:1) returns £9. Bets pay: straight (1 number) 35:1, split (2) 17:1, street (3) 11:1, corner (4) 8:1, six line (6) 5:1, dozen or column 2:1, red/black, odd/even, 1-18/19-36 1:1.</p>
        <p>Tap a number to bet on it alone. The small dots on the board are the other inside bets: a dot on the line between two numbers is a split, a dot where four numbers meet is a corner, and the blue dots on the left edge are streets (a row of three) and six lines (two rows). Dots between 0 and the first row cover 0 with its neighbours. Every bet you place is listed under the board with what it pays; tap one there to remove it. Call bets place several chips at once: <b>Voisins</b> (the 17 numbers near zero, 9 chips), <b>Tiers</b> (the 12 numbers opposite, 6 chips), <b>Orphelins</b> (the remaining 8, 5 chips), <b>Jeu 0</b> (4 chips) and <b>Neighbours</b> (a number and two either side on the wheel, 5 chips).</p>
        <p className="text-slate-500">The house edge is 2.7% on every bet. Hot and cold numbers only describe past spins; every spin is independent, so they don't predict anything.</p>
      </>}>
      <div className={full ? 'mx-auto grid max-w-[520px] grid-cols-[minmax(0,1fr)] gap-3' : 'grid gap-3 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]'}>
        <section className="space-y-3">
          {!full && wheelBox(false)}
          <div className="pop-hide card p-3">
            <div className="mb-2 flex items-center justify-between"><span className="text-xs font-bold uppercase tracking-wider text-slate-400">Last results</span><span className="text-[11px] text-slate-500">{stats.n} spins</span></div>
            <div className="scrollbar-none flex gap-1 overflow-x-auto">
              {hist.slice(0, 18).map((n, i) => <span key={i} className={`flex h-7 min-w-7 items-center justify-center rounded text-xs font-bold text-white ${n === 0 ? 'bg-green-700' : RED.has(n) ? 'bg-red-700' : 'bg-zinc-900 ring-1 ring-white/15'}`}>{n}</span>)}
              {!hist.length && <span className="text-xs text-slate-500">No spins yet</span>}
            </div>
            {stats.n >= 10 && (
              <div className="mt-3 grid grid-cols-2 gap-3 text-xs">
                <div><div className="mb-1 font-semibold text-red-300">Hot</div><div className="flex gap-1">{stats.hot.map(([n, c]) => <span key={n} className="rounded bg-navy-800 px-1.5 py-0.5 tabular-nums text-slate-200">{n}<sub className="text-slate-500">{c}</sub></span>)}</div></div>
                <div><div className="mb-1 font-semibold text-sky-300">Cold</div><div className="flex gap-1">{stats.cold.map(([n, c]) => <span key={n} className="rounded bg-navy-800 px-1.5 py-0.5 tabular-nums text-slate-200">{n}<sub className="text-slate-500">{c}</sub></span>)}</div></div>
                <div className="col-span-2 flex h-2 overflow-hidden rounded-full"><span className="bg-red-600" style={{ width: `${stats.red}%` }} /><span className="bg-green-600" style={{ width: `${stats.zero}%` }} /><span className="bg-zinc-700" style={{ width: `${stats.black}%` }} /></div>
                <p className="col-span-2 text-[11px] text-slate-500">Red {stats.red}% · Zero {stats.zero}% · Black {stats.black}%. Past spins don't change the odds of the next one.</p>
              </div>
            )}
          </div>
        </section>

        <section className={full ? 'min-w-0 space-y-1.5' : 'space-y-3'}>
          {full && (
            <div className="flex h-8 items-center gap-1.5 px-0.5">
              <div className="flex gap-1">{hist.slice(0, 6).map((n, i) => <span key={i} className={`flex h-6 min-w-6 items-center justify-center rounded text-[11px] font-bold text-white ${i === 0 ? 'ring-2 ring-gold-400' : ''} ${n === 0 ? 'bg-green-700' : RED.has(n) ? 'bg-red-700' : 'bg-zinc-900 ring-1 ring-white/15'}`}>{n}</span>)}</div>
              <div className={`ml-auto truncate text-sm font-bold ${result?.payout > result?.staked ? 'text-gold-400' : 'text-slate-300'}`}>{statusText}</div>
            </div>
          )}
          <div className={`card relative ${full ? 'space-y-1.5 p-1.5' : 'space-y-2 p-3'}`}>
            {full && wheelBox(true)}
            {big && full && <WinCelebration game="roulette" amount={big.amount} bet={big.bet} onDone={() => setBig(null)} className="absolute inset-0 z-30 rounded-xl" />}
            <div className={full ? 'scrollbar-none flex w-0 min-w-full gap-1 overflow-x-auto' : 'flex flex-wrap gap-1'}>
              {Object.entries(CALL_BETS).map(([name, list]) => <button key={name} className="chip shrink-0 border-amber-400/40" onClick={() => addMany(list, name)}>{name} · {list.reduce((a, x) => a + x[1], 0)}</button>)}
              <button className="chip shrink-0 border-amber-400/40" disabled={(lastStraight ?? win) == null} onClick={() => { const n = lastStraight ?? win; addMany(neighbours(n).map((x) => [[x], 1]), `Neighbours of ${n}`); }}>Neighbours {lastStraight ?? win ?? ''}</button>
            </div>
            <p className="text-[11px] text-slate-400">{!full && lastAdd ? <span className="font-semibold text-slate-200">{lastAdd.name} · {money(lastAdd.amount)} · pays {lastAdd.pays}</span> : <>Tap a number for a straight bet. Tap the <span className="inline-block h-2 w-2 rounded-full bg-gold-400 align-middle" /> dots on the lines for splits and corners, or on the left edge for streets and six lines.</>}</p>
            {/* Board: vertical layout for phones */}
            <div ref={setBoardEl} className="relative grid select-none grid-cols-[1fr_1fr_1.15fr_1.15fr_1.15fr] gap-[3px] rounded-xl bg-emerald-950 p-1.5 text-white ring-1 ring-emerald-800">
              <div className="col-span-2" />
              <button ref={(e) => { cellRefs.current[0] = e; }} onClick={() => tapNumber(0)} className={`rl-num relative col-span-3 h-9 rounded font-cond text-lg font-bold ${numCls(0)}`}>0<ChipBadge amt={onKey['0']} /></button>
              {OUTSIDE.map((o, i) => (
                <button key={o.label} onClick={() => add(o.nums)} style={{ gridRow: `${2 + i * 2} / span 2`, gridColumn: 1 }} className={`relative rounded text-[10px] font-bold [writing-mode:vertical-rl] rotate-180 ${o.cls || 'bg-emerald-800/80'} hover:brightness-125`}>
                  {o.label}<ChipBadge amt={onKey[key(o.nums)]} />
                </button>
              ))}
              {DOZENS.map((d, i) => (
                <button key={d.label} onClick={() => add(d.nums)} style={{ gridRow: `${2 + i * 4} / span 4`, gridColumn: 2 }} className="relative rounded bg-emerald-800/80 text-[11px] font-bold [writing-mode:vertical-rl] rotate-180 hover:brightness-125">
                  {d.label}<ChipBadge amt={onKey[key(d.nums)]} />
                </button>
              ))}
              {range(1, 36).map((n) => (
                <button key={n} ref={(e) => { cellRefs.current[n] = e; }} onClick={() => tapNumber(n)} style={{ gridRow: 2 + Math.floor((n - 1) / 3), gridColumn: 3 + ((n - 1) % 3) }} className={`rl-num relative h-9 rounded font-cond text-base font-bold transition-colors hover:brightness-125 ${numCls(n)}`}>
                  {n}<ChipBadge amt={onKey[String(n)]} />
                </button>
              ))}
              <div className="col-span-2" style={{ gridRow: 14 }} />
              {COLUMNS.map((c, i) => (
                <button key={i} onClick={() => add(c.nums)} style={{ gridRow: 14, gridColumn: 3 + i }} className="rl-num relative h-8 rounded bg-emerald-800/80 text-[11px] font-bold hover:brightness-125">2:1<ChipBadge amt={onKey[key(c.nums)]} /></button>
              ))}
              {spots.map((sp) => {
                const k = key(sp.nums), amt = onKey[k];
                return (
                  <button key={k} type="button" aria-label={`${betName(sp.nums)}, pays ${PAYS[sp.nums.length]}`} title={`${betName(sp.nums)} · pays ${PAYS[sp.nums.length]}`}
                    onClick={() => add(sp.nums)} disabled={spinning}
                    style={{ left: sp.x, top: sp.y }}
                    className="group absolute z-[15] flex h-[18px] w-[20px] -translate-x-1/2 -translate-y-1/2 items-center justify-center">
                    {amt ? <span className="pointer-events-none rounded-full border-2 border-dashed border-white/80 bg-gold-400 px-1 text-[9px] font-black leading-[13px] text-navy-950 shadow-[0_1px_4px_rgba(0,0,0,.7)]">{money(amt).replace('£', '').replace('.00', '')}</span>
                      : <span className={`pointer-events-none h-2 w-2 rounded-full ${sp.edge ? 'bg-sky-300/80' : 'bg-gold-400/80'} shadow-[0_0_0_1.5px_rgba(0,0,0,.55)] transition-transform group-hover:scale-150 group-active:scale-150`} />}
                  </button>
                );
              })}
            </div>
            {merged.length > 0 && !spinning && (
              <div className={`scrollbar-none flex gap-1 text-[11px] ${full ? 'w-0 min-w-full overflow-x-auto' : 'flex-wrap'}`}>
                {merged.map((b) => (
                  <button key={key(b.nums)} onClick={() => removeBet(key(b.nums))} title="Remove this bet" className="flex shrink-0 items-center gap-1 rounded bg-navy-800 px-1.5 py-0.5 text-slate-300 hover:bg-navy-700">
                    <span className="whitespace-nowrap">{betName(b.nums)} · {money(b.amount)} · {PAYS[b.nums.length]}</span><span className="text-slate-500">✕</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className={`card ${full ? 'space-y-1.5 p-1.5' : 'space-y-3 p-3'}`}>
            <div className="flex items-center justify-center gap-1.5 sm:gap-2">
              {CHIPS.map((c) => (
                <button key={c} onClick={() => { setChip(c); sfx.chip(); }} aria-pressed={chip === c}
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-[3px] border-dashed border-white/40 text-[11px] font-extrabold shadow ring-2 ring-white/20 transition-transform ${CHIP_CLS[c]} ${chip === c ? '-translate-y-1 scale-110 ring-4 ring-gold-400' : ''}`}>{chipLabel(c)}</button>
              ))}
            </div>
            <div className={full ? 'grid grid-cols-[repeat(4,minmax(0,1fr))_2fr] gap-1.5' : 'grid grid-cols-4 gap-2'}>
              <button className="btn-ghost px-1" disabled={spinning || !bets.length} onClick={() => setBets((b) => b.slice(0, -1))}>Undo</button>
              <button className="btn-ghost px-1" disabled={spinning || !bets.length} onClick={() => { setBets([]); setLastAdd(null); }}>Clear</button>
              <button className="btn-ghost px-1" disabled={spinning || !last} onClick={() => setBets(last.map((b) => ({ ...b })))}>Rebet</button>
              <button className="btn-ghost px-1" disabled={spinning || !bets.length} onClick={() => setBets((b) => [...b, ...b.map((x) => ({ ...x }))])}>×2</button>
              {full && <button className="btn-primary h-11 px-2 text-sm" disabled={busy || spinning || !merged.length} onClick={spin}>{spinning ? 'Spinning…' : merged.length ? `Spin ${money(total)}` : 'Bet to spin'}</button>}
            </div>
            {!full && (
              <button className="btn-primary h-12 w-full text-base" disabled={busy || spinning || !merged.length} onClick={spin}>
                {spinning ? 'Spinning…' : merged.length ? `Spin · ${money(total)}` : 'Place a bet to spin'}
              </button>
            )}
          </div>
        </section>
      </div>
    </GameShell>
  );
}
