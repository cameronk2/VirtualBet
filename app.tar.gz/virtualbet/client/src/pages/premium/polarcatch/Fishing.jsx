// Polar Catch – the fishing bonus scene. Plays out a catch the server has
// already decided: cast → bite → reel in → reveal value → multiplier.
import { useEffect, useRef, useState } from 'react';
import { SPOTS } from '../../../../../server/games/polarcatch/config.js';
import { Fish } from '../../../components/SlotArtPolar.jsx';
import { money } from '../../../lib/format.js';

const sizeOf = (bonus, fish) => {
  const tiers = { minnow: [10, 25, 50], salmon: [15, 40, 100], king: [40, 100, 200] }[bonus];
  return fish >= tiers[2] ? 3 : fish >= tiers[1] ? 2 : fish >= tiers[0] ? 1 : 0;
};
const SIZE_LABEL = ['A nice catch', 'A big one!', 'Bring the crane!', 'Call the helicopter!'];

export default function Fishing({ fishing, bet, wait, fx, onDone }) {
  const [phase, setPhase] = useState('cast');
  const root = useRef(null);
  // On small screens, bring the scene into view.
  useEffect(() => { if (window.innerWidth < 768) root.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, []);
  const size = sizeOf(fishing.bonus, fishing.fish);
  useEffect(() => {
    let live = true;
    (async () => {
      fx.cast(); await wait(1100); if (!live) return;
      setPhase('bite'); fx.bite(); await wait(900 + size * 250); if (!live) return;
      setPhase('reel'); fx.reel(size); await wait(1500 + size * 500); if (!live) return;
      setPhase('value'); fx.catchValue(size); await wait(1300); if (!live) return;
      if (fishing.mult > 1) { setPhase('mult'); fx.mult(); await wait(1400); if (!live) return; }
      setPhase('total'); await wait(1400); if (live) onDone();
    })();
    return () => { live = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const scale = [0.55, 0.75, 1, 1.25][size];
  const lifted = phase !== 'cast' && phase !== 'bite';
  return (
    <div ref={root} className="animate-fade-in absolute inset-0 z-30 overflow-hidden rounded-2xl scroll-mt-28 bg-[linear-gradient(180deg,#020617,#0c1e3d_38%,#e0f2fe_39%,#bae6fd)]" role="status" aria-label={`${SPOTS[fishing.bonus].name} bonus`}>
      <div className="pc-aurora absolute inset-x-0 top-0 h-1/3 opacity-60" />
      <div className="absolute inset-x-0 top-3 text-center font-display text-xl tracking-widest text-sky-100 drop-shadow sm:text-2xl">{SPOTS[fishing.bonus].name.toUpperCase()} BONUS</div>
      {/* ice hole */}
      <div className="absolute left-1/2 top-[50%] h-[8%] w-[34%] -translate-x-1/2 rounded-[50%] bg-[radial-gradient(ellipse,#0e7490,#042f2e)] ring-4 ring-white/70" />
      {/* line and bobber */}
      <div className={`absolute left-1/2 top-0 w-px -translate-x-1/2 bg-white/80 ${phase === 'cast' ? 'pc-line' : ''}`} style={{ height: lifted ? '22%' : '52%', transition: 'height 1.2s ease-in' }} />
      {!lifted && <div className={`absolute left-1/2 top-[51%] h-3 w-3 -translate-x-1/2 rounded-full bg-red-500 ring-2 ring-white ${phase === 'bite' ? 'pc-bob' : ''}`} />}
      {phase === 'bite' && <div className="pc-splash absolute left-1/2 top-[49%] h-10 w-28 -translate-x-1/2 rounded-[50%] border-4 border-sky-100/80" />}
      {/* lifting rig for the big ones */}
      {lifted && size === 2 && <svg viewBox="0 0 100 60" className="absolute right-[4%] top-[8%] w-[42%]" aria-hidden="true"><path d="M90 60V10H20" stroke="#facc15" strokeWidth="4" fill="none" /><path d="M90 10L60 30" stroke="#facc15" strokeWidth="2" /><rect x="80" y="44" width="18" height="16" fill="#f59e0b" /></svg>}
      {lifted && size === 3 && <svg viewBox="0 0 120 50" className="pc-heli absolute left-1/2 top-[4%] w-[46%] -translate-x-1/2" aria-hidden="true"><ellipse cx="60" cy="26" rx="26" ry="12" fill="#e11d48" /><rect x="76" y="22" width="40" height="5" fill="#e11d48" /><path d="M20 10H100" stroke="#cbd5e1" strokeWidth="3" className="pc-rotor" /><circle cx="50" cy="24" r="5" fill="#bae6fd" /><path d="M60 38V50" stroke="#fff" /></svg>}
      {/* the fish */}
      {lifted && (
        <div className="pc-rise absolute left-1/2 top-[18%] -translate-x-1/2" style={{ width: `${46 * scale}%` }}>
          <svg viewBox="0 0 120 60" className="w-full rotate-[-12deg] drop-shadow-[0_8px_16px_rgba(0,0,0,0.5)]" aria-hidden="true"><Fish species={fishing.bonus} /></svg>
        </div>
      )}
      {lifted && <div className="absolute inset-x-0 top-[44%] text-center text-sm font-bold text-sky-900">{SIZE_LABEL[size]}</div>}
      {/* values */}
      {(phase === 'value' || phase === 'mult' || phase === 'total') && (
        <div className="absolute inset-x-0 top-[61%] flex flex-col items-center gap-1">
          <div className="flex items-center gap-2">
            <div key="v" className="p3-stamp rounded-xl bg-sky-950/85 px-4 py-1.5 font-display text-4xl text-white ring-2 ring-sky-200">{fishing.fish}x</div>
            {(phase === 'mult' || phase === 'total') && fishing.mult > 1 && <div className="p3-stamp rounded-xl bg-[linear-gradient(180deg,#fff7c2,#facc15,#b45309)] px-3 py-1 font-display text-3xl text-amber-950 shadow-[0_0_20px_#facc15]">×{fishing.mult}</div>}
          </div>
          {phase === 'total' && (
            <div className="p3-stamp rounded-full bg-emerald-500 px-4 py-1 font-display text-xl text-emerald-950">
              Pays {fishing.pays}:1{bet ? ` · ${money(bet * (1 + fishing.pays))}` : ''}{fishing.capped ? ' (max)' : ''}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
