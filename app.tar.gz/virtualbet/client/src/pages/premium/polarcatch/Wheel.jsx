// Polar Catch – the 53-segment wheel (SVG). Spins to whatever segment the
// server already chose; lit multipliers sit on their segments.
import { forwardRef } from 'react';
import { WHEEL } from '../../../../../server/games/polarcatch/config.js';
import { Fish, Flake } from '../../../components/SlotArtPolar.jsx';

const N = WHEEL.length, A = 360 / N;
const FILL = { blue: 'url(#pcBlue)', white: 'url(#pcWhite)', minnow: 'url(#pcMinnow)', salmon: 'url(#pcSalmon)', king: 'url(#pcKing)' };
const rad = (d) => ((d - 90) * Math.PI) / 180;
const pt = (r, d) => [r * Math.cos(rad(d)), r * Math.sin(rad(d))];
function wedge(i, r0, r1) {
  const a0 = i * A - A / 2, a1 = i * A + A / 2;
  const [x0, y0] = pt(r1, a0), [x1, y1] = pt(r1, a1), [x2, y2] = pt(r0, a1), [x3, y3] = pt(r0, a0);
  return `M${x0} ${y0}A${r1} ${r1} 0 0 1 ${x1} ${y1}L${x2} ${y2}A${r0} ${r0} 0 0 0 ${x3} ${y3}Z`;
}

/** Angle that puts `segment` under the top pointer after at least `turns` full turns. */
export function targetAngle(current, segment, turns, jitter = 0) {
  const base = current + 360 * turns;
  const want = -segment * A + jitter * A * 0.35;
  return base + ((((want - base) % 360) + 360) % 360);
}

export const Wheel = forwardRef(function Wheel({ angle, spinning, duration, lit = {}, landed, flashLit }, ref) {
  return (
    <div className="relative mx-auto aspect-square w-full" ref={ref}>
      <svg viewBox="-112 -112 224 224" className="absolute inset-0 h-full w-full drop-shadow-[0_10px_30px_rgba(0,0,0,0.6)]" aria-hidden="true">
        <circle r="110" fill="#0c4a6e" stroke="url(#pcIce)" strokeWidth="4" />
        <g style={{ transform: `rotate(${angle}deg)`, transition: spinning ? `transform ${duration}ms cubic-bezier(.12,.62,.08,1)` : 'none' }}>
          {WHEEL.map((s, i) => (
            <g key={i}>
              <path d={wedge(i, 46, 104)} fill={FILL[s]} stroke="#0c4a6e" strokeWidth=".8" opacity={landed != null && !spinning && landed !== i ? 0.55 : 1} />
              <g transform={`rotate(${i * A}) translate(0 -88)`}>
                {s === 'blue' || s === 'white'
                  ? <g transform="translate(-6 -6) scale(.5)"><Flake fill={s === 'blue' ? '#e0f2fe' : '#0ea5e9'} stroke="none" /></g>
                  : <g transform="rotate(-90) translate(-9 -4.5) scale(.15)"><Fish species={s} /></g>}
              </g>
              {lit[i] && (
                <g transform={`rotate(${i * A}) translate(0 -66)`} className={flashLit ? 'pc-lit' : ''}>
                  <rect x="-7.5" y="-6" width="15" height="12" rx="3" fill="url(#pcGold)" stroke="#78350f" strokeWidth=".8" />
                  <text y="3.4" textAnchor="middle" fontFamily="'Lilita One'" fontSize="8.5" fill="#451a03">x{lit[i]}</text>
                </g>
              )}
            </g>
          ))}
          {Array.from({ length: N }, (_, i) => { const [x, y] = pt(106, i * A + A / 2); return <circle key={i} cx={x} cy={y} r="1.6" fill="#e0f2fe" />; })}
        </g>
        {/* hub */}
        <circle r="44" fill="url(#pcSky)" stroke="url(#pcIce)" strokeWidth="3" />
        <g transform="translate(-16 -24) scale(1.35)"><Flake fill="#bae6fd" stroke="none" /></g>
        <text y="18" textAnchor="middle" fontFamily="'Lilita One'" fontSize="11" fill="#e0f2fe" letterSpacing="1">POLAR</text>
        <text y="29" textAnchor="middle" fontFamily="'Lilita One'" fontSize="11" fill="#7dd3fc" letterSpacing="1">CATCH</text>
      </svg>
      {/* pointer */}
      <svg viewBox="0 0 30 34" className="absolute left-1/2 top-[-3%] z-10 h-[11%] -translate-x-1/2 drop-shadow-[0_3px_4px_rgba(0,0,0,0.6)]" aria-hidden="true">
        <path d="M15 34L2 8Q15 -4 28 8Z" fill="url(#pcGold)" stroke="#78350f" strokeWidth="2" />
        <circle cx="15" cy="11" r="4" fill="#fff" opacity=".7" />
      </svg>
    </div>
  );
});
