// Brick by Brick – the bonus wheel. Its result is fixed on the server when
// the saws land; the wheel just spins to it.
import { BuzzSaw, HardHat, House } from '../../../components/SlotArtBrick.jsx';

export const WEDGES = ['BUZZSAW', 'MINI', 'MEGAHAT', 'MINOR', 'MANSIONS', 'MINI', 'BUZZSAW', 'MAJOR', 'MEGAHAT', 'MINI', 'MANSIONS', 'MINOR', 'BUZZSAW', 'GRAND'];
const N = WEDGES.length, A = 360 / N;
const STYLE = {
  BUZZSAW: ['#64748b', 'BUZZ SAW'], MANSIONS: ['#b91c1c', 'MANSIONS'], MEGAHAT: ['#ca8a04', 'MEGA HAT'],
  MINI: ['#0891b2', 'MINI'], MINOR: ['#16a34a', 'MINOR'], MAJOR: ['#7c3aed', 'MAJOR'], GRAND: ['#be123c', 'GRAND'],
};
const rad = (d) => ((d - 90) * Math.PI) / 180;
const pt = (r, d) => [r * Math.cos(rad(d)), r * Math.sin(rad(d))];
const wedge = (i) => { const a0 = i * A - A / 2, a1 = i * A + A / 2; const [x0, y0] = pt(100, a0), [x1, y1] = pt(100, a1); return `M0 0L${x0} ${y0}A100 100 0 0 1 ${x1} ${y1}Z`; };

export function wheelTarget(current, result, seed) {
  const options = WEDGES.map((w, i) => (w === result ? i : -1)).filter((i) => i >= 0);
  const idx = options[seed % options.length];
  const base = current + 360 * 5;
  const want = -idx * A + ((seed % 7) - 3) * A * 0.08;
  return base + ((((want - base) % 360) + 360) % 360);
}

export default function BonusWheel({ angle, spinning, landed }) {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[min(100%,calc(100dvh_-_360px),420px)]">
      <svg viewBox="-110 -110 220 220" className="absolute inset-0 h-full w-full drop-shadow-[0_10px_24px_rgba(0,0,0,0.5)]" aria-hidden="true">
        <circle r="108" fill="url(#bkWood)" stroke="#5b2d0c" strokeWidth="4" />
        <g style={{ transform: `rotate(${angle}deg)`, transition: spinning ? 'transform 5s cubic-bezier(.15,.62,.1,1)' : 'none' }}>
          {WEDGES.map((w, i) => (
            <g key={i}>
              <path d={wedge(i)} fill={STYLE[w][0]} stroke="#fff7ed" strokeWidth="1.5" opacity={landed && !spinning && WEDGES[i] !== landed ? 0.55 : 1} />
              <g transform={`rotate(${i * A})`}>
                <text transform="translate(0 -55) rotate(-90)" textAnchor="middle" dominantBaseline="central" fontFamily="'Lilita One', system-ui, sans-serif" fontWeight="800" fontSize="11" fill="#fff" stroke="#0008" strokeWidth="2" paintOrder="stroke"
                  {...(STYLE[w][1].length > 5 ? { textLength: 46, lengthAdjust: 'spacingAndGlyphs' } : {})}>{STYLE[w][1]}</text>
                <g transform="translate(-8 -98) scale(.16)">{w === 'BUZZSAW' ? <BuzzSaw /> : w === 'MEGAHAT' ? <HardHat glow={false} /> : w === 'MANSIONS' ? <House tier={3} /> : <circle cx="50" cy="50" r="30" fill="url(#bkGold)" stroke="#78350f" strokeWidth="6" />}</g>
              </g>
            </g>
          ))}
          {WEDGES.map((_, i) => { const [x, y] = pt(102, i * A + A / 2); return <circle key={i} cx={x} cy={y} r="3" fill="url(#bkGold)" />; })}
        </g>
        <circle r="26" fill="url(#bkBrick)" stroke="#fff7ed" strokeWidth="3" />
        <g transform="translate(-16 -18) scale(.32)"><HardHat glow={false} /></g>
      </svg>
      <svg viewBox="0 0 30 34" className="absolute left-1/2 top-[-4%] z-10 h-[12%] -translate-x-1/2 drop-shadow" aria-hidden="true"><path d="M15 34L2 8Q15 -4 28 8Z" fill="url(#bkGold)" stroke="#78350f" strokeWidth="2" /></svg>
    </div>
  );
}
