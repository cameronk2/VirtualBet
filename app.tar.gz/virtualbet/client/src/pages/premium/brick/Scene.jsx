// Brick by Brick – sunny building site: sky, drifting clouds, hills, a
// crane, half-built houses and a picket fence.
import { House } from '../../../components/SlotArtBrick.jsx';

export default function BuildSite({ mode }) {
  const sky = mode === 'free' ? 'from-amber-300 via-orange-300 to-rose-300' : mode === 'wheel' ? 'from-indigo-500 via-sky-400 to-amber-200' : 'from-sky-500 via-sky-300 to-amber-100';
  return (
    <>
      <div className={`absolute inset-0 bg-gradient-to-b transition-colors duration-1000 ${sky}`} />
      {[12, 40, 70].map((y, i) => <div key={i} className="bk-cloud absolute h-8 w-28 rounded-full bg-white/80 blur-[1px]" style={{ top: `${y / 4}%`, animationDelay: `${-i * 22}s`, animationDuration: `${50 + i * 15}s` }} />)}
      <svg viewBox="0 0 400 120" preserveAspectRatio="none" className="absolute bottom-0 left-0 h-[40%] w-full" aria-hidden="true">
        <path d="M0 70Q60 40 120 62T240 56T400 50V120H0Z" fill="#4ade80" />
        <path d="M0 90Q80 70 180 86T400 80V120H0Z" fill="#16a34a" />
        {/* crane */}
        <path d="M330 86V14H392M330 14L300 14M330 24L384 14" stroke="#f59e0b" strokeWidth="3.5" fill="none" />
        <path d="M376 14V38" stroke="#334155" strokeWidth="1.2" /><rect x="370" y="38" width="12" height="8" fill="#dc2626" />
        {/* fence */}
        {Array.from({ length: 26 }, (_, i) => <path key={i} d={`M${i * 16 + 4} 112V98L${i * 16 + 8} 94L${i * 16 + 12} 98V112Z`} fill="#fff7ed" stroke="#d6b48a" strokeWidth=".8" />)}
        <path d="M0 102H400M0 108H400" stroke="#fff7ed" strokeWidth="2" />
      </svg>
      <svg viewBox="0 0 100 100" className="absolute bottom-[14%] left-[2%] w-[13%] opacity-90" aria-hidden="true"><House tier={1} /></svg>
      <svg viewBox="0 0 100 100" className="absolute bottom-[16%] left-[13%] w-[11%] opacity-80" aria-hidden="true"><House tier={2} /></svg>
      <svg viewBox="0 0 100 100" className="absolute bottom-[15%] right-[14%] w-[12%] opacity-85" aria-hidden="true"><House tier={3} /></svg>
    </>
  );
}
