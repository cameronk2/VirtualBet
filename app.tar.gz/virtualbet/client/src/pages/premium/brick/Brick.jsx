// Brick by Brick – game screen. Every result comes from the server before
// anything moves; this file only reveals it: base reels, the six-hat Hard
// Hat Bonus, the three-saw Buzz Saw Wheel (Buzz Saw / Mansions / Mega Hat
// bonuses or a jackpot) and the wolf's huff-and-puff reveal.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, Burst, FeatureIntro, PremiumShell, RecentList, SidePanel, sleep, tierOf, usePremium, useReelStops } from '../../../components/Premium.jsx';
import { STAKES, WinAmount } from '../../../components/GameShell.jsx';
import { Modal } from '../../../components/ui.jsx';
import { BRICK_NAMES, BrickSym, BuzzSaw, HardHat, House, WolfFace } from '../../../components/SlotArtBrick.jsx';
import { brickSfx } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { EXTRA_SPIN_HATS, FREE_SPINS, HAT_TRIGGER, HOUSE, JACKPOTS, JP_NAME, MAX_WIN_X, PAYTABLE, SAW_TRIGGER, WHEEL } from '../../../../../server/games/brick/config.js';
import BuildSite from './Scene.jsx';
import BonusWheel, { wheelTarget } from './Wheel.jsx';

const ROWS = 3;
const START = [['P1', 'K', 'HAT'], ['TAPE', 'WILD', 'Q'], ['HAT', 'P2', 'A'], ['J', 'TOOLBOX', 'SAW'], ['P3', 'T', 'HAT']];
const BLUR = ['J', 'P1', 'Q', 'HAT', 'K', 'TAPE', 'A', 'TOOLBOX', 'P2', 'WILD', 'SAW', 'T', 'P3', 'N'];
const TIER = { 1: 'Straw', 2: 'Stick', 3: 'Brick' };
const FRAME = {
  1: 'ring-[3px] ring-inset ring-yellow-300 bg-yellow-200/25',
  2: 'ring-[3px] ring-inset ring-amber-600 bg-amber-700/30',
  3: 'ring-[3px] ring-inset ring-red-500 bg-red-700/30',
};
const CHIP = { 1: 'bg-yellow-300 text-yellow-950', 2: 'bg-amber-700 text-amber-50', 3: 'bg-red-600 text-white' };
const KIND = {
  hats: { title: 'HARD HAT BONUS', short: 'Hard Hat Bonus', cta: 'Start building', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(202,138,4,0.96),rgba(28,16,4,0.97))]', text: `${FREE_SPINS} free spins. Every triggering hat starts a straw frame. Hats that land frame an empty spot or upgrade a frame: straw → stick → brick. ${EXTRA_SPIN_HATS}+ hats in one spin = +1 spin. Then the wolf blows the houses down to reveal their prizes.` },
  buzzsaw: { title: 'BUZZ SAW BONUS', short: 'Buzz Saw Bonus', cta: 'Rev the saws', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(71,85,105,0.96),rgba(8,10,14,0.97))]', text: `The saws race to the right edge, framing or upgrading every spot they cross. Then ${FREE_SPINS} free spins with hats, and the wolf's reveal.` },
  mansions: { title: 'MANSIONS BONUS', short: 'Mansions Bonus', cta: 'Lay the bricks', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(153,27,27,0.96),rgba(20,4,4,0.97))]', text: `Every spot where a saw landed becomes a brick frame. Then ${FREE_SPINS} free spins with hats, and the wolf's reveal.` },
  megahat: { title: 'MEGA HAT BONUS', short: 'Mega Hat Bonus', cta: 'Drop the Mega Hat', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(161,98,7,0.96),rgba(20,12,2,0.97))]', text: `A giant hat (2×2, 3×3 or 5×3) drops and frames every spot under it. Then ${FREE_SPINS} free spins with hats, and the wolf's reveal.` },
  wheel: { title: 'BUZZ SAW WHEEL', cta: 'To the wheel', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(30,64,175,0.96),rgba(4,8,20,0.97))]', text: 'Three buzz saws! Spin the wheel for the Buzz Saw, Mansions or Mega Hat bonus, or a Mini, Minor, Major or Grand jackpot.' },
  brickwheel: { title: 'BRICK HOUSE WHEEL', cta: 'To the wheel', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(153,27,27,0.96),rgba(20,4,4,0.97))]', text: 'A brick house hid a wheel spin! Spin for another bonus or a jackpot.' },
};
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v ? '1' : '0'); } catch { /* private mode */ } };
const devMode = () => { try { return location.hash.includes('dev') || localStorage.getItem('vb_dev') === '1'; } catch { return false; } };
const key = (c, r) => `${c},${r}`;
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const prizeLabel = (p, bet) => (typeof p === 'number' ? money(Math.floor(bet * p)) : p === 'WHEEL' ? 'WHEEL!' : JP_NAME[p]);

function Reel({ index, cells, spinning, landKey, lit, trig, turbo, tease }) {
  return (
    <div className={`relative overflow-hidden rounded-lg bg-[#3b2414]/50 ring-1 ${tease ? 'ring-2 ring-yellow-300 shadow-[0_0_24px_rgba(250,204,21,0.8)]' : 'ring-amber-100/20'}`} style={{ aspectRatio: `1 / ${ROWS}` }}>
      {spinning ? (
        <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 50}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-0.5 opacity-80 blur-[1.5px]"><BrickSym s={BLUR[(k * 5 + index * 3) % BLUR.length]} /></div>)}
        </div>
      ) : (
        <div key={landKey} className="p3-land-bounce">
          {cells.map((s, row) => {
            const k = `${index}-${row}`, on = lit?.has(k), t = trig?.has(k);
            return (
              <div key={row} className={`relative aspect-square p-0.5 ${lit?.size && !on && !t ? 'p3-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'p3-win' : ''} ${t ? 'bk-trig' : ''}`} style={{ '--glow': '#facc15' }}><BrickSym s={s} /></div>
                {(on || t) && <Burst key={landKey} game="brick" n={t ? 10 : 6} spread={40} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** The free-spin building site: frames, hats, saws, the Mega Hat and the reveal. */
function FreeBoard({ frames, hats, built, flyers, saw, sawsShown, mega, reveal, floats, bet }) {
  const houseAt = useMemo(() => Object.fromEntries((reveal?.houses || []).map((h) => [key(...h.cell), h])), [reveal]);
  return (
    <div className="relative w-full rounded-lg bg-[linear-gradient(180deg,#a16207_0%,#7c4a1e_100%)]" style={{ aspectRatio: '5 / 3' }}>
      <div className="absolute inset-0 grid grid-cols-5 grid-rows-3">
        {Array.from({ length: 15 }, (_, i) => {
          const c = i % 5, r = Math.floor(i / 5), k = key(c, r), tier = frames[k] || 0, h = houseAt[k];
          return (
            <div key={k} className="relative p-[3px]">
              <div className={`relative h-full w-full overflow-hidden rounded-md ${tier ? FRAME[tier] : 'bg-[#5b3a1e]/60 ring-1 ring-inset ring-black/20'}`}>
                {!tier && <div className="absolute inset-0 opacity-25 [background-image:repeating-linear-gradient(45deg,#00000033_0_4px,transparent_4px_10px)]" />}
                {tier > 0 && !h && (
                  <div key={`${k}-${tier}-${built[k] || 0}`} className="bk-build absolute inset-0 flex items-center justify-center">
                    <svg viewBox="0 0 100 100" className="h-[80%] w-[80%] opacity-45" aria-hidden="true"><House tier={tier} /></svg>
                    <span className={`absolute left-1 top-1 rounded px-1 text-[8px] font-extrabold uppercase leading-tight sm:text-[10px] ${CHIP[tier]}`}>{TIER[tier]}</span>
                  </div>
                )}
                {h && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    {h.st === 'house'
                      ? <svg viewBox="0 0 100 100" className="bk-build h-[92%] w-[92%]" aria-hidden="true"><House tier={h.tier} /></svg>
                      : <>
                        <svg viewBox="0 0 100 100" className="bk-blow absolute h-[92%] w-[92%]" aria-hidden="true"><House tier={h.tier} /></svg>
                        <div className={`bk-pop relative rounded-md px-1 text-center font-display leading-none text-white drop-shadow-[0_2px_2px_rgba(0,0,0,.8)] ${typeof h.prize === 'number' ? 'text-sm sm:text-xl' : 'bg-purple-700/80 py-0.5 text-[11px] sm:text-base'}`}>{prizeLabel(h.prize, bet)}</div>
                      </>}
                  </div>
                )}
                {sawsShown?.has(k) && <svg viewBox="0 0 100 100" className="bk-pop absolute inset-[8%] z-10" aria-label="Buzz saw"><BuzzSaw /></svg>}
              </div>
            </div>
          );
        })}
      </div>
      {hats.map((h) => (
        <div key={h.id} className="pointer-events-none absolute z-30" style={{ left: `${h.cell[0] * 20}%`, top: `${h.cell[1] * 33.333}%`, width: '20%', height: '33.333%' }}>
          <div className="bk-hatshadow absolute inset-x-[18%] bottom-[8%] h-[14%] rounded-[50%] bg-black/45 blur-[2px]" />
          <svg viewBox="0 0 100 100" className="bk-hatfall absolute inset-[4%] drop-shadow-[0_6px_6px_rgba(0,0,0,0.5)]" aria-label="Hard hat lands"><HardHat /></svg>
          <div className="bk-landring absolute inset-[10%] rounded-full border-4 border-yellow-200" />
        </div>
      ))}
      {flyers.map((f) => (
        <svg key={f.id} viewBox="0 0 100 100" className="bk-fly pointer-events-none absolute z-20 p-[2%]" aria-hidden="true"
          style={{ left: `${f.from[0] * 20}%`, top: `${f.from[1] * 33.333}%`, width: '20%', height: '33.333%', '--dx': `${(f.to[0] - f.from[0]) * 100}%`, '--dy': `${(f.to[1] - f.from[1]) * 100}%` }}><HardHat glow={false} /></svg>
      ))}
      {floats.map((f) => (
        <div key={f.id} className="pointer-events-none absolute z-40 flex items-start justify-center" style={{ left: `${f.cell[0] * 20}%`, top: `${f.cell[1] * 33.333}%`, width: '20%', height: '33.333%' }}>
          <span className={`bk-label mt-[4%] whitespace-nowrap rounded-md px-1.5 py-0.5 font-display text-[11px] leading-none shadow-lg sm:text-base ${f.tier ? CHIP[f.tier] : 'bg-yellow-300 text-amber-950'}`}>{f.text}</span>
        </div>
      ))}
      {saw && (
        <svg viewBox="0 0 100 100" className="pointer-events-none absolute z-20 drop-shadow-[0_0_12px_rgba(255,255,255,0.8)]" aria-label="Buzz saw"
          style={{ left: `${saw.c * 20}%`, top: `${saw.r * 33.333}%`, width: '20%', height: '33.333%', transition: `left ${saw.ms || 200}ms linear` }}><BuzzSaw /></svg>
      )}
      {mega && (
        <div className="bk-mega pointer-events-none absolute z-20 flex items-center justify-center" style={{ left: `${mega.col * 20}%`, top: `${mega.row * 33.333}%`, width: `${mega.w * 20}%`, height: `${mega.h * 33.333}%` }}>
          <svg viewBox="0 0 100 100" className="h-full max-w-full drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)]" aria-label="Mega hat"><HardHat /></svg>
        </div>
      )}
    </div>
  );
}

function Wolf({ mood, anim, say }) {
  return (
    <div className="relative flex shrink-0 items-end">
      <svg key={anim} viewBox="0 0 100 100" className={`h-14 w-14 drop-shadow-[0_3px_4px_rgba(0,0,0,0.5)] sm:h-16 sm:w-16 ${anim || 'bk-bob'}`} role="img" aria-label="Wolf">
        <WolfFace mood={mood} />
      </svg>
      {anim === 'bk-huff' && <svg viewBox="0 0 60 30" className="bk-wind absolute left-full top-1/3 h-6 w-16" aria-hidden="true"><path d="M2 8H50M8 15H58M2 22H44" stroke="#e0f2fe" strokeWidth="3" strokeLinecap="round" /></svg>}
      {say && <div key={say} className="bk-pop absolute bottom-full left-8 z-10 mb-1 w-max max-w-[11rem] rounded-xl bg-white px-2 py-1 text-[11px] font-bold leading-tight text-slate-800 shadow-lg">{say}</div>}
    </div>
  );
}

function Switch({ label, hint, on, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!on)} aria-pressed={on} className="flex w-full items-center justify-between gap-4 rounded-lg bg-navy-800 px-3 py-2.5 text-left text-sm text-slate-200 hover:bg-navy-700">
      <span>{label}{hint && <span className="block text-[11px] text-slate-500">{hint}</span>}</span>
      <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? 'bg-amber-400' : 'bg-navy-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
    </button>
  );
}

const pays = (bet, h) => money(Math.floor((bet * h) / 100));
const pct = (pairs) => { const t = pairs.reduce((a, [, w]) => a + w, 0); return (w) => `${((w / t) * 100).toFixed(w / t < 0.01 ? 2 : 0)}%`; };

export default function Brick() {
  const { user, view, history, play, commit, guard: rawGuard, shake, doShake } = usePremium('brick');
  const [tick, setTick] = useState(0);
  const guard = (fn) => rawGuard(fn).finally(() => setTick((n) => n + 1));
  const fx = useMemo(() => brickSfx(), []);
  const reels = useReelStops(5);
  const [scene, setScene] = useState('base');
  const [cells, setCells] = useState(START);
  const [lit, setLit] = useState(null);
  const [trig, setTrig] = useState(null);
  const [res, setRes] = useState(null);
  const [stake, setStake] = useState(100);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [tease, setTease] = useState([]);
  const [count, setCount] = useState({ hats: 0, saws: 0 });
  const [banner, setBanner] = useState(null);
  // free-spin board
  const [frames, setFrames] = useState({});
  const [built, setBuilt] = useState({});
  const [hats, setHats] = useState([]);
  const [flyers, setFlyers] = useState([]);
  const [floats, setFloats] = useState([]);
  const [saw, setSaw] = useState(null);
  const [sawsShown, setSawsShown] = useState(null);
  const [mega, setMega] = useState(null);
  const [reveal, setReveal] = useState(null);
  const [freeInfo, setFreeInfo] = useState(null);
  const [busyFx, setBusyFx] = useState(false);
  // wheel
  const [wheel, setWheel] = useState({ angle: 0, spinning: false, landed: null, source: 'saws' });
  // overlays
  const [wolf, setWolf] = useState({ mood: 'idle', anim: '', say: 'Spin, little piggies!' });
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [summary, setSummary] = useState(null);
  const [session, setSession] = useState({ staked: 0, won: 0 });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [turbo, setTurbo] = useState(() => pref('bk_turbo', false));
  const [space, setSpace] = useState(() => pref('bk_space', true));
  const [dev] = useState(devMode);
  const mode = view?.mode || 'base';
  // The server may already be a step ahead of the screen (mid-reveal, say);
  // controls follow what is on screen.
  const barMode = scene === mode ? mode : 'busy';
  const bet = freeInfo?.bet ?? view?.free?.bet ?? view?.wheel?.bet ?? stake;
  const t = useCallback((ms) => sleep(turbo ? ms * 0.45 : ms), [turbo]);
  const track = (out) => setSession((s) => ({ staked: s.staked + (out.staked || 0), won: s.won + (out.payout || 0) }));
  const react = (mood, anim = '', say = null, ms = 2600) => {
    setWolf({ mood, anim, say });
    if (say) setTimeout(() => setWolf((w) => (w.say === say ? { ...w, say: null } : w)), ms);
  };

  // After a refresh mid-feature, put the right screen back and offer to continue.
  const resumed = useRef(false);
  useEffect(() => {
    if (!view || resumed.current) return;
    resumed.current = true;
    if (view.mode === 'free') {
      setFrames(view.free.frames || {}); setFreeInfo({ kind: view.free.kind, remaining: view.free.remaining, played: view.free.played, bet: view.free.bet });
      setScene('free'); setIntro({ type: view.free.kind, resume: true });
    } else if (view.mode === 'wheel') {
      setScene('wheel'); setWheel((w) => ({ ...w, landed: null, source: view.wheel.source })); setIntro({ type: view.wheel.source === 'brick' ? 'brickwheel' : 'wheel', resume: true });
    }
  }, [view]);

  const bigResolve = useRef(null);
  const showBig = (b) => new Promise((r) => { bigResolve.current = r; setBig(b); });
  const introResolve = useRef(null);
  const showIntro = (i) => new Promise((r) => { introResolve.current = r; setIntro(i); });
  const sumResolve = useRef(null);
  const showSummary = (s) => new Promise((r) => { sumResolve.current = r; setSummary(s); });

  // ── feature entry and the pre-feature animations ────────────────────────
  const runPre = async (kind, pre, final) => {
    setBusyFx(true);
    try {
      if (kind === 'buzzsaw' && pre?.sweep) {
        const f = {};
        for (const step of pre.sweep) {
          const [c0, r] = step.saw;
          setSaw({ c: c0, r, ms: 0 }); fx.saw(0.5 + step.path.length * 0.22); await t(250);
          for (let i = 0; i < step.path.length; i++) {
            const a = step.path[i], tgt = a.redirect || a.cell;
            setSaw({ c: c0 + i, r, ms: 200 }); await t(210);
            if (a.redirect) { const id = Math.random(); setFlyers((x) => [...x, { id, from: a.cell, to: a.redirect }]); setTimeout(() => setFlyers((x) => x.filter((y) => y.id !== id)), 500); }
            f[key(...tgt)] = a.to; setFrames({ ...f }); setBuilt((b) => ({ ...b, [key(...tgt)]: (b[key(...tgt)] || 0) + 1 })); fx.hammer(a.to);
          }
          setSaw({ c: 5.2, r, ms: 260 }); await t(320); setSaw(null);
        }
      } else if (kind === 'mansions' && pre?.bricks) {
        setSawsShown(new Set(pre.bricks.map((b) => key(...b.cell)))); fx.saw(0.5); await t(900);
        const f = {};
        for (const b of pre.bricks) { setSawsShown((s) => { const n = new Set(s); n.delete(key(...b.cell)); return n; }); f[key(...b.cell)] = 3; setFrames({ ...f }); fx.hammer(3); await t(420); }
        setSawsShown(null);
      } else if (kind === 'megahat' && pre?.mega) {
        setMega(pre.mega); fx.hat(0); await t(950); fx.hammer(1);
        const f = {}; pre.mega.cells.forEach((c) => { f[key(...c)] = 1; });
        setFrames(f); await t(700); setMega(null);
      }
      setFrames(final);
    } finally { setBusyFx(false); }
  };

  const enterFree = async (started, bet0) => {
    const kind = started.kind;
    setReveal(null); setHats([]);
    setFrames(kind === 'hats' ? started.frames : {});
    setFreeInfo({ kind, remaining: started.spins, played: 0, bet: bet0 });
    if (kind === 'hats') fx.hatIntro(); else fx.sawIntro();
    setScene('free');
    await showIntro({ type: kind });
    if (kind !== 'hats') await runPre(kind, started.pre, started.frames);
  };
  const enterWheel = async (started) => {
    setScene('wheel'); setWheel((w) => ({ ...w, landed: null, spinning: false, source: started.source }));
    fx.wheelIntro();
    await showIntro({ type: started.source === 'brick' ? 'brickwheel' : 'wheel' });
  };
  const handleStarted = async (out) => {
    if (out.started?.type === 'wheel') await enterWheel(out.started);
    else if (out.started?.type === 'free') await enterFree(out.started, out.bet);
    else if (out.mode === 'base') { setScene('base'); setFreeInfo(null); setReveal(null); setFrames({}); }
  };

  // ── base spins ──────────────────────────────────────────────────────────
  const spinBase = async () => {
    fx.click();
    setSpinning(true); setRes(null); setLit(null); setTrig(null); setTease([]); setBanner(null); setCount({ hats: 0, saws: 0 });
    react('idle', 'bk-bob');
    fx.spin(); setSpinId((n) => n + 1); reels.start();
    const out = await play('spin', { stake });
    if (!out) { reels.stopNow(); setSpinning(false); return; }
    track(out);
    setCells(out.grid);
    // anticipation: 4+ hats or 2 saws by a reel stretch the next reels
    const teaseReels = [];
    let h = 0, s = 0;
    out.grid.forEach((col, r) => { if (h >= 4 || s >= 2) teaseReels.push(r); h += col.filter((x) => x === 'HAT').length; s += col.filter((x) => x === 'SAW').length; });
    let ch = 0, cs = 0;
    await reels.stopAll({
      turbo, tease: teaseReels,
      onStop: (r) => {
        fx.stop(r);
        const col = out.grid[r];
        col.forEach((x) => { if (x === 'HAT') fx.hat(ch++); });
        if (col.includes('SAW')) { cs += col.filter((x) => x === 'SAW').length; fx.saw(0.35); }
        if (col.includes('WILD')) fx.wild?.();
        setCount({ hats: ch, saws: cs });
        if (teaseReels.includes(r + 1)) setTease([r + 1]);
      },
    });
    setTease([]);
    const litCells = new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`)));
    const tr = out.triggers || {};
    const trigCells = new Set([...(tr.hats ? out.hats : []), ...(tr.saws ? out.saws : [])].map(([r, c]) => `${r}-${c}`));
    if (litCells.size) { setLit(litCells); if (out.win) fx.win(out.win >= out.bet * 5 ? 2 : 1); }
    setRes(out); setSpinning(false);
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tr.hats || tr.saws) {
      setTrig(trigCells);
      if (tr.hats) { fx.hatTrigger(); react('wow', 'bk-shock', `${out.hats.length} hard hats?! Build away, I'll blow it all down!`, 3200); setBanner({ text: `${out.hats.length} HARD HATS!`, cls: 'from-yellow-200 to-amber-500 text-amber-950' }); }
      if (tr.saws) { await t(tr.hats ? 1300 : 0); fx.sawTrigger(); react('sad', 'bk-shock', 'Buzz saws! Yikes, mind my tail!', 3200); setBanner({ text: `${out.saws.length} BUZZ SAWS!`, cls: 'from-slate-100 to-slate-500 text-slate-900' }); }
      await t(1700);
    } else if (out.win) {
      if (tier >= 3) react('wow', 'bk-dance', 'WHAT?! That much?!');
      else react('happy', '', pick(['Lucky snouts!', 'Not bad, piggies.', 'Hmph, a little win.']));
      await t(900);
    } else react('idle', 'bk-bob', Math.random() < 0.15 ? pick(['Come on, build something!', 'I\'m getting hungry…', 'Spin it again!']) : null);
    commit();
    if (tier >= 3 && out.win) { fx.big(); doShake(tier >= 4); await showBig({ amount: out.win }); }
    setBanner(null);
    if (out.started) { setTrig(null); setLit(null); await handleStarted(out); }
  };

  // ── free spins and the wolf's reveal ────────────────────────────────────
  const doReveal = async (out) => {
    const rv = out.reveal, b = out.bet;
    setHats([]);
    setReveal({ houses: rv.houses.map((h) => ({ ...h, st: 'house' })), total: 0 });
    fx.hammer(3);
    react('wow', '', 'I\'ll huff… and I\'ll puff…', 2400);
    await t(1500);
    let total = 0;
    for (const tier of [1, 2, 3]) {
      const group = rv.houses.filter((h) => h.tier === tier);
      if (!group.length) continue;
      react('wow', 'bk-huff', { 1: 'Straw? Too easy!', 2: 'Sticks snap like twigs!', 3: 'Bricks?! Oof… HUFF!' }[tier], 1800);
      fx.huff(); await t(800);
      for (const h of group) {
        total += typeof h.x === 'number' ? h.x * b : 0;
        setReveal((r) => ({ ...r, total, houses: r.houses.map((x) => (x.cell[0] === h.cell[0] && x.cell[1] === h.cell[1] ? { ...x, st: 'blown' } : x)) }));
        if (typeof h.prize === 'string' && h.prize !== 'WHEEL') fx.jackpot(); else fx.blow(tier);
        await t(typeof h.prize === 'string' ? 900 : 300);
      }
      await t(500);
    }
    if (rv.prizesX) { setReveal((r) => ({ ...r, extraX: rv.prizesX })); fx.extra(); await t(700); }
    setReveal((r) => ({ ...r, total: rv.win, done: true }));
    react(rv.win >= b * 20 ? 'sad' : 'happy', rv.win >= b * 20 ? 'bk-shock' : '', rv.win >= b * 20 ? 'Those piggies built a fortune!' : 'Blown down!', 3000);
    await t(900);
  };

  const spinFree = async () => {
    const out = await play('spin', {});
    if (!out) return;
    track(out);
    setFloats([]);
    // Each hat falls onto its spot in turn, then hammers its frame in.
    const f = { ...frames };
    const label = (id, cell, text, tier) => { setFloats((x) => [...x, { id, cell, text, tier }]); setTimeout(() => setFloats((x) => x.filter((y) => y.id !== id)), 1600); };
    if (!out.applied.length) await t(500);
    for (let i = 0; i < out.applied.length; i++) {
      const a = out.applied[i], id = Math.random();
      setHats((h) => [...h, { id, cell: a.cell }]);
      await t(420);
      fx.hat(i);
      await t(120);
      if (a.prize) {
        label(id, a.cell, `+${a.prize}x BET`); fx.extra();
      } else {
        const tgt = a.redirect || a.cell;
        if (a.redirect) {
          const fid = Math.random(); setFlyers((x) => [...x, { id: fid, from: a.cell, to: a.redirect }]); setTimeout(() => setFlyers((x) => x.filter((y) => y.id !== fid)), 500);
          setHats((h) => h.filter((x) => x.id !== id)); await t(440);
        }
        f[key(...tgt)] = a.to; setFrames({ ...f }); setBuilt((bb) => ({ ...bb, [key(...tgt)]: (bb[key(...tgt)] || 0) + 1 })); fx.hammer(a.to);
        label(id, tgt, a.from ? `${TIER[a.to].toUpperCase()} ↑` : 'STRAW', a.to);
      }
      await t(420);
      setHats((h) => h.filter((x) => x.id !== id));
    }
    setFrames(out.frames);
    setHats([]);
    setFreeInfo((fi) => ({ ...fi, remaining: out.remaining, played: (fi?.played || 0) + 1 }));
    if (out.extra) { fx.extra(); setBanner({ text: '+1 SPIN!', cls: 'from-yellow-200 to-amber-500 text-amber-950' }); react('sad', '', 'More spins?! Grr…'); await t(1000); setBanner(null); }
    else if (out.hats.length) react('idle', '', out.applied.some((a) => a.to === 3) ? 'Bricks… not bricks!' : null, 1600);
    if (!out.reveal) { commit(); return; }
    await t(400);
    await doReveal(out);
    commit();
    fx.big();
    await showBig({ amount: out.win, title: `${KIND[out.finished.kind].title.replace(' BONUS', '')} WIN`, practice: out.practice });
    await showSummary({ ...out.finished, houses: out.reveal.houses.length, practice: out.practice, next: out.started });
    setReveal(null);
    await handleStarted(out);
  };

  // ── the wheel ───────────────────────────────────────────────────────────
  const spinWheel = () => guard(async () => {
    if (mode !== 'wheel' || wheel.spinning) return;
    fx.click(); fx.wheelStart();
    const out = await play('wheel', {});
    if (!out) return;
    track(out);
    const target = wheelTarget(wheel.angle, out.wedge, spinId + Math.floor(Math.random() * 1000));
    setWheel((w) => ({ ...w, angle: target, spinning: true, landed: null }));
    react('wow', '', 'Round and round…', 2000);
    const dur = turbo ? 2600 : 5000;
    let ms = 70; const until = performance.now() + dur - 300;
    while (performance.now() < until) { fx.tick(); await sleep(ms); ms = Math.min(420, ms * 1.08); }
    await sleep(Math.max(0, until + 300 - performance.now()));
    setWheel((w) => ({ ...w, spinning: false, landed: out.wedge }));
    await t(700);
    if (out.jackpot) {
      fx.jackpot(); commit(); doShake(out.jackpot.x >= 1000);
      react('sad', 'bk-shock', `The ${out.jackpot.name}?! Noooo!`, 3000);
      await showBig({ amount: out.win, title: `${out.jackpot.name.toUpperCase()} JACKPOT`, practice: out.practice });
      await handleStarted(out);
    } else {
      commit();
      await handleStarted(out);
    }
  });

  const devTrigger = (event, wedge) => guard(async () => {
    const out = await play('dev', { event, stake, wedge });
    if (!out?.started) return;
    if (event === 'hats') { fx.hatTrigger(); react('wow', 'bk-shock', 'Six hard hats?! Build away, I\'ll blow it all down!', 3000); }
    else { fx.sawTrigger(); react('sad', 'bk-shock', 'Buzz saws! Yikes, mind my tail!', 3000); }
    await handleStarted({ ...out, bet: stake });
  });

  const spin = () => guard(async () => {
    if (mode === 'base') await spinBase();
    else if (mode === 'free' && scene === 'free') await spinFree();
  });

  // Free spins run themselves once the board is ready (never paid spins).
  const ready = !spinning && !big && !intro && !summary && !settingsOpen && !busyFx;
  useEffect(() => {
    if (!ready || mode !== 'free' || scene !== 'free') return undefined;
    const id = setTimeout(spin, turbo ? 350 : 800);
    return () => clearTimeout(id);
  }, [ready, mode, scene, tick]); // eslint-disable-line react-hooks/exhaustive-deps

  // Space bar
  const spinRef = useRef(spin); spinRef.current = spin;
  const wheelRef = useRef(spinWheel); wheelRef.current = spinWheel;
  useEffect(() => {
    if (!space) return undefined;
    const h = (e) => {
      if (e.code !== 'Space' || e.repeat || ['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(e.target.tagName)) return;
      e.preventDefault();
      if (big) return;
      if (ready && barMode === 'base') spinRef.current();
      else if (ready && mode === 'wheel' && scene === 'wheel') wheelRef.current();
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [space, big, ready, mode, scene, barMode]);

  const low = mode === 'base' && (user?.balance ?? 0) < stake;
  const i = Math.max(0, STAKES.indexOf(stake));
  const practice = view?.practice;
  const detail = res?.wins?.length ? res.wins.slice(0, 3).map((w) => `${BRICK_NAMES[w.symbol]} ×${w.count}${w.ways > 1 ? ` · ${w.ways} ways` : ''}`).join(' · ') : '';
  const sessionNet = session.won - session.staked;
  const kindInfo = KIND[freeInfo?.kind] || KIND.hats;
  const houseCount = Object.keys(frames).length;
  const tierCount = [1, 2, 3].map((tr) => Object.values(frames).filter((v) => v === tr).length);

  const bar = (
    <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || barMode !== 'base' || i <= 0} onClick={() => { fx.click(); setStake(STAKES[i - 1]); }} aria-label="Lower bet">−</button>
          <div className="w-[4.4rem] text-center leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{mode === 'base' ? 'Bet' : 'Bonus bet'}</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(bet)}</div></div>
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || barMode !== 'base' || i >= STAKES.length - 1} onClick={() => { fx.click(); setStake(STAKES[i + 1]); }} aria-label="Raise bet">+</button>
        </div>
        {barMode === 'busy' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-amber-400/20 text-sm font-bold text-amber-100 ring-1 ring-amber-300/50">{reveal ? 'The wolf is huffing…' : 'Bonus in progress…'}</div>
        ) : mode === 'wheel' ? (
          <button onClick={spinWheel} disabled={wheel.spinning || !!intro || !!big || scene !== 'wheel'} className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-sky-200 to-blue-600 text-lg font-extrabold text-white shadow-lg active:scale-95">{wheel.spinning ? 'Spinning…' : 'Spin the wheel'}</button>
        ) : mode === 'free' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-amber-400/20 text-sm font-bold text-amber-100 ring-1 ring-amber-300/50">{reveal ? 'The wolf is huffing…' : `Free spins play automatically · ${freeInfo?.remaining ?? view?.free?.remaining ?? 0} left`}</div>
        ) : (
          <button onClick={spin} disabled={spinning || low || !!intro || !!summary || !!big}
            className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-yellow-200 to-amber-500 text-lg font-extrabold text-amber-950 shadow-lg transition-transform active:scale-95">
            {spinning ? 'Spinning…' : low ? 'Not enough balance' : 'Spin'}
          </button>
        )}
      </div>
      <div className="flex items-center justify-between gap-1.5 text-xs text-slate-400">
        <div className="flex gap-1.5">
          <button onClick={() => { const v = !turbo; setTurbo(v); save('bk_turbo', v); }} className={`rounded-md px-2.5 py-1 font-semibold ${turbo ? 'bg-amber-400 text-navy-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Quick</button>
          <button onClick={() => setSettingsOpen(true)} className="rounded-md bg-navy-700 px-2.5 py-1 font-semibold text-slate-200">Settings</button>
        </div>
        <div className="flex gap-3 text-right">
          <span>Win <b className="tabular-nums text-amber-200">{money(res?.win || 0)}</b></span>
          <span>Balance <b className="tabular-nums text-slate-200">{money(user?.balance ?? 0)}</b></span>
        </div>
      </div>
      {dev && barMode === 'base' && !spinning && (
        <div className="rounded-lg border border-dashed border-fuchsia-400/60 bg-fuchsia-500/10 p-2 text-xs text-fuchsia-100">
          <div className="mb-1 font-bold">Test mode (practice: costs and pays nothing)</div>
          <div className="flex flex-wrap gap-1">
            <button className="rounded bg-fuchsia-700 px-2 py-1" onClick={() => devTrigger('hats')}>6 hats</button>
            <button className="rounded bg-fuchsia-700 px-2 py-1" onClick={() => devTrigger('saws')}>3 saws</button>
            {WHEEL.map(([w]) => <button key={w} className="rounded bg-fuchsia-900 px-2 py-1" onClick={() => devTrigger('saws', w)}>Saws → {w}</button>)}
          </div>
        </div>
      )}
    </div>
  );

  const wp = pct(WHEEL);
  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to win</h3>
        <p>5 reels, 3 rows, <b>243 ways</b>. Matching symbols on adjacent reels from reel 1 (any row) pay; each combination of positions is a way, so two matching symbols on one reel double the win. The <b className="text-amber-200">Wolf Wild</b> lands on reels 2, 3 and 4 and substitutes for every symbol except hard hats and buzz saws. Reels sometimes land fully stacked with one symbol.</p>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">Paytable per way at {money(bet)}</h3>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(PAYTABLE).map(([s, p]) => (
            <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
              <div className="h-11 w-11 shrink-0"><BrickSym s={s} /></div>
              <div className="min-w-0 text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">{BRICK_NAMES[s]}</div>{p.map((v, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{pays(bet, v)}</b></div>)}</div>
            </div>
          ))}
        </div>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Hard Hat Bonus (6 or more hats)</h3>
        <div className="flex gap-2"><div className="h-10 w-10 shrink-0"><BrickSym s="HAT" /></div><p><b>{HAT_TRIGGER} or more hard hats</b> anywhere start {FREE_SPINS} free spins at the same bet. Every triggering hat leaves a <b className="text-yellow-200">straw frame</b> on its spot.</p></div>
        <ul className="list-disc space-y-1 pl-5">
          <li>During free spins only hard hats land. A hat on an empty spot starts a straw frame; on a frame it upgrades it: straw → <b className="text-amber-400">stick</b> → <b className="text-red-400">brick</b>.</li>
          <li>A hat on a brick frame upgrades a different frame instead (or starts a new straw frame if none can be upgraded). With all 15 spots brick, a hat is worth 2x the bet.</li>
          <li>{EXTRA_SPIN_HATS} or more hats in one free spin add 1 spin.</li>
          <li>When the spins run out, every frame becomes a house and the wolf blows them down, straw first, then stick, then brick. Each house pays what's inside, added together:</li>
          <li className="ml-4 list-[circle]">Straw: {HOUSE[1].map(([v]) => `${v}x`).join(', ')}.</li>
          <li className="ml-4 list-[circle]">Stick: {HOUSE[2].map(([v]) => (typeof v === 'number' ? `${v}x` : JP_NAME[v])).join(', ')}.</li>
          <li className="ml-4 list-[circle]">Brick: {HOUSE[3].map(([v]) => (typeof v === 'number' ? `${v}x` : v === 'WHEEL' ? 'a wheel spin' : JP_NAME[v])).join(', ')}.</li>
        </ul>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Buzz Saw Wheel (3 or more saws)</h3>
        <div className="flex gap-2"><div className="h-10 w-10 shrink-0"><BrickSym s="SAW" /></div><p><b>{SAW_TRIGGER} or more buzz saws</b> (at most one per reel) award one spin of the bonus wheel. Tap Spin the wheel; the result was fixed when the saws landed.</p></div>
        <ul className="list-disc space-y-1 pl-5">
          <li><b>Buzz Saw Bonus</b> ({wp(WHEEL[0][1])}): each saw slides right to the edge of the reels, rightmost first; every spot it crosses gets a hat (frame or upgrade). Then {FREE_SPINS} free spins.</li>
          <li><b>Mansions Bonus</b> ({wp(WHEEL[1][1])}): a brick frame on every spot where a saw landed. Then {FREE_SPINS} free spins.</li>
          <li><b>Mega Hat Bonus</b> ({wp(WHEEL[2][1])}): a giant 2×2, 3×3 or 5×3 hat drops and frames every spot under it. Then {FREE_SPINS} free spins.</li>
          <li>Jackpots: Mini {wp(WHEEL[3][1])}, Minor {wp(WHEEL[4][1])}, Major {wp(WHEEL[5][1])}, Grand {wp(WHEEL[6][1])}.</li>
        </ul>
        <p>If hats and saws trigger together, the wheel comes first, then the Hard Hat Bonus. Wheel bonuses play like the Hard Hat Bonus, but their brick houses can't award another wheel spin.</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Jackpots</h3>
        <div className="grid grid-cols-5 gap-1.5 text-center text-[11px]">{Object.entries(JACKPOTS).map(([id, x]) => <div key={id} className="rounded-lg bg-navy-800 p-1"><div className="font-bold text-white">{JP_NAME[id]}</div><div>{x.toLocaleString()}x</div><div className="text-amber-200">{money(x * bet)}</div></div>)}</div>
        <p className="text-xs">Fixed multiples of the bet, not progressive.</p>
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Maths</b>: long-run return about 96% (our own tuning, measured by simulation; not the original game's certified RTP). High volatility: about half the return comes from the bonuses. Hard Hat Bonus about 1 in 210 spins, Buzz Saw Wheel about 1 in 255. Maximum win {MAX_WIN_X.toLocaleString()}x the bet per spin or bonus. Results are decided by the server's random number generator before anything moves; tapping, timing or reloading can't change them.
      </section>
      <section className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3 text-xs text-slate-300">
        <b className="text-amber-200">About this game</b>: Brick by Brick is an original game built on the published rules of Light &amp; Wonder's <i>Huff N' Puff</i> family (mainly <i>Huff N' More Puff</i> and <i>Huff N' Even More Puff</i>). Art, characters, names and sound are our own. Exact symbol pays, prize tables and odds aren't published; the values here are our own. Some later variants (gold saws, upgrade wedges, mystery symbols, larger grids) are not included.
      </section>
    </>
  );

  const introCfg = intro && KIND[intro.type];
  return (
    <PremiumShell game="brick" rtp="96%" tagline="5 × 3 · 243 ways · Hard Hat Bonus · Buzz Saw Wheel · 5 jackpots" shake={shake}
      stageClass={`border-2 ${scene === 'free' ? 'border-yellow-300/70 shadow-[0_0_60px_rgba(250,204,21,0.3)]' : scene === 'wheel' ? 'border-sky-300/60 shadow-[0_0_60px_rgba(56,189,248,0.3)]' : 'border-amber-300/50 shadow-[0_0_60px_rgba(251,191,36,0.25)]'}`}
      bg={<BuildSite mode={scene} />}
      below={<>{bar}
        <Modal open={settingsOpen} onClose={() => setSettingsOpen(false)} title="Settings">
          <div className="space-y-2">
            <Switch label="Quick spins" hint="Shorter reel and feature animations" on={turbo} onChange={(v) => { setTurbo(v); save('bk_turbo', v); }} />
            <Switch label="Space bar to spin" hint="Desktop keyboards" on={space} onChange={(v) => { setSpace(v); save('bk_space', v); }} />
            <p className="px-1 pt-1 text-[11px] text-slate-500">Music and sound effects have separate switches and volume sliders under Sound, top right. Sound only starts after your first tap.</p>
          </div>
        </Modal>
      </>}
      info={info}
      side={<>
        <SidePanel title="This session">
          <div className="space-y-1 text-xs text-slate-300">
            <div className="flex justify-between"><span>Staked</span><b className="tabular-nums text-white">{money(session.staked)}</b></div>
            <div className="flex justify-between"><span>Won</span><b className="tabular-nums text-white">{money(session.won)}</b></div>
            <div className="flex justify-between"><span>Net</span><b className={`tabular-nums ${sessionNet >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>{sessionNet >= 0 ? '+' : '−'}{money(Math.abs(sessionNet))}</b></div>
          </div>
        </SidePanel>
        <SidePanel title="Features">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-yellow-200">{HAT_TRIGGER}+ hard hats</b>: Hard Hat Bonus, {FREE_SPINS} free spins.</li>
            <li><b className="text-slate-100">{SAW_TRIGGER}+ buzz saws</b>: Buzz Saw Wheel (bonus or jackpot).</li>
            <li><b className="text-amber-200">Wolf Wild</b> on reels 2–4.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      <div className={`relative pt-1 ${turbo ? 'mr-turbo' : ''}`}>
        {practice && <div className="mb-2 rounded-md bg-fuchsia-600/80 px-2 py-1 text-center text-xs font-bold text-white">PRACTICE ROUND: no stake, no payout</div>}
        {scene === 'free' && (
          <div className="mb-2 flex flex-wrap items-center justify-between gap-1.5">
            <div className="rounded-md bg-yellow-200 px-2.5 py-1 text-xs font-extrabold uppercase text-amber-950 shadow-[0_0_16px_rgba(253,224,71,0.7)]">{kindInfo.short} · {freeInfo?.remaining ?? 0} spin{freeInfo?.remaining === 1 ? '' : 's'} left</div>
            <div className="flex gap-1 text-[10px] font-bold">
              {[1, 2, 3].map((tr) => <span key={tr} className={`rounded px-1.5 py-1 ${CHIP[tr]}`}>{TIER[tr]} {tierCount[tr - 1]}</span>)}
              {reveal && <span className="rounded bg-black/60 px-1.5 py-1 text-yellow-100 ring-1 ring-yellow-300/50">Total {money(reveal.total)}</span>}
            </div>
          </div>
        )}
        <div className="relative mx-auto rounded-2xl bg-[linear-gradient(160deg,#fef3c7,#b7793f_30%,#6b3d18_65%,#facc15_90%)] p-[4px] shadow-[0_0_30px_rgba(250,204,21,0.3)]" style={{ maxWidth: scene === 'wheel' ? undefined : 'min(100%, calc((100dvh - 470px) * 1.67 + 24px))' }}>
          <div className="relative rounded-[12px] bg-[#2a1608]/80 p-1.5 backdrop-blur-sm">
            {scene === 'wheel' ? (
              <div className="py-2">
                <BonusWheel angle={wheel.angle} spinning={wheel.spinning} landed={wheel.landed} />
                <div className="mt-2 text-center font-display text-lg text-white drop-shadow">{wheel.landed ? (KIND[{ BUZZSAW: 'buzzsaw', MANSIONS: 'mansions', MEGAHAT: 'megahat' }[wheel.landed]]?.short || `${JP_NAME[wheel.landed]} jackpot`) : wheel.source === 'brick' ? 'Brick House Wheel' : 'Buzz Saw Wheel'}</div>
              </div>
            ) : scene === 'free' ? (
              <FreeBoard frames={frames} hats={hats} built={built} flyers={flyers} saw={saw} sawsShown={sawsShown} mega={mega} reveal={reveal} floats={floats} bet={bet} />
            ) : (
              <div className="relative">
                <div className="grid grid-cols-5 gap-1 sm:gap-1.5">
                  {[0, 1, 2, 3, 4].map((r) => <Reel key={r} index={r} cells={cells[r]} spinning={!reels.stopped[r]} landKey={`${spinId}-${r}`} lit={lit} trig={trig} turbo={turbo} tease={tease.includes(r) && !reels.stopped[r]} />)}
                </div>
                {(spinning || count.hats + count.saws > 0) && (
                  <div className="pointer-events-none absolute right-1 top-1 z-20 flex gap-1 text-[10px] font-extrabold">
                    {count.hats > 0 && <span className={`rounded-full px-1.5 py-0.5 ${count.hats >= HAT_TRIGGER ? 'bg-yellow-300 text-amber-950' : 'bg-black/60 text-yellow-200'}`}>Hats {count.hats}/{HAT_TRIGGER}</span>}
                    {count.saws > 0 && <span className={`rounded-full px-1.5 py-0.5 ${count.saws >= SAW_TRIGGER ? 'bg-slate-100 text-slate-900' : 'bg-black/60 text-slate-100'}`}>Saws {count.saws}/{SAW_TRIGGER}</span>}
                  </div>
                )}
              </div>
            )}
            {banner && <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center"><div className={`bk-pop rounded-2xl bg-gradient-to-b px-5 py-2 font-display text-3xl shadow-2xl sm:text-5xl ${banner.cls}`}>{banner.text}</div></div>}
          </div>
        </div>
        <div className="mt-2 flex min-h-14 items-center gap-2 rounded-xl bg-black/45 px-2 py-1 backdrop-blur-sm">
          <Wolf mood={wolf.mood} anim={wolf.anim} say={wolf.say} />
          <div className="min-w-0 flex-1 text-center leading-tight">
            {scene === 'free' ? (
              reveal ? <div className="font-display text-xl text-yellow-200">{reveal.done ? 'Bonus win ' : ''}{money(reveal.total)}{reveal.extraX ? <span className="block text-[11px] font-sans text-white/75">includes {reveal.extraX}x from all-brick hats</span> : null}</div>
                : <div className="text-sm text-white/80">{houseCount} frame{houseCount === 1 ? '' : 's'} built · hats upgrade them</div>
            ) : scene === 'wheel' ? <div className="text-sm text-white/80">{wheel.spinning ? 'The wheel is spinning…' : 'Tap Spin the wheel'}</div>
              : res?.win ? <><WinAmount win={res.win} staked={res.staked} />{detail && <div className="mt-0.5 truncate text-[11px] text-white/75">{detail}</div>}</>
                : <div className="text-sm text-white/65">{spinning ? 'Building…' : res ? 'No win this time' : `${HAT_TRIGGER} hats or ${SAW_TRIGGER} saws start a bonus`}</div>}
          </div>
        </div>
        {intro && introCfg && (
          <FeatureIntro title={introCfg.title} subtitle={intro.resume ? 'Your bonus is still in progress. Carry on where you left off.' : introCfg.text}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-28 w-28" aria-hidden="true">{intro.type === 'hats' ? <HardHat /> : intro.type === 'mansions' ? <House tier={3} /> : intro.type === 'megahat' ? <HardHat /> : <BuzzSaw />}</svg>}
            className={introCfg.cls} cta={intro.resume ? 'Continue' : introCfg.cta}
            onStart={() => { fx.click(); setIntro(null); introResolve.current?.(); introResolve.current = null; }} />
        )}
        {summary && !big && (
          <FeatureIntro title={`${KIND[summary.kind].title.replace(' BONUS', '')} COMPLETE`}
            subtitle={`${summary.played} free spins built ${summary.houses} house${summary.houses === 1 ? '' : 's'} worth ${money(summary.total)}.${summary.practice ? ' Practice round: nothing was paid.' : ''}${summary.next?.type === 'wheel' ? ' A brick house hid a wheel spin!' : summary.next?.type === 'free' ? ' Next: the Hard Hat Bonus.' : ''}`}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-24 w-24" aria-hidden="true"><WolfFace mood="sad" /></svg>}
            className="bg-[radial-gradient(ellipse_at_top,rgba(120,53,15,0.96),rgba(20,10,2,0.97))]" cta={summary.next ? 'Continue' : 'Back to the reels'}
            onStart={() => { setSummary(null); sumResolve.current?.(); sumResolve.current = null; }} />
        )}
        {big && <BigWin game="brick" amount={big.amount} bet={bet} title={big.title} onDone={() => { setBig(null); bigResolve.current?.(); bigResolve.current = null; }}
          cinematic={big.practice ? <div className="pointer-events-none absolute inset-x-0 bottom-[6%] z-10 text-center"><span className="rounded-full bg-fuchsia-600 px-3 py-1 text-xs font-extrabold text-white">PRACTICE ROUND · NOT PAID</span></div> : null} />}
      </div>
    </PremiumShell>
  );
}
