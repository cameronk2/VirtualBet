// Mystery of the Mummy – the tomb: sandstone walls with gold hieroglyph
// bands, statues, a sarcophagus, torches, light shafts and drifting sand.
import { useMemo } from 'react';
import { reduceMotion } from '../../../components/Premium.jsx';
import { Glyphs } from '../../../components/SlotArtMummy.jsx';

const MOOD = {
  base: 'bg-[radial-gradient(ellipse_at_50%_30%,#6b4a24,#2a1a0b_55%,#0b0704)]',
  free: 'bg-[radial-gradient(ellipse_at_50%_30%,#0f766e,#123b37_50%,#04100f)]',
  cash: 'bg-[radial-gradient(ellipse_at_50%_30%,#065f46,#0b2a1d_55%,#020a06)]',
  jackpot: 'bg-[radial-gradient(ellipse_at_50%_30%,#a16207,#3b2a0b_55%,#0b0704)]',
};

function Statue({ flip }) {
  return (
    <svg viewBox="0 0 60 200" className={`h-full w-auto ${flip ? '-scale-x-100' : ''}`} aria-hidden="true">
      <path d="M8 200V182H52V200Z" fill="#3b2a17" />
      <path d="M14 182L18 110C16 96 20 84 30 82C40 84 44 96 42 110L46 182Z" fill="#1c140b" />
      <path d="M22 84L18 56L28 70ZM38 84L42 56L32 70Z" fill="#1c140b" />
      <path d="M24 70C24 60 36 60 36 70L44 80L34 84H26Z" fill="#1c140b" />
      <path d="M18 120H42M17 132H43" stroke="#a16207" strokeWidth="2" opacity=".55" />
      <path d="M44 120L54 112V40" stroke="#a16207" strokeWidth="2.5" opacity=".7" fill="none" />
      <circle cx="54" cy="36" r="4" fill="none" stroke="#a16207" strokeWidth="2" opacity=".7" />
      <circle cx="31" cy="72" r="1.2" fill="#fcd34d" />
    </svg>
  );
}

export default function TombScene({ mode = 'base' }) {
  const grains = useMemo(() => (reduceMotion ? [] : Array.from({ length: 26 }, (_, i) => ({ x: (i * 41) % 100, y: (i * 29) % 100, d: `${-(i * 0.7)}s`, t: `${7 + (i % 6)}s`, s: 1 + (i % 3) }))), []);
  return (
    <>
      <div className={`absolute inset-0 transition-[background] duration-1000 ${MOOD[mode] || MOOD.base}`} />
      {/* stone blocks */}
      <div className="absolute inset-0 opacity-25 [background-image:repeating-linear-gradient(0deg,rgba(0,0,0,0.55)_0_2px,transparent_2px_46px),repeating-linear-gradient(90deg,rgba(0,0,0,0.4)_0_2px,transparent_2px_92px)]" />
      {/* gold hieroglyph bands */}
      <svg viewBox="0 0 400 18" preserveAspectRatio="none" className="absolute inset-x-0 top-[6%] h-5 w-full opacity-70" aria-hidden="true"><rect width="400" height="18" fill="#2a1a08" opacity=".6" /><g transform="scale(4 1)"><Glyphs fill="#fcd34d" w={100} /></g></svg>
      <svg viewBox="0 0 400 18" preserveAspectRatio="none" className="absolute inset-x-0 bottom-[16%] h-5 w-full opacity-60" aria-hidden="true"><rect width="400" height="18" fill="#2a1a08" opacity=".6" /><g transform="scale(4 1)"><Glyphs fill="#5eead4" w={100} /></g></svg>
      {/* light shafts */}
      <div className="mm-ray absolute left-[18%] top-0 h-[80%] w-[18%] -skew-x-12 bg-[linear-gradient(180deg,rgba(253,230,138,0.35),transparent)] blur-md" />
      <div className="mm-ray absolute right-[20%] top-0 h-[70%] w-[14%] skew-x-12 bg-[linear-gradient(180deg,rgba(253,230,138,0.28),transparent)] blur-md" style={{ animationDelay: '-3s' }} />
      {/* sarcophagus */}
      <svg viewBox="0 0 120 60" className="absolute bottom-[3%] left-1/2 h-[14%] -translate-x-1/2 opacity-80" aria-hidden="true">
        <path d="M10 60L16 18C16 8 104 8 104 18L110 60Z" fill="url(#mmGold)" opacity=".85" />
        <path d="M20 22H100M18 34H102M16 46H104" stroke="#713f12" strokeWidth="2" />
        <ellipse cx="60" cy="18" rx="12" ry="7" fill="url(#mmTurq)" />
      </svg>
      {/* statues */}
      <div className="absolute bottom-[2%] left-[1%] h-[46%] opacity-90 sm:left-[3%]"><Statue /></div>
      <div className="absolute bottom-[2%] right-[1%] h-[46%] opacity-90 sm:right-[3%]"><Statue flip /></div>
      {/* torches */}
      {[0, 1].map((side) => (
        <div key={side} className={`absolute top-[24%] ${side ? 'right-[6%]' : 'left-[6%]'} flex flex-col items-center`}>
          <div className="p3-torch h-7 w-4 rounded-[50%_50%_40%_40%] bg-[radial-gradient(circle_at_50%_70%,#fef08a,#f97316_55%,transparent_75%)] blur-[0.5px]" style={{ animationDelay: `${-side * 0.3}s` }} />
          <div className="h-8 w-2 rounded-b bg-amber-900" />
          <div className="absolute -top-8 h-24 w-24 rounded-full bg-[radial-gradient(circle,rgba(251,146,60,0.35),transparent_70%)]" />
        </div>
      ))}
      {/* drifting sand */}
      {grains.map((g, i) => <span key={i} className="mr-mote absolute rounded-full bg-amber-200/80" style={{ left: `${g.x}%`, top: `${g.y}%`, width: g.s, height: g.s, '--dx': '40px', '--t': g.t, animationDelay: g.d }} />)}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(0,0,0,0.65))]" />
    </>
  );
}

/** Stone doors that slide open (bonus entry). */
export function TombDoors({ onDone }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-50 overflow-hidden rounded-2xl" onAnimationEnd={(e) => { if (e.animationName === 'p3-door-r') onDone?.(); }}>
      {['l', 'r'].map((s) => (
        <div key={s} className={`p3-door-${s} absolute inset-y-0 ${s === 'l' ? 'left-0 border-r-4' : 'right-0 border-l-4'} w-1/2 border-amber-900 bg-[linear-gradient(180deg,#d6a85b,#8a5a2b)]`} style={{ animationDelay: '.5s', animationDuration: '1.1s', animationFillMode: 'both' }}>
          <svg viewBox="0 0 100 300" preserveAspectRatio="none" className="h-full w-full opacity-60" aria-hidden="true">
            {Array.from({ length: 12 }, (_, i) => <g key={i} transform={`translate(8 ${12 + i * 24}) scale(.85)`}><Glyphs fill="#5b3a14" w={100} /></g>)}
          </svg>
          <div className={`absolute top-1/2 h-14 w-3 -translate-y-1/2 rounded bg-amber-950 ${s === 'l' ? 'right-3' : 'left-3'}`} />
        </div>
      ))}
    </div>
  );
}
