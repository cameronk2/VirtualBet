// Mystery of the Mummy – Cash Collect bonus screen (self-contained).
//
// The server resolves each bonus spin completely; this component replays it
// step by step, in the same order the logic ran:
//   move → land (every empty cell spins) → collect (prizes fly into the
//   Mummy, counter ticks up) → grow (with the extra spins) → late gems.
// What is shown always ends equal to the server's state.
import { useEffect, useRef, useState } from 'react';
import { CASH } from '../../../../../server/games/mummy/config.js';
import { Burst } from '../../../components/Premium.jsx';
import { CoinArt, GemArt, MummyFigure, gemLabel } from '../../../components/SlotArtMummy.jsx';
import { money } from '../../../lib/format.js';

const N = CASH.size;
const pct = (n) => `${(n / N) * 100}%`;
const centre = (z) => ({ x: ((z.col + z.size / 2) / N) * 100, y: ((z.row + z.size / 2) / N) * 100 });
const sync = (c) => c && { board: c.board.map((col) => col.slice()), zone: { ...c.zone }, respins: c.respins, gems: c.gems, total: c.total, level: c.level, step: c.step };
const coinTier = (v) => (v >= 250 ? 'ring-2 ring-rose-300 shadow-[0_0_18px_#fb7185]' : v >= 50 ? 'ring-2 ring-amber-200 shadow-[0_0_14px_#fcd34d]' : v >= 10 ? 'ring-1 ring-amber-300/70' : '');

function GemMeter({ gems, level }) {
  const max = CASH.powerUps[CASH.powerUps.length - 1].gems;
  const next = CASH.powerUps[level];
  return (
    <div className="rounded-lg bg-black/50 px-3 pb-2 pt-1.5 ring-1 ring-emerald-300/30">
      <div className="flex justify-between text-[11px] font-bold text-emerald-100">
        <span>Green gems collected: {gems}</span>
        <span>{!next ? 'Mummy at full size' : gems >= next.gems ? 'The Mummy is growing…' : `${next.gems - gems} more → ${next.size}×${next.size} +${next.spins}`}</span>
      </div>
      <div className="relative mt-1.5 h-3 rounded-full bg-white/10">
        <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-emerald-300 to-amber-300 shadow-[0_0_10px_#34d399] transition-all duration-500" style={{ width: `${Math.min(100, (gems / max) * 100)}%` }} />
        {CASH.powerUps.map((p, i) => (
          <div key={p.size} className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2" style={{ left: `${(p.gems / max) * 100}%` }}>
            <div className={`flex h-5 min-w-8 items-center justify-center rounded-full px-1 text-[10px] font-extrabold ${i < level ? 'bg-amber-300 text-amber-950 shadow-[0_0_8px_#fcd34d]' : 'bg-navy-900 text-emerald-100 ring-1 ring-emerald-300/60'}`}>{p.size}×{p.size}</div>
          </div>
        ))}
      </div>
      <div className="mt-1 flex justify-between text-[9px] text-emerald-200/60"><span>2×2</span>{CASH.powerUps.map((p) => <span key={p.gems}>{p.gems}</span>)}</div>
    </div>
  );
}

export default function CashCollectBonus({ cash, bet, running, lock, request, commit, fx, wait, doShake, onComplete }) {
  const [disp, setDisp] = useState(() => sync(cash));
  const [spinning, setSpinning] = useState(false);
  const [landed, setLanded] = useState([]);
  const [flyers, setFlyers] = useState([]);
  const [grow, setGrow] = useState(null);
  const [flash, setFlash] = useState(0);
  const [boom, setBoom] = useState(null);
  const [caption, setCaption] = useState(null);
  const busy = useRef(false);
  const key = useRef(0);

  // Resync with the server state whenever we're idle (start, refresh).
  useEffect(() => { if (!busy.current && cash) setDisp(sync(cash)); }, [cash?.step, cash?.respins, cash?.gems]); // eslint-disable-line react-hooks/exhaustive-deps

  const collect = async (items, z) => {
    for (const it of items) {
      const c = centre(z);
      const id = ++key.current;
      setFlyers((f) => [...f, { id, ...it, x0: ((it.c + 0.5) / N) * 100, y0: ((it.r + 0.5) / N) * 100, x1: c.x, y1: c.y }]);
      setDisp((d) => {
        const board = d.board.map((col) => col.slice());
        if (it.kind === 'gem') board[it.c][it.r] = null;
        return { ...d, board, total: d.total + it.v, gems: d.gems + (it.kind === 'gem' ? 1 : 0) };
      });
      if (it.kind === 'gem') fx.gem(key.current); else fx.coin();
      if (it.v >= 50) { setBoom({ id, x: ((it.c + 0.5) / N) * 100, y: ((it.r + 0.5) / N) * 100 }); fx.big(); doShake(it.v >= 250); }
      setTimeout(() => setFlyers((f) => f.filter((x) => x.id !== id)), 1300);
      await wait(it.v >= 50 ? 520 : 170);
    }
  };

  const growUp = async (ups) => {
    for (const u of ups) {
      setGrow({ ...u, id: ++key.current });
      setFlash((n) => n + 1);
      fx.powerUp(); doShake(u.size >= 5);
      await wait(350);
      setDisp((d) => ({ ...d, zone: { ...u.zone }, respins: d.respins + u.spins, level: d.level + 1 }));
      await wait(1700);
      setGrow(null);
    }
  };

  const spinOnce = () => lock(async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      fx.spin();
      const out = await request();
      if (!out) return;
      const waiting = disp.board.some((col) => col.some(Boolean));
      setCaption({ text: `Bonus spin ${(disp.step || 0) + 1}: the Mummy ${waiting ? 'steps toward the nearest green gem' : 'walks on'}`, tone: 'move' });
      // 1. the Mummy moves
      setDisp((d) => ({ ...d, zone: { ...out.moved }, respins: d.respins - 1 }));
      if (out.moved.col !== out.from.col || out.moved.row !== out.from.row) fx.mummy();
      setSpinning(true);
      await wait(650);
      // 2. symbols land
      setSpinning(false);
      setLanded(out.landed.map((l) => ({ ...l, id: ++key.current })));
      setDisp((d) => {
        const board = d.board.map((col) => col.slice());
        for (const l of out.landed) if (l.kind === 'gem') board[l.c][l.r] = { v: l.v };
        return { ...d, board };
      });
      out.landed.forEach((l, i) => setTimeout(() => (l.kind === 'gem' ? fx.gem(i) : fx.stop(i % 5)), i * 40));
      await wait(out.landed.length ? 750 : 350);
      const missed = out.landed.filter((l) => l.kind === 'coin' && !l.hit);
      const gotX = out.collected.reduce((a, c) => a + c.v, 0);
      if (!out.landed.length && !out.collected.length) setCaption({ text: 'Nothing landed this spin', tone: 'none' });
      else if (out.collected.length) setCaption({ text: `Collected ${money(Math.floor(gotX * bet))}${missed.length ? ` · ${missed.length} prize${missed.length > 1 ? 's' : ''} outside the Mummy missed` : ''}`, tone: 'win' });
      else setCaption({ text: `${missed.length ? `${missed.length} cash prize${missed.length > 1 ? 's' : ''} landed outside the Mummy: missed` : 'A green gem landed: the Mummy will walk to it'}`, tone: 'miss' });
      // 3. collection (cash prizes under the Mummy, then gems under it)
      await collect(out.collected, out.moved);
      if (out.landed.some((l) => l.kind === 'coin' && !l.hit)) fx.miss();
      await wait(350);
      setLanded([]);
      // 4. growth, then any gems now under the bigger Mummy
      for (const stage of out.growth) {
        await growUp([stage]);
        if (stage.collected.length) { await collect(stage.collected, stage.zone); await wait(300); }
      }
      // land exactly on the server's numbers
      if (out.view?.cash) setDisp(sync(out.view.cash));
      else setDisp((d) => ({ ...d, total: out.total, gems: out.gems, respins: 0, zone: { ...out.zone } }));
      commit();
      if (out.done) { setCaption({ text: `Bonus complete: ${money(Math.floor(out.total * bet))} collected`, tone: 'win' }); await wait(1400); onComplete(out, { size: out.zone.size, gems: out.gems }); }
    } finally {
      busy.current = false;
    }
  });

  // Auto-run the bonus spins once started
  const tick = useRef(0);
  const [, force] = useState(0);
  useEffect(() => {
    if (!running || !disp || disp.respins <= 0 || busy.current || grow) return undefined;
    const id = setTimeout(async () => { await spinOnce(); tick.current++; force((n) => n + 1); }, 1000);
    return () => clearTimeout(id);
  }); // runs after every render; guarded by busy/lock

  if (!disp) return null;
  const { zone } = disp;
  const landedAt = Object.fromEntries(landed.map((l) => [`${l.c}-${l.r}`, l]));
  return (
    <div>
      <div className="mb-2 grid grid-cols-3 items-stretch gap-1.5 text-center">
        <div className="rounded-lg bg-black/55 px-2 py-1 ring-1 ring-emerald-300/40">
          <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-200">Bonus spins</div>
          <div key={disp.respins} className="mm-pop font-display text-3xl leading-none text-white tabular-nums">{disp.respins}</div>
        </div>
        <div className="rounded-lg bg-gradient-to-b from-amber-400/25 to-black/60 px-2 py-1 ring-1 ring-amber-300/70">
          <div className="text-[10px] font-bold uppercase tracking-wider text-amber-200">Bonus win</div>
          <div key={Math.round(disp.total)} className="mm-pop font-cond text-2xl font-extrabold leading-none text-amber-100 tabular-nums drop-shadow-[0_0_8px_#fcd34d]">{money(Math.floor(disp.total * bet))}</div>
        </div>
        <div className="rounded-lg bg-black/55 px-2 py-1 ring-1 ring-emerald-300/40">
          <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-200">Mummy</div>
          <div key={zone.size} className="mm-pop font-display text-3xl leading-none text-white">{zone.size}×{zone.size}</div>
        </div>
      </div>

      <div className={`mb-1.5 flex min-h-8 items-center justify-center rounded-lg px-2 py-1 text-center text-xs font-bold leading-tight ring-1 ${caption?.tone === 'win' ? 'bg-amber-400/20 text-amber-100 ring-amber-300/60' : caption?.tone === 'miss' ? 'bg-red-500/15 text-red-100 ring-red-300/40' : 'bg-black/50 text-emerald-100 ring-emerald-300/30'}`}>
        <span key={caption?.text} className="mm-pop">{caption?.text || (running ? 'Starting…' : 'Prizes landing under the Mummy are collected. Green gems make it grow.')}</span>
      </div>
      <div className="relative mx-auto aspect-square w-full max-w-[min(100%,calc(100dvh_-_470px))] min-w-[250px] rounded-xl bg-[linear-gradient(160deg,#3b2a17,#120c05)] p-1 ring-2 ring-amber-300/50 shadow-[inset_0_0_30px_rgba(0,0,0,0.8)]">
        <div className="relative h-full w-full">
          {/* the 5x5 bonus reels */}
          <div className="grid h-full w-full grid-cols-5 grid-rows-5 gap-1">
            {Array.from({ length: N * N }, (_, k) => {
              const r = Math.floor(k / N), c = k % N;
              const g = disp.board[c][r], l = landedAt[`${c}-${r}`];
              const empty = !g;
              return (
                <div key={k} className={`relative overflow-hidden rounded-md ${l ? 'z-[15]' : ''} bg-[linear-gradient(160deg,rgba(214,168,91,0.22),rgba(20,12,4,0.9))] ring-1 ring-amber-900/50`} style={{ gridColumn: c + 1, gridRow: r + 1 }}>
                  {spinning && empty && (
                    <div className="p3-strip fast absolute inset-x-0 top-0" style={{ animationDelay: `${-(c * 37 + r * 13) % 200}ms` }}>
                      {[0, 1, 2, 3].map((j) => <div key={j} className="aspect-square p-[12%] opacity-60 blur-[1.5px]"><svg viewBox="0 0 100 100" className="h-full w-full">{(j + c + r) % 3 ? <CoinArt /> : <GemArt />}</svg></div>)}
                    </div>
                  )}
                  {g && (
                    <svg viewBox="0 0 100 100" className={`absolute inset-0 h-full w-full p-[6%] ${l?.kind === 'gem' ? 'mm-pop' : 'mm-gemwait'}`} aria-label={`green gem ${g.v}x waiting`}>
                      <GemArt v={g.v} label={gemLabel(g.v)} />
                    </svg>
                  )}
                  {!g && l?.kind === 'coin' && (
                    <div className={`absolute inset-[6%] rounded-full ${l.hit ? '' : 'mm-fade'} ${coinTier(l.v)}`}>
                      <svg viewBox="0 0 100 100" className="mm-pop h-full w-full" aria-label={`cash prize ${l.v}x ${l.hit ? 'collected' : 'missed'}`}><CoinArt v={l.v} /></svg>
                      {!l.hit && <div className="absolute inset-x-0 bottom-0 rounded bg-red-600/90 text-center text-[8px] font-extrabold leading-tight text-white sm:text-[10px]">MISSED</div>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* the Mummy */}
          <div className={`mm-zone pointer-events-none absolute z-10 rounded-xl bg-emerald-400/10 ring-2 ring-emerald-300 ${grow ? 'mm-growing' : ''}`} style={{ left: pct(zone.col), top: pct(zone.row), width: pct(zone.size), height: pct(zone.size) }}>
            <div className="mm-walk absolute inset-[6%] opacity-90"><MummyFigure /></div>
            <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 rounded-full bg-emerald-300 px-2 text-[10px] font-extrabold text-emerald-950 shadow-[0_0_8px_#34d399]">{zone.size}×{zone.size}</div>
          </div>

          {/* prizes flying into the Mummy, with their value */}
          {flyers.map((f) => (
            <div key={f.id} className="pointer-events-none absolute inset-0 z-20">
              <div className="mm-fly absolute h-[16%] w-[16%] -translate-x-1/2 -translate-y-1/2" style={{ '--x0': `${f.x0}%`, '--y0': `${f.y0}%`, '--x1': `${f.x1}%`, '--y1': `${f.y1}%` }}>
                <svg viewBox="0 0 100 100" className="h-full w-full">{f.kind === 'gem' ? <GemArt /> : <CoinArt />}</svg>
              </div>
              <div className="mm-float absolute -translate-x-1/2 whitespace-nowrap font-cond text-lg font-extrabold text-amber-100 drop-shadow-[0_2px_4px_#000]" style={{ left: `${f.x0}%`, top: `${f.y0}%` }}>
                +{money(Math.floor(f.v * bet))}<span className="ml-1 text-xs text-emerald-200">{f.v}x</span>
              </div>
            </div>
          ))}

          {boom && <div key={boom.id} className="pointer-events-none absolute z-30" style={{ left: `${boom.x}%`, top: `${boom.y}%` }}><div className="mr-ring absolute h-24 w-24 rounded-full border-4 border-amber-200" style={{ left: 0, top: 0 }} /><Burst game="mummy" n={26} spread={110} /></div>}
          {flash > 0 && <div key={flash} className="mm-gridflash pointer-events-none absolute inset-0 z-20 rounded-lg" />}

          {/* growth celebration */}
          {grow && (
            <div key={grow.id} className="pointer-events-none absolute inset-0 z-40 flex flex-col items-center justify-center">
              <div className="absolute" style={{ left: `${centre(grow.zone).x}%`, top: `${centre(grow.zone).y}%` }}><Burst game="mummy" n={40} spread={160} /></div>
              <div className="mm-grow-banner rounded-2xl bg-black/70 px-5 py-3 text-center ring-2 ring-amber-300 shadow-[0_0_40px_rgba(252,211,77,0.7)]">
                <div className="font-display text-lg tracking-widest text-emerald-200">THE MUMMY GROWS</div>
                <div className="font-display text-6xl leading-none text-amber-200 drop-shadow-[0_0_14px_#fcd34d]">{grow.size}×{grow.size}</div>
                <div className="mt-1 rounded-full bg-emerald-400 px-3 py-0.5 font-display text-xl text-emerald-950">+{grow.spins} BONUS SPIN{grow.spins > 1 ? 'S' : ''}</div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="mt-2"><GemMeter gems={disp.gems} level={disp.level} /></div>
      <p className="mt-1.5 text-center text-[11px] text-amber-100/70">Cash prizes pay only if they land under the Mummy. Green gems wait where they land until the Mummy reaches them.</p>
    </div>
  );
}
