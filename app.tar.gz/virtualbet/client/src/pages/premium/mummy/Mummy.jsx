// Mystery of the Mummy – game screen. Every result arrives from the server
// before anything moves; this file only reveals it (reels, Cash Collect,
// jackpot pick, Free Games) and keeps the screen in step with the state.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, Burst, FeatureIntro, PremiumShell, RecentList, SidePanel, sleep, tierOf, usePremium, useReelStops } from '../../../components/Premium.jsx';
import { STAKES, WinAmount } from '../../../components/GameShell.jsx';
import { Modal } from '../../../components/ui.jsx';
import { CoinArt, GemArt, MUMMY_ART, MUMMY_LOBBY, MUMMY_NAMES, MummySym } from '../../../components/SlotArtMummy.jsx';
import { mummySfx } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { CASH, FREE_GAMES, JACKPOTS, LINES, MAX_WIN_X, PAYTABLE, RETRIGGER, SCATTER_PAY } from '../../../../../server/games/mummy/config.js';
import TombScene, { TombDoors } from './Scene.jsx';
import CashCollectBonus from './CashCollect.jsx';
import JackpotPick, { TierBadge } from './JackpotPick.jsx';

const ROWS = 3;
const START = [['MUMMY', 'K', 'ANKH'], ['PHARAOH', 'WILD', 'Q'], ['EYE', 'GEM', 'BOOK'], ['A', 'ANUBIS', 'FS'], ['J', 'K', 'PHARAOH']].map((c) => c.map((s) => (s === 'GEM' ? { s, v: 5 } : { s })));
const BLUR = ['J', 'PHARAOH', 'Q', 'ANKH', 'K', 'EYE', 'A', 'BOOK', 'ANUBIS', 'WILD', 'FS', 'GEM'].map((s) => (s === 'GEM' ? { s, v: 2 } : { s }));
const COLOURS = ['#fcd34d', '#2dd4bf', '#f472b6', '#60a5fa', '#a3e635', '#fb923c'];
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v ? '1' : '0'); } catch { /* private mode */ } };
const devMode = () => { try { return location.hash.includes('dev') || localStorage.getItem('vb_dev') === '1'; } catch { return false; } };

function Reel({ index, cells, spinning, landKey, lit, wildFlash, turbo, tease }) {
  return (
    <div className={`relative overflow-hidden rounded-lg bg-black/40 ring-1 ${tease ? 'ring-2 ring-teal-300 shadow-[0_0_24px_rgba(45,212,191,0.8)]' : 'ring-amber-200/10'}`} style={{ aspectRatio: `1 / ${ROWS}` }}>
      {spinning ? (
        <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 50}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-0.5 opacity-80 blur-[1.5px]"><MummySym cell={BLUR[(k * 5 + index * 3) % BLUR.length]} /></div>)}
        </div>
      ) : (
        <div key={landKey} className="p3-land-bounce">
          {cells.map((c, row) => {
            const k = `${index}-${row}`, on = lit?.has(k);
            return (
              <div key={row} className={`relative aspect-square p-0.5 ${lit?.size && !on ? 'p3-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'p3-win' : ''} ${c.s === 'WILD' && wildFlash ? 'mm-wildland' : ''}`} style={{ '--glow': '#fcd34d' }}><MummySym cell={c} /></div>
                {on && <Burst key={landKey} game="mummy" n={7} spread={38} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function WinLines({ wins, id }) {
  if (!wins?.length) return null;
  return (
    <svg key={id} viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 z-20 h-full w-full" aria-hidden="true">
      {wins.slice(0, 10).map((w, i) => {
        const pts = LINES[w.line].slice(0, w.count).map((row, reel) => `${(reel + 0.5) * 20},${((row + 0.5) / ROWS) * 100}`).join(' ');
        const c = COLOURS[i % COLOURS.length];
        return (
          <g key={i}>
            <polyline points={pts} fill="none" stroke={c} strokeOpacity=".4" strokeWidth="8" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" className="fr-line" style={{ animationDelay: `${i * 0.08}s` }} />
            <polyline points={pts} fill="none" stroke="#fff" strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" className="fr-line" style={{ animationDelay: `${i * 0.08}s`, filter: `drop-shadow(0 0 4px ${c})` }} />
          </g>
        );
      })}
    </svg>
  );
}

function Switch({ label, hint, on, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!on)} aria-pressed={on} className="flex w-full items-center justify-between gap-4 rounded-lg bg-navy-800 px-3 py-2.5 text-left text-sm text-slate-200 hover:bg-navy-700">
      <span>{label}{hint && <span className="block text-[11px] text-slate-500">{hint}</span>}</span>
      <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? 'bg-amber-400' : 'bg-navy-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
    </button>
  );
}

const pays = (bet, h) => money(Math.floor((bet * h) / 100));
const INTRO = {
  free: { title: 'FREE GAMES', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(15,118,110,0.96),rgba(3,12,11,0.97))]', text: `${FREE_GAMES} free games. A, K, Q and J leave the reels. 3 or more relics add ${RETRIGGER} more. Cash Collect and jackpots can still trigger.`, cta: 'Enter the tomb' },
  cash: { title: 'CASH COLLECT', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(6,95,70,0.96),rgba(2,10,6,0.97))]', text: `A new 5×5 grid and ${CASH.respins} bonus spins. The Mummy (2×2) collects every cash prize and green gem under it, and walks toward the gems. ${CASH.powerUps[0].gems} gems: 3×3 +3 spins · ${CASH.powerUps[1].gems}: 4×4 +2 · ${CASH.powerUps[2].gems}: 5×5 +1.`, cta: 'Wake the Mummy' },
  jackpot: { title: 'JACKPOT PICK', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(161,98,7,0.96),rgba(12,7,2,0.97))]', text: 'The scarab opened the jackpot vault. Open tiles until one jackpot appears three times.', cta: 'Open the vault' },
};

export default function Mummy() {
  const { user, view, history, play, commit, guard: rawGuard, shake, doShake } = usePremium('mummy');
  // Re-check the auto-run loop only after an action has fully finished.
  const [tick, setTick] = useState(0);
  const guard = (fn) => rawGuard(fn).finally(() => setTick((n) => n + 1));
  const fx = useMemo(() => mummySfx(), []);
  const reels = useReelStops(5);
  const [cells, setCells] = useState(START);
  const [lit, setLit] = useState(null);
  const [lines, setLines] = useState(null);
  const [res, setRes] = useState(null);
  const [stake, setStake] = useState(100);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [tease, setTease] = useState([]);
  const [wildFlash, setWildFlash] = useState(false);
  const [big, setBig] = useState(null);
  const [doors, setDoors] = useState(null);
  const [intro, setIntro] = useState(null);
  const [summary, setSummary] = useState(null);
  const [running, setRunning] = useState(false);
  const [session, setSession] = useState({ staked: 0, won: 0 });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [turbo, setTurbo] = useState(() => pref('mm_turbo', false));
  const [showLines, setShowLines] = useState(() => pref('mm_lines', true));
  const [space, setSpace] = useState(() => pref('mm_space', true));
  const [dev] = useState(devMode);
  const mode = view?.mode || 'base';
  // The bonus screens stay up until their own ending has played out, even
  // though the server has already moved on (it settles on the last action).
  const [held, setHeld] = useState(null);
  useEffect(() => {
    if (view?.mode === 'cash' && view.cash) setHeld({ type: 'cash', data: view.cash });
    else if (view?.mode === 'jackpot' && view.jackpot) setHeld({ type: 'jackpot', data: view.jackpot });
  }, [view]);
  const screen = held ? held.type : mode;
  const free = view?.free;
  const bet = held?.data?.bet ?? free?.bet ?? view?.cash?.bet ?? view?.jackpot?.bet ?? stake;
  const t = useCallback((ms) => sleep(turbo ? ms * 0.45 : ms), [turbo]);
  const track = (out) => setSession((s) => ({ staked: s.staked + (out.staked || 0), won: s.won + (out.payout || 0) }));

  // After a refresh mid-feature, offer to continue it.
  const resumed = useRef(false);
  useEffect(() => {
    if (!view || resumed.current) return;
    resumed.current = true;
    if (view.mode === 'cash' || view.mode === 'jackpot' || view.mode === 'free') setIntro({ type: view.mode, resume: true });
  }, [view]);

  const enter = async (type) => { fx.doors(); setDoors(type); await t(1700); setDoors(null); setIntro({ type }); };

  const spin = () => guard(async () => {
    if (mode !== 'base' && mode !== 'free') return;
    fx.click();
    setSpinning(true); setRes(null); setLit(null); setLines(null); setWildFlash(false); setTease([]);
    fx.spin(); setSpinId((n) => n + 1); reels.start();
    const out = await play('spin', mode === 'free' ? {} : { stake });
    if (!out) { reels.stopNow(); setSpinning(false); return; }
    track(out);
    setCells(out.grid);
    // anticipation: after two relics, or once the Mummy is on reel 1
    const teaseReels = [];
    let fs = 0;
    out.grid.forEach((col, r) => { if (fs >= 2) teaseReels.push(r); if (col.some((c) => c.s === 'FS')) fs++; });
    await reels.stopAll({
      turbo, tease: teaseReels,
      onStop: (r) => {
        fx.stop(r);
        const col = out.grid[r];
        if (col.some((c) => c.s === 'WILD')) { fx.wild(); setWildFlash(true); }
        if (col.some((c) => c.s === 'FS')) fx.scatter();
        if (col.some((c) => c.s === 'MUMMY')) { fx.mummy(); setTease([1, 2, 3, 4]); }
        if (col.some((c) => c.s === 'GEM')) fx.gem(r);
        if (teaseReels.includes(r + 1)) setTease([r + 1]);
      },
    });
    setTease([]);
    const litCells = new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`)));
    if (out.scatter.count >= 3) out.scatter.cells.forEach(([r, c]) => litCells.add(`${r}-${c}`));
    const tr = out.triggers || {};
    if (tr.cash) { if (tr.cash.mummy) litCells.add(`0-${tr.cash.mummy[1]}`); tr.cash.gems.forEach(([r, c]) => litCells.add(`${r}-${c}`)); }
    if (tr.jackpot) litCells.add(`${tr.jackpot.cell[0]}-${tr.jackpot.cell[1]}`);
    if (litCells.size) {
      setLit(litCells); if (showLines) setLines(out.wins);
      if (out.win) fx.win(out.win >= out.bet * 5 ? 2 : 1);
      await t(out.win ? 1100 : 800);
    }
    setRes(out); setSpinning(false); commit();
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); }
    if (tr.free?.retrigger) fx.bonus();
    if (out.finished) setSummary({ type: 'free', ...out.finished, practice: out.practice });
    if (out.started) { fx.bonus(); await enter(out.started.type); }
  });

  // Cash Collect: the bonus component plays each spin; we handle the ending.
  const bigResolve = useRef(null);
  const showBig = (b) => new Promise((res) => { bigResolve.current = res; setBig(b); });
  const requestRespin = async () => { const out = await play('respin', {}); if (!out) setRunning(false); else track(out); return out; };
  const cashComplete = async (out, fin) => {
    setRunning(false);
    fx.jackpot();
    await showBig({ amount: out.win, title: 'BONUS WIN', practice: out.practice, mummy: fin });
    setHeld(null);
    if (out.finished) setSummary({ type: 'free', ...out.finished, practice: out.practice });
    if (out.started) await enter(out.started.type);
  };

  const pickTile = (index) => guard(async () => {
    fx.click();
    const out = await play('pick', { index });
    if (!out) return;
    track(out);
    fx.reveal(out.tier);
    if (out.done) {
      setHeld((h) => h && { ...h, data: { ...h.data, opened: out.opened, done: true, tier: out.jackpot.tier } });
      await t(1400); commit();
      fx.jackpot();
      await showBig({ amount: out.win, title: `${out.jackpot.name.toUpperCase()} JACKPOT`, tier: out.jackpot.tier, practice: out.practice });
      setHeld(null);
      if (out.finished) setSummary({ type: 'free', ...out.finished });
      if (out.started) { await t(400); await enter(out.started.type); }
    } else commit();
  });

  const devTrigger = (event, tier) => guard(async () => {
    const out = await play('dev', { event, stake, tier });
    if (out?.started) await enter(out.started.type);
  });

  // Auto-run free games and respins (never paid spins)
  const ready = !spinning && !big && !intro && !doors && !summary && !settingsOpen && !held;
  useEffect(() => {
    if (!ready) return undefined;
    if (mode === 'free') { const id = setTimeout(spin, turbo ? 400 : 900); return () => clearTimeout(id); }
    return undefined;
  }, [ready, mode, running, tick]); // eslint-disable-line react-hooks/exhaustive-deps

  // Space bar
  const spinRef = useRef(spin); spinRef.current = spin;
  useEffect(() => {
    if (!space) return undefined;
    const h = (e) => {
      if (e.code !== 'Space' || e.repeat || ['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(e.target.tagName)) return;
      e.preventDefault();
      if (big) setBig(null); else if (ready && mode === 'base') spinRef.current();
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [space, big, ready, mode]);

  const low = mode === 'base' && (user?.balance ?? 0) < stake;
  const i = Math.max(0, STAKES.indexOf(stake));
  const practice = view?.practice;
  const detail = res && [res.wins.length && `${res.wins.length} line win${res.wins.length > 1 ? 's' : ''}`, res.scatter.win && `${res.scatter.count} relics`].filter(Boolean).join(' · ');
  const sessionNet = session.won - session.staked;

  const bar = (
    <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || screen !== 'base' || i <= 0} onClick={() => { fx.click(); setStake(STAKES[i - 1]); }} aria-label="Lower bet">−</button>
          <div className="w-[4.4rem] text-center leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{mode === 'free' ? 'Free game' : 'Bet'}</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(bet)}</div></div>
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || screen !== 'base' || i >= STAKES.length - 1} onClick={() => { fx.click(); setStake(STAKES[i + 1]); }} aria-label="Raise bet">+</button>
        </div>
        {screen === 'cash' ? (
          <button onClick={() => setRunning(true)} disabled={running || mode !== 'cash' || !!intro || !!doors} className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-emerald-300 to-emerald-600 text-lg font-extrabold text-emerald-950">{mode !== 'cash' ? 'Bonus complete' : running ? 'Bonus spins running…' : 'Start bonus spins'}</button>
        ) : screen === 'jackpot' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-amber-400/20 text-sm font-bold text-amber-100 ring-1 ring-amber-300/50">Pick a tile above</div>
        ) : (
          <button onClick={spin} disabled={spinning || low || !!intro || !!doors || !!summary}
            className={`btn h-14 flex-1 rounded-full text-lg font-extrabold shadow-lg transition-transform active:scale-95 ${mode === 'free' ? 'bg-gradient-to-b from-teal-200 to-teal-600 text-teal-950' : 'bg-gradient-to-b from-amber-200 to-amber-500 text-amber-950'}`}>
            {spinning ? 'Spinning…' : mode === 'free' ? `Free game · ${free.remaining} left` : low ? 'Not enough balance' : 'Spin'}
          </button>
        )}
      </div>
      <div className="flex items-center justify-between gap-1.5 text-xs text-slate-400">
        <div className="flex gap-1.5">
          <button onClick={() => { const v = !turbo; setTurbo(v); save('mm_turbo', v); }} className={`rounded-md px-2.5 py-1 font-semibold ${turbo ? 'bg-amber-400 text-navy-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Quick</button>
          <button onClick={() => setSettingsOpen(true)} className="rounded-md bg-navy-700 px-2.5 py-1 font-semibold text-slate-200">Settings</button>
        </div>
        <div className="flex gap-3 text-right">
          <span>Win <b className="tabular-nums text-amber-200">{money(res?.win || 0)}</b></span>
          <span>Balance <b className="tabular-nums text-slate-200">{money(user?.balance ?? 0)}</b></span>
        </div>
      </div>
      {dev && screen === 'base' && (
        <div className="rounded-lg border border-dashed border-fuchsia-400/60 bg-fuchsia-500/10 p-2 text-xs text-fuchsia-100">
          <div className="mb-1 font-bold">Test mode (practice: costs and pays nothing)</div>
          <div className="flex flex-wrap gap-1">
            <button className="rounded bg-fuchsia-700 px-2 py-1" onClick={() => devTrigger('free')}>Free Games</button>
            <button className="rounded bg-fuchsia-700 px-2 py-1" onClick={() => devTrigger('cash')}>Cash Collect</button>
            {JACKPOTS.map((j, k) => <button key={j.id} className="rounded bg-fuchsia-700 px-2 py-1" onClick={() => devTrigger('jackpot', k)}>{j.name}</button>)}
          </div>
        </div>
      )}
    </div>
  );

  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to win</h3>
        <p>5 reels, 3 rows, {LINES.length} fixed lines. Three or more matching symbols on a line, from reel 1, pay as shown (only the best win per line). The <b className="text-amber-200">Scarab Wild</b> appears on reels 2–5 and substitutes for every line symbol. Relics, the Mummy and gems are not line symbols.</p>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">Paytable at {money(bet)} per spin</h3>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(PAYTABLE).map(([s, p]) => (
            <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
              <div className="h-11 w-11 shrink-0"><MummySym cell={{ s }} /></div>
              <div className="min-w-0 text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">{MUMMY_NAMES[s]}</div>{p.map((v, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{pays(bet, v)}</b></div>)}</div>
            </div>
          ))}
          <div className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
            <div className="h-11 w-11 shrink-0"><MummySym cell={{ s: 'FS' }} /></div>
            <div className="text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">Relic (anywhere)</div>{[3, 4, 5].map((n) => <div key={n}><span className="text-slate-500">{n}×</span> <b className="text-white">{pays(bet, SCATTER_PAY[n])}</b></div>)}</div>
          </div>
        </div>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Free Games</h3>
        <p>3, 4 or 5 Free Games relics anywhere award <b>{FREE_GAMES} free games</b> at the same bet. Sometimes one or two relics start them at random. In Free Games, A, K, Q and J are taken off the reels. 3 or more relics during Free Games add {RETRIGGER} more. Cash Collect and jackpots can still trigger, and their wins count toward the round total.</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Cash Collect</h3>
        <div className="flex items-center gap-2"><div className="h-10 w-10 shrink-0"><MummySym cell={{ s: 'MUMMY' }} /></div><div className="h-10 w-10 shrink-0"><svg viewBox="0 0 100 100"><GemArt v={5} /></svg></div><div className="h-10 w-10 shrink-0"><svg viewBox="0 0 100 100"><CoinArt v={2} /></svg></div></div>
        <p>A <b>Mummy on reel 1</b> with at least one <b className="text-emerald-300">green gem</b> on reels 2–5 starts Cash Collect (a gem without a Mummy sometimes starts it at random). Play moves to a separate 5×5 bonus grid; the triggering gems are placed in their columns (bottom three rows).</p>
        <ul className="list-disc space-y-1 pl-5">
          <li>You get {CASH.respins} bonus spins. The Mummy starts 2×2 in the bottom-left.</li>
          <li>Each spin the Mummy takes one step (sideways, up, down or diagonally) toward the nearest green gem, then cash prizes and gems land on empty cells.</li>
          <li>Everything under the Mummy is collected: cash prizes that land in its area, and every green gem in its area. Cash prizes outside it disappear and are not paid. Green gems outside it wait until the Mummy reaches them.</li>
          <li>Green gems collected are counted for the whole bonus and never reset:</li>
          {CASH.powerUps.map((p) => <li key={p.size} className="ml-4 list-[circle]">{p.gems} gems: the Mummy grows to {p.size}×{p.size} and you get +{p.spins} bonus spin{p.spins > 1 ? 's' : ''}.</li>)}
          <li>Cash prizes are {CASH.coinValues.map(([v]) => `${v}x`).join(', ')} the bet. Green gems carry 1x–60x (20x = MINI, 60x = MINOR). Collected values are added up and paid once, when the bonus spins run out. Anything not collected is not paid.</li>
        </ul>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Jackpots</h3>
        <p>Any Scarab Wild that lands can open the jackpot pick. Tap tiles until one jackpot appears three times; that one is paid. The prize is decided when the pick starts, so which tiles you tap doesn't change it.</p>
        <div className="grid grid-cols-5 gap-1.5 text-center text-[11px]">{JACKPOTS.map((j, k) => <div key={j.id} className="rounded-lg bg-navy-800 p-1"><div className="mx-auto h-8 w-full"><TierBadge t={k} /></div><div className="mt-1">{j.x.toLocaleString()}x</div><div className="text-amber-200">{money(j.x * bet)}</div></div>)}</div>
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Maths</b>: long-run return about 95% (our own tuning, measured by simulation; it is not the original game's certified RTP). Very high volatility: most of the return comes from Cash Collect, so expect long quiet spells. Free Games about 1 in 185 spins, Cash Collect about 1 in 80, jackpot pick about 1 in 1,400. Maximum win {MAX_WIN_X.toLocaleString()}x the bet per spin or feature. Results are decided by the server's cryptographic random number generator before anything moves; tapping, timing or reloading can't change them.
      </section>
      <section className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3 text-xs text-slate-300">
        <b className="text-amber-200">About this game</b>: Mystery of the Mummy is an original game built on the published rules of Aristocrat's <i>Mo' Mummy</i>. Some details aren't published (3- and 4-of-a-kind pays, relic pays, how many games a retrigger adds, how many gems each power-up needs, how the Mummy moves). The values here are our own; the README lists each one.
      </section>
    </>
  );

  const stageMode = screen === 'cash' ? 'cash' : screen === 'jackpot' ? 'jackpot' : screen === 'free' ? 'free' : 'base';
  return (
    <PremiumShell game="mummy" rtp="95%" tagline="5 × 3 · 20 lines · Cash Collect · Free Games · 5 jackpots" shake={shake}
      stageClass={`border-2 ${stageMode === 'free' ? 'border-teal-300/60 shadow-[0_0_60px_rgba(45,212,191,0.3)]' : stageMode === 'cash' ? 'border-emerald-300/60 shadow-[0_0_60px_rgba(52,211,153,0.3)]' : 'border-amber-300/50 shadow-[0_0_60px_rgba(252,211,77,0.25)]'}`}
      bg={<TombScene mode={stageMode} />}
      below={<>{bar}
        <Modal open={settingsOpen} onClose={() => setSettingsOpen(false)} title="Settings">
          <div className="space-y-2">
            <Switch label="Quick spins" hint="Shorter reel and feature animations" on={turbo} onChange={(v) => { setTurbo(v); save('mm_turbo', v); }} />
            <Switch label="Show win lines" on={showLines} onChange={(v) => { setShowLines(v); save('mm_lines', v); }} />
            <Switch label="Space bar to spin" hint="Desktop keyboards" on={space} onChange={(v) => { setSpace(v); save('mm_space', v); }} />
            <p className="px-1 pt-1 text-[11px] text-slate-500">Music and sound effects have separate switches under Sound, top right. Sound only starts after your first tap.</p>
          </div>
        </Modal>
      </>}
      info={info}
      side={<>
        <SidePanel title="This session">
          <div className="space-y-1 text-xs text-slate-300">
            <div className="flex justify-between"><span>Staked</span><b className="tabular-nums text-white">{money(session.staked)}</b></div>
            <div className="flex justify-between"><span>Won</span><b className="tabular-nums text-white">{money(session.won)}</b></div>
            <div className="flex justify-between"><span>Net</span><b className={`tabular-nums ${sessionNet >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>{sessionNet >= 0 ? '+' : '−'}{money(Math.abs(sessionNet))}</b></div>
          </div>
        </SidePanel>
        <SidePanel title="Features">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-emerald-300">Mummy on reel 1 + a gem</b>: Cash Collect.</li>
            <li><b className="text-teal-300">3+ relics</b>: {FREE_GAMES} Free Games, no A/K/Q/J.</li>
            <li><b className="text-amber-200">Scarab Wild</b> can open the jackpot pick (up to {JACKPOTS[4].x.toLocaleString()}x).</li>
          </ul>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      <div className={`relative pt-1 ${turbo ? 'mr-turbo' : ''}`}>
        {practice && <div className="mb-2 rounded-md bg-fuchsia-600/80 px-2 py-1 text-center text-xs font-bold text-white">PRACTICE ROUND: no stake, no payout</div>}
        {mode === 'free' && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="rounded-md bg-teal-200 px-2.5 py-1 text-xs font-extrabold uppercase text-teal-950 shadow-[0_0_16px_rgba(94,234,212,0.7)]">Free games · {free.remaining} left</div>
            <div className="rounded-md bg-black/50 px-2 py-1 text-xs font-bold text-teal-100 ring-1 ring-teal-300/50">Round win {money(free.total)}</div>
          </div>
        )}
        <div className="relative mx-auto rounded-2xl bg-[linear-gradient(160deg,#fff8d6,#d97706_30%,#713f12_60%,#2dd4bf_85%,#fcd34d)] p-[3px] shadow-[0_0_30px_rgba(252,211,77,0.3)]" style={{ maxWidth: screen === 'cash' || screen === 'jackpot' ? undefined : 'min(100%, calc((100dvh - 470px) * 1.67 + 24px))' }}>
          <div className="relative rounded-[13px] bg-[#0b0704]/85 p-1.5 backdrop-blur-sm">
            {screen === 'cash' ? <CashCollectBonus cash={held?.data ?? view.cash} bet={(held?.data ?? view.cash).bet} running={running && !intro && !doors} lock={guard} request={requestRespin} commit={commit} fx={fx} wait={t} doShake={doShake} onComplete={cashComplete} />
              : screen === 'jackpot' ? <JackpotPick jp={held?.data ?? view.jackpot} bet={(held?.data ?? view.jackpot).bet} onPick={pickTile} busy={!!big} />
                : (
                  <div className="relative">
                    <div className="grid grid-cols-5 gap-1 sm:gap-1.5">
                      {[0, 1, 2, 3, 4].map((r) => <Reel key={r} index={r} cells={cells[r]} spinning={!reels.stopped[r]} landKey={`${spinId}-${r}`} lit={lit} wildFlash={wildFlash} turbo={turbo} tease={tease.includes(r) && !reels.stopped[r]} />)}
                    </div>
                    <WinLines wins={lines} id={spinId} />
                  </div>
                )}
          </div>
        </div>
        {screen !== 'cash' && screen !== 'jackpot' && (
          <div className="mt-2 flex min-h-14 flex-col items-center justify-center rounded-xl bg-black/45 px-2 py-1.5 text-center leading-tight backdrop-blur-sm">
            {res?.win ? <><WinAmount win={res.win} staked={res.staked} />{detail && <div className="mt-0.5 text-[11px] text-white/75">{detail}</div>}</>
              : <div className="text-sm text-white/65">{spinning ? 'The tomb stirs…' : res ? 'No win this time' : 'Set your bet and spin'}</div>}
          </div>
        )}
        {doors && <TombDoors />}
        {intro && (
          <FeatureIntro title={INTRO[intro.type].title} subtitle={intro.resume ? 'Your feature is still in progress. Carry on where you left off.' : INTRO[intro.type].text}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-28 w-28" aria-hidden="true">{intro.type === 'cash' ? MUMMY_ART.MUMMY : intro.type === 'free' ? MUMMY_ART.FS : MUMMY_LOBBY}</svg>}
            className={INTRO[intro.type].cls} cta={intro.resume ? 'Continue' : INTRO[intro.type].cta}
            onStart={() => { fx.click(); setIntro(null); if (intro.type === 'cash') setRunning(true); }} />
        )}
        {summary && !big && (
          <FeatureIntro title={summary.type === 'free' ? 'FREE GAMES COMPLETE' : 'CASH COLLECTED'} subtitle={`${summary.type === 'free' ? `${summary.played} free games won ${money(summary.total)}.` : `The Mummy collected ${money(summary.total)}.`}${summary.practice ? ' Practice round: nothing was paid.' : ''}`}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-24 w-24" aria-hidden="true">{summary.type === 'free' ? MUMMY_ART.FS : MUMMY_ART.MUMMY}</svg>}
            className="bg-[radial-gradient(ellipse_at_top,rgba(113,63,18,0.96),rgba(12,7,2,0.97))]" cta={mode === 'base' ? 'Back to the reels' : 'Continue'}
            onStart={() => setSummary(null)} />
        )}
        {big && <BigWin game="mummy" amount={big.amount} bet={bet} title={big.title} onDone={() => { setBig(null); bigResolve.current?.(); bigResolve.current = null; }}
          cinematic={<>{big.mummy && <div className="pointer-events-none absolute inset-x-0 top-[6%] z-10 text-center font-display text-lg text-emerald-200 drop-shadow">Mummy {big.mummy.size}×{big.mummy.size} · {big.mummy.gems} gem{big.mummy.gems === 1 ? '' : 's'} collected</div>}{big.practice && <div className="pointer-events-none absolute inset-x-0 bottom-[6%] z-10 text-center"><span className="rounded-full bg-fuchsia-600 px-3 py-1 text-xs font-extrabold text-white">PRACTICE ROUND · NOT PAID</span></div>}{big.tier != null ? <div className="pointer-events-none absolute left-1/2 top-[3%] h-10 w-28 -translate-x-1/2"><TierBadge t={big.tier} /></div>
            : <svg viewBox="0 0 100 100" className="pointer-events-none absolute inset-0 h-full w-full opacity-30" preserveAspectRatio="xMidYMid slice" aria-hidden="true">{MUMMY_LOBBY}</svg>}</>} />}
      </div>
    </PremiumShell>
  );
}
