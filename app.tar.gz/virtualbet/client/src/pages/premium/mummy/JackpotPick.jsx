// Mystery of the Mummy – jackpot pick: 15 sealed tiles, first jackpot seen 3 times wins.
import { JACKPOTS } from '../../../../../server/games/mummy/config.js';
import { Scarab } from '../../../components/SlotArtMummy.jsx';
import { money } from '../../../lib/format.js';

export const TIER_STYLE = [
  ['MINI', 'from-orange-300 to-orange-700', '#c2410c'],
  ['MINOR', 'from-slate-100 to-slate-500', '#475569'],
  ['MAXI', 'from-teal-200 to-teal-700', '#0f766e'],
  ['MAJOR', 'from-indigo-300 to-indigo-700', '#4338ca'],
  ['GRAND', 'from-amber-100 via-amber-300 to-amber-700', '#b45309'],
];

export function TierBadge({ t, className = '' }) {
  const [name, grad] = TIER_STYLE[t];
  return <div className={`flex h-full w-full flex-col items-center justify-center rounded-lg bg-gradient-to-b ${grad} font-display leading-none text-white shadow-inner [text-shadow:0_1px_2px_rgba(0,0,0,0.6)] ${className}`}><span className="text-[clamp(10px,3.2vw,18px)]">{name}</span></div>;
}

export default function JackpotPick({ jp, bet, onPick, busy }) {
  if (!jp) return null;
  const opened = Object.fromEntries(jp.opened.map((o) => [o.index, o.tier]));
  const counts = JACKPOTS.map((_, t) => jp.opened.filter((o) => o.tier === t).length);
  return (
    <div>
      <div className="mb-2 grid grid-cols-5 gap-1">
        {JACKPOTS.map((j, t) => (
          <div key={j.id} className={`rounded-lg bg-black/55 px-1 py-1 text-center ring-1 ${jp.done && jp.tier === t ? 'ring-2 ring-amber-200 shadow-[0_0_16px_#fcd34d]' : 'ring-white/10'}`}>
            <div className="text-[10px] font-extrabold tracking-wide" style={{ color: TIER_STYLE[t][2] === '#475569' ? '#e2e8f0' : undefined }}><span className={`bg-gradient-to-b ${TIER_STYLE[t][1]} bg-clip-text text-transparent`}>{j.name.toUpperCase()}</span></div>
            <div className="font-cond text-xs font-bold text-white tabular-nums">{money(j.x * bet)}</div>
            <div className="mt-0.5 flex justify-center gap-0.5">{[0, 1, 2].map((k) => <span key={k} className={`h-1.5 w-1.5 rounded-full ${k < counts[t] ? 'bg-amber-300 shadow-[0_0_4px_#fcd34d]' : 'bg-white/20'}`} />)}</div>
          </div>
        ))}
      </div>
      <div className="mx-auto grid max-w-md grid-cols-5 gap-1.5 [perspective:600px]">
        {Array.from({ length: 15 }, (_, i) => {
          const t = opened[i];
          const open = t !== undefined;
          return (
            <button key={i} type="button" disabled={open || busy || jp.done} onClick={() => onPick(i)} aria-label={open ? `Tile ${i + 1}: ${JACKPOTS[t].name}` : `Open tile ${i + 1}`}
              className={`mm-tile relative aspect-square rounded-lg ${open ? 'open' : 'hover:scale-105'} ${jp.done && !open ? 'opacity-40' : ''}`}>
              <div className="mm-face absolute inset-0 rounded-lg bg-[linear-gradient(160deg,#fcd34d,#a16207_55%,#422006)] p-1 ring-1 ring-amber-200/70">
                <svg viewBox="0 0 100 100" className="h-full w-full" aria-hidden="true"><Scarab glow={false} /></svg>
              </div>
              <div className={`mm-face mm-back absolute inset-0 rounded-lg p-0.5 ${jp.done && jp.tier === t ? 'shadow-[0_0_18px_#fcd34d] ring-2 ring-white' : ''}`}>{open && <TierBadge t={t} />}</div>
            </button>
          );
        })}
      </div>
      <p className="mt-2 text-center text-xs text-amber-100/80">{jp.done ? `${JACKPOTS[jp.tier].name} jackpot!` : 'Open tiles until one jackpot shows three times.'}</p>
    </div>
  );
}
