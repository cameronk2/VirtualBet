// Moonridge – Wolf Peak-style Delayed Expanding Wilds (original art and code).
// The server decides everything; this screen replays the spin's events:
// grow → full column → reels stop → new wilds land & lock → wins → vanish.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, Burst, FeatureIntro, PremiumShell, RecentList, reduceMotion, SidePanel, sleep, tierOf, usePremium, useReelStops } from '../../components/Premium.jsx';
import { STAKES, WinAmount } from '../../components/GameShell.jsx';
import { Modal } from '../../components/ui.jsx';
import { MOON_ART, MOON_LOBBY, MOON_NAMES, MoonColumn, MoonSym } from '../../components/SlotArtMoon.jsx';
import { moonSfx } from '../../lib/sound.js';
import { money } from '../../lib/format.js';
import { FREE_SPINS, JACKPOTS, LINES, MAX_WIN_X, PAYTABLE, RETRIGGER_PER_BONUS, SCATTER_PAY } from '../../../../server/games/moonridge/config.js';

const ROWS = 4;
const START = [['GRAY', 'Q', 'EAGLE', 'K'], ['A', 'WHITE', 'AMULET', 'BONUS'], ['K', 'BLACK', 'Q', 'EAGLE'], ['AMULET', 'A', 'GRAY', 'K'], ['Q', 'EAGLE', 'J1', 'WHITE']];
const BLUR = ['Q', 'GRAY', 'K', 'AMULET', 'A', 'EAGLE', 'WHITE', 'BLACK', 'WILD', 'BONUS', 'J1'];
const LINE_COLOURS = ['#fbbf24', '#f87171', '#a78bfa', '#34d399', '#60a5fa', '#f472b6', '#fde68a', '#fb923c'];
const PAW = <g fill="#fde68a"><ellipse cx="50" cy="62" rx="16" ry="13" /><ellipse cx="30" cy="42" rx="7" ry="9" /><ellipse cx="44" cy="32" rx="7" ry="9" /><ellipse cx="58" cy="32" rx="7" ry="9" /><ellipse cx="72" cy="42" rx="7" ry="9" /></g>;
const KIND_LABEL = { W2: 'x2', W3: 'x3', WG: 'Gold' };
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v ? '1' : '0'); } catch { /* private mode */ } };

/** Dusk mountains, harvest moon, pine forest, fog and drifting fireflies. */
function MoonScene({ free }) {
  const stars = useMemo(() => Array.from({ length: 46 }, (_, i) => ({ x: (i * 37) % 100, y: (i * 23) % 42, s: i % 7 === 0 ? 2 : 1, d: `${-(i % 9) * 0.4}s` })), []);
  const motes = useMemo(() => (reduceMotion ? [] : Array.from({ length: 18 }, (_, i) => ({ x: (i * 53) % 100, y: 70 + (i * 13) % 28, dx: `${((i % 5) - 2) * 14}px`, t: `${6 + (i % 5) * 1.7}s`, d: `${-(i * 0.9)}s` }))), []);
  const pines = useMemo(() => Array.from({ length: 34 }, (_, i) => ({ x: i * 12.4 - 6, h: 26 + ((i * 11) % 22), w: 9 + (i % 3) * 2 })), []);
  return (
    <>
      <div className={`absolute inset-0 transition-[background] duration-1000 ${free ? 'bg-[linear-gradient(180deg,#12051a,#3b0d2b_38%,#7c2d12_70%,#1c0a05)]' : 'bg-[linear-gradient(180deg,#05061a,#1b1640_40%,#5b2a4e_68%,#b45309_86%,#1c1005)]'}`} />
      {stars.map((s, i) => <span key={i} className="fr-twinkle absolute rounded-full bg-white" style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s, animationDelay: s.d }} />)}
      <div className={`absolute left-1/2 top-[6%] -translate-x-1/2 rounded-full transition-all duration-1000 ${free ? 'h-36 w-36 bg-[radial-gradient(circle_at_42%_38%,#fecaca,#ef4444_60%,#7f1d1d)] shadow-[0_0_90px_30px_rgba(239,68,68,0.35)] sm:h-48 sm:w-48' : 'h-28 w-28 bg-[radial-gradient(circle_at_42%_38%,#fffbeb,#fde68a_60%,#d97706)] shadow-[0_0_80px_26px_rgba(251,191,36,0.35)] sm:h-40 sm:w-40'}`} />
      <div className="mr-cloud absolute left-[-10%] top-[12%] h-[7%] w-[60%] rounded-full bg-[radial-gradient(ellipse,rgba(30,27,75,0.85),transparent_70%)] blur-sm" />
      <div className="mr-cloud absolute right-[-12%] top-[20%] h-[6%] w-[55%] rounded-full bg-[radial-gradient(ellipse,rgba(30,27,75,0.75),transparent_70%)] blur-sm" style={{ animationDelay: '-12s' }} />
      <svg viewBox="0 0 400 140" preserveAspectRatio="none" className="absolute bottom-[26%] left-0 h-[34%] w-full opacity-70" aria-hidden="true">
        <polygon points="0,140 0,90 40,58 70,76 120,24 160,64 200,36 240,70 290,18 330,60 370,40 400,58 400,140" fill="#2e2350" />
        <polygon points="120,24 134,40 126,44 110,38" fill="#e9d5ff" opacity=".55" /><polygon points="290,18 306,34 284,36" fill="#e9d5ff" opacity=".55" /><polygon points="200,36 214,48 194,50" fill="#e9d5ff" opacity=".45" />
      </svg>
      <svg viewBox="0 0 400 140" preserveAspectRatio="none" className="absolute bottom-[14%] left-0 h-[30%] w-full" aria-hidden="true">
        <polygon points="0,140 0,96 50,64 96,92 150,48 196,84 252,56 300,96 352,62 400,86 400,140" fill="#1a1433" />
        {/* the ridge with the lone wolf */}
        <polygon points="250,58 270,50 284,58" fill="#1a1433" />
        <g transform="translate(262 22) scale(.32)"><path d="M30 90L34 71C31 62 33 54 39 48L35 37L29 23L24 13L33 18L40 24L44 22L43 13L49 21C53 26 55 32 57 38C65 42 71 50 73 60L77 73L81 90Z" fill="#0b0817" /></g>
      </svg>
      <svg viewBox="0 0 400 70" preserveAspectRatio="none" className="absolute bottom-0 left-0 h-[24%] w-full" aria-hidden="true">
        {pines.map((p, i) => <polygon key={i} points={`${p.x},70 ${p.x + p.w / 2},${70 - p.h} ${p.x + p.w},70`} fill={i % 2 ? '#050a08' : '#0a1610'} />)}
        <rect y="60" width="400" height="10" fill="#040806" />
      </svg>
      <div className="fr-fog absolute bottom-[12%] left-[-20%] h-[16%] w-[140%] bg-[radial-gradient(ellipse_at_center,rgba(216,180,254,0.16),transparent_65%)] blur-md" />
      <div className="fr-fog absolute bottom-[2%] left-[-30%] h-[14%] w-[160%] bg-[radial-gradient(ellipse_at_center,rgba(253,230,138,0.10),transparent_65%)] blur-md" style={{ animationDelay: '-9s' }} />
      {motes.map((m, i) => <span key={i} className="mr-mote absolute h-1 w-1 rounded-full bg-amber-200 shadow-[0_0_6px_2px_rgba(253,230,138,0.7)]" style={{ left: `${m.x}%`, top: `${m.y}%`, '--dx': m.dx, '--t': m.t, animationDelay: m.d }} />)}
    </>
  );
}

/** The expanding wild on its reel: a tall scene revealed over the rows it occupies. */
function WildColumn({ w, fx, lit }) {
  const rows = w.occupied.length ? w.occupied : [w.startRow];
  const top = Math.min(...rows), n = rows.length, bottom = ROWS - top - n;
  const pct = (x) => `${(x / ROWS) * 100}%`;
  const left = Math.max(0, ROWS - n);
  const vanish = fx === 'vanish', full = fx === 'full' || w.stage === 'FULL_COLUMN';
  return (
    <div className={`pointer-events-none absolute inset-0 z-10 ${vanish ? 'mr-vanish' : ''}`}>
      <div className={`absolute inset-0 overflow-hidden rounded-lg ${fx === 'land' ? 'mr-land' : ''} ${fx === 'grow' ? 'mr-growflash' : ''} ${full && !vanish ? 'mr-full' : ''}`}
        style={{ clipPath: `inset(${pct(top)} 0 ${pct(bottom)} 0 round 8px)`, transition: 'clip-path .55s cubic-bezier(.2,.9,.25,1.15)' }}>
        <MoonColumn kind={w.kind} className="h-full w-full" />
        {full && !vanish && <div key={`b${w.id}`} className="mr-beam absolute inset-x-0 top-0 h-1/3 bg-[linear-gradient(180deg,transparent,rgba(253,230,138,0.85),transparent)]" />}
      </div>
      {/* glowing frame around the occupied cells */}
      <div className={`mr-col absolute inset-x-0 rounded-lg ring-2 ${lit ? 'ring-white' : w.kind === 'W3' ? 'ring-red-400' : w.kind === 'W2' ? 'ring-slate-100' : 'ring-amber-300'} mr-edge`} style={{ top: pct(top), height: pct(n) }} />
      {/* progress pips + multiplier gem */}
      <div className="mr-col absolute inset-x-0 flex flex-col items-center justify-between py-1" style={{ top: pct(top), height: pct(n) }}>
        <div className="flex gap-0.5 rounded-full bg-black/55 px-1 py-0.5" aria-label={`${n} of 4 rows`}>
          {Array.from({ length: ROWS }, (_, i) => <span key={i} className={`h-1.5 w-1.5 rounded-full sm:h-2 sm:w-2 ${i < n ? 'mr-pip bg-amber-300 shadow-[0_0_4px_#fbbf24]' : 'bg-white/25'}`} />)}
        </div>
        <div className="flex flex-col items-center gap-0.5">
          {w.mult > 1 && <div className={`rounded-md px-1.5 py-0.5 font-display text-sm leading-none text-white shadow-lg sm:text-base ${w.kind === 'W3' ? 'bg-red-700 ring-1 ring-red-200' : 'bg-blue-700 ring-1 ring-blue-100'}`}>x{w.mult}</div>}
          {!full && !vanish && <div className="whitespace-nowrap rounded bg-black/60 px-1 text-[9px] font-bold uppercase tracking-wide text-amber-100 sm:text-[10px]">{left} spin{left === 1 ? '' : 's'} left</div>}
        </div>
      </div>
      {fx === 'land' && <><div key={`r${w.id}`} className="mr-ring absolute h-16 w-16 rounded-full border-4 border-amber-200" style={{ left: '50%', top: `${((w.startRow + 0.5) / ROWS) * 100}%` }} /><div className="absolute left-1/2 -translate-x-1/2" style={{ top: `${((w.startRow + 0.5) / ROWS) * 100}%` }}><Burst game="moonridge" n={16} spread={70} /></div></>}
      {fx === 'lock' && (
        <div className="mr-lock absolute left-1/2 -translate-x-1/2 -translate-y-1/2" style={{ top: `${((w.startRow + 0.5) / ROWS) * 100}%` }}>
          <svg viewBox="0 0 24 24" className="h-7 w-7 drop-shadow-[0_0_6px_#fbbf24]" aria-hidden="true"><rect x="4" y="10" width="16" height="12" rx="2" fill="#fbbf24" stroke="#1c1205" strokeWidth="1.5" /><path d="M8 10V7a4 4 0 018 0v3" stroke="#fde68a" strokeWidth="2.5" fill="none" /></svg>
        </div>
      )}
      {full && !vanish && <div className="mr-label absolute inset-x-0 top-[40%] text-center font-display text-lg leading-tight text-amber-100 drop-shadow-[0_0_10px_#f59e0b] sm:text-2xl">FULL<br />MOON</div>}
    </div>
  );
}

function Reel({ index, cells, spinning, landKey, lit, special, wild, fx, turbo }) {
  return (
    <div className="relative overflow-hidden rounded-lg bg-black/35 ring-1 ring-amber-200/10" style={{ aspectRatio: `1 / ${ROWS}` }}>
      {spinning ? (
        <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 40}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-0.5 opacity-80 blur-[1.5px]"><MoonSym s={BLUR[(k * 5 + index * 3) % BLUR.length]} /></div>)}
        </div>
      ) : (
        <div key={landKey} className="p3-land-bounce">
          {cells.map((s, row) => {
            const k = `${index}-${row}`, on = lit?.has(k), sp = special?.has(k);
            return (
              <div key={row} className={`relative aspect-square p-0.5 ${lit?.size && !on ? 'p3-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'p3-win' : ''} ${sp ? 'mr-jp' : ''}`} style={{ '--glow': '#fbbf24' }}>{s ? <MoonSym s={s} /> : <div className="flex h-full w-full items-center justify-center rounded-md bg-amber-200/[0.04] ring-1 ring-amber-200/10"><svg viewBox="0 0 100 100" className="h-1/2 w-1/2 opacity-15" aria-hidden="true">{PAW}</svg></div>}</div>
                {on && <Burst key={landKey} game="moonridge" n={6} spread={36} />}
              </div>
            );
          })}
        </div>
      )}
      {wild && <WildColumn key={wild.id} w={wild} fx={fx} lit={lit && [...lit].some((k) => k.startsWith(`${index}-`))} />}
    </div>
  );
}

function WinLines({ wins, id }) {
  if (!wins?.length) return null;
  return (
    <svg key={id} viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 z-20 h-full w-full" aria-hidden="true">
      {wins.slice(0, 12).map((w, i) => {
        const pts = LINES[w.line].slice(0, w.count).map((row, reel) => `${(reel + 0.5) * 20},${(row + 0.5) * 25}`).join(' ');
        const c = LINE_COLOURS[i % LINE_COLOURS.length];
        return (
          <g key={i}>
            <polyline points={pts} fill="none" stroke={c} strokeOpacity=".4" strokeWidth="8" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" className="fr-line" style={{ animationDelay: `${i * 0.07}s` }} />
            <polyline points={pts} fill="none" stroke="#fff" strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" className="fr-line" style={{ animationDelay: `${i * 0.07}s`, filter: `drop-shadow(0 0 4px ${c})` }} />
          </g>
        );
      })}
    </svg>
  );
}

function Switch({ label, hint, on, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!on)} aria-pressed={on} className="flex w-full items-center justify-between gap-4 rounded-lg bg-navy-800 px-3 py-2.5 text-left text-sm text-slate-200 hover:bg-navy-700">
      <span>{label}{hint && <span className="block text-[11px] text-slate-500">{hint}</span>}</span>
      <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? 'bg-amber-400' : 'bg-navy-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
    </button>
  );
}

function Choice({ label, value, options, onChange, fmt = (v) => v }) {
  return (
    <div>
      <div className="mb-1 text-xs font-semibold text-slate-400">{label}</div>
      <div className="flex flex-wrap gap-1.5">{options.map((o) => <button key={o} type="button" onClick={() => onChange(o)} className={`rounded-md px-3 py-1.5 text-sm font-semibold ${value === o ? 'bg-amber-400 text-navy-950' : 'bg-navy-700 text-slate-200 hover:bg-navy-600'}`}>{fmt(o)}</button>)}</div>
    </div>
  );
}

const pays = (bet, h) => money(Math.floor((bet * h) / 100));

export default function Moonridge() {
  const { user, view, history, play, commit, guard, shake, doShake } = usePremium('moonridge');
  const fx = useMemo(() => moonSfx(), []);
  const reels = useReelStops(5);
  const [cells, setCells] = useState(START);
  const [wilds, setWilds] = useState([]);
  const [wfx, setWfx] = useState({});
  const [lit, setLit] = useState(null);
  const [special, setSpecial] = useState(null);
  const [lines, setLines] = useState(null);
  const [running, setRunning] = useState(0);
  const [res, setRes] = useState(null);
  const [stake, setStake] = useState(100);
  const [turbo, setTurbo] = useState(() => pref('mr_turbo', false));
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [outro, setOutro] = useState(null);
  const [banner, setBanner] = useState(null);
  const [freeAuto, setFreeAuto] = useState(false);
  const [auto, setAuto] = useState(null); // { left, lossLimit, stopWinX, startBalance }
  const [autoOpen, setAutoOpen] = useState(false);
  const [autoCfg, setAutoCfg] = useState({ count: 10, lossLimit: 2000, stopWinX: 50 });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [space, setSpace] = useState(() => pref('mr_space', true));
  const [showLines, setShowLines] = useState(() => pref('mr_lines', true));
  const [quickWins, setQuickWins] = useState(() => pref('mr_quick', false));
  const [lastWin, setLastWin] = useState(0);
  const free = view?.free;
  const bet = free ? free.bet : stake;
  const t = useCallback((ms) => sleep(turbo ? ms * 0.4 : ms), [turbo]);

  // Restore the wilds standing on the reels (persisted on the server)
  useEffect(() => { if (view && !spinning) setWilds(view.wilds || []); }, [view?.spin]); // eslint-disable-line react-hooks/exhaustive-deps

  const spin = () => guard(async () => {
    setSpinning(true); setRes(null); setLines(null); setLit(null); setSpecial(null); setRunning(0); setWfx({}); setBanner(null);
    fx.spin();
    setSpinId((n) => n + 1); reels.start();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(); setSpinning(false); setAuto(null); setFreeAuto(false); return; }

    // 1. Standing wilds advance: grow one row; full columns light up
    if (out.grown.length) {
      setWilds(out.grown);
      const g = {};
      for (const w of out.grown) g[w.id] = w.stage === 'FULL_COLUMN' ? 'full' : 'grow';
      setWfx(g);
      const fullOnes = out.grown.filter((w) => w.stage === 'FULL_COLUMN');
      fx.wildGrow(Math.max(...out.grown.map((w) => w.occupied.length)));
      await t(560);
      if (fullOnes.length) { fx.wildFull(); doShake(fullOnes.length > 1); await t(1100); }
    }

    // 2. Reels stop one by one; new wilds slam in as their reel stops
    setCells(out.drawn.map((col) => col.map((s) => s)));
    const landedBy = Object.fromEntries(out.landed.map((w) => [w.reel, w]));
    let seen = 0;
    const tease = [];
    out.drawn.forEach((col, r) => { if (seen >= 2) tease.push(r); if (col.includes('BONUS')) seen++; });
    await reels.stopAll({
      turbo, tease,
      onStop: (r) => {
        fx.stop(r);
        if (out.drawn[r].includes('BONUS')) fx.scatter();
        const w = landedBy[r];
        if (w) {
          setWilds((cur) => [...cur.filter((x) => x.reel !== r), { ...w, stage: 'LANDING', occupied: [w.startRow] }]);
          setWfx((cur) => ({ ...cur, [w.id]: 'land' }));
          fx.wildLand();
        }
      },
    });
    if (out.landed.length) {
      await t(350);
      setWfx((cur) => ({ ...cur, ...Object.fromEntries(out.landed.map((w) => [w.id, 'lock'])) }));
      fx.wildLock();
      if (!pref('mr_seen_wild', false)) { save('mr_seen_wild', true); setBanner({ id: Date.now(), title: 'DELAYED EXPANDING WILD', text: 'Locks in place, grows one row every spin, fills its reel on the 3rd spin, then howls and vanishes.' }); }
      await t(500);
    }

    // 3. Wins
    const litCells = new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`)));
    const sp = new Set([...out.scatter.count >= 3 ? out.scatter.cells : [], ...(out.jackpot?.cells || [])].map(([r, c]) => `${r}-${c}`));
    sp.forEach((k) => litCells.add(k));
    if (litCells.size) {
      setLit(litCells); setSpecial(sp);
      if (showLines) setLines(out.wins);
      setRunning(out.win);
      if (out.wins.length) fx.win(out.wins.some((w) => w.mult > 1) ? 2 : 1);
      if (out.scatter.win) fx.scatter();
      if (out.jackpot) fx.jackpot();
      await t(out.jackpot ? 1400 : 1200);
    }

    // 4. Completed wilds vanish
    if (out.completed.length) {
      setWfx((cur) => ({ ...cur, ...Object.fromEntries(out.completed.map((w) => [w.id, 'vanish'])) }));
      fx.wildVanish();
      await t(900);
    }
    setWilds(out.after); setWfx({});

    setRes(out); setSpinning(false); commit();
    if (out.win) setLastWin(out.win);
    const tier = tierOf(out.win, out.staked, out.bet);
    if (out.jackpot) setBig({ amount: out.win, title: `${out.jackpot.name.toUpperCase()} JACKPOT`, coin: JACKPOTS[out.jackpot.tier].sym });
    else if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); }
    else if (tier === 2) doShake(false);
    if (out.trigger?.freeSpins) { fx.freeStart(); setIntro(out.trigger.freeSpins); setAuto(null); }
    if (out.trigger?.extra) setBanner({ id: Date.now(), title: `+${out.trigger.extra} FREE SPIN${out.trigger.extra > 1 ? 'S' : ''}`, text: 'Bonus symbols add spins to the round.' });
    if (out.finished) { setOutro(out.finished); setFreeAuto(false); }

    // Autoplay bookkeeping (paid spins only)
    if (!free) setAuto((a) => {
      if (!a) return a;
      const balanceAfter = (user?.balance ?? 0) - stake + out.win;
      const lost = a.startBalance - balanceAfter;
      if (a.left - 1 <= 0 || lost >= a.lossLimit || (a.stopWinX && out.win >= stake * a.stopWinX) || out.trigger?.freeSpins || balanceAfter < stake) return null;
      return { ...a, left: a.left - 1 };
    });
  });

  // Paid autoplay and free-spin autoplay
  useEffect(() => {
    const ready = !spinning && !big && !intro && !outro && !autoOpen && !settingsOpen;
    if (!ready) return undefined;
    if (free && (freeAuto || auto)) { const id = setTimeout(spin, turbo ? 350 : 800); return () => clearTimeout(id); }
    if (!free && auto) {
      if ((user?.balance ?? 0) < stake) { setAuto(null); return undefined; }
      const id = setTimeout(spin, turbo ? 350 : 750); return () => clearTimeout(id);
    }
    return undefined;
  }, [auto, freeAuto, free, spinning, big, intro, outro, autoOpen, settingsOpen]); // eslint-disable-line react-hooks/exhaustive-deps

  // Stop autoplay when leaving the tab
  useEffect(() => { const h = () => { if (document.hidden) setAuto(null); }; document.addEventListener('visibilitychange', h); return () => document.removeEventListener('visibilitychange', h); }, []);

  // Space bar to spin (desktop)
  const spinRef = useRef(spin); spinRef.current = spin;
  useEffect(() => {
    if (!space) return undefined;
    const h = (e) => {
      if (e.code !== 'Space' || e.repeat || ['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(e.target.tagName)) return;
      e.preventDefault();
      if (big) setBig(null); else if (!spinning && !intro && !outro) spinRef.current();
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [space, spinning, big, intro, outro]);

  const low = !free && (user?.balance ?? 0) < stake;
  const byReel = Object.fromEntries(wilds.map((w) => [w.reel, w]));
  const i = Math.max(0, STAKES.indexOf(stake));
  const detail = res && [res.wins.length && `${res.wins.length} line win${res.wins.length > 1 ? 's' : ''}`, res.wins.some((w) => w.mult > 1) && `wild multiplier up to x${Math.max(...res.wins.map((w) => w.mult))}`, res.scatter.win && `${res.scatter.count} bonus`, res.jackpot && `${res.jackpot.name} jackpot`, res.capped && `capped at ${MAX_WIN_X.toLocaleString()}x`].filter(Boolean).join(' · ');

  const wildStatus = (
    <div className="grid grid-cols-5 gap-1">
      {[0, 1, 2, 3, 4].map((r) => {
        const w = byReel[r];
        return (
          <div key={r} className={`rounded-md px-1 py-1 text-center text-[10px] font-bold leading-tight ${w ? 'bg-amber-400/15 text-amber-100 ring-1 ring-amber-300/50' : 'bg-black/30 text-slate-500'}`}>
            <div>Reel {r + 1}</div>
            {w ? <><div className="mt-0.5 flex justify-center gap-0.5">{[0, 1, 2, 3].map((k) => <span key={k} className={`h-1.5 w-1.5 rounded-full ${k < w.occupied.length ? 'bg-amber-300' : 'bg-white/20'}`} />)}</div><div>{KIND_LABEL[w.kind]}</div></> : <div className="mt-0.5">–</div>}
          </div>
        );
      })}
    </div>
  );

  const bar = (
    <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || !!free || !!auto || i <= 0} onClick={() => setStake(STAKES[i - 1])} aria-label="Lower bet">−</button>
          <div className="w-[4.4rem] text-center leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{free ? 'Free spin' : 'Bet'}</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(bet)}</div></div>
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || !!free || !!auto || i >= STAKES.length - 1} onClick={() => setStake(STAKES[i + 1])} aria-label="Raise bet">+</button>
        </div>
        {auto ? (
          <button onClick={() => setAuto(null)} className="btn h-14 flex-1 rounded-full bg-red-600 text-base font-extrabold text-white hover:bg-red-500">Stop autoplay · {auto.left} left</button>
        ) : (
          <button onClick={spin} disabled={spinning || low || !!intro || !!outro}
            className={`btn h-14 flex-1 rounded-full text-lg font-extrabold shadow-lg transition-transform active:scale-95 ${free ? 'bg-gradient-to-b from-red-300 to-red-600 text-white' : 'bg-gradient-to-b from-amber-200 to-amber-500 text-amber-950'}`}>
            {spinning ? 'Spinning…' : free ? `Free spin · ${free.remaining} left` : low ? 'Not enough balance' : 'Spin'}
          </button>
        )}
      </div>
      <div className="flex items-center justify-between gap-1.5 text-xs text-slate-400">
        <div className="flex gap-1.5">
          <button onClick={() => setAutoOpen(true)} disabled={!!auto || !!free || spinning} className="rounded-md bg-navy-700 px-2.5 py-1 font-semibold text-slate-200 disabled:opacity-40">Auto</button>
          <button onClick={() => { setTurbo((v) => { save('mr_turbo', !v); return !v; }); }} className={`rounded-md px-2.5 py-1 font-semibold ${turbo ? 'bg-amber-400 text-navy-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Turbo</button>
          <button onClick={() => setSettingsOpen(true)} className="rounded-md bg-navy-700 px-2 py-1 text-slate-200" aria-label="Settings">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.6 1.6 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.6 1.6 0 00-1.8-.3 1.6 1.6 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.6 1.6 0 00-1-1.5 1.6 1.6 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.6 1.6 0 00.3-1.8 1.6 1.6 0 00-1.5-1H3a2 2 0 110-4h.1a1.6 1.6 0 001.5-1 1.6 1.6 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.6 1.6 0 001.8.3H9a1.6 1.6 0 001-1.5V3a2 2 0 114 0v.1a1.6 1.6 0 001 1.5 1.6 1.6 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.6 1.6 0 00-.3 1.8V9a1.6 1.6 0 001.5 1H21a2 2 0 110 4h-.1a1.6 1.6 0 00-1.5 1z" /></svg>
          </button>
        </div>
        <div className="flex gap-3 text-right">
          <span>Last win <b className="tabular-nums text-amber-200">{money(lastWin)}</b></span>
          <span>Balance <b className="tabular-nums text-slate-200">{money(user?.balance ?? 0)}</b></span>
        </div>
      </div>
    </div>
  );

  const ptRows = Object.entries(PAYTABLE);
  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">The Delayed Expanding Wild</h3>
        <p>Three special wolf wilds can land on any reel: <b className="text-blue-300">x2</b>, <b className="text-red-300">x3</b> and <b className="text-amber-300">Gold</b> (no multiplier). When one lands it <b className="text-amber-200">locks in place</b> and stays there while the other positions keep spinning. At the start of each of the next spins it grows by one row, spreading out from where it landed. On the <b>third spin after landing</b> it fills the whole reel, plays its Full Moon animation, counts as a full wild reel for that spin, and then disappears. The reel goes back to normal on the next spin.</p>
        <p>Several expanding wilds can be on the reels at once, one per reel, each with its own progress. If another expanding wild lands on a reel that already holds one, it becomes an ordinary wild for that spin. Wilds stay on the reels between sessions and carry into and out of free spins.</p>
        <p><b>Multipliers</b>: a line win is multiplied by every x2 or x3 wild cell it runs through, and they multiply together (x2 and x3 on one line make x6).</p>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">Paytable at {money(bet)} per spin</h3>
        <p className="mb-2 text-xs text-slate-400">Wins pay left to right on {LINES.length} fixed lines, starting from reel 1. Only the best win on each line pays. Wilds substitute for all symbols except Bonus and jackpot coins.</p>
        <div className="grid grid-cols-2 gap-2">
          {ptRows.map(([s, p]) => (
            <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
              <div className="h-11 w-11 shrink-0"><MoonSym s={s} /></div>
              <div className="min-w-0 text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">{MOON_NAMES[s]}</div>{p.map((v, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{pays(bet, v)}</b></div>)}</div>
            </div>
          ))}
          <div className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
            <div className="h-11 w-11 shrink-0"><MoonSym s="BONUS" /></div>
            <div className="text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">Bonus (anywhere)</div>{[3, 4, 5].map((n) => <div key={n}><span className="text-slate-500">{n}×</span> <b className="text-white">{pays(bet, SCATTER_PAY[n])}</b></div>)}</div>
          </div>
        </div>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Free spins</h3>
        <p>3 or more Bonus symbols anywhere pay as shown and award <b>{FREE_SPINS} free spins</b> at the triggering bet. In free spins the expanding wilds land more often and work exactly as in the base game. Every Bonus symbol that lands during free spins adds {RETRIGGER_PER_BONUS} more spin.</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Jackpots</h3>
        <p>The same jackpot coin on 3 or more adjacent reels wins that fixed jackpot (only the highest pays):</p>
        <div className="grid grid-cols-5 gap-1.5 text-center text-[11px]">
          {JACKPOTS.map((j) => <div key={j.sym} className="rounded-lg bg-navy-800 p-1"><svg viewBox="0 0 100 100" className="mx-auto h-9 w-9">{MOON_ART[j.sym]}</svg><div className="font-bold text-white">{j.name}</div><div>{+(j.pay / 100).toFixed(1)}x</div><div className="text-amber-200">{pays(bet, j.pay)}</div></div>)}
        </div>
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Maths</b>: long-run return about 95% (verified over 12 million simulated spins) · high volatility · wins on about half of spins, though many return less than the bet · free spins about 1 in 185 spins · maximum win {MAX_WIN_X.toLocaleString()}x the bet per spin. Every result comes from the server's cryptographic random number generator before any animation plays.
      </section>
      <section className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3 text-xs text-slate-300">
        <b className="text-amber-200">About this game</b>: Moonridge is an original game inspired by the mechanics of King Show Games' <i>Wolf Peak</i>. The layout, line pays, scatter pays, free spins, jackpot values and maximum win follow published reviews of that game. Its reel weights are not public, so ours are tuned by simulation. A few rule details could not be confirmed (see README); where that happened, the choice made here is stated above.
      </section>
    </>
  );

  return (
    <PremiumShell game="moonridge" rtp="95%" tagline="5 × 4 · 40 lines · delayed expanding wilds · 5 jackpots" shake={shake}
      stageClass={`border-2 ${free ? 'border-red-300/60 shadow-[0_0_60px_rgba(239,68,68,0.3)]' : 'border-amber-300/50 shadow-[0_0_60px_rgba(251,191,36,0.25)]'}`} bg={<MoonScene free={!!free} />}
      below={<>{bar}
      <Modal open={autoOpen} onClose={() => setAutoOpen(false)} title="Autoplay">
        <div className="space-y-4 text-sm text-slate-300">
          <Choice label="Number of spins" value={autoCfg.count} options={[10, 25, 50, 100]} onChange={(count) => setAutoCfg((c) => ({ ...c, count }))} />
          <Choice label="Stop if I lose more than (required)" value={autoCfg.lossLimit} options={[500, 1000, 2000, 5000, 10000]} fmt={money} onChange={(lossLimit) => setAutoCfg((c) => ({ ...c, lossLimit }))} />
          <Choice label="Stop on a single win of" value={autoCfg.stopWinX} options={[0, 10, 50, 100]} fmt={(v) => (v ? `${v}x bet` : 'Off')} onChange={(stopWinX) => setAutoCfg((c) => ({ ...c, stopWinX }))} />
          <p className="text-xs text-slate-400">Autoplay always stops when free spins start, when you leave this tab, when your balance can't cover the bet, or when you tap Stop. Your daily limits and breaks still apply to every spin.</p>
          <button className="btn w-full bg-amber-400 font-bold text-navy-950 hover:bg-amber-300" onClick={() => { setAuto({ left: autoCfg.count, lossLimit: autoCfg.lossLimit, stopWinX: autoCfg.stopWinX, startBalance: user?.balance ?? 0 }); setAutoOpen(false); }}>
            Start {autoCfg.count} spins at {money(stake)}
          </button>
        </div>
      </Modal>
      <Modal open={settingsOpen} onClose={() => setSettingsOpen(false)} title="Settings">
        <div className="space-y-2">
          <Switch label="Turbo spin" hint="Faster reels and animations" on={turbo} onChange={(v) => { setTurbo(v); save('mr_turbo', v); }} />
          <Switch label="Show win lines" on={showLines} onChange={(v) => { setShowLines(v); save('mr_lines', v); }} />
          <Switch label="Quick win celebrations" hint="Shows a skip button on big wins straight away" on={quickWins} onChange={(v) => { setQuickWins(v); save('mr_quick', v); }} />
          <Switch label="Space bar to spin" hint="Desktop keyboards" on={space} onChange={(v) => { setSpace(v); save('mr_space', v); }} />
          <p className="px-1 pt-1 text-[11px] text-slate-500">Music and sound effects have their own switches under Sound, top right.</p>
        </div>
      </Modal>
      </>} info={info}
      side={<>
        <SidePanel title="Expanding wilds">{wildStatus}<p className="mt-2 text-[11px] text-slate-400">Each lit dot is one row filled. Full reel = 4 dots, then it vanishes.</p></SidePanel>
        <SidePanel title="How it works">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-amber-200">x2, x3 and Gold wilds</b> lock where they land.</li>
            <li>They grow <b className="text-amber-200">one row every spin</b> and fill the reel on the 3rd.</li>
            <li>Full reel: <b className="text-amber-200">Full Moon</b>, then the wild vanishes.</li>
            <li><b className="text-amber-200">3+ Bonus</b>: {FREE_SPINS} free spins.</li>
            <li>Same coin on <b className="text-amber-200">3+ adjacent reels</b>: jackpot.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      <div className={`relative pt-1 ${turbo ? 'mr-turbo' : ''}`}>
        {free && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="rounded-md bg-red-200 px-2.5 py-1 text-xs font-extrabold uppercase text-red-950 shadow-[0_0_16px_rgba(254,202,202,0.7)]">Blood Moon free spins · {free.remaining} left</div>
            <div className="rounded-md bg-black/50 px-2 py-1 text-xs font-bold text-red-100 ring-1 ring-red-300/50">Round win {money(free.total)}</div>
          </div>
        )}
        <div className="relative mx-auto rounded-2xl bg-[linear-gradient(160deg,#fde68a,#b45309_35%,#451a03_70%,#fbbf24)] p-[3px] shadow-[0_0_30px_rgba(251,191,36,0.3)]" style={{ maxWidth: 'min(100%, calc((100dvh - 480px) * 1.25 + 24px))' }}>
          <div className="relative rounded-[13px] bg-[#07060f]/80 p-1.5 backdrop-blur-sm">
            <div className="relative mx-auto">
              <div className="grid grid-cols-5 gap-1 sm:gap-1.5">
                {[0, 1, 2, 3, 4].map((r) => {
                  const w = byReel[r];
                  const fullyHeld = w && w.occupied.length >= ROWS && wfx[w.id] !== 'land';
                  return <Reel key={r} index={r} cells={cells[r]} spinning={!reels.stopped[r] && !fullyHeld} landKey={`${spinId}-${r}`} lit={lit} special={special} wild={w} fx={w ? wfx[w.id] : null} turbo={turbo} />;
                })}
              </div>
              <WinLines wins={lines} id={`${spinId}-${running}`} />
            </div>
          </div>
        </div>
        <div className="mt-2 lg:hidden">{wildStatus}</div>
        {banner && (
          <div key={banner.id} className="fr-banner pointer-events-none absolute inset-x-2 top-[30%] z-30 flex justify-center" style={{ animationDuration: '3.2s' }}>
            <div className="max-w-sm rounded-2xl bg-amber-100/95 px-5 py-2.5 text-center text-amber-950 shadow-[0_0_30px_rgba(251,191,36,0.8)]">
              <div className="font-display text-xl tracking-wider">{banner.title}</div>
              <div className="text-xs font-semibold">{banner.text}</div>
            </div>
          </div>
        )}
        <div className="mt-2">
          <div className="flex min-h-14 flex-col items-center justify-center rounded-xl bg-black/45 px-2 py-1.5 text-center leading-tight backdrop-blur-sm">
            {spinning && running ? <div className="font-cond text-3xl font-extrabold tabular-nums text-white">{money(running)}</div>
              : res?.win ? <><WinAmount win={res.win} staked={res.staked} />{detail && <div className="mt-0.5 text-[11px] text-white/75">{detail}</div>}</>
                : <div className="text-sm text-white/65">{spinning ? 'The pack is listening…' : res ? (wilds.length ? `${wilds.length} wild${wilds.length > 1 ? 's' : ''} still growing` : 'No win this time') : 'Set your bet and spin'}</div>}
          </div>
        </div>
        {intro && (
          <FeatureIntro title="BLOOD MOON" subtitle={`${intro} free spins at ${money(bet)}. Expanding wilds land more often, and every Bonus symbol adds a spin. Wilds already growing carry on.`}
            art={<svg viewBox="0 0 100 100" className="fr-moonrise mb-2 h-32 w-32" aria-hidden="true">{MOON_LOBBY}</svg>}
            className="bg-[radial-gradient(ellipse_at_top,rgba(127,29,29,0.95),rgba(12,4,8,0.97))]" cta="Start free spins"
            onStart={() => { setIntro(null); setFreeAuto(true); }} />
        )}
        {outro && (
          <FeatureIntro title="FREE SPINS COMPLETE" subtitle={`${outro.played} free spins won ${money(outro.total)}.`}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-24 w-24" aria-hidden="true">{MOON_LOBBY}</svg>}
            className="bg-[radial-gradient(ellipse_at_top,rgba(120,53,15,0.95),rgba(12,4,8,0.97))]" cta="Back to the base game"
            onStart={() => setOutro(null)} />
        )}
        {big && <BigWin game="moonridge" amount={big.amount} bet={res?.bet || stake} title={big.title} onDone={() => setBig(null)}
          cinematic={big.coin ? <svg viewBox="0 0 100 100" className="mr-jp pointer-events-none absolute left-1/2 top-[8%] h-28 w-28 -translate-x-1/2" aria-hidden="true">{MOON_ART[big.coin]}</svg>
            : <svg viewBox="0 0 100 100" className="fr-moonrise pointer-events-none absolute inset-0 h-full w-full opacity-25" preserveAspectRatio="xMidYMid slice" aria-hidden="true">{MOON_LOBBY}</svg>} />}
        {quickWins && big && <QuickClose onClose={() => setBig(null)} />}
      </div>
    </PremiumShell>
  );
}

function QuickClose({ onClose }) {
  return <button onClick={onClose} className="absolute right-3 top-3 z-50 rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-navy-950">Skip</button>;
}
