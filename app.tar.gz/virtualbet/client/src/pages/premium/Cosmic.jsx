import { useEffect, useMemo, useState } from 'react';
import { BigWin, Burst, FeatureIntro, Paytable, PremiumShell, RecentList, SidePanel, sleep, SpinBar, tierOf, usePremium, WinLine } from '../../components/Premium.jsx';
import { NAMES3, Sym3 } from '../../components/SlotArt3.jsx';
import { CO_COLS, CO_GMAX, CO_METEOR_P, CO_ORBS, CO_PAY, CO_ROWS, CO_S, STATS3 } from '../../../../server/games/slots3.js';

const SYMS = ['ASTEROID', 'COMET', 'MOON', 'CRYSTAL', 'SATELLITE', 'PLANET', 'SUN', 'GALAXY'];
const START = Array.from({ length: CO_COLS }, (_, c) => Array.from({ length: CO_ROWS }, (_, r) => ({ s: SYMS[(c * 3 + r * 5) % SYMS.length] })));

function Space({ hole }) {
  const stars = useMemo(() => Array.from({ length: 50 }, (_, i) => ({ x: (i * 53) % 100, y: (i * 29) % 100, s: i % 7 === 0 ? 2 : 1, d: `${2 + (i % 5)}s`, delay: `${-(i % 9) * 0.4}s` })), []);
  const [meteorKey, setMeteorKey] = useState(0);
  useEffect(() => { const t = setInterval(() => setMeteorKey((k) => k + 1), 9000); return () => clearInterval(t); }, []);
  return (
    <>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,#312e81_0%,#1e1b4b_30%,#020617_75%)]" />
      <div className="p3-deco p3-galaxy absolute -right-1/4 -top-1/4 h-[90%] w-[90%] rounded-full opacity-40 blur-[2px] [background:conic-gradient(from_0deg,transparent,rgba(192,132,252,0.5),transparent_30%,rgba(56,189,248,0.4),transparent_60%,rgba(244,114,182,0.45),transparent)] [mask-image:radial-gradient(circle,black_20%,transparent_70%)]" />
      {stars.map((st, i) => <span key={i} className="absolute rounded-full bg-white" style={{ left: `${st.x}%`, top: `${st.y}%`, width: st.s, height: st.s, animation: `p3-twinkle ${st.d} ease-in-out ${st.delay} infinite` }} />)}
      <div className="absolute bottom-[8%] left-[6%] h-12 w-12 rounded-full bg-[radial-gradient(circle_at_35%_35%,#fdba74,#c2410c_60%,#431407)] opacity-70 shadow-[0_0_30px_rgba(251,146,60,0.4)]" />
      {meteorKey > 0 && <span key={meteorKey} className="p3-deco p3-meteor right-0 top-[10%]" />}
      {hole && <div className="p3-deco p3-hole absolute left-1/2 top-1/2 h-[70%] w-[70%] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-30 [background:conic-gradient(#000,#7c3aed,#000,#f472b6,#000)] [mask-image:radial-gradient(circle,transparent_18%,black_22%,transparent_70%)]" />}
    </>
  );
}

export default function Cosmic() {
  const { user, view, history, play, commit, fx, guard, shake, doShake } = usePremium('cosmic');
  const [grid, setGrid] = useState(START);
  const [gen, setGen] = useState(0);
  const [boom, setBoom] = useState(new Set());
  const [flash, setFlash] = useState(new Set());
  const [meteors, setMeteors] = useState(null);
  const [hole, setHole] = useState(null);
  const [running, setRunning] = useState(0);
  const [gravity, setGravity] = useState(null);
  const [res, setRes] = useState(null);
  const [stake, setStake] = useState(100);
  const [turbo, setTurbo] = useState(false);
  const [auto, setAuto] = useState(false);
  const [spinning, setSpinning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const free = view?.free;
  const T = (ms) => sleep(turbo ? ms * 0.45 : ms);

  const spin = () => guard(async () => {
    setSpinning(true); setRes(null); setBoom(new Set()); setFlash(new Set()); setRunning(0); setGravity(null); setMeteors(null); fx.spin();
    setGrid((g) => g.map((col) => col.map(() => null))); setGen((n) => n + 1);
    const out = await play('spin', free ? {} : { stake });
    if (!out) { setGrid(START); setSpinning(false); setAuto(false); return; }
    // Black Hole: show the transformation first
    if (out.transform) { setHole(out.transform); fx.special(); await T(1300); }
    setGrid(out.steps[0].grid); setGen((n) => n + 1); fx.stop(0);
    await T(650);
    if (out.transform?.cells.length) { setFlash(new Set(out.transform.cells.map(([c, r]) => `${c}-${r}`))); await T(700); setFlash(new Set()); }
    setHole(null);
    if (out.meteors) { setMeteors(out.meteors); fx.special(); await T(1000); setMeteors(null); doShake(false); }
    let won = 0;
    for (let i = 0; i < out.steps.length; i++) {
      const st = out.steps[i];
      if (i > 0) { setGrid(st.grid); setGen((n) => n + 1); fx.stop(i); await T(560); }
      if (!st.wins.length) break;
      setBoom(new Set(st.removed.map(([c, r]) => `${c}-${r}`)));
      fx.win(1);
      won += st.win; setRunning(won);
      await T(760);
      setBoom(new Set());
    }
    if (out.mult > 1 && out.base) { setGravity(out.mult); fx.special(); doShake(false); await T(1100); }
    setRes(out); setSpinning(false); commit();
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); } else if (tier) fx.win(tier);
    if (out.trigger?.freeSpins) { fx.bonus(); setIntro(out.trigger.freeSpins); }
    if (out.finished) setBig({ amount: out.finished.total, title: 'BLACK HOLE COMPLETE' });
    if (!out.free) setAuto(false);
  });
  useEffect(() => {
    if (!auto || !free || spinning || big || intro) return undefined;
    const t = setTimeout(spin, 800);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro]); // eslint-disable-line react-hooks/exhaustive-deps

  const meteorSet = new Set((meteors || []).map(([c, r]) => `${c}-${r}`));
  const pt = Object.entries(CO_PAY).map(([s, v]) => [s, v.map((x) => x * CO_S)]);
  const detail = res && [res.steps.length > 2 && `${res.steps.length - 1} tumbles`, res.mult > 1 && `Gravity x${res.mult}`, res.meteors && 'Meteor Shower'].filter(Boolean).join(' · ');
  return (
    <PremiumShell game="cosmic" rtp="96%" tagline="6 × 5 · pays anywhere · tumbles · gravity multipliers" shake={shake}
      stageClass="border border-violet-400/50 shadow-[0_0_50px_rgba(139,92,246,0.35)]" bg={<Space hole={!!free} />}
      below={<SpinBar stake={stake} setStake={setStake} onSpin={spin} spinning={spinning} free={free} disabled={!!intro} balance={user?.balance} turbo={turbo} setTurbo={setTurbo} auto={auto} setAuto={setAuto} accent="bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white" />}
      side={<>
        <SidePanel title="Features">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-violet-300">8+ anywhere</b> pays, then tumbles.</li>
            <li><b className="text-fuchsia-300">Gravity orbs</b> add up to multiply the whole tumble.</li>
            <li><b className="text-amber-300">Meteor Shower</b> turns symbols into Cosmic Wilds.</li>
            <li><b className="text-sky-300">4+ black holes</b>: transforming free spins.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Recent spins"><RecentList history={history} /></SidePanel>
      </>}
      info={<>
        <section><h3 className="mb-2 font-bold text-white">Paytable (multiples of total stake)</h3><Paytable game="cosmic" rows={pt} heads={['8-9:', '10-11:', '12+:']} /></section>
        <section className="space-y-2">
          <h3 className="font-bold text-white">How it plays</h3>
          <p><b>Pays anywhere</b>: 8 or more of the same symbol anywhere on the 6 × 5 grid pays. Winning symbols explode, everything above falls, and new symbols drop in; this repeats while new wins form.</p>
          <p><b className="text-violet-300">Cosmic Wild</b> counts as every symbol at once.</p>
          <p><b className="text-fuchsia-300">Gravity orbs</b> ({CO_ORBS.map(([v]) => `x${v}`).join(', ')}) stay on the grid through the tumbles. If the spin wins, all orb values are added together and multiply the total.</p>
          <p><b className="text-amber-300">Meteor Shower</b>: about {Math.round(CO_METEOR_P * 100)}% of paid spins, meteors strike 3–6 symbols and turn them into Cosmic Wilds.</p>
          <p><b className="text-sky-300">Black Hole round</b>: 4 or more black holes give 10 free spins. On every free spin the black hole transforms all of one low symbol into a higher one, and gravity orbs on winning spins add to a round multiplier that keeps building (up to x{CO_GMAX}). 3 black holes add 5 spins.</p>
        </section>
        <section className="rounded-lg bg-navy-800 p-3 text-xs"><b className="text-white">Maths</b>: long-run return 96% · wins on about {STATS3.cosmic.hit} of spins · {STATS3.cosmic.feature} · maximum win 5,000x per spin · results come from a cryptographic random number generator before anything animates.</section>
      </>}>
      <div className="relative">
        {free && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="rounded-md bg-violet-500 px-2.5 py-1 text-xs font-extrabold uppercase text-white shadow-[0_0_14px_#8b5cf6]">Black Hole · {free.remaining} left</div>
            <div className="rounded-md bg-black/60 px-2 py-0.5 text-xs font-bold text-fuchsia-200 ring-1 ring-fuchsia-400/50">Gravity <span key={free.gmult} className="p3-stamp inline-block font-display text-xl text-white">x{free.gmult || 1}</span></div>
          </div>
        )}
        <div className="relative rounded-2xl bg-slate-950/50 p-1.5 ring-1 ring-violet-300/30 backdrop-blur-[1px]">
          <div className="mx-auto grid grid-cols-6 gap-1" style={{ maxWidth: 'min(100%, calc((100dvh - 480px) * 1.2))' }}>
            {grid.map((col, c) => (
              <div key={c} className="grid gap-1">
                {col.map((cell, r) => {
                  const k = `${c}-${r}`, blown = boom.has(k);
                  return (
                    <div key={`${gen}-${k}`} className={`relative aspect-square ${cell ? (blown ? '' : 'p3-land-warp') : ''}`} style={{ animationDelay: `${c * 35 + (CO_ROWS - r) * 30}ms` }}>
                      {cell && <div className={`h-full w-full transition-transform duration-300 ${blown ? 'scale-125 opacity-0' : ''} ${flash.has(k) ? 'p3-win' : ''}`} style={{ '--glow': '#c084fc' }}><Sym3 game="cosmic" s={cell.s} v={cell.v} /></div>}
                      {blown && <><div className="p3-supernova absolute inset-0" /><Burst game="cosmic" n={6} spread={30} /></>}
                      {meteorSet.has(k) && <span className="p3-meteor" style={{ right: '-20%', top: '-40%', '--d': '0.7s', '--delay': `${(c + r) * 40}ms` }} />}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
          {hole && (
            <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center">
              <div className="p3-hole h-36 w-36 rounded-full [background:conic-gradient(#000,#7c3aed,#000,#f472b6,#000)] [mask-image:radial-gradient(circle,transparent_22%,black_26%,transparent_72%)]" />
              <div className="absolute h-14 w-14 rounded-full bg-black shadow-[0_0_30px_10px_rgba(124,58,237,0.6)]" />
              <div className="p3-stamp absolute bottom-6 rounded-full bg-black/70 px-3 py-1 text-sm font-bold text-white">{NAMES3[hole.from]} → {NAMES3[hole.to]}</div>
            </div>
          )}
          {gravity && (
            <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
              <div className="p3-stamp rounded-full bg-[radial-gradient(circle,#fef9c3,#a855f7_55%,#312e81)] px-6 py-4 text-center ring-4 ring-violet-300 drop-shadow-[0_0_30px_#a855f7]">
                <div className="text-[10px] font-extrabold uppercase tracking-widest text-white/90">Gravity</div><div className="font-display text-5xl text-white">x{gravity}</div>
              </div>
              <Burst game="cosmic" n={26} spread={160} />
            </div>
          )}
        </div>
        <div className="mt-2">
          {spinning && running ? <div className="flex min-h-14 items-center justify-center rounded-xl bg-black/45 font-cond text-3xl font-extrabold tabular-nums text-white">{(running / 100).toLocaleString('en-GB', { style: 'currency', currency: 'GBP' })}</div>
            : <WinLine res={res} spinning={spinning} detail={detail} busyText="Collapsing stars…" />}
        </div>
        {intro && (
          <FeatureIntro title="BLACK HOLE" subtitle={`${intro} free spins. Each spin the black hole transforms a low symbol into a higher one, and gravity keeps building.`}
            art={<div className="p3-hole mb-2 h-28 w-28 rounded-full [background:conic-gradient(#000,#7c3aed,#000,#f472b6,#000)] [mask-image:radial-gradient(circle,transparent_20%,black_26%,transparent_72%)]" />} onStart={() => { setIntro(null); setAuto(true); }} />
        )}
        {big && <BigWin game="cosmic" amount={big.amount} bet={res?.bet || stake} title={big.title} onDone={() => setBig(null)}
          cinematic={<div className="p3-supernova pointer-events-none absolute left-1/2 top-1/2 h-64 w-64 -translate-x-1/2 -translate-y-1/2 [animation-duration:1.6s]" />} />}
      </div>
    </PremiumShell>
  );
}
