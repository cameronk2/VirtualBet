import { useEffect, useMemo, useState } from 'react';
import { BigWin, Burst, FeatureIntro, Paytable, PremiumReels, PremiumShell, RecentList, SidePanel, sleep, SpinBar, tierOf, usePremium, useReelStops, WinLine } from '../../components/Premium.jsx';
import { Sym3 } from '../../components/SlotArt3.jsx';
import { NE_FREE, NE_MULTS, NE_PAY, NE_S, STATS3 } from '../../../../server/games/slots3.js';

const START = [['NODE', 'BIKE', 'CHIP', 'DISC'], ['WILD', 'VISOR', 'NODE', 'CORE'], ['DRONE', 'OVER', 'ANDROID', 'CHIP'], ['CORE', 'DISC', 'WILD', 'BIKE'], ['VISOR', 'NODE', 'DRONE', 'MULT']].map((c) => c.map((s) => (s === 'MULT' ? { s, v: 5 } : { s })));

function City({ pulse, overdrive }) {
  const towers = useMemo(() => [[0, 46, 18], [20, 30, 14], [36, 54, 20], [58, 24, 12], [72, 40, 16], [90, 34, 10]], []);
  const cars = useMemo(() => Array.from({ length: 6 }, (_, i) => ({ top: `${12 + i * 7}%`, d: `${5 + (i % 3) * 2.5}s`, delay: `${-i * 1.7}s`, c: ['#22d3ee', '#f472b6', '#a78bfa'][i % 3] })), []);
  return (
    <>
      <div className={`absolute inset-0 transition-colors duration-500 ${overdrive ? 'bg-[linear-gradient(180deg,#4a044e,#1e1b4b_45%,#020617)]' : 'bg-[linear-gradient(180deg,#0f0a2e,#1e1b4b_45%,#020617)]'}`} />
      <div className={`absolute inset-0 transition-opacity duration-300 ${pulse ? 'opacity-100' : 'opacity-0'} bg-[radial-gradient(ellipse_at_center,rgba(244,114,182,0.35),transparent_65%)]`} />
      <svg viewBox="0 0 100 60" preserveAspectRatio="none" className="absolute inset-x-0 top-[6%] h-[55%] w-full opacity-70" aria-hidden="true">
        {towers.map(([x, h, w], i) => (
          <g key={i}><rect x={x} y={60 - h} width={w} height={h} fill="#0b0b25" stroke={i % 2 ? '#7c3aed' : '#0e7490'} strokeWidth=".3" />
            {Array.from({ length: Math.floor(h / 5) }, (_, k) => <rect key={k} className="p3-flicker" style={{ animationDelay: `${-(i + k) * 0.7}s` }} x={x + 2} y={62 - h + k * 5} width={w - 4} height="1" fill={k % 3 ? '#22d3ee' : '#f472b6'} opacity=".35" />)}
          </g>
        ))}
      </svg>
      {cars.map((c, i) => <span key={i} className="p3-deco p3-car" style={{ top: c.top, '--d': c.d, animationDelay: c.delay, background: `linear-gradient(90deg, transparent, ${c.c})`, boxShadow: `0 0 8px ${c.c}` }} />)}
      <div className={`p3-deco p3-gridfloor absolute inset-x-[-30%] bottom-0 h-[30%] opacity-40 ${overdrive ? '[animation-duration:.4s]' : ''}`} />
      <div className="p3-scan absolute inset-0" />
    </>
  );
}

/** Electric arcs through one cell per reel of each winning way. */
function Lightning({ wins, rows, id }) {
  if (!wins?.length) return null;
  const paths = wins.slice(0, 3).map((w, k) => {
    const byReel = [];
    w.cells.forEach(([r, row]) => { if (byReel[r] === undefined) byReel[r] = row; });
    const pts = byReel.map((row, r) => [(r + 0.5) * 20, ((row + 0.5) / rows) * 100]);
    let d = `M${pts[0][0]} ${pts[0][1]}`;
    for (let i = 1; i < pts.length; i++) {
      const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
      const mx = (x0 + x1) / 2 + (Math.random() - 0.5) * 6, my = (y0 + y1) / 2 + (Math.random() - 0.5) * 12;
      d += ` L${mx} ${my} L${x1} ${y1}`;
    }
    return { d, c: ['#22d3ee', '#f472b6', '#a78bfa'][k] };
  });
  return (
    <svg key={id} viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 z-10 h-full w-full" aria-hidden="true">
      {paths.map((p, i) => <path key={i} d={p.d} className="p3-bolt" style={{ animationDelay: `${i * 0.15}s` }} stroke={p.c} strokeWidth="1.2" fill="none" vectorEffect="non-scaling-stroke" filter="url(#s3glow)" />)}
    </svg>
  );
}

export default function Neon() {
  const { user, view, history, play, commit, fx, guard, shake, doShake } = usePremium('neon');
  const reels = useReelStops(5);
  const [grid, setGrid] = useState(START);
  const [res, setRes] = useState(null);
  const [lit, setLit] = useState(null);
  const [stake, setStake] = useState(100);
  const [turbo, setTurbo] = useState(false);
  const [auto, setAuto] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [stamp, setStamp] = useState(null);
  const [pulse, setPulse] = useState(false);
  const free = view?.free;

  const spin = () => guard(async () => {
    setSpinning(true); setRes(null); setLit(null); setStamp(null); setSpinId((n) => n + 1); reels.start(); fx.spin();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(); setSpinning(false); setAuto(false); return; }
    setGrid(out.grid);
    let seen = 0;
    const tease = [];
    out.grid.forEach((c, i) => { if (seen >= 2) tease.push(i); if (c.some((x) => x.s === 'OVER')) seen++; });
    await reels.stopAll({ turbo, tease, base: 520, gap: 190, onStop: (i) => { fx.stop(i); if (out.grid[i].some((x) => x.s === 'MULT' || x.s === 'WILD')) fx.special(); } });
    setLit(new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`))));
    if (out.multSum && (out.base || free)) { setStamp(free ? `+${out.multSum}` : `x${out.mult}`); fx.special(); await sleep(turbo ? 300 : 700); }
    setRes(out); setSpinning(false); commit();
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tier) { setPulse(true); setTimeout(() => setPulse(false), 700); }
    if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); } else if (tier) { fx.win(tier); if (tier === 2) doShake(false); }
    if (out.trigger?.freeSpins) { fx.bonus(); setIntro(out.trigger.freeSpins); }
    if (out.finished) setBig({ amount: out.finished.total, title: 'OVERDRIVE COMPLETE' });
    if (!out.free) setAuto(false);
  });
  useEffect(() => {
    if (!auto || !free || spinning || big || intro) return undefined;
    const t = setTimeout(spin, 800);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro]); // eslint-disable-line react-hooks/exhaustive-deps

  const pt = Object.entries(NE_PAY).map(([s, v]) => [s, v.map((x) => x * NE_S)]);
  const ways = res?.wins?.reduce((a, w) => a + w.ways, 0);
  const detail = res && [res.wins.length && `${ways} winning way${ways > 1 ? 's' : ''}`, res.mult > 1 && `x${res.mult}`].filter(Boolean).join(' · ');
  return (
    <PremiumShell game="neon" rtp="96%" tagline="5 reels · 4 rows · 1,024 ways · multipliers · Overdrive" shake={shake}
      stageClass={`border-2 ${free ? 'border-fuchsia-400 shadow-[0_0_50px_rgba(232,121,249,0.45)]' : 'border-cyan-400/50 shadow-[0_0_40px_rgba(34,211,238,0.3)]'}`} bg={<City pulse={pulse} overdrive={!!free} />}
      below={<SpinBar stake={stake} setStake={setStake} onSpin={spin} spinning={spinning} free={free} disabled={!!intro} balance={user?.balance} turbo={turbo} setTurbo={setTurbo} auto={auto} setAuto={setAuto} accent="bg-gradient-to-r from-fuchsia-500 to-cyan-500 text-white" label="SPIN" />}
      side={<>
        <SidePanel title="Features">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-cyan-300">Cyber Wild</b> on reels 2–5.</li>
            <li><b className="text-fuchsia-300">Multiplier chips</b> (x2–x25) add up and multiply any win.</li>
            <li><b className="text-amber-300">3+ OVERDRIVE</b>: bonus round with a meter that only grows.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Recent spins"><RecentList history={history} /></SidePanel>
      </>}
      info={<>
        <section><h3 className="mb-2 font-bold text-white">Paytable (per way, multiples of total stake)</h3><Paytable game="neon" rows={pt} /></section>
        <section className="space-y-2">
          <h3 className="font-bold text-white">How it pays</h3>
          <p><b>1,024 ways</b>: matching symbols on adjacent reels from the left pay, anywhere in each reel. Every combination counts, so 2 matches on reel 2 doubles the win.</p>
          <p><b className="text-cyan-300">Cyber Wild</b> lands on reels 2–5 and substitutes for every paying symbol.</p>
          <p><b className="text-fuchsia-300">Multiplier chips</b> show x2, x3, x5, x10 or x25. When the spin wins, every chip on screen is added together and multiplies the total.</p>
          <p><b className="text-amber-300">Overdrive</b>: 3, 4 or 5 OVERDRIVE gauges give {NE_FREE[3]}, {NE_FREE[4]} or {NE_FREE[5]} free spins with fewer low symbols. The Overdrive meter starts at x1 and every multiplier chip that lands adds to it for the rest of the round; it never resets during the round. 3 more gauges add 5 spins. The meter ends with the round, so it never carries over to paid spins.</p>
          <p className="text-xs text-slate-500">Chip chances: {NE_MULTS.map(([v, w]) => `x${v} ${w}%`).join(' · ')}.</p>
        </section>
        <section className="rounded-lg bg-navy-800 p-3 text-xs"><b className="text-white">Maths</b>: long-run return 96% · a win on about {STATS3.neon.hit} of spins (many of them small partial returns, shown as such) · {STATS3.neon.feature} · maximum win 5,000x per spin · results come from a cryptographic random number generator before the reels animate.</section>
      </>}>
      <div className="relative">
        {free && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="p3-flicker rounded-md bg-fuchsia-500 px-2.5 py-1 text-xs font-extrabold uppercase tracking-wider text-white shadow-[0_0_14px_#e879f9]">Overdrive · {free.remaining} left</div>
            <div className="flex items-center gap-1 rounded-md bg-black/60 px-2 py-0.5 ring-1 ring-cyan-400/60"><span className="text-[10px] font-bold uppercase text-cyan-300">Meter</span><span key={free.meter} className="p3-stamp font-display text-2xl text-white drop-shadow-[0_0_8px_#22d3ee]">x{free.meter}</span></div>
          </div>
        )}
        <div className="relative rounded-xl bg-gradient-to-r from-fuchsia-500/70 via-violet-500/40 to-cyan-400/70 p-[2px]">
          <div className="relative rounded-[10px] bg-slate-950/80 p-1.5">
            <PremiumReels game="neon" grid={grid} stopped={reels.stopped} lit={lit} turbo={turbo} spinId={spinId} landing="glitch" />
            {res && <Lightning wins={res.wins} rows={4} id={spinId} />}
            {stamp && (
              <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
                <div key={spinId} className="p3-stamp rounded-2xl bg-black/70 px-5 py-2 font-display text-5xl text-amber-300 ring-2 ring-fuchsia-400 drop-shadow-[0_0_16px_#e879f9]">{stamp}</div>
                <Burst game="neon" n={18} spread={120} />
              </div>
            )}
          </div>
        </div>
        <div className="mt-2"><WinLine res={res} spinning={spinning} detail={detail} busyText="Jacking in…" /></div>
        {intro && (
          <FeatureIntro title="OVERDRIVE" subtitle={`${intro} free spins. Every multiplier chip powers up a meter that keeps growing for the whole round.`}
            art={<div className="mb-2 h-24 w-24 p3-flicker"><Sym3 game="neon" s="OVER" /></div>} className="bg-[linear-gradient(135deg,rgba(74,4,78,0.9),rgba(8,47,73,0.9))]" onStart={() => { setIntro(null); setAuto(true); }} />
        )}
        {big && <BigWin game="neon" amount={big.amount} bet={res?.bet || stake} title={big.title} onDone={() => setBig(null)}
          cinematic={<div className="pointer-events-none absolute inset-0 bg-[repeating-linear-gradient(90deg,rgba(244,114,182,0.15)_0_2px,transparent_2px_14px)] p3-flicker" />} />}
      </div>
    </PremiumShell>
  );
}
