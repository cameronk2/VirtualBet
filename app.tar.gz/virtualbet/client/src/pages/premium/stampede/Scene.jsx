// Stampede Link – sunset prairie: layered mesas, a low sun, a buffalo herd
// running along the ridge and drifting dust.
const Bison = ({ x, s = 1, d = 0 }) => (
  <g transform={`translate(${x} 0) scale(${s})`}>
    <g className="st-gallop" style={{ animationDelay: `${d}s` }}>
      <path d="M0 -10C2 -18 10 -22 18 -20C24 -24 34 -22 38 -16C42 -14 44 -10 42 -6L40 0H36L35 -5H16L14 0H10L9 -5C4 -5 0 -6 0 -10Z" fill="#1c0a02" />
      <path d="M36 -18Q40 -24 44 -22" stroke="#1c0a02" strokeWidth="1.6" fill="none" />
    </g>
  </g>
);

export default function Prairie({ mode }) {
  const sky = mode === 'hold' ? 'from-indigo-950 via-fuchsia-900 to-amber-500' : mode === 'free' ? 'from-violet-900 via-rose-700 to-amber-300' : 'from-indigo-900 via-orange-600 to-amber-200';
  return (
    <>
      <div className={`absolute inset-0 bg-gradient-to-b transition-colors duration-1000 ${sky}`} />
      <div className="st-sun absolute left-1/2 top-[38%] h-[34%] w-auto aspect-square -translate-x-1/2 rounded-full bg-[radial-gradient(circle,#fff7c2_0%,#fde047_35%,rgba(251,146,60,0.5)_60%,rgba(251,146,60,0)_72%)]" />
      <svg viewBox="0 0 400 160" preserveAspectRatio="none" className="absolute bottom-0 left-0 h-[55%] w-full" aria-hidden="true">
        <path d="M0 70L30 60H60L70 40H110L118 62L160 66L190 46H230L240 64L300 58L320 36H360L372 60L400 64V160H0Z" fill="#7c2d12" opacity=".85" />
        <path d="M0 96L50 84L90 92L140 78L200 90L260 76L320 88L400 80V160H0Z" fill="#431407" />
        <g className="st-herd" transform="translate(0 98)">
          {[0, 46, 80, 130, 168, 214, 250, 300, 336].map((x, i) => <Bison key={x} x={x} s={0.55 + (i % 3) * 0.12} d={i * 0.13} />)}
        </g>
        <path d="M0 118Q100 108 200 116T400 112V160H0Z" fill="#2a0f04" />
      </svg>
      {[0, 1, 2, 3, 4].map((i) => <div key={i} className="st-dust absolute bottom-[8%] h-10 w-40 rounded-full bg-amber-200/20 blur-md" style={{ animationDelay: `${-i * 4}s`, animationDuration: `${16 + i * 3}s` }} />)}
    </>
  );
}
