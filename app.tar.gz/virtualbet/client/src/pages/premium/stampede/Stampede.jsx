// Stampede Link – game screen. Every result comes from the server before
// anything moves; this file only reveals it: 1,024-ways reels with linked
// buffalo chains, free games with multiplying wilds and the Golden Buffalo
// collection, and Hold & Spin.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, Burst, FeatureIntro, PremiumShell, RecentList, SidePanel, sleep, tierOf, usePremium, useReelStops } from '../../../components/Premium.jsx';
import { STAKES, WinAmount } from '../../../components/GameShell.jsx';
import { Modal } from '../../../components/ui.jsx';
import { BuffaloHead, CashCoin, GoldCoin, STAMPEDE_ART, STAMPEDE_NAMES, StampedeSym } from '../../../components/SlotArtStampede.jsx';
import { stampedeSfx } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { CASH_VALUES, FREE_GAMES, GOLD_UPGRADES, HOLD_MULTS, HOLD_RESPINS, HOLD_TRIGGER, JACKPOTS, MAX_WIN_X, PAYTABLE, PAY_SCALE, RETRIGGER, SCATTER_PAY, WILD_MULTS } from '../../../../../server/games/stampede/config.js';
import Prairie from './Scene.jsx';
import HoldSpin, { JackpotLadder } from './HoldSpin.jsx';

const ROWS = 4;
const S = (s, extra) => ({ s, ...extra });
const START = [[S('BUFFALO'), S('A'), S('CASH', { v: 2 }), S('K')], [S('EAGLE'), S('BUFFALO'), S('Q'), S('WILD')], [S('CASH', { v: 'MINI' }), S('BUFFALO'), S('COUGAR'), S('J')], [S('WOLF'), S('T'), S('BUFFALO'), S('COIN')], [S('ELK'), S('CASH', { v: 5 }), S('N'), S('WILD', { m: 3 })]];
const BLUR = ['BUFFALO', 'A', 'EAGLE', 'K', 'CASH', 'COUGAR', 'Q', 'WOLF', 'J', 'ELK', 'WILD', 'T', 'COIN', 'N'].map((s) => S(s, s === 'CASH' ? { v: 1 } : {}));
const COLOURS = ['#fde047', '#38bdf8', '#f472b6', '#4ade80', '#fb923c'];
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v ? '1' : '0'); } catch { /* private mode */ } };
const devMode = () => { try { return location.hash.includes('dev') || localStorage.getItem('vb_dev') === '1'; } catch { return false; } };
const isAnimal = (s) => ['EAGLE', 'COUGAR', 'WOLF', 'ELK'].includes(s);

function Reel({ index, cells, spinning, landKey, lit, trig, turbo, tease, upgrades, bet }) {
  return (
    <div className={`relative overflow-hidden rounded-lg bg-[#1c0a02]/60 ring-1 ${tease ? 'ring-2 ring-yellow-300 shadow-[0_0_24px_rgba(253,224,71,0.8)]' : 'ring-amber-200/15'}`} style={{ aspectRatio: `1 / ${ROWS}` }}>
      {spinning ? (
        <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 50}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-0.5 opacity-80 blur-[1.5px]"><StampedeSym cell={BLUR[(k * 5 + index * 3) % BLUR.length]} /></div>)}
        </div>
      ) : (
        <div key={landKey} className="p3-land-bounce">
          {cells.map((cell, row) => {
            const k = `${index}-${row}`, on = lit?.has(k), t = trig?.has(k);
            const up = upgrades?.includes(cell.s);
            const shown = up ? { s: 'BUFFALO' } : cell;
            const anim = cell.s === 'GOLD' ? 'st-shine' : up ? 'st-morph' : (cell.s === 'BUFFALO' && on) ? 'st-snort' : cell.s === 'CASH' ? 'st-coinland' : '';
            return (
              <div key={row} className={`relative aspect-square p-0.5 ${(lit?.size || trig?.size) && !on && !t ? 'p3-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'p3-win' : ''} ${t ? 'bk-trig' : ''} ${anim}`} style={{ '--glow': '#fde047' }}><StampedeSym cell={shown} bet={bet} money={money} /></div>
                {(on || t) && <Burst key={landKey} game="stampede" n={t ? 10 : 6} spread={40} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** Linked chains: every winning symbol connects to every match on the next reel. */
function LinkChains({ wins, id }) {
  if (!wins?.length) return null;
  const pos = (reel, row) => [(reel + 0.5) * 20, ((row + 0.5) / ROWS) * 100];
  return (
    <svg key={id} viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 z-20 h-full w-full" aria-hidden="true">
      {wins.slice(0, 4).map((w, wi) => {
        const buf = w.symbol === 'BUFFALO', col = buf ? '#fde047' : COLOURS[(wi + 1) % COLOURS.length];
        const segs = [];
        for (let r = 0; r < w.byReel.length - 1; r++) for (const a of w.byReel[r]) for (const b of w.byReel[r + 1]) segs.push([...pos(r, a), ...pos(r + 1, b)]);
        return (
          <g key={wi} style={{ animationDelay: `${wi * 0.15}s` }}>
            {segs.map(([x1, y1, x2, y2], i) => <line key={`o${i}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke={col} strokeOpacity=".45" strokeWidth={buf ? 10 : 6} vectorEffect="non-scaling-stroke" strokeLinecap="round" className="st-draw" />)}
            {segs.map(([x1, y1, x2, y2], i) => <line key={`i${i}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#fff" strokeWidth={buf ? 3 : 2} vectorEffect="non-scaling-stroke" strokeLinecap="round" className={buf ? 'st-link' : 'st-draw'} style={{ filter: `drop-shadow(0 0 4px ${col})` }} />)}
          </g>
        );
      })}
    </svg>
  );
}

function GoldMeter({ gold, upgrades }) {
  const max = GOLD_UPGRADES[GOLD_UPGRADES.length - 1].at;
  return (
    <div className="rounded-lg bg-black/55 px-2.5 pb-1.5 pt-1 ring-1 ring-yellow-300/40">
      <div className="flex justify-between text-[10px] font-bold text-yellow-100"><span>Golden Buffalo collected: {gold}</span><span>{upgrades.length ? `${upgrades.map((u) => STAMPEDE_NAMES[u]).join(', ')} → Buffalo` : `${GOLD_UPGRADES[0].at} turn wolves into buffalo`}</span></div>
      <div className="relative mt-1 h-2.5 rounded-full bg-white/10">
        <div className="h-full rounded-full bg-gradient-to-r from-amber-600 via-yellow-300 to-yellow-100 shadow-[0_0_8px_#fde047] transition-all duration-500" style={{ width: `${Math.min(100, (gold / max) * 100)}%` }} />
        {GOLD_UPGRADES.map((u) => (
          <div key={u.at} className="absolute top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2" style={{ left: `${(u.at / max) * 100}%` }}>
            <svg viewBox="0 0 100 100" className={`h-full w-full rounded-full ${gold >= u.at ? 'bg-yellow-300 ring-2 ring-white' : 'bg-black/70 ring-1 ring-yellow-300/50 opacity-80'}`} aria-label={`${u.at} gold: ${STAMPEDE_NAMES[u.sym]}`}>{STAMPEDE_ART[u.sym]}</svg>
          </div>
        ))}
      </div>
    </div>
  );
}

function Switch({ label, hint, on, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!on)} aria-pressed={on} className="flex w-full items-center justify-between gap-4 rounded-lg bg-navy-800 px-3 py-2.5 text-left text-sm text-slate-200 hover:bg-navy-700">
      <span>{label}{hint && <span className="block text-[11px] text-slate-500">{hint}</span>}</span>
      <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? 'bg-amber-400' : 'bg-navy-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
    </button>
  );
}

const INTRO = {
  hold: { title: 'HOLD & SPIN', cta: 'Lock the herd', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(180,83,9,0.96),rgba(20,8,2,0.97))]', text: `Your buffalo cash lock in place. ${HOLD_RESPINS} respins: every new buffalo locks and resets them to ${HOLD_RESPINS}. Stampede ×2/×3 coins multiply every locked credit. Fill all 20 spots for the Grand.` },
  free: { title: 'FREE GAMES', cta: 'Ride out', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,0.95),rgba(14,6,24,0.97))]', text: `Every wild is a ×2 or ×3 multiplier, and they multiply together. Collect Golden Buffalo: ${GOLD_UPGRADES.map((u) => `${u.at} → ${STAMPEDE_NAMES[u.sym].toLowerCase()}s`).join(', ')} become buffalo. 2+ coins add more games. Hold & Spin can still trigger.` },
};
const pays = (bet, h) => money(Math.floor((bet * h * PAY_SCALE) / 1000));
const pct = (pairs) => { const t = pairs.reduce((a, [, w]) => a + w, 0); return (w) => `${((w / t) * 100).toFixed(w / t < 0.01 ? 2 : 0)}%`; };

export default function Stampede() {
  const { user, view, history, play, commit, guard: rawGuard, shake, doShake } = usePremium('stampede');
  const [tick, setTick] = useState(0);
  const guard = (fn) => rawGuard(fn).finally(() => setTick((n) => n + 1));
  const fx = useMemo(() => stampedeSfx(), []);
  const reels = useReelStops(5);
  const [scene, setScene] = useState('base');
  const [cells, setCells] = useState(START);
  const [lit, setLit] = useState(null);
  const [trig, setTrig] = useState(null);
  const [links, setLinks] = useState(null);
  const [res, setRes] = useState(null);
  const [stake, setStake] = useState(100);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [tease, setTease] = useState([]);
  const [count, setCount] = useState({ cash: 0, coins: 0 });
  const [banner, setBanner] = useState(null);
  const [freeInfo, setFreeInfo] = useState(null);
  const [holdData, setHoldData] = useState(null);
  const [running, setRunning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [summary, setSummary] = useState(null);
  const [session, setSession] = useState({ staked: 0, won: 0 });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [turbo, setTurbo] = useState(() => pref('st_turbo', false));
  const [space, setSpace] = useState(() => pref('st_space', true));
  const [showLinks, setShowLinks] = useState(() => pref('st_links', true));
  const [dev] = useState(devMode);
  const mode = view?.mode || 'base';
  // the server may already be a step ahead of the screen; controls follow the screen
  const barMode = scene === mode ? mode : 'busy';
  const bet = holdData?.bet ?? freeInfo?.bet ?? view?.hold?.bet ?? view?.free?.bet ?? stake;
  const t = useCallback((ms) => sleep(turbo ? ms * 0.45 : ms), [turbo]);
  const track = (out) => setSession((s) => ({ staked: s.staked + (out.staked || 0), won: s.won + (out.payout || 0) }));

  const bigResolve = useRef(null);
  const showBig = (b) => new Promise((r) => { bigResolve.current = r; setBig(b); });
  const introResolve = useRef(null);
  const showIntro = (i) => new Promise((r) => { introResolve.current = r; setIntro(i); });
  const sumResolve = useRef(null);
  const showSummary = (s) => new Promise((r) => { sumResolve.current = r; setSummary(s); });

  // After a refresh mid-feature, put the right screen back.
  const resumed = useRef(false);
  useEffect(() => {
    if (!view || resumed.current) return;
    resumed.current = true;
    if (view.free) setFreeInfo({ ...view.free });
    if (view.mode === 'hold') { setHoldData(view.hold); setScene('hold'); setIntro({ type: 'hold', resume: true }); }
    else if (view.mode === 'free') { setScene('free'); setIntro({ type: 'free', resume: true }); }
  }, [view]);

  const handleStarted = async (out) => {
    const st = out.started;
    if (st?.type === 'hold') {
      setHoldData({ cells: st.cells, respins: HOLD_RESPINS, spins: 0, bet: out.bet });
      setScene('hold'); fx.holdIntro();
      await showIntro({ type: 'hold' });
      setRunning(true);
    } else if (st?.type === 'free') {
      setFreeInfo({ bet: out.bet, remaining: st.games, played: 0, gold: 0, upgrades: [], total: 0 });
      setLit(null); setLinks(null); setTrig(null);
      setScene('free'); fx.freeTrigger();
      await showIntro({ type: 'free' });
    } else if (out.mode === 'free') {
      setFreeInfo((f) => ({ ...f, ...out.view.free })); setScene('free');
    } else if (out.mode === 'base') { setScene('base'); setFreeInfo(null); }
  };

  const endFree = async (out) => {
    const fin = out.finished;
    if (!fin) return;
    if (fin.total >= (freeInfo?.bet || bet) * 10) { fx.big(); await showBig({ amount: fin.total, title: 'FREE GAMES WIN', practice: out.practice }); }
    await showSummary({ type: 'free', ...fin, practice: out.practice });
  };

  // ── spins (base and free) ───────────────────────────────────────────────
  const spinReels = async () => {
    const free = scene === 'free';
    fx.click();
    setSpinning(true); setRes(null); setLit(null); setTrig(null); setLinks(null); setTease([]); setBanner(null); setCount({ cash: 0, coins: 0 });
    fx.spin(); setSpinId((n) => n + 1); reels.start();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(); setSpinning(false); return; }
    track(out);
    setCells(out.grid);
    // anticipation: 2 coins, or 6+ buffalo cash, stretch the next reels
    const teaseReels = [];
    let c = 0, k = 0;
    out.grid.forEach((col, r) => { if (c >= (free ? 1 : 2) || k >= 6) teaseReels.push(r); c += col.filter((x) => x.s === 'COIN').length; k += col.filter((x) => x.s === 'CASH').length; });
    let cc = 0, ck = 0, bufSaid = false;
    await reels.stopAll({
      turbo, tease: teaseReels,
      onStop: (r) => {
        fx.stop(r);
        const col = out.grid[r];
        col.forEach((x) => { if (x.s === 'CASH') fx.cash(ck++); });
        if (col.some((x) => x.s === 'COIN')) fx.scatter(cc++);
        if (col.some((x) => x.s === 'GOLD')) fx.gold();
        if (col.some((x) => x.s === 'WILD')) fx.wild();
        if (!bufSaid && r === 0 && col.some((x) => x.s === 'BUFFALO' || x.s === 'GOLD')) { bufSaid = true; fx.buffalo(); }
        setCount({ cash: ck, coins: cc });
        if (teaseReels.includes(r + 1)) setTease([r + 1]);
      },
    });
    setTease([]);
    if (free) setFreeInfo((f) => ({ ...f, remaining: out.remaining, played: (f?.played || 0) + 1, gold: out.gold, upgrades: out.upgrades, total: out.view?.free?.total ?? f?.total }));
    const litCells = new Set(out.wins.flatMap((w) => w.cells.map(([r, c2]) => `${r}-${c2}`)));
    if (out.scatterWin) out.coins.forEach(([r, c2]) => litCells.add(`${r}-${c2}`));
    if (litCells.size) {
      setLit(litCells); if (showLinks) setLinks(out.wins);
      if (out.wins.some((w) => w.symbol === 'BUFFALO')) { fx.link(out.wins.find((w) => w.symbol === 'BUFFALO').count); setTimeout(() => fx.buffalo(), 250); }
      if (out.win) fx.win(out.win >= out.bet * 5 ? 2 : 1);
    }
    setRes(out); setSpinning(false);
    // Golden Buffalo upgrades reached this spin
    if (free && out.goldNew) {
      const before = (out.gold || 0) - out.goldNew;
      const newly = GOLD_UPGRADES.filter((u) => before < u.at && out.gold >= u.at);
      if (newly.length) { fx.gold(); setBanner({ text: `${newly.map((u) => STAMPEDE_NAMES[u.sym].toUpperCase() + 'S').join(' & ')} → BUFFALO!`, cls: 'from-yellow-100 to-amber-500 text-amber-950' }); await t(1300); setBanner(null); }
    }
    const tr = out.triggers || {};
    const tier = tierOf(out.win, out.staked || out.bet, out.bet);
    if (tr.hold || tr.free || tr.retrigger) {
      const tc = new Set();
      if (tr.hold) out.cash.forEach(([r, c2]) => tc.add(`${r}-${c2}`));
      if (tr.free || tr.retrigger) out.coins.forEach(([r, c2]) => tc.add(`${r}-${c2}`));
      setTrig(tc);
      if (tr.retrigger) { fx.freeTrigger(); setBanner({ text: `+${tr.retrigger} FREE GAMES`, cls: 'from-violet-200 to-violet-600 text-white' }); await t(1300); setBanner(null); }
      if (tr.free) { fx.freeTrigger(); setBanner({ text: `${out.coins.length} GOLD COINS!`, cls: 'from-yellow-100 to-amber-500 text-amber-950' }); await t(1400); }
      if (tr.hold) { await t(tr.free ? 300 : 0); fx.holdTrigger(); setBanner({ text: `${out.cash.length} BUFFALO CASH!`, cls: 'from-amber-200 to-orange-600 text-white' }); await t(1700); }
    } else if (out.win) await t(tier >= 3 ? 600 : 900);
    commit();
    if (tier >= 3 && out.win) { fx.big(); doShake(tier >= 4); await showBig({ amount: out.win }); }
    setBanner(null);
    if (out.started) { setTrig(null); await handleStarted(out); }
    else if (out.finished) { await endFree(out); await handleStarted(out); }
  };

  // ── Hold & Spin ─────────────────────────────────────────────────────────
  const requestRespin = async () => { const out = await play('respin', {}); if (!out) setRunning(false); else track(out); return out; };
  const holdComplete = async (out) => {
    setRunning(false);
    commit();
    fx.jackpot();
    await showBig({ amount: out.win, title: out.holdDone?.grand ? 'GRAND JACKPOT' : 'HOLD & SPIN WIN', practice: out.practice });
    setHoldData(null);
    if (out.started) await handleStarted(out);
    else if (out.mode === 'free') { setFreeInfo((f) => ({ ...f, ...out.view.free })); setScene('free'); }
    else {
      if (out.finished) { setScene('free'); await endFree(out); }
      setScene('base'); setFreeInfo(null);
    }
  };

  const devTrigger = (event) => guard(async () => {
    const out = await play('dev', { event, stake });
    if (!out?.started) return;
    if (event === 'free') fx.freeTrigger(); else fx.holdTrigger();
    await handleStarted({ ...out, bet: stake });
  });

  const spin = () => guard(async () => {
    if ((mode === 'base' && scene === 'base') || (mode === 'free' && scene === 'free')) await spinReels();
  });

  // Free games run themselves once the screen is ready (never paid spins).
  const ready = !spinning && !big && !intro && !summary && !settingsOpen && !banner;
  useEffect(() => {
    if (!ready || mode !== 'free' || scene !== 'free') return undefined;
    const id = setTimeout(spin, turbo ? 350 : 850);
    return () => clearTimeout(id);
  }, [ready, mode, scene, tick]); // eslint-disable-line react-hooks/exhaustive-deps

  const spinRef = useRef(spin); spinRef.current = spin;
  useEffect(() => {
    if (!space) return undefined;
    const h = (e) => {
      if (e.code !== 'Space' || e.repeat || ['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(e.target.tagName)) return;
      e.preventDefault();
      if (!big && ready && barMode === 'base') spinRef.current();
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [space, big, ready, barMode]);

  const low = mode === 'base' && (user?.balance ?? 0) < stake;
  const i = Math.max(0, STAKES.indexOf(stake));
  const practice = view?.practice;
  const detail = res?.wins?.length ? res.wins.slice(0, 2).map((w) => `${STAMPEDE_NAMES[w.symbol]} ×${w.count} · ${w.ways} way${w.ways > 1 ? 's' : ''}${w.mult > 1 ? ` · wilds ×${+w.mult.toFixed(2)}` : ''}`).join(' · ') + (res.scatterWin ? ` · ${res.coins.length} coins` : '') : res?.scatterWin ? `${res.coins.length} gold coins` : '';
  const sessionNet = session.won - session.staked;
  const wp = pct(CASH_VALUES);

  const bar = (
    <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || barMode !== 'base' || i <= 0} onClick={() => { fx.click(); setStake(STAKES[i - 1]); }} aria-label="Lower bet">−</button>
          <div className="w-[4.4rem] text-center leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{barMode === 'base' ? 'Total bet' : 'Bonus bet'}</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(bet)}</div></div>
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || barMode !== 'base' || i >= STAKES.length - 1} onClick={() => { fx.click(); setStake(STAKES[i + 1]); }} aria-label="Raise bet">+</button>
        </div>
        {scene === 'hold' ? (
          <button onClick={() => setRunning(true)} disabled={running || mode !== 'hold' || !!intro} className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-amber-200 to-orange-600 text-lg font-extrabold text-white shadow-lg">{mode !== 'hold' ? 'Collecting…' : running ? 'Respins running…' : 'Start respins'}</button>
        ) : barMode === 'busy' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-amber-400/20 text-sm font-bold text-amber-100 ring-1 ring-amber-300/50">Bonus in progress…</div>
        ) : mode === 'free' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-violet-500/25 text-sm font-bold text-violet-100 ring-1 ring-violet-300/50">Free games play automatically · {freeInfo?.remaining ?? 0} left</div>
        ) : (
          <button onClick={spin} disabled={spinning || low || !!intro || !!summary || !!big}
            className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-yellow-200 to-amber-600 text-lg font-extrabold text-amber-950 shadow-lg transition-transform active:scale-95">
            {spinning ? 'Spinning…' : low ? 'Not enough balance' : 'Spin'}
          </button>
        )}
      </div>
      <div className="flex items-center justify-between gap-1.5 text-xs text-slate-400">
        <div className="flex gap-1.5">
          <button onClick={() => { const v = !turbo; setTurbo(v); save('st_turbo', v); }} className={`rounded-md px-2.5 py-1 font-semibold ${turbo ? 'bg-amber-400 text-navy-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Quick</button>
          <button onClick={() => setSettingsOpen(true)} className="rounded-md bg-navy-700 px-2.5 py-1 font-semibold text-slate-200">Settings</button>
        </div>
        <div className="flex gap-3 text-right">
          <span>Win <b className="tabular-nums text-amber-200">{money(res?.win || 0)}</b></span>
          <span>Balance <b className="tabular-nums text-slate-200">{money(user?.balance ?? 0)}</b></span>
        </div>
      </div>
      {dev && barMode === 'base' && mode === 'base' && !spinning && (
        <div className="rounded-lg border border-dashed border-fuchsia-400/60 bg-fuchsia-500/10 p-2 text-xs text-fuchsia-100">
          <div className="mb-1 font-bold">Test mode (practice: costs and pays nothing)</div>
          <div className="flex flex-wrap gap-1">
            {[['hold', 'Hold & Spin'], ['jackpots', 'Jackpot coins'], ['mult', 'Multipliers'], ['grand', 'Grand (19 locked)'], ['free', 'Free games']].map(([e, l]) => <button key={e} className="rounded bg-fuchsia-700 px-2 py-1" onClick={() => devTrigger(e)}>{l}</button>)}
          </div>
        </div>
      )}
    </div>
  );

  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to win</h3>
        <p>5 reels, 4 rows, <b>1,024 ways</b>. A symbol on reel 1 links to the same symbol (or a wild) on each next reel; every combination of positions is a way, so two buffalo on a reel double the win. Winning chains are drawn across the reels. Reels sometimes land fully stacked with one symbol.</p>
        <p>The <b className="text-amber-200">Buffalo Wild</b> lands on reels 2–5 and substitutes for every symbol except gold coins and buffalo cash. On reel 5 it is always a <b>×2 or ×3</b> multiplier ({WILD_MULTS.map(([m, w]) => `×${m} ${Math.round((w / WILD_MULTS.reduce((a, [, x]) => a + x, 0)) * 100)}%`).join(', ')}). Multipliers multiply every way through them, and with each other.</p>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">Paytable per way at {money(bet)} total bet</h3>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(PAYTABLE).map(([s, p]) => (
            <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
              <div className="h-11 w-11 shrink-0"><StampedeSym cell={{ s }} /></div>
              <div className="min-w-0 text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">{STAMPEDE_NAMES[s]}</div>{p.map((v, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{pays(bet, v)}</b></div>)}</div>
            </div>
          ))}
          <div className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
            <div className="h-11 w-11 shrink-0"><StampedeSym cell={{ s: 'COIN' }} /></div>
            <div className="text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">Gold coin (anywhere)</div>{[3, 4, 5].map((n) => <div key={n}><span className="text-slate-500">{n}×</span> <b className="text-white">{money(bet * SCATTER_PAY[n])}</b></div>)}</div>
          </div>
        </div>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Hold &amp; Spin ({HOLD_TRIGGER} or more buffalo cash)</h3>
        <div className="flex gap-2"><div className="h-12 w-12 shrink-0"><StampedeSym cell={{ s: 'CASH', v: 2 }} /></div><p>Buffalo cash carry a prize ({CASH_VALUES.filter(([v]) => typeof v === 'number').map(([v]) => `${v}x`).join(', ')} the bet) or a Mini, Minor or Major jackpot. They pay nothing on their own. <b>{HOLD_TRIGGER} or more</b> anywhere start Hold &amp; Spin.</p></div>
        <ul className="list-disc space-y-1 pl-5">
          <li>A separate 5×4 grid. The triggering buffalo cash lock in place, and you get {HOLD_RESPINS} respins.</li>
          <li>Each respin, every empty spot spins. Every buffalo that lands locks and resets the respins to {HOLD_RESPINS}. A respin with nothing new uses one up.</li>
          <li>Stampede coins (Hold &amp; Spin only): <b>×2</b> or <b>×3</b> multiplies every locked credit prize when it lands (not jackpots).</li>
          <li>When the respins run out, every locked prize and jackpot is added up and paid once. Fill all 20 spots and you also win the <b>Grand</b>.</li>
        </ul>
        <JackpotLadder bet={bet} />
        <p className="text-xs">Fixed multiples of the bet (Mini {JACKPOTS.MINI}x, Minor {JACKPOTS.MINOR}x, Major {JACKPOTS.MAJOR}x, Grand {JACKPOTS.GRAND.toLocaleString()}x), not progressive. Chance a buffalo cash is a jackpot: Mini {wp(1.1)}, Minor {wp(0.3)}, Major {wp(0.03)}. Stampede coins: ×2 and ×3 ({HOLD_MULTS.map(([, w]) => w).join(' : ')} weighting).</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Free games</h3>
        <div className="flex gap-2"><div className="h-12 w-12 shrink-0"><svg viewBox="0 0 100 100"><GoldCoin /></svg></div><p>3, 4 or 5 gold coins anywhere award <b>{FREE_GAMES[3]}, {FREE_GAMES[4]} or {FREE_GAMES[5]}</b> free games at the same bet. During free games 2, 3, 4 or 5 coins add {RETRIGGER[2]}, {RETRIGGER[3]}, {RETRIGGER[4]} or {RETRIGGER[5]} more.</p></div>
        <ul className="list-disc space-y-1 pl-5">
          <li>Every wild is a ×2 or ×3 multiplier; a way through several wilds multiplies them together.</li>
          <li><b className="text-yellow-200">Golden Buffalo</b> pay as buffalo and are collected for the whole feature: {GOLD_UPGRADES.map((u) => `${u.at} turn ${STAMPEDE_NAMES[u.sym].toLowerCase()}s`).join(', ')} into buffalo for the rest of the free games.</li>
          <li>Hold &amp; Spin can trigger; the free games carry on afterwards.</li>
        </ul>
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Maths</b>: long-run return about 96% (our own tuning, measured by simulation; not the original game's certified RTP). Ways ~51 points, Hold &amp; Spin ~30, free games ~14, coin pays ~1.3. Hold &amp; Spin about 1 in 95 spins, free games about 1 in 175. Maximum win {MAX_WIN_X.toLocaleString()}x the bet per spin or feature. Results are decided by the server's random number generator before anything moves; tapping, timing or reloading can't change them.
      </section>
      <section className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3 text-xs text-slate-300">
        <b className="text-amber-200">About this game</b>: Stampede Link is an original game built on the published rules of Aristocrat's <i>Buffalo Link</i> (5×4, 1,024 ways, reel-5 wild multipliers, Hold &amp; Spin with Mini/Minor/Major and a full-grid Grand, free games with multiplying wilds) and the Golden Buffalo collection from <i>Buffalo Gold</i>. Art, names and sound are our own. Pays, odds, prize values and the stampede coins are our own. The original's linked progressive jackpots and its "must-hit-by" mystery meter are not included.
      </section>
    </>
  );

  const roundHistory = (view?.recent || []).slice(0, 10);
  return (
    <PremiumShell game="stampede" rtp="96%" tagline="5 × 4 · 1,024 ways · Hold & Spin · Free games · 4 jackpots" shake={shake}
      stageClass={`border-2 ${scene === 'hold' ? 'border-amber-300/70 shadow-[0_0_60px_rgba(245,158,11,0.35)]' : scene === 'free' ? 'border-violet-300/60 shadow-[0_0_60px_rgba(167,139,250,0.3)]' : 'border-amber-400/50 shadow-[0_0_60px_rgba(245,158,11,0.25)]'}`}
      bg={<Prairie mode={scene} />}
      below={<>{bar}
        <Modal open={settingsOpen} onClose={() => setSettingsOpen(false)} title="Settings">
          <div className="space-y-2">
            <Switch label="Quick spins" hint="Shorter reel and feature animations" on={turbo} onChange={(v) => { setTurbo(v); save('st_turbo', v); }} />
            <Switch label="Show linked chains" hint="Draw winning ways across the reels" on={showLinks} onChange={(v) => { setShowLinks(v); save('st_links', v); }} />
            <Switch label="Space bar to spin" hint="Desktop keyboards" on={space} onChange={(v) => { setSpace(v); save('st_space', v); }} />
            <p className="px-1 pt-1 text-[11px] text-slate-500">Music and sound effects have separate switches and volume sliders under Sound, top right. Sound only starts after your first tap.</p>
          </div>
        </Modal>
      </>}
      info={info}
      side={<>
        <SidePanel title="This session">
          <div className="space-y-1 text-xs text-slate-300">
            <div className="flex justify-between"><span>Staked</span><b className="tabular-nums text-white">{money(session.staked)}</b></div>
            <div className="flex justify-between"><span>Won</span><b className="tabular-nums text-white">{money(session.won)}</b></div>
            <div className="flex justify-between"><span>Net</span><b className={`tabular-nums ${sessionNet >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>{sessionNet >= 0 ? '+' : '−'}{money(Math.abs(sessionNet))}</b></div>
          </div>
        </SidePanel>
        <SidePanel title="Round history">
          {roundHistory.length ? (
            <ul className="space-y-1 text-xs">
              {roundHistory.map((r, k) => <li key={k} className="flex justify-between text-slate-300"><span>{r.kind === 'hold' ? 'Hold & Spin' : r.kind === 'free' ? 'Free game' : 'Spin'} · {money(r.bet)}</span><b className={r.win ? 'text-amber-200' : 'text-slate-500'}>{money(r.win)}</b></li>)}
            </ul>
          ) : <div className="text-xs text-slate-500">No rounds yet.</div>}
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      <div className={`relative pt-1 ${turbo ? 'mr-turbo' : ''}`}>
        {practice && <div className="mb-2 rounded-md bg-fuchsia-600/80 px-2 py-1 text-center text-xs font-bold text-white">PRACTICE ROUND: no stake, no payout</div>}
        {scene === 'free' && freeInfo && (
          <div className="mb-2 space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <div className="rounded-md bg-violet-200 px-2.5 py-1 text-xs font-extrabold uppercase text-violet-950 shadow-[0_0_16px_rgba(196,181,253,0.7)]">Free games · {freeInfo.remaining} left</div>
              <div className="rounded-md bg-black/55 px-2 py-1 text-xs font-bold text-yellow-100 ring-1 ring-yellow-300/50">Feature win {money(freeInfo.total || 0)}</div>
            </div>
            <GoldMeter gold={freeInfo.gold || 0} upgrades={freeInfo.upgrades || []} />
          </div>
        )}
        <div className="relative mx-auto rounded-2xl bg-[linear-gradient(160deg,#fde3c4,#8a5527_30%,#4a2a10_65%,#fde047_92%)] p-[4px] shadow-[0_0_30px_rgba(245,158,11,0.3)]" style={{ maxWidth: scene === 'hold' ? undefined : `min(100%, calc((100dvh - ${scene === 'free' ? 560 : 480}px) * 1.25 + 24px))` }}>
          <div className="relative rounded-[12px] bg-[#1c0a02]/85 p-1.5 backdrop-blur-sm">
            {scene === 'hold' && holdData ? (
              <HoldSpin hold={holdData} bet={holdData.bet} running={running && !intro} lock={guard} request={requestRespin} commit={commit} fx={fx} wait={t} doShake={doShake} onComplete={holdComplete} />
            ) : (
              <div className="relative">
                <div className="grid grid-cols-5 gap-1 sm:gap-1.5">
                  {[0, 1, 2, 3, 4].map((r) => <Reel key={r} index={r} cells={cells[r]} spinning={!reels.stopped[r]} landKey={`${spinId}-${r}`} lit={lit} trig={trig} turbo={turbo} tease={tease.includes(r) && !reels.stopped[r]} upgrades={scene === 'free' ? freeInfo?.upgrades : null} bet={bet} />)}
                </div>
                <LinkChains wins={links} id={spinId} />
                {(spinning || count.cash + count.coins > 0) && (
                  <div className="pointer-events-none absolute right-1 top-1 z-20 flex gap-1 text-[10px] font-extrabold">
                    {count.cash > 0 && <span className={`rounded-full px-1.5 py-0.5 ${count.cash >= HOLD_TRIGGER ? 'bg-amber-300 text-amber-950' : 'bg-black/65 text-amber-200'}`}>Cash {count.cash}/{HOLD_TRIGGER}</span>}
                    {count.coins > 0 && <span className={`rounded-full px-1.5 py-0.5 ${count.coins >= 3 ? 'bg-yellow-200 text-amber-950' : 'bg-black/65 text-yellow-100'}`}>Coins {count.coins}/{scene === 'free' ? 2 : 3}</span>}
                  </div>
                )}
              </div>
            )}
            {banner && <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center"><div className={`st-reset rounded-2xl bg-gradient-to-b px-5 py-2 text-center font-display text-2xl shadow-2xl sm:text-4xl ${banner.cls}`}>{banner.text}</div></div>}
          </div>
        </div>
        {scene !== 'hold' && (
          <div className="mt-2 flex min-h-14 flex-col items-center justify-center rounded-xl bg-black/50 px-2 py-1.5 text-center leading-tight backdrop-blur-sm">
            {res?.win ? <><WinAmount win={res.win} staked={res.staked} />{detail && <div className="mt-0.5 truncate text-[11px] text-white/75">{detail}</div>}</>
              : <div className="text-sm text-white/70">{spinning ? 'The herd is running…' : res ? 'No win this time' : `${HOLD_TRIGGER} buffalo cash start Hold & Spin · 3 gold coins start free games`}</div>}
          </div>
        )}
        {intro && (
          <FeatureIntro title={INTRO[intro.type].title} subtitle={intro.resume ? 'Your bonus is still in progress. Carry on where you left off.' : INTRO[intro.type].text}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-28 w-28" aria-hidden="true">{intro.type === 'hold' ? <CashCoin v="MAJOR" /> : <GoldCoin />}</svg>}
            className={INTRO[intro.type].cls} cta={intro.resume ? 'Continue' : INTRO[intro.type].cta}
            onStart={() => { fx.click(); setIntro(null); if (intro.resume && intro.type === 'hold') setRunning(true); introResolve.current?.(); introResolve.current = null; }} />
        )}
        {summary && !big && (
          <FeatureIntro title="FREE GAMES COMPLETE" subtitle={`${summary.played} free games won ${money(summary.total)}. Golden Buffalo collected: ${summary.gold}.${summary.practice ? ' Practice round: nothing was paid.' : ''}`}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-24 w-24" aria-hidden="true"><BuffaloHead gold /></svg>}
            className="bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,0.95),rgba(14,6,24,0.97))]" cta="Back to the reels"
            onStart={() => { setSummary(null); sumResolve.current?.(); sumResolve.current = null; }} />
        )}
        {big && <BigWin game="stampede" amount={big.amount} bet={bet} title={big.title} onDone={() => { setBig(null); bigResolve.current?.(); bigResolve.current = null; }}
          cinematic={big.practice ? <div className="pointer-events-none absolute inset-x-0 bottom-[6%] z-10 text-center"><span className="rounded-full bg-fuchsia-600 px-3 py-1 text-xs font-extrabold text-white">PRACTICE ROUND · NOT PAID</span></div> : null} />}
      </div>
    </PremiumShell>
  );
}
