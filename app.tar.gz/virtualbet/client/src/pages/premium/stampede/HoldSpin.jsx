// Stampede Link – Hold & Spin screen (self-contained).
//
// The server resolves each respin completely; this component replays it:
// empty cells spin → new buffalo cash land and lock (counter back to 3) or
// nothing lands (counter down one) → stampede multipliers boost every
// locked credit. When it ends, each coin is collected into the total in
// turn, jackpots get their own banner, then the parent shows the win.
// What is shown always ends equal to the server's numbers.
import { useEffect, useRef, useState } from 'react';
import { HOLD_RESPINS, JACKPOTS, JP_NAME, REELS, ROWS } from '../../../../../server/games/stampede/config.js';
import { Burst } from '../../../components/Premium.jsx';
import { CashCoin } from '../../../components/SlotArtStampede.jsx';
import { money } from '../../../lib/format.js';

const SIZE = REELS * ROWS;
const cellX = (c) => (typeof c.v === 'number' ? c.v : JACKPOTS[c.v] || 0);
const totalOf = (cells) => Object.values(cells).reduce((a, c) => a + cellX(c), 0);
const order = (cells) => Object.keys(cells).map((k) => k.split(',').map(Number)).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
const TIER_CLS = { MINI: 'from-teal-200 to-teal-600 text-teal-950', MINOR: 'from-sky-200 to-blue-600 text-white', MAJOR: 'from-fuchsia-200 to-purple-700 text-white', GRAND: 'from-yellow-100 via-amber-400 to-red-600 text-red-950' };

export function JackpotLadder({ bet, hit = [] }) {
  return (
    <div className="grid grid-cols-4 gap-1 text-center">
      {['GRAND', 'MAJOR', 'MINOR', 'MINI'].map((id) => (
        <div key={id} className={`rounded-md bg-gradient-to-b px-1 py-0.5 leading-tight shadow ${TIER_CLS[id]} ${hit.includes(id) ? 'ring-2 ring-white shadow-[0_0_18px_#fde047]' : 'opacity-90'}`}>
          <div className="text-[9px] font-extrabold tracking-wider sm:text-[10px]">{JP_NAME[id].toUpperCase()}</div>
          <div className="font-cond text-xs font-extrabold tabular-nums sm:text-sm">{money(JACKPOTS[id] * bet)}</div>
        </div>
      ))}
    </div>
  );
}

export default function HoldSpin({ hold, bet, running, lock, request, commit, fx, wait, doShake, onComplete }) {
  const [cells, setCells] = useState(() => ({ ...hold.cells }));
  const [respins, setRespins] = useState(hold.respins);
  const [spinning, setSpinning] = useState(false);
  const [fresh, setFresh] = useState({});
  const [boost, setBoost] = useState(null);
  const [resetKey, setResetKey] = useState(0);
  const [collecting, setCollecting] = useState(null);   // { done: Set, total, current }
  const [banner, setBanner] = useState(null);
  const busy = useRef(false);
  const k = useRef(0);

  // Resync with the server whenever idle (start, refresh).
  useEffect(() => { if (!busy.current && hold) { setCells({ ...hold.cells }); setRespins(hold.respins); } }, [hold?.spins]); // eslint-disable-line react-hooks/exhaustive-deps

  const finish = async (out, finalCells) => {
    // collect every coin into the total, in reading order
    const keys = order(finalCells);
    let total = 0;
    const done = new Set();
    setCollecting({ done: new Set(), total: 0, current: null });
    await wait(500);
    for (let i = 0; i < keys.length; i++) {
      const [c, r] = keys[i], key = `${c},${r}`, cell = finalCells[key];
      total += cellX(cell); done.add(key);
      setCollecting({ done: new Set(done), total, current: key });
      if (JACKPOTS[cell.v]) {
        fx.jackpot(); doShake(cell.v === 'MAJOR');
        setBanner({ id: ++k.current, text: `${JP_NAME[cell.v].toUpperCase()} JACKPOT`, amount: JACKPOTS[cell.v] * bet, tier: cell.v });
        await wait(1500); setBanner(null);
      } else { fx.collect(i); await wait(keys.length > 14 ? 110 : 170); }
    }
    if (out.holdDone?.grand) {
      fx.grand(); doShake(true);
      setBanner({ id: ++k.current, text: 'GRAND JACKPOT', amount: JACKPOTS.GRAND * bet, tier: 'GRAND' });
      setCollecting((x) => ({ ...x, total: total + JACKPOTS.GRAND }));
      await wait(2600); setBanner(null);
    }
    await wait(500);
    onComplete(out);
  };

  const spinOnce = () => lock(async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      fx.respin();
      setSpinning(true); setFresh({});
      const out = await request();
      if (!out) { setSpinning(false); return; }
      await wait(650);
      setSpinning(false);
      // land and lock
      const next = { ...cells };
      out.landed.forEach((l) => { next[`${l.c},${l.r}`] = { v: l.v }; });
      setCells({ ...next });
      setFresh(Object.fromEntries(out.landed.map((l) => [`${l.c},${l.r}`, true])));
      out.landed.forEach((l, i) => setTimeout(() => fx.lock(i), i * 90));
      await wait(out.landed.length ? 450 + out.landed.length * 90 : 250);
      if (out.landed.length) { setRespins(HOLD_RESPINS); setResetKey((n) => n + 1); fx.reset(); }
      else { setRespins(out.respins); fx.empty(); }
      // stampede multipliers
      for (const b of out.boosts) {
        setBoost({ id: ++k.current, m: b.m, c: b.c, r: b.r, touched: new Set(b.touched) });
        fx.mult(b.m); doShake(false);
        await wait(500);
        b.touched.forEach((key) => { const v = next[key].v; if (typeof v === 'number') next[key] = { v: +(v * b.m).toFixed(2) }; });
        setCells({ ...next });
        await wait(900);
        setBoost(null);
      }
      // land exactly on the server's numbers
      const final = out.view?.hold?.cells ? { ...out.view.hold.cells } : next;
      setCells(final);
      commit();
      if (out.done) { setRespins(0); await wait(600); await finish(out, final); }
      else await wait(250);
    } finally { busy.current = false; }
  });

  // Run the respins once started
  const [, force] = useState(0);
  useEffect(() => {
    if (!running || busy.current || collecting || respins <= 0) return undefined;
    const id = setTimeout(async () => { await spinOnce(); force((n) => n + 1); }, 650);
    return () => clearTimeout(id);
  });

  const filled = Object.keys(cells).length;
  const shownTotal = collecting ? collecting.total : totalOf(cells);
  const jpHit = Object.values(cells).map((c) => c.v).filter((v) => JACKPOTS[v]);
  return (
    <div>
      <div className="mb-1.5"><JackpotLadder bet={bet} hit={[...jpHit, ...(collecting && banner?.tier === 'GRAND' ? ['GRAND'] : [])]} /></div>
      <div className="mb-1.5 grid grid-cols-3 items-stretch gap-1.5 text-center">
        <div className="rounded-lg bg-black/55 px-2 py-1 ring-1 ring-amber-300/40">
          <div className="text-[10px] font-bold uppercase tracking-wider text-amber-200">Respins</div>
          <div className="flex items-center justify-center gap-1.5">
            <span key={resetKey} className={`font-display text-3xl leading-none tabular-nums text-white ${resetKey ? 'st-reset' : ''}`}>{respins}</span>
            <span className="flex gap-0.5">{Array.from({ length: HOLD_RESPINS }, (_, i) => <span key={i} className={`h-2.5 w-2.5 rounded-full ${i < respins ? 'bg-amber-300 shadow-[0_0_6px_#fcd34d]' : 'bg-white/15'}`} />)}</span>
          </div>
        </div>
        <div className="rounded-lg bg-gradient-to-b from-amber-400/30 to-black/60 px-2 py-1 ring-1 ring-amber-300/70">
          <div className="text-[10px] font-bold uppercase tracking-wider text-amber-200">{collecting ? 'Collected' : 'On the board'}</div>
          <div key={Math.round(shownTotal * 100)} className="st-tick font-cond text-2xl font-extrabold leading-none tabular-nums text-amber-100 drop-shadow-[0_0_8px_#fcd34d]">{money(Math.floor(shownTotal * bet))}</div>
        </div>
        <div className="rounded-lg bg-black/55 px-2 py-1 ring-1 ring-amber-300/40">
          <div className="text-[10px] font-bold uppercase tracking-wider text-amber-200">Filled</div>
          <div className="font-display text-3xl leading-none text-white">{filled}<span className="text-base text-white/60">/{SIZE}</span></div>
        </div>
      </div>

      <div className="relative mx-auto w-full max-w-[min(100%,calc((100dvh_-_470px)*1.25))] rounded-xl bg-[linear-gradient(160deg,#5b2f12,#1c0a02)] p-1.5 ring-2 ring-amber-400/60 shadow-[inset_0_0_30px_rgba(0,0,0,0.8)]">
        <div className="relative grid grid-cols-5 gap-1" style={{ aspectRatio: '5 / 4' }}>
          {Array.from({ length: SIZE }, (_, i) => {
            const c = i % REELS, r = Math.floor(i / REELS), key = `${c},${r}`, cell = cells[key];
            const isNew = fresh[key], boosted = boost?.touched.has(key), got = collecting?.done.has(key), cur = collecting?.current === key;
            return (
              <div key={key} className={`relative overflow-hidden rounded-md ${cell ? 'bg-[radial-gradient(circle,rgba(253,224,71,0.25),rgba(28,10,2,0.9))] ring-1 ring-amber-300/60' : 'bg-black/45 ring-1 ring-amber-900/50'} ${cell && !collecting ? 'st-locked' : ''}`} style={{ gridColumn: c + 1, gridRow: r + 1 }}>
                {!cell && spinning && (
                  <div className="p3-strip fast absolute inset-x-0 top-0" style={{ animationDelay: `${-(c * 37 + r * 13) % 200}ms` }}>
                    {[0, 1, 2, 3].map((j) => <div key={j} className="aspect-square p-[10%] opacity-50 blur-[1.5px]"><svg viewBox="0 0 100 100"><CashCoin v={[1, 'MINI', 2, 5][(j + c + r) % 4]} /></svg></div>)}
                  </div>
                )}
                {cell && (
                  <svg viewBox="0 0 100 100" className={`absolute inset-0 h-full w-full p-[4%] ${isNew ? 'st-coinland' : ''} ${boosted ? 'st-boost' : ''} ${cur ? 'st-boost' : got ? 'st-collect' : ''}`} aria-label={`Locked ${cell.v}`}>
                    <CashCoin v={cell.v} bet={bet} money={money} />
                  </svg>
                )}
                {isNew && <Burst key={`${key}-${resetKey}`} game="stampede" n={8} spread={36} />}
              </div>
            );
          })}
          {boost && (
            <div key={boost.id} className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
              <div className="st-reset rounded-2xl bg-gradient-to-b from-red-500 to-red-800 px-6 py-2 text-center font-display text-5xl text-yellow-100 shadow-[0_0_40px_rgba(239,68,68,0.8)] ring-4 ring-yellow-200">×{boost.m}<div className="font-sans text-xs font-extrabold tracking-wider">STAMPEDE! EVERY CREDIT ×{boost.m}</div></div>
            </div>
          )}
          {banner && (
            <div key={banner.id} className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center">
              <div className="absolute"><Burst game="stampede" n={40} spread={170} /></div>
              <div className={`st-reset rounded-2xl bg-gradient-to-b px-5 py-3 text-center shadow-[0_0_50px_rgba(253,224,71,0.8)] ring-4 ring-white ${TIER_CLS[banner.tier]}`}>
                <div className="font-display text-2xl tracking-wider sm:text-4xl">{banner.text}</div>
                <div className="font-cond text-3xl font-extrabold tabular-nums sm:text-5xl">{money(banner.amount)}</div>
              </div>
            </div>
          )}
        </div>
      </div>
      <p className="mt-1.5 text-center text-[11px] text-amber-100/75">
        {collecting ? 'Collecting the herd…' : `Every new buffalo locks and resets the respins to ${HOLD_RESPINS}. Fill all ${SIZE} for the Grand.`}
      </p>
    </div>
  );
}
