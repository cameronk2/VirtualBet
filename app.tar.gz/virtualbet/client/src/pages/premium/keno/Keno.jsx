// Keno 40 – game screen. The server draws all 10 numbers (crypto RNG) and
// settles the round in one step; this screen releases the balls one at a
// time from the machine to reveal that draw. Full screen on phones.
import { lockScroll } from '../../../lib/scrollLock.js';
import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Burst, PremiumShell, SidePanel, SoundMenu, sleep, usePremium } from '../../../components/Premium.jsx';
import { Modal } from '../../../components/ui.jsx';
import { Ball } from '../../../components/SlotArtKeno.jsx';
import { useApp } from '../../../state/AppContext.jsx';
import { kenoSfx } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { DRAW, MAX_PICKS, MODES, POOL, TABLES, prob, tableMode, tableRtp } from '../../../../../server/games/keno/config.js';

const MODE_INFO = {
  classic: { label: 'Classic', note: 'Pick your numbers, steady payouts' },
  quick: { label: 'Quick', note: 'Auto picks, fast draw' },
  high: { label: 'High risk', note: 'Fewer wins, much bigger top prizes' },
};
const pref = (k, d) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } };
const fmtX = (m) => (m >= 1000 ? `${Math.floor(m).toLocaleString()}x` : `${m.toFixed(2)}x`);
const pct = (p) => (p >= 0.01 ? `${(p * 100).toFixed(2)}%` : p >= 0.0001 ? `${(p * 100).toFixed(4)}%` : `1 in ${Math.round(1 / p).toLocaleString()}`);
const when = (t) => new Date(t).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const randomPicks = (n, keep = []) => { const s = new Set(keep); while (s.size < n) { const b = new Uint32Array(1); crypto.getRandomValues(b); s.add((b[0] % POOL) + 1); } return [...s]; };
const TUMBLERS = Array.from({ length: 14 }, (_, i) => ({ n: ((i * 17) % 40) + 1, x: 18 + ((i * 29) % 58), y: 26 + ((i * 41) % 46), d: 1.8 + (i % 5) * 0.35, ax: ((i * 13) % 30) - 15, ay: ((i * 7) % 26) - 13, bx: ((i * 19) % 34) - 17, by: ((i * 11) % 30) - 15, cx: ((i * 23) % 26) - 13, cy: ((i * 5) % 22) - 11 }));

function useCount(value, ms = 900, onTick) {
  const [shown, setShown] = useState(value);
  useEffect(() => {
    const t0 = performance.now(); let id, last = -1;
    const step = (now) => { const k = Math.min(1, (now - t0) / ms), e = 1 - (1 - k) ** 3; setShown(value * e); const tick = Math.floor(k * 12); if (tick !== last) { last = tick; onTick?.(tick); } if (k < 1) id = requestAnimationFrame(step); };
    id = requestAnimationFrame(step);
    return () => cancelAnimationFrame(id);
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps
  return shown;
}

function Machine({ fast, c }) {
  return (
    <div className={`relative mx-auto aspect-[4/5] h-full ${fast ? 'kn-fast' : ''}`}>
      <svg viewBox="0 0 100 125" className="absolute inset-0 h-full w-full" aria-hidden="true">
        <ellipse cx="50" cy="120" rx="34" ry="4" fill="#000" opacity=".35" />
        <path d="M30 98H70L66 118H34Z" fill="url(#knChrome)" stroke="#0f172a" strokeWidth="1.2" />
        <rect x="42" y="88" width="16" height="14" fill="url(#knChrome)" stroke="#0f172a" strokeWidth="1" />
        <circle cx="50" cy="50" r="44" fill="rgba(30,27,75,.55)" />
      </svg>
      <div className="absolute left-[6%] top-[4.8%] h-[70.4%] w-[88%] overflow-hidden rounded-full">
        {TUMBLERS.map((b, i) => (
          <div key={i} className="kn-tumble absolute h-[18%] w-[18%]" style={{ left: `${b.x}%`, top: `${b.y}%`, '--d': `${b.d}s`, '--ax': `${b.ax}px`, '--ay': `${b.ay}px`, '--bx': `${b.bx}px`, '--by': `${b.by}px`, '--cx': `${b.cx}px`, '--cy': `${b.cy}px`, animationDelay: `${-i * 0.37}s` }}>
            <svg viewBox="0 0 100 100" className="h-full w-full"><Ball n={b.n} shadow={false} /></svg>
          </div>
        ))}
      </div>
      <svg viewBox="0 0 100 125" className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true">
        <circle cx="50" cy="50" r="44" fill="url(#knGlass)" stroke="url(#knChrome)" strokeWidth="3" />
        <ellipse cx="34" cy="24" rx="16" ry="7" fill="#fff" opacity=".25" transform="rotate(-30 34 24)" />
      </svg>
      {!c && <div className="absolute inset-x-0 -bottom-4 text-center text-[9px] font-semibold uppercase tracking-[.2em] text-indigo-200/60">{fast ? 'Drawing' : 'Ready'}</div>}
    </div>
  );
}

export default function Keno() {
  const { config } = useApp();
  const { user, view, play, commit, guard, shake, doShake } = usePremium('keno');
  const fx = useMemo(() => kenoSfx(), []);
  const rules = config?.rules || { minStake: 10, maxStake: 50000 };
  const [mode, setMode] = useState(() => (['classic', 'quick', 'high'].includes(pref('kn_mode', 'classic')) ? pref('kn_mode', 'classic') : 'classic'));
  const [picks, setPicks] = useState(() => { try { const v = JSON.parse(pref('kn_picks', '[]')); return Array.isArray(v) && v.every((x) => Number.isInteger(x) && x >= 1 && x <= 40) ? [...new Set(v)].slice(0, 10) : []; } catch { return []; } });
  const [quickN, setQuickN] = useState(() => { const v = parseInt(pref('kn_qn', '5'), 10); return v >= 1 && v <= 10 ? v : 5; });
  const [stake, setStake] = useState(() => { const v = parseInt(pref('kn_bet', '100'), 10); return Number.isSafeInteger(v) && v > 0 ? v : 100; });
  const [betText, setBetText] = useState(() => (stake / 100).toFixed(2));
  const [phase, setPhase] = useState('idle');        // idle | drawing | done
  const [drawn, setDrawn] = useState([]);
  const [flash, setFlash] = useState(null);
  const [flyer, setFlyer] = useState(null);
  const [res, setRes] = useState(null);
  const [showRes, setShowRes] = useState(false);
  const [roundPicks, setRoundPicks] = useState(null);
  const [pop, setPop] = useState(true); // every game opens full screen; ✕ leaves it for this visit
  const [histOpen, setHistOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [expanded, setExpanded] = useState(null);

  const drawing = phase === 'drawing';
  const balance = user?.balance ?? 0;
  const tm = tableMode(mode);
  const shownPicks = roundPicks ?? picks;
  const n = mode === 'quick' && !roundPicks ? quickN : shownPicks.length;
  const table = n ? TABLES[tm][n] : [];
  const matchSet = useMemo(() => new Set(drawn.filter((x) => shownPicks.includes(x))), [drawn, shownPicks]);
  const matches = matchSet.size;

  const togglePop = (v) => { setPop(v); fx.click(); };
  useEffect(() => (pop ? lockScroll() : undefined), [pop]);
  useEffect(() => { save('kn_picks', JSON.stringify(picks)); }, [picks]);

  const setBet = (v) => { const c = Math.max(rules.minStake, Math.min(rules.maxStake, Math.round(v))); setStake(c); setBetText((c / 100).toFixed(2)); save('kn_bet', String(c)); };
  const resetBoard = () => { if (phase === 'done') { setDrawn([]); setRes(null); setShowRes(false); setRoundPicks(null); setPhase('idle'); } };
  const toggle = (x) => {
    if (drawing || mode === 'quick') return;
    resetBoard();
    setPicks((p) => { if (p.includes(x)) { fx.select(false); return p.filter((y) => y !== x); } if (p.length >= MAX_PICKS) return p; fx.select(true, p.length); return [...p, x]; });
  };
  const quickPick = () => { if (drawing) return; resetBoard(); const k = mode === 'quick' ? quickN : Math.max(1, picks.length || 5); setPicks(randomPicks(k)); fx.rattle(); };
  const fillTen = () => { if (drawing || mode === 'quick') return; resetBoard(); setPicks((p) => randomPicks(MAX_PICKS, p)); fx.rattle(); };
  const clearPicks = () => { if (drawing) return; resetBoard(); setPicks([]); fx.click(); };
  const chooseMode = (m) => { if (drawing) return; resetBoard(); setMode(m); save('kn_mode', m); fx.click(); };

  // geometry for the flying ball
  const rootRef = useRef(null), chuteRef = useRef(null), slotRefs = useRef([]);
  const centre = (el) => { const r = el.getBoundingClientRect(), o = rootRef.current.getBoundingClientRect(); return { x: r.left - o.left + r.width / 2, y: r.top - o.top + r.height / 2, w: r.width }; };

  const run = () => guard(async () => {
    if (drawing) return;
    let use = picks;
    if (mode === 'quick') { use = randomPicks(quickN); setPicks(use); }
    if (!use.length || stake > balance) return;
    setDrawn([]); setRes(null); setShowRes(false); setRoundPicks(use); setPhase('drawing'); fx.click();
    const out = await play('play', { stake, picks: use, mode });
    if (!out) { setPhase('idle'); setRoundPicks(null); return; }
    const fast = mode === 'quick';
    const set = new Set(use);
    let got = 0;
    fx.rattle();
    for (let i = 0; i < DRAW; i++) {
      const num = out.drawn[i];
      const remainingPicks = use.length - got;
      const suspense = !fast && i === DRAW - 1 && remainingPicks > 0;
      if (suspense) { fx.drumroll(0.55); await sleep(550); }
      // release from the chute, then fly to its slot in the tray
      const from = chuteRef.current && rootRef.current ? centre(chuteRef.current) : null;
      const to = slotRefs.current[i] && rootRef.current ? centre(slotRefs.current[i]) : null;
      fx.release(); if (i % 3 === 0) fx.rattle();
      if (from && to) {
        setFlyer({ n: num, x: from.x, y: from.y, size: to.w * 1.25, moving: false, id: i });
        await sleep(fast ? 110 : 220);
        setFlyer({ n: num, x: to.x, y: to.y, size: to.w, moving: true, id: i, ms: fast ? 170 : 300 });
        await sleep(fast ? 180 : 310);
      }
      setFlyer(null);
      setDrawn((d) => [...d, num]);
      fx.reveal(i);
      if (set.has(num)) { got++; setFlash({ n: num, id: `${i}` }); setTimeout(() => fx.match(got), 60); }
      await sleep(fast ? 80 : 160);
    }
    commit();
    const r = { bet: out.bet, picks: out.picks, drawn: out.drawn, matches: out.matches, mult: out.mult, payout: out.win, n: out.picks.length, mode };
    setRes(r); setPhase('done');
    if (r.payout > r.bet) { fx.win(); if (r.mult >= 20) { fx.celebrate(); doShake(r.mult >= 100); } } else if (!r.payout) fx.lose();
    setTimeout(() => setShowRes(true), fast ? 250 : 400);
  });

  // keyboard: Enter = play, Q = quick pick, C = clear
  const keys = useRef({}); keys.current = { run, quickPick, clearPicks, drawing };
  useEffect(() => {
    const h = (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(e.target.tagName) || e.repeat) return;
      const k = keys.current; if (k.drawing) return;
      if (e.code === 'Enter') { e.preventDefault(); k.run(); } else if (e.code === 'KeyQ') k.quickPick(); else if (e.code === 'KeyC') k.clearPicks();
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, []);

  // board sizing in the pop-out: as large as fits at 8:5
  const boxRef = useRef(null);
  const [box, setBox] = useState({ w: 320, h: 200 });
  useEffect(() => {
    const el = boxRef.current; if (!el) return undefined;
    const ro = new ResizeObserver(() => { const w = el.clientWidth, h = el.clientHeight; const bw = Math.min(w, (h * 8) / 5.15); setBox({ w: Math.floor(bw), h: Math.floor((bw * 5.15) / 8) }); });
    ro.observe(el); return () => ro.disconnect();
  }, [pop]);

  const shownPay = useCount(res?.payout || 0, 1000, (i) => { if (res?.payout && i < 12) fx.count(i); });

  // ── pieces ──────────────────────────────────────────────────────────────
  const tray = (c) => (
    <div className="flex min-w-0 flex-1 flex-col justify-center gap-1">
      <div className="mx-auto grid w-full grid-cols-5 gap-1" style={{ maxWidth: c ? 'calc((clamp(84px, 17dvh, 132px) - 30px) * 2.6)' : 'calc((clamp(110px, 18vw, 160px) - 34px) * 2.6)' }}>
        {Array.from({ length: DRAW }, (_, i) => {
          const num = drawn[i];
          return (
            <div key={i} ref={(el) => { slotRefs.current[i] = el; }} className={`relative aspect-square rounded-full ${num ? '' : 'bg-black/40 ring-1 ring-inset ring-indigo-300/20'}`}>
              {num && <svg viewBox="0 0 100 100" className={`kn-spinin absolute inset-0 h-full w-full ${matchSet.has(num) ? 'drop-shadow-[0_0_8px_#fde047]' : ''}`} aria-label={`Ball ${num}${matchSet.has(num) ? ', match' : ''}`}><Ball n={num} shadow={false} /></svg>}
              {num && matchSet.has(num) && <span className="absolute -right-0.5 -top-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-amber-300 text-[9px] font-black text-amber-950 ring-1 ring-white">✓</span>}
            </div>
          );
        })}
      </div>
      <div className={`flex items-center justify-between gap-1 rounded-lg bg-black/40 px-2 ring-1 ring-indigo-300/20 ${c ? 'py-0.5' : 'py-1'}`}>
        <span className="text-[11px] font-semibold text-indigo-100">Matches <b className="font-display text-base text-amber-200">{matches}</b><span className="text-indigo-200/60">/{n || 0}</span></span>
        <span className="text-[11px] font-semibold text-indigo-100">Drawn <b className="text-white">{drawn.length}</b>/10</span>
        <span className="text-[11px] font-semibold text-indigo-100">Pays <b className={`font-display text-base ${n && table[matches] ? 'text-amber-200' : 'text-white/60'}`}>{n ? fmtX(table[matches] || 0) : '—'}</b></span>
      </div>
    </div>
  );

  const tileState = (x) => {
    const picked = shownPicks.includes(x), hit = drawn.includes(x);
    if (picked && hit) return 'match';
    if (hit) return 'drawn';
    if (picked) return phase === 'done' ? 'miss' : 'picked';
    return 'none';
  };
  const TILE = {
    none: 'bg-[linear-gradient(160deg,#2a2c5c,#191a3a)] text-indigo-100/85 ring-1 ring-indigo-300/15 hover:brightness-125',
    picked: 'bg-[linear-gradient(160deg,#8b5cf6,#5b21b6)] text-white ring-2 ring-violet-200/80 shadow-[0_0_14px_rgba(167,139,250,0.65)]',
    match: 'kn-match bg-[linear-gradient(160deg,#fde047,#d97706)] text-amber-950 ring-2 ring-yellow-100',
    drawn: 'bg-[linear-gradient(160deg,#1e3a8a,#172554)] text-sky-100 ring-2 ring-sky-400/80',
    miss: 'bg-[linear-gradient(160deg,#3b2a5c,#221a3a)] text-violet-200/70 ring-2 ring-violet-400/40 ring-dashed',
  };
  const board = (c) => (
    <div className={c ? 'relative' : 'relative'} style={c ? { width: box.w, height: box.h } : undefined}>
      <div className={`grid grid-cols-8 gap-1 rounded-2xl bg-[linear-gradient(160deg,rgba(124,58,237,0.22),rgba(15,16,41,0.85))] p-1.5 ring-1 ring-violet-300/30 shadow-[0_0_40px_rgba(124,58,237,0.25),inset_0_0_30px_rgba(0,0,0,0.6)] sm:gap-1.5 sm:p-2 ${c ? 'h-full grid-rows-5' : ''}`}>
        {Array.from({ length: POOL }, (_, i) => {
          const x = i + 1, st = tileState(x);
          return (
            <button key={x} type="button" onClick={() => toggle(x)} disabled={drawing || mode === 'quick'} aria-pressed={shownPicks.includes(x)} aria-label={`Number ${x}${st === 'match' ? ', match' : st === 'drawn' ? ', drawn' : st === 'picked' ? ', selected' : ''}`}
              className={`relative flex items-center justify-center rounded-lg font-display text-sm transition-[filter,transform] duration-150 sm:text-lg ${c ? '' : 'aspect-square'} ${TILE[st]} ${st === 'picked' ? 'kn-sel' : ''} ${flash?.n === x ? 'kn-hitflash' : ''} disabled:cursor-default`}>
              {st === 'drawn' && <span className="absolute inset-[18%] rounded-full bg-sky-400/20 ring-1 ring-sky-300/50" />}
              {st === 'picked' && <span className="kn-sheen pointer-events-none absolute inset-0 rounded-lg" />}
              <span className="relative">{x}</span>
              {flash?.n === x && <Burst key={flash.id} game="keno" n={14} spread={46} />}
            </button>
          );
        })}
      </div>
      {res && showRes && (
        <div className="absolute inset-0 z-30 flex items-center justify-center p-1">
          <div className={`p3-intro-pop relative w-full max-w-[340px] overflow-hidden rounded-2xl p-3 text-center shadow-2xl ring-2 backdrop-blur-md ${res.payout > res.bet ? 'bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,0.96),rgba(15,16,41,0.97))] ring-amber-300/80' : res.payout ? 'bg-[radial-gradient(ellipse_at_top,rgba(30,64,175,0.95),rgba(15,16,41,0.97))] ring-sky-300/60' : 'bg-[radial-gradient(ellipse_at_top,rgba(76,29,149,0.92),rgba(15,16,41,0.97))] ring-violet-300/40'}`}>
            {res.payout > res.bet && <div className="pointer-events-none absolute left-1/2 top-8"><Burst game="keno" n={36} spread={150} /></div>}
            <div className={`font-display text-lg tracking-wider ${res.payout > res.bet ? 'text-amber-200' : res.payout ? 'text-sky-200' : 'text-violet-200'}`}>{res.payout > res.bet ? (res.mult >= 20 ? 'BIG WIN!' : 'YOU WIN!') : res.payout ? 'PART RETURN' : 'NO WIN THIS TIME'}</div>
            <div className="font-cond text-3xl font-extrabold tabular-nums text-white drop-shadow-[0_0_12px_rgba(253,224,71,0.5)]">{money(Math.floor(shownPay))}</div>
            <div className="text-[11px] text-indigo-100/80">{res.matches} of {res.n} matched · {fmtX(res.mult)}</div>
            <div className="mt-2 grid grid-cols-4 gap-1 text-[10px] text-indigo-100">
              {[['Bet', money(res.bet)], ['Matches', `${res.matches}/${res.n}`], ['Payout', money(res.payout)], [res.payout >= res.bet ? 'Profit' : 'Net', `${res.payout >= res.bet ? '+' : '−'}${money(Math.abs(res.payout - res.bet))}`]].map(([k, v]) => (
                <div key={k} className="rounded-md bg-black/30 px-1 py-1"><div className="text-[8px] uppercase tracking-wider text-indigo-200/70">{k}</div><div className="font-cond text-xs font-bold tabular-nums text-white">{v}</div></div>
              ))}
            </div>
            <div className="mt-2 text-left text-[10px] text-indigo-200/80">Your numbers</div>
            <div className="flex flex-wrap gap-0.5">{res.picks.map((x) => <span key={x} className={`rounded px-1 text-[11px] font-bold ${res.drawn.includes(x) ? 'bg-amber-300 text-amber-950' : 'bg-violet-900/70 text-violet-200'}`}>{x}</span>)}</div>
            <div className="mt-1 text-left text-[10px] text-indigo-200/80">Drawn</div>
            <div className="flex flex-wrap gap-0.5">{res.drawn.map((x) => <span key={x} className={`rounded px-1 text-[11px] font-bold ${res.picks.includes(x) ? 'bg-amber-300 text-amber-950' : 'bg-sky-900/70 text-sky-100'}`}>{x}</span>)}</div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setShowRes(false)} className="rounded-full bg-white/15 py-2 text-sm font-bold text-white ring-1 ring-white/25">See board</button>
              <button type="button" onClick={run} disabled={stake > balance} className="rounded-full bg-gradient-to-b from-amber-200 to-amber-500 py-2 text-sm font-extrabold text-amber-950 disabled:opacity-50">{mode === 'quick' ? 'Quick play again' : 'Play again'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const payStrip = (c) => (
    <button type="button" onClick={() => setPayOpen(true)} className={`flex w-full items-center gap-1 overflow-x-auto rounded-lg bg-black/35 px-1.5 text-left ring-1 ring-indigo-300/20 ${c ? 'py-1' : 'py-1.5'}`} aria-label="Open the payout table">
      <span className="shrink-0 text-[10px] font-semibold uppercase tracking-wider text-indigo-200/70">{n ? `${n} pick${n > 1 ? 's' : ''}` : 'Pick 1–10'}</span>
      {n ? table.map((x, k) => (x ? (
        <span key={k} className={`shrink-0 rounded-md px-1.5 py-0.5 text-[11px] font-bold tabular-nums ${phase !== 'idle' && k === matches && drawn.length === DRAW ? 'bg-amber-300 text-amber-950' : 'bg-indigo-950/80 text-indigo-100'}`}>{k}✓ <span className="text-amber-200">{fmtX(x)}</span></span>
      ) : null)) : <span className="text-[11px] text-indigo-200/70">Select numbers to see what they pay</span>}
      <span className="ml-auto shrink-0 text-[10px] text-indigo-200/60 underline">Table</span>
    </button>
  );

  const stageEl = (c) => (
    <div ref={rootRef} className={c ? 'relative flex min-h-0 flex-1 flex-col gap-1.5' : 'relative mx-auto max-w-[min(100%,calc((100dvh_-_460px)*1.25),640px)] min-w-[300px] space-y-2'}>
      <div className={`flex items-stretch gap-2 ${c ? 'h-[clamp(84px,17dvh,132px)]' : 'h-[clamp(110px,18vw,160px)]'}`}>
        <div className="relative shrink-0">
          <Machine fast={drawing} c={c} />
          <div ref={chuteRef} className="absolute bottom-[6%] left-1/2 h-4 w-4 -translate-x-1/2" />
        </div>
        {tray(c)}
      </div>
      {c ? <div ref={boxRef} className="flex min-h-0 flex-1 items-center justify-center">{board(true)}</div> : board(false)}
      {payStrip(c)}
      {flyer && (
        <div className="pointer-events-none absolute z-40" style={{ left: flyer.x - flyer.size / 2, top: flyer.y - flyer.size / 2, width: flyer.size, height: flyer.size, transform: 'translate(0,0)', transition: flyer.moving ? `left ${flyer.ms}ms cubic-bezier(.3,.7,.3,1), top ${flyer.ms}ms cubic-bezier(.5,0,.6,1.4), width ${flyer.ms}ms, height ${flyer.ms}ms` : 'none' }}>
          <svg key={flyer.id} viewBox="0 0 100 100" className="kn-pop h-full w-full drop-shadow-[0_6px_10px_rgba(0,0,0,0.55)]" aria-hidden="true"><g className={flyer.moving ? 'kn-tumble' : ''} style={{ '--d': '0.6s', '--ax': '0px', '--ay': '0px', '--bx': '0px', '--by': '0px', '--cx': '0px', '--cy': '0px', transformOrigin: '50px 50px' }}><Ball n={flyer.n} /></g></svg>
        </div>
      )}
    </div>
  );

  const canPlay = !drawing && stake <= balance && (mode === 'quick' ? quickN > 0 : picks.length > 0);
  const barEl = (c) => (
    <div className={c ? 'card shrink-0 space-y-1.5 p-2' : 'card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none'}>
      <div className="grid grid-cols-3 gap-1" role="radiogroup" aria-label="Game mode">
        {['classic', 'quick', 'high'].map((m) => (
          <button key={m} type="button" role="radio" aria-checked={mode === m} disabled={drawing} onClick={() => chooseMode(m)}
            className={`rounded-lg px-1 text-center leading-tight ${c ? 'py-1' : 'py-1.5'} ${mode === m ? 'bg-gradient-to-b from-violet-400 to-indigo-700 text-white ring-2 ring-amber-200/60' : 'bg-navy-800 text-slate-300'} disabled:opacity-60`}>
            <div className="text-xs font-extrabold">{MODE_INFO[m].label}</div>
            {!c && <div className="text-[9px] opacity-80">{MODE_INFO[m].note}</div>}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        {mode === 'quick' ? (
          <div className="flex items-center gap-1">
            <span className="text-xs font-semibold text-slate-400">Numbers</span>
            <div className="flex items-center rounded-lg bg-navy-800 ring-1 ring-navy-600">
              <button className="h-9 w-8 text-lg text-slate-200 disabled:opacity-40" disabled={drawing || quickN <= 1} onClick={() => { setQuickN(quickN - 1); save('kn_qn', String(quickN - 1)); resetBoard(); }} aria-label="Fewer numbers">−</button>
              <span className="w-6 text-center font-cond text-lg font-bold text-white">{quickN}</span>
              <button className="h-9 w-8 text-lg text-slate-200 disabled:opacity-40" disabled={drawing || quickN >= 10} onClick={() => { setQuickN(quickN + 1); save('kn_qn', String(quickN + 1)); resetBoard(); }} aria-label="More numbers">+</button>
            </div>
          </div>
        ) : (
          <span className={`rounded-md px-2 py-1.5 text-xs font-bold tabular-nums ${picks.length === MAX_PICKS ? 'bg-amber-300 text-amber-950' : 'bg-navy-800 text-slate-200'}`}>Picks {picks.length}/{MAX_PICKS}</span>
        )}
        <button className="rounded-lg bg-navy-700 px-2.5 py-1.5 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={drawing} onClick={quickPick}>Quick Pick</button>
        {mode !== 'quick' && <button className="rounded-lg bg-navy-700 px-2.5 py-1.5 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={drawing || picks.length >= MAX_PICKS} onClick={fillTen} title="Add random numbers up to 10">Fill to 10</button>}
        <button className="rounded-lg bg-navy-700 px-2.5 py-1.5 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={drawing || (!picks.length && phase !== 'done')} onClick={clearPicks}>Clear</button>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <div className="flex items-center rounded-lg bg-navy-800 ring-1 ring-navy-600">
          <button className="h-10 w-9 text-lg text-slate-200 disabled:opacity-40" disabled={drawing} onClick={() => setBet(stake - (stake > 1000 ? 100 : 10))} aria-label="Lower bet">−</button>
          <label className="flex items-center gap-0.5 text-sm font-bold text-white">£
            <input inputMode="decimal" aria-label="Bet amount" className="w-16 bg-transparent py-2 text-center font-cond text-lg font-bold tabular-nums outline-none" value={betText} disabled={drawing}
              onChange={(e) => setBetText(e.target.value.replace(/[^\d.]/g, ''))} onBlur={() => { const v = Math.round(parseFloat(betText || '0') * 100); setBet(Number.isFinite(v) ? v : stake); }}
              onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }} />
          </label>
          <button className="h-10 w-9 text-lg text-slate-200 disabled:opacity-40" disabled={drawing} onClick={() => setBet(stake + (stake >= 1000 ? 100 : 10))} aria-label="Raise bet">+</button>
        </div>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={drawing} onClick={() => setBet(stake / 2)}>½</button>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={drawing} onClick={() => setBet(stake * 2)}>2×</button>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={drawing} onClick={() => setBet(Math.min(rules.maxStake, Math.max(rules.minStake, balance)))}>Max</button>
        <div className={`ml-auto text-right text-[11px] leading-tight text-slate-400 ${c ? 'hidden' : ''}`}>Balance<div className="font-cond text-base font-bold tabular-nums text-white">{money(balance)}</div></div>
      </div>
      <button onClick={run} disabled={!canPlay} className={`btn ${c ? 'h-12' : 'h-14'} w-full rounded-full bg-gradient-to-b from-amber-200 to-amber-500 text-lg font-extrabold text-amber-950 shadow-[0_0_24px_rgba(251,191,36,0.35)] active:scale-95`}>
        {drawing ? `Drawing… ${drawn.length}/10` : stake > balance ? 'Not enough balance' : mode !== 'quick' && !picks.length ? 'Pick at least 1 number' : `${mode === 'quick' ? 'Quick play' : 'Play'} · ${money(stake)}`}
      </button>
    </div>
  );

  const stats = view?.stats || { rounds: 0, wagered: 0, paid: 0, biggestWin: 0, bestMatches: 0, bestMatchesOf: 0 };
  const recent = view?.recent || [];
  const statsPanel = (
    <SidePanel title="Lifetime statistics">
      <dl className="grid grid-cols-2 gap-1 text-xs">
        {[['Rounds', stats.rounds.toLocaleString()], ['Wagered', money(stats.wagered)], ['Paid out', money(stats.paid)], ['Net', `${stats.paid >= stats.wagered ? '+' : '−'}${money(Math.abs(stats.paid - stats.wagered))}`], ['Biggest win', stats.biggestWin ? `${money(stats.biggestWin)} (${fmtX(stats.biggestMult || 0)})` : '—'], ['Most matches', stats.rounds ? `${stats.bestMatches} of ${stats.bestMatchesOf}` : '—']].map(([k, v]) => (
          <div key={k} className="rounded-md bg-navy-800 px-2 py-1"><dt className="text-[10px] uppercase text-slate-500">{k}</dt><dd className="font-semibold tabular-nums text-white">{v}</dd></div>
        ))}
      </dl>
    </SidePanel>
  );
  const historyPanel = (
    <SidePanel title="Recent games">
      {recent.length ? (
        <ul className="max-h-[420px] space-y-1 overflow-auto text-[11px]">
          {recent.map((r, k) => (
            <li key={k}>
              <button type="button" onClick={() => setExpanded(expanded === k ? null : k)} className={`w-full rounded-md border-l-4 px-2 py-1 text-left ${r.result === 'win' ? 'border-emerald-400 bg-emerald-500/10' : r.result === 'part' ? 'border-sky-400 bg-sky-500/10' : 'border-red-500 bg-red-500/10'}`} aria-expanded={expanded === k}>
                <div className="flex justify-between gap-2"><span className="font-semibold text-white">{money(r.bet)} · {r.matches}/{r.picks.length} · {MODE_INFO[r.mode]?.label}</span><b className={r.result === 'loss' ? 'text-red-300' : 'text-emerald-300'}>{r.payout ? `${money(r.payout)} (${fmtX(r.mult)})` : `−${money(r.bet)}`}</b></div>
                <div className="flex justify-between gap-2 text-slate-400"><span>{r.result === 'win' ? 'Win' : r.result === 'part' ? 'Part return' : 'Loss'}</span><span>{when(r.at)}</span></div>
                {expanded === k && (
                  <div className="mt-1 space-y-0.5">
                    <div className="flex flex-wrap gap-0.5"><span className="mr-1 text-slate-500">Picked</span>{r.picks.map((x) => <span key={x} className={`rounded px-1 font-bold ${r.drawn.includes(x) ? 'bg-amber-300 text-amber-950' : 'bg-violet-900 text-violet-200'}`}>{x}</span>)}</div>
                    <div className="flex flex-wrap gap-0.5"><span className="mr-1 text-slate-500">Drawn</span>{r.drawn.map((x) => <span key={x} className={`rounded px-1 font-bold ${r.picks.includes(x) ? 'bg-amber-300 text-amber-950' : 'bg-sky-900 text-sky-100'}`}>{x}</span>)}</div>
                  </div>
                )}
              </button>
            </li>
          ))}
        </ul>
      ) : <div className="text-xs text-slate-500">No games yet.</div>}
    </SidePanel>
  );

  const payTable = (
    <div className="space-y-2 text-xs">
      <p className="text-slate-400">{MODES[tm].label} table{mode === 'quick' ? ' (Quick uses the Classic table)' : ''}. Return {(MODES[tm].rtp * 100).toFixed(0)}% for every pick count (exact figure shown, rounding down to the penny).</p>
      {Array.from({ length: 10 }, (_, i) => i + 1).map((pn) => (
        <details key={pn} className="rounded-lg bg-navy-800 p-2" open={pn === n}>
          <summary className="cursor-pointer font-bold text-white">{pn} pick{pn > 1 ? 's' : ''} · top {fmtX(TABLES[tm][pn][pn])} · return {(tableRtp(tm, pn) * 100).toFixed(2)}%</summary>
          <table className="mt-1 w-full text-right tabular-nums">
            <thead className="text-slate-400"><tr><th className="text-left">Matches</th><th>Chance</th><th>Multiplier</th><th>Pays at {money(stake)}</th></tr></thead>
            <tbody>{TABLES[tm][pn].map((x, k) => <tr key={k} className={`border-t border-navy-700 ${x ? 'text-white' : 'text-slate-500'}`}><td className="text-left">{k}</td><td>{pct(prob(pn, k))}</td><td>{x ? fmtX(x) : '—'}</td><td>{x ? money(Math.floor(stake * x)) : '—'}</td></tr>)}</tbody>
          </table>
        </details>
      ))}
    </div>
  );

  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to play</h3>
        <ol className="list-decimal space-y-1 pl-5">
          <li>Choose a mode, your bet and 1–10 numbers from 1–40 (tap them, or use Quick Pick).</li>
          <li>Press <b>Play</b>. The bet is taken and 10 numbers are drawn from the 40, no repeats.</li>
          <li>The more of your numbers that are drawn, the more you win. The table for your pick count shows exactly what each result pays.</li>
        </ol>
        <ul className="list-disc space-y-1 pl-5 text-xs">
          <li><b>Classic</b>: you pick, steady tables. <b>Quick</b>: choose how many numbers; it picks them and draws straight away, faster. Uses the Classic tables. <b>High risk</b>: fewer paying results, much bigger top prizes.</li>
        </ul>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How the payouts are worked out</h3>
        <p className="text-xs">With n picks, the chance of k matches is C(n,k)·C(40−n,10−k) / C(40,10). Each paying result gets a weight from its rarity, and the whole table is scaled so that the average return is exactly {Math.round(MODES.classic.rtp * 100)}%, then rounded down to 2 decimals. Classic caps any prize at {MODES.classic.cap.toLocaleString()}x, High risk at {MODES.high.cap.toLocaleString()}x.</p>
        {payTable}
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Fairness</b>: the 10 numbers are drawn on the server with a cryptographically secure generator before the balls appear; the machine only shows the result. Bets from {money(rules.minStake)} to {money(rules.maxStake)}.
      </section>
    </>
  );

  const header = (
    <div className="mb-1.5 flex shrink-0 items-center gap-2">
      <button type="button" onClick={() => togglePop(false)} className="flex h-9 w-9 items-center justify-center rounded-full bg-black/40 text-lg text-white ring-1 ring-white/15" aria-label="Exit full screen">✕</button>
      <div className="whitespace-nowrap font-display text-base leading-none tracking-wider text-amber-200 min-[380px]:text-lg">KENO 40</div>
      <div className="ml-auto text-right leading-tight"><div className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Balance</div><div className="font-cond text-base font-bold tabular-nums text-white">{money(balance)}</div></div>
      <button type="button" onClick={() => setHistOpen(true)} className="h-8 rounded-md bg-navy-700 px-2 text-xs font-semibold text-slate-200" aria-label="History and statistics">History</button>
      <SoundMenu game="keno" />
    </div>
  );

  return (
    <PremiumShell game="keno" popout={false} rtp="97%" tagline="40 numbers · 10 drawn · Classic, Quick & High risk" shake={shake}
      stageClass="border-2 border-violet-400/40 shadow-[0_0_60px_rgba(124,58,237,0.25)]"
      bg={<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#3b0764_0%,#1e1b4b_40%,#0b0b1e_85%)]"><div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_85%,rgba(59,130,246,0.15),transparent_45%)]" /></div>}
      below={<>{!pop && barEl(false)}<div className="mt-3 space-y-3 lg:hidden">{statsPanel}{historyPanel}</div></>} info={info}
      side={<>{statsPanel}{historyPanel}</>}>
      {pop ? (
        <div className="flex flex-col items-center gap-3 py-10 text-center">
          <p className="text-sm text-indigo-100">Keno is open in full screen.</p>
          <button type="button" onClick={() => togglePop(true)} className="rounded-full bg-gradient-to-b from-violet-400 to-indigo-700 px-6 py-3 font-extrabold text-white">Return to the game</button>
        </div>
      ) : (
        <div className="pt-1">
          <div className="mb-1.5 flex justify-end"><button type="button" onClick={() => togglePop(true)} className="rounded-md bg-black/40 px-2.5 py-1 text-xs font-semibold text-indigo-100 ring-1 ring-indigo-300/30 hover:bg-black/60" aria-label="Play full screen">⤢ Full screen</button></div>
          {stageEl(false)}
        </div>
      )}
      {pop && createPortal(
        <div className={`fixed inset-0 z-[45] flex flex-col bg-[radial-gradient(ellipse_at_top,#3b0764_0%,#1e1b4b_40%,#0b0b1e_85%)] px-2 ${shake}`} role="dialog" aria-label="Keno full screen"
          style={{ paddingTop: 'max(8px, env(safe-area-inset-top))', paddingBottom: 'max(8px, env(safe-area-inset-bottom))', height: '100dvh' }}>
          <div className="mx-auto flex min-h-0 w-full max-w-[620px] flex-1 flex-col">
            {header}
            {stageEl(true)}
            <div className="mt-1.5">{barEl(true)}</div>
          </div>
        </div>,
        document.body,
      )}
      {createPortal(<Modal open={histOpen} onClose={() => setHistOpen(false)} title="History and statistics"><div className="space-y-3">{statsPanel}{historyPanel}</div></Modal>, document.body)}
      {createPortal(<Modal open={payOpen} onClose={() => setPayOpen(false)} title="Payout table">{payTable}</Modal>, document.body)}
    </PremiumShell>
  );
}
