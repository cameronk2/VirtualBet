import { useEffect, useMemo, useState } from 'react';
import { BigWin, Burst, FeatureIntro, Paytable, PremiumReels, PremiumShell, RecentList, SidePanel, sleep, SpinBar, tierOf, usePremium, useReelStops, WinLine } from '../../components/Premium.jsx';
import { DragonTall, Sym3 } from '../../components/SlotArt3.jsx';
import { money } from '../../lib/format.js';
import { DR_CLIMB, DR_FORTUNE, DR_FORTUNE_P, DR_FREE, DR_LADDER, DR_PAY, DR_S, LINES_25, STATS3 } from '../../../../server/games/slots3.js';

const START = [['LANTERN', 'JADE', 'KOI'], ['COIN', 'DRAGON', 'FAN'], ['INGOT', 'PHOENIX', 'LANTERN'], ['KNOT', 'LION', 'COIN'], ['PEARL', 'FAN', 'LANTERN']].map((c) => c.map((s) => ({ s })));

function Palace({ lit, flyKey }) {
  const lanterns = useMemo(() => [8, 26, 74, 92], []);
  return (
    <>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#991b1b_0%,#450a0a_45%,#0c0202_100%)]" />
      <div className="absolute inset-0 opacity-[0.12] bg-[repeating-linear-gradient(45deg,#fbbf24_0_2px,transparent_2px_16px),repeating-linear-gradient(-45deg,#fbbf24_0_2px,transparent_2px_16px)]" />
      <svg viewBox="0 0 100 20" preserveAspectRatio="none" className="absolute inset-x-0 top-0 h-[10%] w-full" aria-hidden="true"><path d="M0 0h100v8c-10 0-14 6-25 6S60 8 50 8 35 14 25 14 10 8 0 8z" fill="#1c0505" /><path d="M0 8c10 0 15 6 25 6S40 8 50 8s15 6 25 6S90 8 100 8" stroke="#fbbf24" strokeWidth=".8" fill="none" /></svg>
      {lanterns.map((x, i) => (
        <div key={i} className="absolute top-0" style={{ left: `${x}%` }}>
          <div className="mx-auto h-6 w-px bg-amber-500/60" />
          <div className={`p3-lantern -ml-3 h-8 w-6 rounded-[45%] transition-all duration-700 ${lit ? 'bg-red-500 shadow-[0_0_24px_8px_rgba(251,191,36,0.75)]' : 'bg-red-800 shadow-[0_0_10px_2px_rgba(251,191,36,0.3)]'}`} style={{ animationDelay: `${-i * 0.7}s` }}><div className="mx-auto mt-1 h-6 w-px bg-amber-300/50" /></div>
        </div>
      ))}
      {flyKey > 0 && (
        <svg key={flyKey} viewBox="0 0 200 60" className="p3-deco p3-dragonfly absolute left-0 top-[18%] h-16 w-48 opacity-0" aria-hidden="true">
          <path d="M10 30c20-20 40 20 60 0s40 20 60 0 30 10 40 0" stroke="url(#s3gold)" strokeWidth="9" fill="none" strokeLinecap="round" />
          <path d="M170 30c6-10 18-12 24-4-4 2-6 8-2 12-8 2-16 0-22-8z" fill="url(#s3gold)" /><circle cx="186" cy="28" r="2" fill="#dc2626" />
        </svg>
      )}
    </>
  );
}

function FireReel({ id }) {
  return (
    <div key={id} className="pointer-events-none absolute inset-0 z-10 overflow-hidden rounded-lg">
      <div className="p3-fire absolute inset-0" />
      <DragonTall className="p3-fadeup absolute inset-0 h-full w-full bg-[radial-gradient(circle,#b91c1c,#450a0a)]" />
    </div>
  );
}

function Ladder({ ladder, onDone }) {
  const [step, setStep] = useState(0);
  useEffect(() => {
    if (step > ladder.level) return undefined;
    const t = setTimeout(() => setStep((s) => s + 1), step === 0 ? 700 : 520);
    return () => clearTimeout(t);
  }, [step, ladder.level]);
  const done = step > ladder.level;
  return (
    <div className="animate-fade-in absolute inset-0 z-30 flex flex-col items-center justify-center rounded-2xl bg-[radial-gradient(ellipse_at_center,#7f1d1d,#1c0505_75%)] p-3">
      <div className="font-display text-2xl tracking-wide text-amber-300">LUCKY LANTERNS</div>
      <div className="mb-2 text-[11px] text-amber-100/80">Each lantern lights the next with a 1 in 2 chance</div>
      <div className="flex flex-col-reverse gap-1">
        {DR_LADDER.map((x, i) => {
          const on = i < step, top = done && i === ladder.level;
          return (
            <div key={i} className={`flex w-48 items-center gap-2 rounded-lg px-2 py-0.5 transition-all duration-300 ${top ? 'bg-amber-400/30 ring-2 ring-amber-300' : on ? 'bg-red-900/60' : 'bg-black/40'}`}>
              <div className={`h-6 w-5 rounded-[45%] transition-all duration-300 ${on ? 'bg-red-500 shadow-[0_0_14px_4px_rgba(251,191,36,0.8)]' : 'bg-red-950 ring-1 ring-red-900'}`} />
              <span className={`font-cond text-lg font-extrabold tabular-nums ${on ? 'text-amber-200' : 'text-white/30'}`}>{x / 100}x</span>
              {top && <span className="ml-auto text-xs font-bold text-amber-200">{money(ladder.amount)}</span>}
            </div>
          );
        })}
      </div>
      {done && <button className="btn-primary p3-fadeup mt-3 h-11 px-6" onClick={onDone}>Collect {money(ladder.amount)}</button>}
    </div>
  );
}

export default function Dragon() {
  const { user, view, history, play, commit, fx, guard, shake, doShake } = usePremium('dragon');
  const reels = useReelStops(5);
  const [grid, setGrid] = useState(START);
  const [res, setRes] = useState(null);
  const [lit, setLit] = useState(null);
  const [fire, setFire] = useState([]);
  const [stake, setStake] = useState(100);
  const [turbo, setTurbo] = useState(false);
  const [auto, setAuto] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [fortune, setFortune] = useState(null);
  const [ladder, setLadder] = useState(null);
  const [flyKey, setFlyKey] = useState(0);
  const free = view?.free;
  const sticky = free?.sticky || [];

  // A golden dragon crosses the sky now and then
  useEffect(() => { const t = setInterval(() => setFlyKey((k) => k + 1), 16000); const f = setTimeout(() => setFlyKey(1), 2500); return () => { clearInterval(t); clearTimeout(f); }; }, []);

  const spin = () => guard(async () => {
    setSpinning(true); setRes(null); setLit(null); setFortune(null); setFire([]); setSpinId((n) => n + 1); reels.start(); fx.spin();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(); setSpinning(false); setAuto(false); return; }
    setGrid(out.landed);
    let seen = 0;
    const tease = [];
    out.landed.forEach((c, i) => { if (seen >= 2) tease.push(i); if (c.some((x) => x.s === 'PEARL')) seen++; });
    await reels.stopAll({ turbo, tease, onStop: (i) => { fx.stop(i); if (out.landed[i].some((x) => x.s === 'LANTERN' || x.s === 'PEARL')) fx.land(); } });
    if (out.fresh.length) { setFire(out.fresh); fx.special(); doShake(false); await sleep(turbo ? 500 : 1100); }
    setGrid(out.grid);
    setLit(new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`))));
    if (out.fortune) { setFortune(out.fortune); fx.special(); await sleep(turbo ? 500 : 1100); }
    setRes(out); setSpinning(false);
    if (out.ladder) { fx.bonus(); setLadder(out.ladder); return; } // committed when the ladder is collected
    commit();
    after(out);
  });
  const after = (out) => {
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); } else if (tier) { fx.win(tier); if (tier === 2) doShake(false); }
    if (out.trigger?.freeSpins) { fx.bonus(); setIntro(out.trigger.freeSpins); }
    if (out.finished) setBig({ amount: out.finished.total, title: "DRAGON'S TREASURE" });
    if (!out.free) setAuto(false);
  };
  useEffect(() => {
    if (!auto || !free || spinning || big || intro || ladder) return undefined;
    const t = setTimeout(spin, 900);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro, ladder]); // eslint-disable-line react-hooks/exhaustive-deps

  const overlays = [0, 1, 2, 3, 4].map((i) => {
    if (fire.includes(i)) return <FireReel id={`${spinId}-${i}`} />;
    if (sticky.includes(i) && (spinning || !res)) return <div className="pointer-events-none absolute inset-0 z-10 rounded-lg ring-2 ring-amber-300"><DragonTall className="h-full w-full bg-[radial-gradient(circle,#b91c1c,#450a0a)]" /></div>;
    return null;
  });
  const pt = Object.entries(DR_PAY).map(([s, v]) => [s, v.map((x) => x * DR_S)]);
  const detail = res && [res.wins.length && `${res.wins.length} line win${res.wins.length > 1 ? 's' : ''}`, res.fortune && `Golden Fortune x${res.fortune}`, res.ladder && `Lanterns ${money(res.ladder.amount)}`].filter(Boolean).join(' · ');
  return (
    <PremiumShell game="dragon" rtp="96%" tagline="5 reels · 25 lines · fire wilds · lucky lanterns" shake={shake}
      stageClass="border-[3px] border-amber-400/80 shadow-[0_0_40px_rgba(251,191,36,0.25)]" bg={<Palace lit={!!free || !!ladder} flyKey={flyKey} />}
      below={<SpinBar stake={stake} setStake={setStake} onSpin={spin} spinning={spinning} free={free} disabled={!!intro || !!ladder} balance={user?.balance} turbo={turbo} setTurbo={setTurbo} auto={auto} setAuto={setAuto} accent="bg-gradient-to-b from-amber-300 to-amber-600 text-red-950" />}
      side={<>
        <SidePanel title="Features">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-amber-300">Dragon Wild</b> breathes fire and fills its reel.</li>
            <li><b className="text-amber-300">Golden Fortune</b> can multiply any win x2–x8.</li>
            <li><b className="text-red-300">3 lanterns</b> light the Lucky Lantern ladder (up to 1,000x).</li>
            <li><b className="text-sky-300">3+ pearls</b>: free spins with sticky dragons.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Recent spins"><RecentList history={history} /></SidePanel>
      </>}
      info={<>
        <section><h3 className="mb-2 font-bold text-white">Paytable (multiples of total stake)</h3><Paytable game="dragon" rows={pt} /></section>
        <section className="space-y-2">
          <h3 className="font-bold text-white">Features</h3>
          <p><b className="text-amber-300">Dragon Wild</b> lands on reels 2–4, breathes fire and expands to fill the whole reel, substituting for every symbol except pearls and lanterns. Wins pay left to right on {LINES_25.length} lines.</p>
          <p><b className="text-amber-300">Golden Fortune</b>: any winning spin has a {Math.round(DR_FORTUNE_P * 100)}% chance of a fortune multiplier on its line wins ({DR_FORTUNE.map(([v]) => `x${v}`).join(', ')}).</p>
          <p><b className="text-red-300">Lucky Lanterns</b>: lanterns land on reels 1, 3 and 5. One on each lights the ladder: it starts at {DR_LADDER[0] / 100}x and each step up has a {DR_CLIMB * 100}% chance, through {DR_LADDER.map((x) => `${x / 100}x`).join(', ')}.</p>
          <p><b className="text-sky-300">Dragon's Treasure</b>: 3, 4 or 5 flaming pearls give {DR_FREE[3]}, {DR_FREE[4]} or {DR_FREE[5]} free spins. Every Dragon Wild that lands stays fixed for the rest of the round. 3 pearls add 4 more spins.</p>
        </section>
        <section className="rounded-lg bg-navy-800 p-3 text-xs"><b className="text-white">Maths</b>: long-run return 96% (about 7.5 points from the fixed lantern ladder) · line wins on about {STATS3.dragon.hit} of spins · {STATS3.dragon.feature} · maximum win 5,000x per spin · results come from a cryptographic random number generator before the reels animate.</section>
      </>}>
      <div className="relative pt-6">
        {free && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="rounded-md bg-amber-400 px-2.5 py-1 text-xs font-extrabold uppercase text-red-950">Dragon's Treasure · {free.remaining} left</div>
            <div className="rounded-md bg-black/50 px-2 py-1 text-xs font-bold text-amber-200">{sticky.length} sticky dragon{sticky.length === 1 ? '' : 's'}</div>
          </div>
        )}
        <div className="rounded-xl bg-gradient-to-b from-amber-200 via-amber-500 to-amber-800 p-[3px] shadow-[0_0_24px_rgba(251,191,36,0.35)]">
          <div className="rounded-[10px] bg-[#1c0505]/90 p-1.5 ring-1 ring-amber-900">
            <PremiumReels game="dragon" grid={grid} stopped={reels.stopped.map((s, i) => s || sticky.includes(i))} lit={lit} turbo={turbo} spinId={spinId} landing="bounce" overlays={overlays} />
          </div>
        </div>
        {fortune && (
          <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
            <div key={spinId} className="p3-stamp flex h-28 w-28 flex-col items-center justify-center rounded-full bg-[radial-gradient(circle,#fde68a,#d97706_60%,#78350f)] ring-4 ring-amber-200 drop-shadow-[0_0_24px_#facc15]">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-red-900">Golden Fortune</span><span className="font-display text-4xl text-red-900">x{fortune}</span>
            </div>
            <Burst game="dragon" n={22} spread={140} />
          </div>
        )}
        <div className="mt-2"><WinLine res={res} spinning={spinning} detail={detail} busyText="The dragon stirs…" /></div>
        {ladder && <Ladder ladder={ladder} onDone={() => { const out = res; setLadder(null); commit(); after(out); }} />}
        {intro && (
          <FeatureIntro title="DRAGON'S TREASURE" subtitle={`${intro} free spins. Every Dragon Wild that lands stays for the rest of the round.`}
            art={<div className="mb-2 h-24 w-24"><Sym3 game="dragon" s="PEARL" /></div>} className="bg-[radial-gradient(circle,rgba(127,29,29,0.92),rgba(12,2,2,0.95))]" onStart={() => { setIntro(null); setAuto(true); }} />
        )}
        {big && <BigWin game="dragon" amount={big.amount} bet={res?.bet || stake} title={big.title} onDone={() => setBig(null)}
          cinematic={<svg viewBox="0 0 200 60" className="p3-dragonfly pointer-events-none absolute left-0 top-[12%] h-24 w-72" aria-hidden="true"><path d="M10 30c20-20 40 20 60 0s40 20 60 0 30 10 40 0" stroke="url(#s3gold)" strokeWidth="10" fill="none" strokeLinecap="round" /><path d="M170 30c6-10 18-12 24-4-4 2-6 8-2 12-8 2-16 0-22-8z" fill="url(#s3gold)" /></svg>} />}
      </div>
    </PremiumShell>
  );
}
