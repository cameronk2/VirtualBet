import { useEffect, useRef, useState } from 'react';
import { BigWin, Burst, FeatureIntro, Paytable, PremiumReels, PremiumShell, RecentList, SidePanel, sleep, SpinBar, tierOf, usePremium, useReelStops, WinLine } from '../../components/Premium.jsx';
import { MULT_STONE, Sym3 } from '../../components/SlotArt3.jsx';
import { PH_LEVELS, PH_MULT_REEL, PH_MYSTERY_P, PH_PAY, PH_S, STATS3 } from '../../../../server/games/slots3.js';

const START = [['ANKH', 'MASK', 'LOTUS'], ['EYE', 'PHARAOH', 'CAT'], ['SCARAB', 'SPHINX', 'ANKH'], ['LOTUS', 'EYE', 'MASK'], ['CAT', 'ANKH', 'SPHINX']].map((c) => c.map((s) => ({ s })));

function Temple() {
  return (
    <>
      <div className="absolute inset-0 bg-[linear-gradient(180deg,#78350f_0%,#451a03_45%,#1c0a02_100%)]" />
      <svg viewBox="0 0 100 40" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-[35%] w-full opacity-60" aria-hidden="true">
        <path d="M0 40L22 12 44 40zM30 40L58 4 86 40zM70 40l18-20 18 20z" fill="#92400e" /><path d="M58 4l28 36H58z" fill="#78350f" />
      </svg>
      <div className="p3-deco p3-sand absolute inset-0 opacity-70" />
      <div className="absolute inset-x-0 top-0 h-5 bg-[repeating-linear-gradient(90deg,#1e3a8a_0_10px,#fbbf24_10px_12px,#0d9488_12px_22px,#fbbf24_22px_24px)] opacity-80" />
      {[0, 1].map((side) => (
        <div key={side} className={`absolute top-[18%] ${side ? 'right-1' : 'left-1'} flex flex-col items-center`}>
          <div className="p3-deco p3-torch h-7 w-4 rounded-[50%_50%_40%_40%] bg-[radial-gradient(circle_at_50%_70%,#fef08a,#f97316_55%,transparent_75%)] blur-[0.5px]" style={{ animationDelay: `${-side * 0.3}s` }} />
          <div className="h-10 w-2 rounded-b bg-gradient-to-b from-amber-700 to-amber-950" />
          <div className="absolute -top-4 h-16 w-16 rounded-full bg-orange-400/20 blur-xl" />
        </div>
      ))}
    </>
  );
}

function MultReel({ values, value, spinning, upgraded }) {
  return (
    <div className="flex w-[17%] flex-col items-center gap-1">
      <div className="text-[8px] font-extrabold uppercase tracking-wider text-amber-200/80">Multiplier</div>
      <div className="relative w-full flex-1 overflow-hidden rounded-lg bg-black/40 ring-2 ring-amber-400/70" style={{ aspectRatio: '1 / 3' }}>
        {spinning ? (
          <div className="p3-strip">{[...values, ...values, ...values, ...values].map((v, i) => <div key={i} className="aspect-square p-1 blur-[1px]"><svg viewBox="0 0 100 100">{MULT_STONE(v)}</svg></div>)}</div>
        ) : (
          <div className="p3-land-thud flex h-full flex-col justify-center">
            <div className={`aspect-square p-1 ${value > 1 ? 'p3-win' : ''}`} style={{ '--glow': '#fbbf24' }}><svg viewBox="0 0 100 100">{MULT_STONE(value)}</svg></div>
          </div>
        )}
        {upgraded && <div className="p3-stamp absolute inset-x-0 bottom-0 bg-amber-400 text-center text-[9px] font-extrabold text-amber-950">MIN x{upgraded}</div>}
      </div>
    </div>
  );
}

function PyramidDoors({ onDone, children }) {
  const done = useRef(onDone);
  done.current = onDone;
  useEffect(() => { const t = setTimeout(() => done.current(), 2000); return () => clearTimeout(t); }, []);
  return (
    <div className="pointer-events-none absolute inset-0 z-30 overflow-hidden rounded-2xl">
      <div className="absolute inset-0 bg-[radial-gradient(circle,#fde68a,#f59e0b_40%,#451a03_80%)]">{children}</div>
      <div className="p3-door-l absolute inset-y-0 left-0 w-1/2 border-r-4 border-amber-900 bg-[linear-gradient(90deg,#a47a4a,#d6a85b)] [background-image:repeating-linear-gradient(0deg,rgba(120,53,15,0.35)_0_2px,transparent_2px_26px)]"><div className="absolute right-3 top-1/2 h-10 w-3 -translate-y-1/2 rounded bg-amber-900" /></div>
      <div className="p3-door-r absolute inset-y-0 right-0 w-1/2 border-l-4 border-amber-900 bg-[linear-gradient(270deg,#a47a4a,#d6a85b)] [background-image:repeating-linear-gradient(0deg,rgba(120,53,15,0.35)_0_2px,transparent_2px_26px)]"><div className="absolute left-3 top-1/2 h-10 w-3 -translate-y-1/2 rounded bg-amber-900" /></div>
    </div>
  );
}

export default function Pharaoh() {
  const { user, view, history, play, commit, fx, guard, shake, doShake } = usePremium('pharaoh');
  const reels = useReelStops(5);
  const [grid, setGrid] = useState(START);
  const [res, setRes] = useState(null);
  const [lit, setLit] = useState(null);
  const [crumble, setCrumble] = useState(new Set());
  const [multSpin, setMultSpin] = useState(false);
  const [mult, setMult] = useState(1);
  const [stake, setStake] = useState(100);
  const [turbo, setTurbo] = useState(false);
  const [auto, setAuto] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [doors, setDoors] = useState(false);
  const [upgraded, setUpgraded] = useState(null);
  const free = view?.free;
  const level = free?.scarabs || 0;
  const reelVals = PH_MULT_REEL.filter(([v]) => v >= PH_LEVELS.filter((l) => level >= l.at).reduce((a, l) => Math.max(a, l.min), 1)).map(([v]) => v);

  const spin = () => guard(async () => {
    setSpinning(true); setRes(null); setLit(null); setCrumble(new Set()); setUpgraded(null); setSpinId((n) => n + 1); reels.start(); setMultSpin(true); fx.spin();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(); setMultSpin(false); setSpinning(false); setAuto(false); return; }
    setGrid(out.landed);
    let seen = 0;
    const tease = [];
    out.landed.forEach((c, i) => { if (seen >= 2) tease.push(i); if (c.some((x) => x.s === 'SCARAB')) seen++; });
    await reels.stopAll({ turbo, tease, base: 600, gap: 220, onStop: (i) => { fx.stop(i); if (out.landed[i].some((x) => x.s === 'SCARAB')) fx.land(); } });
    if (out.mystery.length) {
      setCrumble(new Set(out.mystery.map(([r, c]) => `${r}-${c}`))); fx.special(); doShake(false);
      await sleep(turbo ? 300 : 600);
      setCrumble(new Set());
    }
    setGrid(out.grid);
    await sleep(turbo ? 120 : 300);
    setMultSpin(false); setMult(out.mult); fx.stop(5);
    if (out.mult > 1 && out.lineWin) fx.special();
    setLit(new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`))));
    if (out.trigger?.upgraded) setUpgraded(out.trigger.upgraded);
    setRes(out); setSpinning(false); commit();
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); } else if (tier) { fx.win(tier); if (tier === 2) doShake(false); }
    if (out.trigger?.freeSpins) { fx.bonus(); setDoors(true); }
    if (out.finished) setBig({ amount: out.finished.total, title: 'GOLDEN SCARAB TREASURE' });
    if (!out.free) setAuto(false);
  });
  useEffect(() => {
    if (!auto || !free || spinning || big || intro || doors) return undefined;
    const t = setTimeout(spin, 900);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro, doors]); // eslint-disable-line react-hooks/exhaustive-deps

  const pt = Object.entries(PH_PAY).map(([s, v]) => [s, v.map((x) => x * PH_S)]);
  const detail = res && [res.wins.length && `${res.wins.length} line win${res.wins.length > 1 ? 's' : ''}`, res.mult > 1 && res.lineWin && `x${res.mult} multiplier`, res.wins.some((w) => w.doubled) && 'Pharaoh doubled', res.reveal && `Mystery: ${res.reveal.toLowerCase()}`].filter(Boolean).join(' · ');
  return (
    <PremiumShell game="pharaoh" rtp="96%" tagline="5 reels · 10 lines · Ancient Multiplier reel · mystery stacks" shake={shake}
      stageClass="border-[3px] border-amber-500/80 shadow-[0_0_40px_rgba(245,158,11,0.3)]" bg={<Temple />}
      below={<SpinBar stake={stake} setStake={setStake} onSpin={spin} spinning={spinning} free={free} disabled={!!intro || doors} balance={user?.balance} turbo={turbo} setTurbo={setTurbo} auto={auto} setAuto={setAuto} accent="bg-gradient-to-b from-amber-300 to-amber-600 text-amber-950" />}
      side={<>
        <SidePanel title="Features">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-amber-300">Pharaoh Wild</b> doubles every win it completes.</li>
            <li><b className="text-amber-300">Ancient Multiplier</b> reel multiplies line wins.</li>
            <li><b className="text-teal-300">Mystery stacks</b> all reveal the same symbol.</li>
            <li><b className="text-teal-300">3+ scarabs</b>: Golden Scarab free spins.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Recent spins"><RecentList history={history} /></SidePanel>
      </>}
      info={<>
        <section><h3 className="mb-2 font-bold text-white">Paytable (multiples of total stake)</h3><Paytable game="pharaoh" rows={pt} /></section>
        <section className="space-y-2">
          <h3 className="font-bold text-white">Features</h3>
          <p><b className="text-amber-300">Pharaoh Wild</b> lands on reels 2–5, substitutes for every symbol except the scarab, and doubles any line win it completes. Wins pay left to right on 10 lines.</p>
          <p><b className="text-amber-300">Ancient Multiplier reel</b> spins with every spin and multiplies the total line win: {PH_MULT_REEL.map(([v, w]) => `x${v} (${w}%)`).join(', ')}.</p>
          <p><b className="text-teal-300">Pyramid mystery stacks</b>: about {Math.round(PH_MYSTERY_P * 100)}% of the time per reel, a stack of 2–3 stone blocks lands. They crumble to reveal one symbol, the same for every block on screen (possibly the Pharaoh Wild).</p>
          <p><b className="text-teal-300">Golden Scarab free spins</b>: 3, 4 or 5 scarabs pay 2x, 10x or 50x and give 10 free spins. Every scarab that lands during them adds a spin, and collecting 3, 6 and 9 scarabs raises the multiplier reel's lowest value to x2, x3 and x5.</p>
        </section>
        <section className="rounded-lg bg-navy-800 p-3 text-xs"><b className="text-white">Maths</b>: long-run return 96% · wins on about {STATS3.pharaoh.hit} of spins · {STATS3.pharaoh.feature} · maximum win 5,000x per spin · results come from a cryptographic random number generator before the reels animate.</section>
      </>}>
      <div className="relative pt-4">
        {free && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="rounded-md bg-teal-400 px-2.5 py-1 text-xs font-extrabold uppercase text-teal-950">Golden Scarab · {free.remaining} left</div>
            <div className="flex items-center gap-1 rounded-md bg-black/50 px-2 py-1">
              {Array.from({ length: 9 }, (_, i) => <span key={i} className={`h-2.5 w-2.5 rounded-full ${i < level ? 'bg-amber-300 shadow-[0_0_6px_#fbbf24]' : 'bg-white/15'} ${(i + 1) % 3 === 0 ? 'mr-1' : ''}`} />)}
            </div>
          </div>
        )}
        <div className="flex items-stretch gap-1.5 rounded-xl bg-[linear-gradient(180deg,#d6a85b,#78350f)] p-1.5 shadow-[inset_0_2px_0_rgba(255,255,255,0.3)]">
          <div className="min-w-0 flex-1 rounded-lg bg-[#2a1405] p-1">
            <PremiumReels game="pharaoh" grid={grid} stopped={reels.stopped} lit={lit} turbo={turbo} spinId={spinId} landing="thud"
              cellExtra={(r, row) => (crumble.has(`${r}-${row}`) ? <div className="p3-crumble absolute inset-0.5"><Sym3 game="pharaoh" s="MYSTERY" /></div> : null)} />
          </div>
          <MultReel values={reelVals} value={mult} spinning={multSpin} upgraded={upgraded} />
        </div>
        <div className="mt-2"><WinLine res={res} spinning={spinning} detail={detail} busyText="The stones grind…" /></div>
        {doors && <PyramidDoors onDone={() => { setDoors(false); setIntro(10); }}><Burst game="pharaoh" n={20} spread={150} /></PyramidDoors>}
        {intro && (
          <FeatureIntro title="GOLDEN SCARAB" subtitle={`${intro} free spins. Every scarab adds a spin, and every third one raises the lowest multiplier.`}
            art={<div className="mb-2 h-24 w-24"><Sym3 game="pharaoh" s="SCARAB" /></div>} className="bg-[radial-gradient(circle,rgba(180,83,9,0.9),rgba(28,10,2,0.95))]" onStart={() => { setIntro(null); setAuto(true); }} />
        )}
        {big && <BigWin game="pharaoh" amount={big.amount} bet={res?.bet || stake} title={big.title} onDone={() => setBig(null)}
          cinematic={<PyramidDoors onDone={() => {}}><div className="absolute inset-0 bg-[radial-gradient(circle,rgba(253,230,138,0.6),transparent_70%)]" /></PyramidDoors>} />}
      </div>
    </PremiumShell>
  );
}
