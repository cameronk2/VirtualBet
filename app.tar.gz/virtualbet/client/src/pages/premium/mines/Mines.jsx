// Gem Mines – game screen. The board is shuffled and kept on the server;
// each tap asks the server what is under that one tile. This screen only
// animates the answer. States: idle → run (gems…) → cashed | mine (lost).
import { lockScroll } from '../../../lib/scrollLock.js';
import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Burst, PremiumShell, SidePanel, SoundMenu, usePremium, sleep } from '../../../components/Premium.jsx';
import { Modal } from '../../../components/ui.jsx';
import { Gem, Mine } from '../../../components/SlotArtMines.jsx';
import { useApp } from '../../../state/AppContext.jsx';
import { minesSfx } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { MAX_MINES, MIN_MINES, RTP, TILES, multiplier, survival } from '../../../../../server/games/mines/config.js';

const QUICK = [1, 3, 5, 10, 24];
const pref = (k, d) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } };
const fmtX = (m) => (m >= 10000 ? `${Math.floor(m).toLocaleString()}x` : `${m.toFixed(2)}x`);
const pct = (p) => (p >= 0.1 ? `${(p * 100).toFixed(1)}%` : p >= 0.001 ? `${(p * 100).toFixed(3)}%` : `${(p * 100).toExponential(1)}%`);
const when = (t) => new Date(t).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const multCls = (m) => (m >= 100 ? 'bg-gradient-to-r from-amber-200 via-fuchsia-300 to-sky-300 bg-clip-text text-transparent' : m >= 10 ? 'text-amber-200' : m >= 2 ? 'text-sky-200' : 'text-white');

function useCount(value, ms = 380) {
  const [shown, setShown] = useState(value);
  const from = useRef(value);
  useEffect(() => {
    const t0 = performance.now(), a = from.current, b = value;
    let id;
    const step = (now) => { const k = Math.min(1, (now - t0) / ms), e = 1 - (1 - k) ** 3; setShown(a + (b - a) * e); if (k < 1) id = requestAnimationFrame(step); else from.current = b; };
    id = requestAnimationFrame(step);
    return () => { cancelAnimationFrame(id); from.current = b; };
  }, [value, ms]);
  return shown;
}

function Tile({ i, state, playable, pending, onPick, onHover, delay, boom }) {
  // state: null (closed) | 'gem' (picked) | 'mine-hit' | 'gem-rest' | 'mine-rest'
  const open = !!state;
  const isMine = state === 'mine-hit' || state === 'mine-rest';
  const rest = state === 'gem-rest' || state === 'mine-rest';
  return (
    <button type="button" disabled={!playable || open || pending} onClick={() => onPick(i)} onMouseEnter={playable && !open ? onHover : undefined}
      aria-label={open ? `Tile ${i + 1}: ${isMine ? 'mine' : 'gem'}` : `Tile ${i + 1}, hidden`}
      className={`mn-tile group relative aspect-square ${playable && !open ? 'cursor-pointer' : 'cursor-default'}`}>
      <div className={`mn-flip ${open ? 'open' : ''}`} style={{ transitionDelay: open && rest ? `${delay}ms` : '0ms' }}>
        <div className={`mn-face flex items-center justify-center bg-[linear-gradient(160deg,#4a4f9a,#262859_55%,#17183a)] ring-1 ring-indigo-300/25 ${playable ? 'mn-closed transition-transform duration-150 group-hover:-translate-y-0.5 group-hover:brightness-125 group-active:translate-y-0' : ''} ${pending ? 'animate-pulse brightness-150' : ''}`}>
          <div className="h-[22%] w-[22%] rotate-45 rounded-[3px] bg-indigo-200/15 ring-1 ring-indigo-200/20" />
        </div>
        <div className={`mn-face mn-back flex items-center justify-center ${isMine ? (state === 'mine-hit' ? 'bg-[radial-gradient(circle,#7f1d1d,#2a0a0a)] ring-2 ring-red-400' : 'bg-[radial-gradient(circle,#2a1530,#120a1a)] ring-1 ring-red-400/30') : (state === 'gem' ? 'bg-[radial-gradient(circle,#1e3a8a,#0f1029)] ring-2 ring-sky-300/70 shadow-[0_0_18px_rgba(56,189,248,0.45)]' : 'bg-[radial-gradient(circle,#1e2752,#0f1029)] ring-1 ring-sky-300/20')} ${rest ? 'mn-faded' : ''}`}>
          <svg viewBox="0 0 100 100" className={`h-[86%] w-[86%] ${state === 'gem' ? 'mn-gemin' : ''}`} aria-hidden="true">
            <g className={state === 'gem' ? 'mn-float' : ''}>{isMine ? <Mine lit={state === 'mine-hit'} /> : <Gem glow={state === 'gem'} />}</g>
          </svg>
        </div>
      </div>
      {state === 'gem' && <Burst key={`g${i}`} game="mines" n={8} spread={40} />}
      {boom && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <div className="mn-boom absolute h-full w-full rounded-full bg-[radial-gradient(circle,#fffbeb_0%,#fde047_25%,#f97316_50%,rgba(220,38,38,0)_70%)]" />
          <div className="mn-ring absolute h-full w-full rounded-full border-orange-300" style={{ borderStyle: 'solid' }} />
          <Burst game="chicken" n={18} spread={90} />
        </div>
      )}
    </button>
  );
}

function MiniBoard({ r }) {
  return (
    <div className="mx-auto grid w-full max-w-[260px] grid-cols-5 gap-1">
      {r.board.map((b, i) => {
        const picked = r.picks.includes(i), hit = r.hit === i;
        return (
          <div key={i} className={`relative aspect-square rounded-md ${hit ? 'bg-red-800 ring-2 ring-red-400' : picked ? 'bg-sky-900 ring-2 ring-sky-300' : 'bg-indigo-950/80 ring-1 ring-indigo-300/20'}`}>
            <svg viewBox="0 0 100 100" className={`h-full w-full p-[8%] ${!picked && !hit ? 'opacity-45' : ''}`} aria-label={b ? 'mine' : 'gem'}>{b ? <Mine lit={hit} /> : <Gem glow={picked} />}</svg>
            {picked && <span className="absolute left-0.5 top-0 text-[8px] font-bold text-sky-100">{r.picks.indexOf(i) + 1}</span>}
          </div>
        );
      })}
    </div>
  );
}

export default function Mines() {
  const { config } = useApp();
  const { user, view, play, commit, guard, shake, doShake } = usePremium('mines');
  const fx = useMemo(() => minesSfx(), []);
  const rules = config?.rules || { minStake: 10, maxStake: 50000 };
  const [mines, setMines] = useState(() => { const v = parseInt(pref('mn_mines', '3'), 10); return v >= MIN_MINES && v <= MAX_MINES ? v : 3; });
  const [stake, setStake] = useState(() => { const v = parseInt(pref('mn_bet', '100'), 10); return Number.isSafeInteger(v) && v > 0 ? v : 100; });
  const [betText, setBetText] = useState(() => (stake / 100).toFixed(2));
  const [phase, setPhase] = useState('idle');         // idle | starting | run | cashed | lost
  const [round, setRound] = useState(null);           // { bet, mines, picks }
  const [board, setBoard] = useState(null);           // revealed after the round
  const [hit, setHit] = useState(null);
  const [pending, setPending] = useState(null);
  const [result, setResult] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [gridShake, setGridShake] = useState(0);
  const [viewing, setViewing] = useState(null);
  const lastHover = useRef(0);
  const roundId = useRef(0);
  // Full-screen ("pop-out") play: on by default on phones, remembered per device
  const [pop, setPop] = useState(true); // every game opens full screen; ✕ leaves it for this visit
  const [histOpen, setHistOpen] = useState(false);
  const togglePop = (v) => { setPop(v); fx.click(); };
  useEffect(() => {
    if (!pop) return undefined;
    return lockScroll();
  }, [pop]);
  // the board is sized to the space left in the pop-out (square, as large as fits)
  const boxRef = useRef(null);
  const [boxSize, setBoxSize] = useState(300);
  useEffect(() => {
    const el = boxRef.current; if (!el) return undefined;
    const ro = new ResizeObserver(() => setBoxSize(Math.floor(Math.min(el.clientWidth, el.clientHeight))));
    ro.observe(el); return () => ro.disconnect();
  }, [pop]);

  const balance = user?.balance ?? 0;
  const live = phase === 'run' || phase === 'starting';
  const m = round?.mines ?? mines;
  const gems = round?.picks.length ?? 0;
  const mult = gems ? multiplier(m, gems) : 0;
  const nextMult = gems < TILES - m ? multiplier(m, gems + 1) : null;
  const nextChance = gems < TILES - m ? (TILES - m - gems) / (TILES - gems) : 0;
  const shownMult = useCount(mult || 1);
  const bet = round?.bet ?? stake;
  const cashValue = Math.floor(bet * mult);

  // Restore a round left in play
  const restored = useRef(false);
  useEffect(() => {
    if (!view || restored.current) return;
    restored.current = true;
    if (view.mode === 'run' && view.round) { const r = view.round; setRound({ bet: r.bet, mines: r.mines, picks: r.picks }); setMines(r.mines); setPhase('run'); }
  }, [view]);

  const setBet = (v) => { const c = Math.max(rules.minStake, Math.min(rules.maxStake, Math.round(v))); setStake(c); setBetText((c / 100).toFixed(2)); save('mn_bet', String(c)); };
  const pickMines = (v) => { const c = Math.max(MIN_MINES, Math.min(MAX_MINES, v)); setMines(c); save('mn_mines', String(c)); fx.click(); };
  const clear = () => { setRound(null); setBoard(null); setHit(null); setResult(null); setShowResult(false); setPhase('idle'); };

  const start = () => guard(async () => {
    if (live || stake > balance) return;
    roundId.current++;
    clear(); fx.click();
    setPhase('starting');
    const out = await play('start', { stake, mines });
    if (!out) { setPhase('idle'); return; }
    commit();
    setRound({ bet: stake, mines, picks: [] });
    setPhase('run');
  });

  const reveal = (tile) => guard(async () => {
    if (phase !== 'run' || !round || round.picks.includes(tile)) return;
    setPending(tile); fx.pick();
    const out = await play('reveal', { tile });
    setPending(null);
    if (!out) return;
    if (out.gem) {
      setRound((r) => ({ ...r, picks: [...r.picks, tile] }));
      fx.gem(out.gems); fx.mult(out.gems);
      if (out.mult >= 10 && out.gems > 1 && multiplier(m, out.gems - 1) < 10) doShake(false);
      if (out.cleared) {
        await sleep(450);
        commit(); setBoard(out.board); fx.cashout();
        setResult({ type: 'win', bet: out.bet, gems: out.gems, mines: m, mult: out.mult, payout: out.win, all: true });
        setPhase('cashed'); setShowResult(true);
      }
    } else if (out.mine) {
      setHit(tile); setBoard(out.board);
      fx.explode(); doShake(true); setGridShake((n) => n + 1);
      setPhase('lost');
      out.board.forEach((_, i) => setTimeout(() => fx.revealAll(i), 300 + i * 18));
      fx.gameover();
      commit();
      // show the result after the explosion, without holding up the next Play
      const id = ++roundId.current;
      setTimeout(() => { if (roundId.current === id) { setResult({ type: 'lost', bet: round.bet, gems: out.gems, mines: m, reached: out.reached }); setShowResult(true); } }, 900);
    }
  });

  const cashout = () => guard(async () => {
    if (phase !== 'run' || !gems) return;
    const out = await play('cashout', {});
    if (!out) return;
    commit(); setBoard(out.board); fx.cashout();
    setResult({ type: 'win', bet: out.bet, gems: out.gems, mines: out.mines, mult: out.mult, payout: out.win });
    setPhase('cashed'); setShowResult(true);
  });

  const randomPick = () => {
    if (phase !== 'run' || !round) return;
    const free = Array.from({ length: TILES }, (_, i) => i).filter((i) => !round.picks.includes(i));
    reveal(free[Math.floor(Math.random() * free.length)]);
  };

  // Keyboard: Enter = play / cash out, R = random tile
  const keys = useRef({}); keys.current = { start, cashout, randomPick, phase, gems };
  useEffect(() => {
    const h = (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(e.target.tagName) || e.repeat) return;
      const k = keys.current;
      if (e.code === 'Enter') { e.preventDefault(); if (k.phase === 'run' && k.gems) k.cashout(); else if (k.phase !== 'run' && k.phase !== 'starting') k.start(); }
      else if (e.code === 'KeyR' && k.phase === 'run') k.randomPick();
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, []);

  const tileState = (i) => {
    if (round?.picks.includes(i)) return 'gem';
    if (!board) return null;
    if (hit === i) return 'mine-hit';
    return board[i] ? 'mine-rest' : 'gem-rest';
  };
  const restOrder = useMemo(() => { const o = {}; let n = 0; for (let i = 0; i < TILES; i++) if (board && !round?.picks.includes(i) && hit !== i) o[i] = n++; return o; }, [board, round, hit]);

  const stageEl = (c) => (
    <div className={c ? 'relative flex min-h-0 flex-1 flex-col' : 'relative'}>
      {/* drifting motes */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {Array.from({ length: 10 }, (_, i) => <span key={i} className="mn-mote absolute bottom-0 h-1 w-1 rounded-full bg-indigo-200/60" style={{ left: `${(i * 37) % 100}%`, animationDuration: `${6 + (i % 4) * 2}s`, animationDelay: `${-i * 1.3}s` }} />)}
      </div>
      {/* HUD */}
      <div className={`relative grid grid-cols-3 gap-1.5 text-center ${c ? 'mb-1.5' : 'mb-2'}`}>
        <div className={`rounded-xl bg-black/40 px-2 ring-1 ring-indigo-300/20 ${c ? 'py-1' : 'py-1.5'}`}>
          <div className="text-[10px] font-semibold uppercase tracking-[.15em] text-indigo-200/70">Multiplier</div>
          <div key={gems} className={`font-display text-2xl leading-none tabular-nums sm:text-3xl ${gems ? 'ck-multpop' : ''} ${phase === 'lost' ? 'text-red-400' : multCls(shownMult)}`}>{phase === 'lost' ? 'BUST' : gems ? fmtX(shownMult) : '—'}</div>
        </div>
        <div className={`rounded-xl bg-black/40 px-2 ring-1 ring-indigo-300/20 ${c ? 'py-1' : 'py-1.5'}`}>
          <div className="text-[10px] font-semibold uppercase tracking-[.15em] text-indigo-200/70">Next gem</div>
          <div className="font-display text-2xl leading-none tabular-nums text-sky-200 sm:text-3xl">{nextMult && phase !== 'lost' && phase !== 'cashed' ? fmtX(nextMult) : '—'}</div>
          <div className="text-[10px] text-indigo-200/70">{phase === 'run' && nextMult ? `${(nextChance * 100).toFixed(1)}% safe` : `${m} mine${m > 1 ? 's' : ''}`}</div>
        </div>
        <div className={`rounded-xl px-2 ring-1 ${c ? 'py-1' : 'py-1.5'} ${gems && phase === 'run' ? 'bg-amber-400/15 ring-amber-300/60' : phase === 'lost' ? 'bg-red-500/15 ring-red-400/50' : 'bg-black/40 ring-indigo-300/20'}`}>
          <div className="text-[10px] font-semibold uppercase tracking-[.15em] text-amber-200/80">{phase === 'lost' ? 'Lost' : phase === 'cashed' ? 'Won' : 'Cash out'}</div>
          <div className={`font-cond text-2xl font-extrabold leading-none tabular-nums sm:text-3xl ${phase === 'lost' ? 'text-red-300' : 'text-amber-100'}`}>{phase === 'lost' ? `−${money(bet)}` : gems ? money(cashValue) : money(0)}</div>
          <div className="text-[10px] text-indigo-200/70">{gems} gem{gems === 1 ? '' : 's'} found</div>
        </div>
      </div>
      {/* the board */}
      <div ref={c ? boxRef : undefined} className={c ? 'relative flex min-h-0 flex-1 items-center justify-center' : 'contents'}>
      <div className={c ? 'relative' : 'relative mx-auto w-full max-w-[min(100%,calc(100dvh_-_400px),520px)] min-w-[260px]'} style={c ? { width: boxSize, height: boxSize } : undefined}>
        <div key={gridShake} className={`grid grid-cols-5 gap-1.5 rounded-2xl bg-[linear-gradient(160deg,rgba(99,102,241,0.25),rgba(15,16,41,0.85))] p-2 ring-1 ring-indigo-300/30 shadow-[0_0_40px_rgba(99,102,241,0.25),inset_0_0_30px_rgba(0,0,0,0.6)] sm:gap-2 sm:p-3 ${gridShake ? 'mn-shake' : ''}`}>
          {Array.from({ length: TILES }, (_, i) => (
            <Tile key={i} i={i} state={tileState(i)} playable={phase === 'run'} pending={pending === i} onPick={reveal} boom={hit === i}
              onHover={() => { const now = performance.now(); if (now - lastHover.current > 90) { lastHover.current = now; fx.hover(); } }} delay={260 + (restOrder[i] ?? 0) * 28} />
          ))}
        </div>
        {phase === 'idle' && !board && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="rounded-xl bg-black/60 px-4 py-2 text-center text-sm font-semibold text-indigo-100 ring-1 ring-indigo-300/30 backdrop-blur-sm">Choose your mines and bet, then press Play</div>
          </div>
        )}
        {/* result screens */}
        {result && showResult && (
          <div className="absolute inset-0 z-30 flex items-center justify-center p-2">
            <div className={`p3-intro-pop relative w-full max-w-[300px] overflow-hidden rounded-2xl p-4 text-center shadow-2xl ring-2 backdrop-blur-md ${result.type === 'win' ? 'bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,0.95),rgba(15,16,41,0.96))] ring-amber-300/80' : 'bg-[radial-gradient(ellipse_at_top,rgba(153,27,27,0.95),rgba(20,6,10,0.96))] ring-red-400/70'}`}>
              {result.type === 'win' ? (
                <>
                  <div className="pointer-events-none absolute left-1/2 top-10"><Burst game="mines" n={36} spread={150} /></div>
                  <svg viewBox="0 0 100 100" className="mx-auto -mb-1 h-14 w-14" aria-hidden="true"><g className="mn-float"><Gem /></g></svg>
                  <div className="font-display text-xl tracking-wider text-amber-200">{result.all ? 'BOARD CLEARED!' : 'CASHED OUT'}</div>
                  <div className="my-1 font-cond text-4xl font-extrabold tabular-nums text-white drop-shadow-[0_0_14px_rgba(253,224,71,0.6)]">{money(result.payout)}</div>
                  <dl className="grid grid-cols-3 gap-1 text-[11px] text-indigo-100">
                    {[['Bet', money(result.bet)], ['Gems', result.gems], ['Mines', result.mines], ['Multiplier', fmtX(result.mult)], ['Payout', money(result.payout)], ['Profit', `+${money(result.payout - result.bet)}`]].map(([k, v]) => (
                      <div key={k} className="rounded-lg bg-black/30 px-1 py-1"><dt className="text-[9px] uppercase tracking-wider text-indigo-200/70">{k}</dt><dd className="font-cond text-sm font-bold tabular-nums text-white">{v}</dd></div>
                    ))}
                  </dl>
                </>
              ) : (
                <>
                  <svg viewBox="0 0 100 100" className="mx-auto -mb-1 h-14 w-14" aria-hidden="true"><Mine /></svg>
                  <div className="font-display text-2xl tracking-wider text-red-200">BOOM!</div>
                  <p className="mt-1 text-sm text-red-100">You hit a mine after {result.gems} gem{result.gems === 1 ? '' : 's'}.</p>
                  <dl className="mt-2 grid grid-cols-2 gap-1 text-[11px]">
                    <div className="rounded-lg bg-black/30 py-1"><dt className="text-[9px] uppercase tracking-wider text-red-200/70">Bet</dt><dd className="font-cond text-sm font-bold text-white">{money(result.bet)}</dd></div>
                    <div className="rounded-lg bg-black/30 py-1"><dt className="text-[9px] uppercase tracking-wider text-red-200/70">Lost</dt><dd className="font-cond text-sm font-bold text-red-200">−{money(result.bet)}</dd></div>
                  </dl>
                  {result.reached > 0 && <p className="mt-1 text-[11px] text-red-100/80">You could have cashed out at {fmtX(result.reached)}.</p>}
                </>
              )}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setShowResult(false)} className="rounded-full bg-white/15 py-2 text-sm font-bold text-white ring-1 ring-white/25">See board</button>
                <button type="button" onClick={start} disabled={stake > balance} className="rounded-full bg-gradient-to-b from-amber-200 to-amber-500 py-2 text-sm font-extrabold text-amber-950 disabled:opacity-50">Play again</button>
              </div>
            </div>
          </div>
        )}
      </div>
      </div>
    </div>
  );

  const canStart = !live && stake <= balance;
  const barEl = (c) => (
    <div className={c ? 'card shrink-0 space-y-1.5 p-2' : 'card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none'}>
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-xs font-semibold text-slate-400">Mines</span>
        <div className="flex items-center rounded-lg bg-navy-800 ring-1 ring-navy-600">
          <button className="h-9 w-8 text-lg text-slate-200 disabled:opacity-40" disabled={live || mines <= MIN_MINES} onClick={() => pickMines(mines - 1)} aria-label="Fewer mines">−</button>
          <select aria-label="Number of mines" value={live ? m : mines} disabled={live} onChange={(e) => pickMines(parseInt(e.target.value, 10))} className="h-9 appearance-none bg-transparent px-1 text-center font-cond text-lg font-bold text-white outline-none">
            {Array.from({ length: MAX_MINES }, (_, i) => <option key={i} value={i + 1} className="bg-navy-900">{i + 1}</option>)}
          </select>
          <button className="h-9 w-8 text-lg text-slate-200 disabled:opacity-40" disabled={live || mines >= MAX_MINES} onClick={() => pickMines(mines + 1)} aria-label="More mines">+</button>
        </div>
        {QUICK.map((q) => <button key={q} disabled={live} onClick={() => pickMines(q)} className={`rounded-md px-2 py-1.5 text-xs font-bold ${(live ? m : mines) === q ? 'bg-indigo-500 text-white' : 'bg-navy-700 text-slate-300'} disabled:opacity-50`}>{q}</button>)}
        <span className={`ml-auto text-[11px] text-slate-400 ${c ? 'hidden' : ''}`}>1st gem <b className="text-sky-200">{fmtX(multiplier(live ? m : mines, 1))}</b> · {Math.round(((TILES - (live ? m : mines)) / TILES) * 100)}% safe</span>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <div className="flex items-center rounded-lg bg-navy-800 ring-1 ring-navy-600">
          <button className="h-10 w-9 text-lg text-slate-200 disabled:opacity-40" disabled={live} onClick={() => setBet(stake - (stake > 1000 ? 100 : 10))} aria-label="Lower bet">−</button>
          <label className="flex items-center gap-0.5 text-sm font-bold text-white">£
            <input inputMode="decimal" aria-label="Bet amount" className="w-16 bg-transparent py-2 text-center font-cond text-lg font-bold tabular-nums outline-none" value={live ? (bet / 100).toFixed(2) : betText} disabled={live}
              onChange={(e) => setBetText(e.target.value.replace(/[^\d.]/g, ''))} onBlur={() => { const v = Math.round(parseFloat(betText || '0') * 100); setBet(Number.isFinite(v) ? v : stake); }}
              onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }} />
          </label>
          <button className="h-10 w-9 text-lg text-slate-200 disabled:opacity-40" disabled={live} onClick={() => setBet(stake + (stake >= 1000 ? 100 : 10))} aria-label="Raise bet">+</button>
        </div>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={live} onClick={() => setBet(stake / 2)}>½</button>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={live} onClick={() => setBet(stake * 2)}>2×</button>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={live} onClick={() => setBet(Math.min(rules.maxStake, Math.max(rules.minStake, balance)))}>Max</button>
        <div className={`ml-auto text-right text-[11px] leading-tight text-slate-400 ${c ? 'hidden' : ''}`}>Balance<div className="font-cond text-base font-bold tabular-nums text-white">{money(balance)}</div></div>
      </div>
      {phase === 'run' ? (
        <div className="grid grid-cols-[auto_1fr] gap-2">
          <button onClick={randomPick} disabled={pending != null} className={`${c ? 'h-12' : 'h-14'} rounded-full bg-navy-700 px-4 text-sm font-bold text-slate-100 ring-1 ring-indigo-300/30 active:scale-95`} title="Reveal a random tile (R)">Random</button>
          <button onClick={cashout} disabled={!gems || pending != null} className={`btn ${c ? 'h-12' : 'h-14'} rounded-full text-lg font-extrabold leading-tight shadow-lg active:scale-95 ${gems ? 'mn-cashpulse bg-gradient-to-b from-amber-200 to-amber-500 text-amber-950 ring-2 ring-amber-100/70' : 'bg-navy-700 text-slate-400'}`}>
            {gems ? <span className="flex flex-col items-center leading-tight"><span>Cash out <span className="tabular-nums">{money(cashValue)}</span></span><span className="text-xs font-bold opacity-80">{fmtX(mult)} · {gems} gem{gems === 1 ? '' : 's'}</span></span> : <span className="text-sm">Find a gem to cash out</span>}
          </button>
        </div>
      ) : (
        <button onClick={start} disabled={!canStart} className={`btn ${c ? 'h-12' : 'h-14'} w-full rounded-full bg-gradient-to-b from-violet-400 to-indigo-700 text-lg font-extrabold text-white shadow-[0_0_24px_rgba(129,140,248,0.45)] active:scale-95`}>
          {phase === 'starting' ? 'Starting…' : stake > balance ? 'Not enough balance' : `Play · ${money(stake)}`}
        </button>
      )}
    </div>
  );

  const recent = view?.recent || [];
  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to play</h3>
        <ol className="list-decimal space-y-1 pl-5">
          <li>Choose how many mines (1–24) are hidden among the 25 tiles, and your bet. Press <b>Play</b>: the bet is taken and the board is shuffled on the server.</li>
          <li>Tap tiles. Every gem raises the multiplier. <b>Random</b> (or R) picks a tile for you.</li>
          <li><b>Cash out</b> any time after your first gem to win bet × multiplier. Find every gem and you're paid automatically.</li>
          <li>Reveal a mine and the round ends: the bet is lost and the whole board is shown.</li>
        </ol>
        <p className="text-xs">The mine count and bet are locked once the round starts. Closing or refreshing the page keeps the same board and your gems found so far.</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How the multiplier is worked out</h3>
        <p className="text-xs">With M mines, the chance of k safe picks in a row is P = (25−M)/25 × (24−M)/24 × … for k picks. The fair multiplier is 1 ÷ P; the paid multiplier is {Math.round(RTP * 100)}% of that, rounded down to 2 decimals. So cashing out after any number of gems returns {Math.round(RTP * 100)}% on average.</p>
        <details className="rounded-lg bg-navy-800 p-2" open>
          <summary className="cursor-pointer text-sm font-bold text-white">Table for {live ? m : mines} mine{(live ? m : mines) > 1 ? 's' : ''}</summary>
          <div className="mt-2 max-h-60 overflow-auto">
            <table className="w-full text-right text-[11px] tabular-nums">
              <thead className="sticky top-0 bg-navy-800 text-slate-400"><tr><th className="text-left">Gems</th><th>Chance to get here</th><th>Multiplier</th><th>Pays at {money(bet)}</th></tr></thead>
              <tbody>{Array.from({ length: TILES - (live ? m : mines) }, (_, i) => { const mm = live ? m : mines; return <tr key={i} className={`border-t border-navy-700 ${i + 1 === gems ? 'bg-amber-400/10 text-amber-100' : ''}`}><td className="text-left">{i + 1}</td><td>{pct(survival(mm, i + 1))}</td><td className="text-white">{fmtX(multiplier(mm, i + 1))}</td><td>{money(Math.floor(bet * multiplier(mm, i + 1)))}</td></tr>; })}</tbody>
            </table>
          </div>
        </details>
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Fairness</b>: mines are placed with a cryptographically secure shuffle when you press Play. The board stays on the server until the round ends; your browser only ever learns what's under the tiles you pick. Bets from {money(rules.minStake)} to {money(rules.maxStake)}.
      </section>
    </>
  );

  const historyPanel = (
        <SidePanel title="Recent games">
      {recent.length ? (
        <ul className="max-h-[440px] space-y-1 overflow-auto text-[11px]">
          {recent.map((r, k) => (
            <li key={k}>
              <button type="button" onClick={() => setViewing(r)} className={`w-full rounded-md border-l-4 px-2 py-1 text-left hover:brightness-125 ${r.result === 'mine' ? 'border-red-500 bg-red-500/10' : 'border-emerald-400 bg-emerald-500/10'}`}>
                <div className="flex justify-between gap-2"><span className="font-semibold text-white">{money(r.bet)} · {r.mines} mine{r.mines > 1 ? 's' : ''}</span><b className={r.result === 'mine' ? 'text-red-300' : 'text-emerald-300'}>{r.result === 'mine' ? `−${money(r.bet)}` : `+${money(r.payout)}`}</b></div>
                <div className="flex justify-between gap-2 text-slate-400"><span>{r.gems} gem{r.gems === 1 ? '' : 's'} · {r.result === 'mine' ? 'Mine' : fmtX(r.mult)}</span><span>{when(r.at)}</span></div>
              </button>
            </li>
          ))}
        </ul>
      ) : <div className="text-xs text-slate-500">No games yet.</div>}
    </SidePanel>
  );

  return (
    <PremiumShell game="mines" popout={false} rtp={`${Math.round(RTP * 100)}%`} tagline="5 × 5 · 1–24 mines · cash out any time" shake={shake}
      stageClass="border-2 border-indigo-400/40 shadow-[0_0_60px_rgba(99,102,241,0.25)]"
      bg={<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#312e81_0%,#1e1b4b_35%,#0b0b1e_80%)]"><div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_90%,rgba(234,179,8,0.12),transparent_45%)]" /></div>}
      below={<>{!pop && barEl(false)}<div className="mt-3 lg:hidden">{historyPanel}</div></>} info={info}
      side={<>
        {historyPanel}
      </>}>
      {pop ? (
        <div className="flex flex-col items-center gap-3 py-10 text-center">
          <p className="text-sm text-indigo-100">Gem Mines is open in full screen.</p>
          <button type="button" onClick={() => togglePop(true)} className="rounded-full bg-gradient-to-b from-violet-400 to-indigo-700 px-6 py-3 font-extrabold text-white">Return to the game</button>
        </div>
      ) : (
        <div className="pt-1">
          <div className="mb-1.5 flex justify-end"><button type="button" onClick={() => togglePop(true)} className="rounded-md bg-black/40 px-2.5 py-1 text-xs font-semibold text-indigo-100 ring-1 ring-indigo-300/30 hover:bg-black/60" aria-label="Play full screen">⤢ Full screen</button></div>
          {stageEl(false)}
        </div>
      )}
      {pop && createPortal(
        <div className={`fixed inset-0 z-[45] flex flex-col bg-[radial-gradient(ellipse_at_top,#312e81_0%,#1e1b4b_35%,#0b0b1e_80%)] px-2 ${shake}`} role="dialog" aria-label="Gem Mines full screen"
          style={{ paddingTop: 'max(8px, env(safe-area-inset-top))', paddingBottom: 'max(8px, env(safe-area-inset-bottom))', height: '100dvh' }}>
          <div className="mx-auto flex w-full max-w-[560px] min-h-0 flex-1 flex-col">
            <div className="mb-1.5 flex shrink-0 items-center gap-2">
              <button type="button" onClick={() => togglePop(false)} className="flex h-9 w-9 items-center justify-center rounded-full bg-black/40 text-lg text-white ring-1 ring-white/15" aria-label="Exit full screen">✕</button>
              <div className="whitespace-nowrap font-display text-base leading-none tracking-wider text-amber-200 min-[380px]:text-lg">GEM MINES</div>
              <div className="ml-auto text-right leading-tight"><div className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Balance</div><div className="font-cond text-base font-bold tabular-nums text-white">{money(balance)}</div></div>
              <button type="button" onClick={() => setHistOpen(true)} className="h-8 rounded-md bg-navy-700 px-2 text-xs font-semibold text-slate-200" aria-label="Recent games">History</button>
              <SoundMenu game="mines" />
            </div>
            {stageEl(true)}
            <div className="mt-1.5">{barEl(true)}</div>
          </div>
        </div>,
        document.body,
      )}
      {createPortal(<Modal open={histOpen} onClose={() => setHistOpen(false)} title="Recent games">{historyPanel}</Modal>, document.body)}
      {createPortal(
      <Modal open={!!viewing} onClose={() => setViewing(null)} title="Previous game">
        {viewing && (
          <div className="space-y-3 text-sm">
            <MiniBoard r={viewing} />
            <dl className="grid grid-cols-3 gap-1 text-center text-xs">
              {[['Bet', money(viewing.bet)], ['Mines', viewing.mines], ['Gems', viewing.gems], ['Multiplier', viewing.result === 'mine' ? '—' : fmtX(viewing.mult)], ['Result', viewing.result === 'mine' ? 'Hit a mine' : viewing.result === 'cleared' ? 'Cleared' : 'Cashed out'], ['Payout', money(viewing.payout)]].map(([k, v]) => (
                <div key={k} className="rounded-lg bg-navy-800 p-1.5"><dt className="text-[10px] uppercase text-slate-500">{k}</dt><dd className="font-semibold text-white">{v}</dd></div>
              ))}
            </dl>
            <p className="text-center text-xs text-slate-500">{when(viewing.at)} · numbers show the order you picked the tiles</p>
          </div>
        )}
      </Modal>,
        document.body,
      )}
    </PremiumShell>
  );
}
