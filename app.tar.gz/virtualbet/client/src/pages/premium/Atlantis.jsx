import { useEffect, useMemo, useState } from 'react';
import { BigWin, Burst, FeatureIntro, Paytable, PremiumReels, PremiumShell, RecentList, SidePanel, sleep, SpinBar, tierOf, usePremium, useReelStops, WinLine } from '../../components/Premium.jsx';
import { ChestItem, Poseidon, Sym3 } from '../../components/SlotArt3.jsx';
import { money } from '../../lib/format.js';
import { AT_COINS, AT_FREE_SPINS, AT_JACKPOT, AT_MAX_MULT, AT_PAY, AT_S, LINES_20, STATS3 } from '../../../../server/games/slots3.js';

const START = [['SHELL', 'MASK', 'CORAL'], ['TURTLE', 'WILD', 'STAR'], ['CHEST', 'TRIDENT', 'SEAHORSE'], ['KRAKEN', 'WILD', 'SHELL'], ['STAR', 'CORAL', 'TURTLE']].map((c) => c.map((s) => ({ s })));

function Background({ intense }) {
  const bubbles = useMemo(() => Array.from({ length: 14 }, (_, i) => ({ left: `${(i * 37) % 100}%`, size: 4 + ((i * 7) % 12), d: `${7 + (i % 5) * 2}s`, delay: `${-(i * 1.3)}s`, sway: `${((i % 3) - 1) * 30}px` })), []);
  return (
    <>
      <div className={`absolute inset-0 transition-colors duration-1000 ${intense ? 'bg-[radial-gradient(ellipse_at_top,#0e7490_0%,#0c4a6e_40%,#020617_100%)]' : 'bg-[radial-gradient(ellipse_at_top,#0369a1_0%,#0c4a6e_38%,#082f49_70%,#020617_100%)]'}`} />
      <div className="p3-deco p3-rays absolute -top-10 left-[10%] h-[120%] w-[30%] bg-gradient-to-b from-cyan-200/25 to-transparent blur-md" />
      <div className="p3-deco p3-rays absolute -top-10 left-[55%] h-[110%] w-[20%] bg-gradient-to-b from-cyan-100/20 to-transparent blur-md" style={{ animationDelay: '-4s' }} />
      <div className="p3-deco p3-caustic absolute inset-0 opacity-80" />
      <svg viewBox="0 0 400 80" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-[22%] w-full opacity-60" aria-hidden="true">
        <path d="M0 80V60h30V30l20-14 20 14v30h20V44h12V24l26-18 26 18v20h12v16h20V20l40-20 40 20v40h20V40l18-12 18 12v20h20V48h30v32z" fill="#0c4a6e" />
        {[150, 170, 190, 210, 230, 250].map((x) => <rect key={x} x={x} y="22" width="6" height="38" fill="#b45309" opacity=".5" />)}
      </svg>
      {bubbles.map((b, i) => <span key={i} className="p3-deco p3-bubble" style={{ left: b.left, width: b.size, height: b.size, '--d': b.d, animationDelay: b.delay, '--sway': b.sway }} />)}
    </>
  );
}

function TreasureBoard({ board, onPick, onClose, busy }) {
  const items = board.revealed;
  return (
    <div className="animate-fade-in absolute inset-0 z-30 flex flex-col rounded-2xl bg-[radial-gradient(ellipse_at_top,#0e7490,#082f49_60%,#020617)] p-3">
      <div className="mb-2 flex items-center justify-between gap-2">
        <div><div className="font-display text-xl tracking-wide text-amber-200">HIDDEN TREASURE</div><div className="text-[11px] text-cyan-100/80">Open chests until you find COLLECT{board.chestMult > 1 ? ` · coins x${board.chestMult}` : ''}</div></div>
        <div className="text-right"><div className="text-[10px] uppercase text-cyan-100/70">Treasure</div><div className="font-cond text-2xl font-extrabold tabular-nums text-amber-300">{money(board.total)}</div></div>
      </div>
      <div className="mb-2 flex items-center gap-2 rounded-lg bg-black/30 px-2 py-1 text-xs text-cyan-50">
        Poseidon's Jackpot ({AT_JACKPOT / 100}x):
        {[0, 1, 2].map((k) => <span key={k} className={`h-6 w-6 rounded-full ${k < board.tridents ? 'bg-amber-400/30 ring-2 ring-amber-300' : 'bg-white/5 ring-1 ring-white/20'}`}><svg viewBox="0 0 100 100" className="h-full w-full p-0.5"><path d="M50 90V34M32 18v16c0 8 8 10 18 10s18-2 18-10V18M50 14v20" stroke={k < board.tridents ? '#fde68a' : '#475569'} strokeWidth="8" fill="none" /></svg></span>)}
        {board.freeSpins > 0 && <span className="ml-auto rounded bg-cyan-500/30 px-1.5 font-bold">+{board.freeSpins} free spins</span>}
      </div>
      <div className="grid min-h-0 flex-1 grid-cols-4 grid-rows-3 gap-1.5">
        {Array.from({ length: 12 }, (_, i) => {
          const picked = board.picked.find((p) => p.i === i);
          const item = picked || (items && items[i] ? { ...items[i], ghost: true } : null);
          return (
            <button key={i} disabled={!!item || busy || board.done} onClick={() => onPick(i)} className={`relative flex min-h-0 items-center justify-center rounded-lg ${item?.ghost ? 'opacity-40' : ''} ${!item && !board.done ? 'hover:scale-105' : ''} transition-transform [perspective:400px]`} aria-label={item ? `${item.k}` : `Chest ${i + 1}`}>
              {item ? (
                <div className="p3-fadeup h-full max-h-24 w-full">
                  <ChestItem item={item} />
                  {!item.ghost && <Burst game="atlantis" n={10} spread={50} />}
                </div>
              ) : (
                <svg viewBox="0 0 100 100" className="h-full max-h-24 w-full"><g><rect x="14" y="44" width="72" height="40" rx="5" fill="#92400e" stroke="#451a03" strokeWidth="3" /><path d="M14 46c0-18 14-26 36-26s36 8 36 26z" fill="#b45309" stroke="#451a03" strokeWidth="3" /><path d="M14 50h72M30 22v62M70 22v62" stroke="url(#s3gold)" strokeWidth="5" /><rect x="44" y="46" width="12" height="14" rx="2" fill="url(#s3gold)" /></g></svg>
              )}
            </button>
          );
        })}
      </div>
      {board.done && (
        <div className="p3-fadeup mt-2 flex items-center justify-between gap-2 rounded-xl bg-black/45 p-2">
          <div><div className="text-xs text-cyan-100/80">Treasure collected</div><div className="font-cond text-2xl font-extrabold text-amber-300">{money(board.win)}</div></div>
          <button className="btn-primary h-11 px-5" onClick={onClose}>{board.freeStart ? `Start ${board.freeStart.remaining} free spins` : 'Continue'}</button>
        </div>
      )}
    </div>
  );
}

export default function Atlantis() {
  const { user, view, history, play, commit, fx, guard, shake, doShake } = usePremium('atlantis');
  const reels = useReelStops(5);
  const [grid, setGrid] = useState(START);
  const [res, setRes] = useState(null);
  const [lit, setLit] = useState(null);
  const [stake, setStake] = useState(100);
  const [turbo, setTurbo] = useState(false);
  const [auto, setAuto] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [poseidon, setPoseidon] = useState(null);
  const [board, setBoard] = useState(null);
  const [picking, setPicking] = useState(false);
  const free = view?.free;

  // Resume a treasure bonus left open (e.g. after a reload)
  useEffect(() => { if (view?.bonus && !board && !intro) setBoard({ ...view.bonus, picked: view.bonus.picked }); }, [view?.bonus]); // eslint-disable-line react-hooks/exhaustive-deps

  const spin = () => guard(async () => {
    if (view?.bonus || board) return;
    setSpinning(true); setRes(null); setLit(null); setSpinId((n) => n + 1); reels.start(); fx.spin();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(); setSpinning(false); setAuto(false); return; }
    setGrid(out.grid);
    let seen = 0;
    const tease = [];
    out.grid.forEach((c, i) => { if (seen >= 2) tease.push(i); if (c.some((x) => x.s === 'CHEST')) seen++; });
    await reels.stopAll({ turbo, tease, onStop: (i) => { fx.stop(i); if (out.grid[i].some((x) => x.s === 'CHEST' || x.s === 'WILD')) fx.special(); } });
    setLit(new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`))));
    if (free && out.mult > out.multBefore) { setPoseidon(out.mult); fx.bonus(); await sleep(turbo ? 700 : 1500); setPoseidon(null); }
    setRes(out); setSpinning(false); commit();
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); } else if (tier) { fx.win(tier); if (tier === 2) doShake(false); }
    if (out.trigger?.treasure) { fx.bonus(); setIntro({ type: 'treasure', mult: out.trigger.chestMult, bonus: out.bonus }); }
    if (out.finished) setBig({ amount: out.finished.total, title: 'FREE SPINS WON' });
    if (!out.free) setAuto(false);
  });

  const pick = (i) => guard(async () => {
    setPicking(true);
    const out = await play('pick', { index: i });
    setPicking(false);
    if (!out) return;
    fx.special();
    setBoard((b) => ({ ...b, picked: out.bonus.picked, total: out.bonus.total, tridents: out.bonus.tridents, freeSpins: out.bonus.freeSpins }));
    if (out.pick.k === 'coin') fx.coin();
    if (out.jackpot) { fx.big(); doShake(true); setBig({ amount: out.jackpot, title: "POSEIDON'S JACKPOT", poseidon: true }); }
    if (out.done) {
      await sleep(700);
      setBoard((b) => ({ ...b, revealed: out.revealed, done: true, win: out.win, freeStart: out.freeStart }));
      commit();
      fx.win(2);
    }
  });
  const closeBoard = () => {
    const fs = board?.freeStart;
    setBoard(null);
    if (fs) { fx.bonus(); setIntro({ type: 'free', spins: fs.remaining }); }
  };

  useEffect(() => {
    if (!auto || !free || spinning || big || intro || board) return undefined;
    const t = setTimeout(spin, 900);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro, board]); // eslint-disable-line react-hooks/exhaustive-deps

  const pt = Object.entries(AT_PAY).map(([s, v]) => [s, v.map((x) => x * AT_S)]);
  const detail = res && [res.wins.length && `${res.wins.length} line win${res.wins.length > 1 ? 's' : ''}`, res.mult > 1 && `x${res.mult} multiplier`].filter(Boolean).join(' · ');
  const mult = free?.mult || 1;

  return (
    <PremiumShell game="atlantis" rtp="96%" tagline="5 reels · 20 lines · treasure chests · Poseidon's Jackpot" shake={shake}
      below={<SpinBar stake={stake} setStake={setStake} onSpin={spin} spinning={spinning} free={free} disabled={!!view?.bonus || !!board || !!intro} balance={user?.balance} turbo={turbo} setTurbo={setTurbo} auto={auto} setAuto={setAuto} accent="bg-gradient-to-b from-cyan-300 to-cyan-600 text-cyan-950" />}
      stageClass="border-2 border-amber-400/50 shadow-[0_0_40px_rgba(34,211,238,0.25)]" bg={<Background intense={!!free} />}
      side={<>
        <SidePanel title="Features">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-amber-300">Atlantis Wild</b> on reels 2–4 replaces every symbol except chests.</li>
            <li><b className="text-amber-300">3+ chests</b> open Hidden Treasure.</li>
            <li><b className="text-cyan-300">Free spins</b>: every wild raises the multiplier, up to x{AT_MAX_MULT}.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Recent spins"><RecentList history={history} /></SidePanel>
      </>}
      info={<>
        <section><h3 className="mb-2 font-bold text-white">Paytable (multiples of your total stake)</h3><Paytable game="atlantis" rows={pt} /></section>
        <section className="space-y-2">
          <h3 className="font-bold text-white">Features</h3>
          <p><b className="text-amber-300">Atlantis Wild</b> (the golden temple) lands on reels 2, 3 and 4 and substitutes for every symbol except the chest. Wins pay left to right on {LINES_20.length} lines.</p>
          <p><b className="text-amber-300">Hidden Treasure</b>: 3 or more chests anywhere open a board of 12 sealed chests. Open them one at a time. Coins add to your treasure (x2 with 4 chests, x3 with 5), and the round ends when you find a COLLECT. Each board was sealed when it was triggered, so which chest you choose doesn't change your chances.</p>
          <p><b className="text-cyan-300">Poseidon's Jackpot</b>: find all 3 golden tridents before a COLLECT to win a fixed {AT_JACKPOT / 100}x your stake.</p>
          <p><b className="text-cyan-300">Free spins</b>: a chest may hold {AT_FREE_SPINS} free spins. During them every Atlantis Wild that lands raises the multiplier by 1 (up to x{AT_MAX_MULT}) for the rest of the round. 3 chests add 5 more spins.</p>
          <p className="text-xs text-slate-500">Coin chests hold {AT_COINS.map(([x]) => `${+(x * AT_S / 100).toFixed(2)}x`).join(', ')} your stake.</p>
        </section>
        <section className="rounded-lg bg-navy-800 p-3 text-xs"><b className="text-white">Maths</b>: long-run return 96% (about 2 points of it from the fixed jackpot) · line wins on about {STATS3.atlantis.hit} of spins · {STATS3.atlantis.feature} · maximum win 5,000x per spin · outcomes come from a cryptographic random number generator before any animation plays.</section>
      </>}>
      <div className="relative min-h-[360px]">
        {free && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="rounded-lg bg-cyan-400/90 px-2.5 py-1 text-xs font-extrabold uppercase text-cyan-950">Free spins · {free.remaining} left</div>
            <div key={mult} className="p3-stamp rounded-lg bg-black/50 px-3 py-0.5 font-display text-2xl text-amber-300 ring-1 ring-amber-300/60">x{mult}</div>
          </div>
        )}
        <div className="rounded-xl bg-gradient-to-b from-amber-300/70 via-amber-600/60 to-amber-800/70 p-[3px]">
          <div className="rounded-[10px] bg-sky-950/70 p-1.5">
            <PremiumReels game="atlantis" grid={grid} stopped={reels.stopped} lit={lit} turbo={turbo} spinId={spinId} landing="bounce" />
          </div>
        </div>
        <div className="mt-2"><WinLine res={res} spinning={spinning} detail={detail} busyText="The tide turns…" /></div>
        {poseidon && (
          <div className="pointer-events-none absolute inset-0 z-20 flex items-end justify-center overflow-hidden">
            <Poseidon className="p3-rise h-[85%] w-auto drop-shadow-[0_0_30px_rgba(34,211,238,0.8)]" />
            <div className="p3-stamp absolute top-1/3 font-display text-6xl text-amber-300 drop-shadow-[0_0_20px_#22d3ee]">x{poseidon}</div>
          </div>
        )}
        {board && <TreasureBoard board={board} onPick={pick} onClose={closeBoard} busy={picking} />}
        {intro?.type === 'treasure' && (
          <FeatureIntro title="HIDDEN TREASURE" subtitle={`Open chests until you find COLLECT. Find 3 tridents for Poseidon's Jackpot.${intro.mult > 1 ? ` Coins x${intro.mult}!` : ''}`}
            art={<div className="mb-2 h-28 w-28"><Sym3 game="atlantis" s="CHEST" /></div>}
            onStart={() => { setBoard({ ...(view?.bonus || intro.bonus) }); setIntro(null); }} cta="Tap to dive in" />
        )}
        {intro?.type === 'free' && (
          <FeatureIntro title={`${intro.spins} FREE SPINS`} subtitle="Every Atlantis Wild raises the multiplier for the rest of the round." art={<Poseidon className="p3-rise mb-1 h-36 w-auto" />} onStart={() => { setIntro(null); setAuto(true); }} />
        )}
        {big && <BigWin game="atlantis" amount={big.amount} bet={res?.bet || stake} title={big.title} onDone={() => setBig(null)}
          cinematic={<div className="pointer-events-none absolute inset-0 flex items-end justify-center"><Poseidon className="p3-rise h-[95%] w-auto opacity-60" /></div>} />}
      </div>
    </PremiumShell>
  );
}
