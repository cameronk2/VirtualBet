import { useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, Burst, FeatureIntro, Paytable, PremiumReels, PremiumShell, RecentList, reduceMotion, SidePanel, sleep, SpinBar, tierOf, usePremium, useReelStops, WinLine } from '../../components/Premium.jsx';
import { Sym3 } from '../../components/SlotArt3.jsx';
import { FROST_LOBBY, WolfReel } from '../../components/SlotArtFrost.jsx';
import { money } from '../../lib/format.js';
import { FR_FREE, FR_MAX_MULT, FR_MULTS, FR_PAY, FR_S, LINES_40 } from '../../../../server/games/slots3.js';

const START = [['RUNE_B', 'OWL', 'RUNE_R', 'ELK'], ['EAGLE', 'RUNE_G', 'WOLF', 'RUNE_P'], ['MOON', 'BEAR', 'RUNE_B', 'OWL'], ['RUNE_P', 'WOLF', 'ELK', 'RUNE_G'], ['BEAR', 'RUNE_R', 'EAGLE', 'MOON']].map((c) => c.map((s) => ({ s })));
const LINE_COLOURS = ['#7dd3fc', '#f0abfc', '#86efac', '#fde68a', '#fda4af', '#a5b4fc', '#5eead4', '#fdba74'];

/** Falling snow on a canvas (paused when hidden or with reduced motion). */
function Snow({ heavy }) {
  const ref = useRef(null);
  useEffect(() => {
    if (reduceMotion) return undefined;
    const c = ref.current, ctx = c.getContext('2d');
    let w = 0, h = 0, raf = 0;
    const size = () => { const r = c.getBoundingClientRect(); w = c.width = Math.max(1, r.width); h = c.height = Math.max(1, r.height); };
    size();
    const ro = new ResizeObserver(size); ro.observe(c);
    const n = heavy ? 110 : 70;
    const flakes = Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, r: 0.6 + Math.random() * 2, s: 0.25 + Math.random() * 0.8, d: Math.random() * Math.PI * 2 }));
    const tick = () => {
      if (!document.hidden) {
        ctx.clearRect(0, 0, w, h);
        for (const f of flakes) {
          f.y += f.s; f.d += 0.01; f.x += Math.sin(f.d) * 0.35;
          if (f.y > h + 4) { f.y = -4; f.x = Math.random() * w; }
          ctx.globalAlpha = 0.35 + f.r / 4;
          ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
        }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [heavy]);
  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true" />;
}

function FrostScene({ fullMoon }) {
  const stars = useMemo(() => Array.from({ length: 40 }, (_, i) => ({ x: (i * 41) % 100, y: (i * 17) % 45, s: i % 6 === 0 ? 2 : 1, delay: `${-(i % 7) * 0.5}s` })), []);
  return (
    <>
      <div className={`absolute inset-0 transition-colors duration-1000 ${fullMoon ? 'bg-[linear-gradient(180deg,#0b1026,#1e1b4b_40%,#0f172a)]' : 'bg-[linear-gradient(180deg,#020617,#0b1f3a_45%,#0f172a)]'}`} />
      {stars.map((s, i) => <span key={i} className="fr-twinkle absolute rounded-full bg-white" style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s, animationDelay: s.delay }} />)}
      <div className="fr-aurora absolute -left-[10%] top-[4%] h-[22%] w-[120%] rounded-[50%] bg-[linear-gradient(90deg,transparent,rgba(45,212,191,0.55),rgba(129,140,248,0.45),rgba(236,72,153,0.35),transparent)]" />
      <div className="fr-aurora absolute -left-[20%] top-[14%] h-[14%] w-[130%] rounded-[50%] bg-[linear-gradient(90deg,transparent,rgba(52,211,153,0.4),rgba(56,189,248,0.4),transparent)]" style={{ animationDelay: '-6s', animationDuration: '19s' }} />
      <div className={`absolute right-[7%] top-[5%] rounded-full bg-[radial-gradient(circle_at_40%_38%,#fff,#e2e8f0_60%,#94a3b8)] shadow-[0_0_60px_20px_rgba(186,230,253,0.35)] transition-all duration-1000 ${fullMoon ? 'h-24 w-24 sm:h-32 sm:w-32' : 'h-14 w-14 sm:h-20 sm:w-20'}`} />
      <svg viewBox="0 0 400 120" preserveAspectRatio="none" className="fr-drift absolute bottom-[18%] left-0 h-[34%] w-[106%] opacity-50" aria-hidden="true">
        <polygon points="0,120 0,70 40,40 80,62 130,20 175,58 220,30 270,64 320,24 360,50 400,36 400,120" fill="#334155" />
        <polygon points="130,20 145,32 138,36 120,30" fill="#e2e8f0" /><polygon points="220,30 236,42 214,40" fill="#e2e8f0" /><polygon points="320,24 338,38 314,36" fill="#e2e8f0" />
      </svg>
      <svg viewBox="0 0 400 120" preserveAspectRatio="none" className="absolute bottom-[8%] left-0 h-[30%] w-full opacity-80" aria-hidden="true">
        <polygon points="0,120 0,80 50,50 95,78 150,36 200,70 250,46 300,82 350,52 400,74 400,120" fill="#1e293b" />
        <polygon points="150,36 168,52 146,54 134,48" fill="#cbd5e1" /><polygon points="250,46 266,58 244,60" fill="#cbd5e1" /><polygon points="50,50 64,62 44,62" fill="#cbd5e1" />
      </svg>
      <svg viewBox="0 0 400 60" preserveAspectRatio="none" className="absolute bottom-0 left-0 h-[16%] w-full" aria-hidden="true">
        {Array.from({ length: 26 }, (_, i) => { const x = i * 16 - 4, hgt = 24 + ((i * 7) % 18); return <polygon key={i} points={`${x},60 ${x + 8},${60 - hgt} ${x + 16},60`} fill="#020617" />; })}
        <rect y="52" width="400" height="8" fill="#020617" />
      </svg>
      <div className="fr-fog absolute bottom-[10%] left-[-20%] h-[18%] w-[140%] bg-[radial-gradient(ellipse_at_center,rgba(203,213,225,0.18),transparent_65%)] blur-md" />
      <Snow heavy={fullMoon} />
    </>
  );
}

function WildOverlay({ mult, effect, lit }) {
  const origin = effect?.row != null ? `50% ${((effect.row + 0.5) / 4) * 100}%` : '50% 50%';
  return (
    <div className={`pointer-events-none absolute inset-0 z-10 overflow-hidden rounded-lg ${lit ? 'ring-2 ring-sky-200 shadow-[0_0_20px_rgba(125,211,252,0.8)]' : 'ring-1 ring-sky-300/60'}`}>
      <div key={effect?.id} className={`h-full w-full ${effect?.fresh ? 'fr-expand' : ''}`} style={{ transformOrigin: origin }}>
        <WolfReel className="h-full w-full" />
      </div>
      {effect?.fresh && <div key={`f${effect.id}`} className="fr-flash absolute inset-0" />}
      {effect?.fresh && <Burst key={`b${effect.id}`} game="frost" n={14} spread={60} />}
      <div className="absolute inset-x-0 bottom-[24%] flex justify-center">
        <div key={`m${mult}-${effect?.id}`} className={`relative flex h-10 w-10 items-center justify-center sm:h-12 sm:w-12 ${effect?.grow ? 'fr-badge-grow' : effect?.fresh ? 'p3-stamp' : ''}`}>
          <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full drop-shadow-[0_0_10px_rgba(125,211,252,0.9)]"><polygon points="50,4 92,27 92,73 50,96 8,73 8,27" fill="url(#frIceDeep)" stroke="#e0f2fe" strokeWidth="5" /><polygon points="50,4 92,27 50,50" fill="#fff" opacity=".25" /></svg>
          <span className="relative font-display text-base text-white drop-shadow sm:text-lg">x{mult}</span>
        </div>
      </div>
      {effect?.grow ? <div key={`g${effect.id}`} className="fr-plus absolute bottom-[42%] left-1/2 font-display text-2xl text-sky-100 drop-shadow-[0_0_8px_#38bdf8]">+{effect.grow}</div> : null}
    </div>
  );
}

function WinLines({ wins, id }) {
  if (!wins?.length) return null;
  return (
    <svg key={id} viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 z-20 h-full w-full" aria-hidden="true">
      {wins.slice(0, 10).map((w, i) => {
        const pts = LINES_40[w.line].slice(0, w.count).map((row, reel) => `${(reel + 0.5) * 20},${(row + 0.5) * 25}`).join(' ');
        const c = LINE_COLOURS[i % LINE_COLOURS.length];
        return (
          <g key={i}>
            <polyline points={pts} fill="none" stroke={c} strokeOpacity=".35" strokeWidth="7" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" className="fr-line" style={{ animationDelay: `${i * 0.08}s` }} />
            <polyline points={pts} fill="none" stroke="#fff" strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" className="fr-line" style={{ animationDelay: `${i * 0.08}s`, filter: `drop-shadow(0 0 4px ${c})` }} />
          </g>
        );
      })}
    </svg>
  );
}

export default function Frostfang() {
  const { user, view, history, play, commit, fx, guard, shake, doShake } = usePremium('frost');
  const reels = useReelStops(5);
  const [grid, setGrid] = useState(START);
  const [wilds, setWilds] = useState({});
  const [effects, setEffects] = useState({});
  const [held, setHeld] = useState(new Set());
  const [lines, setLines] = useState(null);
  const [lit, setLit] = useState(null);
  const [running, setRunning] = useState(0);
  const [banner, setBanner] = useState(null);
  const [res, setRes] = useState(null);
  const [stake, setStake] = useState(100);
  const [turbo, setTurbo] = useState(false);
  const [auto, setAuto] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const free = view?.free;
  const fxId = useRef(0);

  // Show the round's standing wilds when arriving mid-free-spins
  useEffect(() => {
    if (free && !spinning) { setWilds(free.wilds); setHeld(new Set(Object.keys(free.wilds).map(Number))); }
  }, [free?.remaining]); // eslint-disable-line react-hooks/exhaustive-deps

  const spin = () => guard(async () => {
    setSpinning(true); setRes(null); setLines(null); setLit(null); setRunning(0); setEffects({}); setBanner(null); fx.spin();
    const standing = free ? free.wilds : {};
    setWilds(standing); setHeld(new Set(Object.keys(standing).map(Number)));
    setSpinId((n) => n + 1); reels.start();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(); setSpinning(false); setAuto(false); return; }
    let total = 0;
    for (let i = 0; i < out.steps.length; i++) {
      const st = out.steps[i];
      if (i > 0) {
        setBanner({ text: 'HOWL RESPIN', id: i }); fx.special();
        await sleep(turbo ? 500 : 1100);
        setLines(null); setLit(null); setEffects({}); setBanner(null);
        setHeld(new Set(st.held)); setSpinId((n) => n + 1); reels.start(); fx.spin();
      }
      setGrid(st.landed);
      let seen = 0;
      const tease = [];
      if (i === 0) st.landed.forEach((c, r) => { if (seen >= 2) tease.push(r); if (c.some((x) => x.s === 'MOON')) seen++; });
      await reels.stopAll({ turbo, tease, onStop: (r) => { fx.stop(r); if (st.landed[r].some((x) => x.s === 'MOON')) fx.land(); } });
      // Wilds expand, and every new one powers up the wilds already standing
      const fxMap = {};
      st.fresh.forEach((r) => { fxMap[r] = { fresh: true, row: st.landed[r].findIndex((c) => c.s === 'WILD'), id: ++fxId.current }; });
      if (st.fresh.length) {
        setWilds({ ...st.before, ...Object.fromEntries(st.fresh.map((r) => [r, st.wilds[r]])) });
        setEffects(fxMap); fx.special(); doShake(false);
        await sleep(turbo ? 450 : 950);
        const grown = Object.keys(st.before).filter((r) => st.wilds[r] > st.before[r]);
        if (grown.length) {
          setEffects(Object.fromEntries(grown.map((r) => [r, { grow: st.wilds[r] - st.before[r], id: ++fxId.current }])));
          setWilds(st.wilds); fx.win(2);
          await sleep(turbo ? 450 : 1000);
        }
      }
      setWilds(st.wilds);
      setGrid(st.grid);
      if (st.wins.length) {
        setLines(st.wins);
        setLit(new Set(st.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`))));
        total += st.win; setRunning(total);
        fx.win(1);
        await sleep(turbo ? 600 : 1400);
      }
    }
    setRes(out); setSpinning(false); commit();
    if (out.free) setHeld(new Set(Object.keys(out.free.wilds).map(Number)));
    const tier = tierOf(out.win, out.staked, out.bet);
    if (tier >= 3) { setBig({ amount: out.win }); fx.big(); doShake(tier >= 4); } else if (tier) { fx.win(tier); if (tier === 2) doShake(false); }
    if (out.trigger?.freeSpins) { fx.bonus(); setIntro(out.trigger.freeSpins); }
    if (out.finished) setBig({ amount: out.finished.total, title: 'FULL MOON COMPLETE' });
    if (!out.free) setAuto(false);
  });
  useEffect(() => {
    if (!auto || !free || spinning || big || intro) return undefined;
    const t = setTimeout(spin, 900);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro]); // eslint-disable-line react-hooks/exhaustive-deps

  const litReels = new Set([...(lit || [])].map((k) => Number(k.split('-')[0])));
  const overlays = [0, 1, 2, 3, 4].map((r) => (wilds[r] !== undefined ? <WildOverlay mult={wilds[r]} effect={effects[r]} lit={litReels.has(r)} /> : null));
  const pt = Object.entries(FR_PAY).map(([s, v]) => [s, v.map((x) => x * FR_S)]);
  const wildTotal = Object.values(wilds).reduce((a, v) => a + v, 0);
  const detail = res && [res.respins && `${res.respins} Howl Respin${res.respins > 1 ? 's' : ''}`, res.steps.some((s) => s.wins.length) && `${res.steps.reduce((a, s) => a + s.wins.length, 0)} line wins`].filter(Boolean).join(' · ');

  return (
    <PremiumShell game="frost" rtp="96%" tagline="5 × 4 · 40 lines · expanding sticky wilds with growing multipliers" shake={shake}
      stageClass="border-2 border-sky-200/60 shadow-[0_0_60px_rgba(56,189,248,0.3)]" bg={<FrostScene fullMoon={!!free} />}
      below={<SpinBar stake={stake} setStake={setStake} onSpin={spin} spinning={spinning} free={free} disabled={!!intro} balance={user?.balance} turbo={turbo} setTurbo={setTurbo} auto={auto} setAuto={setAuto} accent="bg-gradient-to-b from-sky-200 to-sky-500 text-sky-950" />}
      side={<>
        <SidePanel title="Wild reels">
          {Object.keys(wilds).length ? (
            <div className="flex gap-1.5">{[1, 2, 3, 4].map((r) => <div key={r} className={`flex-1 rounded-md py-1 text-center text-xs font-bold ${wilds[r] !== undefined ? 'bg-sky-400/20 text-sky-100 ring-1 ring-sky-300/60' : 'bg-navy-800 text-slate-600'}`}>{wilds[r] !== undefined ? `x${wilds[r]}` : '–'}</div>)}</div>
          ) : <p className="text-xs text-slate-500">No wilds on the reels.</p>}
          {free && <p className="mt-2 text-[11px] text-sky-200">Full Moon: wild reels stay until the round ends.</p>}
        </SidePanel>
        <SidePanel title="How the wilds work">
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li><b className="text-sky-200">Frostfang Wilds</b> fill their reel with a x2–x10 multiplier.</li>
            <li>Every new wild adds <b className="text-sky-200">+1</b> to wilds already there.</li>
            <li><b className="text-sky-200">Howl Respins</b> keep wilds in place while new ones land.</li>
            <li><b className="text-sky-200">3+ moons</b>: Full Moon free spins, wilds stay all round.</li>
          </ul>
        </SidePanel>
        <SidePanel title="Recent spins"><RecentList history={history} /></SidePanel>
      </>}
      info={<>
        <section><h3 className="mb-2 font-bold text-white">Paytable (multiples of total stake, before wild multipliers)</h3><Paytable game="frost" rows={pt} /></section>
        <section className="space-y-2">
          <h3 className="font-bold text-white">The Frostfang Wild</h3>
          <p>Wilds land on reels 2–5. When one lands it <b className="text-sky-200">expands to fill the whole reel</b> and takes a multiplier: {FR_MULTS.map(([v, w]) => `x${v} (${w}%)`).join(', ')}. A line win that runs through wild reels is multiplied by the <b>sum</b> of their multipliers (a x3 and a x5 reel on the same win make x8). Wins pay left to right on {LINES_40.length} lines; the moon is never substituted.</p>
          <p><b className="text-sky-200">Growing multipliers</b>: every new wild that lands adds +1 to the multiplier of every wild reel already standing, up to x{FR_MAX_MULT}.</p>
          <p><b className="text-sky-200">Howl Respins</b>: in the base game, when wilds land they stay where they are and the other reels respin for free. If more wilds land, they expand and stay too, and the respins continue. They end when a respin brings no new wild, or all four wild reels are full. Respins are part of the spin you paid for.</p>
          <p><b className="text-sky-200">Full Moon free spins</b>: 3, 4 or 5 moons give {FR_FREE[3]}, {FR_FREE[4]} or {FR_FREE[5]} free spins. Every wild that lands stays on its reel <b>for the rest of the round</b>, and keeps growing as new wilds join. 3 moons during the round add 5 spins.</p>
        </section>
        <section className="rounded-lg bg-navy-800 p-3 text-xs"><b className="text-white">Maths</b>: long-run return 96% · wins on about 44% of spins · Howl Respins on about 1 in 8 spins · Full Moon about 1 in 200 spins · maximum win 5,000x per spin · results come from a cryptographic random number generator before any animation plays.</section>
      </>}>
      <div className="relative pt-2">
        {free && (
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="rounded-md bg-sky-200 px-2.5 py-1 text-xs font-extrabold uppercase text-sky-950 shadow-[0_0_16px_rgba(186,230,253,0.7)]">Full Moon · {free.remaining} left</div>
            <div className="rounded-md bg-black/50 px-2 py-1 text-xs font-bold text-sky-100 ring-1 ring-sky-300/50">{Object.keys(free.wilds).length} wild reel{Object.keys(free.wilds).length === 1 ? '' : 's'} · x{Object.values(free.wilds).reduce((a, v) => a + v, 0) || 0}</div>
          </div>
        )}
        <div className="relative rounded-2xl bg-[linear-gradient(160deg,rgba(224,242,254,0.85),rgba(56,189,248,0.5)_40%,rgba(12,74,110,0.8))] p-[3px] shadow-[0_0_30px_rgba(125,211,252,0.35)]">
          <div className="relative rounded-[13px] bg-slate-950/70 p-1.5 backdrop-blur-sm">
            <div className="relative mx-auto" style={{ maxWidth: 'min(100%, calc((100dvh - 480px) * 1.25))' }}>
              <PremiumReels game="frost" grid={grid} stopped={reels.stopped.map((s, i) => s || held.has(i))} lit={lit} turbo={turbo} spinId={spinId} landing="bounce" overlays={overlays} />
              <WinLines wins={lines} id={`${spinId}-${running}`} />
            </div>
          </div>
          {['left-0 top-0', 'right-0 top-0 rotate-90', 'right-0 bottom-0 rotate-180', 'left-0 bottom-0 -rotate-90'].map((pos) => (
            <svg key={pos} viewBox="0 0 20 20" className={`pointer-events-none absolute h-5 w-5 ${pos}`} aria-hidden="true"><path d="M2 18V6l4-4h12" stroke="#e0f2fe" strokeWidth="2" fill="none" /><circle cx="6" cy="6" r="1.6" fill="#e0f2fe" /></svg>
          ))}
        </div>
        {banner && (
          <div key={banner.id} className="fr-banner pointer-events-none absolute inset-x-0 top-1/3 z-30 flex justify-center">
            <div className="rounded-full bg-sky-100/95 px-6 py-2 font-display text-2xl tracking-widest text-sky-900 shadow-[0_0_30px_rgba(186,230,253,0.9)]">{banner.text}</div>
          </div>
        )}
        <div className="mt-2">
          {spinning && running ? <div className="flex min-h-14 flex-col items-center justify-center rounded-xl bg-black/45 leading-tight"><div className="font-cond text-3xl font-extrabold tabular-nums text-white">{money(running)}</div><div className="text-[11px] text-sky-200">Wild multiplier total x{wildTotal}</div></div>
            : <WinLine res={res} spinning={spinning} detail={detail} busyText="The wind howls…" />}
        </div>
        {intro && (
          <FeatureIntro title="FULL MOON" subtitle={`${intro} free spins. Every wild that lands stays for the whole round and grows with each new wild.`}
            art={<svg viewBox="0 0 100 100" className="fr-moonrise mb-2 h-32 w-32" aria-hidden="true">{FROST_LOBBY}</svg>} className="bg-[radial-gradient(ellipse_at_top,rgba(30,58,95,0.95),rgba(2,6,23,0.97))]" onStart={() => { setIntro(null); setAuto(true); }} />
        )}
        {big && <BigWin game="frost" amount={big.amount} bet={res?.bet || stake} title={big.title} onDone={() => setBig(null)}
          cinematic={<svg viewBox="0 0 100 100" className="fr-moonrise pointer-events-none absolute inset-0 h-full w-full opacity-50" preserveAspectRatio="xMidYMid slice" aria-hidden="true">{FROST_LOBBY}</svg>} />}
        {!Object.keys(wilds).length && !spinning && !res && <div className="pointer-events-none absolute -top-1 right-2 z-10 hidden h-12 w-12 sm:block"><Sym3 game="frost" s="WILD" /></div>}
      </div>
    </PremiumShell>
  );
}
