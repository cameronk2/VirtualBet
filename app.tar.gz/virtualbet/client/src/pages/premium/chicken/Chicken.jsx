// Cluck Crossing – game screen. The server decides every lane (secure RNG)
// before anything moves; this screen walks the chicken to the answer.
// States: idle (waiting for bet) → placing (bet placed) → starting →
// ready ⇄ crossing → safe → ready … → cashed (cash-out) | hit → over.
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Burst, PremiumShell, SidePanel, sleep, usePremium } from '../../../components/Premium.jsx';
import { Barrier, Chicken, Manhole, Vehicle, VEHICLE_COLOURS, VEHICLE_KINDS } from '../../../components/SlotArtChicken.jsx';
import { useApp } from '../../../state/AppContext.jsx';
import { chickenSfx } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { DIFF_IDS, RTP, TABLES } from '../../../../../server/games/chicken/config.js';

const DIFF_STYLE = {
  easy: 'from-emerald-300 to-emerald-600 text-emerald-950', medium: 'from-sky-300 to-sky-600 text-sky-950',
  hard: 'from-orange-300 to-orange-600 text-orange-950', hardcore: 'from-rose-400 to-red-700 text-white',
};
const SPEED = { easy: 1.25, medium: 1, hard: 0.82, hardcore: 0.66 };
const STATUS = {
  idle: 'Place your bet', placing: 'Bet placed', starting: 'Get ready…', crossing: 'Crossing…', safe: 'Safe!',
  ready: 'Cross again or cash out', cashed: 'Cashed out', hit: 'Hit!', over: 'Game over',
};
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } };
const fmtX = (m) => `${m >= 1000 ? Math.floor(m).toLocaleString() : m.toFixed(2)}x`;
const multClass = (m) => (m >= 100 ? 'bg-gradient-to-r from-yellow-200 via-pink-300 to-sky-300 bg-clip-text text-transparent' : m >= 20 ? 'text-pink-300' : m >= 5 ? 'text-orange-300' : m >= 2 ? 'text-yellow-200' : 'text-white');
const when = (t) => new Date(t).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

/** Smoothly counts a number up/down to its new value. */
function useCount(value, ms = 450) {
  const [shown, setShown] = useState(value);
  const from = useRef(value);
  useEffect(() => {
    const start = performance.now(), a = from.current, b = value;
    let id;
    const step = (now) => { const k = Math.min(1, (now - start) / ms), e = 1 - (1 - k) ** 3; setShown(a + (b - a) * e); if (k < 1) id = requestAnimationFrame(step); else from.current = b; };
    id = requestAnimationFrame(step);
    return () => { cancelAnimationFrame(id); from.current = b; };
  }, [value, ms]);
  return shown;
}

/** Lane geometry follows the screen size. */
function useLaneSize() {
  const get = () => (typeof window === 'undefined' ? 100 : window.innerWidth < 400 ? 74 : window.innerWidth < 640 ? 84 : 104);
  const [w, setW] = useState(get);
  useEffect(() => { const h = () => setW(get()); window.addEventListener('resize', h); return () => window.removeEventListener('resize', h); }, []);
  return w;
}

function Traffic({ idx, diff, height }) {
  const up = idx % 2 === 1;
  const cars = useMemo(() => [0, 1].map((k) => ({
    kind: VEHICLE_KINDS[(idx * 3 + k * 5) % VEHICLE_KINDS.length], colour: VEHICLE_COLOURS[(idx * 5 + k * 3) % VEHICLE_COLOURS.length],
    dur: (2.4 + ((idx * 7 + k * 3) % 9) * 0.22) * SPEED[diff], delay: k,
  })), [idx, diff]);
  return cars.map((c, k) => (
    <div key={k} className="ck-car absolute left-1/2 top-0 -ml-[22px] w-[44px]" style={{ '--from': up ? `${height + 20}px` : '-140px', '--to': up ? '-140px' : `${height + 20}px`, animationDuration: `${c.dur}s`, animationDelay: `${-c.dur * (c.delay * 0.5 + ((idx * 13) % 10) / 20)}s` }}>
      <div className="mx-auto w-fit scale-[.78] sm:scale-100"><Vehicle kind={c.kind} colour={c.colour} up={up} /></div>
    </div>
  ));
}

function Feathers({ id }) {
  return (
    <div key={id} className="pointer-events-none absolute inset-0">
      {Array.from({ length: 12 }, (_, i) => {
        const a = (i / 12) * Math.PI * 2, d = 40 + (i % 3) * 22;
        return <svg key={i} viewBox="0 0 20 10" className="ck-feather absolute left-1/2 top-1/2 h-3 w-6" style={{ '--fx': `${Math.cos(a) * d}px`, '--fy': `${Math.sin(a) * d - 20}px`, '--fr': `${i * 70}deg`, animationDelay: `${(i % 4) * 0.03}s` }}><path d="M0 5Q10 -2 20 5Q10 12 0 5Z" fill="#fff7ed" stroke="#d6b48a" strokeWidth=".8" /></svg>;
      })}
    </div>
  );
}

export default function ChickenGame() {
  const { config } = useApp();
  const { user, view, play, commit, guard, shake, doShake } = usePremium('chicken');
  const fx = useMemo(() => chickenSfx(), []);
  const rules = config?.rules || { minStake: 10, maxStake: 50000 };
  const LW = useLaneSize();
  const [diff, setDiff] = useState(() => (DIFF_IDS.includes(pref('ck_diff', 'medium')) ? pref('ck_diff', 'medium') : 'medium'));
  const [stake, setStake] = useState(() => { const v = parseInt(pref('ck_bet', '100'), 10); return Number.isSafeInteger(v) && v > 0 ? v : 100; });
  const [betText, setBetText] = useState(() => (stake / 100).toFixed(2));
  const [phase, setPhase] = useState('idle');
  const [lane, setLane] = useState(0);           // lanes safely crossed (chicken position)
  const [walkTo, setWalkTo] = useState(null);     // lane being walked into
  const [pose, setPose] = useState('idle');
  const [blocked, setBlocked] = useState(0);      // lanes with traffic stopped
  const [strike, setStrike] = useState(null);
  const [flash, setFlash] = useState(null);
  const [burst, setBurst] = useState(0);
  const [result, setResult] = useState(null);
  const [roundBet, setRoundBet] = useState(null);
  const [roundDiff, setRoundDiff] = useState(diff);
  const stageRef = useRef(null);
  const [viewW, setViewW] = useState(360);
  useLayoutEffect(() => {
    const el = stageRef.current; if (!el) return undefined;
    const ro = new ResizeObserver(() => setViewW(el.clientWidth)); ro.observe(el); setViewW(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const table = TABLES[roundDiff];
  const L = table.lanes;
  const mult = lane ? table.mults[lane - 1] : 0;
  const nextMult = lane < L ? table.mults[lane] : null;
  const nextChance = lane < L ? 1 - table.risks[lane] : null;
  const shownMult = useCount(mult || 1);
  const bet = roundBet ?? stake;
  const potential = Math.floor(bet * (mult || 0));
  const inRound = ['placing', 'starting', 'crossing', 'safe', 'ready'].includes(phase);
  const balance = user?.balance ?? 0;
  const progress = lane / L;

  // Restore a round left in play (refresh, closed tab, lost connection)
  const restored = useRef(false);
  useEffect(() => {
    if (!view || restored.current) return;
    restored.current = true;
    if (view.mode === 'run' && view.round) {
      const r = view.round;
      setRoundDiff(r.difficulty); setDiff(r.difficulty); setRoundBet(r.bet); setLane(r.lane); setBlocked(r.lane); setPose('nervous'); setPhase('ready');
    }
  }, [view]);

  // Ambient traffic noise while the screen is open
  useEffect(() => {
    const id = setInterval(() => { if (Math.random() < 0.55) fx.whoosh(); else if (Math.random() < 0.12) fx.horn(); }, 2600);
    return () => clearInterval(id);
  }, [fx]);
  // Idle clucks / nervous clucks
  useEffect(() => {
    if (phase !== 'idle' && phase !== 'ready') return undefined;
    const id = setInterval(() => { if (phase === 'ready') fx.nervous(); else if (Math.random() < 0.5) fx.cluck(2); }, phase === 'ready' ? 4200 : 7000);
    return () => clearInterval(id);
  }, [phase, fx]);

  const setBet = (v) => {
    const c = Math.max(rules.minStake, Math.min(rules.maxStake, Math.round(v)));
    setStake(c); setBetText((c / 100).toFixed(2)); save('ck_bet', String(c));
  };
  const reset = () => { setLane(0); setBlocked(0); setWalkTo(null); setStrike(null); setPose('idle'); setRoundBet(null); setResult(null); setPhase('idle'); };

  const start = () => guard(async () => {
    if (inRound) return;
    if (result) reset();
    if (stake > balance) return;
    setRoundDiff(diff); setRoundBet(stake); setLane(0); setBlocked(0); setStrike(null); setResult(null);
    setPhase('placing'); fx.click();
    const out = await play('start', { stake, difficulty: diff });
    if (!out) { setRoundBet(null); setPhase('idle'); return; }
    commit();
    setPhase('starting'); setPose('nervous'); fx.cluck(3);
    await sleep(550);
    setPhase('ready');
  });

  const go = () => guard(async () => {
    if (phase !== 'ready' || lane >= L) return;
    setPhase('crossing'); fx.engine(0.6);
    const out = await play('step', {});
    if (!out) { setPhase('ready'); return; }
    const target = out.lane;
    setWalkTo(target); setPose('walk');
    [0, 1, 2, 3].forEach((i) => setTimeout(() => fx.step(i), i * 110));
    if (out.safe) {
      setBlocked(target); fx.brake();
      await sleep(470);
      setLane(target); setWalkTo(null); setPose('happy');
      fx.safe(target); setTimeout(() => fx.mult(target), 120);
      if (progress >= 0.5) setTimeout(() => fx.heartbeat(), 350);
      if (out.mult >= 10) { setBurst((n) => n + 1); setFlash({ id: Date.now(), cls: 'bg-yellow-200' }); if (out.mult >= 50) doShake(out.mult >= 500); }
      setPhase('safe');
      await sleep(480);
      if (out.finished) {
        commit(); setPose('victory'); fx.victory(); setBurst((n) => n + 1);
        setResult({ type: 'win', bet: bet, mult: out.mult, payout: out.win, lanes: target, all: true });
        setPhase('cashed');
      } else { setPose('nervous'); setPhase('ready'); }
    } else {
      // the lane wasn't safe: a vehicle comes through as the chicken steps in
      const sk = { lane: target, id: Date.now(), kind: ['truck', 'bus', 'van', 'car'][target % 4], colour: VEHICLE_COLOURS[target % VEHICLE_COLOURS.length], up: (target - 1) % 2 === 1 };
      setStrike({ ...sk, pending: true });            // clears the lane's normal traffic
      await sleep(260);
      setStrike(sk); fx.horn(); fx.brake();
      await sleep(370);
      setPose('hit'); fx.crash(); doShake(true); setFlash({ id: Date.now(), cls: 'bg-red-500' });
      await sleep(1100);
      commit();
      setResult({ type: 'lost', bet, lane: target, missed: table.mults[target - 1], reached: mult });
      setPhase('hit');
      await sleep(250);
      setPhase('over');
    }
  });

  const cashout = () => guard(async () => {
    if (phase !== 'ready' || lane < 1) return;
    setPhase('crossing');
    const out = await play('cashout', {});
    if (!out) { setPhase('ready'); return; }
    commit(); fx.cashout(); setTimeout(() => fx.victory(), 250);
    setPose('victory'); setBurst((n) => n + 1);
    setResult({ type: 'win', bet: out.bet, mult: out.mult, payout: out.win, lanes: out.lane });
    setPhase('cashed');
  });

  // Keyboard: space/↑/→ = cross, C = cash out, Enter = start
  const keys = useRef({}); keys.current = { go, cashout, start, phase, result };
  useEffect(() => {
    const h = (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(e.target.tagName) || e.repeat) return;
      const k = keys.current;
      if ((e.code === 'Space' || e.code === 'ArrowRight' || e.code === 'ArrowUp') && k.phase === 'ready') { e.preventDefault(); k.go(); }
      else if (e.code === 'KeyC' && k.phase === 'ready') k.cashout();
      else if (e.code === 'Enter' && !inRoundOf(k.phase)) { e.preventDefault(); k.start(); }
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, []);

  // ── road geometry ───────────────────────────────────────────────────────
  const H_ROAD = viewW < 640 ? 250 : 330;
  const START_W = Math.round(LW * 1.25), END_W = Math.round(LW * 1.6);
  const totalW = START_W + L * LW + END_W;
  const xOf = (n) => (n === 0 ? START_W * 0.5 : START_W + (n - 1) * LW + LW / 2);
  const chickenLane = walkTo ?? lane;
  const chickenX = phase === 'cashed' && result?.all ? START_W + L * LW + END_W * 0.45 : xOf(chickenLane);
  const camX = Math.max(0, Math.min(totalW - viewW, chickenX - viewW * 0.32));
  const firstLane = Math.max(0, lane - 2), lastLane = Math.min(L - 1, lane + Math.ceil(viewW / LW) + 1);

  const goEnabled = phase === 'ready' && lane < L;
  const cashEnabled = phase === 'ready' && lane >= 1;
  const canStart = !inRound && stake <= balance && stake >= rules.minStake && stake <= rules.maxStake;

  const stage = (
    <div ref={stageRef} className="relative overflow-hidden rounded-xl bg-[#0b1220] select-none" style={{ height: H_ROAD + 96 }}>
      {/* sky and distant hills (parallax) */}
      <div className="absolute inset-x-0 top-0 h-[96px] overflow-hidden bg-gradient-to-b from-sky-500 via-sky-300 to-amber-100">
        <div className="ck-cloud absolute left-0 top-3 h-6 w-24 rounded-full bg-white/80 blur-[1px]" />
        <div className="ck-cloud absolute left-0 top-8 h-5 w-16 rounded-full bg-white/70 blur-[1px]" style={{ animationDelay: '-35s', animationDuration: '90s' }} />
        <div className="absolute inset-y-0 left-0" style={{ width: totalW * 0.4 + viewW, transform: `translateX(${-camX * 0.4}px)`, transition: 'transform .55s ease-out' }}>
          <svg viewBox="0 0 800 96" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
            <path d="M0 70Q60 40 120 60T260 52T400 58T560 44T800 56V96H0Z" fill="#86efac" />
            {[60, 180, 330, 470, 610, 730].map((x, i) => <g key={x}><rect x={x} y={44 - (i % 3) * 8} width="22" height={52 + (i % 3) * 8} fill="#94a3b8" /><rect x={x + 26} y={54 - (i % 2) * 10} width="16" height={42 + (i % 2) * 10} fill="#64748b" />{[0, 1, 2].map((j) => <rect key={j} x={x + 4} y={52 - (i % 3) * 8 + j * 12} width="5" height="5" fill="#fde68a" />)}</g>)}
            <path d="M0 82Q100 70 200 80T400 76T600 82T800 74V96H0Z" fill="#4ade80" />
          </svg>
        </div>
        <div className="absolute inset-x-0 bottom-0 h-3 bg-gradient-to-b from-transparent to-black/30" />
      </div>
      {/* the road plane */}
      <div className="absolute inset-x-0 bottom-0 overflow-hidden" style={{ height: H_ROAD }}>
        <div className="absolute inset-y-0 left-0" style={{ width: totalW, transform: `translateX(${-camX}px)`, transition: 'transform .55s cubic-bezier(.3,.7,.3,1)' }}>
          {/* start pavement */}
          <div className="absolute inset-y-0 left-0 bg-[linear-gradient(90deg,#4ade80_0%,#22c55e_55%,#cbd5e1_56%,#94a3b8_100%)]" style={{ width: START_W }}>
            <svg viewBox="0 0 100 300" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
              {[30, 120, 220].map((y) => <g key={y}><circle cx="22" cy={y} r="16" fill="#15803d" /><circle cx="30" cy={y - 8} r="12" fill="#16a34a" /></g>)}
            </svg>
            <div className="absolute bottom-3 left-2 rounded bg-black/50 px-1.5 py-0.5 text-[10px] font-bold text-white">START</div>
          </div>
          {/* lanes */}
          <div className="absolute inset-y-0 bg-[#3f4a5a]" style={{ left: START_W, width: L * LW }}>
            <div className="absolute inset-0 opacity-30 [background-image:radial-gradient(#0003_1px,transparent_1px)] [background-size:6px_6px]" />
          </div>
          {Array.from({ length: L }, (_, idx) => {
            const n = idx + 1, done = n <= lane, isNext = n === lane + 1 && inRound, up = idx % 2 === 1;
            const visible = idx >= firstLane - 1 && idx <= lastLane + 1;
            const stopped = n <= blocked;
            return (
              <div key={idx} className="absolute inset-y-0" style={{ left: START_W + idx * LW, width: LW }}>
                {idx > 0 && <div className="absolute inset-y-0 left-0 w-[3px] -translate-x-1/2 [background-image:linear-gradient(#f8fafc_55%,transparent_55%)] [background-size:3px_34px] opacity-80" />}
                {isNext && <div className="absolute inset-0 bg-yellow-300/10 shadow-[inset_0_0_30px_rgba(253,224,71,0.35)]" />}
                {done && <div className="absolute inset-0 bg-emerald-400/10" />}
                <button type="button" onClick={isNext ? go : undefined} disabled={!isNext || !goEnabled} aria-label={`Lane ${n}: ${fmtX(table.mults[idx])}`}
                  className={`absolute left-1/2 top-1/2 z-[5] -translate-x-1/2 -translate-y-1/2 ${isNext && goEnabled ? 'cursor-pointer animate-pulse' : 'cursor-default'}`} style={{ width: LW * 0.66, height: LW * 0.66 }}>
                  <Manhole label={fmtX(table.mults[idx])} state={done ? 'done' : isNext ? 'next' : 'ahead'} />
                </button>
                {visible && !stopped && strike?.lane !== n && <Traffic idx={idx} diff={roundDiff} height={H_ROAD} />}
                {stopped && (
                  <>
                    <div key={`b${n}-${blocked >= n}`} className="ck-barrier absolute left-[6%] z-[6] w-[88%]" style={up ? { bottom: '12%', height: LW * 0.34 } : { top: '12%', height: LW * 0.34 }}><Barrier /></div>
                    <div className="absolute left-1/2 z-[4] -translate-x-1/2 scale-[.7] sm:scale-[.85]" style={up ? { bottom: '-6%' } : { top: '-14%' }}><Vehicle kind={VEHICLE_KINDS[idx % VEHICLE_KINDS.length]} colour={VEHICLE_COLOURS[idx % VEHICLE_COLOURS.length]} up={up} /></div>
                  </>
                )}
                {strike?.lane === n && !strike.pending && (
                  <div key={strike.id} className="absolute left-1/2 top-0 z-[20] -ml-[24px] w-[48px]" style={{ '--h': `${H_ROAD}px`, animation: `${strike.up ? 'ck-strike-up' : 'ck-strike-down'} .56s cubic-bezier(.35,0,.85,1) forwards` }}>
                    <div className="mx-auto w-fit"><Vehicle kind={strike.kind} colour={strike.colour} up={strike.up} /></div>
                  </div>
                )}
              </div>
            );
          })}
          {/* finish */}
          <div className="absolute inset-y-0 bg-[linear-gradient(90deg,#94a3b8_0%,#cbd5e1_40%,#4ade80_41%,#22c55e_100%)]" style={{ left: START_W + L * LW, width: END_W }}>
            <div className="absolute left-[46%] top-1/2 -translate-y-1/2 rounded-lg bg-gradient-to-b from-yellow-200 to-amber-500 px-2 py-1 text-center font-display text-sm leading-tight text-amber-950 shadow-lg ring-2 ring-white">SAFE<br /><span className="text-xs">{fmtX(table.mults[L - 1])}</span></div>
          </div>
          {/* chicken */}
          <div className={`absolute z-[10] ck-pose-${pose}`} style={{ left: chickenX - LW * 0.5, top: H_ROAD / 2 - LW * 0.62, width: LW, height: LW, transition: walkTo != null || phase === 'cashed' ? 'left .45s linear' : 'left .3s ease-out' }}>
            <svg viewBox="0 0 100 100" className="h-full w-full overflow-visible drop-shadow-[0_4px_4px_rgba(0,0,0,0.35)]" role="img" aria-label={`Chicken, ${STATUS[phase].toLowerCase()}`}><Chicken goldHat={pose === 'victory'} /></svg>
            {pose === 'hit' && <Feathers id={strike?.id} />}
            {pose === 'happy' && <Burst key={`h${lane}`} game="chicken" n={8} spread={50} />}
          </div>
        </div>
        {/* tension vignette grows as the chicken goes further */}
        <div className="pointer-events-none absolute inset-0 transition-opacity duration-700" style={{ opacity: inRound ? Math.min(0.75, progress * 0.9) : 0, background: 'radial-gradient(ellipse at center, transparent 45%, rgba(220,38,38,0.55) 100%)' }} />
      </div>

      {/* HUD */}
      <div className="pointer-events-none absolute inset-x-0 top-2 z-[30] flex flex-col items-center">
        <div className="rounded-2xl bg-black/65 px-4 py-1 text-center shadow-lg ring-1 ring-white/15 backdrop-blur-sm">
          <div className="text-[10px] font-bold uppercase tracking-wider text-white/60">{lane ? 'Multiplier' : TABLES[roundDiff].label}</div>
          <div key={lane} className={`font-display text-4xl leading-none tabular-nums sm:text-5xl ${lane ? 'ck-multpop' : ''} ${multClass(shownMult)}`}>{lane ? fmtX(shownMult) : '1.00x'}</div>
          {inRound && <div className="mt-0.5 text-[11px] font-semibold text-white/85">{nextMult ? <>Next <b className="text-yellow-200">{fmtX(nextMult)}</b> · {Math.round(nextChance * 100)}% safe</> : 'Last lane crossed!'}</div>}
        </div>
      </div>
      <div className="pointer-events-none absolute bottom-2 left-2 z-[30] rounded-md bg-black/60 px-2 py-1 text-[11px] font-bold text-white ring-1 ring-white/10">Lane {lane}/{L}</div>
      <div className={`pointer-events-none absolute bottom-2 right-2 z-[30] rounded-md px-2 py-1 text-[11px] font-bold ring-1 ${phase === 'hit' || phase === 'over' ? 'bg-red-600/85 text-white ring-red-300' : phase === 'cashed' ? 'bg-emerald-500/85 text-white ring-emerald-200' : 'bg-black/60 text-white ring-white/10'}`}>{STATUS[phase]}</div>
      {flash && <div key={flash.id} className={`ck-flash pointer-events-none absolute inset-0 z-[25] ${flash.cls}`} />}
      {burst > 0 && <div key={burst} className="pointer-events-none absolute left-1/2 top-1/3 z-[26]"><Burst game="chicken" n={30} spread={160} /></div>}

      {/* result screens */}
      {result && (phase === 'cashed' || phase === 'over') && (
        <div className="absolute inset-0 z-[40] flex items-center justify-center bg-black/45 p-3 backdrop-blur-[2px]">
          <div className={`p3-intro-pop w-full max-w-xs rounded-2xl p-4 text-center shadow-2xl ring-2 ${result.type === 'win' ? 'bg-gradient-to-b from-emerald-600 to-emerald-900 ring-emerald-300' : 'bg-gradient-to-b from-red-700 to-red-950 ring-red-300'}`}>
            <div className="font-display text-3xl text-white drop-shadow">{result.type === 'win' ? (result.all ? 'MADE IT ACROSS!' : 'CASHED OUT!') : 'SPLAT!'}</div>
            {result.type === 'win' ? (
              <dl className="mt-2 grid grid-cols-3 gap-1 text-white">
                <div className="rounded-lg bg-black/25 p-1.5"><dt className="text-[10px] uppercase text-white/70">Bet</dt><dd className="font-cond text-lg font-bold tabular-nums">{money(result.bet)}</dd></div>
                <div className="rounded-lg bg-black/25 p-1.5"><dt className="text-[10px] uppercase text-white/70">Multiplier</dt><dd className="font-cond text-lg font-bold tabular-nums text-yellow-200">{fmtX(result.mult)}</dd></div>
                <div className="rounded-lg bg-black/25 p-1.5"><dt className="text-[10px] uppercase text-white/70">Payout</dt><dd className="font-cond text-lg font-bold tabular-nums text-yellow-200">{money(result.payout)}</dd></div>
              </dl>
            ) : (
              <p className="mt-1 text-sm text-white/90">Hit in lane {result.lane}. Lost {money(result.bet)}.{result.reached ? ` You could have cashed out at ${fmtX(result.reached)}.` : ''}</p>
            )}
            <button type="button" onClick={() => { fx.click(); reset(); }} className="pointer-events-auto mt-3 w-full rounded-full bg-white py-2 font-extrabold text-slate-900 shadow active:scale-95">Play again</button>
          </div>
        </div>
      )}
    </div>
  );

  const bar = (
    <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
      <div className="grid grid-cols-4 gap-1" role="radiogroup" aria-label="Difficulty">
        {DIFF_IDS.map((d) => (
          <button key={d} type="button" role="radio" aria-checked={diff === d} disabled={inRound} onClick={() => { fx.click(); setDiff(d); setRoundDiff(d); save('ck_diff', d); if (result) reset(); }}
            className={`rounded-lg px-1 py-1.5 text-center leading-tight transition ${diff === d ? `bg-gradient-to-b ${DIFF_STYLE[d]} shadow ring-2 ring-white/70` : 'bg-navy-800 text-slate-300 hover:bg-navy-700'} disabled:opacity-60`}>
            <div className="text-xs font-extrabold">{TABLES[d].label}</div>
            <div className="text-[9px] opacity-80">{TABLES[d].lanes} lanes · up to {fmtX(TABLES[d].mults[TABLES[d].lanes - 1]).replace('.00', '')}</div>
          </button>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <div className="flex items-center rounded-lg bg-navy-800 ring-1 ring-navy-600">
          <button className="h-10 w-9 text-lg text-slate-200 disabled:opacity-40" disabled={inRound} onClick={() => setBet(stake - (stake > 1000 ? 100 : 10))} aria-label="Lower bet">−</button>
          <label className="flex items-center gap-0.5 text-sm font-bold text-white">£
            <input inputMode="decimal" aria-label="Bet amount" className="w-16 bg-transparent py-2 text-center font-cond text-lg font-bold tabular-nums outline-none" value={betText} disabled={inRound}
              onChange={(e) => setBetText(e.target.value.replace(/[^\d.]/g, ''))} onBlur={() => { const v = Math.round(parseFloat(betText || '0') * 100); setBet(Number.isFinite(v) ? v : stake); }}
              onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }} />
          </label>
          <button className="h-10 w-9 text-lg text-slate-200 disabled:opacity-40" disabled={inRound} onClick={() => setBet(stake + (stake >= 1000 ? 100 : 10))} aria-label="Raise bet">+</button>
        </div>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={inRound} onClick={() => setBet(stake / 2)}>½</button>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={inRound} onClick={() => setBet(stake * 2)}>2×</button>
        <button className="rounded-lg bg-navy-700 px-2.5 py-2 text-xs font-bold text-slate-200 disabled:opacity-40" disabled={inRound} onClick={() => setBet(Math.min(rules.maxStake, Math.max(rules.minStake, balance)))}>Max</button>
        <div className="ml-auto text-right text-[11px] leading-tight text-slate-400">
          <div>Balance <b className="tabular-nums text-slate-100">{money(balance)}</b></div>
          <div>{inRound && lane ? 'Cash out now' : inRound ? 'Win if you reach next' : 'Win after lane 1'} <b className="tabular-nums text-yellow-200">{money(inRound && lane ? potential : inRound ? Math.floor(bet * (nextMult || 0)) : Math.floor(stake * TABLES[diff].mults[0]))}</b></div>
        </div>
      </div>
      {inRound ? (
        <div className="grid grid-cols-2 gap-2">
          <button onClick={go} disabled={!goEnabled} className="btn h-14 rounded-full bg-gradient-to-b from-sky-300 to-blue-600 text-lg font-extrabold text-white shadow-lg active:scale-95 disabled:opacity-60">
            {phase === 'crossing' ? 'Crossing…' : phase === 'placing' || phase === 'starting' ? 'Get ready…' : <>GO <span className="text-sm font-bold opacity-90">→ {nextMult ? fmtX(nextMult) : ''}</span></>}
          </button>
          <button onClick={cashout} disabled={!cashEnabled} className="btn h-14 rounded-full bg-gradient-to-b from-yellow-200 to-amber-500 text-lg font-extrabold leading-tight text-amber-950 shadow-lg ring-2 ring-yellow-100/70 active:scale-95 disabled:opacity-50">
            {lane ? <>Cash out<div className="text-sm tabular-nums">{money(potential)}</div></> : <span className="text-sm">Cross a lane to cash out</span>}
          </button>
        </div>
      ) : (
        <button onClick={start} disabled={!canStart} className="btn h-14 w-full rounded-full bg-gradient-to-b from-emerald-300 to-emerald-600 text-lg font-extrabold text-emerald-950 shadow-lg active:scale-95">
          {stake > balance ? 'Not enough balance' : `Start game · ${money(stake)}`}
        </button>
      )}
    </div>
  );

  const recent = view?.recent || [];
  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to play</h3>
        <ol className="list-decimal space-y-1 pl-5">
          <li>Choose a difficulty and a bet, then press <b>Start game</b>. The bet is taken from your balance.</li>
          <li>Press <b>GO</b> (or tap the glowing lane, or press space) to cross the next lane. Each safe lane raises the multiplier.</li>
          <li><b>Cash out</b> at any time after a safe lane to win bet × multiplier. Reach the far side and you're paid automatically.</li>
          <li>If a vehicle hits the chicken, the round ends and the bet is lost.</li>
        </ol>
        <p className="text-xs">Each lane is decided on the server with a cryptographically secure random number only when you press GO. Closing or refreshing the page leaves the round exactly where it was.</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Difficulties</h3>
        <p className="text-xs">Each difficulty has its own road length and its own chance of being hit in each lane. The risk rises a little with every lane. Multipliers are worked out from those chances so that cashing out after any lane returns {Math.round(RTP * 100)}% on average (rounded down to the penny).</p>
        {DIFF_IDS.map((d) => {
          const t = TABLES[d];
          let p = 1;
          return (
            <details key={d} className="rounded-lg bg-navy-800 p-2" open={d === diff}>
              <summary className="cursor-pointer text-sm font-bold text-white">{t.label}: {t.lanes} lanes · first lane {Math.round((1 - t.risks[0]) * 100)}% safe · top {fmtX(t.mults[t.lanes - 1])}</summary>
              <div className="mt-2 max-h-56 overflow-auto">
                <table className="w-full text-right text-[11px] tabular-nums">
                  <thead className="sticky top-0 bg-navy-800 text-slate-400"><tr><th className="text-left">Lane</th><th>Safe chance</th><th>Reach from start</th><th>Multiplier</th></tr></thead>
                  <tbody>{t.risks.map((r, i) => { p *= 1 - r; return <tr key={i} className="border-t border-navy-700"><td className="text-left">{i + 1}</td><td>{((1 - r) * 100).toFixed(1)}%</td><td>{p < 0.001 ? (p * 100).toFixed(4) : (p * 100).toFixed(2)}%</td><td className="text-white">{fmtX(t.mults[i])}</td></tr>; })}</tbody>
                </table>
              </div>
            </details>
          );
        })}
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Maths</b>: return {Math.round(RTP * 100)}% whichever lane you cash out at (configurable). Bets from {money(rules.minStake)} to {money(rules.maxStake)}. Results are decided by the server before the chicken moves; tapping, timing or reloading can't change them.
      </section>
      <section className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3 text-xs text-slate-300">
        <b className="text-amber-200">About this game</b>: Cluck Crossing is an original game inspired by the road-crossing format of InOut Games' <i>Chicken Road</i>. Art, sound, risk tables and multipliers are our own.
      </section>
    </>
  );

  const historyPanel = (
        <SidePanel title="Recent rounds">
      {recent.length ? (
        <ul className="max-h-[420px] space-y-1 overflow-auto text-[11px]">
          {recent.map((r, k) => (
            <li key={k} className={`rounded-md border-l-4 px-2 py-1 ${r.result === 'hit' ? 'border-red-500 bg-red-500/10' : 'border-emerald-400 bg-emerald-500/10'}`}>
              <div className="flex justify-between gap-2"><span className="font-semibold text-white">{money(r.bet)} · {TABLES[r.difficulty]?.label}</span><b className={r.result === 'hit' ? 'text-red-300' : 'text-emerald-300'}>{r.result === 'hit' ? `−${money(r.bet)}` : `+${money(r.payout)}`}</b></div>
              <div className="flex justify-between gap-2 text-slate-400"><span>{r.result === 'hit' ? `Hit in lane ${r.lane}` : r.result === 'finish' ? `Crossed all ${r.lanes}` : `Cashed out at ${fmtX(r.mult)}`}{r.result !== 'hit' ? '' : r.reached ? ` (had ${fmtX(r.reached)})` : ''}</span><span>{when(r.at)}</span></div>
            </li>
          ))}
        </ul>
      ) : <div className="text-xs text-slate-500">No rounds yet.</div>}
    </SidePanel>
  );

  return (
    <PremiumShell game="chicken" title="Cluck Crossing" rtp={`${Math.round(RTP * 100)}%`} tagline="Cross the road · 4 difficulties · cash out any time" shake={shake}
      stageClass="border-2 border-yellow-300/50 shadow-[0_0_50px_rgba(253,224,71,0.2)]"
      bg={<div className="absolute inset-0 bg-gradient-to-b from-sky-900 via-slate-900 to-slate-950" />}
      below={<>{bar}<div className="pop-hide mt-3 lg:hidden">{historyPanel}</div></>} info={info}
      side={<>
        {historyPanel}
      </>}>
      <div className="pt-1">{stage}</div>
    </PremiumShell>
  );
}

const inRoundOf = (p) => ['placing', 'starting', 'crossing', 'safe', 'ready'].includes(p);
