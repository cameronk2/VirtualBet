// Golden Wishes – Genie's Treasure. Twelve treasures; each pick asks the
// server to turn over the next treasure in the board it dealt when the bonus
// began. Three matching jewels win that jackpot, plus every prize found and
// the multiplier. The rest of the board is shown at the end.
import { useEffect, useState } from 'react';
import { TREASURE_OBJECTS } from '../../../components/SlotArtGenie.jsx';
import { money } from '../../../lib/format.js';
import { JACKPOTS, JP_NAME } from '../../../../../server/games/genie/config.js';

export const JP_STYLE = {
  MINI: { c: '#34d399', grad: 'from-emerald-200 via-emerald-500 to-emerald-900', ring: 'ring-emerald-300', text: 'text-emerald-950', fill: 'url(#gnEmerald)' },
  MINOR: { c: '#60a5fa', grad: 'from-sky-200 via-blue-500 to-blue-950', ring: 'ring-sky-300', text: 'text-blue-950', fill: 'url(#gnSapph)' },
  MAJOR: { c: '#fb7185', grad: 'from-rose-200 via-rose-600 to-rose-950', ring: 'ring-rose-300', text: 'text-rose-950', fill: 'url(#gnRuby)' },
  GRAND: { c: '#facc15', grad: 'from-yellow-100 via-amber-400 to-fuchsia-900', ring: 'ring-yellow-200', text: 'text-amber-950', fill: 'url(#gnGold)' },
};

export function Jewel({ jp, className = 'h-full w-full' }) {
  const st = JP_STYLE[jp];
  return (
    <svg viewBox="0 0 100 100" className={className} aria-label={`${JP_NAME[jp]} jewel`}>
      <circle cx="50" cy="44" r="38" fill="url(#gnGlow)" opacity=".5" />
      <path d="M50 10L80 34L50 78L20 34Z" fill={st.fill} stroke="#fff" strokeWidth="1.5" />
      <path d="M20 34H80M35 34L50 10L65 34L50 78L35 34" fill="none" stroke="#fff" strokeOpacity=".6" strokeWidth="1" />
      <rect x="16" y="78" width="68" height="17" rx="8" fill="#1e0b3b" stroke={st.c} strokeWidth="2" />
      <text x="50" y="91" textAnchor="middle" fontFamily="'Cinzel', Georgia, serif" fontWeight="900" fontSize="12" fill={st.c}>{jp}</text>
    </svg>
  );
}

function Face({ item, bet }) {
  if (!item) return null;
  if (item.k === 'JP') return <Jewel jp={item.v} />;
  if (item.k === 'MULT') return <div className="flex h-full w-full flex-col items-center justify-center rounded-xl bg-[radial-gradient(circle,#e879f9,#6b21a8)] font-cond font-extrabold text-white shadow-[0_0_16px_#e879f9]"><span className="text-3xl leading-none">×{item.v}</span><span className="text-[9px] uppercase tracking-widest">multiplier</span></div>;
  return (
    <div className="flex h-full w-full flex-col items-center justify-center">
      <div className="flex h-[62%] w-[62%] items-center justify-center rounded-full bg-[radial-gradient(circle_at_35%_30%,#fffbeb,#fde047_40%,#b45309)] font-cond text-lg font-extrabold text-amber-950 shadow-[0_0_12px_#facc15]">{item.v}x</div>
      <div className="mt-0.5 font-cond text-xs font-bold tabular-nums text-amber-100">{money(item.v * bet)}</div>
    </div>
  );
}

export default function Treasure({ data, bet, fx, request, lock, wait, onProgress, onComplete }) {
  const [picks, setPicks] = useState(() => data?.picks || {});
  const [opening, setOpening] = useState(null);
  const [rest, setRest] = useState(null);
  const [won, setWon] = useState(null);
  const [tot, setTot] = useState({ cashX: data?.cashX || 0, mult: data?.mult || 1, jp: data?.jp || {} });
  const busy = opening != null || !!won;
  useEffect(() => { onProgress?.(tot.jp); }, [tot.jp]); // eslint-disable-line react-hooks/exhaustive-deps

  const pick = (tile) => lock(async () => {
    if (picks[tile] || busy) return;
    fx.pick(); setOpening(tile);
    const out = await request(tile);
    if (!out) { setOpening(null); return; }
    await wait(380);
    const item = out.item;
    setPicks((p) => ({ ...p, [tile]: item })); setOpening(null);
    setTot({ cashX: out.cashX, mult: out.mult, jp: out.jp });
    if (item.k === 'JP') fx.jewel(out.jp[item.v], ['MINI', 'MINOR', 'MAJOR', 'GRAND'].indexOf(item.v));
    else if (item.k === 'MULT') fx.mult(3); else fx.cash();
    if (out.treasureDone) {
      setWon(out.treasureDone.won);
      fx.drumroll(0.9); await wait(1200);
      setRest(out.rest); await wait(1300);
      onComplete(out);
    }
  });

  const near = Object.entries(tot.jp).filter(([, n]) => n === 2).map(([k]) => k);
  return (
    <div className="relative">
      <div className="mb-1.5 flex items-center justify-between gap-2 px-1">
        <div className="font-[Cinzel,Georgia,serif] text-sm font-black tracking-wide text-amber-200 sm:text-base">Genie&apos;s Treasure</div>
        <div className="flex gap-1.5 text-[11px] font-bold">
          <span className="rounded-full bg-black/55 px-2 py-0.5 text-amber-100 ring-1 ring-amber-300/40">Prizes {money(tot.cashX * bet)}</span>
          <span className={`rounded-full px-2 py-0.5 ring-1 ${tot.mult > 1 ? 'bg-fuchsia-600 text-white ring-fuchsia-300' : 'bg-black/55 text-fuchsia-200 ring-fuchsia-300/40'}`}>×{tot.mult}</span>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
        {Array.from({ length: 12 }, (_, i) => {
          const item = picks[i] || rest?.[i];
          const unpicked = !picks[i] && rest?.[i];
          const match = won && picks[i]?.k === 'JP' && picks[i].v === won;
          return (
            <button key={i} type="button" disabled={!!item || busy} onClick={() => pick(i)} aria-label={item ? `Treasure ${i + 1}: ${item.k === 'JP' ? `${item.v} jewel` : item.k === 'MULT' ? `multiplier ${item.v}` : `${item.v}x prize`}` : `Open treasure ${i + 1}`}
              className={`relative aspect-square rounded-xl p-1 transition ${item ? 'bg-black/45' : 'bg-gradient-to-b from-violet-700/80 to-indigo-950/90 ring-1 ring-amber-300/50 hover:ring-amber-200 active:scale-95'} ${match ? 'ring-4 ring-yellow-200 shadow-[0_0_24px_#facc15]' : ''} ${unpicked ? 'opacity-45 grayscale-[.4]' : ''}`}>
              {item ? <div className={picks[i] && !unpicked ? 'gn-reveal h-full w-full' : 'h-full w-full'}><Face item={item} bet={bet} /></div>
                : <svg viewBox="0 0 100 100" className={`h-full w-full ${opening === i ? 'gn-shake' : 'gn-float'}`} style={{ animationDelay: `${(i % 4) * 0.3}s` }} aria-hidden="true">{TREASURE_OBJECTS[(i + Math.floor(i / 4)) % 4]}</svg>}
            </button>
          );
        })}
      </div>
      <div className="mt-1.5 min-h-5 text-center text-xs font-semibold text-amber-100/90">
        {won ? `Three ${JP_NAME[won]} jewels! ${JP_NAME[won]} jackpot ${money(JACKPOTS[won] * bet)}` : near.length ? `One more ${near.map((k) => JP_NAME[k]).join(' or ')} jewel wins that jackpot` : 'Pick treasures until three jewels match'}
      </div>
    </div>
  );
}
