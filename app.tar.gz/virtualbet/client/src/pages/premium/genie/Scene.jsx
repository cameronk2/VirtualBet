// Golden Wishes – background: night sky over a golden palace, twinkling
// stars, drifting genie smoke and floating golden motes. Free spins and
// Genie's Treasure shift the palette. Particle counts are kept small for phones.
import { useMemo } from 'react';
import { reduceMotion } from '../../../components/Premium.jsx';

const SKY = {
  base: 'linear-gradient(180deg,#12052b 0%,#3b0764 45%,#831843 78%,#b45309 100%)',
  free: 'linear-gradient(180deg,#020617 0%,#1e1b4b 40%,#0e7490 85%,#14b8a6 100%)',
  treasure: 'linear-gradient(180deg,#1c0a02 0%,#451a03 40%,#a16207 85%,#facc15 100%)',
};

export default function Scene({ mode = 'base' }) {
  const small = typeof window !== 'undefined' && window.innerWidth < 640;
  const stars = useMemo(() => Array.from({ length: small ? 22 : 40 }, (_, i) => ({ x: (i * 37 + 7) % 100, y: (i * 53 + 11) % 55, d: `${(i % 7) * 0.35}s`, s: i % 5 ? 1.5 : 2.5 })), [small]);
  const motes = useMemo(() => Array.from({ length: reduceMotion ? 0 : small ? 10 : 18 }, (_, i) => ({ x: (i * 41 + 9) % 100, d: `${-(i * 0.9) % 9}s`, t: `${7 + (i % 5) * 1.6}s`, dx: `${((i % 3) - 1) * 30}px` })), [small]);
  const smoke = useMemo(() => Array.from({ length: reduceMotion ? 0 : small ? 3 : 5 }, (_, i) => ({ x: 10 + i * 20, d: `${-i * 2.4}s`, t: `${11 + i * 1.5}s`, dx: `${(i % 2 ? 1 : -1) * 40}px`, w: 120 + (i % 3) * 50 })), [small]);
  return (
    <div className="absolute inset-0 overflow-hidden transition-[background] duration-700" style={{ background: SKY[mode] || SKY.base }}>
      {stars.map((s, i) => <span key={i} className="gn-twinkle absolute rounded-full bg-white" style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s, animationDelay: s.d }} />)}
      <div className="absolute left-1/2 top-[58%] h-40 w-40 -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(253,230,138,.35),transparent_65%)] sm:h-72 sm:w-72" />
      {/* palace silhouette */}
      <svg viewBox="0 0 400 120" preserveAspectRatio="xMidYMax slice" className="absolute inset-x-0 bottom-0 h-[38%] w-full opacity-80" aria-hidden="true">
        <defs><linearGradient id="gnPal" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#facc15" stopOpacity=".55" /><stop offset="1" stopColor="#1e0b3b" stopOpacity=".95" /></linearGradient></defs>
        <path d="M0 120V92h30V70c0-10 12-18 12-30 0 12 12 20 12 30v22h30V60c0-22 30-30 30-50 0 20 30 28 30 50v32h18V40c0-6 6-10 6-18 0 8 6 12 6 18v52h20V54c0-26 38-34 38-54 0 20 38 28 38 54v38h20V40c0-6 6-10 6-18 0 8 6 12 6 18v52h18V60c0-22 30-30 30-50 0 20 30 28 30 50v32h30V70c0-10 12-18 12-30 0 12 12 20 12 30v22h0v28z" fill="url(#gnPal)" />
        {[60, 150, 196, 250, 340].map((x, i) => <rect key={i} x={x} y={96} width="6" height="10" rx="3" fill="#fde68a" opacity=".7" />)}
      </svg>
      {smoke.map((s, i) => <span key={i} className="gn-smoke" style={{ left: `${s.x}%`, bottom: '-10%', width: s.w, height: s.w, animationDelay: s.d, animationDuration: s.t, '--dx': s.dx }} />)}
      {motes.map((m, i) => <span key={i} className="gn-mote" style={{ left: `${m.x}%`, bottom: 0, animationDelay: m.d, animationDuration: m.t, '--dx': m.dx }} />)}
    </div>
  );
}
