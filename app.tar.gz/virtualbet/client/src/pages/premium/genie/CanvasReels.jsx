// Golden Wishes – the reels drawn on a canvas (the "enhanced graphics" mode).
// Motion-blurred spinning strips, physics-style stops with overshoot and
// settle, landing bursts for lamps, stars and genies, glowing pulsing wins,
// light-trail paylines, a towering genie for expanding wilds, anticipation
// sparks and coin rain. Purely presentation: results come in from Genie.jsx.
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { ease, fitCanvas, lerp, loop, Particles, reducedMotion, rnd, roundRect, Tweens } from '../../../lib/fx2d.js';
import { LINES } from '../../../../../server/games/genie/config.js';
import { genieTextures, SPECIAL_STYLE, TIER, TIER_SCALE } from './textures.jsx';

const COLS = 5, ROWS = 3;
const POOL = ['GENIE', 'A', 'PRINCESS', 'K', 'LAMP', 'PALACE', 'Q', 'CHEST', 'J', 'CROWN', 'STAR', 'T', 'AMETHYST', 'EMERALD', 'RUBY', 'A', 'K', 'Q', 'J', 'T'];
const LINE_COLOURS = ['#fde047', '#f472b6', '#5eead4', '#a78bfa', '#fb923c', '#4ade80', '#60a5fa', '#f87171', '#facc15', '#e879f9', '#2dd4bf', '#c084fc', '#fdba74', '#86efac', '#93c5fd', '#fca5a5', '#fef08a', '#f0abfc', '#99f6e4', '#d8b4fe'];
const randSym = () => POOL[Math.floor(Math.random() * POOL.length)];

function CanvasReels({ grid, lit, trig, wins, lineShow, expanding = [], coins = 0, tease = [], turbo, onFail }, ref) {
  const wrap = useRef(null), canvas = useRef(null);
  const S = useRef(null);
  const [ready, setReady] = useState(false);
  if (!S.current) {
    S.current = {
      tex: null, tw: new Tweens(), parts: new Particles(reducedMotion() ? 0 : 420), t: 0,
      reels: Array.from({ length: COLS }, (_, r) => ({ syms: [randSym(), ...grid[r], randSym()], off: 0, v: 0, state: 'idle', queue: [], onLand: null, settle: 0, blurV: 0 })),
      lay: null, pop: {}, lit: null, trig: null, wins: null, lineShow: null, lineK: 1, expand: {}, tease: [], dimK: 0, turbo: false,
    };
  }
  const st = S.current;
  st.lit = lit; st.trig = trig; st.wins = wins; st.lineShow = lineShow; st.tease = tease; st.turbo = turbo;

  // layout: reels fill the wrapper width; the canvas extends past it so effects can spill over the frame
  useEffect(() => {
    const el = wrap.current;
    const fit = () => {
      const W = el.clientWidth; if (!W) return;
      const gap = Math.max(3, W * 0.012), col = (W - gap * (COLS - 1)) / COLS, H = col * ROWS;
      el.style.height = `${H}px`;
      const mx = W * 0.06, my = W * 0.12;
      const c = canvas.current;
      c.style.left = `${-mx}px`; c.style.top = `${-my}px`;
      st.g = fitCanvas(c, W + mx * 2, H + my * 2);
      st.lay = { W, H, gap, col, mx, my };
    };
    const ro = new ResizeObserver(fit); ro.observe(el); fit();
    return () => ro.disconnect();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    let stop = () => {}, alive = true;
    genieTextures().then((tex) => {
      if (!alive) return;
      st.tex = tex; setReady(true);
      stop = loop((dt, now) => frame(dt, now));
    }).catch(() => onFail?.());
    return () => { alive = false; stop(); st.tw.clear(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // a grid change while idle (start, resume, expanding wilds) shows directly
  useEffect(() => {
    st.reels.forEach((rl, r) => { if (rl.state === 'idle') { rl.syms = [rl.syms[0], ...grid[r], rl.syms[4]]; rl.off = 0; } });
  }, [grid]); // eslint-disable-line react-hooks/exhaustive-deps

  // expanding genies: the tall genie rises over the reel with smoke
  useEffect(() => {
    const now = {};
    expanding.forEach((r) => {
      now[r] = st.expand[r] || { k: 0 };
      if (!st.expand[r]) {
        st.tw.add({ dur: 650, ease: ease.outBack, update: (v) => { now[r].k = v; } });
        const L = st.lay; if (!L || !st.tex) return;
        const x = L.mx + r * (L.col + L.gap) + L.col / 2;
        for (let i = 0; i < 26; i++) st.parts.add({ x: x + rnd(-L.col * 0.4, L.col * 0.4), y: L.my + L.H * rnd(0.4, 1), vx: rnd(-30, 30), vy: rnd(-160, -40), life: rnd(0.8, 1.5), size: rnd(L.col * 0.5, L.col * 1.1), grow: L.col * 0.6, tex: i % 2 ? st.tex.smoke : st.tex.smokeViolet, add: false, alpha: 0.55 });
        for (let i = 0; i < 18; i++) st.parts.add({ x, y: L.my + L.H * rnd(0.1, 0.9), vx: rnd(-140, 140), vy: rnd(-140, 60), drag: 1.5, life: rnd(0.5, 1), size: rnd(8, 20), tex: st.tex.sparkTeal });
      }
    });
    st.expand = now;
  }, [expanding.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps

  // winning cells: sparks fly out
  useEffect(() => {
    if (!lit?.size || !st.lay || !st.tex) return;
    st.tw.add({ dur: 350, update: (v) => { st.dimK = v; } });
    const L = st.lay;
    lit.forEach((k) => {
      const [r, row] = k.split('-').map(Number);
      const { x, y } = centre(r, row);
      for (let i = 0; i < 9; i++) { const a = rnd(0, Math.PI * 2), sp = rnd(60, 220); st.parts.add({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, drag: 2.2, life: rnd(0.5, 1), size: rnd(L.col * 0.08, L.col * 0.2), tex: i % 3 ? st.tex.spark : st.tex.dot, vr: rnd(-4, 4) }); }
    });
  }, [lit]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!lit?.size && !trig?.size) st.dimK = 0; }, [lit, trig]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { st.lineK = 0; st.tw.add({ dur: 420, ease: ease.outCubic, update: (v) => { st.lineK = v; } }); }, [lineShow, wins]); // eslint-disable-line react-hooks/exhaustive-deps

  // coin rain
  useEffect(() => {
    if (!coins || !st.lay || !st.tex) return;
    const L = st.lay;
    for (let i = 0; i < 34; i++) st.parts.add({ x: L.mx + rnd(0, L.W), y: rnd(-L.my * 0.2, L.my * 0.8), vx: rnd(-40, 40), vy: rnd(-120, 40), ay: L.H * 2.2, life: rnd(1.1, 1.8), size: rnd(L.col * 0.18, L.col * 0.3), tex: st.tex.coin, add: false, flip: rnd(6, 14), vr: rnd(-1, 1) });
  }, [coins]); // eslint-disable-line react-hooks/exhaustive-deps

  function centre(r, row) {
    const L = st.lay;
    return { x: L.mx + r * (L.col + L.gap) + L.col / 2, y: L.my + row * L.col + L.col / 2 };
  }

  function landBurst(r, cells) {
    const L = st.lay; if (!L || !st.tex) return;
    cells.forEach((s, row) => {
      if (!['LAMP', 'STAR', 'GENIE'].includes(s)) return;
      const { x, y } = centre(r, row);
      const tex = s === 'GENIE' ? st.tex.sparkTeal : s === 'STAR' ? st.tex.sparkPink : st.tex.spark;
      for (let i = 0; i < 14; i++) { const a = (i / 14) * Math.PI * 2; st.parts.add({ x, y, vx: Math.cos(a) * L.col * 1.6, vy: Math.sin(a) * L.col * 1.6, drag: 3, life: 0.7, size: L.col * 0.16, tex }); }
      st.parts.add({ x, y, life: 0.5, size: L.col * 0.6, grow: L.col * 3, tex: s === 'GENIE' ? st.tex.dotTeal : s === 'STAR' ? st.tex.dotPink : st.tex.dot, alpha: 0.8 });
    });
  }

  useImperativeHandle(ref, () => ({
    ready: () => !!st.tex,
    spin() {
      st.dimK = 0; st.pop = {};
      st.reels.forEach((rl, r) => {
        rl.state = 'spin'; rl.queue = []; rl.v = 0; rl.wind = 0.09 + r * 0.025;
      });
    },
    /** Bring reel r to a stop on `cells`; resolves when the symbols hit the line. */
    stop(r, cells) {
      const rl = st.reels[r];
      return new Promise((res) => {
        rl.queue = [cells[2], cells[1], cells[0], randSym()];
        rl.state = 'stopping'; rl.final = cells;
        rl.onLand = () => { landBurst(r, cells); cells.forEach((sym, row) => { if (SPECIAL_STYLE[sym]) st.pop[`${r}-${row}`] = st.t; }); res(); };
      });
    },
    stopNow(g) { st.reels.forEach((rl, r) => { rl.state = 'idle'; rl.v = 0; rl.off = 0; rl.syms = [randSym(), ...g[r], randSym()]; }); },
  }));

  function frame(dt, now) {
    const g = st.g, L = st.lay, T = st.tex;
    if (!g || !L || !T) return;
    st.t = now;
    st.tw.step(dt);
    const vmax = L.col * (st.turbo ? 30 : 21);
    // reel motion
    st.reels.forEach((rl, r) => {
      if (rl.state === 'spin' || rl.state === 'stopping') {
        if (rl.wind > 0) { rl.wind -= dt; rl.off = Math.max(-L.col * 0.14, rl.off - L.col * 1.6 * dt); return; }
        rl.v = Math.min(vmax, rl.v + vmax * 7 * dt);
        rl.off += rl.v * dt;
        while (rl.off >= L.col) {
          rl.off -= L.col;
          const next = rl.state === 'stopping' && rl.queue.length ? rl.queue.shift() : randSym();
          rl.syms.unshift(next); rl.syms.pop();
          if (rl.state === 'stopping' && !rl.queue.length) {
            rl.state = 'settle';
            const from = rl.off, over = L.col * (st.turbo ? 0.12 : 0.2);
            rl.onLand?.(); rl.onLand = null;
            st.tw.add({ dur: st.turbo ? 50 : 90, ease: ease.outQuad, update: (v) => { rl.off = lerp(from, over, v); } })
              .then(() => st.tw.add({ dur: st.turbo ? 160 : 300, ease: ease.outBack, update: (v) => { rl.off = lerp(over, 0, v); } }))
              .then(() => { rl.off = 0; rl.state = 'idle'; rl.v = 0; });
            rl.v = 0;
            break;
          }
        }
      }
      rl.blurV = rl.state === 'spin' || rl.state === 'stopping' ? rl.v / vmax : 0;
    });
    st.parts.step(dt);
    // anticipation sparks
    st.tease.forEach((r) => {
      const rl = st.reels[r]; if (rl.state === 'idle' || rl.state === 'settle') return;
      const x0 = L.mx + r * (L.col + L.gap);
      for (let i = 0; i < 2; i++) st.parts.add({ x: x0 + (Math.random() < 0.5 ? 0 : L.col), y: L.my + rnd(0, L.H), vx: rnd(-20, 20), vy: rnd(-120, -40), life: rnd(0.4, 0.8), size: rnd(6, 14), tex: T.spark });
    });

    g.setTransform(dprOfCanvas(), 0, 0, dprOfCanvas(), 0, 0);
    g.clearRect(0, 0, L.W + L.mx * 2, L.H + L.my * 2);
    const hasHi = (st.lit && st.lit.size) || (st.trig && st.trig.size);
    for (let r = 0; r < COLS; r++) drawReel(g, r, hasHi);
    drawLines(g);
    st.parts.draw(g);
  }
  function dprOfCanvas() { return canvas.current.width / (st.lay.W + st.lay.mx * 2); }

  function drawReel(g, r, hasHi) {
    const L = st.lay, T = st.tex, rl = st.reels[r];
    const x = L.mx + r * (L.col + L.gap), y = L.my;
    // reel well
    g.save();
    roundRect(g, x, y, L.col, L.H, L.col * 0.08);
    const well = g.createLinearGradient(0, y, 0, y + L.H);
    well.addColorStop(0, 'rgba(12,4,28,.92)'); well.addColorStop(0.5, 'rgba(30,11,59,.82)'); well.addColorStop(1, 'rgba(12,4,28,.92)');
    g.fillStyle = well; g.fill();
    g.clip();
    const pad = L.col * 0.035, size = L.col - pad * 2;
    const blur = rl.blurV;
    for (let k = 0; k < 5; k++) {
      const s = rl.syms[k]; const sy = y + (k - 1) * L.col + rl.off;
      if (sy > y + L.H || sy + L.col < y) continue;
      const tex = T.sym[s];
      if (blur > 0.05) {
        // motion blur: stacked fading copies along the direction of travel
        const n = 4, len = L.col * 0.42 * blur;
        for (let i = n; i >= 0; i--) { g.globalAlpha = i === 0 ? 0.55 : 0.18; g.drawImage(tex, x + pad, sy + pad - (len * i) / n, size, size); }
        g.globalAlpha = 1;
        continue;
      }
      const row = k - 1, key = `${r}-${row}`;
      const on = st.lit?.has(key), tr = st.trig?.has(key);
      const pulse = on || tr ? 1 + 0.06 * Math.sin(st.t * 7 + r) + (tr ? 0.04 : 0) : 1;
      if (hasHi && !on && !tr && rl.state === 'idle') g.globalAlpha = lerp(1, 0.3, st.dimK);
      if ((on || tr) && rl.state === 'idle') {
        const gl = T.glow[s], gs = size * pulse * (gl.canvas.width / TILEOF(T));
        g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.55 + 0.35 * Math.sin(st.t * 7 + r);
        g.drawImage(gl.canvas, x + L.col / 2 - gs / 2, sy + L.col / 2 - gs / 2, gs, gs);
        g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
      }
      const tier = TIER(s), since = st.pop[key] != null ? st.t - st.pop[key] : 9;
      const popK = since < 0.6 ? 1 + 0.2 * Math.exp(-since * 7) * Math.cos(since * 22) : 1;
      if (tier === 'special' && !hasHi && rl.state === 'idle') {
        // a constant pulsing aura so specials read instantly
        const gl = T.glow[s], gs = size * 1.02 * (gl.canvas.width / TILEOF(T));
        g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.35 + 0.25 * Math.sin(st.t * 4 + r * 0.7) + (since < 0.6 ? 0.4 * (1 - since / 0.6) : 0);
        g.drawImage(gl.canvas, x + L.col / 2 - gs / 2, sy + L.col / 2 - gs / 2, gs, gs);
        g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
      }
      const sz = size * pulse * TIER_SCALE[tier] * popK;
      g.drawImage(tex, x + L.col / 2 - sz / 2, sy + L.col / 2 - sz / 2, sz, sz);
      g.globalAlpha = 1;
      if ((on || tr) && rl.state === 'idle') {
        // gold frame with a travelling glint
        g.save(); g.globalCompositeOperation = 'lighter';
        roundRect(g, x + pad, sy + pad, size, size, size * 0.09);
        g.lineWidth = Math.max(2, L.col * 0.03); g.strokeStyle = s === 'STAR' ? 'rgba(244,114,182,.95)' : s === 'GENIE' ? 'rgba(103,232,249,.95)' : 'rgba(253,224,71,.95)'; g.stroke();
        const gx = x + pad + ((st.t * 0.9 + r * 0.17) % 1) * size;
        const grd = g.createLinearGradient(gx - size * 0.25, 0, gx + size * 0.25, 0);
        grd.addColorStop(0, 'rgba(255,255,255,0)'); grd.addColorStop(0.5, 'rgba(255,255,255,.35)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = grd; g.fill();
        g.restore();
      }
    }
    // tall genie on expanding reels
    const ex = st.expand[r];
    if (ex) {
      const k = ex.k, h = L.H * k;
      g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.5 + 0.3 * Math.sin(st.t * 5);
      const gl = st.tex.tallGlow; const gw = L.col * (gl.canvas.width / st.tex.tall.width);
      g.drawImage(gl.canvas, x + L.col / 2 - gw / 2, y + L.H - h - (gw - L.col) * 1.5, gw, h + (gw - L.col) * 3);
      g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
      g.drawImage(st.tex.tall, x, y + L.H - h, L.col, h);
    }
    // spinning sheen and top/bottom shading
    const shade = g.createLinearGradient(0, y, 0, y + L.H);
    shade.addColorStop(0, 'rgba(8,2,20,.65)'); shade.addColorStop(0.12, 'rgba(8,2,20,0)'); shade.addColorStop(0.88, 'rgba(8,2,20,0)'); shade.addColorStop(1, 'rgba(8,2,20,.65)');
    g.fillStyle = shade; g.fillRect(x, y, L.col, L.H);
    g.restore();
    // anticipation frame
    if (st.tease.includes(r) && rl.state !== 'idle') {
      g.save(); g.globalCompositeOperation = 'lighter';
      roundRect(g, x - 1, y - 1, L.col + 2, L.H + 2, L.col * 0.08);
      g.shadowColor = '#fde047'; g.shadowBlur = 18 + 10 * Math.sin(st.t * 12);
      g.lineWidth = 3; g.strokeStyle = 'rgba(253,224,71,.95)'; g.stroke();
      g.restore();
    }
  }

  function drawLines(g) {
    const ws = st.wins; if (!ws?.length || st.lineShow == null) return;
    const L = st.lay;
    const list = st.lineShow === -1 ? ws : [ws[st.lineShow % ws.length]];
    g.save();
    g.lineJoin = 'round'; g.lineCap = 'round';
    list.forEach((w) => {
      const col = LINE_COLOURS[w.line % LINE_COLOURS.length];
      const pts = [[L.mx - L.gap, null], ...LINES[w.line].map((row, r) => [centre(r, row).x, centre(r, row).y]), [L.mx + L.W + L.gap, null]];
      pts[0][1] = pts[1][1]; pts[6][1] = pts[5][1];
      // reveal by length
      const segs = []; let total = 0;
      for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); segs.push(d); total += d; }
      const upto = total * st.lineK;
      const path = () => {
        g.beginPath(); g.moveTo(pts[0][0], pts[0][1]);
        let acc = 0;
        for (let i = 1; i < pts.length; i++) {
          const d = segs[i - 1];
          if (acc + d <= upto) { g.lineTo(pts[i][0], pts[i][1]); acc += d; } else { const f = (upto - acc) / d; g.lineTo(lerp(pts[i - 1][0], pts[i][0], f), lerp(pts[i - 1][1], pts[i][1], f)); break; }
        }
      };
      g.globalCompositeOperation = 'lighter';
      path(); g.strokeStyle = col; g.globalAlpha = 0.28; g.lineWidth = L.col * 0.16; g.stroke();
      path(); g.globalAlpha = 0.75; g.lineWidth = L.col * 0.06; g.stroke();
      g.globalCompositeOperation = 'source-over';
      path(); g.globalAlpha = 1; g.strokeStyle = '#fff'; g.lineWidth = Math.max(1.5, L.col * 0.022); g.stroke();
      // a spark travels along the line
      if (st.lineK >= 1 && st.tex) {
        const pos = ((st.t * 0.6) % 1) * total; let acc = 0;
        for (let i = 1; i < pts.length; i++) { const d = segs[i - 1]; if (acc + d >= pos) { const f = (pos - acc) / d; const sx = lerp(pts[i - 1][0], pts[i][0], f), sy = lerp(pts[i - 1][1], pts[i][1], f); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1; const s = L.col * 0.45; g.drawImage(st.tex.spark, sx - s / 2, sy - s / 2, s, s); break; } acc += d; }
      }
      // line number badge
      g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
      const bx = L.mx - L.gap * 0.2, by = pts[0][1], br = Math.max(8, L.col * 0.13);
      g.fillStyle = col; g.beginPath(); g.arc(bx, by, br, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#1e0b3b'; g.font = `800 ${br * 1.1}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(w.line + 1), bx, by + 0.5);
    });
    g.restore();
  }

  return (
    <div ref={wrap} className="relative w-full" aria-label="Reels">
      <canvas ref={canvas} className="pointer-events-none absolute" aria-hidden="true" />
      {!ready && <div className="absolute inset-0 flex items-center justify-center text-xs text-white/60">Loading reels…</div>}
    </div>
  );
}
const TILEOF = (T) => T.sym.GENIE.width;

export default forwardRef(CanvasReels);
