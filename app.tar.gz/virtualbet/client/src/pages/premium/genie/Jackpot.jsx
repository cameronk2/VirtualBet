// Golden Wishes – jackpot plaques and jackpot celebrations.
// Values are fixed multiples of the current bet (they change with the bet).
// Each jackpot has its own colour, sound and celebration; the Grand takes over
// the whole screen.
import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { GenieFigure } from '../../../components/SlotArtGenie.jsx';
import { money } from '../../../lib/format.js';

const short = (v) => (v % 100 === 0 ? money(v).replace(/\.00$/, '') : money(v));
import { reduceMotion } from '../../../components/Premium.jsx';
import { JACKPOTS, JACKPOT_ORDER, JP_NAME } from '../../../../../server/games/genie/config.js';
import { JP_STYLE, Jewel } from './Treasure.jsx';

function useCount(target, ms = 600) {
  const [v, setV] = useState(target);
  const from = useRef(target);
  useEffect(() => {
    if (reduceMotion) { setV(target); from.current = target; return undefined; }
    const a = from.current, t0 = performance.now(); let raf;
    const step = (t) => { const k = Math.min(1, (t - t0) / ms); const x = Math.round(a + (target - a) * (1 - (1 - k) ** 3)); setV(x); if (k < 1) raf = requestAnimationFrame(step); else from.current = target; };
    raf = requestAnimationFrame(step);
    return () => { cancelAnimationFrame(raf); from.current = target; };
  }, [target, ms]);
  return v;
}

function Plaque({ k, bet, count, active }) {
  const st = JP_STYLE[k];
  const v = useCount(bet * JACKPOTS[k]);
  const hot = count === 2 && active;
  const grand = k === 'GRAND';
  return (
    <div className={`gn-jp relative overflow-hidden rounded-lg bg-gradient-to-b ${st.grad} p-[2px] ${hot ? 'gn-jp-hot' : ''} ${grand ? 'col-span-1' : ''}`} style={{ '--c': st.c }}>
      <div className="relative rounded-[6px] bg-[#14062a]/88 px-1 pb-1 pt-0.5 text-center">
        <div className="text-[9px] font-black uppercase tracking-[0.2em] sm:text-[10px]" style={{ color: st.c }}>{JP_NAME[k]}</div>
        <div key={v === bet * JACKPOTS[k] ? bet : 'x'} className={`font-cond font-extrabold leading-none tabular-nums text-white ${grand ? 'text-[15px] sm:text-xl' : 'text-[14px] sm:text-lg'}`} style={{ textShadow: `0 0 8px ${st.c}` }}>{short(v)}</div>
        {active && <div className="mt-0.5 flex justify-center gap-1">{[0, 1, 2].map((i) => <span key={i} className={`h-1.5 w-3 rounded-full ${i < count ? '' : 'bg-white/15'}`} style={i < count ? { background: st.c, boxShadow: `0 0 6px ${st.c}` } : undefined} />)}</div>}
        <span className="kn-sheen pointer-events-none absolute inset-0" style={{ animationDelay: `${JACKPOT_ORDER.indexOf(k) * 0.6}s`, animationDuration: '4s' }} />
      </div>
    </div>
  );
}

export function JackpotBar({ bet, progress, active }) {
  return (
    <div className="grid grid-cols-4 gap-1 sm:gap-1.5" aria-label="Jackpots">
      {JACKPOT_ORDER.map((k) => <Plaque key={k} k={k} bet={bet} count={progress?.[k] || 0} active={active} />)}
    </div>
  );
}

export function CoinShower({ n = 24, fall = 420 }) {
  const coins = useMemo(() => Array.from({ length: reduceMotion ? 0 : n }, (_, i) => ({ x: (i * 53 + 7) % 100, d: `${(i % 10) * 0.12}s`, t: `${1.4 + (i % 4) * 0.35}s`, s: 0.7 + (i % 3) * 0.25 })), [n]);
  return <div className="pointer-events-none absolute inset-0 z-30 overflow-hidden">{coins.map((c, i) => <span key={i} className="gn-coin" style={{ left: `${c.x}%`, animationDelay: c.d, animationDuration: c.t, transform: `scale(${c.s})`, '--fall': `${fall}px` }} />)}</div>;
}

function Fireworks({ colours }) {
  const parts = useMemo(() => Array.from({ length: reduceMotion ? 0 : 5 }, (_, b) => Array.from({ length: 14 }, (_, i) => {
    const a = (i / 14) * Math.PI * 2, d = 70 + (b % 3) * 25;
    return { b, x: 15 + ((b * 37) % 70), y: 15 + ((b * 23) % 40), dx: `${Math.cos(a) * d}px`, dy: `${Math.sin(a) * d}px`, c: colours[(b + i) % colours.length], delay: `${b * 0.35}s` };
  })).flat(), [colours]);
  return <div className="pointer-events-none absolute inset-0">{parts.map((p, i) => <span key={i} className="gn-firework" style={{ left: `${p.x}%`, top: `${p.y}%`, background: p.c, boxShadow: `0 0 8px ${p.c}`, '--dx': p.dx, '--dy': p.dy, animationDelay: p.delay }} />)}</div>;
}

/** Jackpot win: count-up, tier colour, coins; the Grand fills the screen. */
export function JackpotCelebration({ jp, amount, bet, detail, fx, onDone, practice }) {
  const st = JP_STYLE[jp];
  const grand = jp === 'GRAND';
  const tier = JACKPOT_ORDER.indexOf(jp);
  const [shown, setShown] = useState(reduceMotion ? amount : 0);
  const [done, setDone] = useState(reduceMotion);
  const raf = useRef(0);
  useEffect(() => {
    if (grand) { fx.grand(); fx.wow(); } else { fx.jackpot(tier); fx.laugh(); }
    fx.coins(10 + tier * 6);
    if (reduceMotion) return undefined;
    const dur = 1600 + tier * 900, t0 = performance.now();
    const step = (t) => { const k = Math.min(1, (t - t0) / dur); setShown(Math.floor(amount * (1 - (1 - k) ** 2.2))); if (k < 1) raf.current = requestAnimationFrame(step); else { setShown(amount); setDone(true); } };
    raf.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf.current);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!done) return undefined; const id = setTimeout(onDone, 3200 + tier * 600); return () => clearTimeout(id); }, [done]); // eslint-disable-line react-hooks/exhaustive-deps
  const tap = () => { if (!done) { cancelAnimationFrame(raf.current); setShown(amount); setDone(true); } else onDone(); };
  const body = (
    <button type="button" onClick={tap} aria-live="polite" aria-label={`${JP_NAME[jp]} jackpot ${money(amount)}. Tap to ${done ? 'continue' : 'skip'}`}
      className={`animate-fade-in z-[55] flex flex-col items-center justify-center overflow-hidden text-center ${grand ? 'fixed inset-0' : 'absolute inset-0 rounded-2xl'}`}
      style={{ background: `radial-gradient(ellipse at 50% 45%, ${st.c}55, rgba(10,3,24,.96) 70%)` }}>
      <div className="gn-flash pointer-events-none absolute inset-0 bg-white" />
      <div className="gn-rays pointer-events-none absolute opacity-50" style={{ background: `repeating-conic-gradient(${st.c}55 0deg 8deg, transparent 8deg 18deg)`, width: '220vmax', height: '220vmax', marginLeft: '-110vmax', marginTop: '-110vmax', left: '50%', top: '50%' }} />
      {tier >= 2 && <Fireworks colours={[st.c, '#fff', '#f0abfc', '#fde047']} />}
      <CoinShower n={[18, 28, 40, 64][tier]} fall={grand ? (typeof window !== 'undefined' ? window.innerHeight + 60 : 800) : 460} />
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-64 w-[90%] max-w-xl -translate-x-1/2 -translate-y-1/2 rounded-full bg-black/55 blur-2xl" />
      {grand && <svg viewBox="0 0 100 100" className="gn-emerge relative h-36 w-36 sm:h-48 sm:w-48" aria-hidden="true"><GenieFigure pose="wow" /></svg>}
      <Jewel jp={jp} className={`gn-pop relative ${grand ? 'h-20 w-20' : 'h-24 w-24'}`} />
      <div className={`p3-stamp relative font-[Cinzel,Georgia,serif] font-black tracking-wide text-transparent ${grand ? 'text-5xl sm:text-7xl' : 'text-4xl sm:text-5xl'}`}
        style={{ backgroundImage: `linear-gradient(180deg,#fff,${st.c} 55%,#3b0764)`, WebkitBackgroundClip: 'text', backgroundClip: 'text', filter: `drop-shadow(0 0 ${10 + tier * 6}px ${st.c})` }}>{JP_NAME[jp].toUpperCase()}</div>
      <div className="relative -mt-1 text-sm font-black uppercase tracking-[0.5em] text-white/90">jackpot</div>
      <div className="relative mt-2 font-cond text-5xl font-extrabold tabular-nums text-white sm:text-6xl" style={{ textShadow: `0 0 18px ${st.c}` }}>{money(shown)}</div>
      {detail && <div className="relative mt-1 text-xs font-semibold text-white/80">{detail}</div>}
      {practice && <div className="relative mt-2 rounded-full bg-fuchsia-600 px-3 py-1 text-xs font-extrabold text-white">PRACTICE ROUND · NOT PAID</div>}
      <div className="relative mt-4 text-[11px] uppercase tracking-widest text-white/60">{done ? 'Tap to continue' : 'Tap to skip'}</div>
    </button>
  );
  return grand ? createPortal(body, document.body) : body;
}
