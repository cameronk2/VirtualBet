// Golden Wishes – game screen. Every result (reels, wish, treasure board)
// comes from the server before anything moves; this file only presents it:
// 20-line reels with drawn paylines, the genie host, Magic Lamp wishes,
// Wishing Star free spins with expanding genies, Genie's Treasure and the
// jackpots. Auto-spin always has a spin count and a loss limit, and stops on
// any feature.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { reduceMotion, BigWin, Burst, FeatureIntro, PremiumShell, RecentList, SidePanel, sleep, tierOf, usePremium, useReelStops } from '../../../components/Premium.jsx';
import { STAKES } from '../../../components/GameShell.jsx';
import { Modal } from '../../../components/ui.jsx';
import { GENIE_NAMES, GenieFigure, GenieSym, Lamp, WishStar } from '../../../components/SlotArtGenie.jsx';
import { genieSfx, playSting, registerTracks, setMusicScene } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { FREE_MIN_X, FREE_MULT, FREE_SPINS, JACKPOTS, JACKPOT_WEIGHTS, JP_NAME, LAMP_BOOST, LINES, MAX_WIN_X, PAYTABLE, PAY_SCALE, RETRIGGER, SCATTER_PAY, TREASURE_CASH, TREASURE_MULT, WISH_CASH, WISH_FREE, WISH_MULTIPLIER, WISH_MULT_BASE, WISH_TYPES } from '../../../../../server/games/genie/config.js';
import Scene from './Scene.jsx';
import CanvasScene from './CanvasScene.jsx';
import CanvasReels from './CanvasReels.jsx';
import Wish from './Wish.jsx';
import Treasure from './Treasure.jsx';
import { CoinShower, JackpotBar, JackpotCelebration } from './Jackpot.jsx';

const ROWS = 3;
// Recorded soundtrack (client/audio/genie/*.mp3), if present at build time; otherwise the synthesised theme plays.
const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
const TRACKS = Object.fromEntries(['base', 'free', 'bonus', 'win', 'jackpot'].filter((k) => AUD.files.includes(`genie/${k}.mp3`)).map((k) => [k, `${AUD.base}genie/${k}.mp3`]));
if (TRACKS.base) registerTracks('genie', TRACKS);
const START = [['PRINCESS', 'A', 'RUBY'], ['LAMP', 'GENIE', 'K'], ['CROWN', 'PALACE', 'STAR'], ['Q', 'EMERALD', 'CHEST'], ['AMETHYST', 'J', 'T']];
const BLUR = ['GENIE', 'A', 'PRINCESS', 'K', 'LAMP', 'PALACE', 'Q', 'CHEST', 'J', 'CROWN', 'STAR', 'T', 'AMETHYST', 'EMERALD', 'RUBY'];
const LINE_COLOURS = ['#fde047', '#f472b6', '#5eead4', '#a78bfa', '#fb923c', '#4ade80', '#60a5fa', '#f87171', '#facc15', '#e879f9', '#2dd4bf', '#c084fc', '#fdba74', '#86efac', '#93c5fd', '#fca5a5', '#fef08a', '#f0abfc', '#99f6e4', '#d8b4fe'];
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v ? '1' : '0'); } catch { /* private mode */ } };
const devMode = () => { try { return location.hash.includes('dev') || localStorage.getItem('vb_dev') === '1'; } catch { return false; } };
const SMALL = ['Splendid!', 'A fine win!', 'Ha! Gold!', 'Wonderful!', 'Shining!'];
const BIG = ['Magnificent!', 'By the stars!', 'What riches!'];
const pick = (a) => a[Math.floor(Math.random() * a.length)];

function Reel({ index, cells, spinning, landKey, lit, trig, turbo, tease, expanding }) {
  return (
    <div className={`relative overflow-hidden rounded-lg bg-[#12052b]/70 ring-1 ${tease ? 'ring-2 ring-yellow-300 shadow-[0_0_24px_rgba(253,224,71,0.85)]' : 'ring-amber-200/20'}`} style={{ aspectRatio: `1 / ${ROWS}` }}>
      {spinning ? (
        <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 50}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-0.5 opacity-80 blur-[1.5px]"><GenieSym s={BLUR[(k * 4 + index * 3) % BLUR.length]} /></div>)}
        </div>
      ) : (
        <div key={landKey} className="p3-land-bounce">
          {cells.map((s, row) => {
            const k = `${index}-${row}`, on = lit?.has(k), t = trig?.has(k);
            const special = s === 'LAMP' || s === 'STAR';
            return (
              <div key={row} className={`relative aspect-square p-0.5 ${(lit?.size || trig?.size) && !on && !t ? 'p3-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'p3-win' : ''} ${t ? 'bk-trig' : ''} ${special && !on && !t ? 'gn-special' : ''} ${expanding ? 'gn-expand' : ''}`} style={{ '--glow': '#fde047', animationDelay: expanding ? `${row * 0.08}s` : undefined }}><GenieSym s={s} /></div>
                {(on || t) && <Burst key={landKey + (t ? 't' : '')} game="genie" n={t ? 10 : 6} spread={40} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** Winning paylines: all together first, then one at a time. */
function Paylines({ wins, show }) {
  if (!wins?.length || show == null) return null;
  const list = show === -1 ? wins : [wins[show % wins.length]];
  const pt = (r, row) => `${(r + 0.5) * 20},${((row + 0.5) / ROWS) * 100}`;
  return (
    <svg key={show} viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 z-20 h-full w-full" aria-hidden="true">
      {list.map((w) => {
        const col = LINE_COLOURS[w.line % LINE_COLOURS.length];
        const d = LINES[w.line].map((row, r) => pt(r, row)).join(' ');
        return (
          <g key={w.line}>
            <polyline points={`0,${((LINES[w.line][0] + 0.5) / ROWS) * 100} ${d} 100,${((LINES[w.line][4] + 0.5) / ROWS) * 100}`} fill="none" stroke={col} strokeOpacity=".45" strokeWidth="9" vectorEffect="non-scaling-stroke" strokeLinejoin="round" className="gn-line" />
            <polyline points={`0,${((LINES[w.line][0] + 0.5) / ROWS) * 100} ${d} 100,${((LINES[w.line][4] + 0.5) / ROWS) * 100}`} fill="none" stroke="#fff" strokeWidth="2.4" vectorEffect="non-scaling-stroke" strokeLinejoin="round" className="gn-line" style={{ filter: `drop-shadow(0 0 4px ${col})` }} />
          </g>
        );
      })}
    </svg>
  );
}

/** The genie host: reacts to play with poses, sounds and a speech bubble. */
function Host({ pose, say, sayKey, cheer }) {
  const [blink, setBlink] = useState(false);
  useEffect(() => { const id = setInterval(() => { setBlink(true); setTimeout(() => setBlink(false), 140); }, 4200); return () => clearInterval(id); }, []);
  return (
    <div className="relative h-[68px] w-[60px] shrink-0 sm:h-[92px] sm:w-[82px] lg:h-[118px] lg:w-[104px]">
      <svg viewBox="2 0 96 100" className={`h-full w-full drop-shadow-[0_0_10px_rgba(94,234,212,0.55)] ${cheer ? 'gn-cheer' : 'gn-float'}`} aria-label={`Genie ${pose}`}><GenieFigure pose={pose} blink={blink && pose === 'crossed'} /></svg>
      {say && <div key={sayKey} className="gn-bubble pointer-events-none absolute left-[88%] top-0 z-30 whitespace-nowrap rounded-2xl rounded-bl-none bg-white px-2.5 py-1 text-xs font-extrabold text-violet-900 shadow-[0_4px_14px_rgba(0,0,0,0.4)] sm:text-sm">{say}</div>}
    </div>
  );
}

function Switch({ label, hint, on, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!on)} aria-pressed={on} className="flex w-full items-center justify-between gap-4 rounded-lg bg-navy-800 px-3 py-2.5 text-left text-sm text-slate-200 hover:bg-navy-700">
      <span>{label}{hint && <span className="block text-[11px] text-slate-500">{hint}</span>}</span>
      <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? 'bg-amber-400' : 'bg-navy-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
    </button>
  );
}

function Choice({ label, options, value, onChange, fmt = (v) => v }) {
  return (
    <div>
      <div className="mb-1 text-xs font-semibold text-slate-400">{label}</div>
      <div className="grid grid-cols-4 gap-1.5">{options.map((o) => <button key={String(o)} type="button" onClick={() => onChange(o)} className={`rounded-lg py-2 text-sm font-bold ${value === o ? 'bg-amber-400 text-navy-950' : 'bg-navy-800 text-slate-200 hover:bg-navy-700'}`}>{fmt(o)}</button>)}</div>
    </div>
  );
}

const INTRO = {
  treasure: { title: "GENIE'S TREASURE", cta: 'Open the vault', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(161,98,7,0.96),rgba(20,6,2,0.97))]', text: 'Pick treasures. Three matching jewels win that jackpot: Mini, Minor, Major or Grand. Prizes and a multiplier may be hidden too.' },
  free: { title: 'FREE SPINS', cta: 'Fly to the stars', cls: 'bg-[radial-gradient(ellipse_at_top,rgba(14,116,144,0.96),rgba(4,8,24,0.97))]', text: `All wins ×${FREE_MULT}. Every Genie that lands fills its whole reel. The round is guaranteed to pay at least ${FREE_MIN_X}× your bet. Three or more stars add more spins, and lamps can still grant wishes.` },
};
const pct = (pairs, key) => { const t = pairs.reduce((a, [, w]) => a + w, 0); const w = pairs.find(([k]) => k === key)?.[1] || 0; return `${((w / t) * 100).toFixed(w / t < 0.1 ? 1 : 0)}%`; };

export default function Genie() {
  const { user, view, history, play, commit, guard: rawGuard, shake, doShake } = usePremium('genie');
  const [tick, setTick] = useState(0);
  const guard = (fn) => rawGuard(fn).finally(() => setTick((n) => n + 1));
  const fx = useMemo(() => {
    const f = genieSfx();
    // with recorded stings, the synthesised fanfares would clash with them
    if (TRACKS.win) f.big = () => {};
    if (TRACKS.jackpot) { f.jackpot = () => {}; f.grand = () => {}; }
    return f;
  }, []);
  const domReels = useReelStops(5);
  const [hd, setHd] = useState(() => pref('gn_hd', (() => { try { return !!document.createElement('canvas').getContext('2d'); } catch { return false; } })()));
  const canvasRef = useRef(null);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  // The canvas reels use the same stop timing as the classic reels; each reel reports when it lands.
  const hdReels = useMemo(() => ({
    stopped: [true, true, true, true, true],
    start: () => canvasRef.current?.spin(),
    stopNow: (g) => canvasRef.current?.stopNow(g),
    stopAll: ({ turbo: tb = false, tease: tz = [], onStop, grid }) => new Promise((res) => {
      const cv = canvasRef.current;
      if (!cv?.ready()) { cv?.stopNow(grid); for (let i = 0; i < 5; i++) onStop?.(i); res(); return; }
      let at = reduceMotion ? 60 : tb ? 200 : 520, left = 5;
      for (let i = 0; i < 5; i++) {
        if (tz.includes(i) && !tb && !reduceMotion) at += 900;
        timers.current.push(setTimeout(() => cv.stop(i, grid[i]).then(() => { onStop?.(i); if (--left === 0) setTimeout(res, tb ? 120 : 260); }), at));
        at += reduceMotion ? 20 : tb ? 80 : 230;
      }
    }),
  }), []);
  const reels = hd ? hdReels : domReels;
  const [scene, setScene] = useState('base');
  const [cells, setCells] = useState(START);
  const [lit, setLit] = useState(null);
  const [trig, setTrig] = useState(null);
  const [wins, setWins] = useState(null);
  const [lineShow, setLineShow] = useState(null);
  const [res, setRes] = useState(null);
  const [stake, setStake] = useState(100);
  const [spinId, setSpinId] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [tease, setTease] = useState([]);
  const [expanding, setExpanding] = useState([]);
  const [count, setCount] = useState({ lamps: 0, stars: 0 });
  const [banner, setBanner] = useState(null);
  const [freeInfo, setFreeInfo] = useState(null);
  const [treasure, setTreasure] = useState(null);
  const [progress, setProgress] = useState(null);
  const [wish, setWish] = useState(null);
  const [jackpot, setJackpot] = useState(null);
  const [coins, setCoins] = useState(0);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [summary, setSummary] = useState(null);
  const [session, setSession] = useState({ staked: 0, won: 0 });
  const [host, setHost] = useState({ pose: 'crossed', say: 'Spin, and make a wish!', key: 0, cheer: false });
  const [modal, setModal] = useState(null); // settings | auto | paytable | rules
  const [auto, setAuto] = useState(null);
  const [autoCfg, setAutoCfg] = useState({ spins: 25, loss: 25, winStop: 50 });
  const [turbo, setTurbo] = useState(() => pref('gn_turbo', false));
  const [space, setSpace] = useState(() => pref('gn_space', true));
  const [dev] = useState(devMode);
  const mode = view?.mode || 'base';
  const barMode = scene === mode ? mode : 'busy';
  const bet = treasure?.bet ?? freeInfo?.bet ?? view?.treasure?.bet ?? view?.free?.bet ?? stake;
  const t = useCallback((ms) => sleep(turbo ? ms * 0.45 : ms), [turbo]);
  const track = (out) => setSession((s) => ({ staked: s.staked + (out.staked || 0), won: s.won + (out.payout || 0) }));
  const hostTimer = useRef(0);
  const react = (pose, say, ms = 2200, cheer = false) => {
    clearTimeout(hostTimer.current);
    setHost((h) => ({ pose, say, key: h.key + 1, cheer }));
    if (ms) hostTimer.current = setTimeout(() => setHost((h) => ({ ...h, pose: 'crossed', say: null, cheer: false })), ms);
  };
  useEffect(() => { const id = setTimeout(() => setHost((h) => ({ ...h, say: null })), 3000); return () => clearTimeout(id); }, []);

  const waiter = (setter) => { const ref = { current: null }; return [(v) => new Promise((r) => { ref.current = r; setter(v); }), () => { ref.current?.(); ref.current = null; }]; };
  const [showBig, bigDone] = useMemo(() => waiter(setBig), []);
  const [showIntro, introDone] = useMemo(() => waiter(setIntro), []);
  const [showSummary, sumDone] = useMemo(() => waiter(setSummary), []);
  const [showWish, wishDone] = useMemo(() => waiter(setWish), []);
  const [showJackpot, jpDone] = useMemo(() => waiter(setJackpot), []);

  // After a refresh mid-feature, put the right screen back.
  useEffect(() => { setMusicScene('genie', scene === 'free' ? 'free' : scene === 'treasure' ? 'bonus' : 'base'); }, [scene]);
  const resumed = useRef(false);
  useEffect(() => {
    if (!view || resumed.current) return;
    resumed.current = true;
    if (view.free) setFreeInfo({ ...view.free });
    if (view.mode === 'treasure') { setTreasure({ ...view.treasure }); setProgress(view.treasure.jp); setScene('treasure'); setIntro({ type: 'treasure', resume: true }); }
    else if (view.mode === 'free') { setScene('free'); setIntro({ type: 'free', resume: true }); }
  }, [view]);

  // payline display: all lines, then each one in turn while idle
  useEffect(() => {
    if (!wins?.length || spinning) return undefined;
    let i = -1;
    setLineShow(-1);
    const id = setInterval(() => { i = (i + 1) % wins.length; setLineShow(wins.length > 1 ? i : -1); }, turbo ? 900 : 1500);
    return () => clearInterval(id);
  }, [wins, spinning, turbo]);

  const handleStarted = async (out) => {
    const st = out.started;
    if (st?.type === 'treasure') {
      setTreasure({ picks: {}, order: [], jp: {}, cashX: 0, mult: 1, bet: out.bet });
      setProgress({}); setLit(null); setWins(null); setTrig(null);
      setScene('treasure'); fx.bonus(); react('magic', 'Choose wisely, master!', 3000);
      await showIntro({ type: 'treasure' });
    } else if (st?.type === 'free') {
      setFreeInfo({ bet: out.bet, remaining: st.spins, played: 0, total: 0 });
      setLit(null); setWins(null); setTrig(null);
      setScene('free'); fx.freeTrigger(); react('up', 'Up among the stars!', 3000, true);
      await showIntro({ type: 'free' });
    } else if (out.mode === 'free') {
      setFreeInfo((f) => ({ ...f, ...out.view.free })); setScene('free');
    } else if (out.mode === 'base') { setScene('base'); setFreeInfo(null); }
  };

  const endFree = async (out) => {
    const fin = out.finished;
    if (!fin) return;
    if (fin.total >= (freeInfo?.bet || bet) * 10) { fx.big(); playSting('genie', 'win'); react('wow', pick(BIG), 3000); await showBig({ amount: fin.total, title: 'FREE SPINS WIN', practice: out.practice }); }
    await showSummary({ ...fin, practice: out.practice });
  };

  // ── spins (base and free) ───────────────────────────────────────────────
  const spinReels = async () => {
    const free = scene === 'free';
    fx.click();
    setSpinning(true); setRes(null); setLit(null); setTrig(null); setWins(null); setLineShow(null); setTease([]); setBanner(null); setExpanding([]); setCount({ lamps: 0, stars: 0 }); setCoins(0);
    if (!free) react('crossed', null, 0);
    fx.spin(); setSpinId((n) => n + 1); reels.start();
    const out = await play('spin', free ? {} : { stake });
    if (!out) { reels.stopNow(cells); setSpinning(false); setAuto(null); return null; }
    track(out);
    setCells(out.drawn);
    const teaseReels = [];
    let l = 0, s = 0;
    out.drawn.forEach((col, r) => { if (l >= 2 || s >= 2) teaseReels.push(r); l += col.filter((x) => x === 'LAMP').length; s += col.filter((x) => x === 'STAR').length; });
    let cl = 0, cs = 0;
    await reels.stopAll({
      turbo, tease: teaseReels, grid: out.drawn,
      onStop: (r) => {
        fx.stop(r);
        const col = out.drawn[r];
        if (col.includes('LAMP')) fx.lamp(cl++);
        if (col.includes('STAR')) fx.star(cs++);
        if (col.includes('GENIE')) fx.land('GENIE');
        setCount({ lamps: cl, stars: cs });
        if (teaseReels.includes(r + 1)) { setTease([r + 1]); fx.tease(); }
      },
    });
    setTease([]);
    // free spins: genies fill their reels
    if (out.expanded?.length) {
      fx.expand(); react('magic', 'Genie power!', 1600);
      setCells(out.grid); setExpanding(out.expanded); await t(800);
    }
    if (free) setFreeInfo((f) => ({ ...f, remaining: out.remaining, played: (f?.played || 0) + 1, total: out.view?.free?.total ?? f?.total }));
    const litCells = new Set(out.wins.flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`)));
    if (out.scatterWin) out.stars.forEach(([r, c]) => litCells.add(`${r}-${c}`));
    const lineAndStars = out.lineWin + out.scatterWin;
    const x = lineAndStars / out.bet;
    if (litCells.size) {
      setLit(litCells); setWins(out.wins.length ? out.wins : null);
      fx.win(x >= 5 ? 2 : 1);
      if (x >= 3) { setCoins((n) => n + 1); fx.coins(8); }
      if (x < 10 && !out.wish) react('up', x >= 5 ? pick(BIG) : pick(SMALL), 1800, x >= 5);
      if (x >= 5 && x < 10) fx.laugh();
    }
    setRes(out); setSpinning(false);
    const tr = out.triggers || {};
    if (out.wish) {
      setTrig(new Set(out.lamps.map(([r, c]) => `${r}-${c}`)));
      fx.lamp(4); react('magic', 'You summoned me!', 1800);
      setBanner({ text: `${out.lamps.length} MAGIC LAMPS!`, cls: 'from-yellow-100 to-amber-500 text-amber-950' }); await t(1500); setBanner(null);
      await showWish({ wish: out.wish, practice: out.practice });
      setTrig(null);
    }
    if (tr.retrigger) { fx.freeTrigger(); setBanner({ text: `+${tr.retrigger} FREE SPINS`, cls: 'from-cyan-100 to-teal-600 text-white' }); await t(1300); setBanner(null); }
    if (out.stars.length >= 3 && !free) {
      setTrig(new Set(out.stars.map(([r, c]) => `${r}-${c}`)));
      fx.freeTrigger(); setBanner({ text: `${out.stars.length} WISHING STARS!`, cls: 'from-pink-100 to-fuchsia-600 text-white' }); await t(1500);
    } else if (out.win && !out.wish) await t(x >= 10 ? 500 : 700);
    commit();
    const tier = tierOf(lineAndStars, out.staked || out.bet, out.bet);
    if (tier >= 3) { fx.big(); fx.wow(); playSting('genie', 'win'); react('wow', pick(BIG), 3500, true); doShake(tier >= 4); await showBig({ amount: lineAndStars, practice: out.practice }); }
    setBanner(null);
    if (out.started) { setTrig(null); await handleStarted(out); }
    else if (out.finished) { await endFree(out); await handleStarted(out); }
    return out;
  };

  // ── Genie's Treasure ────────────────────────────────────────────────────
  const requestPick = async (tile) => { const out = await play('pick', { tile }); if (out) track(out); return out; };
  const treasureComplete = async (out) => {
    const d = out.treasureDone;
    react('wow', 'A jackpot!', 4000, true); playSting('genie', 'jackpot');
    const parts = [`${JP_NAME[d.won]} ${money(d.jackpotX * out.bet)}`];
    if (d.cashX) parts.push(`prizes ${money(d.cashX * out.bet)}`);
    await showJackpot({ jp: d.won, amount: out.win, detail: `${parts.join(' + ')}${d.mult > 1 ? ` × ${d.mult}` : ''}`, practice: out.practice });
    commit();
    setTreasure(null); setProgress(null);
    if (out.started) await handleStarted(out);
    else if (out.mode === 'free') { setFreeInfo((f) => ({ ...f, ...out.view.free })); setScene('free'); }
    else {
      if (out.finished) { setScene('free'); await endFree(out); }
      setScene('base'); setFreeInfo(null);
    }
  };

  const devTrigger = (event) => guard(async () => {
    setAuto(null);
    if (['CASH', 'MULT', 'FREE', 'TREASURE'].includes(event)) {
      // a practice spin with three lamps and the chosen wish
      const out = await play('dev', { event, stake });
      if (!out) return;
      setCells(out.grid); setRes(null); setSpinId((n) => n + 1);
      setTrig(new Set(out.lamps.map(([r, c]) => `${r}-${c}`)));
      fx.lamp(4); setBanner({ text: '3 MAGIC LAMPS!', cls: 'from-yellow-100 to-amber-500 text-amber-950' }); await t(1200); setBanner(null);
      await showWish({ wish: out.wish, practice: true }); setTrig(null);
      if (out.started) await handleStarted({ ...out, bet: stake });
      return;
    }
    const out = await play('dev', { event, stake });
    if (out?.started) await handleStarted({ ...out, bet: stake });
  });

  const spin = () => guard(async () => {
    if ((mode === 'base' && scene === 'base') || (mode === 'free' && scene === 'free')) {
      const out = await spinReels();
      // auto-spin bookkeeping (paid spins only)
      if (out && !out.free) setAuto((a) => {
        if (!a) return a;
        const left = a.left - 1;
        const lost = a.lost + (out.staked || 0) - (out.payout || 0);
        const reason = out.wish || out.started || out.stars.length >= 3 ? 'A feature started' : a.winStop && out.win >= out.bet * a.winStop ? `A win of ${a.winStop}x or more` : lost >= a.loss ? 'Loss limit reached' : left <= 0 ? 'All auto spins played' : null;
        if (reason) { setBanner(null); setAutoStopped(reason); return null; }
        return { ...a, left, lost };
      });
    }
  });
  const [autoStopped, setAutoStopped] = useState(null);
  useEffect(() => { if (!autoStopped) return undefined; const id = setTimeout(() => setAutoStopped(null), 3500); return () => clearTimeout(id); }, [autoStopped]);

  const low = mode === 'base' && (user?.balance ?? 0) < stake;
  const ready = !spinning && !big && !intro && !summary && !modal && !banner && !wish && !jackpot;
  // Free spins run themselves (never paid spins).
  useEffect(() => {
    if (!ready || mode !== 'free' || scene !== 'free') return undefined;
    const id = setTimeout(spin, turbo ? 350 : 850);
    return () => clearTimeout(id);
  }, [ready, mode, scene, tick]); // eslint-disable-line react-hooks/exhaustive-deps
  // Auto-spin: paid spins, only when the player set it up with limits.
  useEffect(() => {
    if (!auto || !ready || mode !== 'base' || scene !== 'base') return undefined;
    if (low) { setAuto(null); setAutoStopped('Not enough balance'); return undefined; }
    const id = setTimeout(spin, turbo ? 450 : 900);
    return () => clearTimeout(id);
  }, [auto, ready, mode, scene, tick, low]); // eslint-disable-line react-hooks/exhaustive-deps

  const spinRef = useRef(spin); spinRef.current = spin;
  useEffect(() => {
    if (!space) return undefined;
    const h = (e) => {
      if (e.code !== 'Space' || e.repeat || ['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(e.target.tagName)) return;
      e.preventDefault();
      if (ready && barMode === 'base' && !auto) spinRef.current();
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [space, ready, barMode, auto]);

  const i = Math.max(0, STAKES.indexOf(stake));
  const practice = view?.practice;
  const sessionNet = session.won - session.staked;
  const shownWin = lineShow != null && lineShow >= 0 && wins?.length > 1 ? wins[lineShow % wins.length] : null;
  const detail = shownWin ? `Line ${shownWin.line + 1} · ${shownWin.count}× ${GENIE_NAMES[shownWin.symbol].replace(' (wild)', '')} · ${money(shownWin.amount)}`
    : res?.wins?.length ? `${res.wins.length} winning line${res.wins.length > 1 ? 's' : ''}${res.scatterWin ? ` + ${res.stars.length} stars` : ''}${res.free ? ` · ×${FREE_MULT}` : ''}${res.wishWin ? ` + wish ${money(res.wishWin)}` : ''}`
      : res?.scatterWin ? `${res.stars.length} Wishing Stars` : res?.wishWin ? `Genie's wish ${money(res.wishWin)}` : '';

  const bar = (
    <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || !!auto || barMode !== 'base' || i <= 0} onClick={() => { fx.click(); setStake(STAKES[i - 1]); }} aria-label="Lower bet">−</button>
          <div className="w-[4.4rem] text-center leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{barMode === 'base' ? 'Total bet' : 'Bonus bet'}</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(bet)}</div></div>
          <button className="btn-ghost h-12 w-10 p-0 text-xl" disabled={spinning || !!auto || barMode !== 'base' || i >= STAKES.length - 1} onClick={() => { fx.click(); setStake(STAKES[i + 1]); }} aria-label="Raise bet">+</button>
        </div>
        {scene === 'treasure' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-amber-400/20 px-2 text-center text-sm font-bold text-amber-100 ring-1 ring-amber-300/50">Pick a treasure</div>
        ) : barMode === 'busy' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-amber-400/20 text-sm font-bold text-amber-100 ring-1 ring-amber-300/50">Feature in progress…</div>
        ) : mode === 'free' ? (
          <div className="flex h-14 flex-1 items-center justify-center rounded-full bg-teal-500/25 px-2 text-center text-sm font-bold text-teal-100 ring-1 ring-teal-300/50">Free spins play automatically · {freeInfo?.remaining ?? 0} left</div>
        ) : auto ? (
          <button onClick={() => { fx.click(); setAuto(null); }} className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-rose-300 to-rose-600 text-base font-extrabold text-white shadow-lg">Stop auto · {auto.left} left</button>
        ) : (
          <button onClick={spin} disabled={spinning || low || !!intro || !!summary || !!big || !!wish || !!jackpot}
            className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-yellow-200 via-amber-400 to-amber-700 text-lg font-extrabold text-amber-950 shadow-[0_0_18px_rgba(250,204,21,0.45)] transition-transform active:scale-95">
            {spinning ? 'Spinning…' : low ? 'Not enough balance' : 'Spin'}
          </button>
        )}
      </div>
      <div className="flex items-center justify-between gap-1.5 text-xs text-slate-400">
        <div className="flex gap-1">
          <button onClick={() => { fx.click(); setModal('auto'); }} disabled={barMode !== 'base' || !!auto || spinning} className={`rounded-md px-2 py-1 font-semibold ${auto ? 'bg-rose-500 text-white' : 'bg-navy-700 text-slate-200'} disabled:opacity-50`}>Auto</button>
          <button onClick={() => { const v = !turbo; setTurbo(v); save('gn_turbo', v); }} className={`rounded-md px-2 py-1 font-semibold ${turbo ? 'bg-amber-400 text-navy-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Turbo</button>
          <button onClick={() => setModal('paytable')} className="rounded-md bg-navy-700 px-2 py-1 font-semibold text-slate-200">Pays</button>
          <button onClick={() => setModal('rules')} className="rounded-md bg-navy-700 px-2 py-1 font-semibold text-slate-200">Rules</button>
          <button onClick={() => setModal('settings')} className="rounded-md bg-navy-700 px-2 py-1 font-semibold text-slate-200" aria-label="Settings">⚙</button>
        </div>
        <div className="flex gap-2.5 text-right leading-tight">
          <span>Last win<br /><b className="tabular-nums text-amber-200">{money(res?.win || 0)}</b></span>
          <span>Balance<br /><b className="tabular-nums text-slate-200">{money(user?.balance ?? 0)}</b></span>
        </div>
      </div>
      {autoStopped && <div className="rounded-md bg-navy-800 px-2 py-1 text-center text-[11px] text-slate-300">Auto stopped: {autoStopped}</div>}
      {dev && barMode === 'base' && mode === 'base' && !spinning && !auto && (
        <div className="rounded-lg border border-dashed border-fuchsia-400/60 bg-fuchsia-500/10 p-2 text-xs text-fuchsia-100">
          <div className="mb-1 font-bold">Test mode (practice: costs and pays nothing)</div>
          <div className="flex flex-wrap gap-1">
            {[['CASH', 'Wish: cash'], ['MULT', 'Wish: multiplier'], ['FREE', 'Wish: free spins'], ['TREASURE', 'Wish: treasure'], ['free', 'Free spins'], ['MINI', 'Mini'], ['MINOR', 'Minor'], ['MAJOR', 'Major'], ['GRAND', 'Grand']].map(([e, l]) => <button key={e} className="rounded bg-fuchsia-700 px-2 py-1" onClick={() => devTrigger(e)}>{l}</button>)}
          </div>
        </div>
      )}
    </div>
  );

  const payRow = (s, p) => (
    <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
      <div className="h-12 w-12 shrink-0"><GenieSym s={s} /></div>
      <div className="min-w-0 text-[11px] leading-tight text-slate-300"><div className="mb-0.5 font-semibold text-white">{GENIE_NAMES[s]}</div>{p.map((v, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{money(Math.floor((bet * v * PAY_SCALE) / LINES.length))}</b></div>)}</div>
    </div>
  );
  const paytable = (
    <>
      <section>
        <h3 className="mb-1 font-bold text-white">Line pays at {money(bet)} total bet</h3>
        <p className="mb-2 text-xs">Each of the 20 lines pays its best left-to-right win from reel 1. Wins on different lines add together. Free-spin wins are ×{FREE_MULT}.</p>
        <div className="grid grid-cols-2 gap-2">{Object.entries(PAYTABLE).map(([s, p]) => payRow(s, p))}</div>
      </section>
      <section className="space-y-2">
        <div className="flex items-center gap-2 rounded-lg bg-navy-800 p-2"><div className="h-12 w-12 shrink-0"><GenieSym s="GENIE" /></div><p className="text-xs"><b className="text-cyan-200">Genie wild</b>: the top-paying symbol, and it stands in for every symbol except lamps and stars. A line pays the better of the genies alone or the symbol they complete. In free spins a Genie fills its whole reel.</p></div>
        <div className="flex items-center gap-2 rounded-lg bg-navy-800 p-2"><div className="h-12 w-12 shrink-0"><GenieSym s="STAR" /></div><p className="text-xs"><b className="text-pink-200">Wishing Star</b> (anywhere): 3 / 4 / 5 pay {money(bet * SCATTER_PAY[3])} / {money(bet * SCATTER_PAY[4])} / {money(bet * SCATTER_PAY[5])} and award {FREE_SPINS[3]} / {FREE_SPINS[4]} / {FREE_SPINS[5]} free spins.</p></div>
        <div className="flex items-center gap-2 rounded-lg bg-navy-800 p-2"><div className="h-12 w-12 shrink-0"><GenieSym s="LAMP" /></div><p className="text-xs"><b className="text-amber-200">Magic Lamp</b> (anywhere): 3, 4 or 5 lamps summon the genie, who grants a wish. More lamps, better wishes.</p></div>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">Jackpots at {money(bet)}</h3>
        <JackpotBar bet={bet} />
        <p className="mt-2 text-xs">Won in Genie&apos;s Treasure by matching three jewels. Chance the treasure holds each jackpot: Mini {pct(Object.entries(JACKPOT_WEIGHTS), 'MINI')}, Minor {pct(Object.entries(JACKPOT_WEIGHTS), 'MINOR')}, Major {pct(Object.entries(JACKPOT_WEIGHTS), 'MAJOR')}, Grand {pct(Object.entries(JACKPOT_WEIGHTS), 'GRAND')}.</p>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">The 20 lines</h3>
        <div className="grid grid-cols-5 gap-1.5">
          {LINES.map((ln, k) => (
            <div key={k} className="rounded bg-navy-800 p-1">
              <div className="mb-0.5 text-center text-[9px] font-bold" style={{ color: LINE_COLOURS[k] }}>{k + 1}</div>
              <div className="grid grid-cols-5 gap-[1px]">{[0, 1, 2].map((r) => ln.map((row, c) => <span key={`${r}${c}`} className="aspect-square rounded-[1px]" style={{ background: row === r ? LINE_COLOURS[k] : 'rgba(255,255,255,.08)' }} />))}</div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
  const wishOdds = (n) => WISH_TYPES[n].map(([k]) => `${({ CASH: 'cash', MULT: 'multiplied', FREE: 'free spins', TREASURE: 'treasure' })[k]} ${pct(WISH_TYPES[n], k)}`).join(', ');
  const rules = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">The Magic Lamp wish</h3>
        <p>3, 4 or 5 lamps anywhere: the genie rises from the lamp and grants one wish, decided with the spin.</p>
        <ul className="list-disc space-y-1 pl-5 text-xs">
          <li><b>Instant prize</b>: {WISH_CASH.map(([v]) => `${v}x`).join(', ')} the bet, ×{LAMP_BOOST[4]} with 4 lamps, ×{LAMP_BOOST[5]} with 5.</li>
          <li><b>Multiplied prize</b>: {WISH_MULT_BASE.map(([v]) => `${v}x`).join(' / ')} (boosted the same way), multiplied by {WISH_MULTIPLIER.map(([v]) => `×${v}`).join(', ')}.</li>
          <li><b>Free spins</b>: {WISH_FREE[3]} / {WISH_FREE[4]} / {WISH_FREE[5]} for 3 / 4 / 5 lamps (added to the stars&apos; spins, or to free spins already running).</li>
          <li><b>Genie&apos;s Treasure</b>: the jackpot pick bonus.</li>
          <li className="text-slate-400">Chances: 3 lamps {wishOdds(3)}. 4 lamps {wishOdds(4)}. 5 lamps {wishOdds(5)}.</li>
        </ul>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Genie&apos;s Treasure</h3>
        <p>Twelve treasures hide jewels, cash prizes ({TREASURE_CASH.map(([v]) => `${v}x`).join(', ')}) and sometimes one multiplier ({TREASURE_MULT.map(([v]) => `×${v}`).join(' or ')}). Pick until three jewels of one kind match: you win that jackpot (Mini {JACKPOTS.MINI}x, Minor {JACKPOTS.MINOR}x, Major {JACKPOTS.MAJOR}x, Grand {JACKPOTS.GRAND.toLocaleString()}x the bet) plus every prize you found, times the multiplier.</p>
        <p className="text-xs text-slate-400">The jackpot is drawn when the bonus starts, and the server deals the board then. Each pick turns over the next treasure, so which tile you tap does not change what you win. Every treasure bonus wins a jackpot. Jackpots are fixed multiples of the bet, not progressive.</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Free spins</h3>
        <p>{FREE_SPINS[3]}, {FREE_SPINS[4]} or {FREE_SPINS[5]} free spins at the same bet. The round always pays at least {FREE_MIN_X}x the bet (topped up at the end if needed). All line and star wins are ×{FREE_MULT}, and every Genie expands to fill its reel. 3 / 4 / 5 stars add {RETRIGGER[3]} / {RETRIGGER[4]} / {RETRIGGER[5]} spins (up to 100 in total). Lamps can still grant wishes, including Genie&apos;s Treasure; the free spins carry on afterwards.</p>
      </section>
      <section className="space-y-2">
        <h3 className="font-bold text-white">Controls</h3>
        <ul className="list-disc space-y-1 pl-5 text-xs">
          <li><b>− / +</b> change the total bet ({money(STAKES[0])} to {money(STAKES[STAKES.length - 1])}); the jackpots follow it.</li>
          <li><b>Auto</b> plays a set number of paid spins. You must choose a loss limit; it also stops on any wish, free spins or treasure, on an optional big win, when your balance runs short, or when you tap Stop.</li>
          <li><b>Turbo</b> shortens the reel and feature animations. <b>Sound</b> (top right) has separate music and effects switches and volume sliders.</li>
          <li>Space bar spins on desktop keyboards (switch it off in ⚙).</li>
        </ul>
      </section>
      <section className="rounded-lg bg-navy-800 p-3 text-xs">
        <b className="text-white">Maths and fairness</b>: long-run return about 96% (measured over millions of simulated spins). Lines about 42 points, free spins about 28, wish prizes about 12, Genie&apos;s Treasure about 12 and star pays about 1.3. One spin in about 4.3 wins something. Free spins come about 1 in 180 spins and average about 40x the bet (never less than {FREE_MIN_X}x); a wish about 1 in 82 spins (cash wishes average about 14x, never less than 5x); the treasure about 1 in 750 spins, averaging about 90x. Maximum win {MAX_WIN_X.toLocaleString()}x the bet per spin or per free-spins round. Every result comes from the server&apos;s random number generator before the reels move; it never depends on your balance or past results, and tapping, timing or reloading can&apos;t change it. Each spin and pick is settled once.
      </section>
      <section className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3 text-xs text-slate-300">
        <b className="text-amber-200">About this game</b>: Golden Wishes is an original slot in the spirit of classic genie-themed jackpot slots. Art, names, sounds and maths are our own.
      </section>
    </>
  );

  const roundHistory = (view?.recent || []).slice(0, 10);
  const stageW = scene === 'treasure' ? 'min(100%, calc((100dvh - 430px) * 1.3 + 24px))' : 'min(100%, calc((100dvh - 470px) * 1.62 + 24px))';
  return (
    <PremiumShell game="genie" rtp="96%" title="Golden Wishes" tagline="5 × 3 · 20 lines · Magic Lamp wishes · Free spins · 4 jackpots" shake={shake}
      stageClass={`border-2 ${scene === 'treasure' ? 'border-amber-300/70 shadow-[0_0_60px_rgba(250,204,21,0.35)]' : scene === 'free' ? 'border-teal-300/60 shadow-[0_0_60px_rgba(45,212,191,0.3)]' : 'border-amber-400/50 shadow-[0_0_60px_rgba(192,38,211,0.3)]'}`}
      bg={hd ? <CanvasScene mode={scene} /> : <Scene mode={scene} />}
      below={<>{bar}
        <Modal open={modal === 'settings'} onClose={() => setModal(null)} title="Settings">
          <div className="space-y-2">
            <Switch label="Turbo spins" hint="Shorter reel and feature animations" on={turbo} onChange={(v) => { setTurbo(v); save('gn_turbo', v); }} />
            <Switch label="Enhanced graphics" hint="Canvas-rendered reels, particles and lighting. Switch off on older phones or to compare with the classic look." on={hd} onChange={(v) => { setHd(v); save('gn_hd', v); }} />
            <Switch label="Space bar to spin" hint="Desktop keyboards" on={space} onChange={(v) => { setSpace(v); save('gn_space', v); }} />
            <p className="px-1 pt-1 text-[11px] text-slate-500">Music and sound effects have separate switches and volume sliders under Sound, top right. Sound only starts after your first tap.</p>
          </div>
        </Modal>
        <Modal open={modal === 'auto'} onClose={() => setModal(null)} title="Auto spin">
          <div className="space-y-3 text-sm text-slate-300">
            <Choice label="Number of spins" options={[10, 25, 50, 100]} value={autoCfg.spins} onChange={(v) => setAutoCfg((c) => ({ ...c, spins: v }))} />
            <Choice label={`Stop if I lose (at ${money(stake)} a spin)`} options={[10, 25, 50, 100]} value={autoCfg.loss} onChange={(v) => setAutoCfg((c) => ({ ...c, loss: v }))} fmt={(v) => money(v * stake)} />
            <Choice label="Also stop on a single win of" options={[0, 20, 50, 100]} value={autoCfg.winStop} onChange={(v) => setAutoCfg((c) => ({ ...c, winStop: v }))} fmt={(v) => (v ? `${v}x+` : 'Off')} />
            <p className="text-xs text-slate-500">Auto spin always stops when a wish, free spins or Genie&apos;s Treasure starts, and when you tap Stop.</p>
            <button type="button" className="btn-primary w-full" disabled={low} onClick={() => { fx.click(); setModal(null); setAuto({ left: autoCfg.spins, loss: autoCfg.loss * stake, winStop: autoCfg.winStop, lost: 0 }); }}>Start {autoCfg.spins} spins at {money(stake)}</button>
          </div>
        </Modal>
        <Modal open={modal === 'paytable'} onClose={() => setModal(null)} title="Paytable"><div className="space-y-4 text-sm text-slate-300">{paytable}</div></Modal>
        <Modal open={modal === 'rules'} onClose={() => setModal(null)} title="Rules"><div className="space-y-4 text-sm text-slate-300">{rules}</div></Modal>
      </>}
      info={<>{paytable}{rules}</>}
      side={<>
        <SidePanel title="This session">
          <div className="space-y-1 text-xs text-slate-300">
            <div className="flex justify-between"><span>Staked</span><b className="tabular-nums text-white">{money(session.staked)}</b></div>
            <div className="flex justify-between"><span>Won</span><b className="tabular-nums text-white">{money(session.won)}</b></div>
            <div className="flex justify-between"><span>Net</span><b className={`tabular-nums ${sessionNet >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>{sessionNet >= 0 ? '+' : '−'}{money(Math.abs(sessionNet))}</b></div>
          </div>
        </SidePanel>
        <SidePanel title="Round history">
          {roundHistory.length ? (
            <ul className="space-y-1 text-xs">
              {roundHistory.map((r, k) => <li key={k} className="flex justify-between text-slate-300"><span>{r.kind === 'treasure' ? `Treasure · ${JP_NAME[r.jp] || ''}` : r.kind === 'free' ? 'Free spin' : 'Spin'} · {money(r.bet)}</span><b className={r.win ? 'text-amber-200' : 'text-slate-500'}>{money(r.win)}</b></li>)}
            </ul>
          ) : <div className="text-xs text-slate-500">No rounds yet.</div>}
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      <div className={`relative pt-0.5 ${turbo ? 'mr-turbo' : ''}`}>
        {practice && <div className="mb-1.5 rounded-md bg-fuchsia-600/80 px-2 py-1 text-center text-xs font-bold text-white">PRACTICE ROUND: no stake, no payout</div>}
        <div className="mx-auto" style={{ maxWidth: stageW }}>
          <div className="mb-1.5 flex items-center gap-1.5">
            <Host pose={host.pose} say={host.say} sayKey={host.key} cheer={host.cheer} />
            <div className="min-w-0 flex-1"><JackpotBar bet={bet} progress={progress} active={scene === 'treasure'} /></div>
          </div>
          {scene === 'free' && freeInfo && (
            <div className="mb-1.5 flex items-center justify-between gap-2">
              <div className="rounded-md bg-teal-200 px-2.5 py-1 text-xs font-extrabold uppercase text-teal-950 shadow-[0_0_16px_rgba(94,234,212,0.7)]">Free spins · {freeInfo.remaining} left · wins ×{FREE_MULT}</div>
              <div className="rounded-md bg-black/55 px-2 py-1 text-xs font-bold text-yellow-100 ring-1 ring-yellow-300/50">Total {money(freeInfo.total || 0)}</div>
            </div>
          )}
          <div className="relative rounded-2xl bg-[linear-gradient(160deg,#fef3c7,#b45309_25%,#fde047_50%,#92400e_75%,#fef3c7)] p-[4px] shadow-[0_0_34px_rgba(250,204,21,0.35)]">
            <div className="relative rounded-[12px] bg-[#12052b]/85 p-1.5 backdrop-blur-sm">
              {scene === 'treasure' && treasure ? (
                <Treasure data={treasure} bet={treasure.bet} fx={fx} request={requestPick} lock={guard} wait={t} onProgress={setProgress} onComplete={treasureComplete} />
              ) : (
                <div className="relative">
                  {hd ? <CanvasReels ref={canvasRef} grid={cells} lit={lit} trig={trig} wins={wins} lineShow={lineShow} expanding={expanding} coins={coins} tease={tease} turbo={turbo} onFail={() => setHd(false)} />
                    : <>
                      <div className="grid grid-cols-5 gap-1 sm:gap-1.5">
                        {[0, 1, 2, 3, 4].map((r) => <Reel key={r} index={r} cells={cells[r]} spinning={!reels.stopped[r]} landKey={`${spinId}-${r}${expanding.includes(r) ? 'x' : ''}`} lit={lit} trig={trig} turbo={turbo} tease={tease.includes(r) && !reels.stopped[r]} expanding={expanding.includes(r)} />)}
                      </div>
                      <Paylines wins={wins} show={lineShow} />
                    </>}
                  {(spinning || count.lamps + count.stars > 0) && (
                    <div className="pointer-events-none absolute right-1 top-1 z-20 flex gap-1 text-[10px] font-extrabold">
                      {count.lamps > 0 && <span className={`rounded-full px-1.5 py-0.5 ${count.lamps >= 3 ? 'bg-amber-300 text-amber-950' : 'bg-black/65 text-amber-200'}`}>Lamps {count.lamps}/3</span>}
                      {count.stars > 0 && <span className={`rounded-full px-1.5 py-0.5 ${count.stars >= 3 ? 'bg-pink-300 text-pink-950' : 'bg-black/65 text-pink-200'}`}>Stars {count.stars}/3</span>}
                    </div>
                  )}
                  {coins > 0 && !hd && <CoinShower key={coins} n={16} fall={320} />}
                </div>
              )}
              {banner && <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center"><div className={`st-reset rounded-2xl bg-gradient-to-b px-5 py-2 text-center font-[Cinzel,Georgia,serif] text-2xl font-black shadow-2xl sm:text-4xl ${banner.cls}`}>{banner.text}</div></div>}
            </div>
          </div>
          {scene !== 'treasure' && (
            <div className="mt-1.5 flex min-h-[3.25rem] flex-col items-center justify-center rounded-xl bg-black/50 px-2 py-1 text-center leading-tight backdrop-blur-sm">
              {res?.win ? <><div className="font-cond text-2xl font-extrabold tabular-nums text-amber-200 drop-shadow-[0_0_8px_rgba(250,204,21,0.6)]">WIN {money(res.win)}</div>{detail && <div className="mt-0.5 truncate text-[11px] text-white/80">{detail}</div>}</>
                : <div className="text-sm text-white/70">{spinning ? 'The reels are spinning…' : res ? 'No win this time' : '3 lamps summon the genie · 3 stars start free spins'}</div>}
            </div>
          )}
        </div>
        {wish && <Wish wish={wish.wish} bet={bet} fx={fx} wait={t} practice={wish.practice} onDone={() => { setWish(null); wishDone(); }} />}
        {jackpot && <JackpotCelebration jp={jackpot.jp} amount={jackpot.amount} bet={bet} detail={jackpot.detail} practice={jackpot.practice} fx={fx} onDone={() => { setJackpot(null); jpDone(); }} />}
        {intro && (
          <FeatureIntro title={INTRO[intro.type].title} subtitle={intro.resume ? 'Your bonus is still in progress. Carry on where you left off.' : INTRO[intro.type].text}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-28 w-28" aria-hidden="true">{intro.type === 'treasure' ? <Lamp /> : <WishStar />}</svg>}
            className={INTRO[intro.type].cls} cta={intro.resume ? 'Continue' : INTRO[intro.type].cta}
            onStart={() => { fx.click(); setIntro(null); introDone(); }} />
        )}
        {summary && !big && (
          <FeatureIntro title="FREE SPINS COMPLETE" subtitle={`${summary.played} free spins won ${money(summary.total)}.${summary.topUp ? ` That includes ${money(summary.topUp)} from the Genie's ${FREE_MIN_X}× guarantee.` : ''}${summary.practice ? ' Practice round: nothing was paid.' : ''}`}
            art={<svg viewBox="0 0 100 100" className="mb-2 h-24 w-24" aria-hidden="true"><GenieFigure pose="up" /></svg>}
            className="bg-[radial-gradient(ellipse_at_top,rgba(14,116,144,0.96),rgba(4,8,24,0.97))]" cta="Back to the palace"
            onStart={() => { setSummary(null); sumDone(); }} />
        )}
        {big && <BigWin game="genie" amount={big.amount} bet={bet} title={big.title} labels={['BIG WIN', 'MEGA WIN', 'EPIC WIN']} onDone={() => { setBig(null); bigDone(); }}
          cinematic={<>
            <svg viewBox="0 0 100 100" className="gn-emerge pointer-events-none absolute bottom-[4%] left-[2%] h-28 w-28 sm:h-36 sm:w-36" aria-hidden="true"><GenieFigure pose="wow" /></svg>
            {big.practice && <div className="pointer-events-none absolute inset-x-0 bottom-[6%] z-10 text-center"><span className="rounded-full bg-fuchsia-600 px-3 py-1 text-xs font-extrabold text-white">PRACTICE ROUND · NOT PAID</span></div>}
          </>} />}
        {jackpot == null && treasure && scene === 'treasure' && progress && Object.values(progress).some((n) => n === 2) && <div className="sr-only" aria-live="polite">One more matching jewel wins a jackpot</div>}
      </div>
    </PremiumShell>
  );
}

