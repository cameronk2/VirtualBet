// Golden Wishes – animated background on a canvas: a night sky that shifts
// colour with the mode, slow light rays, twinkling stars, shooting stars,
// drifting genie smoke, rising golden motes and the palace skyline.
// Particle counts are lower on phones; it pauses when the tab is hidden.
import { useEffect, useRef } from 'react';
import { GENIE_BG_IMG } from '../../../assets/genie/index.js';
import { dotTexture, fitCanvas, lerp, loadImg, loadSvg, loop, makeCanvas, puffTexture, reducedMotion, rnd, sparkTexture } from '../../../lib/fx2d.js';

const SKIES = {
  base: [[18, 5, 43], [59, 7, 100], [131, 24, 67], [180, 83, 9]],
  free: [[2, 6, 23], [30, 27, 75], [14, 116, 144], [20, 184, 166]],
  treasure: [[28, 10, 2], [69, 26, 3], [161, 98, 7], [250, 204, 21]],
};
const PALACE = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 120" width="800" height="240"><defs><linearGradient id="p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#facc15" stop-opacity=".5"/><stop offset=".35" stop-color="#3b0764" stop-opacity=".95"/><stop offset="1" stop-color="#12052b"/></linearGradient></defs><path d="M0 120V92h30V70c0-10 12-18 12-30 0 12 12 20 12 30v22h30V60c0-22 30-30 30-50 0 20 30 28 30 50v32h18V40c0-6 6-10 6-18 0 8 6 12 6 18v52h20V54c0-26 38-34 38-54 0 20 38 28 38 54v38h20V40c0-6 6-10 6-18 0 8 6 12 6 18v52h18V60c0-22 30-30 30-50 0 20 30 28 30 50v32h30V70c0-10 12-18 12-30 0 12 12 20 12 30v22h0v28z" fill="url(#p)"/><g fill="#fde68a" opacity=".85"><rect x="60" y="96" width="6" height="10" rx="3"/><rect x="150" y="96" width="6" height="10" rx="3"/><rect x="196" y="80" width="8" height="14" rx="4"/><rect x="250" y="96" width="6" height="10" rx="3"/><rect x="340" y="96" width="6" height="10" rx="3"/></g></svg>';

export default function CanvasScene({ mode = 'base' }) {
  const ref = useRef(null), box = useRef(null);
  const S = useRef({ mode, sky: SKIES.base.map((c) => [...c]) });
  S.current.mode = mode;
  useEffect(() => {
    const el = box.current, c = ref.current, st = S.current;
    const small = window.innerWidth < 640, still = reducedMotion();
    const tex = { mote: dotTexture('#fde68a', 48), smoke: puffTexture('rgba(94,234,212,1)', 160), smokeV: puffTexture('rgba(167,139,250,1)', 160), spark: sparkTexture('#ffffff', 48) };
    let W = 0, H = 0, g = null, palace = null, paint = null;
    if (GENIE_BG_IMG) loadImg(GENIE_BG_IMG).then((img) => { paint = img; }).catch(() => {});
    const tint = { free: [14, 116, 144], treasure: [161, 98, 7] }; st.tintA = st.tintA || { free: 0, treasure: 0 };
    loadSvg(PALACE).then((img) => { palace = makeCanvas(800, 240); palace.getContext('2d').drawImage(img, 0, 0); }).catch(() => {});
    const fit = () => { W = el.clientWidth; H = el.clientHeight; if (W && H) g = fitCanvas(c, W, H); };
    const ro = new ResizeObserver(fit); ro.observe(el); fit();
    const stars = Array.from({ length: small ? 36 : 70 }, () => ({ x: Math.random(), y: Math.random() * 0.6, s: rnd(0.6, 1.8), p: rnd(0, 6) }));
    const motes = Array.from({ length: still ? 0 : small ? 22 : 44 }, () => ({ x: Math.random(), y: Math.random(), v: rnd(0.02, 0.06), s: rnd(3, 9), p: rnd(0, 6) }));
    const smoke = Array.from({ length: still ? 0 : small ? 5 : 8 }, (_, i) => ({ x: Math.random(), y: rnd(0.4, 1.2), v: rnd(0.008, 0.02), s: rnd(0.45, 0.8), p: rnd(0, 6), v2: i % 2 }));
    let shoot = null, nextShoot = 3;
    const draw = (dt, t) => {
      if (!g) return;
      const target = SKIES[st.mode] || SKIES.base;
      st.sky.forEach((c2, i) => c2.forEach((v, k) => { c2[k] = lerp(v, target[i][k], Math.min(1, dt * 2.5)); }));
      const sky = g.createLinearGradient(0, 0, 0, H);
      [0, 0.45, 0.78, 1].forEach((o, i) => sky.addColorStop(o, `rgb(${st.sky[i].map(Math.round).join(',')})`));
      g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1; g.fillStyle = sky; g.fillRect(0, 0, W, H);
      if (paint) {
        // the painted backdrop (cover), slowly drifting, tinted for free spins / treasure
        const k = Math.max(W / paint.width, H / paint.height) * 1.06, pw = paint.width * k, ph = paint.height * k;
        g.drawImage(paint, (W - pw) / 2 + Math.sin(t * 0.05) * W * 0.02, (H - ph) / 2 + Math.cos(t * 0.04) * H * 0.01, pw, ph);
        for (const m of ['free', 'treasure']) {
          st.tintA[m] = lerp(st.tintA[m], st.mode === m ? 0.42 : 0, Math.min(1, dt * 2.5));
          if (st.tintA[m] > 0.01) { g.globalAlpha = st.tintA[m]; g.fillStyle = `rgb(${tint[m].join(',')})`; g.globalCompositeOperation = 'color'; g.fillRect(0, 0, W, H); }
        }
        g.globalCompositeOperation = 'source-over'; g.globalAlpha = 0.35; g.fillStyle = '#0b0418'; g.fillRect(0, 0, W, H); g.globalAlpha = 1;
      }
      // light rays from above
      if (!still) {
        g.save(); g.translate(W / 2, -H * 0.15); g.rotate(Math.sin(t * 0.08) * 0.15); g.globalCompositeOperation = 'lighter';
        for (let i = 0; i < 7; i++) {
          const a = (i - 3) * 0.22, len = H * 1.4;
          const grd = g.createLinearGradient(0, 0, Math.sin(a) * len, Math.cos(a) * len);
          grd.addColorStop(0, `rgba(253,230,138,${0.07 + 0.03 * Math.sin(t * 0.7 + i)})`); grd.addColorStop(1, 'rgba(253,230,138,0)');
          g.fillStyle = grd; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.sin(a - 0.05) * len, Math.cos(a - 0.05) * len); g.lineTo(Math.sin(a + 0.05) * len, Math.cos(a + 0.05) * len); g.closePath(); g.fill();
        }
        g.restore();
      }
      // stars
      g.fillStyle = '#fff';
      if (!paint) for (const s of stars) { g.globalAlpha = still ? 0.6 : 0.35 + 0.65 * Math.abs(Math.sin(t * 0.9 + s.p)); g.fillRect(s.x * W, s.y * H, s.s, s.s); }
      g.globalAlpha = 1;
      // shooting star
      if (!still) {
        nextShoot -= dt;
        if (nextShoot <= 0 && !shoot) { shoot = { x: rnd(0.1, 0.7) * W, y: rnd(0.02, 0.25) * H, t: 0 }; nextShoot = rnd(5, 11); }
        if (shoot) {
          shoot.t += dt; const k = shoot.t / 0.9, dx = W * 0.35 * k, dy = H * 0.14 * k;
          g.globalCompositeOperation = 'lighter';
          const grd = g.createLinearGradient(shoot.x + dx - W * 0.12, shoot.y + dy - H * 0.05, shoot.x + dx, shoot.y + dy);
          grd.addColorStop(0, 'rgba(255,255,255,0)'); grd.addColorStop(1, `rgba(255,255,255,${0.9 * (1 - k)})`);
          g.strokeStyle = grd; g.lineWidth = 2; g.beginPath(); g.moveTo(shoot.x + dx - W * 0.12, shoot.y + dy - H * 0.05); g.lineTo(shoot.x + dx, shoot.y + dy); g.stroke();
          g.globalAlpha = 1 - k; g.drawImage(tex.spark, shoot.x + dx - 10, shoot.y + dy - 10, 20, 20); g.globalAlpha = 1;
          if (k >= 1) shoot = null;
        }
      }
      // smoke
      g.globalCompositeOperation = 'lighter';
      for (const s of smoke) {
        s.y -= s.v * dt; if (s.y < -0.4) { s.y = 1.2; s.x = Math.random(); }
        const size = s.s * Math.min(W, 700) * (1.2 + (1 - s.y) * 0.4);
        g.globalAlpha = 0.16 + 0.06 * Math.sin(t * 0.5 + s.p);
        g.drawImage(s.v2 ? tex.smokeV : tex.smoke, s.x * W + Math.sin(t * 0.3 + s.p) * 30 - size / 2, s.y * H - size / 2, size, size);
      }
      // palace skyline
      g.globalCompositeOperation = 'source-over'; g.globalAlpha = 0.85;
      if (palace && !paint) { const ph = Math.min(H * 0.34, W * 0.3); const pw = ph * (800 / 240); for (let x = (W - pw) / 2 - pw; x < W; x += pw) g.drawImage(palace, x, H - ph, pw, ph); }
      // rising motes
      g.globalCompositeOperation = 'lighter';
      for (const m of motes) {
        m.y -= m.v * dt; if (m.y < -0.05) { m.y = 1.05; m.x = Math.random(); }
        g.globalAlpha = 0.5 + 0.5 * Math.sin(t * 2 + m.p);
        const x = m.x * W + Math.sin(t * 0.8 + m.p) * 14;
        g.drawImage(tex.mote, x - m.s, m.y * H - m.s, m.s * 2, m.s * 2);
      }
      g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
    };
    const stop = still ? (draw(0, 0), () => {}) : loop(draw);
    const id = still ? setInterval(() => draw(0.5, 0), 600) : 0;
    return () => { stop(); clearInterval(id); ro.disconnect(); };
  }, []);
  return <div ref={box} className="absolute inset-0 overflow-hidden"><canvas ref={ref} className="absolute inset-0" aria-hidden="true" /></div>;
}
