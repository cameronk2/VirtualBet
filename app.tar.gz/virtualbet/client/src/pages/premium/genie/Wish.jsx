// Golden Wishes – the Magic Lamp wish. The wish was decided by the server
// with the spin; this only presents it: the lamp is rubbed, smoke pours out,
// the genie rises and grants the wish (with a rolling multiplier for
// multiplied prizes). Tap to hurry it along.
import { useEffect, useRef, useState } from 'react';
import { GenieFigure, Lamp, WishStar, TREASURE_OBJECTS } from '../../../components/SlotArtGenie.jsx';
import { money } from '../../../lib/format.js';
import { WISH_MULTIPLIER } from '../../../../../server/games/genie/config.js';

const TITLE = { CASH: 'INSTANT PRIZE', MULT: 'MULTIPLIED PRIZE', FREE: 'FREE SPINS', TREASURE: "GENIE'S TREASURE" };
const LINE = { CASH: 'Riches for you, master!', MULT: 'Let me multiply that!', FREE: 'Fly with me among the stars!', TREASURE: 'Behold my treasure vault!' };

export default function Wish({ wish, bet, fx, wait, onDone, practice }) {
  const [phase, setPhase] = useState('rub');
  const [m, setM] = useState(null);
  const [shown, setShown] = useState(0);
  const skip = useRef(false);
  const done = useRef(false);
  const finish = () => { if (done.current) return; done.current = true; onDone(); };
  const w = (ms) => (skip.current ? Promise.resolve() : wait(ms));

  useEffect(() => {
    let alive = true;
    (async () => {
      fx.rub(); await w(1100); if (!alive) return;
      setPhase('smoke'); fx.smoke(); await w(800); if (!alive) return;
      setPhase('genie'); fx.appear(); fx.chant(); await w(1300); if (!alive) return;
      setPhase('reveal'); fx.grant();
      if (wish.type === 'MULT') {
        setShown(wish.base * bet);
        const ms = WISH_MULTIPLIER.map(([x]) => x);
        for (let k = 0; k < 10 && !skip.current; k++) { setM(ms[k % ms.length]); fx.mult(k % 4); await wait(110 + k * 18); if (!alive) return; }
        setM(wish.mult); fx.mult(4); await w(450);
        if (!alive) return;
        setPhase('total'); setShown(wish.x * bet); fx.coins(14); fx.laugh();
      } else if (wish.type === 'CASH') { setShown(wish.x * bet); fx.coins(10); fx.laugh(); } else fx.ooh();
      await w(2400); if (alive) finish();
    })();
    return () => { alive = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const tap = () => { if (phase === 'reveal' || phase === 'total') { if (wish.type !== 'MULT' || phase === 'total') finish(); else skip.current = true; } else skip.current = true; };
  const revealed = phase === 'reveal' || phase === 'total';
  return (
    <button type="button" onClick={tap} className="animate-fade-in absolute inset-0 z-40 flex flex-col items-center justify-center overflow-hidden rounded-2xl bg-[radial-gradient(ellipse_at_50%_70%,rgba(91,33,182,0.96),rgba(12,4,28,0.97))] px-3 pb-6 text-center" aria-live="polite" aria-label={`Magic Lamp wish: ${TITLE[wish.type]}`}>
      {revealed && <div className="gn-rays pointer-events-none absolute opacity-40" style={{ background: 'repeating-conic-gradient(rgba(250,204,21,.25) 0deg 8deg, transparent 8deg 20deg)', width: '200vmax', height: '200vmax', left: '50%', top: '50%', marginLeft: '-100vmax', marginTop: '-100vmax' }} />}
      <div className="relative text-[11px] font-extrabold uppercase tracking-[0.3em] text-amber-200/90">{wish.lamps} magic lamps{practice ? ' · practice' : ''}</div>
      <div className="relative mt-1 h-[46%] w-full max-w-[260px]">
        {/* lamp at the bottom, smoke rising, genie emerging */}
        <svg viewBox="0 0 100 100" className={`absolute bottom-0 left-1/2 -translate-x-1/2 transition-all duration-500 ${phase === 'rub' || phase === 'smoke' ? 'h-[80%]' : 'h-[40%]'} ${phase === 'rub' ? 'gn-rub' : ''}`} aria-hidden="true"><Lamp /></svg>
        {(phase === 'smoke' || phase === 'genie') && [0, 1, 2, 3].map((k) => <span key={k} className="gn-puff absolute bottom-[20%] left-1/2 h-24 w-24 -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(165,243,252,.9),rgba(94,234,212,.4)_50%,transparent_70%)] blur-md" style={{ animationDelay: `${k * 0.18}s`, marginLeft: (k - 1.5) * 18 }} />)}
        {phase !== 'rub' && phase !== 'smoke' && (
          <svg viewBox="0 0 100 100" className="gn-emerge absolute bottom-[26%] left-1/2 h-[78%] -translate-x-1/2" aria-hidden="true"><g className={revealed ? 'gn-float' : ''} style={{ transformBox: 'fill-box' }}><GenieFigure pose={revealed ? (wish.type === 'MULT' || wish.type === 'CASH' ? 'up' : 'magic') : 'magic'} /></g></svg>
        )}
        {phase === 'genie' && <div className="gn-bubble absolute -right-1 top-0 max-w-[60%] rounded-2xl bg-white px-2.5 py-1.5 text-xs font-bold text-violet-900 shadow-lg">Your wish is my command!</div>}
      </div>
      {revealed ? (
        <div className="gn-reveal relative mt-1 w-full max-w-xs rounded-2xl bg-gradient-to-b from-amber-200/95 via-yellow-400/95 to-amber-600/95 p-[3px] shadow-[0_0_40px_rgba(250,204,21,0.6)]">
          <div className="rounded-[14px] bg-[#1e0b3b]/95 px-3 py-2.5">
            <div className="font-[Cinzel,Georgia,serif] text-lg font-black tracking-wide text-amber-200 sm:text-xl">{TITLE[wish.type]}</div>
            <div className="text-[11px] text-violet-200">{LINE[wish.type]}</div>
            {wish.type === 'CASH' && <div className="gn-pop mt-1 font-cond text-4xl font-extrabold tabular-nums text-white drop-shadow-[0_0_12px_#facc15]">{money(shown)}</div>}
            {wish.type === 'MULT' && (
              <div className="mt-1 flex items-center justify-center gap-2 font-cond font-extrabold tabular-nums text-white">
                <span className="text-2xl">{money(wish.base * bet)}</span><span className="text-xl text-amber-300">×</span>
                <span key={m} className="gn-tick inline-block min-w-[3.2rem] rounded-lg bg-fuchsia-600 px-2 text-3xl shadow-[0_0_14px_#e879f9]">{m ?? '?'}</span>
                {phase === 'total' && <><span className="text-xl text-amber-300">=</span><span className="gn-pop text-3xl drop-shadow-[0_0_12px_#facc15]">{money(shown)}</span></>}
              </div>
            )}
            {wish.type === 'FREE' && <div className="gn-pop mt-1 flex items-center justify-center gap-2"><svg viewBox="0 0 100 100" className="h-12 w-12" aria-hidden="true"><WishStar label="FREE" /></svg><span className="font-cond text-4xl font-extrabold text-white">{wish.spins} FREE SPINS</span></div>}
            {wish.type === 'TREASURE' && <div className="gn-pop mt-1 flex items-center justify-center gap-1">{TREASURE_OBJECTS.map((o, i) => <svg key={i} viewBox="0 0 100 100" className="h-11 w-11" aria-hidden="true">{o}</svg>)}</div>}
            {wish.type === 'TREASURE' && <div className="mt-1 text-xs text-white/85">Match three jewels to win a jackpot</div>}
          </div>
        </div>
      ) : <div className="relative mt-2 h-[4.5rem] text-sm font-semibold text-violet-100/80">{phase === 'rub' ? 'Rubbing the lamp…' : 'The genie awakens…'}</div>}
      <div className="relative mt-3 text-[10px] uppercase tracking-widest text-white/50">{revealed ? 'Tap to continue' : 'Tap to skip'}</div>
    </button>
  );
}
