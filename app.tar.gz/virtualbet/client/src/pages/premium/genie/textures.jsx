// Golden Wishes – textures for the canvas renderer, built once from the SVG
// art: framed symbol tiles, glow silhouettes, the full-reel genie, the palace
// skyline and particle sprites. Card letters and the FREE label are drawn with
// canvas text so they can use the page's Cinzel font.
import { GenieDefs, GENIE_ART, Letter, TallGenie, WishStar } from '../../../components/SlotArtGenie.jsx';
import { coinTexture, defsMarkup, dotTexture, glowOf, loadImg, loadSvg, makeCanvas, puffTexture, roundRect, sparkTexture, svgMarkup } from '../../../lib/fx2d.js';
import { GENIE_IMG, GENIE_TALL_IMG } from '../../../assets/genie/index.js';

export const TILE = 256;                 // texture size per symbol (px)
const PREMIUM = ['PRINCESS', 'PALACE', 'CHEST', 'CROWN'];
const GEMS = ['AMETHYST', 'EMERALD', 'RUBY'];
const LETTERS = ['A', 'K', 'Q', 'J', 'T'];
const LETTER_GRAD = { A: ['#fecaca', '#e11d48', '#4c0519'], K: ['#bfdbfe', '#2563eb', '#172554'], Q: ['#f5d0fe', '#9333ea', '#2e1065'], J: ['#bbf7d0', '#10b981', '#064e3b'], T: ['#ccfbf1', '#14b8a6', '#134e4a'] };

const TILE_STYLE = (s) => (s === 'GENIE' ? ['#67e8f9', '#1e0b3b', '#67e8f9', 2.2]
  : s === 'LAMP' ? ['#fde047', '#3b0764', '#fde047', 2.2]
    : s === 'STAR' ? ['#f472b6', '#1e0b3b', '#f9a8d4', 2.2]
      : PREMIUM.includes(s) ? ['#facc15', '#2e1065', '#fcd34d', 1.4]
        : GEMS.includes(s) ? ['#5eead4', '#17082e', '#5eead4', 0.9]
          : ['#7c3aed', '#0f061e', '#a78bfa', 0.7]);

function tileBg(s) {
  const [c1, c2, ring, rw] = TILE_STYLE(s);
  const strong = rw > 2;
  return `<defs><radialGradient id="tb" cx="50%" cy="40%" r="70%"><stop offset="0" stop-color="${c1}" stop-opacity="${strong ? 0.55 : 0.35}"/><stop offset="1" stop-color="${c2}" stop-opacity=".95"/></radialGradient>
  <linearGradient id="tr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".22"/><stop offset=".5" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>
  <rect x="2" y="2" width="96" height="96" rx="9" fill="url(#tb)" stroke="${ring}" stroke-opacity="${strong ? 0.9 : 0.45}" stroke-width="${rw}"/>
  <rect x="4" y="4" width="92" height="44" rx="7" fill="url(#tr)"/>`;
}

function drawText(g, text, x, y, size, grad, stroke, weight = 800, sw = 0.1) {
  g.font = `${weight} ${size}px Cinzel, Georgia, serif`;
  g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  g.lineJoin = 'round'; g.lineWidth = size * sw; g.strokeStyle = stroke; g.strokeText(text, x, y);
  const fill = g.createLinearGradient(0, y - size * 0.8, 0, y);
  grad.forEach((c, i) => fill.addColorStop(i / (grad.length - 1), c));
  g.fillStyle = fill; g.fillText(text, x, y);
}

// Symbol tiers, so the important symbols stand out at a glance.
export const SPECIAL_STYLE = { GENIE: { c: '#22d3ee', label: 'WILD' }, LAMP: { c: '#facc15', label: 'BONUS' }, STAR: { c: '#f472b6', label: null } };
export const TIER = (s) => (SPECIAL_STYLE[s] ? 'special' : PREMIUM.includes(s) ? 'premium' : GEMS.includes(s) ? 'gem' : 'low');
export const TIER_SCALE = { special: 1.06, premium: 1, gem: 0.93, low: 0.86 };

/** Tier treatment on a finished tile: low symbols dimmed and muted; specials get a neon frame and a label. */
function decorate(c, s) {
  const g = c.getContext('2d'), T = c.width, tier = TIER(s);
  if (tier === 'low' || tier === 'gem') {
    g.save();
    g.globalCompositeOperation = 'saturation'; g.globalAlpha = tier === 'low' ? 0.45 : 0.15; g.fillStyle = '#808080'; g.fillRect(0, 0, T, T);
    g.globalCompositeOperation = 'source-atop'; g.globalAlpha = tier === 'low' ? 0.3 : 0.12; g.fillStyle = '#0b0418'; g.fillRect(0, 0, T, T);
    g.restore();
  }
  if (tier === 'special') {
    const st = SPECIAL_STYLE[s], w = T * 0.045;
    g.save();
    roundRect(g, w / 2, w / 2, T - w, T - w, T * 0.08);
    g.shadowColor = st.c; g.shadowBlur = T * 0.06; g.lineWidth = w; g.strokeStyle = st.c; g.stroke(); g.stroke();
    g.shadowBlur = 0; g.lineWidth = w * 0.3; g.strokeStyle = '#ffffff'; g.globalAlpha = 0.85; g.stroke();
    g.restore();
    if (st.label) {
      const bh = T * 0.2, by = T - bh - w * 0.6, bx = T * 0.14, bw = T * 0.72;
      g.save();
      roundRect(g, bx, by, bw, bh, bh / 2);
      const grd = g.createLinearGradient(0, by, 0, by + bh);
      grd.addColorStop(0, s === 'GENIE' ? '#0e7490' : '#7c2d12'); grd.addColorStop(1, s === 'GENIE' ? '#083344' : '#451a03');
      g.fillStyle = grd; g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = T * 0.03; g.fill();
      g.shadowBlur = 0; g.lineWidth = T * 0.012; g.strokeStyle = st.c; g.stroke();
      g.restore();
      drawText(g, st.label, T / 2, by + bh * 0.76, bh * 0.66, ['#ffffff', st.c], 'rgba(0,0,0,.55)', 800, 0.08);
    }
  }
}

let cache = null;
export function genieTextures() {
  if (cache) return cache;
  cache = (async () => {
    try { await Promise.race([document.fonts?.load('800 100px Cinzel'), new Promise((r) => setTimeout(r, 1500))]); } catch { /* fallback font */ }
    const defs = defsMarkup(<GenieDefs />);
    const sym = {}, glow = {};
    await Promise.all(Object.keys(GENIE_ART).map(async (s) => {
      if (GENIE_IMG[s]) {
        // painted symbol: the tile art already has its own frame
        try {
          const img = await loadImg(GENIE_IMG[s]);
          const c = makeCanvas(TILE, TILE), g = c.getContext('2d');
          roundRect(g, 0, 0, TILE, TILE, TILE * 0.07); g.clip();
          g.drawImage(img, 0, 0, TILE, TILE);
          decorate(c, s);
          sym[s] = c;
          glow[s] = glowOf(c, s === 'GENIE' ? '#67e8f9' : s === 'STAR' ? '#f472b6' : '#fde047', 26, 34);
          return;
        } catch { /* fall back to the drawn symbol */ }
      }
      const art = LETTERS.includes(s) ? <Letter ch={s} noText /> : s === 'STAR' ? <WishStar label="" /> : GENIE_ART[s];
      const svg = svgMarkup(<g transform="translate(6 6) scale(.88)">{art}</g>, { w: TILE, h: TILE, defs: defs + tileBg(s) });
      const img = await loadSvg(svg);
      const c = makeCanvas(TILE, TILE), g = c.getContext('2d');
      g.drawImage(img, 0, 0, TILE, TILE);
      if (LETTERS.includes(s)) drawText(g, s === 'T' ? '10' : s, TILE / 2, TILE * 0.665, TILE * (s === 'T' ? 0.36 : 0.46), LETTER_GRAD[s], '#fde047', 800);
      if (s === 'STAR') drawText(g, 'FREE', TILE / 2, TILE * 0.862, TILE * 0.125, ['#fffbeb', '#fde047', '#fbbf24'], 'rgba(59,7,100,.6)', 800, 0.05);
      sym[s] = c;
      glow[s] = glowOf(c, s === 'GENIE' ? '#67e8f9' : s === 'STAR' ? '#f472b6' : '#fde047', 26, 34);
    }));
    const tallImg = await (GENIE_TALL_IMG ? loadImg(GENIE_TALL_IMG).catch(() => null) : Promise.resolve(null)) || await loadSvg(svgMarkup(<TallGenie />, { viewBox: '0 0 100 300', w: TILE, h: TILE * 3, defs }));
    const tall = makeCanvas(TILE, TILE * 3); tall.getContext('2d').drawImage(tallImg, 0, 0, TILE, TILE * 3);
    return {
      sym, glow, tall, tallGlow: glowOf(tall, '#67e8f9', 30, 40),
      dot: dotTexture('#fde68a'), dotTeal: dotTexture('#5eead4'), dotPink: dotTexture('#f0abfc'),
      spark: sparkTexture('#fde047'), sparkTeal: sparkTexture('#67e8f9'), sparkPink: sparkTexture('#f472b6'),
      coin: coinTexture(72), smoke: puffTexture('rgba(165,243,252,1)'), smokeViolet: puffTexture('rgba(196,181,253,1)'),
    };
  })();
  return cache;
}
