import { useState } from 'react';
import { usePolling } from '../lib/hooks.js';
import { Link } from '../lib/router.jsx';
import { dayLabel, kickoffTime } from '../lib/format.js';
import Crest from '../components/Crest.jsx';
import OddsButton from '../components/OddsButton.jsx';
import { Empty, ErrorBox, Icon, LiveBadge, Loading, SimBadge } from '../components/ui.jsx';

const GROUPS = [
  { key: 'all', label: 'All markets' },
  { key: 'main', label: 'Main' },
  { key: 'goals', label: 'Goals' },
  { key: 'halves', label: 'Half' },
  { key: 'score', label: 'Correct Score' },
  { key: 'specials', label: 'Teams & Specials' },
];

const SOURCE_LABEL = { 'api-football': 'API-Football', 'football-data': 'football-data.org' };
const updated = (ms) => (ms ? new Date(ms).toLocaleString('en-GB', { weekday: 'short', hour: '2-digit', minute: '2-digit' }) : null);

function Scoreboard({ m }) {
  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-navy-700 bg-navy-800 px-4 py-2 text-xs">
        <div className="flex min-w-0 items-center gap-2">
          <Link to={`/upcoming?league=${m.league.code}`} className="truncate font-semibold text-slate-300 hover:text-white">{m.league.name}</Link>
          {m.league.country && <span className="hidden text-slate-500 sm:inline">{m.league.country}</span>}
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {m.simulated ? <SimBadge /> : m.real
            ? <span className="rounded bg-sky-500/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-sky-300">Real fixture</span>
            : <span className="rounded bg-sky-500/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-sky-300">Live data · {SOURCE_LABEL[m.source] || m.source}</span>}
        </div>
      </div>
      <div className="bg-gradient-to-b from-navy-800 to-navy-850 px-4 py-5 sm:px-8">
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 flex-1 flex-col items-center gap-2 text-center">
            <Crest team={m.home} size={56} />
            <span className="w-full truncate text-sm font-bold text-white sm:text-base">{m.home.name}</span>
          </div>
          <div className="flex shrink-0 flex-col items-center gap-1.5">
            {m.score ? (
              <div className="text-4xl font-extrabold tabular-nums text-white sm:text-5xl">{m.score.home}<span className="mx-2 text-slate-500">-</span>{m.score.away}</div>
            ) : (
              <div className="text-center">
                <div className="text-2xl font-extrabold text-white tabular-nums">{kickoffTime(m.kickoff)}</div>
                <div className="text-xs text-slate-400">{dayLabel(m.kickoff)}</div>
              </div>
            )}
            {m.live ? <span className="flex items-center gap-2"><LiveBadge /><span className="text-sm font-bold text-red-400 tabular-nums">{m.minuteLabel}</span></span>
              : m.minuteLabel && <span className="rounded bg-navy-700 px-2 py-0.5 text-xs font-bold uppercase text-slate-300">{m.minuteLabel}</span>}
            {m.ht && m.status !== 'LIVE_1H' && <span className="text-[11px] text-slate-500">HT {m.ht.home}-{m.ht.away}</span>}
          </div>
          <div className="flex min-w-0 flex-1 flex-col items-center gap-2 text-center">
            <Crest team={m.away} size={56} />
            <span className="w-full truncate text-sm font-bold text-white sm:text-base">{m.away.name}</span>
          </div>
        </div>
        {(m.corners || m.cards) && m.status !== 'SCHEDULED' && (
          <div className="mx-auto mt-4 grid max-w-xs grid-cols-3 gap-y-1 text-center text-xs text-slate-400">
            {m.corners && <><span className="font-bold text-white tabular-nums">{m.corners.home}</span><span>Corners</span><span className="font-bold text-white tabular-nums">{m.corners.away}</span></>}
            {m.cards && <><span className="font-bold text-white tabular-nums">{m.cards.home}</span><span>Cards</span><span className="font-bold text-white tabular-nums">{m.cards.away}</span></>}
          </div>
        )}
      </div>
    </div>
  );
}

function Events({ m }) {
  if (!m.events?.length) return null;
  return (
    <div className="card p-3">
      <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">Match events</h3>
      <ul className="max-h-48 space-y-1 overflow-y-auto text-sm">
        {m.events.map((e, i) => (
          <li key={i} className={`flex items-center gap-2 ${e.team === '2' ? 'flex-row-reverse text-right' : ''}`}>
            <span className="w-12 shrink-0 text-xs font-bold text-slate-400 tabular-nums">{e.label}</span>
            {e.type === 'goal' ? <Icon.ball className="h-4 w-4 shrink-0 text-brand-400" /> : <Icon.card className={`h-4 w-3 shrink-0 ${e.detail && /red/i.test(e.detail) ? 'text-red-500' : 'text-gold-400'}`} />}
            <span className="truncate text-slate-200">
              {e.type === 'goal' ? `Goal${e.score ? ` (${e.score})` : ''}` : e.detail || 'Card'} · {e.team === '1' ? m.home.name : m.away.name}{e.player ? ` · ${e.player}` : ''}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function MarketCard({ m, market }) {
  const [open, setOpen] = useState(true);
  const n = market.selections.length;
  const cols = market.key === 'CS' ? 'grid-cols-3' : n === 2 || n === 4 ? 'grid-cols-2' : 'grid-cols-1 sm:grid-cols-3';
  let content;
  if (market.key === 'CS') {
    const col = (pred) => market.selections.filter(pred);
    const home = col((s) => /^\d-\d$/.test(s.key) && +s.key[0] > +s.key[2]).concat(col((s) => s.key === 'OTH1'));
    const draw = col((s) => /^\d-\d$/.test(s.key) && +s.key[0] === +s.key[2]).concat(col((s) => s.key === 'OTHX'));
    const away = col((s) => /^\d-\d$/.test(s.key) && +s.key[0] < +s.key[2]).concat(col((s) => s.key === 'OTH2'));
    content = (
      <div className="grid grid-cols-3 gap-1.5">
        {[[m.home.name, home], ['Draw', draw], [m.away.name, away]].map(([title, list]) => (
          <div key={title} className="space-y-1.5">
            <div className="truncate text-center text-[11px] font-semibold text-slate-400">{title}</div>
            {list.map((s) => <OddsButton key={s.key} match={m} market={market} sel={s} label={s.key.startsWith('OTH') ? 'Other' : s.label} compact />)}
          </div>
        ))}
      </div>
    );
  } else {
    content = (
      <div className={`grid gap-1.5 ${market.key === 'HTFT' ? 'grid-cols-1 sm:grid-cols-3' : cols}`}>
        {market.selections.map((s) => <OddsButton key={s.key} match={m} market={market} sel={s} />)}
      </div>
    );
  }
  return (
    <section className="card relative overflow-hidden">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full items-center justify-between px-3 py-2.5 text-left hover:bg-navy-800">
        <span className="text-sm font-bold text-white">{market.name}</span>
        <span className="flex items-center gap-2">
          {market.suspended && <span className="rounded bg-gold-500/20 px-1.5 py-0.5 text-[10px] font-bold uppercase text-gold-400">Suspended</span>}
          <Icon.chevron className={`h-4 w-4 text-slate-500 transition-transform ${open ? 'rotate-90' : ''}`} />
        </span>
      </button>
      {open && <div className="px-3 pb-3">{content}</div>}
    </section>
  );
}

function closedMessage(m) {
  switch (m.status) {
    case 'FINISHED': return ['Betting closed', 'This match has finished. Open bets settle automatically using the verified result.'];
    case 'ABANDONED': return ['Match abandoned', 'Bets on this match are void and stakes are returned.'];
    case 'CANCELLED': return ['Match cancelled', 'Bets on this match are void and stakes are returned.'];
    case 'POSTPONED': return ['Match postponed', 'Betting is unavailable until the match is rescheduled.'];
    case 'IN_PLAY_PENDING': return ['Kicked off - betting closed', `This real match has started. Live scores aren't available in this version, so open bets settle as soon as the verified full-time score is added${m.lastUpdate ? ` (results last checked ${updated(m.lastUpdate)})` : ''}.`];
    default: return ['Markets unavailable', 'Markets will reopen shortly.'];
  }
}

export default function MatchPage({ id }) {
  const { data, loading, error, reload } = usePolling(`/api/matches/${encodeURIComponent(id)}`, 3000, [id]);
  const [group, setGroup] = useState('all');
  if (loading && !data) return <Loading label="Loading match…" />;
  if (error && !data) return error.status === 404 ? <div className="card"><Empty title="Match not found"><Link to="/" className="text-brand-400 underline">Back to home</Link></Empty></div> : <ErrorBox error={error} onRetry={reload} />;
  const m = data.match;
  const markets = m.markets.filter((mk) => group === 'all' || mk.group === group);
  const groups = GROUPS.filter((g) => g.key === 'all' || m.markets.some((mk) => mk.group === g.key));
  const [title, body] = closedMessage(m);

  return (
    <div className="space-y-3">
      <Link to={m.live ? '/live' : '/upcoming'} className="inline-flex items-center gap-1 text-xs font-semibold text-slate-400 hover:text-white">
        <Icon.chevron className="h-4 w-4 rotate-180" /> Back
      </Link>
      <Scoreboard m={m} />
      <Events m={m} />
      {m.markets.length ? (
        <>
          <div className="flex items-center justify-between gap-2">
            <div className="scrollbar-none flex gap-2 overflow-x-auto">
              {groups.map((g) => <button key={g.key} className={`chip ${group === g.key ? 'chip-active' : ''}`} onClick={() => setGroup(g.key)}>{g.label}</button>)}
            </div>
          </div>
          <p className="text-[11px] text-slate-500">
            {m.live ? 'In-play odds update with the score and clock. ' : ''}{m.real ? <>Real fixture. Odds are <b className="text-slate-400">simulated</b> from the data provider's win probabilities, in decimal format - not bookmaker prices. Betting closes at kick-off; markets that need half-time or event data aren't offered.</> : <>Odds are <b className="text-slate-400">simulated</b> by VirtualBet's model and shown in decimal format - they are not bookmaker prices.</>}
            {m.suspended && <b className="ml-1 text-gold-400">Markets are suspended for a moment.</b>}
          </p>
          <div className="space-y-2">
            {markets.map((mk) => <MarketCard key={mk.key} m={m} market={mk} />)}
          </div>
        </>
      ) : (
        <div className="card"><Empty title={title}>{body}</Empty></div>
      )}
    </div>
  );
}
