import { useEffect, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { usePolling } from '../lib/hooks.js';
import { Link, navigate, useLocation } from '../lib/router.jsx';
import { dateTime, odds, signed, money } from '../lib/format.js';
import { Empty, ErrorBox, Loading, Modal, StatusBadge, Tabs } from '../components/ui.jsx';

const BORDER = { WON: 'border-l-brand-500', LOST: 'border-l-red-500', OPEN: 'border-l-slate-500', VOID: 'border-l-gold-500', CASHED_OUT: 'border-l-sky-400' };

/** Two-tap Cash Out: tap to see the confirm button, tap again to cash out. */
export function CashOutButton({ b, onDone }) {
  const { setUser, toast } = useApp();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const co = b.cashOut;
  useEffect(() => { if (!confirm) return undefined; const t = setTimeout(() => setConfirm(false), 5000); return () => clearTimeout(t); }, [confirm]);
  if (!co) return null;
  if (!co.available) return <div className="mt-2 rounded-md bg-navy-800/70 px-3 py-2 text-center text-[11px] text-slate-500">Cash Out: {co.reason}</div>;
  const go = async (e) => {
    e.stopPropagation();
    if (!confirm) { setConfirm(true); return; }
    setBusy(true);
    try {
      const r = await api.post(`/api/bets/${encodeURIComponent(b.ref)}/cashout`, { value: co.value });
      if (r.user) setUser(r.user);
      toast(`Cashed out for ${money(r.value)} (virtual)`, 'success');
      onDone?.();
    } catch (err) {
      toast(err.message, 'error');
      onDone?.();
    } finally { setBusy(false); setConfirm(false); }
  };
  const profit = co.value - b.stake;
  return (
    <button type="button" onClick={go} disabled={busy}
      className={`mt-2 flex h-11 w-full items-center justify-center gap-2 rounded-lg text-sm font-extrabold transition-colors ${confirm ? 'bg-gold-500 text-navy-950 hover:bg-gold-400' : 'bg-sky-500/15 text-sky-200 ring-1 ring-sky-400/40 hover:bg-sky-500/25'}`}>
      {busy ? 'Cashing out…' : confirm ? `Confirm Cash Out ${money(co.value)}` : <>Cash Out {money(co.value)}<span className={`text-xs font-bold ${profit >= 0 ? 'text-brand-400' : 'text-red-300'}`}>{signed(profit)}</span></>}
    </button>
  );
}
const SEL_COLOR = { WON: 'text-brand-400', LOST: 'text-red-400', VOID: 'text-gold-400', OPEN: 'text-slate-400' };

export function LoginPrompt({ what }) {
  return (
    <div className="card">
      <Empty title={`Log in to see ${what}`}>
        <div className="mt-3 flex justify-center gap-2">
          <Link to="/login" className="btn-ghost">Log in</Link>
          <Link to="/register" className="btn-primary">Join free</Link>
        </div>
      </Empty>
    </div>
  );
}

function BetCard({ b, onOpen, onChanged }) {
  return (
    <div role="button" tabIndex={0} onClick={onOpen} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpen(); } }}
      className={`card block w-full cursor-pointer border-l-4 ${BORDER[b.status]} p-3 text-left transition-colors hover:bg-navy-800`}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <StatusBadge status={b.status} />
          <span className="text-sm font-bold text-white">{b.type === 'ACCA' ? `${b.selections.length}-fold accumulator` : 'Single'}</span>
        </div>
        <span className="font-mono text-[11px] text-slate-500">{b.ref}</span>
      </div>
      <ul className="mt-2 space-y-1">
        {b.selections.map((s, i) => (
          <li key={i} className="flex items-center justify-between gap-2 text-sm">
            <div className="min-w-0">
              <span className="font-semibold text-slate-100">{s.selection}</span>
              <span className="text-slate-500"> · {s.market}</span>
              <div className="truncate text-xs text-slate-500">
                {s.match}
                {s.matchStatus && ['LIVE_1H', 'HT', 'LIVE_2H'].includes(s.matchStatus) && <span className="ml-1 rounded bg-red-600 px-1 text-[10px] font-bold text-white">LIVE {s.liveScore}</span>}
                {s.result && <span className="ml-1 text-slate-400">FT {s.result}</span>}
              </div>
            </div>
            <span className={`shrink-0 text-xs font-bold tabular-nums ${SEL_COLOR[s.status]}`}>{odds(s.odds)}</span>
          </li>
        ))}
      </ul>
      <div className="mt-3 grid grid-cols-2 gap-2 border-t border-navy-700 pt-2 text-xs sm:grid-cols-4">
        <div><div className="text-slate-500">Stake</div><div className="font-semibold text-white tabular-nums">{money(b.stake)}</div></div>
        <div><div className="text-slate-500">Odds</div><div className="font-semibold text-white tabular-nums">{odds(b.totalOdds)}</div></div>
        <div><div className="text-slate-500">Potential return</div><div className="font-semibold text-white tabular-nums">{money(b.potentialReturn)}</div></div>
        <div><div className="text-slate-500">{b.status === 'CASHED_OUT' ? 'Cashed out for' : 'Actual return'}</div><div className={`font-semibold tabular-nums ${b.status === 'WON' ? 'text-brand-400' : b.status === 'CASHED_OUT' ? 'text-sky-300' : 'text-white'}`}>{b.status === 'OPEN' ? '–' : money(b.actualReturn)}</div></div>
      </div>
      <CashOutButton b={b} onDone={onChanged} />
      <div className="mt-1 text-[11px] text-slate-500">Placed {dateTime(b.createdAt)}</div>
    </div>
  );
}

export function BetDetail({ betRef, onClose }) {
  const { data, loading, error, reload } = usePolling(betRef ? `/api/bets/${encodeURIComponent(betRef)}` : null, 5000, [betRef]);
  const b = data?.bet;
  return (
    <Modal open={!!betRef} onClose={onClose} title="Bet details" wide>
      {loading && !b ? <Loading /> : error && !b ? <ErrorBox error={error} /> : b && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2"><StatusBadge status={b.status} /><span className="font-bold text-white">{b.type === 'ACCA' ? `${b.selections.length}-fold accumulator` : 'Single bet'}</span></div>
            <span className="font-mono text-sm text-brand-400">{b.ref}</span>
          </div>
          <dl className="grid grid-cols-2 gap-3 rounded-lg bg-navy-800 p-3 text-sm sm:grid-cols-3">
            <div><dt className="text-xs text-slate-500">Placed</dt><dd className="text-white">{dateTime(b.createdAt)}</dd></div>
            <div><dt className="text-xs text-slate-500">Settled</dt><dd className="text-white">{b.settledAt ? dateTime(b.settledAt) : 'Pending'}</dd></div>
            <div><dt className="text-xs text-slate-500">Stake</dt><dd className="font-semibold text-white tabular-nums">{money(b.stake)}</dd></div>
            <div><dt className="text-xs text-slate-500">{b.type === 'ACCA' ? 'Combined odds' : 'Odds'}</dt><dd className="font-semibold text-white tabular-nums">{odds(b.totalOdds)}</dd></div>
            <div><dt className="text-xs text-slate-500">Potential return</dt><dd className="font-semibold text-white tabular-nums">{money(b.potentialReturn)}</dd></div>
            <div><dt className="text-xs text-slate-500">Actual return</dt><dd className="font-semibold text-white tabular-nums">{b.status === 'OPEN' ? '–' : money(b.actualReturn)}</dd></div>
            {b.profit != null && <div><dt className="text-xs text-slate-500">Profit / loss</dt><dd className={`font-bold tabular-nums ${b.profit > 0 ? 'text-brand-400' : b.profit < 0 ? 'text-red-400' : 'text-gold-400'}`}>{signed(b.profit)}</dd></div>}
          </dl>
          <div>
            <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">Selections</h3>
            <div className="divide-y divide-navy-700 rounded-lg border border-navy-700">
              {b.selections.map((s, i) => (
                <div key={i} className="flex items-start justify-between gap-3 p-3 text-sm">
                  <div className="min-w-0">
                    <div className="font-semibold text-white">{s.selection}</div>
                    <div className="text-xs text-slate-400">{s.market}</div>
                    <Link to={`/match/${encodeURIComponent(s.matchId)}`} onClick={onClose} className="text-xs text-slate-500 hover:text-brand-400">{s.match} · {s.league}</Link>
                    {s.inPlay && <div className="mt-0.5 text-[11px] text-slate-500">Placed in-play at {s.scoreAtPlacement} ({s.minuteAtPlacement}')</div>}
                    {s.result && <div className="mt-0.5 text-[11px] text-slate-400">Full-time result: {s.result}</div>}
                    {s.voidReason && <div className="mt-0.5 text-[11px] text-gold-400">Void: {s.voidReason}</div>}
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="font-bold text-white tabular-nums">{odds(s.odds)}</div>
                    <StatusBadge status={s.status} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <CashOutButton b={b} onDone={reload} />
          {b.status === 'CASHED_OUT' && <p className="text-xs text-slate-500">This bet was cashed out early. Selections still show their own results for reference.</p>}
          {b.type === 'ACCA' && b.selections.some((s) => s.status === 'VOID') && (
            <p className="text-xs text-slate-500">Void selections are removed from the accumulator and the return is recalculated with the remaining odds.</p>
          )}
        </div>
      )}
    </Modal>
  );
}

export default function MyBets() {
  const { user } = useApp();
  const { query } = useLocation();
  const tab = query.get('tab') || 'open';
  const betRef = query.get('bet');
  const { data, loading, error, reload } = usePolling(user ? `/api/bets?status=${tab}` : null, 5000, [tab, user?.id]);
  if (user === null) return <LoginPrompt what="your bets" />;
  const setTab = (t) => navigate(`/my-bets?tab=${t}`);
  const open = (ref) => navigate(`/my-bets?tab=${tab}&bet=${ref}`);
  const close = () => navigate(`/my-bets?tab=${tab}`, { replace: true });

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold text-white">My Bets</h1>
      <Tabs tabs={[{ value: 'open', label: 'Open Bets' }, { value: 'settled', label: 'Settled Bets' }, { value: 'all', label: 'All Bets' }]} value={tab} onChange={setTab} />
      {loading && !data ? <Loading /> : error && !data ? <ErrorBox error={error} onRetry={reload} /> : data?.bets?.length ? (
        <div className="grid gap-2 xl:grid-cols-2">
          {data.bets.map((b) => <BetCard key={b.ref} b={b} onOpen={() => open(b.ref)} onChanged={reload} />)}
        </div>
      ) : (
        <div className="card">
          <Empty title={tab === 'open' ? 'No open bets' : tab === 'settled' ? 'No settled bets yet' : 'No bets yet'}>
            {tab === 'open' ? 'Bets you place appear here until their matches finish.' : 'Settled bets appear here automatically after full time.'}
            <div className="mt-3"><Link to="/" className="btn-primary">Browse matches</Link></div>
          </Empty>
        </div>
      )}
      <BetDetail betRef={betRef} onClose={close} />
    </div>
  );
}
