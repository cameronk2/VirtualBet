import { usePolling } from '../lib/hooks.js';
import { pct, signed } from '../lib/format.js';
import { ErrorBox, Loading } from '../components/ui.jsx';

export default function Leaderboard() {
  const { data, loading, error, reload } = usePolling('/api/leaderboard', 30000);
  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-white">Leaderboard</h1>
        <p className="mt-1 text-xs text-slate-400">Ranked by total virtual profit. Bragging rights only - there are no prizes, rewards or cash value of any kind. Accounts marked <b>demo</b> are sample players.</p>
      </div>
      {loading && !data ? <Loading /> : error && !data ? <ErrorBox error={error} onRetry={reload} /> : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[480px] text-sm">
            <thead className="bg-navy-800 text-left text-[11px] uppercase tracking-wider text-slate-400">
              <tr><th className="w-14 px-3 py-2">#</th><th className="px-3 py-2">Username</th><th className="px-3 py-2 text-right">Virtual profit</th><th className="px-3 py-2 text-right">Win %</th><th className="px-3 py-2 text-right">Bets</th></tr>
            </thead>
            <tbody className="divide-y divide-navy-700">
              {data.rows.map((r) => (
                <tr key={r.username} className={r.you ? 'bg-brand-500/10' : ''}>
                  <td className="px-3 py-2.5">
                    <span className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${r.rank === 1 ? 'bg-gold-500 text-navy-950' : r.rank <= 3 ? 'bg-navy-500 text-white' : 'text-slate-400'}`}>{r.rank}</span>
                  </td>
                  <td className="px-3 py-2.5 font-semibold text-white">
                    {r.username}
                    {r.you && <span className="ml-2 rounded bg-brand-500 px-1.5 py-0.5 text-[10px] font-bold text-navy-950">YOU</span>}
                    {r.demo && <span className="ml-2 rounded bg-navy-600 px-1.5 py-0.5 text-[10px] font-bold uppercase text-slate-300">demo</span>}
                  </td>
                  <td className={`px-3 py-2.5 text-right font-bold tabular-nums ${r.profit > 0 ? 'text-brand-400' : r.profit < 0 ? 'text-red-400' : 'text-slate-300'}`}>{signed(r.profit)}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums text-slate-300">{pct(r.winRate)}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums text-slate-300">{r.bets}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
