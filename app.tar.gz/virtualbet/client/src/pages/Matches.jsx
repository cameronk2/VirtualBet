import { useMemo, useState } from 'react';
import { Link, navigate, useLocation } from '../lib/router.jsx';
import { usePolling } from '../lib/hooks.js';
import { dayLabel } from '../lib/format.js';
import { MatchList } from '../components/MatchRow.jsx';
import { Empty, ErrorBox, Loading } from '../components/ui.jsx';
import { useApp } from '../state/AppContext.jsx';

export function LivePage() {
  const { config } = useApp();
  const { data, loading, error, reload } = usePolling('/api/matches?view=live', 3000);
  const results = usePolling('/api/matches?view=results', 15000);
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="flex items-center gap-2 text-xl font-extrabold text-white"><span className="h-2.5 w-2.5 animate-pulse rounded-full bg-red-500" />Live Football</h1>
        <span className="text-xs text-slate-500">Updates automatically</span>
      </div>
      {config?.localMode && (
        <p className="rounded-md border border-gold-500/30 bg-gold-500/10 px-3 py-2 text-xs text-gold-400">
          Live scores for real matches aren't available in this version, so in-play betting uses <b>simulated practice matches</b>. Real matches that have kicked off are listed here until their result is in.
        </p>
      )}
      {loading && !data ? <Loading /> : error && !data ? <ErrorBox error={error} onRetry={reload} /> : data.matches.length ? (
        <MatchList matches={data.matches} />
      ) : (
        <div className="card"><Empty title="No matches in play">Check the <Link to="/upcoming" className="text-brand-400 underline">upcoming fixtures</Link> - matches move here automatically at kick-off.</Empty></div>
      )}
      {results.data?.matches?.length > 0 && (
        <section>
          <h2 className="section-title mb-2">Recent results</h2>
          <MatchList matches={results.data.matches.slice(0, 20)} />
        </section>
      )}
    </div>
  );
}

export function UpcomingPage() {
  const { query } = useLocation();
  const league = query.get('league');
  const { data, loading, error, reload } = usePolling(`/api/matches?view=upcoming${league ? `&league=${league}` : ''}`, 10000, [league]);
  const leagues = usePolling('/api/leagues', 30000);
  const days = useMemo(() => {
    const out = new Map();
    for (const m of data?.matches || []) {
      const d = dayLabel(m.kickoff);
      if (!out.has(d)) out.set(d, []);
      out.get(d).push(m);
    }
    return [...out];
  }, [data]);
  const leagueName = leagues.data?.leagues.find((l) => l.code === league)?.name;
  const [term, setTerm] = useState('');
  const shown = useMemo(() => {
    const t = term.trim().toLowerCase();
    if (!t) return days;
    return days.map(([d, list]) => [d, list.filter((m) => `${m.home.name} ${m.away.name} ${m.league.name}`.toLowerCase().includes(t))]).filter(([, l]) => l.length);
  }, [days, term]);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-extrabold text-white">{leagueName || 'Upcoming Matches'}</h1>
      <div className="scrollbar-none -mx-3 flex gap-2 overflow-x-auto px-3 sm:mx-0 sm:flex-wrap sm:px-0">
        <button className={`chip ${!league ? 'chip-active' : ''}`} onClick={() => navigate('/upcoming')}>All competitions</button>
        {(leagues.data?.leagues || []).filter((l) => l.upcoming > 0).map((l) => (
          <button key={l.code} className={`chip ${league === l.code ? 'chip-active' : ''}`} onClick={() => navigate(`/upcoming?league=${l.code}`)}>{l.name}</button>
        ))}
      </div>
      <div className="relative">
        <svg viewBox="0 0 24 24" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></svg>
        <input type="search" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Search teams or competitions" aria-label="Search fixtures"
          className="input h-11 w-full pl-9" />
      </div>
      {loading && !data ? <Loading /> : error && !data ? <ErrorBox error={error} onRetry={reload} /> : term && !shown.length ? (
        <div className="card"><Empty title={`No fixtures match "${term}"`}>Try a team name like Arsenal or Real Madrid.</Empty></div>
      ) : shown.length ? (
        shown.map(([day, list]) => (
          <section key={day}>
            <h2 className="section-title mb-2">{day}</h2>
            <MatchList matches={list} hideDay />
          </section>
        ))
      ) : (
        <div className="card"><Empty title="No upcoming fixtures">{league ? 'Nothing scheduled in this competition right now.' : 'New fixtures appear here automatically.'}</Empty></div>
      )}
    </div>
  );
}
