import { useEffect, useRef, useState } from 'react';
import GameShell, { useGame } from '../components/GameShell.jsx';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import WinCelebration from '../components/WinCelebration.jsx';
import { SCRATCH_PRIZES, TICKETS } from '../../../server/games/instant.js';

const fmtPrize = (p) => `£${p / 100 >= 1 ? (p / 100).toLocaleString('en-GB') : (p / 100).toFixed(2)}`;

function ScratchLayer({ onProgress, done }) {
  const ref = useRef(null);
  const drawing = useRef(false);
  useEffect(() => {
    const c = ref.current;
    const ctx = c.getContext('2d');
    const r = c.getBoundingClientRect();
    c.width = r.width * 2; c.height = r.height * 2;
    const g = ctx.createLinearGradient(0, 0, c.width, c.height);
    g.addColorStop(0, '#d4d4d8'); g.addColorStop(0.5, '#a1a1aa'); g.addColorStop(1, '#e4e4e7');
    ctx.fillStyle = g; ctx.fillRect(0, 0, c.width, c.height);
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    for (let i = 0; i < 400; i++) ctx.fillRect(Math.random() * c.width, Math.random() * c.height, 2, 2);
    ctx.fillStyle = '#52525b'; ctx.font = `800 ${c.width / 14}px system-ui`; ctx.textAlign = 'center';
    ctx.fillText('SCRATCH HERE', c.width / 2, c.height / 2 + c.width / 40);
  }, []);
  const scratch = (e) => {
    if (!drawing.current || done) return;
    const c = ref.current, ctx = c.getContext('2d'), r = c.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width) * c.width, y = ((e.clientY - r.top) / r.height) * c.height;
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath(); ctx.arc(x, y, c.width / 16, 0, Math.PI * 2); ctx.fill();
    if (Math.random() < 0.15) {
      const d = ctx.getImageData(0, 0, c.width, c.height).data;
      let clear = 0;
      for (let i = 3; i < d.length; i += 64) if (d[i] === 0) clear++;
      onProgress(clear / (d.length / 64));
    }
  };
  return (
    <canvas ref={ref} className={`absolute inset-0 h-full w-full touch-none rounded-xl transition-opacity duration-500 ${done ? 'pointer-events-none opacity-0' : ''}`}
      onPointerDown={(e) => { drawing.current = true; e.currentTarget.setPointerCapture(e.pointerId); scratch(e); }}
      onPointerMove={scratch} onPointerUp={() => { drawing.current = false; }} onPointerCancel={() => { drawing.current = false; }} aria-label="Scratch to reveal" />
  );
}

export default function Scratch() {
  const { history, busy, play, commit } = useGame('scratch');
  const [price, setPrice] = useState(200);
  const [ticket, setTicket] = useState(null);
  const [revealed, setRevealed] = useState(false);
  const [n, setN] = useState(0);
  const [big, setBig] = useState(null);

  const buy = async () => {
    const out = await play('buy', { price });
    if (!out) return;
    setTicket(out); setRevealed(false); setN((x) => x + 1); sfx.card();
  };
  const reveal = () => {
    if (revealed || !ticket) return;
    setRevealed(true);
    commit();
    if (ticket.win >= price * 10) setBig({ amount: ticket.win, bet: price }); else if (ticket.win) sfx.win(); else sfx.lose();
  };
  const winVal = ticket?.win || 0;

  return (
    <GameShell title="Scratchcards" subtitle="Match three prizes to win that prize" rtp="68%" history={history}
      rules={<>
        <p>Each card has nine prize amounts. Find three the same and you win that amount. There's never more than one winning prize on a card.</p>
        <p>Prizes are 1x, 2x, 5x, 10x, 20x, 100x and 500x the ticket price. About 1 in {Math.round(1 / SCRATCH_PRIZES.reduce((a, p) => a + p[1], 0))} cards wins something, and the 500x top prize comes up about once in 25,000 cards.</p>
        <p className="text-slate-500">Scratchcards pay back only about 68% of what's spent over time, far less than the other games here, which is typical of real scratchcards too. The result is fixed when you buy the card; scratching only reveals it.</p>
      </>}>
      <section className="relative flex flex-col items-center gap-3 overflow-hidden rounded-2xl bg-[radial-gradient(ellipse_at_top,#3f6212_0%,#1a2e05_60%,#0b1520_100%)] p-4 ring-1 ring-lime-900">
        {big && <WinCelebration game="scratch" amount={big.amount} bet={big.bet} onDone={() => setBig(null)} className="absolute inset-0 z-30 rounded-2xl" />}
        {ticket ? (
          <div key={n} className="animate-fade-in w-full max-w-xs rounded-2xl bg-gradient-to-br from-yellow-200 via-amber-300 to-lime-400 p-3 shadow-2xl">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-display text-xl tracking-wide text-lime-900">LUCKY LIME</span>
              <span className="rounded-full bg-lime-900 px-2 py-0.5 text-xs font-bold text-yellow-200">{money(ticket.price)}</span>
            </div>
            <div className="relative">
              <div className="grid grid-cols-3 gap-2 rounded-xl bg-lime-900/90 p-2">
                {ticket.cells.map((v, i) => (
                  <div key={i} className={`flex aspect-square items-center justify-center rounded-lg font-cond text-lg font-extrabold ${revealed && winVal && v === winVal ? 'animate-win-pulse bg-gold-400 text-navy-950 ring-2 ring-white' : 'bg-yellow-100 text-lime-900'}`}>{fmtPrize(v)}</div>
                ))}
              </div>
              <ScratchLayer key={n} done={revealed} onProgress={(f) => { if (f > 0.55) reveal(); }} />
            </div>
            <div className="mt-2 min-h-7 text-center font-cond text-xl font-extrabold text-lime-950">
              {revealed ? (winVal ? `You won ${fmtPrize(winVal)}!` : 'Not a winner this time') : 'Match 3 to win'}
            </div>
          </div>
        ) : (
          <div className="py-12 text-center text-sm text-lime-100/70">Pick a ticket price and buy a card</div>
        )}
        {ticket && !revealed && <button className="btn-ghost" onClick={reveal}>Reveal all</button>}
      </section>

      <div className="card flex flex-wrap items-center gap-3 p-3">
        <div className="flex gap-1 rounded-lg bg-navy-800 p-1">
          {TICKETS.map((p) => <button key={p} onClick={() => setPrice(p)} className={`rounded-md px-4 py-1.5 font-cond text-base font-bold ${price === p ? 'bg-lime-400 text-navy-950' : 'text-slate-300'}`}>{money(p).replace('.00', '')}</button>)}
        </div>
        <button className="btn ml-auto h-12 min-w-40 rounded-full bg-lime-400 text-base font-extrabold text-navy-950 hover:bg-lime-300" disabled={busy || (ticket && !revealed)} onClick={buy}>
          {ticket && !revealed ? 'Scratch your card first' : `Buy card · ${money(price)}`}
        </button>
      </div>
    </GameShell>
  );
}
