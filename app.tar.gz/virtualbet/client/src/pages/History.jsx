import { useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { usePolling } from '../lib/hooks.js';
import { navigate, useLocation } from '../lib/router.jsx';
import { dateTime, odds, pct, signed, money } from '../lib/format.js';
import { Empty, ErrorBox, Loading, StatTile, StatusBadge } from '../components/ui.jsx';
import { BetsNav } from '../components/Layout.jsx';
import { MarketBars, PLChart, WinLossDonut } from '../components/Charts.jsx';
import { BetDetail, LoginPrompt } from './MyBets.jsx';

function HistoryTable({ onOpen }) {
  const [filter, setFilter] = useState('ALL');
  const { data, loading, error, reload } = usePolling('/api/bets?status=settled&limit=500', 15000);
  if (loading && !data) return <Loading />;
  if (error && !data) return <ErrorBox error={error} onRetry={reload} />;
  const bets = (data?.bets || []).filter((b) => filter === 'ALL' || b.status === filter);
  return (
    <div className="space-y-3">
      <div className="scrollbar-none -mx-3 flex gap-2 overflow-x-auto px-3 sm:mx-0 sm:px-0">
        {['ALL', 'WON', 'LOST', 'CASHED_OUT', 'VOID'].map((f) => <button key={f} className={`chip ${filter === f ? 'chip-active' : ''}`} onClick={() => setFilter(f)}>{{ ALL: 'All', WON: 'Won', LOST: 'Lost', CASHED_OUT: 'Cashed out', VOID: 'Void' }[f]}</button>)}
      </div>
      {bets.length ? (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="bg-navy-800 text-left text-[11px] uppercase tracking-wider text-slate-400">
              <tr><th className="px-3 py-2">Settled</th><th className="px-3 py-2">Bet</th><th className="px-3 py-2 text-right">Stake</th><th className="px-3 py-2 text-right">Odds</th><th className="px-3 py-2 text-right">Return</th><th className="px-3 py-2 text-right">P/L</th><th className="px-3 py-2">Status</th></tr>
            </thead>
            <tbody className="divide-y divide-navy-700">
              {bets.map((b) => (
                <tr key={b.ref} onClick={() => onOpen(b.ref)} className="cursor-pointer hover:bg-navy-800">
                  <td className="whitespace-nowrap px-3 py-2 text-xs text-slate-400">{dateTime(b.settledAt)}</td>
                  <td className="max-w-[260px] px-3 py-2">
                    <div className="truncate font-semibold text-slate-100">{b.type === 'ACCA' ? `${b.selections.length}-fold accumulator` : b.selections[0].selection}</div>
                    <div className="truncate text-xs text-slate-500">{b.type === 'ACCA' ? b.selections.map((s) => s.selection).join(', ') : `${b.selections[0].market} · ${b.selections[0].match}`}</div>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">{money(b.stake)}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{odds(b.totalOdds)}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{money(b.actualReturn)}</td>
                  <td className={`px-3 py-2 text-right font-bold tabular-nums ${b.profit > 0 ? 'text-brand-400' : b.profit < 0 ? 'text-red-400' : 'text-gold-400'}`}>{signed(b.profit)}</td>
                  <td className="px-3 py-2"><StatusBadge status={b.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <div className="card"><Empty title="No settled bets">Your bet history builds up as your bets are settled.</Empty></div>}
    </div>
  );
}

function Statistics() {
  const { data, loading, error, reload } = usePolling('/api/stats', 15000);
  if (loading && !data) return <Loading />;
  if (error && !data) return <ErrorBox error={error} onRetry={reload} />;
  const s = data.stats;
  const tone = (v) => (v > 0 ? 'pos' : v < 0 ? 'neg' : null);
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        <StatTile label="Total bets placed" value={s.totalBets} sub={`${s.openBets} still open`} />
        <StatTile label="Won" value={s.won} />
        <StatTile label="Lost" value={s.lost} sub={s.void ? `${s.void} void` : null} />
        <StatTile label="Win percentage" value={pct(s.winRate)} sub="of settled, excluding void" />
        <StatTile label="Total staked" value={money(s.staked)} />
        <StatTile label="Total returned" value={money(s.returned)} />
        <StatTile label="Virtual profit / loss" value={signed(s.profit)} tone={tone(s.profit)} />
        <StatTile label="Average odds" value={s.averageOdds ? odds(s.averageOdds) : '–'} />
        <StatTile label="Best winning bet" value={s.bestWin ? signed(s.bestWin.profit) : '–'} tone={s.bestWin ? 'pos' : null} sub={s.bestWin ? `${money(s.bestWin.stake)} @ ${odds(s.bestWin.odds)} · ${s.bestWin.ref}` : null} />
        <StatTile label="Biggest losing bet" value={s.biggestLoss ? signed(-s.biggestLoss.stake) : '–'} tone={s.biggestLoss ? 'neg' : null} sub={s.biggestLoss ? `@ ${odds(s.biggestLoss.odds)} · ${s.biggestLoss.ref}` : null} />
        <StatTile label="Most profitable market" value={s.mostProfitableMarket ? s.mostProfitableMarket.market : '–'} sub={s.mostProfitableMarket ? signed(s.mostProfitableMarket.profit) : 'No profitable market yet'} />
        <StatTile label="P/L last 7 days" value={signed(s.profit7d)} tone={tone(s.profit7d)} />
      </div>
      <div className="grid gap-3 xl:grid-cols-5">
        <section className="card p-4 xl:col-span-3">
          <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">Virtual profit / loss over time</h3>
          <PLChart series={s.series} />
        </section>
        <section className="card p-4 xl:col-span-2">
          <h3 className="mb-4 text-xs font-bold uppercase tracking-wider text-slate-400">Winning vs losing bets</h3>
          <WinLossDonut won={s.won} lost={s.lost} voided={s.void} />
        </section>
      </div>
      <section className="card p-4">
        <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">Performance by betting market</h3>
        <MarketBars markets={s.markets} />
      </section>
      <p className="rounded-md border border-navy-700 bg-navy-900 p-3 text-xs leading-relaxed text-slate-400">
        Bookmaker odds include a margin, so over many bets most bettors lose. If your virtual P/L is trending down, that is exactly what would have happened to real money.
      </p>
    </div>
  );
}

export default function History() {
  const { user } = useApp();
  const { query } = useLocation();
  const tab = query.get('tab') || 'history';
  const [betRef, setBetRef] = useState(null);
  if (user === null) return <LoginPrompt what="your bet history" />;
  if (!user) return <Loading />;
  return (
    <div className="space-y-3">
      <BetsNav />
      <h1 className="text-xl font-extrabold text-white">{tab === 'stats' ? 'Your statistics' : 'Bet history'}</h1>
      {tab === 'stats' ? <Statistics /> : <HistoryTable onOpen={setBetRef} />}
      <BetDetail betRef={betRef} onClose={() => setBetRef(null)} />
    </div>
  );
}
