import { useEffect, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { Link, navigate } from '../lib/router.jsx';
import { Spinner } from '../components/ui.jsx';

export default function Auth({ mode }) {
  const { user, setUser, startSession, toast, config } = useApp();
  const local = !!config?.localMode;
  const [profileName, setProfileName] = useState(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const isRegister = mode === 'register';

  useEffect(() => { if (user) navigate('/', { replace: true }); }, [user]);
  useEffect(() => { setError(null); }, [mode]);
  useEffect(() => {
    if (local) api.get('/api/me').then((d) => { setProfileName(d.profileName); if (d.profileName) setUsername(d.profileName); }).catch(() => {});
  }, [local]);

  const submit = async (e) => {
    e?.preventDefault();
    setBusy(true); setError(null);
    try {
      const creating = isRegister || (local && !profileName);
      const d = await api.post(creating ? '/api/auth/register' : '/api/auth/login', { username: username.trim(), password });
      startSession();
      setUser(d.user);
      toast(creating && !profileName ? 'Welcome! £100 of free virtual money added to your wallet.' : `Welcome back, ${d.user.username}`, 'success');
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  if (local && !isRegister && profileName) {
    return (
      <div className="mx-auto max-w-md py-6">
        <div className="card p-6">
          <h1 className="text-2xl font-extrabold text-white">Welcome back</h1>
          <p className="mt-1 text-sm text-slate-400">Your wallet and bets are saved.</p>
          {error && <p className="mt-4 rounded bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
          <button className="btn-primary mt-5 h-11 w-full" disabled={busy} onClick={submit}>{busy ? <Spinner className="h-4 w-4" /> : `Continue as ${profileName}`}</button>
        </div>
      </div>
    );
  }
  const showRegister = isRegister || local;
  return (
    <div className="mx-auto max-w-md py-6">
      <div className="card p-6">
        <h1 className="text-2xl font-extrabold text-white">{showRegister ? (local ? 'Create your player profile' : 'Join VirtualBet') : 'Log in'}</h1>
        <p className="mt-1 text-sm text-slate-400">{showRegister ? (local ? 'Pick a username and get £100 of free virtual money. No password or payment details needed.' : 'Free account · £100 of free virtual money · no payment details, ever.') : 'Welcome back. Virtual play only.'}</p>
        <form onSubmit={submit} className="mt-5 space-y-4">
          <div>
            <label className="label" htmlFor="username">Username</label>
            <input id="username" className="input" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} required maxLength={20} />
          </div>
          {!local && <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" className="input" autoComplete={isRegister ? 'new-password' : 'current-password'} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={isRegister ? 8 : 1} />
            {isRegister && <p className="mt-1 text-xs text-slate-500">At least 8 characters.</p>}
          </div>}
          {showRegister && (
            <label className="flex items-start gap-2 text-sm text-slate-300">
              <input type="checkbox" className="mt-0.5 h-4 w-4 accent-brand-500" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
              I understand all money in VirtualBet is virtual with no real value, and that no real money can be deposited, won or withdrawn.
            </label>
          )}
          {error && <p className="rounded bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
          <button className="btn-primary h-11 w-full" disabled={busy || (showRegister && !agree)}>
            {busy ? <Spinner className="h-4 w-4" /> : showRegister ? (local ? 'Create profile & get £100 virtual' : 'Create account & get £100 virtual') : 'Log in'}
          </button>
        </form>
        {!local && <p className="mt-4 text-center text-sm text-slate-400">
          {isRegister ? <>Already have an account? <Link to="/login" className="text-brand-400 underline">Log in</Link></>
            : <>New here? <Link to="/register" className="text-brand-400 underline">Create a free account</Link></>}
        </p>}
      </div>
    </div>
  );
}
