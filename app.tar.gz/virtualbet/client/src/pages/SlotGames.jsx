import { useEffect, useMemo, useRef, useState } from 'react';
import GameShell, { isRealWin, StakePicker, STAKES, useGame, WinAmount } from '../components/GameShell.jsx';
import Reels from '../components/Reels.jsx';
import WinCelebration from '../components/WinCelebration.jsx';
import { Coin, Sym } from '../components/SlotArt2.jsx';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import { JACKPOTS, NEB_MULTS, FRUIT_PAY, STAR_SCATTER } from '../../../server/games/slots2.js';

const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const wait = (ms) => new Promise((r) => setTimeout(r, reduceMotion ? 0 : ms));
const randomGrid = (game, reels, rows) => Array.from({ length: reels }, () => Array.from({ length: rows }, () => ({ s: { vault: 'K', starlight: 'Q' }[game] || 'A' })));

function BigWin({ game, amount, bet, onClose, title }) {
  return <WinCelebration game={game} amount={amount} bet={bet} title={title} onDone={onClose} className="absolute inset-0 z-30 rounded-2xl" />;
}

function Controls({ stake, setStake, spinning, free, onSpin, turbo, setTurbo, balance, label }) {
  const low = !free && balance != null && stake > balance;
  return (
    <div className="card flex flex-wrap items-center gap-3 p-3">
      <StakePicker value={free ? free.bet : stake} onChange={setStake} options={STAKES} disabled={spinning || !!free} />
      <button onClick={() => setTurbo((t) => !t)} className={`rounded-md px-2.5 py-1 text-xs font-semibold ${turbo ? 'bg-gold-500 text-navy-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Turbo</button>
      <button onClick={onSpin} disabled={spinning || low} className={`btn ml-auto h-14 min-w-40 flex-1 rounded-full text-lg font-extrabold shadow-lg sm:flex-none ${free ? 'bg-gold-500 text-navy-950 hover:bg-gold-400' : 'bg-brand-500 text-navy-950 hover:bg-brand-400'}`}>
        {spinning ? 'Spinning…' : free ? `Free spin (${free.remaining})` : low ? 'Low balance' : label || 'Spin'}
      </button>
    </div>
  );
}

// ═══════════════════════ COIN VAULT ═══════════════════════
export function VaultGame() {
  const { user, view, history, play, commit } = useGame('vault');
  const [stake, setStake] = useState(100);
  const [grid, setGrid] = useState(() => [[{ s: 'A' }, { s: 'COIN', v: 200 }, { s: 'Q' }], [{ s: 'BELL' }, { s: 'K' }, { s: 'COIN', v: 500 }], [{ s: 'J' }, { s: 'WILD' }, { s: '10' }], [{ s: 'SEVEN' }, { s: 'A' }, { s: 'BAR' }], [{ s: 'Q' }, { s: 'COIN', v: 'MINI' }, { s: 'K' }]]);
  const [stopped, setStopped] = useState([true, true, true, true, true]);
  const [spinning, setSpinning] = useState(false);
  const [res, setRes] = useState(null);
  const [hs, setHs] = useState(null); // hold & spin display { locked, left, landed, total }
  const [big, setBig] = useState(null);
  const [turbo, setTurbo] = useState(false);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const spin = async () => {
    setRes(null); setHs(null); setSpinning(true); sfx.spin();
    setStopped([false, false, false, false, false]);
    const out = await play('spin', { stake });
    if (!out) { setStopped([true, true, true, true, true]); setSpinning(false); return; }
    setGrid(out.grid);
    const b = turbo ? 250 : 600, g = turbo ? 90 : 220;
    for (let i = 0; i < 5; i++) timers.current.push(setTimeout(() => { setStopped((s) => s.map((x, j) => (j === i ? true : x))); sfx.stop(i); }, b + i * g));
    await wait(b + 4 * g + 300);
    if (out.feature) {
      sfx.splash();
      const coins0 = out.grid.map((col) => col.map((c) => (c.s === 'COIN' ? { v: c.v } : null)));
      setHs({ locked: coins0, left: 3, landed: [], intro: true });
      await wait(1600);
      for (const r of out.feature.rounds) {
        setHs({ locked: r.locked, left: r.left, landed: r.landed });
        if (r.landed.length) sfx.coin(); else sfx.stop(2);
        await wait(turbo ? 450 : 900);
      }
      setHs((h) => ({ ...h, done: true, total: out.feature.total, full: out.feature.full }));
      await wait(1200);
    }
    setRes(out);
    setSpinning(false);
    commit();
    if (out.win >= out.bet * 10) { setBig(out.win); sfx.bigWin(); } else if (isRealWin(out.win, out.staked)) sfx.win();
  };

  const lit = useMemo(() => new Set((res?.wins || []).flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`))), [res]);
  const bet = res?.bet || stake;
  return (
    <GameShell title="Coin Vault" subtitle="6 or more coins start Hold & Spin" rtp="96%" history={history} game="slot"
      rules={<>
        <p>Five reels, 10 paylines, wins pay left to right. The vault wild substitutes for every symbol except coins, and can't land on reel 1.</p>
        <p><b className="text-gold-400">Hold & Spin</b>: land 6 or more coins anywhere. They lock in place and you get 3 respins. Every new coin locks too and resets the respins to 3. When the respins run out, every coin pays its value.</p>
        <p>Jackpot coins: <b className="text-sky-300">MINI {JACKPOTS.MINI / 100}x</b>, <b className="text-violet-300">MINOR {JACKPOTS.MINOR / 100}x</b>, <b className="text-rose-300">MAJOR {JACKPOTS.MAJOR / 100}x</b>. Fill all 15 spaces for the <b className="text-gold-400">GRAND {JACKPOTS.GRAND / 100}x</b>.</p>
        <p className="text-slate-500">Hold & Spin starts about once every 230 spins. Long-run return about 96%. Maximum win 5,000x stake.</p>
      </>}>
      <section className="relative overflow-hidden rounded-2xl border-2 border-amber-700/70 bg-[radial-gradient(ellipse_at_top,#78350f_0%,#292524_55%,#0c0a09_100%)] p-3 shadow-2xl sm:p-5">
        <div className="mx-auto mb-3 w-fit rounded-xl border border-amber-300/50 bg-gradient-to-b from-stone-800 to-stone-950 px-5 py-1.5">
          <div className="font-display bg-[linear-gradient(180deg,#fef9c3,#facc15_45%,#b45309)] bg-clip-text text-2xl tracking-wide text-transparent sm:text-3xl">COIN VAULT</div>
        </div>
        <div className="mb-2 grid grid-cols-4 gap-1 text-center text-[10px] font-bold">
          {['MINI', 'MINOR', 'MAJOR', 'GRAND'].map((j) => <div key={j} className="rounded-md bg-black/40 py-1 text-gold-400 ring-1 ring-gold-500/30">{j}<div className="font-cond text-sm text-white">{money(Math.floor((bet * JACKPOTS[j]) / 100))}</div></div>)}
        </div>
        <div className="relative rounded-xl bg-gradient-to-b from-amber-700/50 to-amber-950/70 p-1.5">
          {hs ? (
            <div className="grid grid-cols-5 gap-1.5">
              {hs.locked.map((col, r) => (
                <div key={r} className="grid gap-1.5">
                  {col.map((c, row) => (
                    <div key={row} className={`aspect-square rounded-lg p-1 ${c ? 'bg-amber-900/60 ring-1 ring-gold-400/60' : 'bg-black/50'} ${hs.landed?.some(([a, b]) => a === r && b === row) ? 'animate-net-drop' : ''}`}>
                      {c ? <Coin v={c.v} bet={bet} /> : null}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          ) : <Reels game="vault" grid={grid} stopped={stopped} bet={bet} lit={lit} turbo={turbo} />}
          {hs && (
            <div className="pointer-events-none absolute inset-x-0 -bottom-1 flex justify-center">
              <div className="rounded-full bg-gold-500 px-4 py-1 font-cond text-sm font-extrabold uppercase text-navy-950 shadow">
                {hs.intro ? 'Hold & Spin!' : hs.done ? `Collected ${money(hs.total)}${hs.full ? ' · GRAND!' : ''}` : `Respins left: ${hs.left}`}
              </div>
            </div>
          )}
        </div>
        <div className="mt-3 flex min-h-12 items-center justify-center rounded-xl bg-black/35 py-2 text-center">
          {res?.win ? <div><WinAmount win={res.win} staked={res.staked} /><div className="text-[11px] text-white/70">{[res.wins.length && `${res.wins.length} line win${res.wins.length > 1 ? 's' : ''}`, res.feature && `Hold & Spin ${money(res.feature.total)}`].filter(Boolean).join(' · ')}</div></div>
            : <div className="text-sm text-white/60">{spinning ? (hs ? 'Hold & Spin in play…' : 'Reels spinning…') : res ? 'No win this time' : 'Set your stake and spin'}</div>}
        </div>
        {big && <BigWin game="vault" amount={big} bet={bet} onClose={() => setBig(null)} />}
      </section>
      <Controls stake={stake} setStake={setStake} spinning={spinning} onSpin={spin} turbo={turbo} setTurbo={setTurbo} balance={user?.balance} />
    </GameShell>
  );
}

// ═══════════════════════ STARLIGHT OBSERVATORY ═══════════════════════
export function StarlightGame() {
  const { user, view, history, play, commit } = useGame('starlight');
  const [stake, setStake] = useState(100);
  const [grid, setGrid] = useState(() => [[{ s: 'A' }, { s: 'MOON' }, { s: 'Q' }], [{ s: 'ROCKET' }, { s: 'K' }, { s: 'J' }], [{ s: '10' }, { s: 'SCOPE' }, { s: 'SATURN' }], [{ s: 'ASTRO' }, { s: 'A' }, { s: 'Q' }], [{ s: 'K' }, { s: 'MOON' }, { s: '10' }]]);
  const [stopped, setStopped] = useState([true, true, true, true, true]);
  const [spinning, setSpinning] = useState(false);
  const [res, setRes] = useState(null);
  const [expanded, setExpanded] = useState(null);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(null);
  const [auto, setAuto] = useState(false);
  const [turbo, setTurbo] = useState(false);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const free = view?.free;

  const spin = async () => {
    if (spinning) return;
    setRes(null); setExpanded(null); setSpinning(true); sfx.spin();
    setStopped([false, false, false, false, false]);
    const out = await play('spin', { stake });
    if (!out) { setStopped([true, true, true, true, true]); setSpinning(false); setAuto(false); return; }
    setGrid(out.grid);
    const b = turbo ? 250 : 600, g = turbo ? 90 : 220;
    const scopeReels = out.grid.map((c) => c.some((x) => x.s === 'SCOPE'));
    let seen = 0, extra = 0;
    for (let i = 0; i < 5; i++) {
      if (seen >= 2 && !turbo) extra += 700;
      const at = b + i * g + extra;
      timers.current.push(setTimeout(() => { setStopped((s) => s.map((x, j) => (j === i ? true : x))); sfx.stop(i); }, at));
      if (scopeReels[i]) seen++;
    }
    await wait(b + 4 * g + extra + 300);
    if (out.expand) { await wait(300); setExpanded(out.expand); sfx.splash(); await wait(1200); }
    setRes(out);
    setSpinning(false);
    commit();
    if (out.trigger?.freeSpins) { setIntro(out.trigger); sfx.bigWin(); }
    else if (out.finished) setBig({ amount: out.finished.total, title: 'FREE SPINS WON' });
    else if (out.win >= out.bet * 10) { setBig({ amount: out.win }); sfx.bigWin(); } else if (isRealWin(out.win, out.staked)) sfx.win();
    if (!out.free) setAuto(false);
  };
  useEffect(() => {
    if (!auto || !free || spinning || big || intro) return undefined;
    const t = setTimeout(spin, 1100);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro]); // eslint-disable-line react-hooks/exhaustive-deps

  const lit = useMemo(() => new Set((res?.wins || []).flatMap((w) => w.cells.map(([r, c]) => `${r}-${c}`))), [res]);
  const bet = res?.bet || free?.bet || stake;
  const overlays = [0, 1, 2, 3, 4].map((i) => (expanded?.reels.includes(i) ? (
    <div className="animate-net-drop absolute inset-0 flex items-center justify-center bg-indigo-500/30 ring-2 ring-gold-400"><div className="w-full"><Sym s={expanded.sym} game="starlight" /></div></div>
  ) : null));
  return (
    <GameShell title="Starlight Observatory" subtitle="Telescopes are wild and scatter · free spins with an expanding symbol" rtp="96%" history={history} game="slot"
      rules={<>
        <p>Five reels, 10 paylines, wins pay left to right. The <b className="text-gold-400">telescope</b> is both wild (substitutes for everything) and scatter: 3, 4 or 5 anywhere pay {STAR_SCATTER[3] / 100}x, {STAR_SCATTER[4] / 100}x or {STAR_SCATTER[5] / 100}x and award 10 free spins.</p>
        <p>Before free spins start, one symbol is chosen as the <b className="text-sky-300">special expanding symbol</b>. During free spins, when it lands on 3 or more reels (2 for the rocket and astronaut), it fills those whole reels and pays on all 10 lines, even if the reels aren't next to each other. 3+ telescopes during free spins add 10 more.</p>
        <p className="text-slate-500">Free spins start about once every 300 spins. Long-run return about 96%. Maximum win 5,000x stake.</p>
      </>}>
      <section className={`relative overflow-hidden rounded-2xl border-2 border-indigo-400/40 p-3 shadow-2xl transition-colors duration-700 sm:p-5 ${free ? 'bg-[radial-gradient(ellipse_at_top,#3730a3_0%,#1e1b4b_50%,#020617_100%)]' : 'bg-[radial-gradient(ellipse_at_top,#1e3a8a_0%,#0f172a_55%,#020617_100%)]'}`}>
        {[8, 18, 30, 44, 61, 73, 86, 94].map((x, i) => <span key={i} className="animate-twinkle pointer-events-none absolute h-0.5 w-0.5 rounded-full bg-white" style={{ left: `${x}%`, top: `${(i * 13) % 30 + 2}%`, animationDelay: `${i * 0.3}s` }} />)}
        <div className="relative mx-auto mb-3 w-fit text-center">
          <div className="font-display bg-[linear-gradient(180deg,#e0e7ff,#a5b4fc_50%,#6366f1)] bg-clip-text text-2xl tracking-wide text-transparent sm:text-3xl">STARLIGHT OBSERVATORY</div>
        </div>
        {free && (
          <div className="relative mb-2 flex items-center justify-between gap-2">
            <div className="rounded-lg bg-gold-500 px-3 py-1 text-xs font-extrabold uppercase text-navy-950">Free spins · {free.remaining} left</div>
            <div className="flex items-center gap-1 rounded-lg bg-black/40 px-2 py-1 text-xs text-indigo-100">Expanding: <span className="h-7 w-7"><Sym s={free.special} game="starlight" /></span></div>
          </div>
        )}
        <div className="relative rounded-xl bg-indigo-950/60 p-1.5 ring-1 ring-indigo-400/30">
          <Reels game="starlight" grid={grid} stopped={stopped} bet={bet} lit={expanded ? new Set() : lit} overlays={overlays} turbo={turbo} />
        </div>
        <div className="mt-3 flex min-h-12 items-center justify-center rounded-xl bg-black/35 py-2 text-center">
          {res?.win ? <div><WinAmount win={res.win} staked={res.staked} /><div className="text-[11px] text-white/70">{[res.wins.length && `${res.wins.length} line win${res.wins.length > 1 ? 's' : ''}`, res.scatterWin && `Telescopes ${money(res.scatterWin)}`, res.expand && `Expanding ${money(res.expand.amount)}`].filter(Boolean).join(' · ')}</div></div>
            : <div className="text-sm text-white/60">{spinning ? 'Scanning the sky…' : res ? 'No win this time' : 'Set your stake and spin'}</div>}
        </div>
        {intro && (
          <button type="button" onClick={() => { setIntro(null); setAuto(true); }} className="animate-fade-in absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/75 text-center">
            <div className="font-display text-2xl tracking-widest text-indigo-200">10 FREE SPINS</div>
            <div className="mt-2 text-sm text-white/80">Special expanding symbol</div>
            <div className="animate-big-win mt-2 h-24 w-24"><Sym s={intro.special} game="starlight" /></div>
            <div className="mt-3 text-[11px] uppercase tracking-widest text-white/60">Tap to start</div>
          </button>
        )}
        {big && <BigWin game="starlight" amount={big.amount} bet={bet} title={big.title} onClose={() => setBig(null)} />}
      </section>
      <Controls stake={stake} setStake={setStake} spinning={spinning} free={free} onSpin={spin} turbo={turbo} setTurbo={setTurbo} balance={user?.balance} />
      {free && <label className="flex items-center gap-2 px-1 text-sm text-slate-300"><input type="checkbox" className="h-4 w-4 accent-brand-500" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> Auto-play free spins</label>}
    </GameShell>
  );
}

// ═══════════════════════ NEBULA CLUSTERS ═══════════════════════
export function NebulaGame() {
  const { user, view, history, play, commit } = useGame('nebula');
  const [stake, setStake] = useState(100);
  const [grid, setGrid] = useState(() => Array.from({ length: 6 }, (_, c) => Array.from({ length: 6 }, (_, r) => ['RED', 'ORG', 'YEL', 'GRN', 'BLU', 'PUR'][(c * 2 + r * 3) % 6])));
  const [popping, setPopping] = useState(new Set());
  const [gen, setGen] = useState(0);
  const [level, setLevel] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [res, setRes] = useState(null);
  const [running, setRunning] = useState(0);
  const [big, setBig] = useState(null);
  const [intro, setIntro] = useState(false);
  const [auto, setAuto] = useState(false);
  const free = view?.free;

  const spin = async () => {
    if (spinning) return;
    setSpinning(true); setRes(null); setRunning(0); sfx.spin();
    const out = await play('spin', { stake });
    if (!out) { setSpinning(false); setAuto(false); return; }
    let won = 0;
    for (let i = 0; i < out.steps.length; i++) {
      const st = out.steps[i];
      setGrid(st.grid); setGen((g) => g + 1); setPopping(new Set()); setLevel(NEB_MULTS.indexOf(st.mult));
      await wait(i === 0 ? 650 : 450);
      if (!st.clusters.length) break;
      setPopping(new Set(st.clusters.flatMap((c) => c.cells.map(([x, y]) => `${x}-${y}`))));
      sfx.coin();
      won += st.win; setRunning(won);
      await wait(800);
    }
    setRes(out);
    setSpinning(false);
    commit();
    if (out.trigger?.freeSpins) { setIntro(true); sfx.bigWin(); }
    else if (out.finished) setBig({ amount: out.finished.total, title: 'FREE SPINS WON' });
    else if (out.win >= out.bet * 10) { setBig({ amount: out.win }); sfx.bigWin(); } else if (isRealWin(out.win, out.staked)) sfx.win();
    if (!out.free) setAuto(false);
  };
  useEffect(() => {
    if (!auto || !free || spinning || big || intro) return undefined;
    const t = setTimeout(spin, 900);
    return () => clearTimeout(t);
  }, [auto, free, spinning, big, intro]); // eslint-disable-line react-hooks/exhaustive-deps

  const bet = res?.bet || free?.bet || stake;
  return (
    <GameShell title="Nebula Clusters" subtitle="Clusters of 5+ pay · cascades raise the multiplier" rtp="96%" history={history} game="slot"
      rules={<>
        <p>A 6×6 grid. Groups of 5 or more matching gems touching up, down, left or right pay, then vanish. New gems fall in from above and can form more clusters.</p>
        <p>Each cascade in the same spin raises the multiplier: x1, x2, x3, x5, x8, x10. It resets on the next paid spin.</p>
        <p><b className="text-sky-300">4 or more comets</b> award 10 free spins where the multiplier <b>never resets</b> between spins. 3 comets during free spins add 5 more.</p>
        <p className="text-slate-500">Free spins start about once every 190 spins. Long-run return about 96%. Maximum win 5,000x stake.</p>
      </>}>
      <section className="relative overflow-hidden rounded-2xl border-2 border-fuchsia-500/40 bg-[radial-gradient(ellipse_at_30%_10%,#86198f_0%,#3b0764_35%,#0b1029_75%)] p-3 shadow-2xl sm:p-5">
        <div className="pointer-events-none absolute -right-10 top-10 h-40 w-40 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="relative mb-3 text-center font-display text-2xl tracking-wide text-fuchsia-100 sm:text-3xl">NEBULA CLUSTERS</div>
        <div className="relative mb-2 flex items-center justify-between gap-2">
          <div className="flex gap-1">
            {NEB_MULTS.map((m, i) => <span key={m} className={`rounded-md px-2 py-0.5 font-cond text-sm font-extrabold transition-all ${i === level ? 'scale-110 bg-gold-400 text-navy-950 shadow-[0_0_12px_rgba(250,204,21,0.8)]' : i < level ? 'bg-fuchsia-500/40 text-white' : 'bg-black/40 text-white/50'}`}>x{m}</span>)}
          </div>
          {free && <div className="rounded-lg bg-gold-500 px-2 py-1 text-xs font-extrabold uppercase text-navy-950">Free · {free.remaining}</div>}
        </div>
        <div className="relative mx-auto grid grid-cols-6 gap-1 rounded-xl bg-black/35 p-1.5 ring-1 ring-fuchsia-300/20" style={{ maxWidth: 'min(100%, calc(100dvh - 400px))', minWidth: 'min(100%, 300px)' }}>
          {grid.map((col, c) => (
            <div key={c} className="grid gap-1">
              {col.map((s, r) => {
                const k = `${c}-${r}`;
                const pop = popping.has(k);
                return (
                  <div key={`${gen}-${k}`} className={`aspect-square p-0.5 ${pop ? 'animate-gem-pop' : 'animate-gem-drop'}`} style={{ animationDelay: pop ? '0ms' : `${c * 30 + (5 - r) * 25}ms` }}>
                    <Sym s={s} game="nebula" />
                  </div>
                );
              })}
            </div>
          ))}
        </div>
        <div className="mt-3 flex min-h-12 items-center justify-center rounded-xl bg-black/35 py-2 text-center">
          {res?.win ? <WinAmount win={res.win} staked={res.staked} /> : running ? <div className="font-cond text-3xl font-extrabold tabular-nums text-white">{money(running)}</div>
            : <div className="text-sm text-white/60">{spinning ? 'Gems falling…' : res ? 'No clusters this time' : 'Set your stake and spin'}</div>}
        </div>
        {intro && (
          <button type="button" onClick={() => { setIntro(false); setAuto(true); }} className="animate-fade-in absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/75 text-center">
            <div className="animate-big-win font-display text-5xl text-fuchsia-200">10 FREE SPINS</div>
            <div className="mt-2 max-w-xs text-sm text-white/80">The multiplier keeps climbing between spins and never resets.</div>
            <div className="mt-3 text-[11px] uppercase tracking-widest text-white/60">Tap to start</div>
          </button>
        )}
        {big && <BigWin game="nebula" amount={big.amount} bet={bet} title={big.title} onClose={() => setBig(null)} />}
      </section>
      <Controls stake={stake} setStake={setStake} spinning={spinning} free={free} onSpin={spin} turbo={false} setTurbo={() => {}} balance={user?.balance} />
      {free && <label className="flex items-center gap-2 px-1 text-sm text-slate-300"><input type="checkbox" className="h-4 w-4 accent-brand-500" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> Auto-play free spins</label>}
    </GameShell>
  );
}

// ═══════════════════════ FRUIT SHACK ═══════════════════════
const FRUIT_STAKES = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000];
export function FruitGame() {
  const { user, view, history, busy, play, commit } = useGame('fruit');
  const [stake, setStake] = useState(100);
  const [win, setWin] = useState(null);
  const [spinningReels, setSpinningReels] = useState([false, false, false]);
  const [window3, setWindow3] = useState(null);
  const [holds, setHolds] = useState([false, false, false]);
  const [lastPay, setLastPay] = useState(null);
  const [big, setBig] = useState(null);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  useEffect(() => { if (view && !window3) setWindow3(view.window); }, [view]); // eslint-disable-line react-hooks/exhaustive-deps

  const offer = view?.offer;
  const nudges = view?.nudges || 0;
  const spinning = spinningReels.some(Boolean);

  const spin = async () => {
    setWin(null); setLastPay(null);
    const h = offer ? holds : [false, false, false];
    setSpinningReels(h.map((x) => !x));
    sfx.spin();
    const out = await play('spin', { stake, holds: h.some(Boolean) ? h : undefined });
    if (!out) { setSpinningReels([false, false, false]); return; }
    setHolds([false, false, false]);
    [0, 1, 2].forEach((i) => timers.current.push(setTimeout(() => {
      setSpinningReels((s) => s.map((x, j) => (j === i ? false : x)));
      setWindow3((w) => w.map((c, j) => (j === i ? out.window[i] : c)));
      sfx.stop(i);
    }, 500 + i * 300)));
    timers.current.push(setTimeout(() => {
      setWindow3(out.window); commit();
      if (out.win) { setWin(out.win); setLastPay(out.pay); if (out.win >= stake * 10) setBig(out.win); else sfx.win(); }
      else if (out.offer) sfx.tease();
      else if (out.nudges) sfx.tease();
    }, 1250));
  };
  const nudge = async (reel) => {
    const out = await play('nudge', { reel });
    if (!out) return;
    sfx.stop(reel);
    setWindow3(out.window);
    commit();
    if (out.win) { setWin(out.win); setLastPay(out.pay); if (out.win >= stake * 10) setBig(out.win); else sfx.win(); }
  };

  const w = window3 || [['LEMON', 'CHERRY', 'PLUM'], ['ORANGE', 'BELL', 'LEMON'], ['PLUM', 'SEVEN', 'ORANGE']];
  return (
    <GameShell title="Fruit Shack" subtitle="Classic 3-reel fruit machine with holds and nudges" rtp="96%" history={history} game="slot"
      rules={<>
        <p>One payline across the middle. Three of a kind pays: 7s {FRUIT_PAY.SEVEN}x, BAR {FRUIT_PAY.BAR}x, Bell {FRUIT_PAY.BELL}x, Plum {FRUIT_PAY.PLUM}x, Cherry {FRUIT_PAY.CHERRY}x, Orange {FRUIT_PAY.ORANGE}x, Lemon {FRUIT_PAY.LEMON}x. Any two cherries on the line pay 2x.</p>
        <p><b className="text-gold-400">Holds</b>: after some losing spins you're offered holds. Hold up to two reels and they stay put on your next spin (same stake). The machine suggests a hold, but you choose.</p>
        <p><b className="text-gold-400">Nudges</b>: after some losing spins you get 1-4 nudges. Each nudge moves a reel down one position, bringing the symbol above onto the payline. A win ends the nudges.</p>
        <p className="text-slate-500">The 96% return assumes good use of holds and nudges; careless choices return less.</p>
      </>}>
      <section className="relative overflow-hidden rounded-2xl border-4 border-red-900 bg-[linear-gradient(180deg,#7f1d1d,#450a0a)] p-3 shadow-2xl sm:p-5">
        {big && <BigWin game="fruit" amount={big} bet={stake} onClose={() => setBig(null)} />}
        <div className="mx-auto mb-2 w-fit rounded-xl bg-[repeating-linear-gradient(90deg,#facc15_0_10px,#fde68a_10px_20px)] p-1">
          <div className="rounded-lg bg-red-950 px-5 py-1 font-display text-2xl tracking-wide text-gold-400 sm:text-3xl">FRUIT SHACK</div>
        </div>
        <div className="mx-auto mb-2 hidden max-w-sm grid-cols-4 gap-1 text-center text-[10px] font-bold sm:grid">
          {Object.entries(FRUIT_PAY).map(([s, p]) => (
            <div key={s} className={`flex items-center justify-center gap-0.5 rounded bg-black/40 px-1 py-0.5 ${lastPay === p && win ? 'animate-win-pulse bg-gold-400 text-navy-950' : 'text-gold-200'}`}><span className="h-4 w-4"><Sym s={s} game="fruit" /></span>{p}x</div>
          ))}
          <div className={`flex items-center justify-center rounded bg-black/40 px-1 py-0.5 ${lastPay === 2 && win ? 'animate-win-pulse bg-gold-400 text-navy-950' : 'text-gold-200'}`}>2 cherries 2x</div>
        </div>
        <div className="relative mx-auto max-w-[264px] rounded-xl bg-zinc-900 p-2 ring-4 ring-zinc-700 sm:max-w-sm">
          <div className="pointer-events-none absolute inset-x-1 top-1/2 z-10 h-0.5 -translate-y-1/2 bg-red-500/80 shadow-[0_0_6px_rgba(239,68,68,0.9)]" />
          <div className="grid grid-cols-3 gap-2">
            {[0, 1, 2].map((i) => (
              <div key={i} style={{ aspectRatio: '1 / 3' }} className="relative overflow-hidden rounded-lg bg-gradient-to-b from-zinc-300 via-white to-zinc-300">
                {spinningReels[i] ? (
                  <div className="animate-reel-spin absolute inset-x-0 top-0 will-change-transform">{[...Array(12)].map((_, k) => <div key={k} className="aspect-square p-1.5 opacity-70 blur-[1.5px] sm:p-2"><Sym s={['CHERRY', 'LEMON', 'BELL', 'PLUM', 'ORANGE', 'SEVEN'][(k + i) % 6]} game="fruit" /></div>)}</div>
                ) : (
                  <div className="animate-reel-stop">{w[i].map((s, r) => <div key={r} className={`aspect-square p-1.5 sm:p-2 ${r === 1 ? '' : 'opacity-45'}`}><Sym s={s} game="fruit" /></div>)}</div>
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="mx-auto mt-2 grid max-w-[264px] grid-cols-3 gap-2 sm:max-w-sm">
          {[0, 1, 2].map((i) => nudges > 0 ? (
            <button key={i} disabled={busy} onClick={() => nudge(i)} className="btn h-11 bg-sky-500 text-white hover:bg-sky-400">▼ Nudge</button>
          ) : (
            <button key={i} disabled={!offer || spinning} onClick={() => setHolds((h) => (h[i] || h.filter(Boolean).length < 2 ? h.map((x, j) => (j === i ? !x : x)) : h))}
              className={`btn h-11 ${holds[i] ? 'bg-gold-400 text-navy-950' : offer ? 'bg-amber-700 text-white animate-win-pulse' : 'bg-black/40 text-white/30'}`}>{holds[i] ? 'HELD' : 'HOLD'}</button>
          ))}
        </div>
        <div className="mt-2 flex h-14 flex-col items-center justify-center rounded-xl bg-black/40 px-2 text-center leading-tight">
          {win ? <div className="font-cond text-3xl font-extrabold text-gold-400">WIN {money(win)}</div>
            : nudges > 0 ? <><div className="font-cond text-xl font-bold text-sky-300">{nudges} NUDGE{nudges > 1 ? 'S' : ''}</div><div className="text-[11px] text-sky-100/70">Tap ▼ to move a reel down one symbol</div></>
            : offer && !spinning ? <><div className="font-cond text-xl font-bold text-gold-300">HOLDS AVAILABLE</div>{offer.suggested?.some(Boolean) && <div className="text-[11px] text-gold-100/70">Suggested: hold reel {offer.suggested.map((x, i) => (x ? i + 1 : null)).filter(Boolean).join(' & ')}</div>}</>
            : <div className="text-sm text-white/60">{spinning ? 'Spinning…' : 'Insert virtual coins and spin'}</div>}
        </div>
      </section>
      <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 flex flex-wrap items-center gap-3 p-3 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
        <StakePicker value={offer ? view.lastStake : stake} onChange={setStake} options={FRUIT_STAKES} disabled={spinning || !!offer || nudges > 0} />
        {nudges > 0 && <button className="btn-ghost" disabled={busy} onClick={async () => { await play('collect', {}); }}>Skip nudges</button>}
        <button onClick={spin} disabled={busy || spinning || nudges > 0 || (user && stake > user.balance)} className="btn ml-auto h-12 min-w-36 rounded-full bg-gold-500 text-lg font-extrabold text-navy-950 hover:bg-gold-400">
          {spinning ? 'Spinning…' : holds.some(Boolean) ? 'Spin with holds' : `Spin · ${money(offer ? view.lastStake : stake)}`}
        </button>
      </div>
    </GameShell>
  );
}
