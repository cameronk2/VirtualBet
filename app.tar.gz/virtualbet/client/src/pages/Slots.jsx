import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { GameHeader, isRealWin, useGameSound, WinAmount } from '../components/GameShell.jsx';
import { PopoutToggle, PopoutWrap } from '../components/Popout.jsx';
import SoundMenu from '../components/SoundMenu.jsx';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { money, signed } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import WinCelebration from '../components/WinCelebration.jsx';
import { ALL_SYMBOLS, SlotSymbol } from '../components/SlotSymbols.jsx';
import { LINES } from '../../../server/slots.js';
import { LoginPrompt } from './MyBets.jsx';

const BETS = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000];
const LINE_COLOURS = ['#facc15', '#38bdf8', '#f472b6', '#4ade80', '#fb923c', '#a78bfa', '#f87171', '#2dd4bf', '#e879f9', '#a3e635'];
const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const TIERS = [{ x: 50, label: 'EPIC WIN' }, { x: 25, label: 'MEGA WIN' }, { x: 10, label: 'BIG WIN' }];

const randomStrip = (n) => Array.from({ length: n }, () => {
  const s = ALL_SYMBOLS[Math.floor(Math.random() * ALL_SYMBOLS.length)];
  return s === 'FISH' ? { s, v: [200, 500, 1000][Math.floor(Math.random() * 3)] } : { s };
});
const IDLE_GRID = [
  [{ s: 'A' }, { s: 'BOAT' }, { s: 'Q' }], [{ s: 'FISH', v: 500 }, { s: 'K' }, { s: 'FLY' }], [{ s: 'J' }, { s: 'WILD' }, { s: '10' }],
  [{ s: 'ROD' }, { s: 'A' }, { s: 'FISH', v: 1000 }], [{ s: 'Q' }, { s: 'BOX' }, { s: 'SCAT' }],
];

// ── Scenery: a lake at dusk (base game) or under the moon (free spins) ──
function LakeScene({ night }) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      <div className={`absolute inset-0 transition-colors duration-1000 ${night ? 'bg-[linear-gradient(180deg,#0b1030_0%,#1e1b4b_38%,#0f2a3d_60%,#06202a_100%)]' : 'bg-[linear-gradient(180deg,#f59e0b_0%,#c2410c_18%,#7c2d12_32%,#0c4a6e_52%,#083344_75%,#052e2b_100%)]'}`} />
      <div className={`absolute left-1/2 top-[8%] h-20 w-20 -translate-x-1/2 rounded-full blur-[2px] transition-all duration-1000 ${night ? 'bg-slate-100 shadow-[0_0_60px_20px_rgba(226,232,240,0.35)]' : 'bg-amber-200 shadow-[0_0_80px_30px_rgba(251,191,36,0.55)]'}`} />
      {night && [12, 25, 70, 82, 90, 40, 58].map((x, i) => <span key={i} className="animate-twinkle absolute h-0.5 w-0.5 rounded-full bg-white" style={{ left: `${x}%`, top: `${4 + (i * 7) % 20}%`, animationDelay: `${i * 0.4}s` }} />)}
      <svg viewBox="0 0 400 60" preserveAspectRatio="none" className="absolute inset-x-0 top-[24%] h-[14%] w-full">
        <path d="M0 60V35c40-18 70-22 110-10s60 6 100-12 80-10 110 5 50 8 80-4v46z" fill={night ? '#0b1430' : '#3f1d0b'} opacity=".85" />
        <path d="M0 60V44c50-10 90-6 140 2s90-14 140-8 80 10 120 2v20z" fill={night ? '#081022' : '#2a1206'} />
      </svg>
      <div className="animate-water absolute inset-x-0 bottom-0 top-[37%] opacity-40 bg-[repeating-linear-gradient(180deg,transparent_0_7px,rgba(255,255,255,0.10)_7px_8px)]" />
      <div className={`animate-shimmer absolute left-1/2 top-[37%] h-[40%] w-24 -translate-x-1/2 blur-md ${night ? 'bg-[linear-gradient(180deg,rgba(226,232,240,0.35),transparent)]' : 'bg-[linear-gradient(180deg,rgba(251,191,36,0.45),transparent)]'}`} />
      {[3, 8, 92, 96].map((x, i) => (
        <svg key={i} viewBox="0 0 20 80" className="absolute bottom-0 h-28 w-7" style={{ left: `${x}%`, transform: `translateX(-50%) scaleX(${i % 2 ? -1 : 1})` }}>
          <path d="M10 80C9 55 6 30 2 4M10 80c1-25 4-45 9-62M10 80c0-20 0-40-2-55" stroke="#0a1f14" strokeWidth="2" fill="none" />
          <ellipse cx="2.5" cy="8" rx="2" ry="7" fill="#3f2a16" />
        </svg>
      ))}
    </div>
  );
}

function Reel({ index, cells, spinning, bet, lit, dim, tease, floats, netCell, turbo }) {
  const strip = useMemo(() => randomStrip(12), [spinning]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div style={{ aspectRatio: '1 / 3' }} className={`relative overflow-hidden rounded-lg bg-gradient-to-b from-sky-950/85 via-cyan-950/75 to-sky-950/85 ring-1 transition-shadow duration-300 ${tease ? 'ring-2 ring-gold-400 shadow-[0_0_24px_rgba(250,204,21,0.7)]' : 'ring-cyan-300/10'}`}>
      {spinning ? (
        <div className={`${turbo ? 'animate-reel-spin-fast' : 'animate-reel-spin'} will-change-transform`} style={{ animationDelay: `${-index * 60}ms` }}>
          {[...strip, ...strip].map((c, i) => <div key={i} className="aspect-square p-1 opacity-80 blur-[1.5px]"><SlotSymbol cell={c} bet={bet} /></div>)}
        </div>
      ) : (
        <div className="animate-reel-stop">
          {cells.map((c, row) => {
            const k = `${index}-${row}`;
            const on = lit.has(k);
            const isNet = netCell === k;
            return (
              <div key={row} className={`relative aspect-square p-1 transition-opacity duration-300 ${dim && !on ? 'opacity-35' : ''}`}>
                {on && <div className="animate-win-pulse absolute inset-0.5 rounded-md bg-gold-400/20 ring-2 ring-gold-400" />}
                <div className={`relative h-full w-full ${on ? 'animate-symbol-pop' : ''} ${isNet ? 'animate-net-drop' : ''}`}><SlotSymbol cell={c} bet={bet} /></div>
                {isNet && <div className="animate-net-drop pointer-events-none absolute inset-0 rounded-md bg-[repeating-linear-gradient(45deg,rgba(255,255,255,0.35)_0_1px,transparent_1px_7px),repeating-linear-gradient(-45deg,rgba(255,255,255,0.35)_0_1px,transparent_1px_7px)]" />}
                {floats[k] && <div className="animate-float-up pointer-events-none absolute inset-x-0 top-1 z-20 text-center text-sm font-black text-gold-400 [text-shadow:0_2px_4px_#000]">+{money(floats[k])}</div>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function WinLines({ wins, active }) {
  if (!wins?.length) return null;
  const show = active === -1 ? wins : [wins[active % wins.length]];
  return (
    <svg viewBox="0 0 500 300" preserveAspectRatio="none" className="pointer-events-none absolute inset-1.5 z-20 h-[calc(100%-12px)] w-[calc(100%-12px)]">
      {show.map((w) => {
        const pts = LINES[w.line].map((row, reel) => `${reel * 100 + 50},${row * 100 + 50}`).join(' ');
        const c = LINE_COLOURS[w.line];
        return (
          <g key={w.line}>
            <polyline points={pts} fill="none" stroke="#000" strokeOpacity=".5" strokeWidth="9" strokeLinejoin="round" strokeLinecap="round" />
            <polyline points={pts} fill="none" stroke={c} strokeWidth="5" strokeLinejoin="round" strokeLinecap="round" className="animate-line-draw" />
          </g>
        );
      })}
    </svg>
  );
}

function Particles({ count = 36, kind = 'coin' }) {
  const items = useMemo(() => Array.from({ length: count }, (_, i) => ({
    left: Math.random() * 100, delay: Math.random() * 1.2, dur: 1.6 + Math.random() * 1.4, size: 10 + Math.random() * 14, key: i,
  })), [count]);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {items.map((p) => (
        <span key={p.key} className={kind === 'coin' ? 'animate-coin-fall absolute rounded-full bg-[radial-gradient(circle_at_35%_35%,#fef08a,#eab308_55%,#a16207)] shadow' : 'animate-bubble absolute rounded-full border border-white/50 bg-white/10'}
          style={{ left: `${p.left}%`, width: p.size, height: p.size, animationDelay: `${p.delay}s`, animationDuration: `${p.dur}s`, top: kind === 'coin' ? '-30px' : 'auto', bottom: kind === 'coin' ? 'auto' : '-30px' }} />
      ))}
    </div>
  );
}

function useCountUp(target, run, duration) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!run) { setV(0); return undefined; }
    if (reduceMotion || target <= 0) { setV(target); return undefined; }
    const start = performance.now(), dur = duration || Math.min(2600, 500 + target / 15);
    let raf;
    const tick = (t) => {
      const p = Math.min(1, (t - start) / dur);
      setV(Math.round(target * (1 - (1 - p) ** 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, run, duration]);
  return v;
}

function Overlay({ children, onClose }) {
  return (
    <button type="button" onClick={onClose} className="animate-fade-in absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/70 text-center backdrop-blur-[2px]">
      {children}
      <span className="mt-4 text-[11px] uppercase tracking-widest text-white/60">Tap to continue</span>
    </button>
  );
}

export default function Slots() {
  const { user, setUser, toast } = useApp();
  const [bet, setBet] = useState(100);
  const [grid, setGrid] = useState(IDLE_GRID);
  const [gridBet, setGridBet] = useState(100);
  const [stopped, setStopped] = useState([true, true, true, true, true]);
  const [tease, setTease] = useState([false, false, false, false, false]);
  const [phase, setPhase] = useState('idle'); // idle | spinning | showing
  const [result, setResult] = useState(null);
  const [free, setFree] = useState(null);
  const [history, setHistory] = useState([]);
  const [overlay, setOverlay] = useState(null); // { type: 'big'|'intro'|'summary', ... }
  const [auto, setAuto] = useState(false);
  const [turbo, setTurbo] = useState(false);
  const music = useGameSound('lakeside');
  const [showPays, setShowPays] = useState(false);
  const [lineIdx, setLineIdx] = useState(-1);
  const [floats, setFloats] = useState({});
  const timers = useRef([]);
  const queued = useRef([]);
  const showOverlay = (o) => setOverlay((cur) => { if (cur) { queued.current.push(o); return cur; } return o; });
  const closeOverlay = () => setOverlay(queued.current.shift() || null);
  const later = (fn, ms) => timers.current.push(setTimeout(fn, ms));

  useEffect(() => {
    if (!user) return;
    api.get('/api/slots').then((d) => { setFree(d.free); setHistory(d.history); if (d.free) setBet(d.free.bet); }).catch(() => {});
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  // Cycle through winning lines one at a time after showing them all
  useEffect(() => {
    if (phase !== 'showing' || !result?.wins?.length) { setLineIdx(-1); return undefined; }
    setLineIdx(-1);
    if (result.wins.length < 2) return undefined;
    let i = 0;
    const t = setInterval(() => setLineIdx(i++), 1100);
    return () => clearInterval(t);
  }, [phase, result]);

  const spin = useCallback(async () => {
    if (phase === 'spinning' || overlay) return;
    timers.current.forEach(clearTimeout);
    timers.current = [];
    setResult(null);
    setFloats({});
    setPhase('spinning');
    setStopped([false, false, false, false, false]);
    setTease([false, false, false, false, false]);
    sfx.spin();
    const startedAt = performance.now();
    let d;
    try {
      music();
      d = await api.post('/api/slots/spin', { stake: bet });
    } catch (e) {
      toast(e.message, 'error');
      setStopped([true, true, true, true, true]);
      setPhase('idle');
      setAuto(false);
      return;
    }
    const r = d.result;
    const base = turbo ? 280 : 650, gap = turbo ? 90 : 230, teaseMs = turbo ? 500 : 1100;
    const wait = Math.max(0, base - (performance.now() - startedAt));
    // Suspense: once two scatters have landed, the remaining reels spin longer
    const scatterReels = r.grid.map((col) => col.some((c) => c.s === 'SCAT'));
    let seen = 0, extra = 0;
    const stopAt = [];
    for (let i = 0; i < 5; i++) {
      if (seen >= 2 && !reduceMotion) extra += teaseMs;
      stopAt.push(reduceMotion ? 0 : wait + i * gap + extra);
      if (scatterReels[i]) seen++;
    }
    setGrid(r.grid);
    setGridBet(d.free?.bet || d.result?.free?.bet || bet);
    let count = 0;
    for (let i = 0; i < 5; i++) {
      if (i > 0 && stopAt[i] - stopAt[i - 1] > gap + 10 && !reduceMotion) {
        later(() => { setTease((t) => t.map((x, j) => (j === i ? true : x))); sfx.tease(); }, stopAt[i - 1] + 60);
      }
      later(() => {
        setStopped((s) => s.map((x, j) => (j === i ? true : x)));
        setTease((t) => t.map((x, j) => (j === i ? false : x)));
        sfx.stop(i);
        if (scatterReels[i]) { count++; if (count >= 2) sfx.coin(); }
      }, stopAt[i]);
    }
    const done = stopAt[4] + (reduceMotion ? 0 : 280);
    later(() => {
      setResult({ ...r, staked: d.staked });
      setHistory(d.history);
      setPhase('showing');
      if (r.net) sfx.net();
      if (r.collect) {
        // Float each fish value up from its cell
        const f = {};
        r.grid.forEach((col, ri) => col.forEach((c, row) => { if (c.s === 'FISH') f[`${ri}-${row}`] = Math.floor((r.collect.wilds * r.collect.mult * (d.free?.bet || bet) * c.v) / 100); }));
        setFloats(f);
        sfx.coin();
      }
      const stake = d.free?.bet || r.free?.bet || bet;
      const tier = TIERS.find((t) => r.win >= t.x * stake);
      if (tier) showOverlay({ type: 'big', label: tier.label, amount: r.win, bet: r.bet || bet });
      else if (isRealWin(r.win, d.staked)) sfx.win();
      if (r.trigger?.freeSpins) later(() => { showOverlay({ type: 'intro', spins: r.trigger.freeSpins }); sfx.splash(); }, 700);
      if (r.trigger?.retrigger) toast(`+10 free spins · multiplier x${r.trigger.mult}`, 'success');
      if (d.finished) later(() => showOverlay({ type: 'summary', ...d.finished }), 900);
      setFree(d.free);
      setUser(d.user);
      if (!d.free) setAuto(false);
      if (navigator.vibrate && isRealWin(r.win, d.staked)) try { navigator.vibrate(tier ? [60, 40, 60] : 30); } catch { /* ignore */ }
    }, done);
  }, [bet, phase, overlay, turbo, setUser, toast]);

  // Free spins may play themselves (no stake is taken). Paid spins never auto-play.
  useEffect(() => {
    if (!auto || !free || phase === 'spinning' || overlay) return undefined;
    const t = setTimeout(spin, result?.win ? 1600 : 900);
    return () => clearTimeout(t);
  }, [auto, free, phase, result, spin, overlay]);

  // Space bar spins on desktop
  useEffect(() => {
    const onKey = (e) => { if (e.code === 'Space' && e.target === document.body) { e.preventDefault(); if (overlay) closeOverlay(); else spin(); } };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [spin, overlay]);

  const lit = useMemo(() => {
    const s = new Set();
    if (phase !== 'showing' || !result) return s;
    const wins = lineIdx === -1 ? result.wins : [result.wins[lineIdx % result.wins.length]];
    wins.forEach((w) => w.cells.forEach(([r, c]) => s.add(`${r}-${c}`)));
    if (result.collect && lineIdx === -1) result.grid.forEach((col, ri) => col.forEach((c, row) => { if (c.s === 'FISH' || c.s === 'WILD') s.add(`${ri}-${row}`); }));
    return s;
  }, [phase, result, lineIdx]);
  const shown = useCountUp(result?.win || 0, phase === 'showing');
  const bigShown = useCountUp(overlay?.type === 'big' ? overlay.amount : overlay?.type === 'summary' ? overlay.totalWin : 0, !!overlay && overlay.type !== 'intro', 2200);

  if (user === null) return <LoginPrompt what="the slots" />;
  const inFree = !!free;
  const night = inFree || overlay?.type === 'intro';
  const sessionNet = history.reduce((a, h) => a + h.win - (h.free ? 0 : h.bet), 0);
  const level = free ? free.wilds % 4 : 0;
  const betIdx = BETS.indexOf(bet);
  const netCell = phase === 'showing' && result?.net ? `${result.net.reel}-${result.net.row}` : null;

  return (
    <div className="space-y-3">
      <GameHeader game="lakeside" title="Lakeside Lures" subtitle="5 reels · 10 lines · fish collect free spins" rtp="96%"
        extra={<><PopoutToggle /><button onClick={() => setTurbo((t) => !t)} className={`rounded-md px-2 py-1 text-xs font-semibold ${turbo ? 'bg-gold-500 text-navy-950' : 'bg-navy-700 text-slate-200 hover:bg-navy-600'}`} aria-pressed={turbo}>Turbo</button></>} />
      <PopoutWrap title="Lakeside Lures" extras={<SoundMenu game="lakeside" />}>

      <section className="relative overflow-hidden rounded-2xl border-2 border-amber-700/70 shadow-[0_10px_40px_rgba(0,0,0,0.6),inset_0_0_0_2px_rgba(251,191,36,0.25)]">
        <LakeScene night={night} />
        <div className="relative p-3 sm:p-5">
          {/* Title plate */}
          <div className="mx-auto mb-3 w-fit rounded-xl border border-amber-300/50 bg-gradient-to-b from-amber-900/80 to-amber-950/90 px-5 py-1.5 shadow-lg">
            <div className="font-display bg-[linear-gradient(180deg,#fef9c3_0%,#facc15_45%,#b45309_100%)] bg-clip-text text-center text-2xl leading-none tracking-wide text-transparent drop-shadow sm:text-3xl">LAKESIDE LURES</div>
          </div>

          <div className="mb-2 flex min-h-7 items-center justify-between gap-2">
            {inFree ? (
              <>
                <div className="rounded-lg bg-gold-500 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-navy-950 shadow">Free spins · {free.remaining} left</div>
                <div className="flex items-center gap-1.5 rounded-lg bg-black/40 px-2 py-1">
                  <span className="text-[11px] font-semibold text-cyan-100/80">Wilds</span>
                  {[0, 1, 2, 3].map((i) => <span key={i} className={`h-2.5 w-2.5 rounded-full transition-all ${i < level ? 'bg-gold-400 shadow-[0_0_8px_rgba(250,204,21,0.9)]' : 'bg-white/15'}`} />)}
                  <span className="ml-1 rounded bg-gold-500/20 px-1.5 text-xs font-extrabold text-gold-400">x{free.mult}</span>
                </div>
              </>
            ) : (
              <div className="w-full text-center text-[11px] font-semibold uppercase tracking-wider text-amber-50/80 [text-shadow:0_1px_2px_#000]">Wild collects every fish · 3 floats = free spins · Lucky Net can strike</div>
            )}
          </div>

          <div className="relative rounded-xl bg-gradient-to-b from-amber-700/60 to-amber-900/70 p-1.5 shadow-[inset_0_2px_6px_rgba(0,0,0,0.6)]">
            <div className="relative grid grid-cols-5 gap-1.5 rounded-lg bg-black/40 p-1.5">
              {grid.map((col, i) => (
                <Reel key={i} index={i} cells={col} spinning={!stopped[i]} bet={gridBet} turbo={turbo}
                  lit={lit} dim={phase === 'showing' && lit.size > 0} tease={tease[i]} floats={floats} netCell={netCell} />
              ))}
              {phase === 'showing' && <WinLines wins={result?.wins} active={lineIdx} />}
            </div>
            {overlay?.type === 'big' && <WinCelebration game="lakeside" amount={overlay.amount} bet={overlay.bet || bet} onDone={closeOverlay} className="absolute inset-0 z-30 rounded-xl" />}
            {overlay?.type === 'intro' && (
              <Overlay onClose={() => { closeOverlay(); setAuto(true); }}>
                <Particles kind="bubble" count={24} />
                <div className="font-display text-2xl tracking-widest text-cyan-100">THE LAKE AWAKENS</div>
                <div className="animate-big-win font-display bg-[linear-gradient(180deg,#fff7c2,#facc15)] bg-clip-text text-5xl text-transparent drop-shadow sm:text-7xl">{overlay.spins} FREE SPINS</div>
                <p className="mt-2 max-w-xs text-xs text-cyan-50/80">Every 4 wilds collected: +10 spins and a bigger multiplier (x2, x3, x10).</p>
              </Overlay>
            )}
            {overlay?.type === 'summary' && (
              <Overlay onClose={closeOverlay}>
                <Particles kind="bubble" count={20} />
                <div className="font-display text-2xl tracking-widest text-cyan-100">FREE SPINS COMPLETE</div>
                <div className="mt-1 text-5xl font-black tabular-nums text-gold-400 [text-shadow:0_3px_8px_#000]">{money(bigShown)}</div>
                <div className="mt-1 text-xs text-cyan-50/80">won in {overlay.spins} spins</div>
              </Overlay>
            )}
          </div>

          <div className="relative mt-3 flex min-h-16 flex-col items-center justify-center rounded-xl bg-black/35 py-2 text-center">
            {phase === 'showing' && result?.win > 0 ? (
              <>
                {isRealWin(result.win, result.staked)
                  ? <div className="font-display text-3xl tabular-nums tracking-wide text-gold-400 [text-shadow:0_2px_6px_#000]">{money(shown)}{result.staked ? <span className="ml-2 align-middle font-cond text-base font-bold text-brand-400">+{money(result.win - result.staked)}</span> : null}</div>
                  : <WinAmount win={result.win} staked={result.staked} />}
                <div className="px-2 text-[11px] text-cyan-50/85">
                  {[
                    result.net && 'Lucky Net dropped a wild!',
                    result.collect && `Fisherman collected ${money(result.collect.amount)}${result.collect.mult > 1 ? ` (x${result.collect.mult})` : ''}`,
                    result.wins.length && (lineIdx === -1 ? `${result.wins.length} line win${result.wins.length > 1 ? 's' : ''}` : `Line ${result.wins[lineIdx % result.wins.length].line + 1}: ${result.wins[lineIdx % result.wins.length].count}× pays ${money(result.wins[lineIdx % result.wins.length].amount * (result.mult || 1))}`),
                    result.scatter && `Floats pay ${money(result.scatter.amount)}`,
                  ].filter(Boolean).join(' · ')}
                </div>
              </>
            ) : phase === 'showing' ? (
              <div className="text-sm text-cyan-50/60">{result?.net ? 'Lucky Net dropped a wild - no catch this time' : 'No catch this time'}</div>
            ) : phase === 'spinning' ? (
              <div className="text-sm text-cyan-50/70">{tease.some(Boolean) ? 'One more float…' : 'Reels spinning…'}</div>
            ) : (
              <div className="text-sm text-cyan-50/60">Set your stake and spin</div>
            )}
          </div>
        </div>
      </section>

      <div className="card flex items-center gap-3 p-3">
        <div className="flex items-center gap-1">
          <button className="btn-ghost h-11 w-11 p-0 text-lg" disabled={inFree || phase === 'spinning' || betIdx <= 0} onClick={() => { setBet(BETS[Math.max(0, betIdx - 1)]); sfx.chip(); }} aria-label="Lower stake">−</button>
          <div className="w-20 text-center">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Stake</div>
            <div className="text-base font-extrabold tabular-nums text-white">{money(inFree ? free.bet : bet)}</div>
          </div>
          <button className="btn-ghost h-11 w-11 p-0 text-lg" disabled={inFree || phase === 'spinning' || betIdx >= BETS.length - 1} onClick={() => { setBet(BETS[Math.min(BETS.length - 1, betIdx + 1)]); sfx.chip(); }} aria-label="Raise stake">+</button>
        </div>
        <button
          onClick={spin}
          disabled={phase === 'spinning' || !!overlay || (!inFree && user && bet > user.balance)}
          className={`btn ml-auto h-14 flex-1 rounded-full text-lg font-extrabold shadow-lg ${inFree ? 'bg-gold-500 text-navy-950 hover:bg-gold-400' : 'bg-brand-500 text-navy-950 hover:bg-brand-400'}`}
        >
          {phase === 'spinning' ? 'Spinning…' : inFree ? `Free spin (${free.remaining})` : user && bet > user.balance ? 'Low balance' : 'Spin'}
        </button>
      </div>
      </PopoutWrap>
      <div className="flex items-center justify-between gap-2 px-1 text-xs text-slate-400">
        {inFree ? (
          <label className="flex items-center gap-2 text-slate-300">
            <input type="checkbox" className="h-4 w-4 accent-brand-500" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
            Auto-play free spins
          </label>
        ) : <span>Recent spins</span>}
        <span className={`font-bold tabular-nums ${sessionNet > 0 ? 'text-brand-400' : sessionNet < 0 ? 'text-red-400' : 'text-slate-200'}`}>{signed(sessionNet)}</span>
      </div>

      <section className="card overflow-hidden">
        <button onClick={() => setShowPays((v) => !v)} className="flex w-full items-center justify-between px-4 py-3 text-left text-sm font-bold text-white hover:bg-navy-800">
          How it pays <span className="text-xs text-slate-400">{showPays ? 'Hide' : 'Show'}</span>
        </button>
        {showPays && (
          <div className="space-y-3 border-t border-navy-700 p-4 text-xs text-slate-300">
            <p>Line wins pay left to right on 10 lines, as multiples of your total stake (3 / 4 / 5 in a row). A 3-symbol win on a low card returns half your stake, so it's shown as a partial return, not a win:</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {[['WILD', '2.5 / 10 / 50'], ['BOAT', '2.5 / 10 / 50'], ['ROD', '1.5 / 6 / 25'], ['BOX', '1 / 4 / 15'], ['FLY', '1 / 4 / 15'], ['A', '0.5 / 2 / 7.5'], ['K', '0.5 / 2 / 7.5'], ['Q', '0.5 / 1.5 / 5'], ['J', '0.5 / 1.5 / 5'], ['10', '0.5 / 1.5 / 5']].map(([s, p]) => (
                <div key={s} className="flex items-center gap-2 rounded-md bg-navy-800 p-2"><div className="h-9 w-9 shrink-0"><SlotSymbol cell={{ s }} /></div><span className="tabular-nums">{p}x</span></div>
              ))}
            </div>
            <p><b className="text-gold-400">Wild fisherman</b> substitutes for line symbols and collects the cash value of every fish on screen; each wild collects them all. Fish are worth 2x to 500x your stake. Wilds can't land on reel 1.</p>
            <p><b className="text-cyan-300">Lucky Net</b>: on a spin with fish but no fisherman, a net can drop a wild onto reels 2-5 to collect them.</p>
            <p><b className="text-red-300">Scatter float</b>: 3, 4 or 5 anywhere pay 2x, 10x or 100x and award 10, 15 or 20 free spins. In free spins every 4 wilds add 10 spins and raise the multiplier to x2, x3 then x10.</p>
            <p className="text-slate-500">Maximum win 5,000x stake. Long-run return about 96%: on average £96 back for every £100 staked, so most sessions lose. Outcomes are decided when you press Spin; the suspense spin doesn't change them.</p>
          </div>
        )}
      </section>
    </div>
  );
}
