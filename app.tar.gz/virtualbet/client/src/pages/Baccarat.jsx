import { useEffect, useRef, useState } from 'react';
import GameShell, { PlayingCard, useGame } from '../components/GameShell.jsx';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import { total as handTotal } from '../../../server/games/baccarat.js';

const CHIPS = [100, 500, 2500, 10000, 50000, 100000];
const chipLabel = (v) => (v >= 100000 ? `£${v / 100000}k` : `£${v / 100}`);
const SPOTS = [
  { k: 'pPair', label: 'P Pair', pays: '11:1', cls: 'from-sky-900 to-sky-950' },
  { k: 'player', label: 'PLAYER', pays: '1:1', cls: 'from-sky-600 to-sky-800', big: true },
  { k: 'tie', label: 'TIE', pays: '8:1', cls: 'from-emerald-600 to-emerald-800', big: true },
  { k: 'banker', label: 'BANKER', pays: '0.95:1', cls: 'from-red-600 to-red-800', big: true },
  { k: 'bPair', label: 'B Pair', pays: '11:1', cls: 'from-red-900 to-red-950' },
];
const EMPTY = { player: 0, banker: 0, tie: 0, pPair: 0, bPair: 0 };
// Deal timing: a card leaves the shoe every STEP ms, lands face down, then
// turns over; the hand total updates once the card is face up.
const STEP = 560, FLY = 420, FLIP = 340;

/** One dealt card: slides from the shoe face down, then turns over. Only new cards animate. */
function DealtCard({ code, fx, fy, side }) {
  const narrow = typeof window !== 'undefined' && window.innerWidth < 640;
  return (
    <div className={`bc-card relative h-[66px] w-11 shrink-0 sm:h-24 sm:w-16 md:h-28 md:w-20 ${side ? 'bc-side' : ''}`} style={{ '--fx': `${fx}px`, '--fy': `${fy}px`, '--fly': `${FLY}ms`, '--flip': `${FLIP}ms` }}>
      <div className="bc-inner absolute inset-0">
        <div className="bc-face bc-back absolute inset-0"><PlayingCard code={null} small={narrow} className="!h-full !w-full" /></div>
        <div className="bc-face absolute inset-0"><PlayingCard code={code} small={narrow} className="!h-full !w-full" /></div>
      </div>
    </div>
  );
}

/** A hand: fixed space for three cards so nothing shifts while dealing. */
function Hand({ cards, revealed, label, color, fromX, win }) {
  const shownTotal = revealed > 0 ? handTotal(cards.slice(0, revealed)) : null;
  return (
    <div className="flex flex-col items-center gap-2">
      <div className={`flex h-7 items-center gap-2 font-cond text-lg font-bold uppercase tracking-wide ${color}`}>{label}
        <span key={shownTotal} className={`min-w-[2rem] rounded-full px-2 text-center text-base tabular-nums transition-colors ${shownTotal == null ? 'opacity-0' : 'bc-total bg-black/40 text-white'} ${win ? 'bg-gold-400 !text-navy-950' : ''}`}>{shownTotal ?? 0}</span>
      </div>
      <div className="relative flex h-[66px] items-center gap-1 sm:h-24 sm:gap-1.5 md:h-28">
        {[0, 1, 2].map((i) => (
          <div key={i} className={`relative flex h-full items-center justify-center ${i === 2 ? 'w-[66px] sm:w-24 md:w-28' : 'w-11 sm:w-16 md:w-20'}`}>
            {i < 2 && !cards[i] && <div className="h-full w-full rounded-md border border-dashed border-white/15" />}
            {cards[i] && <DealtCard code={cards[i]} fx={fromX - i * 40} fy={-150} side={i === 2} />}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Baccarat() {
  const { view, history, busy, play, commit } = useGame('baccarat');
  const [chip, setChip] = useState(500);
  const [bets, setBets] = useState(EMPTY);
  const [last, setLast] = useState(null);
  const [shown, setShown] = useState({ P: [], B: [] });
  const [revealed, setRevealed] = useState({ P: 0, B: 0 });
  const tableRef = useRef(null);
  const [tableW, setTableW] = useState(360);
  useEffect(() => { const el = tableRef.current; if (!el) return undefined; const ro = new ResizeObserver(() => setTableW(el.clientWidth)); ro.observe(el); return () => ro.disconnect(); }, []);
  const [out, setOut] = useState(null);
  const [dealing, setDealing] = useState(false);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const total = Object.values(bets).reduce((a, b) => a + b, 0);

  const deal = async () => {
    if (!total || dealing) return;
    timers.current.forEach(clearTimeout); timers.current = [];
    setOut(null);
    setShown({ P: [], B: [] }); setRevealed({ P: 0, B: 0 });
    setDealing(true);
    const r = await play('deal', bets);
    if (!r) { setDealing(false); return; }
    setLast(bets);
    let t = 0;
    r.order.forEach(([who, card], i) => {
      if (i === 4) t += 380;                                   // short pause before a third card
      timers.current.push(setTimeout(() => { setShown((s) => ({ ...s, [who]: [...s[who], card] })); sfx.card(); }, t));
      timers.current.push(setTimeout(() => { setRevealed((v) => ({ ...v, [who]: v[who] + 1 })); sfx.chip(); }, t + FLY + FLIP * 0.6));
      t += STEP;
    });
    timers.current.push(setTimeout(() => { setOut(r); setDealing(false); commit(); if (r.payout > r.stake) sfx.win(); else if (r.payout < r.stake) sfx.lose(); }, t + FLY + FLIP + 250));
  };

  const road = view?.road || [];
  const counts = { P: road.filter((x) => x === 'P').length, B: road.filter((x) => x === 'B').length, T: road.filter((x) => x === 'T').length };
  return (
    <GameShell title="Baccarat" subtitle="Punto Banco · 8 decks · bet on Player, Banker or Tie" rtp="98.9%" history={history}
      rules={<>
        <p>Cards count at face value, 10s and picture cards count 0, and only the last digit of the total counts (7+8 = 5). The hand closer to 9 wins. Third cards are drawn automatically by the standard rules.</p>
        <p>Player pays 1:1. Banker pays 0.95:1 (5% commission). Tie pays 8:1, and Player/Banker bets are returned on a tie. Player Pair and Banker Pair pay 11:1 if that hand's first two cards are the same rank.</p>
        <p className="text-slate-500">House edge: Banker 1.06%, Player 1.24%, Tie about 14%. The bead road below only records history; it doesn't predict the next hand.</p>
      </>}>
      <section className="relative overflow-hidden rounded-2xl bg-[radial-gradient(ellipse_at_top,#1e3a8a_0%,#0b1d4d_55%,#060f2b_100%)] px-3 pb-3 pt-4 ring-1 ring-blue-900 sm:p-6">
        <div className="pointer-events-none absolute left-1/2 top-0 -translate-x-1/2" aria-hidden="true">
          <div className="relative h-7 w-16 rounded-b-lg bg-gradient-to-b from-slate-700 to-slate-900 shadow-lg ring-1 ring-white/10"><div className="absolute inset-x-2 bottom-1 h-3 rounded-sm bg-gradient-to-br from-red-800 to-red-950 ring-1 ring-white/30" /></div>
        </div>
        <div ref={tableRef} className="grid grid-cols-2 gap-2 pt-4 sm:gap-4">
          <Hand cards={shown.P} revealed={revealed.P} label="Player" color="text-sky-300" fromX={tableW / 4} win={out?.winner === 'P'} />
          <Hand cards={shown.B} revealed={revealed.B} label="Banker" color="text-red-300" fromX={-tableW / 4} win={out?.winner === 'B'} />
        </div>
        <div className="mt-3 flex min-h-12 items-center justify-center">
          {out ? (
            <div className="animate-fade-in rounded-xl bg-black/40 px-5 py-2 text-center">
              <div className={`font-cond text-2xl font-extrabold uppercase ${out.winner === 'P' ? 'text-sky-300' : out.winner === 'B' ? 'text-red-300' : 'text-emerald-300'}`}>{out.winner === 'P' ? 'Player wins' : out.winner === 'B' ? 'Banker wins' : 'Tie'} {out.p}-{out.b}{out.natural ? ' · natural' : ''}</div>
              <div className="text-xs text-white/80">{out.payout > 0 ? `Returned ${money(out.payout)}` : `Lost ${money(out.stake)}`}{out.pairP ? ' · Player pair' : ''}{out.pairB ? ' · Banker pair' : ''}</div>
            </div>
          ) : <div className="text-sm text-blue-100/60">{dealing ? 'Dealing…' : 'Place your bets'}</div>}
        </div>
        <div className="mt-3 grid grid-cols-[0.8fr_1fr_1fr_1fr_0.8fr] gap-1.5">
          {SPOTS.map((s) => (
            <button key={s.k} disabled={dealing} onClick={() => { sfx.chip(); setOut(null); setBets((b) => ({ ...b, [s.k]: b[s.k] + chip })); }}
              className={`relative flex flex-col items-center justify-center rounded-xl bg-gradient-to-b ${s.cls} ring-1 ring-white/15 transition hover:brightness-125 ${s.big ? 'h-20' : 'h-20 text-[10px]'} ${out && ((s.k === 'player' && out.winner === 'P') || (s.k === 'banker' && out.winner === 'B') || (s.k === 'tie' && out.winner === 'T') || (s.k === 'pPair' && out.pairP) || (s.k === 'bPair' && out.pairB)) ? 'ring-2 ring-gold-400' : ''}`}>
              <span className={`font-cond font-extrabold text-white ${s.big ? 'text-base' : 'text-xs'}`}>{s.label}</span>
              <span className="text-[10px] text-white/70">{s.pays}</span>
              {bets[s.k] > 0 && <span className="absolute -top-2 rounded-full bg-gold-400 px-1.5 text-[10px] font-black text-navy-950 shadow">{money(bets[s.k]).replace('.00', '')}</span>}
            </button>
          ))}
        </div>
      </section>

      <div className="card space-y-3 p-3">
        <div className="flex justify-center gap-2">
          {CHIPS.map((c) => <button key={c} onClick={() => { setChip(c); sfx.chip(); }} aria-pressed={chip === c} className={`flex h-11 w-11 items-center justify-center rounded-full border-[3px] border-dashed border-white/40 bg-navy-700 text-[11px] font-extrabold text-white ring-2 ring-white/10 ${chip === c ? '-translate-y-1 bg-gold-500 text-navy-950 ring-gold-400' : ''}`}>{chipLabel(c)}</button>)}
        </div>
        <div className="grid grid-cols-3 gap-2">
          <button className="btn-ghost" disabled={dealing} onClick={() => setBets(EMPTY)}>Clear</button>
          <button className="btn-ghost" disabled={dealing || !last} onClick={() => setBets(last)}>Rebet</button>
          <button className="btn-ghost" disabled={dealing || !total} onClick={() => setBets((b) => Object.fromEntries(Object.entries(b).map(([k, v]) => [k, v * 2])))}>×2</button>
        </div>
        <button className="btn-primary h-12 w-full text-base" disabled={busy || dealing || !total} onClick={deal}>{dealing ? 'Dealing…' : total ? `Deal · ${money(total)}` : 'Tap a bet spot to bet'}</button>
      </div>

      <div className="pop-hide card p-3">
        <div className="mb-2 flex items-center justify-between text-xs"><span className="font-bold uppercase tracking-wider text-slate-400">Bead road</span><span className="text-slate-400">P {counts.P} · B {counts.B} · T {counts.T}</span></div>
        <div className="scrollbar-none overflow-x-auto">
          <div className="grid w-max grid-flow-col grid-rows-6 gap-1">
            {road.map((r, i) => <span key={i} className={`flex h-5 w-5 items-center justify-center rounded-full text-[9px] font-black text-white ${r === 'P' ? 'bg-sky-600' : r === 'B' ? 'bg-red-600' : 'bg-emerald-600'}`}>{r}</span>)}
            {!road.length && <span className="text-xs text-slate-500">No hands yet</span>}
          </div>
        </div>
      </div>
    </GameShell>
  );
}
