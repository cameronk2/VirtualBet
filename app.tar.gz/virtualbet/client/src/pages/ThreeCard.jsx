import { useEffect, useRef, useState } from 'react';
import GameShell, { PlayingCard, StakePicker, useGame } from '../components/GameShell.jsx';
import { money } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import { ANTE_BONUS, HAND_NAME, PAIR_PLUS } from '../../../server/games/threecard.js';

const ANTES = [10, 50, 100, 200, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000, 250000, 500000];
const OUTCOME = { win: ['You win', 'text-gold-400'], lose: ['Dealer wins', 'text-red-400'], push: ['Push', 'text-slate-200'], noQualify: ["Dealer doesn't qualify", 'text-sky-300'], fold: ['Folded', 'text-slate-400'] };

export default function ThreeCard() {
  const { view, history, busy, play, commit } = useGame('threecard');
  const [ante, setAnte] = useState(100);
  const [ppOn, setPpOn] = useState(false);
  const [hint, setHint] = useState(false);
  const [res, setRes] = useState(null);
  const [reveal, setReveal] = useState(0);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const hand = view?.hand;
  const deciding = !!hand;

  const deal = async () => {
    setRes(null); setReveal(0);
    const out = await play('deal', { ante, pp: ppOn ? ante : 0 });
    if (out) { [0, 1, 2].forEach((i) => timers.current.push(setTimeout(() => sfx.card(), i * 180))); commit(); }
  };
  const decide = async (a) => {
    const out = await play(a, {});
    if (!out) return;
    setRes(out);
    setReveal(0);
    [1, 2, 3].forEach((i) => timers.current.push(setTimeout(() => { setReveal(i); sfx.card(); }, i * 420)));
    timers.current.push(setTimeout(() => { commit(); if (out.payout > out.staked) sfx.win(); else if (out.payout < out.staked) sfx.lose(); }, 1500));
  };

  const playerCards = res ? res.player : hand?.player;
  const dealerCards = res ? res.dealer.map((c, i) => (i < reveal ? c : '??')) : hand ? ['??', '??', '??'] : null;
  const done = res && reveal >= 3;

  return (
    <GameShell title="Three Card Poker" subtitle="Beat the dealer's three cards · dealer needs Queen-high to qualify" rtp="96.6%" history={history}
      rules={<>
        <p>Place an Ante (and optionally Pair Plus), see your three cards, then Play (a bet equal to your Ante) or Fold. The dealer needs Queen-high or better to qualify.</p>
        <p>Dealer doesn't qualify: Ante pays 1:1 and Play is returned. Dealer qualifies: beat them and Ante and Play both pay 1:1; lose and both lose; tie and both are returned.</p>
        <p>Hand order: straight flush, three of a kind, straight, flush, pair, high card (in 3-card poker a straight beats a flush). A-2-3 is the lowest straight.</p>
        <p><b>Ante bonus</b> (paid even if the dealer wins): straight {ANTE_BONUS.straight}:1, three of a kind {ANTE_BONUS.trips}:1, straight flush {ANTE_BONUS.straightFlush}:1.</p>
        <p><b>Pair Plus</b> (your hand only): pair {PAIR_PLUS.pair}:1, flush {PAIR_PLUS.flush}:1, straight {PAIR_PLUS.straight}:1, three of a kind {PAIR_PLUS.trips}:1, straight flush {PAIR_PLUS.straightFlush}:1.</p>
        <p className="text-slate-500">Best strategy: Play with Queen-6-4 or better, fold anything worse. The hint uses this rule.</p>
      </>}>
      <section className="rounded-2xl bg-[radial-gradient(ellipse_at_top,#115e59_0%,#0b3b38_55%,#062523_100%)] p-4 ring-1 ring-teal-900 sm:p-6">
        <div className="flex flex-col items-center gap-2">
          <div className="font-cond text-sm font-bold uppercase tracking-widest text-teal-100/80">Dealer {done && <span className="ml-1 rounded-full bg-black/40 px-2 text-white">{HAND_NAME[res.dealerHand]}{res.dealerQualifies ? '' : ' · no qualify'}</span>}</div>
          <div className="flex min-h-28 gap-2">{dealerCards?.map((c, i) => <PlayingCard key={`${i}-${c}`} code={c} anim={c !== '??' ? 'flip' : 'deal'} />)}</div>
        </div>
        <div className="my-3 flex min-h-14 items-center justify-center text-center">
          {done ? (
            <div className="animate-fade-in rounded-xl bg-black/40 px-5 py-2">
              <div className={`font-cond text-2xl font-extrabold uppercase ${OUTCOME[res.outcome][1]}`}>{OUTCOME[res.outcome][0]}</div>
              <div className="text-xs text-white/80">{res.lines.map((l) => `${l.bet}: ${l.result}${l.amount ? ` +${money(l.amount)}` : ''}`).join(' · ')}{res.lines.length ? ' · ' : ''}{res.payout > 0 ? `Returned ${money(res.payout)}` : `Lost ${money(res.staked)}`}</div>
            </div>
          ) : deciding ? <div className="text-sm text-teal-50/80">You have <b className="text-white">{HAND_NAME[hand.playerHand]}</b>. Play for {money(hand.ante)} or fold?</div>
            : <div className="text-sm text-teal-50/60">Set your Ante and deal</div>}
        </div>
        <div className="flex flex-col items-center gap-2">
          <div className="flex min-h-28 gap-2">{playerCards?.map((c, i) => <PlayingCard key={`${i}-${c}`} code={c} anim="deal" />)}</div>
          <div className="font-cond text-sm font-bold uppercase tracking-widest text-teal-100/80">You</div>
        </div>
      </section>

      {deciding ? (
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button className={`btn-primary h-12 text-base ${hint && hand.hint === 'play' ? 'ring-2 ring-gold-400 ring-offset-2 ring-offset-navy-950' : ''}`} disabled={busy} onClick={() => decide('play')}>Play · {money(hand.ante)}</button>
            <button className={`btn-ghost h-12 text-base ${hint && hand.hint === 'fold' ? 'ring-2 ring-gold-400 ring-offset-2 ring-offset-navy-950' : ''}`} disabled={busy} onClick={() => decide('fold')}>Fold</button>
          </div>
          <label className="flex items-center justify-center gap-2 text-xs text-slate-400">
            <input type="checkbox" className="h-4 w-4 accent-brand-500" checked={hint} onChange={(e) => setHint(e.target.checked)} /> Show strategy hint{hint ? <b className="text-gold-400"> · {hand.hint === 'play' ? 'Play' : 'Fold'}</b> : ''}
          </label>
        </div>
      ) : (
        <div className="card flex flex-wrap items-center gap-3 p-3">
          <StakePicker value={ante} onChange={setAnte} options={ANTES} label="Ante" />
          <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" className="h-4 w-4 accent-brand-500" checked={ppOn} onChange={(e) => setPpOn(e.target.checked)} /> Pair Plus {money(ante)}</label>
          <button className="btn-primary ml-auto h-12 min-w-36 text-base" disabled={busy} onClick={deal}>Deal · {money(ante + (ppOn ? ante : 0))}</button>
          <p className="w-full text-[11px] text-slate-500">You'll need another {money(ante)} to Play after seeing your cards.</p>
        </div>
      )}
    </GameShell>
  );
}
