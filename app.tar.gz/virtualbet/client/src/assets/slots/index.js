import mummy_A from './mummy/A.webp';
import mummy_ANKH from './mummy/ANKH.webp';
import mummy_ANUBIS from './mummy/ANUBIS.webp';
import mummy_BOOK from './mummy/BOOK.webp';
import mummy_COIN from './mummy/COIN.webp';
import mummy_EYE from './mummy/EYE.webp';
import mummy_FS from './mummy/FS.webp';
import mummy_J from './mummy/J.webp';
import mummy_K from './mummy/K.webp';
import mummy_MUMMY from './mummy/MUMMY.webp';
import mummy_PHARAOH from './mummy/PHARAOH.webp';
import mummy_Q from './mummy/Q.webp';
import mummy_WILD from './mummy/WILD.webp';
import stampede_BUFFALO from './stampede/BUFFALO.webp';
import stampede_COIN from './stampede/COIN.webp';
import stampede_COUGAR from './stampede/COUGAR.webp';
import stampede_EAGLE from './stampede/EAGLE.webp';
import stampede_ELK from './stampede/ELK.webp';
import stampede_GOLD from './stampede/GOLD.webp';
import stampede_WILD from './stampede/WILD.webp';
import stampede_WOLF from './stampede/WOLF.webp';
import brick_P1 from './brick/P1.webp';
import moonridge_WHITE from './moonridge/WHITE.webp';
import atlantis_MASK from './atlantis/MASK.webp';

export const SLOT_IMG = {
  mummy: { A: mummy_A, ANKH: mummy_ANKH, ANUBIS: mummy_ANUBIS, BOOK: mummy_BOOK, COIN: mummy_COIN, EYE: mummy_EYE, FS: mummy_FS, J: mummy_J, K: mummy_K, MUMMY: mummy_MUMMY, PHARAOH: mummy_PHARAOH, Q: mummy_Q, WILD: mummy_WILD },
  stampede: { BUFFALO: stampede_BUFFALO, COIN: stampede_COIN, COUGAR: stampede_COUGAR, EAGLE: stampede_EAGLE, ELK: stampede_ELK, GOLD: stampede_GOLD, WILD: stampede_WILD, WOLF: stampede_WOLF },
  brick: { P1: brick_P1 },
  moonridge: { WHITE: moonridge_WHITE },
  atlantis: { MASK: atlantis_MASK },
};
export const SLOT_BG = {};
