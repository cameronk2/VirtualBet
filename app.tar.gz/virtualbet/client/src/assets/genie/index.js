// Golden Wishes painted art (generated with ElevenLabs image models from our own
// prompts, see docs/genie-mechanics.md). Bundled as data URLs. Symbols are
// 320px tiles with their frames; TALL is the expanding wild; BG the backdrop.
import GENIE from './genie.webp';
import LAMP from './lamp.webp';
import STAR from './star.webp';
import PRINCESS from './princess.webp';
import PALACE from './palace.webp';
import CHEST from './chest.webp';
import CROWN from './crown.webp';
import AMETHYST from './amethyst.webp';
import EMERALD from './emerald.webp';
import RUBY from './ruby.webp';
import A from './a.webp';
import K from './k.webp';
import Q from './q.webp';
import J from './j.webp';
import T from './t.webp';
import TALL from './tall.webp';
import BG from './bg.webp';

export const GENIE_IMG = { GENIE, LAMP, STAR, PRINCESS, PALACE, CHEST, CROWN, AMETHYST, EMERALD, RUBY, A, K, Q, J, T };
export const GENIE_TALL_IMG = TALL;
export const GENIE_BG_IMG = BG;
