import { lazy, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { AppProvider } from './state/AppContext.jsx';
import { matchPath, useLocation } from './lib/router.jsx';
import Layout from './components/Layout.jsx';
import Home from './pages/Home.jsx';
import { LivePage, ResultsPage, UpcomingPage } from './pages/Matches.jsx';
import MatchPage from './pages/Match.jsx';
import MyBets from './pages/MyBets.jsx';
import History from './pages/History.jsx';
import Leaderboard from './pages/Leaderboard.jsx';
import Account from './pages/Account.jsx';
import Auth from './pages/Auth.jsx';
const Blackjack = lazy(() => import('./pages/Blackjack.jsx'));
const Slots = lazy(() => import('./pages/Slots.jsx'));
const Casino = lazy(() => import('./pages/Casino.jsx'));
const Roulette = lazy(() => import('./pages/Roulette.jsx'));
const Baccarat = lazy(() => import('./pages/Baccarat.jsx'));
const ThreeCard = lazy(() => import('./pages/ThreeCard.jsx'));
const Crash = lazy(() => import('./pages/Crash.jsx'));
const Plinko = lazy(() => import('./pages/Plinko.jsx'));
const Scratch = lazy(() => import('./pages/Scratch.jsx'));
const FruitGame = lazy(() => import('./pages/SlotGames.jsx').then((m) => ({ default: m.FruitGame })));
const NebulaGame = lazy(() => import('./pages/SlotGames.jsx').then((m) => ({ default: m.NebulaGame })));
const StarlightGame = lazy(() => import('./pages/SlotGames.jsx').then((m) => ({ default: m.StarlightGame })));
const VaultGame = lazy(() => import('./pages/SlotGames.jsx').then((m) => ({ default: m.VaultGame })));
import { Achievements } from './pages/Progress.jsx';
const Atlantis = lazy(() => import('./pages/premium/Atlantis.jsx'));
const Neon = lazy(() => import('./pages/premium/Neon.jsx'));
const Dragon = lazy(() => import('./pages/premium/Dragon.jsx'));
const Cosmic = lazy(() => import('./pages/premium/Cosmic.jsx'));
const Pharaoh = lazy(() => import('./pages/premium/Pharaoh.jsx'));
const Frostfang = lazy(() => import('./pages/premium/Frostfang.jsx'));
const Moonridge = lazy(() => import('./pages/premium/Moonridge.jsx'));
const Mummy = lazy(() => import('./pages/premium/mummy/Mummy.jsx'));
const PolarCatch = lazy(() => import('./pages/premium/polarcatch/PolarCatch.jsx'));
const Brick = lazy(() => import('./pages/premium/brick/Brick.jsx'));
const Stampede = lazy(() => import('./pages/premium/stampede/Stampede.jsx'));
const Genie = lazy(() => import('./pages/premium/genie/Genie.jsx'));
const ChickenGame = lazy(() => import('./pages/premium/chicken/Chicken.jsx'));
const Mines = lazy(() => import('./pages/premium/mines/Mines.jsx'));
const Keno = lazy(() => import('./pages/premium/keno/Keno.jsx'));
import { Empty, Loading } from './components/ui.jsx';

const CASINO = { roulette: Roulette, baccarat: Baccarat, threecard: ThreeCard, crash: Crash, plinko: Plinko, scratch: Scratch, nebula: NebulaGame, vault: VaultGame, fruit: FruitGame, starlight: StarlightGame, atlantis: Atlantis, neon: Neon, dragon: Dragon, cosmic: Cosmic, pharaoh: Pharaoh, frost: Frostfang, moonridge: Moonridge, mummy: Mummy, polarcatch: PolarCatch, brick: Brick, stampede: Stampede, chicken: ChickenGame, mines: Mines, keno: Keno, genie: Genie };

function Routes() {
  const { pathname } = useLocation();
  let params;
  if (pathname === '/') return <Home />;
  if (pathname === '/live') return <LivePage />;
  if (pathname === '/upcoming') return <UpcomingPage />;
  if (pathname === '/results') return <ResultsPage />;
  if ((params = matchPath('/match/:id', pathname))) return <MatchPage id={params.id} />;
  if (pathname === '/my-bets') return <MyBets />;
  if (pathname === '/history') return <History />;
  if (pathname === '/leaderboard') return <Leaderboard />;
  if (pathname === '/blackjack') return <Blackjack />;
  if (pathname === '/spin21') return <Blackjack key="spin21" variant="spin21" />;
  if (pathname === '/slots') return <Slots />;
  if (pathname === '/casino') return <Casino />;
  if ((params = matchPath('/casino/:game', pathname)) && CASINO[params.game]) { const G = CASINO[params.game]; return <G key={params.game} />; }
  if (pathname === '/achievements') return <Achievements />;
  if (pathname === '/account') return <Account />;
  if (pathname === '/login') return <Auth mode="login" />;
  if (pathname === '/register') return <Auth mode="register" />;
  return <div className="card"><Empty title="Page not found" /></div>;
}

// Register the service worker in the hosted build only (not the single-file version)
if (typeof __PWA__ !== 'undefined' && __PWA__ && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}

createRoot(document.getElementById('root')).render(
  <AppProvider>
    <Layout>
      <Suspense fallback={<Loading label="Loading…" />}>
        <Routes />
      </Suspense>
    </Layout>
  </AppProvider>,
);
