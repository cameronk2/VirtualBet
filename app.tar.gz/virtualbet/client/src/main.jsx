import { createRoot } from 'react-dom/client';
import { AppProvider } from './state/AppContext.jsx';
import { matchPath, useLocation } from './lib/router.jsx';
import Layout from './components/Layout.jsx';
import Home from './pages/Home.jsx';
import { LivePage, UpcomingPage } from './pages/Matches.jsx';
import MatchPage from './pages/Match.jsx';
import MyBets from './pages/MyBets.jsx';
import History from './pages/History.jsx';
import Leaderboard from './pages/Leaderboard.jsx';
import Account from './pages/Account.jsx';
import Auth from './pages/Auth.jsx';
import Blackjack from './pages/Blackjack.jsx';
import Slots from './pages/Slots.jsx';
import Casino from './pages/Casino.jsx';
import Roulette from './pages/Roulette.jsx';
import Baccarat from './pages/Baccarat.jsx';
import ThreeCard from './pages/ThreeCard.jsx';
import Crash from './pages/Crash.jsx';
import Plinko from './pages/Plinko.jsx';
import Scratch from './pages/Scratch.jsx';
import { FruitGame, NebulaGame, StarlightGame, VaultGame } from './pages/SlotGames.jsx';
import { Achievements } from './pages/Progress.jsx';
import Atlantis from './pages/premium/Atlantis.jsx';
import Neon from './pages/premium/Neon.jsx';
import Dragon from './pages/premium/Dragon.jsx';
import Cosmic from './pages/premium/Cosmic.jsx';
import Pharaoh from './pages/premium/Pharaoh.jsx';
import Frostfang from './pages/premium/Frostfang.jsx';
import Moonridge from './pages/premium/Moonridge.jsx';
import Mummy from './pages/premium/mummy/Mummy.jsx';
import PolarCatch from './pages/premium/polarcatch/PolarCatch.jsx';
import Brick from './pages/premium/brick/Brick.jsx';
import Stampede from './pages/premium/stampede/Stampede.jsx';
import Genie from './pages/premium/genie/Genie.jsx';
import ChickenGame from './pages/premium/chicken/Chicken.jsx';
import Mines from './pages/premium/mines/Mines.jsx';
import Keno from './pages/premium/keno/Keno.jsx';
import { Empty } from './components/ui.jsx';

const CASINO = { roulette: Roulette, baccarat: Baccarat, threecard: ThreeCard, crash: Crash, plinko: Plinko, scratch: Scratch, nebula: NebulaGame, vault: VaultGame, fruit: FruitGame, starlight: StarlightGame, atlantis: Atlantis, neon: Neon, dragon: Dragon, cosmic: Cosmic, pharaoh: Pharaoh, frost: Frostfang, moonridge: Moonridge, mummy: Mummy, polarcatch: PolarCatch, brick: Brick, stampede: Stampede, chicken: ChickenGame, mines: Mines, keno: Keno, genie: Genie };

function Routes() {
  const { pathname } = useLocation();
  let params;
  if (pathname === '/') return <Home />;
  if (pathname === '/live') return <LivePage />;
  if (pathname === '/upcoming') return <UpcomingPage />;
  if ((params = matchPath('/match/:id', pathname))) return <MatchPage id={params.id} />;
  if (pathname === '/my-bets') return <MyBets />;
  if (pathname === '/history') return <History />;
  if (pathname === '/leaderboard') return <Leaderboard />;
  if (pathname === '/blackjack') return <Blackjack />;
  if (pathname === '/spin21') return <Blackjack key="spin21" variant="spin21" />;
  if (pathname === '/slots') return <Slots />;
  if (pathname === '/casino') return <Casino />;
  if ((params = matchPath('/casino/:game', pathname)) && CASINO[params.game]) { const G = CASINO[params.game]; return <G key={params.game} />; }
  if (pathname === '/achievements') return <Achievements />;
  if (pathname === '/account') return <Account />;
  if (pathname === '/login') return <Auth mode="login" />;
  if (pathname === '/register') return <Auth mode="register" />;
  return <div className="card"><Empty title="Page not found" /></div>;
}

// Register the service worker in the hosted build only (not the single-file version)
if (typeof __PWA__ !== 'undefined' && __PWA__ && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}

createRoot(document.getElementById('root')).render(
  <AppProvider>
    <Layout>
      <Routes />
    </Layout>
  </AppProvider>,
);
