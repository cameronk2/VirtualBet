// In-browser SIMULATED match schedule for the standalone (phone) build.
// Fixtures are a pure function of the clock: every slot's matches are
// derived from a seed, so a bet placed today settles against exactly the
// same match when the app is reopened tomorrow. Nothing is stored.
import { DEMO_LEAGUES } from '../../server/data/demo-teams.js';
import { lambdasFor } from '../../server/markets.js';
import { generateTimeline, hashSeed, rng, stateAt } from '../../server/providers/sim.js';

export const SECONDS_PER_MINUTE = 8;
const SLOT_MS = 5 * 60000;
const PER_SLOT = 2;
const BLOCK_SLOTS = 36; // 3 hours
const BLOCK_MS = SLOT_MS * BLOCK_SLOTS;
const LEAGUE_WEIGHT = { PL: 3, CL: 2, ELC: 1.5 };
const CAPS = { goalOrder: true, corners: true, liveCorners: true, cards: true, liveCards: true };

const blockCache = new Map();

function buildBlock(index, avoidTeams) {
  const r = rng(hashSeed(`block-${index}`));
  const queues = DEMO_LEAGUES.map((l) => {
    const teams = [...l.teams];
    for (let i = teams.length - 1; i > 0; i--) {
      const j = Math.floor(r() * (i + 1));
      [teams[i], teams[j]] = [teams[j], teams[i]];
    }
    const pairs = [];
    for (let i = 0; i + 1 < teams.length; i += 2) pairs.push([teams[i], teams[i + 1]]);
    return { league: l, pairs };
  });
  const fixtures = [];
  const start = index * BLOCK_MS;
  for (let s = 0; s < BLOCK_SLOTS; s++) {
    for (let i = 0; i < PER_SLOT; i++) {
      const avail = queues.filter((qq) => qq.pairs.length);
      if (!avail.length) break;
      let pick = null;
      for (let tries = 0; tries < 6 && !pick; tries++) {
        const total = avail.reduce((a, qq) => a + (LEAGUE_WEIGHT[qq.league.code] || 1), 0);
        let roll = r() * total;
        const qq = avail.find((x) => (roll -= LEAGUE_WEIGHT[x.league.code] || 1) <= 0) || avail[0];
        const idx = s < 3 && avoidTeams ? qq.pairs.findIndex(([h, a]) => !avoidTeams.has(h.name) && !avoidTeams.has(a.name)) : 0;
        if (idx >= 0) pick = { league: qq.league, pair: qq.pairs.splice(idx, 1)[0] };
      }
      if (!pick) continue;
      const slot = start + s * SLOT_MS;
      const [home, away] = r() < 0.5 ? pick.pair : [pick.pair[1], pick.pair[0]];
      fixtures.push({ id: `d${slot.toString(36)}-${i}`, slot, s, league: pick.league, home, away });
    }
  }
  return fixtures;
}

function block(index) {
  if (blockCache.has(index)) return blockCache.get(index);
  // Teams in the last 3 slots of the previous block can't start this one (still playing)
  const prev = buildBlock(index - 1, null);
  const avoid = new Set(prev.filter((f) => f.s >= BLOCK_SLOTS - 3).flatMap((f) => [f.home.name, f.away.name]));
  const fx = buildBlock(index, avoid);
  blockCache.set(index, fx);
  if (blockCache.size > 30) blockCache.delete(blockCache.keys().next().value);
  return fx;
}

const simCache = new Map();
function rowFor(f, t) {
  let base = simCache.get(f.id);
  if (!base) {
    const lam = lambdasFor(f.home.s, f.away.s);
    base = {
      sim: generateTimeline(hashSeed(f.id), lam.lambda_home, lam.lambda_away),
      row: {
        id: f.id, source: 'demo', league_code: `SIM-${f.league.code}`, league_name: `${f.league.name} (simulated)`, country: 'Practice',
        home_name: f.home.name, away_name: f.away.name, home_short: f.home.short, away_short: f.away.short,
        home_crest: null, away_crest: null, home_color: f.home.color, away_color: f.away.color,
        kickoff_at: f.slot, ...lam, caps: CAPS, minute_estimated: 0, last_sync_at: null,
      },
    };
    simCache.set(f.id, base);
    if (simCache.size > 3000) simCache.delete(simCache.keys().next().value);
  }
  const st = stateAt(f.slot, base.sim, t, SECONDS_PER_MINUTE);
  if (st.status === 'SCHEDULED') {
    return { ...base.row, status: 'SCHEDULED', minute: null, home_score: null, away_score: null, ht_home: null, ht_away: null,
      home_corners: null, away_corners: null, home_cards: null, away_cards: null, goal_order: null, events: '[]',
      suspended_until: null, result_verified: 0, finished_at: null };
  }
  return { ...base.row, ...st };
}

/** Rows for fixtures kicking off in [from, to]. */
export function rowsBetween(from, to, t = Date.now()) {
  const out = [];
  for (let b = Math.floor(from / BLOCK_MS); b <= Math.floor(to / BLOCK_MS); b++) {
    for (const f of block(b)) if (f.slot >= from && f.slot <= to) out.push(rowFor(f, t));
  }
  return out;
}

export function rowById(id, t = Date.now()) {
  const m = /^d([0-9a-z]+)-(\d)$/.exec(id || '');
  if (!m) return null;
  const slot = parseInt(m[1], 36);
  const f = block(Math.floor(slot / BLOCK_MS)).find((x) => x.id === id);
  return f ? rowFor(f, t) : null;
}

export const AHEAD_MS = 3 * 3600000;
export const BEHIND_MS = 25 * 60000;
