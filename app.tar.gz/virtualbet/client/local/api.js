// Standalone build: the same /api/* interface as the Node server, answered
// in the browser. Uses the server's own pure odds, settlement and money
// modules, so prices and payouts are identical to the full app.
import { RULES as SERVER_RULES } from './rules.js';
import { priceMarkets, resultFromRow, settleSelection, VOID_STATUSES } from '../../server/markets.js';
import { combinedOddsX100, gbp, potentialReturn } from '../../server/money.js';
import { cashOutValue, currentLegs } from '../../server/cashout.js';
import { serializeMatch } from '../../server/serialize.js';
import { act as bjAct, extraStake as bjExtra, hint as bjHint, MAX_SEATS, publicView as bjView, startRound as bjStart } from '../../server/blackjack.js';
import { spin as slotSpin } from '../../server/slots.js';
import { CATALOGUE, GameError, GAMES, runGame } from '../../server/games/registry.js';
import { NO_LIMIT, TABLE_GAMES } from '../../server/games/common.js';
import { ACHIEVEMENTS, isReturnTx, isStakeTx, productOf, track } from '../../server/achievements.js';

const rand = () => crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296;
import { AHEAD_MS, BEHIND_MS, rowById as simRowById, rowsBetween, SECONDS_PER_MINUTE } from './engine.js';
import { fixturesLoaded, fixturesReady, lastFixturesSync, realRowById, realRows } from './fixtures.js';

const isReal = (id) => /^r\d+$/.test(String(id));
const rowById = (id) => (isReal(id) ? realRowById(id) : simRowById(id));
import { persistence, ready, save, state } from './store.js';

const RULES = SERVER_RULES;

export const apiEvents = new EventTarget();

export class ApiError extends Error {
  constructor(status, body) {
    super(body?.error || `Request failed (${status})`);
    this.status = status;
    this.body = body || {};
  }
}
const fail = (status, error, extra) => { throw new ApiError(status, { error, ...(extra || {}) }); };
const now = () => Date.now();
const fmt = gbp;
const LEAGUE_ORDER = ['CL', 'PL', 'EL', 'PD', 'SA', 'BL1', 'FL1', 'ELC', 'SPL', 'EL1', 'EL2'];
const rank = (c) => { const i = LEAGUE_ORDER.indexOf(c); return i < 0 ? 99 : i; };
const LIVE = ['LIVE_1H', 'HT', 'LIVE_2H', 'SUSPENDED'];

// ── Wallet ──
function change(type, amount, reference = null, note = null) {
  const p = state.profile;
  const after = p.balance + amount;
  if (after < 0) fail(400, 'Insufficient virtual balance.');
  state.tx.unshift({ id: state.seq++, type, amount, balanceBefore: p.balance, balanceAfter: after, reference, note, createdAt: now() });
  p.balance = after;
  // Lifetime totals per product, for the "what this would have cost" panel
  const prod = productOf({ type, reference });
  if (prod && state.lifetime) {
    const l = state.lifetime[prod] || (state.lifetime[prod] = { staked: 0, returned: 0 });
    if (isStakeTx(type)) l.staked -= amount;
    if (isReturnTx(type)) l.returned += amount;
  }
}

// Achievements (badges only): newly unlocked ones ride along on the next response
let unlockedQueue = [];
function award(events) {
  state.progress = state.progress || {};
  const got = track(state.progress, events, now());
  if (got.length) unlockedQueue.push(...got);
  return got;
}

function requireUser() {
  if (!state.profile || !state.loggedIn) fail(401, 'Please create your player profile to continue.');
  return state.profile;
}

function bonusStatus(p) {
  const next = p.lastDailyBonusAt ? p.lastDailyBonusAt + RULES.dailyBonusIntervalMs : 0;
  return { available: now() >= next, nextAvailableAt: next > now() ? next : null, amount: RULES.dailyBonus };
}

function checkBreak(p) {
  if (p.breakUntil && p.breakUntil > now()) fail(403, `You're taking a break until ${new Date(p.breakUntil).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}. Bets and games are paused until then.`, { code: 'BREAK' });
}

function effectiveLimit(p) {
  if (p.pendingLimitAt && p.pendingLimitAt <= now()) {
    p.dailyStakeLimit = p.pendingStakeLimit === -1 ? null : p.pendingStakeLimit;
    p.pendingStakeLimit = null;
    p.pendingLimitAt = null;
    save();
  }
  return p.dailyStakeLimit ?? null;
}
const staked24h = () => state.bets.filter((b) => b.createdAt > now() - 86400000).reduce((a, b) => a + b.stake, 0)
  + state.tx.filter((t) => (t.type === 'BLACKJACK_BET' || t.type === 'SLOTS_BET' || t.type === 'CASINO_BET') && t.createdAt > now() - 86400000).reduce((a, t) => a - t.amount, 0);

function publicUser() {
  const p = state.profile;
  if (!p || !state.loggedIn) return null;
  effectiveLimit(p);
  return {
    id: 1, username: p.username, balance: p.balance, createdAt: p.createdAt,
    dailyBonus: bonusStatus(p), dailyStakeLimit: p.dailyStakeLimit ?? null,
    pendingStakeLimit: p.pendingLimitAt ? (p.pendingStakeLimit === -1 ? 'none' : p.pendingStakeLimit) : null,
    pendingLimitAt: p.pendingLimitAt ?? null, stakedLast24h: staked24h(), realityCheckMinutes: p.realityCheckMinutes ?? 60,
    breakUntil: p.breakUntil && p.breakUntil > now() ? p.breakUntil : null,
  };
}

// ── Matches ──
// Real fixtures are the main content. Simulated matches appear only as
// clearly labelled in-play practice on the Live page.
function listMatches(view, league) {
  const t = now();
  const real = realRows(t);
  let rows;
  if (view === 'live') {
    const sim = rowsBetween(t - BEHIND_MS - 30 * 60000, t + 60000, t).filter((r) => LIVE.includes(r.status));
    rows = [...real.filter((r) => r.status === 'IN_PLAY_PENDING' && r.kickoff_at > t - 4 * 3600000), ...sim];
  } else if (view === 'upcoming') rows = real.filter((r) => r.status === 'SCHEDULED');
  else if (view === 'results') rows = real.filter((r) => ['FINISHED', 'ABANDONED', 'CANCELLED'].includes(r.status) && r.kickoff_at > t - 3 * 86400000).reverse();
  else if (view === 'practice') rows = rowsBetween(t - BEHIND_MS, t + AHEAD_MS, t).filter((r) => r.status === 'SCHEDULED' || LIVE.includes(r.status));
  else rows = real.filter((r) => r.kickoff_at >= t - 6 * 3600000 && r.kickoff_at <= t + 9 * 86400000);
  if (league) rows = rows.filter((r) => r.league_code === league);
  return rows.map((r) => serializeMatch(r));
}

function leagues() {
  const t = now();
  const map = new Map();
  for (const r of realRows(t).filter((x) => x.kickoff_at >= t - 6 * 3600000)) {
    const l = map.get(r.league_code) || { code: r.league_code, name: r.league_name, country: r.country, live: 0, upcoming: 0 };
    if (LIVE.includes(r.status)) l.live++;
    if (r.status === 'SCHEDULED') l.upcoming++;
    map.set(r.league_code, l);
  }
  return [...map.values()].sort((a, b) => rank(a.code) - rank(b.code));
}

// ── Bets ──
const genRef = () => {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const part = () => Array.from(crypto.getRandomValues(new Uint8Array(4)), (x) => A[x % A.length]).join('');
  for (;;) { const r = `VB-${part()}-${part()}`; if (!state.bets.some((b) => b.ref === r)) return r; }
};

function cashOutFor(b) {
  if (b.status !== 'OPEN') return null;
  return cashOutValue(b.stake, b.potentialReturn, currentLegs(b.selections, rowById, priceMarkets));
}

function cashOutBet(ref, expected) {
  requireUser();
  const b = state.bets.find((x) => x.ref === ref);
  if (!b) fail(404, 'Bet not found.');
  settle();
  if (b.status !== 'OPEN') fail(409, 'This bet has already been settled.', { code: 'SETTLED' });
  const co = cashOutFor(b);
  if (!co.available) fail(409, `Cash Out isn't available: ${co.reason.toLowerCase()}.`, { code: 'CASHOUT_UNAVAILABLE' });
  if (!Number.isSafeInteger(expected) || expected !== co.value) fail(409, `The Cash Out value has changed to ${fmt(co.value)}.`, { code: 'CASHOUT_CHANGED', value: co.value });
  b.status = 'CASHED_OUT'; b.actualReturn = co.value; b.settledAt = now();
  change('BET_CASHOUT', co.value, b.ref, 'Cash Out');
  save();
  return { bet: decorate(b), value: co.value, user: publicUser() };
}

function decorate(b) {
  return {
    ...b,
    cashOut: cashOutFor(b),
    profit: b.status === 'OPEN' ? null : (b.actualReturn ?? 0) - b.stake,
    selections: b.selections.map((s) => {
      const row = rowById(s.matchId);
      return {
        ...s,
        matchStatus: row?.status ?? null,
        liveScore: row && row.home_score != null ? `${row.home_score}-${row.away_score}` : null,
        minute: row?.minute ?? null,
        result: row?.status === 'FINISHED' ? `${row.home_score}-${row.away_score}` : null,
      };
    }),
  };
}

function placeBets(body) {
  const p = requireUser();
  const { bets, idempotencyKey } = body || {};
  if (typeof idempotencyKey !== 'string' || idempotencyKey.length < 8) fail(400, 'Missing submission key.');
  const prior = state.placements.find((x) => x.key === idempotencyKey);
  if (prior) return { ...prior.result, duplicate: true };
  if (!Array.isArray(bets) || !bets.length) fail(400, 'Your bet slip is empty.');
  for (const b of bets) {
    if (!Number.isSafeInteger(b.stake) || b.stake < RULES.minStake) fail(400, `Minimum stake is ${fmt(RULES.minStake)}.`);
    if (b.stake > RULES.maxStake) fail(400, `Maximum stake is ${fmt(RULES.maxStake)} per bet.`);
    if (b.type === 'SINGLE' && b.selections.length !== 1) fail(400, 'A single bet must have exactly one selection.');
    if (b.type === 'ACCA') {
      if (b.selections.length < 2) fail(400, 'An accumulator needs at least two selections.');
      if (new Set(b.selections.map((s) => s.matchId)).size !== b.selections.length) fail(400, 'Accumulator selections must all come from different matches.');
    }
  }
  const changes = [];
  const priced = new Map();
  const resolved = bets.map((b) => ({
    ...b,
    selections: b.selections.map((s) => {
      const row = rowById(s.matchId);
      if (!row) fail(404, 'Match not found.');
      if (!priced.has(row.id)) priced.set(row.id, priceMarkets(row));
      const label = `${row.home_name} v ${row.away_name}`;
      const market = priced.get(row.id).find((m) => m.key === s.market);
      if (!market) fail(409, `${label}: that market is no longer available.`, { code: 'UNAVAILABLE' });
      if (market.suspended) fail(409, `${label}: betting is suspended right now.`, { code: 'SUSPENDED' });
      const sel = market.selections.find((x) => x.key === s.selection);
      if (!sel?.odds) fail(409, `${label}: that selection is no longer available.`, { code: 'UNAVAILABLE' });
      if (sel.odds !== s.odds) changes.push({ matchId: s.matchId, market: s.market, selection: s.selection, from: s.odds, to: sel.odds });
      const inPlay = row.status !== 'SCHEDULED';
      return {
        matchId: row.id, match: label, league: row.league_name, market: market.name, marketKey: market.key,
        selection: sel.label, selectionKey: sel.key, odds: sel.odds, inPlay,
        scoreAtPlacement: inPlay ? `${row.home_score ?? 0}-${row.away_score ?? 0}` : null,
        minuteAtPlacement: inPlay ? row.minute : null, status: 'OPEN', voidReason: null,
      };
    }),
  }));
  if (changes.length && body.acceptOddsChanges !== true) fail(409, 'Odds have changed. Please review and accept the new odds.', { code: 'ODDS_CHANGED', changes });
  const total = bets.reduce((a, b) => a + b.stake, 0);
  if (total > p.balance) fail(400, `Total stake (${fmt(total)}) is more than your balance (${fmt(p.balance)}).`);
  checkBreak(p);
  const limit = effectiveLimit(p);
  if (limit != null && staked24h() + total > limit) {
    fail(400, `This would exceed your daily stake limit. You can stake ${fmt(Math.max(0, limit - staked24h()))} more in the current 24 hours.`, { code: 'LIMIT' });
  }
  const placed = resolved.map((b) => {
    const odds = b.selections.map((s) => s.odds);
    const bet = {
      ref: genRef(), type: b.type, stake: b.stake, totalOdds: combinedOddsX100(odds), potentialReturn: potentialReturn(b.stake, odds),
      status: 'OPEN', actualReturn: null, createdAt: now(), settledAt: null, selections: b.selections,
    };
    state.bets.unshift(bet);
    change('BET_STAKE', -b.stake, bet.ref, `${b.type === 'ACCA' ? `${odds.length}-fold accumulator` : 'Single'} stake`);
    return bet;
  });
  const result = { refs: placed.map((b) => b.ref), bets: placed.map(decorate), balance: p.balance };
  award([{ t: 'sportsBet' }, { t: 'played', game: 'sports' }]);
  state.placements.unshift({ key: idempotencyKey, result });
  save();
  return result;
}

function quote(selections) {
  const priced = new Map();
  return (selections || []).map((s) => {
    const row = rowById(s.matchId);
    if (!row) return { ...s, available: false };
    if (!priced.has(row.id)) priced.set(row.id, priceMarkets(row));
    const market = priced.get(row.id).find((m) => m.key === s.market);
    const sel = market?.selections.find((x) => x.key === s.selection);
    if (!market || !sel?.odds) return { matchId: s.matchId, market: s.market, selection: s.selection, available: false };
    return {
      matchId: s.matchId, market: s.market, selection: s.selection, odds: sel.odds, available: true, suspended: market.suspended,
      live: row.status !== 'SCHEDULED', minute: row.minute, score: row.status !== 'SCHEDULED' ? `${row.home_score ?? 0}-${row.away_score ?? 0}` : null,
    };
  });
}

// ── Settlement (same rules as the server) ──
export function settle() {
  if (!state.profile) return;
  let changed = false;
  for (const b of state.bets) {
    if (b.status !== 'OPEN') continue;
    for (const s of b.selections) {
      if (s.status !== 'OPEN') continue;
      const row = rowById(s.matchId);
      if (!row) {
        // Never void a real fixture just because data hasn't loaded yet
        if (isReal(s.matchId)) continue;
        s.status = 'VOID'; s.voidReason = 'Match data unavailable'; changed = true; continue;
      }
      if (row.status === 'POSTPONED' && now() - row.kickoff_at > 72 * 3600000) { s.status = 'VOID'; s.voidReason = 'Match postponed'; changed = true; continue; }
      if (VOID_STATUSES.includes(row.status)) { s.status = 'VOID'; s.voidReason = `Match ${row.status.toLowerCase()}`; changed = true; continue; }
      if (row.status === 'FINISHED' && row.result_verified) {
        const r = settleSelection(s.marketKey, s.selectionKey, resultFromRow(row));
        if (r) { s.status = r; s.settledAt = now(); changed = true; }
      }
    }
    const lost = b.selections.some((s) => s.status === 'LOST');
    const open = b.selections.some((s) => s.status === 'OPEN');
    if (!lost && open) continue;
    b.settledAt = now();
    if (lost) { b.status = 'LOST'; b.actualReturn = 0; }
    else {
      const won = b.selections.filter((s) => s.status === 'WON').map((s) => s.odds);
      if (!won.length) { b.status = 'VOID'; b.actualReturn = b.stake; change('BET_VOID_REFUND', b.stake, b.ref, 'Stake returned - bet void'); }
      else { b.status = 'WON'; b.actualReturn = potentialReturn(b.stake, won); change('BET_WINNINGS', b.actualReturn, b.ref, `Winning ${b.type === 'ACCA' ? 'accumulator' : 'single'} return`); award([{ t: 'sportsWin', legs: b.selections.length, odds: b.totalOdds }]); }
    }
    changed = true;
  }
  if (changed) save();
}

// Pay out a finished blackjack round exactly once
function finishHand(g = 'blackjack') {
  const st = state[g];
  const h = st?.hand;
  if (!h || h.status !== 'done' || h.paid) return;
  if (h.totalPayout > 0) change('BLACKJACK_WIN', h.totalPayout, g, `${g === 'spin21' ? 'Spin 21' : 'Blackjack'} return`);
  award([{ t: 'played', game: g }, {
    t: 'blackjack',
    natural: h.seats.some((x) => x.hands.some((hh) => hh.result === 'blackjack')),
    split: h.seats.some((x) => x.hands.length > 1),
    wheel: h.seats.some((x) => x.side?.spin?.result === 'wheel'),
    grand: h.seats.some((x) => x.side?.spin?.result === 'wheel' && x.side.spin.x >= 150),
  }]);
  h.paid = true;
  st.history.unshift({ at: now(), staked: h.totalStaked, payout: h.totalPayout, hands: h.seats.reduce((a, x) => a + x.hands.length, 0) });
  st.history = st.history.slice(0, 20);
}
// Rounds from the older single-hand version: refund any unfinished one
function migrateBlackjack() {
  const h = state.blackjack.hand;
  if (h && h.v !== 2) {
    if (h.status === 'player' && !h.paid) { change('BLACKJACK_WIN', h.totalStake, null, 'Blackjack - unfinished hand refunded after update'); save(); }
    state.blackjack.hand = null;
    state.blackjack.history = (state.blackjack.history || []).map((x) => (x.staked == null ? { at: x.at, staked: x.stake, payout: x.payout, hands: 1 } : x));
  }
}
const bjOut = (g = 'blackjack') => ({ round: bjView(state[g]?.hand), hint: bjHint(state[g]?.hand), history: state[g]?.history || [], user: publicUser() });

// ── Stats ──
function stats() {
  const bets = [...state.bets].reverse();
  const settled = bets.filter((b) => b.status !== 'OPEN');
  const won = settled.filter((b) => b.status === 'WON'), lost = settled.filter((b) => b.status === 'LOST'), voided = settled.filter((b) => b.status === 'VOID');
  const returned = settled.reduce((a, b) => a + (b.actualReturn || 0), 0);
  const profit = returned - settled.reduce((a, b) => a + b.stake, 0);
  const best = won.reduce((m, b) => (!m || b.actualReturn - b.stake > m.actualReturn - m.stake ? b : m), null);
  const worst = lost.reduce((m, b) => (!m || b.stake > m.stake ? b : m), null);
  let run = 0;
  const series = [...settled].sort((a, b) => a.settledAt - b.settledAt).map((b) => ({ t: b.settledAt, pl: (run += (b.actualReturn || 0) - b.stake) }));
  const byMarket = new Map();
  const add = (name, b) => {
    const m = byMarket.get(name) || { market: name, bets: 0, won: 0, staked: 0, returned: 0 };
    m.bets++; if (b.status === 'WON') m.won++; m.staked += b.stake; m.returned += b.actualReturn || 0;
    byMarket.set(name, m);
  };
  for (const b of settled) add(b.type === 'ACCA' ? 'Accumulators' : /^NG\d+$/.test(b.selections[0].marketKey) ? 'Next Goal' : b.selections[0].market, b);
  const markets = [...byMarket.values()].map((m) => ({ ...m, profit: m.returned - m.staked })).sort((a, b) => b.profit - a.profit);
  const since = (ms) => settled.filter((b) => b.settledAt >= ms).reduce((a, b) => a + (b.actualReturn || 0) - b.stake, 0);
  const midnight = new Date(); midnight.setHours(0, 0, 0, 0);
  const decided = won.length + lost.length;
  return {
    totalBets: bets.length, openBets: bets.length - settled.length, won: won.length, lost: lost.length, void: voided.length,
    winRate: decided ? won.length / decided : null, staked: bets.reduce((a, b) => a + b.stake, 0), returned, profit,
    averageOdds: bets.length ? Math.round(bets.reduce((a, b) => a + b.totalOdds, 0) / bets.length) : null,
    bestWin: best ? { ref: best.ref, stake: best.stake, return: best.actualReturn, profit: best.actualReturn - best.stake, odds: best.totalOdds } : null,
    biggestLoss: worst ? { ref: worst.ref, stake: worst.stake, odds: worst.totalOdds } : null,
    mostProfitableMarket: markets.length && markets[0].profit > 0 ? markets[0] : null,
    markets, series, profitToday: since(midnight.getTime()), profit7d: since(now() - 7 * 86400000),
  };
}

const DEMO_LEADERS = [
  ['DemoAce_Liam', 18450, 212, 101], ['DemoPunter_Sophie', 12210, 145, 66], ['DemoTipster_Raj', 7640, 301, 128],
  ['DemoOddsOn_Mia', 3120, 88, 47], ['DemoValue_Ella', 950, 64, 30], ['DemoAccaKing_Tom', -2450, 176, 52],
  ['DemoUnder25_Jack', -6830, 240, 96], ['DemoBTTS_Zara', -11200, 133, 41],
];

// ── Router ──
async function handle(method, path, body) {
  await ready;
  await fixturesReady;
  settle();
  const url = new URL(path, 'https://local');
  const p = url.pathname, qy = url.searchParams;
  const key = `${method} ${p}`;
  let m;

  if (key === 'GET /api/config') {
    return { appName: 'VirtualBet', virtualOnly: true, localMode: true, persistence, realFixtures: fixturesLoaded(), fixturesUpdatedAt: lastFixturesSync(), demoEnabled: true, demoSecondsPerMinute: SECONDS_PER_MINUTE, provider: 'none', providerStatus: null, rules: RULES };
  }
  if (key === 'POST /api/auth/register') {
    const username = String(body?.username || '').trim();
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) fail(400, 'Username must be 3–20 characters: letters, numbers or underscores.');
    if (/^demo/i.test(username)) fail(400, 'Usernames starting with "demo" are reserved.');
    if (state.profile) { state.profile.username = username; state.loggedIn = true; save(); return { user: publicUser() }; }
    state.profile = { username, createdAt: now(), balance: 0, lastDailyBonusAt: null, dailyStakeLimit: null, pendingStakeLimit: null, pendingLimitAt: null, realityCheckMinutes: 60 };
    state.loggedIn = true;
    change('WELCOME_BONUS', RULES.startingBalance, null, 'Free virtual welcome balance (not real money)');
    save();
    return { user: publicUser() };
  }
  if (key === 'POST /api/auth/login') {
    if (!state.profile) fail(404, 'No player profile yet. Create one to get £100 of free virtual money.');
    state.loggedIn = true; save();
    return { user: publicUser() };
  }
  if (key === 'POST /api/auth/logout') { state.loggedIn = false; save(); return { ok: true }; }
  if (key === 'GET /api/me') return { user: publicUser(), profileName: state.profile?.username ?? null };
  if (key === 'PATCH /api/me') {
    const pr = requireUser();
    const username = String(body?.username || '').trim();
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) fail(400, 'Username must be 3–20 characters: letters, numbers or underscores.');
    if (/^demo/i.test(username)) fail(400, 'Usernames starting with "demo" are reserved.');
    pr.username = username; save();
    return { user: publicUser() };
  }

  if (key === 'GET /api/matches') return { matches: listMatches(qy.get('view') || 'all', qy.get('league')), serverTime: now() };
  if (key === 'GET /api/matches/featured') {
    const all = listMatches('all').filter((x) => x.bettingOpen);
    return { matches: all.sort((a, b) => (b.live - a.live) || rank(a.league.code) - rank(b.league.code) || a.kickoff - b.kickoff).slice(0, 6), serverTime: now() };
  }
  if (method === 'GET' && (m = /^\/api\/matches\/([^/]+)$/.exec(p))) {
    const row = rowById(decodeURIComponent(m[1]));
    if (!row) fail(404, 'Match not found.');
    return { match: serializeMatch(row, { full: true }), serverTime: now() };
  }
  if (key === 'GET /api/leagues') return { leagues: leagues() };

  if (key === 'GET /api/wallet') {
    requireUser();
    const before = Number(qy.get('before')) || null;
    const list = before ? state.tx.filter((t) => t.id < before) : state.tx;
    return { user: publicUser(), transactions: list.slice(0, 50), packages: RULES.depositPackages };
  }
  if (key === 'POST /api/wallet/deposit') {
    requireUser();
    const amount = body?.amount;
    if (!(Number.isSafeInteger(amount) && amount >= RULES.depositMin && amount <= RULES.depositMax && amount % RULES.depositStep === 0)) fail(400, `Choose a whole-pound amount from ${fmt(RULES.depositMin)} to ${fmt(RULES.depositMax)}.`);
    if (body?.acknowledged !== true) fail(400, 'Please confirm you understand this is virtual money with no real value.');
    change('FREE_TOKENS', body.amount, null, `Free virtual deposit (${fmt(body.amount)})`);
    save();
    return { user: publicUser() };
  }
  if (key === 'POST /api/wallet/daily-bonus') {
    const pr = requireUser();
    if (!bonusStatus(pr).available) fail(400, 'Daily bonus already claimed. Come back later.');
    pr.lastDailyBonusAt = now();
    change('DAILY_BONUS', RULES.dailyBonus, null, 'Free daily bonus');
    save();
    return { user: publicUser() };
  }
  if (key === 'POST /api/wallet/reset') {
    const pr = requireUser();
    if (body?.confirm !== true) fail(400, 'Please confirm the wallet reset.');
    change('WALLET_RESET', RULES.startingBalance - pr.balance, null, `Wallet reset to ${fmt(RULES.startingBalance)}`);
    save();
    return { user: publicUser() };
  }

  if (key === 'POST /api/bets') { const r = placeBets(body); return { ...r, user: publicUser() }; }
  if (method === 'POST' && (m = /^\/api\/bets\/([^/]+)\/cashout$/.exec(p))) return cashOutBet(decodeURIComponent(m[1]), body?.value);
  if (key === 'POST /api/bets/quote') return { quotes: quote(body?.selections) };
  if (key === 'GET /api/bets') {
    requireUser();
    const st = qy.get('status') || 'all';
    let list = state.bets;
    if (st === 'open') list = list.filter((b) => b.status === 'OPEN');
    if (st === 'settled') list = list.filter((b) => b.status !== 'OPEN').sort((a, b) => b.settledAt - a.settledAt);
    return { bets: list.slice(0, Number(qy.get('limit')) || 200).map(decorate) };
  }
  if (method === 'GET' && (m = /^\/api\/bets\/([^/]+)$/.exec(p))) {
    requireUser();
    const b = state.bets.find((x) => x.ref === decodeURIComponent(m[1]));
    if (!b) fail(404, 'Bet not found.');
    return { bet: decorate(b) };
  }
  if (key === 'GET /api/stats') {
    requireUser();
    const since = Number(qy.get('sessionStart')) || null;
    const s = stats();
    const session = since ? state.bets.filter((b) => b.status !== 'OPEN' && b.settledAt >= since) : null;
    return { stats: s, session: session ? { p: session.reduce((a, b) => a + (b.actualReturn || 0) - b.stake, 0), n: session.length } : null };
  }
  if (key === 'GET /api/leaderboard') {
    const rows = DEMO_LEADERS.map(([username, profit, bets, won]) => ({ username, profit, bets, winRate: won / bets, demo: true, you: false }));
    if (state.profile && state.loggedIn) {
      const s = stats();
      rows.push({ username: state.profile.username, profit: s.profit, bets: s.totalBets, winRate: s.winRate, demo: false, you: true });
    }
    return { rows: rows.sort((a, b) => b.profit - a.profit).map((r, i) => ({ rank: i + 1, ...r })) };
  }
  // ── Blackjack tables (virtual money, same wallet): classic + Spin 21 ──
  const bjm = /^\/api\/(blackjack|spin21)(?:\/(deal|action))?$/.exec(p);
  if (bjm) {
    const g = bjm[1], sub = bjm[2] || '';
    const label = g === 'spin21' ? 'Spin 21' : 'Blackjack';
    if (!state[g]) state[g] = { hand: null, history: [] };
    const st = state[g];
    if (g === 'blackjack') migrateBlackjack();
    if (method === 'GET' && !sub) { requireUser(); return bjOut(g); }
    if (method === 'POST' && sub === 'deal') {
      const pr = requireUser();
      if (st.hand && st.hand.status === 'player') fail(400, 'Finish the current round first.');
      const seats = body?.seats;
      if (!Array.isArray(seats) || seats.length < 1 || seats.length > MAX_SEATS) fail(400, `Play 1 to ${MAX_SEATS} hands.`);
      for (const x of seats) {
        if (!Number.isSafeInteger(x?.bet) || x.bet < RULES.minStake) fail(400, `Minimum bet is ${fmt(RULES.minStake)} per hand.`);
        if (g === 'spin21') {
          if ((x.pp || 0) || (x.t213 || 0)) fail(400, 'Spin 21 only has the Spin side bet.');
          if (x.spin && x.spin !== x.bet) fail(400, 'The Spin bet must match your main bet.');
        } else {
          if (x.spin) fail(400, 'The Spin bet is only on the Spin 21 table.');
          for (const k of ['pp', 't213']) {
            const v = x[k] || 0;
            if (!Number.isSafeInteger(v) || v < 0 || (v > 0 && v < RULES.minStake)) fail(400, `Side bets must be at least ${fmt(RULES.minStake)}.`);
          }
        }
      }
      const total = seats.reduce((a, x) => a + x.bet + (x.pp || 0) + (x.t213 || 0) + (x.spin || 0), 0);
      if (total > pr.balance) fail(400, `Total bet ${fmt(total)} is more than your virtual balance (${fmt(pr.balance)}).`);
      checkBreak(pr);
      const limit = effectiveLimit(pr);
      if (limit != null && staked24h() + total > limit) fail(400, 'This would exceed your daily stake limit.');
      change('BLACKJACK_BET', -total, g, `${label} - ${seats.length} hand${seats.length > 1 ? 's' : ''}`);
      st.hand = bjStart(seats.map((x) => ({ bet: x.bet, pp: x.pp || 0, t213: x.t213 || 0, spin: x.spin || 0 })), rand);
      finishHand(g);
      save();
      return bjOut(g);
    }
    if (method === 'POST' && sub === 'action') {
      const pr = requireUser();
      const h = st.hand;
      if (!h || h.v !== 2 || h.status !== 'player') fail(400, 'Deal a new round first.');
      let extra = 0;
      try { extra = bjExtra(h, body?.action); } catch (e) { fail(400, e.message); }
      if (extra > pr.balance) fail(400, `Not enough virtual balance to ${body.action} (${fmt(pr.balance)}).`);
      const before = JSON.stringify(h);
      try { bjAct(h, body?.action); } catch (e) { st.hand = JSON.parse(before); fail(400, e.message); }
      if (extra) change('BLACKJACK_BET', -extra, g, `${label} ${body.action === 'split' ? 'split' : 'double down'}`);
      finishHand(g);
      save();
      return bjOut(g);
    }
  }

  // ── Slots (virtual money, same wallet) ──
  if (key === 'GET /api/slots') {
    requireUser();
    return { free: state.slots.free, history: state.slots.history, user: publicUser() };
  }
  if (key === 'POST /api/slots/spin') {
    const pr = requireUser();
    const free = state.slots.free;
    let bet;
    if (free) bet = free.bet;
    else {
      bet = body?.stake;
      if (!Number.isSafeInteger(bet) || bet < RULES.minStake) fail(400, `Minimum spin is ${fmt(RULES.minStake)}.`);
      if (bet > 10000) fail(400, `Maximum spin is ${fmt(10000)}.`);
      if (bet > pr.balance) fail(400, `Not enough virtual balance (${fmt(pr.balance)}).`);
      checkBreak(pr);
      const limit = effectiveLimit(pr);
      if (limit != null && staked24h() + bet > limit) fail(400, 'This would exceed your daily stake limit.');
      change('SLOTS_BET', -bet, null, 'Lakeside Lures spin');
    }
    const r = slotSpin(bet, rand, free);
    if (r.win > 0) change('SLOTS_WIN', r.win, null, free ? 'Lakeside Lures free spin win' : 'Lakeside Lures win');
    award([{ t: 'played', game: 'lakeside' }, { t: 'slot', game: 'lakeside', x: r.win / bet, feature: !!r.trigger?.freeSpins }]);
    state.slots.free = r.free && !r.free.ended ? r.free : null;
    const finished = r.free?.ended ? { totalWin: r.free.totalWin, spins: r.free.spinsPlayed } : null;
    if (!free || finished) state.slots.history.unshift({ at: now(), bet, win: finished ? finished.totalWin : r.win, free: !!finished });
    state.slots.history = state.slots.history.slice(0, 20);
    save();
    return { result: r, staked: free ? 0 : bet, free: state.slots.free, finished, history: state.slots.history, user: publicUser() };
  }

  // ── Casino games (shared engines) ──
  const cm = /^\/api\/casino\/([a-z0-9]+)(?:\/([a-z]+))?$/.exec(p);
  if (cm && GAMES[cm[1]]) {
    const id = cm[1], sub = cm[2];
    const pr = requireUser();
    state.casino = state.casino || {};
    const slot = state.casino[id] || (state.casino[id] = { state: GAMES[id].init(), history: [] });
    if (method === 'GET' && !sub) return { view: GAMES[id].view(slot.state, now()), history: slot.history, user: publicUser() };
    if (method === 'POST' && sub) {
      let r;
      try { r = runGame(id, slot.state, sub, body, { rand, now: now(), minStake: RULES.minStake, maxStake: TABLE_GAMES.has(id) ? NO_LIMIT : RULES.maxStake }); }
      catch (e) { if (e instanceof GameError) fail(400, e.message); throw e; }
      if (r.stake > pr.balance) fail(400, `Not enough virtual balance (${fmt(pr.balance)}).`);
      if (r.stake) {
        checkBreak(pr);
        const limit = effectiveLimit(pr);
        if (limit != null && staked24h() + r.stake > limit) fail(400, 'This would exceed your daily stake limit.');
        change('CASINO_BET', -r.stake, id, GAMES[id].label);
      }
      if (r.payout > 0) change('CASINO_WIN', r.payout, id, `${GAMES[id].label} win`);
      slot.state = r.state;
      if (r.settled && (r.settled.staked || r.settled.payout)) {
        slot.history = [{ at: now(), staked: r.settled.staked, payout: r.settled.payout }, ...slot.history].slice(0, 30);
      }
      award([{ t: 'played', game: id }, ...(r.events || [])]);
      save();
      return { out: { ...r.out, staked: r.stake }, view: GAMES[id].view(slot.state, now()), history: slot.history, user: publicUser() };
    }
  }
  if (key === 'GET /api/casino') return { catalogue: CATALOGUE };
  if (key === 'GET /api/achievements') {
    requireUser();
    const pg = state.progress || {};
    return { achievements: ACHIEVEMENTS.map((a) => ({ ...a, unlockedAt: pg.unlocked?.[a.id] || null })), played: (pg.played || []).length };
  }
  if (key === 'POST /api/achievements/event') {
    requireUser();
    if (body?.t === 'hint') { award([{ t: 'hint' }]); save(); }
    return { ok: true };
  }
  if (key === 'GET /api/lifetime') {
    requireUser();
    const products = Object.entries(state.lifetime || {}).map(([id, v]) => ({ id, name: CATALOGUE.find((c) => c.id === id)?.name || (id === 'sports' ? 'Sports betting' : id), ...v, net: v.returned - v.staked }));
    const staked = products.reduce((a, x) => a + x.staked, 0), returned = products.reduce((a, x) => a + x.returned, 0);
    return { products: products.sort((a, b) => b.staked - a.staked), staked, returned, net: returned - staked, since: state.profile?.createdAt };
  }

  if (key === 'PUT /api/settings') {
    const pr = requireUser();
    let limitResult = null;
    if (body?.dailyStakeLimit !== undefined) {
      const lim = body.dailyStakeLimit;
      if (lim !== null && (!Number.isSafeInteger(lim) || lim < RULES.minStake)) fail(400, `Daily limit must be at least ${fmt(RULES.minStake)}, or none.`);
      const cur = effectiveLimit(pr);
      if (lim !== null && (cur === null || lim <= cur)) {
        pr.dailyStakeLimit = lim; pr.pendingStakeLimit = null; pr.pendingLimitAt = null; limitResult = { applied: true };
        award([{ t: 'limit' }]);
      } else {
        pr.pendingStakeLimit = lim === null ? -1 : lim; pr.pendingLimitAt = now() + RULES.limitIncreaseCoolOffMs;
        limitResult = { applied: false, effectiveAt: pr.pendingLimitAt };
      }
    }
    if (body?.takeBreakHours !== undefined) {
      if (![24, 72, 168, 720].includes(body.takeBreakHours)) fail(400, 'Invalid break length.');
      pr.breakUntil = Math.max(pr.breakUntil || 0, now() + body.takeBreakHours * 3600000);
    }
    if (body?.realityCheckMinutes !== undefined) {
      if (![0, 15, 30, 45, 60, 90, 120].includes(body.realityCheckMinutes)) fail(400, 'Invalid reality-check interval.');
      pr.realityCheckMinutes = body.realityCheckMinutes;
    }
    save();
    return { user: publicUser(), limitResult };
  }
  fail(404, 'Not found');
}

async function request(method, path, body) {
  try {
    const out = structuredClone(await handle(method, path, body));
    if (unlockedQueue.length && out && typeof out === 'object') { out.unlocked = unlockedQueue; unlockedQueue = []; apiEvents.dispatchEvent(new CustomEvent('unlocked', { detail: out.unlocked })); }
    return out;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    console.error(e);
    throw new ApiError(500, { error: 'Something went wrong. Please try again.' });
  }
}

setInterval(() => { try { settle(); } catch (e) { console.error(e); } }, 3000);

export const api = {
  get: (p) => request('GET', p),
  post: (p, b = {}) => request('POST', p, b),
  put: (p, b = {}) => request('PUT', p, b),
  patch: (p, b = {}) => request('PATCH', p, b),
};
