// REAL fixtures for the standalone build. The page can't reach the
// internet itself, so fixtures and verified results are written into the
// artifact's shared `fixtures` collection (by Claude / a scheduled update)
// and read here. Scores are never invented: a result exists only once the
// data source has reported the match as final.
import { DEMO_LEAGUES } from '../../server/data/demo-teams.js';

const CAPS = { goalOrder: false, corners: false, liveCorners: false, cards: false, liveCards: false, halfTime: false };
const LEAGUES = {
  CL: ['Champions League', 'Europe'], PL: ['Premier League', 'England'], PD: ['La Liga', 'Spain'],
  SA: ['Serie A', 'Italy'], BL1: ['Bundesliga', 'Germany'], FL1: ['Ligue 1', 'France'], EL: ['Europa League', 'Europe'],
  ELC: ['Championship', 'England'], SPL: ['Scottish Premiership', 'Scotland'],
};
const PALETTE = ['#c8102e', '#034694', '#6cabdd', '#fdb913', '#241f20', '#670e36', '#0057b8', '#e30613', '#00a752', '#7a263a', '#1b458f', '#f37021'];

let docs = new Map();
let loaded = false;
let lastSnapshotAt = null;
const listeners = new Set();
export const onFixtures = (fn) => (listeners.add(fn), () => listeners.delete(fn));
export const fixturesLoaded = () => loaded;

const timeout = (ms) => new Promise((res) => setTimeout(res, ms));
export const fixturesReady = (async () => {
  try {
    const db = await Promise.race([window.claude?.use?.('db'), timeout(10000)]);
    if (!db) return;
    await Promise.race([
      new Promise((resolve) => {
        db.collection('fixtures').onSnapshot((snap) => {
          const next = new Map();
          for (const d of snap.docs) if (d.exists) next.set(d.id, d.data());
          docs = next;
          loaded = true;
          lastSnapshotAt = Date.now();
          listeners.forEach((fn) => fn());
          resolve();
        }, () => resolve());
      }),
      timeout(10000),
    ]);
  } catch (e) {
    console.warn('[virtualbet] fixtures unavailable', e);
  }
})();

export function cleanName(n = '') {
  const s = String(n)
    .replace(/^AFC /, '')
    .replace(/ (FC|AFC|CF|OSC)$/, '')
    .replace(/^(FC|SSC|ACF|US|CA|RC|SK|TSG|FSV|SC) /, '')
    .replace(/^Celta de Vigo$/, 'Celta Vigo')
    .trim();
  return s || n;
}
const display = cleanName;

const known = new Map(DEMO_LEAGUES.flatMap((l) => l.teams.map((t) => [t.name.toLowerCase(), t])));
function colorFor(name) {
  const t = known.get(name.toLowerCase());
  if (t) return t.color;
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return PALETTE[h % PALETTE.length];
}

// ── Fit expected goals to the data source's win probabilities ──
const fitCache = new Map();
function poisson(l, max = 10) {
  const out = []; let p = Math.exp(-l);
  for (let k = 0; k <= max; k++) { out.push(p); p *= l / (k + 1); }
  return out;
}
function probs(lh, la) {
  const a = poisson(lh), b = poisson(la);
  let h = 0, d = 0, w = 0;
  for (let i = 0; i < a.length; i++) for (let j = 0; j < b.length; j++) {
    const p = a[i] * b[j];
    if (i > j) h += p; else if (i === j) d += p; else w += p;
  }
  return [h, d, w];
}
export function fitLambdas(wp) {
  if (!wp || !(wp.home > 0) || !(wp.away > 0)) return { lambda_home: 1.42, lambda_away: 1.12 };
  const key = `${wp.home}|${wp.draw}|${wp.away}`;
  if (fitCache.has(key)) return fitCache.get(key);
  const sum = wp.home + (wp.draw || 0) + wp.away;
  const target = [wp.home / sum, (wp.draw || 0) / sum, wp.away / sum];
  let best = null;
  const err = (lh, la) => { const p = probs(lh, la); return (p[0] - target[0]) ** 2 + (p[1] - target[1]) ** 2 + (p[2] - target[2]) ** 2; };
  for (let lh = 0.2; lh <= 4.0; lh += 0.1) for (let la = 0.2; la <= 4.0; la += 0.1) {
    const e = err(lh, la);
    if (!best || e < best.e) best = { lh, la, e };
  }
  for (let lh = best.lh - 0.1; lh <= best.lh + 0.1; lh += 0.01) for (let la = best.la - 0.1; la <= best.la + 0.1; la += 0.01) {
    if (lh <= 0.05 || la <= 0.05) continue;
    const e = err(lh, la);
    if (e < best.e) best = { lh, la, e };
  }
  const out = { lambda_home: +best.lh.toFixed(3), lambda_away: +best.la.toFixed(3) };
  fitCache.set(key, out);
  return out;
}

function statusOf(f, kickoff, t) {
  switch (String(f.status || 'scheduled').toLowerCase()) {
    case 'final': case 'closed': case 'ended': case 'finished':
      return f.homeScore != null && f.awayScore != null ? 'FINISHED' : 'IN_PLAY_PENDING';
    case 'postponed': return 'POSTPONED';
    case 'cancelled': case 'canceled': case 'abandoned': return f.status.toLowerCase() === 'abandoned' ? 'ABANDONED' : 'CANCELLED';
    case 'live': case 'inprogress': case 'in_progress': return 'IN_PLAY_PENDING';
    default: return t < kickoff ? 'SCHEDULED' : 'IN_PLAY_PENDING';
  }
}

function rowFrom(id, f, t) {
  const kickoff = new Date(f.kickoff).getTime();
  if (!Number.isFinite(kickoff)) return null;
  const status = statusOf(f, kickoff, t);
  const [leagueName, country] = LEAGUES[f.league] || [f.leagueName || 'Football', f.country || ''];
  const home = display(f.home), away = display(f.away);
  const showScore = status === 'FINISHED' || (status === 'IN_PLAY_PENDING' && f.homeScore != null && String(f.status).toLowerCase() !== 'scheduled');
  return {
    id: `r${id}`, source: 'real', league_code: f.league, league_name: f.leagueName || leagueName, country: f.country || country,
    home_name: home, away_name: away, home_short: f.homeShort || home.slice(0, 3).toUpperCase(), away_short: f.awayShort || away.slice(0, 3).toUpperCase(),
    home_crest: null, away_crest: null, home_color: colorFor(home), away_color: colorFor(away),
    kickoff_at: kickoff, status, minute: status === 'FINISHED' ? 90 : null, minute_estimated: 0,
    home_score: showScore ? f.homeScore : null, away_score: showScore ? f.awayScore : null,
    ht_home: null, ht_away: null, home_corners: null, away_corners: null, home_cards: null, away_cards: null,
    goal_order: null, events: '[]', ...fitLambdas(f.winProb), caps: CAPS,
    result_verified: status === 'FINISHED' ? 1 : 0, finished_at: status === 'FINISHED' ? kickoff + 2 * 3600000 : null,
    suspended_until: null, last_sync_at: f.updatedAt ? new Date(f.updatedAt).getTime() : null,
  };
}

export function realRows(t = Date.now()) {
  const out = [];
  for (const [id, f] of docs) {
    const r = rowFrom(id, f, t);
    if (r) out.push(r);
  }
  return out.sort((a, b) => a.kickoff_at - b.kickoff_at || a.home_name.localeCompare(b.home_name));
}

export function realRowById(id, t = Date.now()) {
  const f = docs.get(String(id).replace(/^r/, ''));
  return f ? rowFrom(String(id).replace(/^r/, ''), f, t) : null;
}

export const lastFixturesSync = () => {
  let m = 0;
  for (const f of docs.values()) { const u = f.updatedAt ? new Date(f.updatedAt).getTime() : 0; if (u > m) m = u; }
  return m || lastSnapshotAt;
};
