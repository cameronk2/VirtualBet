// Persistence for the standalone build. Saves to the viewer's private
// space in the artifact database (data/users/<id>/...) so the wallet and
// bets follow the viewer across devices, with localStorage as a fallback.
import { isReturnTx, isStakeTx, productOf } from '../../server/achievements.js';

const LS_KEY = 'virtualbet_state_v1';
// Older saves have no running totals: rebuild them from the history we have
function rebuildLifetime(tx) {
  const l = {};
  for (const t of tx || []) {
    const ref = t.type.startsWith('BLACKJACK_') && /Spin 21/.test(t.note || '') ? 'spin21' : t.reference;
    const prod = productOf({ type: t.type, reference: ref });
    if (!prod) continue;
    const x = l[prod] || (l[prod] = { staked: 0, returned: 0 });
    if (isStakeTx(t.type)) x.staked -= t.amount;
    if (isReturnTx(t.type)) x.returned += t.amount;
  }
  return l;
}
const MAX_TX = 400;
const MAX_SETTLED_BETS = 250;
const DOC_LIMIT = 240 * 1024;

export const state = {
  profile: null,      // { username, createdAt, balance, ... }
  loggedIn: false,
  tx: [],             // newest first
  bets: [],           // newest first
  placements: [],     // [{ key, result }] recent idempotency keys
  seq: 1,
  blackjack: { hand: null, history: [] },
  spin21: { hand: null, history: [] },
  casino: {},
  progress: {},
  lifetime: {},
  slots: { free: null, history: [] },
};

let db = null;
let userId = null;
export let persistence = 'memory';

function lsRead() {
  try { return JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch { return null; }
}
function lsWrite(v) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(v)); } catch { /* ignore */ }
}

function apply(core, bets) {
  if (core) {
    state.profile = core.profile ?? null;
    state.loggedIn = !!core.loggedIn && !!core.profile;
    state.tx = core.tx || [];
    state.placements = core.placements || [];
    state.seq = core.seq || 1;
    state.blackjack = core.blackjack || { hand: null, history: [] };
    state.spin21 = core.spin21 || { hand: null, history: [] };
    state.casino = core.casino || {};
    state.progress = core.progress || {};
    state.lifetime = core.lifetime || rebuildLifetime(state.tx);
    state.slots = core.slots || { free: null, history: [] };
  }
  if (bets) state.bets = bets.bets || [];
}

const withTimeout = (p, ms) => Promise.race([p, new Promise((res) => setTimeout(() => res(null), ms))]);

export const ready = (async () => {
  try {
    const use = window.claude?.use;
    if (use) {
      const [d, u] = await withTimeout(Promise.all([use('db'), use('user')]), 10000) || [];
      const id = d && u ? await withTimeout(u.id(), 5000) : null;
      if (d && id) {
        db = d;
        userId = id;
        const [c, b] = await withTimeout(Promise.all([
          db.doc(`data/users/${id}/virtualbet_core`).get(),
          db.doc(`data/users/${id}/virtualbet_bets`).get(),
        ]), 10000) || [];
        if (c || b) {
          persistence = 'account';
          if (c?.exists) {
            apply(JSON.parse(c.data().json), b?.exists ? JSON.parse(b.data().json) : { bets: [] });
            return;
          }
        }
      }
    }
  } catch (e) {
    console.warn('[virtualbet] account storage unavailable', e);
  }
  const local = lsRead();
  if (local) apply(local.core, local.bets);
  if (persistence === 'memory') persistence = local !== null || canUseLocal() ? 'device' : 'memory';
})();

function canUseLocal() {
  try { localStorage.setItem('__vb', '1'); localStorage.removeItem('__vb'); return true; } catch { return false; }
}

function snapshot() {
  const open = state.bets.filter((b) => b.status === 'OPEN');
  let settled = state.bets.filter((b) => b.status !== 'OPEN').slice(0, MAX_SETTLED_BETS);
  let betsJson = JSON.stringify({ bets: [...open, ...settled].sort((a, b) => b.createdAt - a.createdAt) });
  while (betsJson.length > DOC_LIMIT && settled.length) {
    settled = settled.slice(0, Math.floor(settled.length * 0.8));
    betsJson = JSON.stringify({ bets: [...open, ...settled].sort((a, b) => b.createdAt - a.createdAt) });
  }
  const core = {
    profile: state.profile, loggedIn: state.loggedIn, seq: state.seq,
    tx: state.tx.slice(0, MAX_TX), placements: state.placements.slice(0, 30),
    blackjack: { hand: state.blackjack.hand, history: state.blackjack.history.slice(0, 20) },
    spin21: { hand: state.spin21.hand, history: state.spin21.history.slice(0, 20) },
    casino: state.casino, progress: state.progress, lifetime: state.lifetime,
    slots: { free: state.slots.free, history: state.slots.history.slice(0, 20) },
  };
  return { core, coreJson: JSON.stringify(core), betsJson };
}

// One write at a time per document, coalesced.
let timer = null;
let writing = false;
let dirty = false;
const last = { core: null, bets: null };

async function flush() {
  if (writing) { dirty = true; return; }
  writing = true;
  try {
    const { core, coreJson, betsJson } = snapshot();
    lsWrite({ core, bets: JSON.parse(betsJson) });
    if (db && userId) {
      if (coreJson !== last.core) {
        await db.doc(`data/users/${userId}/virtualbet_core`).set({ json: coreJson, savedAt: Date.now() });
        last.core = coreJson;
      }
      if (betsJson !== last.bets) {
        await db.doc(`data/users/${userId}/virtualbet_bets`).set({ json: betsJson, savedAt: Date.now() });
        last.bets = betsJson;
      }
    }
  } catch (e) {
    console.warn('[virtualbet] save failed', e);
  } finally {
    writing = false;
    if (dirty) { dirty = false; schedule(); }
  }
}

export function save() {
  schedule();
}
function schedule() {
  clearTimeout(timer);
  timer = setTimeout(flush, 600);
}
