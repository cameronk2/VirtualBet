// Same betting and wallet rules as server/config.js
export const RULES = {
  startingBalance: 10_000,
  minStake: 10,
  maxStake: 50_000,
  maxSelections: 20,
  depositPackages: [1_000, 2_000, 5_000, 10_000, 25_000, 50_000, 100_000], // quick picks
  depositMin: 500, // any whole-pound amount from £5
  depositMax: 100_000, // to £1,000
  depositStep: 100,
  dailyBonus: 500,
  dailyBonusIntervalMs: 24 * 60 * 60 * 1000,
  limitIncreaseCoolOffMs: 24 * 60 * 60 * 1000,
};
