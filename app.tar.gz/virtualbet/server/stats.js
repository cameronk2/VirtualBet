import { q } from './db.js';
import { now } from './util.js';

export function userStats(userId) {
  const bets = q('SELECT id, ref, type, stake, total_odds, status, actual_return, created_at, settled_at FROM bets WHERE user_id = ? ORDER BY created_at').all(userId);
  const settled = bets.filter((b) => b.status !== 'OPEN');
  const won = settled.filter((b) => b.status === 'WON');
  const lost = settled.filter((b) => b.status === 'LOST');
  const voided = settled.filter((b) => b.status === 'VOID');
  const staked = bets.reduce((a, b) => a + b.stake, 0);
  const settledStaked = settled.reduce((a, b) => a + b.stake, 0);
  const returned = settled.reduce((a, b) => a + (b.actual_return || 0), 0);
  const profit = returned - settledStaked;
  const decided = won.length + lost.length;

  const best = won.reduce((m, b) => (!m || b.actual_return - b.stake > m.actual_return - m.stake ? b : m), null);
  const worst = lost.reduce((m, b) => (!m || b.stake > m.stake ? b : m), null);

  // Cumulative P/L over time (by settlement)
  let run = 0;
  const series = settled
    .slice()
    .sort((a, b) => a.settled_at - b.settled_at)
    .map((b) => {
      run += (b.actual_return || 0) - b.stake;
      return { t: b.settled_at, pl: run };
    });

  // Performance by market: singles only (an accumulator can't be attributed to one market)
  const marketRows = q(`SELECT s.market_name AS name, s.market_key AS mkey, b.stake, b.status, b.actual_return
     FROM bets b JOIN bet_selections s ON s.bet_id = b.id
     WHERE b.user_id = ? AND b.type = 'SINGLE' AND b.status != 'OPEN'`).all(userId);
  const byMarket = new Map();
  for (const r of marketRows) {
    const name = /^NG\d+$/.test(r.mkey) ? 'Next Goal' : r.name;
    const m = byMarket.get(name) || { market: name, bets: 0, won: 0, staked: 0, returned: 0 };
    m.bets++;
    if (r.status === 'WON') m.won++;
    m.staked += r.stake;
    m.returned += r.actual_return || 0;
    byMarket.set(name, m);
  }
  const accas = settled.filter((b) => b.type === 'ACCA');
  if (accas.length) {
    byMarket.set('Accumulators', {
      market: 'Accumulators', bets: accas.length, won: accas.filter((b) => b.status === 'WON').length,
      staked: accas.reduce((a, b) => a + b.stake, 0), returned: accas.reduce((a, b) => a + (b.actual_return || 0), 0),
    });
  }
  const markets = [...byMarket.values()].map((m) => ({ ...m, profit: m.returned - m.staked })).sort((a, b) => b.profit - a.profit);

  const since = (ms) => {
    const s = settled.filter((b) => b.settled_at >= ms);
    return s.reduce((a, b) => a + (b.actual_return || 0) - b.stake, 0);
  };
  const midnight = new Date(); midnight.setHours(0, 0, 0, 0);

  return {
    totalBets: bets.length,
    openBets: bets.length - settled.length,
    won: won.length,
    lost: lost.length,
    void: voided.length,
    winRate: decided ? won.length / decided : null,
    staked,
    returned,
    profit,
    averageOdds: bets.length ? Math.round(bets.reduce((a, b) => a + b.total_odds, 0) / bets.length) : null,
    bestWin: best ? { ref: best.ref, stake: best.stake, return: best.actual_return, profit: best.actual_return - best.stake, odds: best.total_odds } : null,
    biggestLoss: worst ? { ref: worst.ref, stake: worst.stake, odds: worst.total_odds } : null,
    mostProfitableMarket: markets.length && markets[0].profit > 0 ? markets[0] : null,
    markets,
    series,
    profitToday: since(midnight.getTime()),
    profit7d: since(now() - 7 * 86400000),
  };
}

export function profitSince(userId, ms) {
  return q(`SELECT COALESCE(SUM(COALESCE(actual_return,0) - stake), 0) AS p, COUNT(*) AS n
            FROM bets WHERE user_id = ? AND status != 'OPEN' AND settled_at >= ?`).get(userId, ms);
}

export function leaderboard(currentUserId) {
  const users = q(`SELECT u.id, u.username,
      COALESCE(SUM(CASE WHEN b.status != 'OPEN' THEN COALESCE(b.actual_return,0) - b.stake END), 0) AS profit,
      COUNT(b.id) AS bets,
      SUM(b.status = 'WON') AS won, SUM(b.status = 'LOST') AS lost
    FROM users u LEFT JOIN bets b ON b.user_id = u.id GROUP BY u.id`).all();
  const demo = q('SELECT username, profit, bets, won FROM demo_leaders').all();
  const rows = [
    ...users.map((u) => ({
      username: u.username, profit: u.profit, bets: u.bets,
      winRate: (u.won || 0) + (u.lost || 0) ? (u.won || 0) / ((u.won || 0) + (u.lost || 0)) : null,
      demo: false, you: u.id === currentUserId,
    })),
    ...demo.map((d) => ({ username: d.username, profit: d.profit, bets: d.bets, winRate: d.bets ? d.won / d.bets : null, demo: true, you: false })),
  ];
  return rows.sort((a, b) => b.profit - a.profit).map((r, i) => ({ rank: i + 1, ...r }));
}
