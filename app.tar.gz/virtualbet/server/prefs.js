// Per-user preferences: favourite teams and notification settings.
import { q } from './db.js';
import { HttpError } from './util.js';

const MAX_FAVS = 20;

function row(userId) {
  return q('SELECT favourites, notify_settled FROM user_prefs WHERE user_id = ?').get(userId);
}

export function getPrefs(userId) {
  const r = row(userId);
  let favourites = [];
  try { favourites = JSON.parse(r?.favourites || '[]'); } catch { favourites = []; }
  return { favourites: Array.isArray(favourites) ? favourites : [], notifySettled: r ? !!r.notify_settled : true };
}

export function setFavourites(userId, teams) {
  if (!Array.isArray(teams)) throw new HttpError(400, 'Favourites must be a list of team names.');
  const clean = [...new Set(teams.map((t) => String(t ?? '').trim()).filter((t) => t && t.length <= 60))].slice(-MAX_FAVS);
  q(`INSERT INTO user_prefs (user_id, favourites) VALUES (?, ?)
     ON CONFLICT(user_id) DO UPDATE SET favourites = excluded.favourites`).run(userId, JSON.stringify(clean));
  return clean;
}

export function setNotifySettled(userId, on) {
  q(`INSERT INTO user_prefs (user_id, notify_settled) VALUES (?, ?)
     ON CONFLICT(user_id) DO UPDATE SET notify_settled = excluded.notify_settled`).run(userId, on ? 1 : 0);
}
