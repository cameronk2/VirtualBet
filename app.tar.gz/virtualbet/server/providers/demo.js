// ─────────────────────────────────────────────────────────────────
// DEMO MODE: clearly-labelled SIMULATED matches.
// Each match's full timeline is generated (seeded) when the fixture is
// created and revealed minute by minute as real time passes. Matches run
// accelerated (DEMO_SECONDS_PER_MINUTE real seconds per match minute).
// Future events are never sent to clients, and the odds engine does not
// look at them - it only knows the current score and minute.
// ─────────────────────────────────────────────────────────────────
import { q, tx } from '../db.js';
import { config } from '../config.js';
import { DEMO_LEAGUES } from '../data/demo-teams.js';
import { lambdasFor } from '../markets.js';
import { now } from '../util.js';
import { generateTimeline, stateAt as simStateAt, hashSeed, rng } from './sim.js';

const SLOT_MS = 5 * 60000;
const PER_SLOT = 2;
const AHEAD_MS = 3 * 3600000;
const CAPS = JSON.stringify({ goalOrder: true, corners: true, liveCorners: true, cards: true, liveCards: true });
const LEAGUE_WEIGHT = { PL: 3, CL: 2, ELC: 1.5 };

const teamIndex = new Map(DEMO_LEAGUES.flatMap((l) => l.teams.map((tm) => [tm.name, tm])));

function ensureSchedule() {
  const t = now();
  const last = q(`SELECT MAX(kickoff_at) AS k FROM matches WHERE source = 'demo'`).get().k;
  let slot = last ? last + SLOT_MS : Math.floor((t - 25 * 60000) / SLOT_MS) * SLOT_MS;
  if (slot < t - 25 * 60000) slot = Math.ceil(t / SLOT_MS) * SLOT_MS; // after long downtime, resume from now
  if (slot > t + AHEAD_MS) return 0;

  const busy = new Set(q(`SELECT home_name, away_name FROM matches WHERE source = 'demo'
      AND status IN ('SCHEDULED','LIVE_1H','HT','LIVE_2H','SUSPENDED')`).all().flatMap((r) => [r.home_name, r.away_name]));
  const pickR = rng(hashSeed(String(slot)));
  let created = 0;
  tx(() => {
    for (; slot <= t + AHEAD_MS; slot += SLOT_MS) {
      for (let i = 0; i < PER_SLOT; i++) {
        const leagues = DEMO_LEAGUES.map((l) => ({ l, free: l.teams.filter((tm) => !busy.has(tm.name)) })).filter((x) => x.free.length >= 2);
        if (!leagues.length) break;
        const total = leagues.reduce((a, x) => a + (LEAGUE_WEIGHT[x.l.code] || 1), 0);
        let roll = pickR() * total;
        const { l, free } = leagues.find((x) => (roll -= LEAGUE_WEIGHT[x.l.code] || 1) <= 0) || leagues[0];
        const home = free.splice(Math.floor(pickR() * free.length), 1)[0];
        const away = free[Math.floor(pickR() * free.length)];
        busy.add(home.name); busy.add(away.name);
        const id = `demo-${slot.toString(36)}-${i}`;
        const lam = lambdasFor(home.s, away.s);
        const sim = generateTimeline(hashSeed(id), lam.lambda_home, lam.lambda_away);
        q(`INSERT OR IGNORE INTO matches (id, source, league_code, league_name, country, home_name, away_name, home_short, away_short,
             home_color, away_color, kickoff_at, status, lambda_home, lambda_away, caps, sim, updated_at)
           VALUES (?, 'demo', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SCHEDULED', ?, ?, ?, ?, ?)`).run(
          id, l.code, l.name, l.country, home.name, away.name, home.short, away.short, home.color, away.color,
          slot, lam.lambda_home, lam.lambda_away, CAPS, JSON.stringify(sim), t);
        created++;
      }
    }
  });
  return created;
}

const FIELDS = ['status', 'minute', 'home_score', 'away_score', 'ht_home', 'ht_away', 'home_corners', 'away_corners',
  'home_cards', 'away_cards', 'goal_order', 'events', 'suspended_until', 'result_verified', 'finished_at'];

function tick() {
  const t = now();
  const rows = q(`SELECT * FROM matches WHERE source = 'demo' AND status IN ('SCHEDULED','LIVE_1H','HT','LIVE_2H') AND kickoff_at <= ?`).all(t);
  if (!rows.length) return;
  tx(() => {
    for (const row of rows) {
      const st = simStateAt(row.kickoff_at, JSON.parse(row.sim), t, config.demoSecondsPerMinute);
      if (st.status === 'SCHEDULED') continue;
      if (FIELDS.every((f) => row[f] === st[f])) continue;
      q(`UPDATE matches SET ${FIELDS.map((f) => `${f} = ?`).join(', ')}, updated_at = ? WHERE id = ?`)
        .run(...FIELDS.map((f) => st[f]), t, row.id);
    }
  });
}

function cleanup() {
  q(`DELETE FROM matches WHERE source = 'demo' AND status IN ('FINISHED','ABANDONED') AND kickoff_at < ?
     AND NOT EXISTS (SELECT 1 FROM bet_selections s WHERE s.match_id = matches.id)`).run(now() - 24 * 3600000);
}

export function startDemo() {
  ensureSchedule();
  tick();
  setInterval(() => { try { tick(); } catch (e) { console.error('[demo] tick failed', e); } }, 1000);
  setInterval(() => { try { ensureSchedule(); cleanup(); } catch (e) { console.error('[demo] schedule failed', e); } }, 30000);
  console.log(`[demo] Simulated matches enabled (1 match minute = ${config.demoSecondsPerMinute}s)`);
}

export const demoTeamStrength = (name) => teamIndex.get(name)?.s;
