// Pure, deterministic match simulation shared by the server (demo mode)
// and the standalone in-browser build. No Node-only imports here.
export const HT_REAL_MS = 60000;
export const SUSPEND_AFTER_GOAL_MS = 15000;
const ABANDON_CHANCE = 0.02;

/** Deterministic PRNG (mulberry32). */
export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619);
  return h >>> 0;
}

export function generateTimeline(seed, lh, la) {
  const r = rng(seed);
  const st1 = 1 + Math.floor(r() * 4);
  const st2 = 2 + Math.floor(r() * 5);
  const share = lh / (lh + la);
  const corners = [10.2 * (0.35 + 0.3 * share), 0];
  corners[1] = 10.2 - corners[0];
  const cards = [4 * (0.55 - 0.1 * share), 0];
  cards[1] = 4 - cards[0];
  const events = [];
  const halves = [[1, 1, 45 + st1], [2, 46, 90 + st2]];
  for (const [half, from, to] of halves) {
    for (let minute = from; minute <= to; minute++) {
      [lh, la].forEach((l, i) => {
        const team = i === 0 ? '1' : '2';
        if (r() < l / 93) events.push({ half, minute, type: 'goal', team });
        if (r() < corners[i] / 93) events.push({ half, minute, type: 'corner', team });
        if (r() < cards[i] / 93) events.push({ half, minute, type: 'card', team });
      });
    }
  }
  let abandon = null;
  if (r() < ABANDON_CHANCE) {
    const half = r() < 0.5 ? 1 : 2;
    abandon = { half, minute: half === 1 ? 10 + Math.floor(r() * 30) : 50 + Math.floor(r() * 35) };
  }
  return { st1, st2, events, abandon };
}

/** Pure function: match state at time t from its timeline. */
export function stateAt(kickoff, sim, t, secondsPerMinute = 8) {
  const S = secondsPerMinute * 1000;
  const end1 = kickoff + (45 + sim.st1) * S;
  const start2 = end1 + HT_REAL_MS;
  const end2 = start2 + (45 + sim.st2) * S;
  const revealAt = (e) => (e.half === 1 ? kickoff + (e.minute - 1) * S : start2 + (e.minute - 46) * S) + S / 2;

  if (t < kickoff) return { status: 'SCHEDULED', minute: null };
  let status, minute;
  if (t < end1) { status = 'LIVE_1H'; minute = Math.floor((t - kickoff) / S) + 1; }
  else if (t < start2) { status = 'HT'; minute = 45; }
  else if (t < end2) { status = 'LIVE_2H'; minute = 46 + Math.floor((t - start2) / S); }
  else { status = 'FINISHED'; minute = 90; }

  let cutoff = t;
  if (sim.abandon && revealAt(sim.abandon) <= t) {
    status = 'ABANDONED';
    cutoff = revealAt(sim.abandon);
    minute = sim.abandon.minute;
  }
  const seen = sim.events.filter((e) => revealAt(e) <= cutoff);
  const score = [0, 0], corners = [0, 0], cards = [0, 0], order = [];
  let lastGoalAt = 0;
  const events = [];
  for (const e of seen) {
    const i = e.team === '1' ? 0 : 1;
    if (e.type === 'goal') { score[i]++; order.push(e.team); lastGoalAt = Math.max(lastGoalAt, revealAt(e)); }
    if (e.type === 'corner') corners[i]++;
    if (e.type === 'card') cards[i]++;
    if (e.type !== 'corner') {
      events.push({
        minute: e.minute, half: e.half, type: e.type, team: e.team,
        label: e.half === 1 && e.minute > 45 ? `45+${e.minute - 45}'` : e.half === 2 && e.minute > 90 ? `90+${e.minute - 90}'` : `${e.minute}'`,
        score: e.type === 'goal' ? `${score[0]}-${score[1]}` : undefined,
      });
    }
  }
  const firstHalfDone = t >= end1 && !(sim.abandon?.half === 1 && status === 'ABANDONED');
  const ht = firstHalfDone
    ? sim.events.filter((e) => e.half === 1 && e.type === 'goal').reduce((a, e) => (a[e.team === '1' ? 0 : 1]++, a), [0, 0])
    : null;
  return {
    status, minute,
    home_score: score[0], away_score: score[1],
    ht_home: ht ? ht[0] : null, ht_away: ht ? ht[1] : null,
    home_corners: corners[0], away_corners: corners[1],
    home_cards: cards[0], away_cards: cards[1],
    goal_order: JSON.stringify(order),
    events: JSON.stringify(events.reverse()),
    suspended_until: lastGoalAt ? lastGoalAt + SUSPEND_AFTER_GOAL_MS : null,
    result_verified: status === 'FINISHED' ? 1 : 0,
    finished_at: status === 'FINISHED' ? end2 : status === 'ABANDONED' ? cutoff : null,
  };
}

