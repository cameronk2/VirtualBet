// ─────────────────────────────────────────────────────────────────
// REAL football data adapters (configurable via .env):
//   api-football   https://www.api-football.com  (api-sports.io v3)
//   football-data  https://www.football-data.org (v4)
// Scores and statuses come only from the provider - nothing is invented.
// A result is marked verified only when the provider reports the match
// as finished with a full-time score.
// ─────────────────────────────────────────────────────────────────
import { q, tx } from '../db.js';
import { config } from '../config.js';
import { lambdasFor } from '../markets.js';
import { demoTeamStrength } from './demo.js';
import { now } from '../util.js';

export const providerStatus = { provider: config.provider, lastSuccessAt: null, lastError: null, lastErrorAt: null, requests: 0 };

const LIVE_DB_STATUSES = `('LIVE_1H','HT','LIVE_2H','SUSPENDED')`;

async function getJson(url, headers) {
  providerStatus.requests++;
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(20000) });
  const text = await res.text();
  let body;
  try { body = JSON.parse(text); } catch { throw new Error(`Non-JSON response (${res.status})`); }
  if (!res.ok) throw new Error(body?.message || `HTTP ${res.status}`);
  return body;
}

const ymd = (d) => d.toISOString().slice(0, 10);

function upsert(m) {
  const t = now();
  const existing = q('SELECT id, status, finished_at FROM matches WHERE id = ?').get(m.id);
  if (!existing) {
    const lam = lambdasFor(demoTeamStrength(m.home_name) ?? 0, demoTeamStrength(m.away_name) ?? 0);
    q(`INSERT INTO matches (id, source, league_code, league_name, country, home_name, away_name, home_short, away_short,
         home_crest, away_crest, kickoff_at, status, lambda_home, lambda_away, caps, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(m.id, m.source, m.league_code, m.league_name, m.country ?? null,
      m.home_name, m.away_name, m.home_short ?? null, m.away_short ?? null, m.home_crest ?? null, m.away_crest ?? null,
      m.kickoff_at, m.status, lam.lambda_home, lam.lambda_away, JSON.stringify(m.caps), t);
  }
  const fields = ['kickoff_at', 'status', 'minute', 'minute_estimated', 'home_score', 'away_score', 'ht_home', 'ht_away',
    'home_corners', 'away_corners', 'home_cards', 'away_cards', 'goal_order', 'events', 'result_verified', 'home_crest', 'away_crest'];
  const set = fields.filter((f) => m[f] !== undefined);
  const finishedAt = m.status === 'FINISHED' && !existing?.finished_at ? t : existing?.finished_at ?? null;
  q(`UPDATE matches SET ${set.map((f) => `${f} = ?`).join(', ')}, finished_at = ?, last_sync_at = ?, updated_at = ? WHERE id = ?`)
    .run(...set.map((f) => (typeof m[f] === 'boolean' ? Number(m[f]) : m[f])), finishedAt, t, t, m.id);
}

// ── API-Football ────────────────────────────────────────────────
const AF_LEAGUES = {
  39: 'PL', 40: 'ELC', 41: 'EL1', 42: 'EL2', 179: 'SPL', 2: 'CL', 3: 'EL', 848: 'ECL', 140: 'PD', 135: 'SA', 78: 'BL1',
  61: 'FL1', 45: 'FAC', 48: 'EFL', 88: 'DED', 94: 'PPL',
};
const AF_CAPS = { goalOrder: true, corners: true, liveCorners: false, cards: true, liveCards: true };

const af = (path) => getJson(`https://v3.football.api-sports.io${path}`, { 'x-apisports-key': config.apiFootballKey })
  .then((b) => {
    if (b.errors && (Array.isArray(b.errors) ? b.errors.length : Object.keys(b.errors).length)) {
      throw new Error(Object.values(b.errors).join('; '));
    }
    return b.response || [];
  });

function afStatus(short, elapsed) {
  switch (short) {
    case 'TBD': case 'NS': return 'SCHEDULED';
    case '1H': return 'LIVE_1H';
    case 'HT': return 'HT';
    case '2H': return 'LIVE_2H';
    case 'LIVE': return (elapsed ?? 0) > 45 ? 'LIVE_2H' : 'LIVE_1H';
    case 'ET': case 'BT': case 'P': case 'FT': case 'AET': case 'PEN': return 'FINISHED'; // markets settle on 90 minutes
    case 'SUSP': case 'INT': return 'SUSPENDED';
    case 'PST': return 'POSTPONED';
    case 'CANC': case 'AWD': case 'WO': return 'CANCELLED';
    case 'ABD': return 'ABANDONED';
    default: return 'SCHEDULED';
  }
}

function afGoalOrder(events, homeId, totals) {
  const goals = events
    .filter((e) => e.type === 'Goal' && e.detail !== 'Missed Penalty' && (e.time?.elapsed ?? 0) <= 90)
    .sort((a, b) => a.time.elapsed - b.time.elapsed || (a.time.extra || 0) - (b.time.extra || 0));
  const candidates = [
    goals.map((e) => (e.team?.id === homeId ? '1' : '2')),
    goals.map((e) => {
      const side = e.team?.id === homeId ? '1' : '2';
      return e.detail === 'Own Goal' ? (side === '1' ? '2' : '1') : side;
    }),
  ];
  // Only trust the order if it matches the official score exactly.
  return candidates.find((o) => o.filter((x) => x === '1').length === totals[0] && o.filter((x) => x === '2').length === totals[1]) || null;
}

function afMap(f) {
  const fx = f.fixture, home = f.teams.home, away = f.teams.away;
  const status = afStatus(fx.status.short, fx.status.elapsed);
  const live = ['LIVE_1H', 'HT', 'LIVE_2H', 'SUSPENDED'].includes(status);
  const m = {
    id: `af-${fx.id}`, source: 'api-football', caps: AF_CAPS,
    league_code: AF_LEAGUES[f.league.id] || `AF${f.league.id}`, league_name: f.league.name, country: f.league.country,
    home_name: home.name, away_name: away.name, home_crest: home.logo, away_crest: away.logo,
    home_short: home.name.slice(0, 3).toUpperCase(), away_short: away.name.slice(0, 3).toUpperCase(),
    kickoff_at: new Date(fx.date).getTime(), status,
    minute: live ? fx.status.elapsed ?? null : status === 'FINISHED' ? 90 : null,
    minute_estimated: 0,
    ht_home: f.score?.halftime?.home ?? null, ht_away: f.score?.halftime?.away ?? null,
  };
  if (status === 'FINISHED') {
    // Use the 90-minute score; for ET/penalty games the full-time field holds it.
    const ft = f.score?.fulltime;
    const ok = ft && ft.home != null && ft.away != null;
    m.home_score = ok ? ft.home : f.goals.home;
    m.away_score = ok ? ft.away : f.goals.away;
    m.result_verified = ok ? 1 : 0;
  } else {
    m.home_score = f.goals.home;
    m.away_score = f.goals.away;
    m.result_verified = 0;
  }
  if (Array.isArray(f.events)) {
    const totals = [m.home_score ?? 0, m.away_score ?? 0];
    const order = afGoalOrder(f.events, home.id, totals);
    m.goal_order = order ? JSON.stringify(order) : null;
    const cards = f.events.filter((e) => e.type === 'Card' && (e.time?.elapsed ?? 0) <= 90);
    m.home_cards = cards.filter((e) => e.team?.id === home.id).length;
    m.away_cards = cards.filter((e) => e.team?.id === away.id).length;
    m.events = JSON.stringify(f.events.filter((e) => e.type === 'Goal' || e.type === 'Card').map((e) => ({
      type: e.type === 'Goal' ? 'goal' : 'card', team: e.team?.id === home.id ? '1' : '2', player: e.player?.name || null,
      detail: e.detail, minute: e.time.elapsed, label: `${e.time.elapsed}${e.time.extra ? `+${e.time.extra}` : ''}'`,
    })).reverse());
  }
  // Corners only from the full statistics, and only for 90-minute games
  if (status === 'FINISHED' && fx.status.short === 'FT' && Array.isArray(f.statistics) && f.statistics.length === 2) {
    const corners = (teamId) => {
      const s = f.statistics.find((x) => x.team?.id === teamId)?.statistics?.find((x) => x.type === 'Corner Kicks');
      return s ? Number(s.value ?? 0) : null;
    };
    m.home_corners = corners(home.id);
    m.away_corners = corners(away.id);
  }
  return m;
}

async function afFixtures() {
  const wanted = new Set(config.apiFootballLeagues);
  for (let d = 0; d < config.fixtureDaysAhead; d++) {
    const date = ymd(new Date(Date.now() + d * 86400000));
    const list = await af(`/fixtures?date=${date}&timezone=UTC`);
    tx(() => list.filter((f) => wanted.has(f.league.id)).forEach((f) => upsert(afMap(f))));
  }
}

async function afLive() {
  const ids = config.apiFootballLeagues.join('-');
  const live = await af(`/fixtures?live=${ids}`);
  tx(() => live.forEach((f) => upsert(afMap(f))));
  // Matches we think are live/started but which are no longer in the live feed,
  // plus finished games still missing detail: fetch them by id (max 20 per call).
  const liveIds = new Set(live.map((f) => `af-${f.fixture.id}`));
  const stale = q(`SELECT id FROM matches WHERE source = 'api-football' AND (
      (status IN ${LIVE_DB_STATUSES}) OR (status = 'SCHEDULED' AND kickoff_at < ?)
      OR (status = 'FINISHED' AND (result_verified = 0 OR home_corners IS NULL OR goal_order IS NULL) AND finished_at > ?))
    ORDER BY kickoff_at DESC LIMIT 40`).all(now() - 15 * 60000, now() - 6 * 3600000)
    .map((r) => r.id).filter((id) => !liveIds.has(id));
  for (let i = 0; i < stale.length; i += 20) {
    const chunk = stale.slice(i, i + 20).map((id) => id.slice(3));
    const full = await af(`/fixtures?ids=${chunk.join('-')}`);
    tx(() => full.forEach((f) => upsert(afMap(f))));
  }
}

// ── football-data.org ───────────────────────────────────────────
const FD_CAPS = { goalOrder: false, corners: false, liveCorners: false, cards: false, liveCards: false };
const fd = (path) => getJson(`https://api.football-data.org/v4${path}`, { 'X-Auth-Token': config.footballDataKey });

function fdStatus(m) {
  switch (m.status) {
    case 'SCHEDULED': case 'TIMED': return 'SCHEDULED';
    case 'IN_PLAY': {
      if (m.minute != null) return Number(m.minute) > 45 && m.score?.halfTime?.home != null ? 'LIVE_2H' : 'LIVE_1H';
      return (Date.now() - new Date(m.utcDate).getTime()) / 60000 > 50 ? 'LIVE_2H' : 'LIVE_1H';
    }
    case 'PAUSED': return 'HT';
    case 'FINISHED': return 'FINISHED';
    case 'SUSPENDED': return 'SUSPENDED';
    case 'POSTPONED': return 'POSTPONED';
    case 'CANCELLED': case 'AWARDED': return 'CANCELLED';
    default: return 'SCHEDULED';
  }
}

function fdMap(x) {
  const status = fdStatus(x);
  const kickoff = new Date(x.utcDate).getTime();
  let minute = null, estimated = 0;
  if (status === 'LIVE_1H' || status === 'LIVE_2H' || status === 'SUSPENDED') {
    if (x.minute != null) minute = Number(x.minute);
    else {
      // The free tier may omit the minute: estimate from kick-off time and label it "(est.)"
      const e = Math.floor((Date.now() - kickoff) / 60000);
      minute = status === 'LIVE_1H' ? Math.min(45, Math.max(1, e)) : Math.min(90, Math.max(46, e - 15));
      estimated = 1;
    }
  }
  const sc = x.score || {};
  const regular = sc.duration && sc.duration !== 'REGULAR' ? sc.regularTime : sc.fullTime;
  const m = {
    id: `fd-${x.id}`, source: 'football-data', caps: FD_CAPS,
    league_code: x.competition?.code || 'FD', league_name: x.competition?.name || 'Football', country: x.area?.name,
    home_name: x.homeTeam?.shortName || x.homeTeam?.name || 'TBC', away_name: x.awayTeam?.shortName || x.awayTeam?.name || 'TBC',
    home_short: x.homeTeam?.tla, away_short: x.awayTeam?.tla, home_crest: x.homeTeam?.crest, away_crest: x.awayTeam?.crest,
    kickoff_at: kickoff, status, minute: status === 'HT' ? 45 : status === 'FINISHED' ? 90 : minute, minute_estimated: estimated,
    home_score: (status === 'FINISHED' ? regular?.home : sc.fullTime?.home) ?? null,
    away_score: (status === 'FINISHED' ? regular?.away : sc.fullTime?.away) ?? null,
    ht_home: sc.halfTime?.home ?? null, ht_away: sc.halfTime?.away ?? null,
  };
  m.result_verified = status === 'FINISHED' && m.home_score != null && m.away_score != null ? 1 : 0;
  return m;
}

async function fdRange(from, to) {
  const comps = config.footballDataCompetitions.join(',');
  const body = await fd(`/matches?competitions=${comps}&dateFrom=${ymd(from)}&dateTo=${ymd(to)}`);
  tx(() => (body.matches || []).forEach((x) => upsert(fdMap(x))));
}
const fdFixtures = () => fdRange(new Date(), new Date(Date.now() + (config.fixtureDaysAhead - 1) * 86400000));
const fdLive = () => fdRange(new Date(Date.now() - 86400000), new Date());

// ── Poll loop ───────────────────────────────────────────────────
async function run(label, fn) {
  try {
    await fn();
    providerStatus.lastSuccessAt = now();
  } catch (e) {
    providerStatus.lastError = `${label}: ${e.message}`;
    providerStatus.lastErrorAt = now();
    console.error(`[${config.provider}] ${label} failed: ${e.message}`);
  }
}

export function startLiveData() {
  if (config.provider === 'none') return;
  const key = config.provider === 'api-football' ? config.apiFootballKey : config.footballDataKey;
  if (!key) {
    providerStatus.lastError = `No API key set for ${config.provider}. Add it to .env.`;
    console.warn(`[live] ${providerStatus.lastError}`);
    return;
  }
  const fixtures = config.provider === 'api-football' ? afFixtures : fdFixtures;
  const live = config.provider === 'api-football' ? afLive : fdLive;
  const needsLivePoll = () => !!q(`SELECT 1 FROM matches WHERE source = ? AND (status IN ${LIVE_DB_STATUSES}
      OR (status = 'SCHEDULED' AND kickoff_at BETWEEN ? AND ?)
      OR (status = 'FINISHED' AND result_verified = 0 AND finished_at > ?)) LIMIT 1`)
    .get(config.provider, now() - 3 * 3600000, now() + 5 * 60000, now() - 6 * 3600000);

  (async () => {
    await run('fixtures', fixtures);
    await run('live', live);
  })();
  setInterval(() => run('fixtures', fixtures), config.fixturesPollMinutes * 60000);
  // Only spend API requests on live polling when something is (or should be) in play.
  setInterval(() => { if (needsLivePoll()) run('live', live); }, config.livePollSeconds * 1000);
  console.log(`[live] Real football data from ${config.provider} (live every ${config.livePollSeconds}s, fixtures every ${config.fixturesPollMinutes}m)`);
}
