import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  balance INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
  created_at INTEGER NOT NULL,
  last_daily_bonus_at INTEGER,
  daily_stake_limit INTEGER,
  pending_stake_limit INTEGER,
  pending_limit_at INTEGER,
  reality_check_minutes INTEGER NOT NULL DEFAULT 60
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS wallet_tx (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  amount INTEGER NOT NULL,
  balance_before INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  reference TEXT,
  note TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS wallet_tx_user ON wallet_tx(user_id, id DESC);

CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY,
  source TEXT NOT NULL,              -- demo | api-football | football-data
  league_code TEXT NOT NULL,
  league_name TEXT NOT NULL,
  country TEXT,
  home_name TEXT NOT NULL,
  away_name TEXT NOT NULL,
  home_short TEXT,
  away_short TEXT,
  home_crest TEXT,
  away_crest TEXT,
  home_color TEXT,
  away_color TEXT,
  kickoff_at INTEGER NOT NULL,
  status TEXT NOT NULL,              -- SCHEDULED | LIVE_1H | HT | LIVE_2H | FINISHED | ABANDONED | CANCELLED | POSTPONED | SUSPENDED
  minute INTEGER,
  minute_estimated INTEGER NOT NULL DEFAULT 0,
  home_score INTEGER,
  away_score INTEGER,
  ht_home INTEGER,
  ht_away INTEGER,
  home_corners INTEGER,
  away_corners INTEGER,
  home_cards INTEGER,
  away_cards INTEGER,
  goal_order TEXT,                   -- JSON array of '1'/'2' in scoring order, null when unknown
  lambda_home REAL NOT NULL,
  lambda_away REAL NOT NULL,
  caps TEXT NOT NULL,                -- JSON capabilities of the data source
  result_verified INTEGER NOT NULL DEFAULT 0,
  finished_at INTEGER,
  suspended_until INTEGER,
  events TEXT,                       -- JSON list of events that have happened so far
  sim TEXT,                          -- demo only: pre-generated timeline (never sent to clients)
  last_sync_at INTEGER,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS matches_kickoff ON matches(kickoff_at);
CREATE INDEX IF NOT EXISTS matches_status ON matches(status);

CREATE TABLE IF NOT EXISTS placements (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  idem_key TEXT NOT NULL,
  result TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, idem_key)
);

CREATE TABLE IF NOT EXISTS bets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,                -- SINGLE | ACCA
  stake INTEGER NOT NULL CHECK (stake > 0),
  total_odds INTEGER NOT NULL,       -- combined odds x100 (display, rounded)
  potential_return INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'OPEN', -- OPEN | WON | LOST | VOID
  actual_return INTEGER,
  created_at INTEGER NOT NULL,
  settled_at INTEGER
);
CREATE INDEX IF NOT EXISTS bets_user ON bets(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS bets_status ON bets(status);

CREATE TABLE IF NOT EXISTS bet_selections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bet_id INTEGER NOT NULL REFERENCES bets(id) ON DELETE CASCADE,
  match_id TEXT NOT NULL REFERENCES matches(id),
  match_label TEXT NOT NULL,
  league_name TEXT,
  market_key TEXT NOT NULL,
  market_name TEXT NOT NULL,
  selection_key TEXT NOT NULL,
  selection_label TEXT NOT NULL,
  odds INTEGER NOT NULL,             -- decimal odds x100
  in_play INTEGER NOT NULL DEFAULT 0,
  score_at_placement TEXT,
  minute_at_placement INTEGER,
  status TEXT NOT NULL DEFAULT 'OPEN',
  void_reason TEXT,
  settled_at INTEGER
);
CREATE INDEX IF NOT EXISTS sel_bet ON bet_selections(bet_id);
CREATE INDEX IF NOT EXISTS sel_match ON bet_selections(match_id, status);

CREATE TABLE IF NOT EXISTS blackjack (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  hand TEXT,
  history TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS spin21 (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  hand TEXT,
  history TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS slots (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  free TEXT,
  history TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS casino_state (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game TEXT NOT NULL,
  state TEXT NOT NULL,
  history TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY (user_id, game)
);

CREATE TABLE IF NOT EXISTS progress (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  data TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_prefs (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  favourites TEXT NOT NULL DEFAULT '[]',
  notify_settled INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS push_subs (
  endpoint TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS push_subs_user ON push_subs(user_id);

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS demo_leaders (
  username TEXT PRIMARY KEY,
  profit INTEGER NOT NULL,
  bets INTEGER NOT NULL,
  won INTEGER NOT NULL
);
`;

let db;
const stmtCache = new Map();

export function openDb(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  try { db.exec('ALTER TABLE users ADD COLUMN break_until INTEGER'); } catch { /* already added */ }
  seedDemoLeaders();
  return db;
}

export function getDb() {
  return db;
}

/** Cached prepared statement. */
export function q(sql) {
  let s = stmtCache.get(sql);
  if (!s) {
    s = db.prepare(sql);
    stmtCache.set(sql, s);
  }
  return s;
}

let inTx = false;
/** Run fn inside a single IMMEDIATE transaction (all-or-nothing). */
export function tx(fn) {
  if (inTx) return fn();
  db.exec('BEGIN IMMEDIATE');
  inTx = true;
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    inTx = false;
  }
}

function seedDemoLeaders() {
  const count = db.prepare('SELECT COUNT(*) AS n FROM demo_leaders').get().n;
  if (count) return;
  const rows = [
    ['DemoAce_Liam', 18450, 212, 101], ['DemoPunter_Sophie', 12210, 145, 66],
    ['DemoTipster_Raj', 7640, 301, 128], ['DemoOddsOn_Mia', 3120, 88, 47],
    ['DemoAccaKing_Tom', -2450, 176, 52], ['DemoValue_Ella', 950, 64, 30],
    ['DemoUnder25_Jack', -6830, 240, 96], ['DemoBTTS_Zara', -11200, 133, 41],
  ];
  const ins = db.prepare('INSERT INTO demo_leaders (username, profit, bets, won) VALUES (?, ?, ?, ?)');
  for (const r of rows) ins.run(...r);
}
