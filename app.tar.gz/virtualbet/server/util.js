import crypto from 'node:crypto';
import zlib from 'node:zlib';

export class HttpError extends Error {
  constructor(status, message, extra) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

export const now = () => Date.now();

export function sendJson(res, status, body, headers = {}) {
  let data = JSON.stringify(body);
  const extra = {};
  // Compress larger responses (match lists) - much faster on mobile data
  if (data.length > 1400 && /\bgzip\b/.test(res.req?.headers['accept-encoding'] || '')) {
    data = zlib.gzipSync(data, { level: 5 });
    extra['Content-Encoding'] = 'gzip';
    extra.Vary = 'Accept-Encoding';
  }
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...extra,
    ...headers,
  });
  res.end(data);
}

export async function readJson(req, limit = 64 * 1024) {
  const type = req.headers['content-type'] || '';
  // Requiring JSON blocks cross-site form posts (CSRF) because browsers
  // cannot send application/json cross-origin without a CORS preflight.
  if (!type.toLowerCase().startsWith('application/json')) {
    throw new HttpError(415, 'Requests must be sent as JSON.');
  }
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new HttpError(413, 'Request body too large.');
    chunks.push(c);
  }
  if (!size) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'Invalid JSON body.');
  }
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function randomCode(len) {
  const bytes = crypto.randomBytes(len);
  let s = '';
  for (let i = 0; i < len; i++) s += REF_ALPHABET[bytes[i] % REF_ALPHABET.length];
  return s;
}

export const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

/** Deterministic PRNG (mulberry32) for reproducible demo simulations. */
export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const isInt = (v) => Number.isSafeInteger(v);
