import { q } from './db.js';
import { config } from './config.js';
import { serializeMatch } from './serialize.js';
import { now } from './util.js';

const COLS = `id, source, league_code, league_name, country, home_name, away_name, home_short, away_short,
  home_crest, away_crest, home_color, away_color, kickoff_at, status, minute, minute_estimated, home_score, away_score,
  ht_home, ht_away, home_corners, away_corners, home_cards, away_cards, goal_order, lambda_home, lambda_away, caps,
  result_verified, finished_at, suspended_until, events, last_sync_at, updated_at`;

const LEAGUE_ORDER = ['CL', 'PL', 'EL', 'ECL', 'PD', 'SA', 'BL1', 'FL1', 'ELC', 'SPL', 'EL1', 'EL2', 'FAC', 'EFL', 'DED', 'PPL'];
const leagueRank = (code) => {
  const i = LEAGUE_ORDER.indexOf(code);
  return i < 0 ? 99 : i;
};

function visibleSourceClause() {
  const sources = [];
  if (config.demoEnabled) sources.push("'demo'");
  if (config.provider !== 'none') sources.push(`'${config.provider}'`);
  return sources.length ? `source IN (${sources.join(',')})` : '0';
}

export function listMatches({ view = 'all', league = null } = {}) {
  const t = now();
  const where = [visibleSourceClause()];
  const params = [];
  if (view === 'live') where.push(`status IN ('LIVE_1H','HT','LIVE_2H','SUSPENDED')`);
  else if (view === 'upcoming') { where.push(`status = 'SCHEDULED' AND kickoff_at > ?`); params.push(t - 5 * 60000); }
  else if (view === 'results') { where.push(`status IN ('FINISHED','ABANDONED','CANCELLED') AND kickoff_at > ?`); params.push(t - 2 * 86400000); }
  else {
    where.push('kickoff_at BETWEEN ? AND ?');
    params.push(t - 6 * 3600000, t + config.fixtureDaysAhead * 86400000);
  }
  if (league) { where.push('league_code = ?'); params.push(league); }
  const order = view === 'results' ? 'kickoff_at DESC' : 'kickoff_at ASC';
  const rows = q(`SELECT ${COLS} FROM matches WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT 300`).all(...params);
  return rows.map((r) => serializeMatch(r));
}

export function getMatchRow(id) {
  return q(`SELECT ${COLS} FROM matches WHERE id = ?`).get(id);
}

export function getMatch(id) {
  const row = getMatchRow(id);
  return row ? serializeMatch(row, { full: true }) : null;
}

export function listLeagues() {
  const t = now();
  const rows = q(`SELECT league_code AS code, league_name AS name, country,
      SUM(status IN ('LIVE_1H','HT','LIVE_2H','SUSPENDED')) AS live,
      SUM(status = 'SCHEDULED') AS upcoming
    FROM matches WHERE ${visibleSourceClause()} AND kickoff_at BETWEEN ? AND ?
    GROUP BY league_code, league_name, country`).all(t - 6 * 3600000, t + config.fixtureDaysAhead * 86400000);
  return rows.sort((a, b) => leagueRank(a.code) - leagueRank(b.code) || a.name.localeCompare(b.name));
}

export function featuredMatches() {
  const all = listMatches({ view: 'all' }).filter((m) => m.bettingOpen);
  return all
    .sort((a, b) => (b.live - a.live) || leagueRank(a.league.code) - leagueRank(b.league.code) || a.kickoff - b.kickoff)
    .slice(0, 6);
}
