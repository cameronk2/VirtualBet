import crypto from 'node:crypto';
import { q, tx } from './db.js';
import { config, RULES } from './config.js';
import { HttpError, now, parseCookies, sha256 } from './util.js';
import { credit } from './wallet.js';

const COOKIE = 'vb_session';
const USERNAME_RE = /^[A-Za-z0-9_]{3,20}$/;

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  const [alg, saltHex, hashHex] = String(stored).split('$');
  if (alg !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(expected, actual);
}

export function validateUsername(username) {
  if (typeof username !== 'string' || !USERNAME_RE.test(username)) {
    throw new HttpError(400, 'Username must be 3–20 characters: letters, numbers or underscores.');
  }
  if (/^demo/i.test(username)) throw new HttpError(400, 'Usernames starting with "demo" are reserved.');
}

function validatePassword(password) {
  if (typeof password !== 'string' || password.length < 8 || password.length > 200) {
    throw new HttpError(400, 'Password must be at least 8 characters.');
  }
}

// Simple in-memory brute-force protection
const attempts = new Map();
function checkRate(key) {
  const t = now();
  const rec = attempts.get(key) || { n: 0, reset: t + 15 * 60 * 1000 };
  if (t > rec.reset) { rec.n = 0; rec.reset = t + 15 * 60 * 1000; }
  rec.n++;
  attempts.set(key, rec);
  if (rec.n > 10) throw new HttpError(429, 'Too many attempts. Please wait 15 minutes and try again.');
}

function createSession(res, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const t = now();
  const expires = t + config.sessionDays * 86400000;
  q('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)').run(sha256(token), userId, t, expires);
  const parts = [`${COOKIE}=${token}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${config.sessionDays * 86400}`];
  if (config.cookieSecure) parts.push('Secure');
  res.setHeader('Set-Cookie', parts.join('; '));
}

export function register(res, { username, password }, ip) {
  validateUsername(username);
  validatePassword(password);
  checkRate(`reg:${ip}`);
  if (q('SELECT 1 FROM users WHERE username = ?').get(username)) throw new HttpError(409, 'That username is taken.');
  const hash = hashPassword(password);
  const userId = tx(() => {
    const r = q('INSERT INTO users (username, password_hash, balance, created_at) VALUES (?, ?, 0, ?)').run(username, hash, now());
    const id = Number(r.lastInsertRowid);
    credit(id, 'WELCOME_BONUS', RULES.startingBalance, null, 'Free virtual welcome balance (not real money)');
    return id;
  });
  createSession(res, userId);
  return userId;
}

export function login(res, { username, password }, ip) {
  checkRate(`login:${ip}:${String(username).toLowerCase()}`);
  const user = typeof username === 'string' ? q('SELECT id, password_hash FROM users WHERE username = ?').get(username) : null;
  if (!user || typeof password !== 'string' || !verifyPassword(password, user.password_hash)) {
    throw new HttpError(401, 'Incorrect username or password.');
  }
  createSession(res, user.id);
  return user.id;
}

export function logout(req, res) {
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (token) q('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
  res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

export function userFromRequest(req) {
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (!token) return null;
  const row = q(`SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
                 WHERE s.token_hash = ? AND s.expires_at > ?`).get(sha256(token), now());
  return row || null;
}

export function requireUser(req) {
  const u = userFromRequest(req);
  if (!u) throw new HttpError(401, 'Please log in to continue.');
  return u;
}

export function changeUsername(userId, username) {
  validateUsername(username);
  const clash = q('SELECT id FROM users WHERE username = ?').get(username);
  if (clash && clash.id !== userId) throw new HttpError(409, 'That username is taken.');
  q('UPDATE users SET username = ? WHERE id = ?').run(username, userId);
}

export function purgeExpiredSessions() {
  q('DELETE FROM sessions WHERE expires_at < ?').run(now());
}
