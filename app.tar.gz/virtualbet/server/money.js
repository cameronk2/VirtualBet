// Exact integer arithmetic for VIRTUAL money held in pence. Odds are stored as integers x100
// (2.00 -> 200) so no floating-point error can creep into balances.

/** Return in whole pence, rounded down: stake x product(odds). */
export function potentialReturn(stake, oddsX100List) {
  if (!oddsX100List.length) return stake; // every leg void -> stake back
  let num = BigInt(stake);
  let den = 1n;
  for (const o of oddsX100List) {
    num *= BigInt(o);
    den *= 100n;
  }
  return Number(num / den);
}

/** Combined decimal odds x100, rounded half-up to 2dp, for display. */
export function combinedOddsX100(oddsX100List) {
  if (!oddsX100List.length) return 100;
  let num = 1n;
  let den = 1n;
  for (const o of oddsX100List) {
    num *= BigInt(o);
    den *= 100n;
  }
  // value x100 = num*100/den, rounded half up
  return Number((num * 100n * 2n + den) / (den * 2n));
}

/** Virtual pounds for messages: 1050 -> "£10.50" */
export const gbp = (pence) => `£${(pence / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
