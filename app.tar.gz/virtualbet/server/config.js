import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Minimal .env loader (no dependency). Real environment variables win.
function loadDotEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 0) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadDotEnv();

const env = (k, d) => (process.env[k] === undefined || process.env[k] === '' ? d : process.env[k]);
const num = (k, d) => {
  const v = Number(env(k, d));
  return Number.isFinite(v) ? v : d;
};
const bool = (k, d) => {
  const v = env(k, undefined);
  if (v === undefined) return d;
  return ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());
};

const provider = String(env('FOOTBALL_API_PROVIDER', 'none')).toLowerCase();

export const config = {
  port: num('PORT', 3000),
  cookieSecure: bool('COOKIE_SECURE', false),
  sessionDays: num('SESSION_DAYS', 30),
  databasePath: path.resolve(ROOT, env('DATABASE_PATH', './data/virtualbet.db')),
  provider: ['api-football', 'football-data'].includes(provider) ? provider : 'none',
  apiFootballKey: env('API_FOOTBALL_KEY', ''),
  apiFootballLeagues: String(env('API_FOOTBALL_LEAGUES', '39,40,41,42,179,2,3,848,140,135,78,61,45,48'))
    .split(',').map((s) => Number(s.trim())).filter(Boolean),
  footballDataKey: env('FOOTBALL_DATA_KEY', ''),
  footballDataCompetitions: String(env('FOOTBALL_DATA_COMPETITIONS', 'PL,ELC,CL,PD,SA,BL1,FL1,DED,PPL'))
    .split(',').map((s) => s.trim()).filter(Boolean),
  livePollSeconds: Math.max(15, num('LIVE_POLL_SECONDS', 60)),
  fixturesPollMinutes: Math.max(5, num('FIXTURES_POLL_MINUTES', 30)),
  fixtureDaysAhead: Math.min(7, Math.max(1, num('FIXTURE_DAYS_AHEAD', 3))),
  demoSecondsPerMinute: Math.max(1, num('DEMO_SECONDS_PER_MINUTE', 8)),
};
config.demoEnabled = bool('ENABLE_DEMO_MATCHES', config.provider === 'none');

// Betting & wallet rules - enforced server side. All amounts are VIRTUAL
// pounds stored as integer pence (10_000 = £100.00).
export const RULES = {
  startingBalance: 10_000,
  minStake: 10,
  maxStake: 50_000,
  maxSelections: 20,
  depositPackages: [1_000, 2_000, 5_000, 10_000, 25_000, 50_000, 100_000], // quick picks
  depositMin: 500, // any whole-pound amount from £5
  depositMax: 100_000, // to £1,000
  depositStep: 100,
  dailyBonus: 500,
  dailyBonusIntervalMs: 24 * 60 * 60 * 1000,
  limitIncreaseCoolOffMs: 24 * 60 * 60 * 1000,
};
