// Web Push notifications ("your bet won") for the installed app.
// Implements VAPID (RFC 8292) and aes128gcm payload encryption (RFC 8291,
// RFC 8188) with Node's built-in crypto, so no extra packages are needed.
// Works with Apple (iPhone home-screen apps, iOS 16.4+), Chrome/Android,
// Firefox and Edge push services.
import crypto from 'node:crypto';
import { q } from './db.js';
import { HttpError, now } from './util.js';
import { getPrefs } from './prefs.js';

const b64u = (buf) => Buffer.from(buf).toString('base64url');
const fromB64u = (s) => Buffer.from(String(s), 'base64url');

// Only real push services: the server POSTs to the subscription URL, so an
// arbitrary URL would let anyone make the server call internal addresses.
const PUSH_HOSTS = [/\.push\.apple\.com$/, /^fcm\.googleapis\.com$/, /^android\.googleapis\.com$/, /\.push\.services\.mozilla\.com$/, /\.notify\.windows\.com$/, /^wns2?-.*\.notify\.windows\.com$/];
export function allowedEndpoint(endpoint) {
  try {
    const u = new URL(endpoint);
    return u.protocol === 'https:' && !u.port && PUSH_HOSTS.some((re) => re.test(u.hostname));
  } catch { return false; }
}

// ── VAPID keys: created once and kept in the database ─────────────
let vapid = null;
function keys() {
  if (vapid) return vapid;
  const row = q("SELECT value FROM app_settings WHERE key = 'vapid'").get();
  let jwk;
  if (row) jwk = JSON.parse(row.value);
  else {
    const { privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
    jwk = privateKey.export({ format: 'jwk' });
    q("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('vapid', ?)").run(JSON.stringify(jwk));
    jwk = JSON.parse(q("SELECT value FROM app_settings WHERE key = 'vapid'").get().value);
  }
  const privateKey = crypto.createPrivateKey({ key: jwk, format: 'jwk' });
  const publicRaw = Buffer.concat([Buffer.from([4]), fromB64u(jwk.x), fromB64u(jwk.y)]);
  vapid = { privateKey, publicKey: b64u(publicRaw) };
  return vapid;
}
export const vapidPublicKey = () => keys().publicKey;

const SUBJECT = process.env.VAPID_SUBJECT || 'mailto:notifications@virtualbet.app';
export function vapidHeader(endpoint, t = now()) {
  const { privateKey, publicKey } = keys();
  const aud = new URL(endpoint).origin;
  const head = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const body = b64u(JSON.stringify({ aud, exp: Math.floor(t / 1000) + 12 * 3600, sub: SUBJECT }));
  const sig = crypto.sign('sha256', Buffer.from(`${head}.${body}`), { key: privateKey, dsaEncoding: 'ieee-p1363' });
  return `vapid t=${head}.${body}.${b64u(sig)}, k=${publicKey}`;
}

// ── Payload encryption (RFC 8291) ───────────────────────────────
const hmac = (key, data) => crypto.createHmac('sha256', key).update(data).digest();
export function encrypt(payload, p256dh, authSecret, { salt = crypto.randomBytes(16), ecdh } = {}) {
  const uaPublic = fromB64u(p256dh);
  const auth = fromB64u(authSecret);
  if (uaPublic.length !== 65 || auth.length !== 16) throw new HttpError(400, 'Invalid push subscription keys.');
  const local = ecdh || crypto.createECDH('prime256v1');
  if (!ecdh) local.generateKeys();
  const asPublic = local.getPublicKey();
  const shared = local.computeSecret(uaPublic);
  const prkKey = hmac(auth, shared);
  const ikm = hmac(prkKey, Buffer.concat([Buffer.from('WebPush: info\0'), uaPublic, asPublic, Buffer.from([1])]));
  const prk = hmac(salt, ikm);
  const cek = hmac(prk, Buffer.from('Content-Encoding: aes128gcm\0\x01')).subarray(0, 16);
  const nonce = hmac(prk, Buffer.from('Content-Encoding: nonce\0\x01')).subarray(0, 12);
  const cipher = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const body = Buffer.concat([cipher.update(Buffer.concat([Buffer.from(payload), Buffer.from([2])])), cipher.final(), cipher.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPublic.length]), asPublic, body]);
}

// ── Subscriptions ───────────────────────────────────────────────
export function subscribe(userId, sub) {
  const endpoint = sub?.endpoint;
  const p256dh = sub?.keys?.p256dh;
  const auth = sub?.keys?.auth;
  if (typeof endpoint !== 'string' || endpoint.length > 1000 || !allowedEndpoint(endpoint)) throw new HttpError(400, 'This browser\'s push service is not supported.');
  if (typeof p256dh !== 'string' || typeof auth !== 'string') throw new HttpError(400, 'Invalid push subscription.');
  if (fromB64u(p256dh).length !== 65 || fromB64u(auth).length !== 16) throw new HttpError(400, 'Invalid push subscription keys.');
  q(`INSERT INTO push_subs (endpoint, user_id, p256dh, auth, created_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth`).run(endpoint, userId, p256dh, auth, now());
}
export function unsubscribe(userId, endpoint) {
  q('DELETE FROM push_subs WHERE user_id = ? AND endpoint = ?').run(userId, String(endpoint || ''));
}
export const deviceCount = (userId) => q('SELECT COUNT(*) AS n FROM push_subs WHERE user_id = ?').get(userId).n;

// ── Sending ─────────────────────────────────────────────────────
let sender = (url, init) => fetch(url, init); // swapped in tests
export const _setSender = (fn) => { sender = fn; };

async function sendOne(s, message) {
  const body = encrypt(JSON.stringify(message), s.p256dh, s.auth);
  try {
    const res = await sender(s.endpoint, {
      method: 'POST',
      headers: { TTL: '86400', Urgency: 'normal', 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', Authorization: vapidHeader(s.endpoint) },
      body,
    });
    if (res.status === 404 || res.status === 410) q('DELETE FROM push_subs WHERE endpoint = ?').run(s.endpoint); // device unsubscribed
    else if (res.status >= 400) console.warn(`[push] ${new URL(s.endpoint).hostname} answered ${res.status}`);
    return res.status;
  } catch (e) {
    console.warn('[push] send failed:', e.message);
    return 0;
  }
}

export async function sendToUser(userId, message) {
  const subs = q('SELECT endpoint, p256dh, auth FROM push_subs WHERE user_id = ?').all(userId);
  return Promise.all(subs.map((s) => sendOne(s, message)));
}

const money = (p) => `£${(p / 100).toFixed(2)}`;
/** Called after settlement: one notification per settled bet. Never throws. */
export function notifySettled(list) {
  for (const b of list) {
    try {
      if (!getPrefs(b.userId).notifySettled) continue;
      const title = b.status === 'WON' ? `Bet won: +${money(b.ret - b.stake)} virtual` : b.status === 'LOST' ? 'Bet lost' : 'Bet void: stake returned';
      const what = b.type === 'ACCA' ? `${b.legs}-fold accumulator` : b.label;
      const body = b.status === 'WON' ? `${what} paid ${money(b.ret)} (stake ${money(b.stake)}).` : b.status === 'LOST' ? `${what} · stake ${money(b.stake)}.` : `${what} · ${money(b.stake)} back in your virtual balance.`;
      sendToUser(b.userId, { title, body, tag: `bet-${b.ref}`, url: `/my-bets?tab=settled&bet=${b.ref}` }).catch(() => {});
    } catch (e) { console.warn('[push]', e.message); }
  }
}
