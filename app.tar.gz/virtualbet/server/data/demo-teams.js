// Teams used for SIMULATED demo matches. Strength ratings (-1..1) only
// drive the simulated odds/outcomes and are not a judgement of the
// clubs. League line-ups are approximate and may not match the current
// season. Badges are generated shields - no club crests are used.

const t = (name, short, color, s) => ({ name, short, color, s });

export const DEMO_LEAGUES = [
  { code: 'PL', name: 'Premier League', country: 'England', teams: [
    t('Arsenal', 'ARS', '#e3242b', 0.85), t('Liverpool', 'LIV', '#c8102e', 0.85), t('Manchester City', 'MCI', '#6cabdd', 0.8),
    t('Chelsea', 'CHE', '#034694', 0.6), t('Newcastle United', 'NEW', '#241f20', 0.5), t('Aston Villa', 'AVL', '#670e36', 0.45),
    t('Tottenham Hotspur', 'TOT', '#132257', 0.4), t('Manchester United', 'MUN', '#da291c', 0.4), t('Brighton', 'BHA', '#0057b8', 0.35),
    t('Nottingham Forest', 'NFO', '#dd0000', 0.3), t('Crystal Palace', 'CRY', '#1b458f', 0.3), t('Bournemouth', 'BOU', '#da291c', 0.25),
    t('Brentford', 'BRE', '#e30613', 0.2), t('Fulham', 'FUL', '#cccccc', 0.2), t('Everton', 'EVE', '#003399', 0.1),
    t('West Ham United', 'WHU', '#7a263a', 0.1), t('Wolverhampton', 'WOL', '#fdb913', 0.0), t('Leeds United', 'LEE', '#ffcd00', -0.05),
    t('Sunderland', 'SUN', '#eb172b', -0.1), t('Burnley', 'BUR', '#6c1d45', -0.15),
  ] },
  { code: 'ELC', name: 'Championship', country: 'England', teams: [
    t('Leicester City', 'LEI', '#003090', 0.0), t('Southampton', 'SOU', '#d71920', 0.0), t('Ipswich Town', 'IPS', '#0044a9', -0.05),
    t('Sheffield United', 'SHU', '#ee2737', -0.1), t('Middlesbrough', 'MID', '#e11b22', -0.1), t('Coventry City', 'COV', '#59cbe8', -0.1),
    t('West Bromwich Albion', 'WBA', '#122f67', -0.15), t('Norwich City', 'NOR', '#fff200', -0.15), t('Hull City', 'HUL', '#f5a12d', -0.2),
    t('Bristol City', 'BRC', '#e21a23', -0.2), t('Watford', 'WAT', '#fbee23', -0.2), t('Millwall', 'MIL', '#001d5e', -0.25),
    t('Stoke City', 'STK', '#e03a3e', -0.25), t('Preston North End', 'PNE', '#ffffff', -0.25), t('Swansea City', 'SWA', '#eeeeee', -0.3),
    t('Derby County', 'DER', '#ffffff', -0.3), t('Queens Park Rangers', 'QPR', '#1d5ba4', -0.3), t('Portsmouth', 'POR', '#001489', -0.35),
    t('Blackburn Rovers', 'BLB', '#009ee0', -0.3), t('Sheffield Wednesday', 'SHW', '#4466aa', -0.4), t('Oxford United', 'OXF', '#ffde00', -0.4),
    t('Charlton Athletic', 'CHA', '#d4021d', -0.4), t('Wrexham', 'WRE', '#d71920', -0.3), t('Birmingham City', 'BIR', '#0000ff', -0.2),
  ] },
  { code: 'EL1', name: 'League One', country: 'England', teams: [
    t('Luton Town', 'LUT', '#f78f1e', -0.4), t('Plymouth Argyle', 'PLY', '#00523a', -0.45), t('Cardiff City', 'CAR', '#0070b5', -0.45),
    t('Bolton Wanderers', 'BOL', '#263c7e', -0.5), t('Huddersfield Town', 'HUD', '#0e63ad', -0.5), t('Barnsley', 'BAR', '#d71920', -0.55),
    t('Peterborough United', 'PET', '#005daa', -0.55), t('Reading', 'REA', '#004494', -0.55), t('Wigan Athletic', 'WIG', '#1d59af', -0.6),
    t('Stockport County', 'STO', '#004b9b', -0.55), t('Lincoln City', 'LIN', '#e2231a', -0.6), t('Wycombe Wanderers', 'WYC', '#88d1f1', -0.6),
    t('Leyton Orient', 'LOR', '#d71920', -0.6), t('Blackpool', 'BLP', '#f68712', -0.6), t('Rotherham United', 'ROT', '#d71920', -0.65),
    t('Exeter City', 'EXE', '#d71920', -0.65), t('Mansfield Town', 'MAN', '#f5a300', -0.65), t('Burton Albion', 'BRT', '#fdb913', -0.7),
  ] },
  { code: 'EL2', name: 'League Two', country: 'England', teams: [
    t('Bradford City', 'BRA', '#7b2a3b', -0.7), t('Doncaster Rovers', 'DON', '#e2231a', -0.7), t('Notts County', 'NCO', '#000000', -0.7),
    t('Chesterfield', 'CHF', '#0033a0', -0.75), t('Walsall', 'WAL', '#d71920', -0.75), t('Port Vale', 'PVA', '#ffffff', -0.75),
    t('Milton Keynes Dons', 'MKD', '#ffffff', -0.75), t('Salford City', 'SAL', '#e2231a', -0.8), t('Crewe Alexandra', 'CRE', '#d71920', -0.8),
    t('Gillingham', 'GIL', '#0033a0', -0.8), t('Swindon Town', 'SWI', '#d71920', -0.8), t('Grimsby Town', 'GRI', '#000000', -0.85),
    t('Colchester United', 'COL', '#0047ab', -0.85), t('Tranmere Rovers', 'TRA', '#ffffff', -0.85), t('AFC Wimbledon', 'WIM', '#0047ab', -0.8),
    t('Newport County', 'NPT', '#f5a300', -0.9),
  ] },
  { code: 'SPL', name: 'Scottish Premiership', country: 'Scotland', teams: [
    t('Celtic', 'CEL', '#018749', 0.35), t('Rangers', 'RAN', '#1b458f', 0.25), t('Heart of Midlothian', 'HEA', '#a6192e', -0.3),
    t('Aberdeen', 'ABE', '#e2231a', -0.3), t('Hibernian', 'HIB', '#006e3c', -0.35), t('Dundee United', 'DDU', '#f37021', -0.45),
    t('Motherwell', 'MOT', '#fbb03b', -0.5), t('St Mirren', 'STM', '#000000', -0.5), t('Kilmarnock', 'KIL', '#0047ab', -0.55),
    t('Dundee', 'DUN', '#1d2c5e', -0.55), t('Livingston', 'LIV2', '#ffd200', -0.6), t('Falkirk', 'FAL', '#00205b', -0.6),
  ] },
  { code: 'CL', name: 'Champions League', country: 'Europe', teams: [
    t('Real Madrid', 'RMA', '#febe10', 0.9), t('Bayern Munich', 'BAY', '#dc052d', 0.85), t('Paris Saint-Germain', 'PSG', '#004170', 0.85),
    t('Barcelona', 'BAR2', '#a50044', 0.8), t('Inter', 'INT', '#0068a8', 0.7), t('Atlético Madrid', 'ATM', '#cb3524', 0.6),
    t('Borussia Dortmund', 'BVB', '#fde100', 0.5), t('Bayer Leverkusen', 'B04', '#e32221', 0.5), t('Juventus', 'JUV', '#000000', 0.5),
    t('Napoli', 'NAP', '#12a0d7', 0.55), t('Benfica', 'BEN', '#e83030', 0.4), t('Sporting CP', 'SCP', '#008057', 0.4),
    t('PSV Eindhoven', 'PSV', '#ed1c24', 0.35), t('Club Brugge', 'BRU', '#0063b0', 0.2), t('Galatasaray', 'GAL', '#a90432', 0.3),
    t('Ajax', 'AJA', '#d2122e', 0.3),
  ] },
  { code: 'EL', name: 'Europa League', country: 'Europe', teams: [
    t('Roma', 'ROM', '#8e1f2f', 0.45), t('Lyon', 'LYO', '#1b3e93', 0.4), t('Porto', 'FCP', '#00428c', 0.45),
    t('Real Betis', 'BET', '#0bb363', 0.35), t('Fenerbahçe', 'FEN', '#002d72', 0.35), t('Lille', 'LIL', '#e01e13', 0.35),
    t('Feyenoord', 'FEY', '#e30613', 0.3), t('Freiburg', 'SCF', '#e2001a', 0.3), t('Celta Vigo', 'CEL2', '#8ac3ee', 0.2),
    t('Braga', 'BRG', '#e30613', 0.2), t('Bologna', 'BOL2', '#1a2f48', 0.35), t('Panathinaikos', 'PAO', '#007a33', 0.1),
    t('FC Midtjylland', 'FCM', '#000000', 0.1), t('Red Star Belgrade', 'CZV', '#e2001a', 0.1), t('Basel', 'BAS', '#e30613', 0.05),
    t('Ferencváros', 'FTC', '#009a3e', 0.0),
  ] },
  { code: 'PD', name: 'La Liga', country: 'Spain', teams: [
    t('Villarreal', 'VIL', '#ffe667', 0.45), t('Athletic Club', 'ATH', '#ee2523', 0.45), t('Real Sociedad', 'RSO', '#0067b1', 0.35),
    t('Sevilla', 'SEV', '#f43333', 0.2), t('Valencia', 'VAL', '#ee3524', 0.15), t('Osasuna', 'OSA', '#d91a21', 0.1),
    t('Girona', 'GIR', '#cd2534', 0.15), t('Getafe', 'GET', '#005999', 0.05), t('Rayo Vallecano', 'RAY', '#e53027', 0.05),
    t('Mallorca', 'MLL', '#e20613', 0.05), t('Espanyol', 'ESP', '#007fc8', 0.0), t('Alavés', 'ALA', '#0761af', -0.05),
    t('Levante', 'LEV', '#b4053f', -0.1), t('Elche', 'ELC2', '#05642c', -0.1),
  ] },
  { code: 'SA', name: 'Serie A', country: 'Italy', teams: [
    t('AC Milan', 'MIL2', '#fb090b', 0.55), t('Atalanta', 'ATA', '#1e71b8', 0.55), t('Lazio', 'LAZ', '#87d8f7', 0.4),
    t('Fiorentina', 'FIO', '#482e92', 0.35), t('Torino', 'TOR', '#8a1e03', 0.15), t('Udinese', 'UDI', '#000000', 0.1),
    t('Genoa', 'GEN', '#ad1919', 0.05), t('Como', 'COM', '#003e7e', 0.2), t('Cagliari', 'CAG', '#a6192e', 0.0),
    t('Lecce', 'LEC', '#ffde00', -0.05), t('Parma', 'PAR', '#ffd700', 0.0), t('Verona', 'VER', '#003d8f', -0.05),
    t('Sassuolo', 'SAS', '#00a752', 0.0), t('Cremonese', 'CRE2', '#c8102e', -0.1),
  ] },
  { code: 'BL1', name: 'Bundesliga', country: 'Germany', teams: [
    t('RB Leipzig', 'RBL', '#dd0741', 0.5), t('Eintracht Frankfurt', 'SGE', '#e1000f', 0.4), t('VfB Stuttgart', 'VFB', '#e32219', 0.4),
    t('Borussia Mönchengladbach', 'BMG', '#000000', 0.2), t('VfL Wolfsburg', 'WOB', '#65b32e', 0.2), t('Mainz 05', 'M05', '#c3141e', 0.2),
    t('Werder Bremen', 'SVW', '#1d9053', 0.15), t('Union Berlin', 'FCU', '#eb1923', 0.15), t('Hoffenheim', 'TSG', '#1961b5', 0.2),
    t('FC Augsburg', 'FCA', '#ba3733', 0.05), t('FC Köln', 'KOE', '#ed1c24', 0.0), t('Hamburger SV', 'HSV', '#0a3f86', 0.0),
    t('St. Pauli', 'STP', '#624839', -0.05), t('Heidenheim', 'HDH', '#e30613', -0.05),
  ] },
  { code: 'FL1', name: 'Ligue 1', country: 'France', teams: [
    t('Marseille', 'OM', '#2faee0', 0.5), t('Monaco', 'MON', '#e7001c', 0.45), t('Nice', 'NIC', '#c8102e', 0.3),
    t('Lens', 'RCL', '#ffd700', 0.3), t('Rennes', 'REN', '#e13327', 0.3), t('Strasbourg', 'RCS', '#009fe3', 0.25),
    t('Toulouse', 'TFC', '#6b3fa0', 0.1), t('Nantes', 'FCN', '#fcd405', 0.05), t('Brest', 'SB29', '#ed1c24', 0.1),
    t('Auxerre', 'AJA2', '#0058a3', 0.0), t('Angers', 'SCO', '#000000', -0.05), t('Le Havre', 'HAC', '#12a9e0', -0.05),
    t('Lorient', 'FCL', '#f58220', -0.05), t('Paris FC', 'PFC', '#1c2a5d', 0.0),
  ] },
];
