import { q, tx } from './db.js';
import { RULES } from './config.js';
import { HttpError, isInt, now, randomCode } from './util.js';
import { credit, debit } from './wallet.js';
import { cashOutValue, currentLegs } from './cashout.js';
import { getMatchRow } from './matches.js';
import { priceMarkets } from './markets.js';
import { award } from './progress.js';
import { combinedOddsX100, gbp, potentialReturn } from './money.js';

// ── Responsible play: daily stake limit ─────────────────────────
export function effectiveLimit(userId) {
  const u = q('SELECT daily_stake_limit, pending_stake_limit, pending_limit_at FROM users WHERE id = ?').get(userId);
  if (u.pending_limit_at && u.pending_limit_at <= now()) {
    const next = u.pending_stake_limit === -1 ? null : u.pending_stake_limit;
    q('UPDATE users SET daily_stake_limit = ?, pending_stake_limit = NULL, pending_limit_at = NULL WHERE id = ?').run(next, userId);
    return { limit: next, pending: null, pendingAt: null };
  }
  return {
    limit: u.daily_stake_limit,
    pending: u.pending_limit_at ? (u.pending_stake_limit === -1 ? 'none' : u.pending_stake_limit) : null,
    pendingAt: u.pending_limit_at,
  };
}

/** "Take a break": staking is blocked until the break ends. It can't be cancelled early. */
export const BREAK_HOURS = [24, 72, 168, 720];
export function checkBreak(userId) {
  const u = q('SELECT break_until FROM users WHERE id = ?').get(userId);
  if (u?.break_until && u.break_until > now()) {
    throw new HttpError(403, `You're taking a break until ${new Date(u.break_until).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}. Bets and games are paused until then.`, { code: 'BREAK' });
  }
}
export function takeBreak(userId, hours) {
  if (!BREAK_HOURS.includes(hours)) throw new HttpError(400, 'Invalid break length.');
  const cur = q('SELECT break_until FROM users WHERE id = ?').get(userId).break_until || 0;
  q('UPDATE users SET break_until = ? WHERE id = ?').run(Math.max(cur, now() + hours * 3600000), userId);
}

export function stakedLast24h(userId) {
  const since = now() - 86400000;
  return q('SELECT COALESCE(SUM(stake), 0) AS s FROM bets WHERE user_id = ? AND created_at > ?').get(userId, since).s
    + q(`SELECT COALESCE(SUM(-amount), 0) AS s FROM wallet_tx WHERE user_id = ? AND type IN ('BLACKJACK_BET','SLOTS_BET','CASINO_BET') AND created_at > ?`).get(userId, since).s;
}

export function setDailyLimit(userId, limit) {
  if (limit !== null && (!isInt(limit) || limit < RULES.minStake || limit > 10_000_000)) {
    throw new HttpError(400, `Daily limit must be at least ${gbp(RULES.minStake)}, or none.`);
  }
  const cur = effectiveLimit(userId).limit;
  const isDecrease = limit !== null && (cur === null || limit <= cur);
  if (isDecrease) {
    // Lowering a limit is protective, so it applies immediately.
    q('UPDATE users SET daily_stake_limit = ?, pending_stake_limit = NULL, pending_limit_at = NULL WHERE id = ?').run(limit, userId);
    award(userId, [{ t: 'limit' }]);
    return { applied: true };
  }
  // Raising or removing a limit only takes effect after a 24h cooling-off period.
  const at = now() + RULES.limitIncreaseCoolOffMs;
  q('UPDATE users SET pending_stake_limit = ?, pending_limit_at = ? WHERE id = ?').run(limit === null ? -1 : limit, at, userId);
  return { applied: false, effectiveAt: at };
}

// ── Placement ───────────────────────────────────────────────────
function newRef() {
  for (;;) {
    const ref = `VB-${randomCode(4)}-${randomCode(4)}`;
    if (!q('SELECT 1 FROM bets WHERE ref = ?').get(ref)) return ref;
  }
}

function validateShape(body) {
  const { bets, idempotencyKey } = body || {};
  if (typeof idempotencyKey !== 'string' || idempotencyKey.length < 8 || idempotencyKey.length > 100) {
    throw new HttpError(400, 'Missing submission key.');
  }
  if (!Array.isArray(bets) || bets.length < 1 || bets.length > RULES.maxSelections) {
    throw new HttpError(400, 'Your bet slip is empty.');
  }
  for (const b of bets) {
    if (!b || !['SINGLE', 'ACCA'].includes(b.type)) throw new HttpError(400, 'Unknown bet type.');
    if (!isInt(b.stake) || b.stake < RULES.minStake) throw new HttpError(400, `Minimum stake is ${gbp(RULES.minStake)}.`);
    if (b.stake > RULES.maxStake) throw new HttpError(400, `Maximum stake is ${gbp(RULES.maxStake)} per bet.`);
    if (!Array.isArray(b.selections) || !b.selections.length) throw new HttpError(400, 'Each bet needs at least one selection.');
    for (const s of b.selections) {
      if (!s || typeof s.matchId !== 'string' || typeof s.market !== 'string' || typeof s.selection !== 'string' || !isInt(s.odds)) {
        throw new HttpError(400, 'Invalid selection.');
      }
    }
    if (b.type === 'SINGLE' && b.selections.length !== 1) throw new HttpError(400, 'A single bet must have exactly one selection.');
    if (b.type === 'ACCA') {
      if (b.selections.length < 2) throw new HttpError(400, 'An accumulator needs at least two selections.');
      if (b.selections.length > RULES.maxSelections) throw new HttpError(400, `An accumulator can have at most ${RULES.maxSelections} selections.`);
      const ids = new Set(b.selections.map((s) => s.matchId));
      if (ids.size !== b.selections.length) {
        throw new HttpError(400, 'Accumulator selections must all come from different matches.');
      }
    }
  }
  return { bets, idempotencyKey };
}

export function placeBets(userId, body) {
  const { bets, idempotencyKey } = validateShape(body);
  const acceptOddsChanges = body.acceptOddsChanges === true;

  return tx(() => {
    const prior = q('SELECT result FROM placements WHERE user_id = ? AND idem_key = ?').get(userId, idempotencyKey);
    if (prior) return { ...JSON.parse(prior.result), duplicate: true };

    // Re-price every selection from current server-side match state.
    const priced = new Map();
    const changes = [];
    const resolved = bets.map((b) => ({
      ...b,
      selections: b.selections.map((s) => {
        const row = getMatchRow(s.matchId);
        if (!row) throw new HttpError(404, 'Match not found.');
        if (!priced.has(row.id)) priced.set(row.id, priceMarkets(row));
        const market = priced.get(row.id).find((m) => m.key === s.market);
        const label = `${row.home_name} v ${row.away_name}`;
        if (!market) throw new HttpError(409, `${label}: that market is no longer available.`, { code: 'UNAVAILABLE', matchId: s.matchId, market: s.market, selection: s.selection });
        if (market.suspended) throw new HttpError(409, `${label}: betting is suspended right now.`, { code: 'SUSPENDED', matchId: s.matchId, market: s.market, selection: s.selection });
        const sel = market.selections.find((x) => x.key === s.selection);
        if (!sel || !sel.odds) throw new HttpError(409, `${label}: that selection is no longer available.`, { code: 'UNAVAILABLE', matchId: s.matchId, market: s.market, selection: s.selection });
        if (sel.odds !== s.odds) changes.push({ matchId: s.matchId, market: s.market, selection: s.selection, from: s.odds, to: sel.odds });
        const inPlay = row.status !== 'SCHEDULED';
        return {
          row, label, market, sel, inPlay,
          score: inPlay ? `${row.home_score ?? 0}-${row.away_score ?? 0}` : null,
        };
      }),
    }));

    if (changes.length && !acceptOddsChanges) {
      throw new HttpError(409, 'Odds have changed. Please review and accept the new odds.', { code: 'ODDS_CHANGED', changes });
    }

    const totalStake = bets.reduce((a, b) => a + b.stake, 0);
    const bal = q('SELECT balance FROM users WHERE id = ?').get(userId).balance;
    if (totalStake > bal) throw new HttpError(400, `Total stake (${gbp(totalStake)}) is more than your balance (${gbp(bal)}).`);
    checkBreak(userId);
    const { limit } = effectiveLimit(userId);
    if (limit !== null) {
      const used = stakedLast24h(userId);
      if (used + totalStake > limit) {
        throw new HttpError(400, `This would exceed your daily stake limit. You can stake ${gbp(Math.max(0, limit - used))} more in the current 24 hours.`, { code: 'LIMIT' });
      }
    }

    const t = now();
    const placed = [];
    for (const b of resolved) {
      const odds = b.selections.map((s) => s.sel.odds);
      const ref = newRef();
      const r = q(`INSERT INTO bets (ref, user_id, type, stake, total_odds, potential_return, status, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, 'OPEN', ?)`).run(ref, userId, b.type, b.stake, combinedOddsX100(odds), potentialReturn(b.stake, odds), t);
      const betId = Number(r.lastInsertRowid);
      for (const s of b.selections) {
        q(`INSERT INTO bet_selections (bet_id, match_id, match_label, league_name, market_key, market_name, selection_key,
             selection_label, odds, in_play, score_at_placement, minute_at_placement)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(betId, s.row.id, s.label, s.row.league_name, s.market.key, s.market.name,
          s.sel.key, s.sel.label, s.sel.odds, s.inPlay ? 1 : 0, s.score, s.inPlay ? s.row.minute : null);
      }
      debit(userId, 'BET_STAKE', b.stake, ref, `${b.type === 'ACCA' ? `${odds.length}-fold accumulator` : 'Single'} stake`);
      placed.push(ref);
    }
    award(userId, [{ t: 'sportsBet' }, { t: 'played', game: 'sports' }]);
    const balance = q('SELECT balance FROM users WHERE id = ?').get(userId).balance;
    const result = { refs: placed, bets: placed.map((ref) => getBet(userId, ref)), balance };
    q('INSERT INTO placements (user_id, idem_key, result, created_at) VALUES (?, ?, ?, ?)').run(userId, idempotencyKey, JSON.stringify(result), t);
    return result;
  });
}

// ── Quotes for the bet slip (current odds of each selection) ────
export function quoteSelections(selections) {
  if (!Array.isArray(selections)) throw new HttpError(400, 'Invalid request.');
  const priced = new Map();
  return selections.slice(0, RULES.maxSelections).map((s) => {
    const row = s && typeof s.matchId === 'string' ? getMatchRow(s.matchId) : null;
    if (!row) return { ...s, available: false, reason: 'Match not found' };
    if (!priced.has(row.id)) priced.set(row.id, priceMarkets(row));
    const market = priced.get(row.id).find((m) => m.key === s.market);
    const sel = market?.selections.find((x) => x.key === s.selection);
    if (!market || !sel?.odds) return { matchId: s.matchId, market: s.market, selection: s.selection, available: false, reason: 'No longer available' };
    return {
      matchId: s.matchId, market: s.market, selection: s.selection, odds: sel.odds,
      available: true, suspended: market.suspended, live: row.status !== 'SCHEDULED',
      minute: row.minute, score: row.status !== 'SCHEDULED' ? `${row.home_score ?? 0}-${row.away_score ?? 0}` : null,
    };
  });
}

// ── Reading bets ────────────────────────────────────────────────
function cashOutFor(b, sels) {
  if (b.status !== 'OPEN') return null;
  const legs = currentLegs(sels.map((s) => ({ matchId: s.match_id, marketKey: s.market_key, selectionKey: s.selection_key, odds: s.odds, status: s.status })), getMatchRow, priceMarkets);
  return cashOutValue(b.stake, b.potential_return, legs);
}

function serializeBet(b, sels) {
  return {
    cashOut: cashOutFor(b, sels),
    ref: b.ref, type: b.type, stake: b.stake, totalOdds: b.total_odds, potentialReturn: b.potential_return,
    status: b.status, actualReturn: b.actual_return, createdAt: b.created_at, settledAt: b.settled_at,
    profit: b.status === 'OPEN' ? null : (b.actual_return ?? 0) - b.stake,
    selections: sels.map((s) => ({
      matchId: s.match_id, match: s.match_label, league: s.league_name, market: s.market_name, marketKey: s.market_key,
      selection: s.selection_label, selectionKey: s.selection_key, odds: s.odds, inPlay: !!s.in_play,
      scoreAtPlacement: s.score_at_placement, minuteAtPlacement: s.minute_at_placement, status: s.status, voidReason: s.void_reason,
      result: s.home_score != null && ['FINISHED'].includes(s.mstatus) ? `${s.home_score}-${s.away_score}` : null,
      matchStatus: s.mstatus, liveScore: s.home_score != null ? `${s.home_score}-${s.away_score}` : null, minute: s.minute,
    })),
  };
}

const SEL_SQL = `SELECT s.*, m.status AS mstatus, m.home_score, m.away_score, m.minute
  FROM bet_selections s JOIN matches m ON m.id = s.match_id WHERE s.bet_id = ? ORDER BY s.id`;

export function getBet(userId, ref) {
  const b = q('SELECT * FROM bets WHERE user_id = ? AND ref = ?').get(userId, ref);
  if (!b) return null;
  return serializeBet(b, q(SEL_SQL).all(b.id));
}

export function listBets(userId, status = 'all', limit = 200) {
  let rows;
  if (status === 'open') rows = q(`SELECT * FROM bets WHERE user_id = ? AND status = 'OPEN' ORDER BY created_at DESC LIMIT ?`).all(userId, limit);
  else if (status === 'settled') rows = q(`SELECT * FROM bets WHERE user_id = ? AND status != 'OPEN' ORDER BY settled_at DESC LIMIT ?`).all(userId, limit);
  else rows = q('SELECT * FROM bets WHERE user_id = ? ORDER BY created_at DESC LIMIT ?').all(userId, limit);
  return rows.map((b) => serializeBet(b, q(SEL_SQL).all(b.id)));
}

// ── Cash Out ────────────────────────────────────────────────────
export function cashOutBet(userId, ref, expected) {
  return tx(() => {
    const b = q('SELECT * FROM bets WHERE user_id = ? AND ref = ?').get(userId, ref);
    if (!b) throw new HttpError(404, 'Bet not found.');
    if (b.status !== 'OPEN') throw new HttpError(409, 'This bet has already been settled.', { code: 'SETTLED' });
    const co = cashOutFor(b, q(SEL_SQL).all(b.id));
    if (!co.available) throw new HttpError(409, `Cash Out isn't available: ${co.reason.toLowerCase()}.`, { code: 'CASHOUT_UNAVAILABLE' });
    if (!isInt(expected) || expected !== co.value) throw new HttpError(409, `The Cash Out value has changed to ${gbp(co.value)}.`, { code: 'CASHOUT_CHANGED', value: co.value });
    q(`UPDATE bets SET status = 'CASHED_OUT', actual_return = ?, settled_at = ? WHERE id = ?`).run(co.value, now(), b.id);
    credit(userId, 'BET_CASHOUT', co.value, b.ref, 'Cash Out');
    return { bet: getBet(userId, ref), value: co.value, balance: q('SELECT balance FROM users WHERE id = ?').get(userId).balance };
  });
}
