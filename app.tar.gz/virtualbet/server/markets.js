// ─────────────────────────────────────────────────────────────────
// Market catalogue, SIMULATED odds engine and settlement rules.
//
// Odds are produced by a Poisson goal model (with a bookmaker-style
// margin). They are always labelled "simulated" in the UI - they are
// never presented as genuine bookmaker prices.
//
// The SAME predicates are used for pricing and for settlement, so a
// selection always settles exactly the way it was priced.
// ─────────────────────────────────────────────────────────────────

const CAP = 8; // max extra goals per team per half in the model
const MINUTES = 93; // 90 + average stoppage time
const CORNERS_PER_MATCH = 10.2;
const CARDS_PER_MATCH = 4.0;
const MIN_ODDS = 101;
const MAX_ODDS = 50000;

export const LIVE_STATUSES = ['LIVE_1H', 'HT', 'LIVE_2H', 'SUSPENDED'];
export const FINAL_STATUSES = ['FINISHED'];
export const VOID_STATUSES = ['ABANDONED', 'CANCELLED'];

const res = (h, a) => (h > a ? '1' : h < a ? '2' : 'X');

function poisson(lambda) {
  const out = [];
  if (lambda <= 0) return [1];
  let p = Math.exp(-lambda);
  let acc = 0;
  for (let k = 0; k < CAP; k++) {
    out.push(p);
    acc += p;
    p *= lambda / (k + 1);
  }
  out.push(Math.max(0, 1 - acc)); // tail mass lumped into the last bucket
  return out;
}

function poissonAtLeast(lambda, k) {
  if (k <= 0) return 1;
  let p = Math.exp(-lambda);
  let cdf = 0;
  for (let i = 0; i < k; i++) {
    cdf += p;
    p *= lambda / (i + 1);
  }
  return Math.max(0, 1 - cdf);
}

export function phaseOf(status, minute) {
  switch (status) {
    case 'SCHEDULED': return 'PRE';
    case 'LIVE_1H': return '1H';
    case 'HT': return 'HT';
    case 'LIVE_2H': return '2H';
    case 'SUSPENDED': return (minute ?? 0) > 45 ? '2H' : '1H';
    default: return 'END';
  }
}

function remainingMinutes(phase, minute) {
  if (phase === 'PRE') return [47, 48];
  if (phase === '1H') return [Math.max(0.5, 47 - (minute || 1)), 48];
  if (phase === 'HT') return [0, 48];
  if (phase === '2H') return [0, Math.max(0.5, MINUTES - (minute || 46))];
  return [0, 0];
}

// ── Score-based markets (priced & settled from HT/FT scores) ─────
function scoreMarkets(H, A) {
  const lab = { 1: H, X: 'Draw', 2: A };
  const m = [
    {
      key: '1X2', name: 'Full Time Result', group: 'main', ovr: 1.06,
      sels: ['1', 'X', '2'].map((k) => [k, lab[k], (ht, ft) => res(ft[0], ft[1]) === k]),
    },
    {
      key: 'DC', name: 'Double Chance', group: 'main', ovr: 1.04,
      sels: [
        ['1X', `${H} or Draw`, (ht, ft) => res(...ft) !== '2'],
        ['12', `${H} or ${A}`, (ht, ft) => res(...ft) !== 'X'],
        ['X2', `Draw or ${A}`, (ht, ft) => res(...ft) !== '1'],
      ],
    },
    {
      key: 'DNB', name: 'Draw No Bet', group: 'main', ovr: 1.05,
      sels: [
        ['1', H, (ht, ft) => (ft[0] === ft[1] ? 'VOID' : ft[0] > ft[1])],
        ['2', A, (ht, ft) => (ft[0] === ft[1] ? 'VOID' : ft[1] > ft[0])],
      ],
    },
    {
      key: 'BTTS', name: 'Both Teams To Score', group: 'main', ovr: 1.06,
      sels: [
        ['Y', 'Yes', (ht, ft) => ft[0] > 0 && ft[1] > 0],
        ['N', 'No', (ht, ft) => !(ft[0] > 0 && ft[1] > 0)],
      ],
    },
  ];
  for (const line of [0.5, 1.5, 2.5, 3.5]) {
    m.push({
      key: `OU${String(line * 10).padStart(2, '0')}`, name: `Total Goals Over/Under ${line}`,
      group: line === 2.5 ? 'main' : 'goals', ovr: 1.06,
      sels: [
        ['O', `Over ${line}`, (ht, ft) => ft[0] + ft[1] > line],
        ['U', `Under ${line}`, (ht, ft) => ft[0] + ft[1] < line],
      ],
    });
  }
  m.push(
    {
      key: 'HT1X2', name: 'Half Time Result', group: 'halves', ovr: 1.07,
      sels: ['1', 'X', '2'].map((k) => [k, lab[k], (ht) => res(ht[0], ht[1]) === k]),
    },
    {
      key: 'HTFT', name: 'Half Time / Full Time', group: 'halves', ovr: 1.15,
      sels: ['1', 'X', '2'].flatMap((h) => ['1', 'X', '2'].map((f) => [
        `${h}/${f}`, `${lab[h]} / ${lab[f]}`, (ht, ft) => res(...ht) === h && res(...ft) === f,
      ])),
    },
  );
  const cs = [];
  for (let h = 0; h <= 3; h++) for (let a = 0; a <= 3; a++) {
    cs.push([`${h}-${a}`, `${h}-${a}`, (ht, ft) => ft[0] === h && ft[1] === a]);
  }
  const other = (ft) => ft[0] > 3 || ft[1] > 3;
  cs.push(
    ['OTH1', `Any other ${H} win`, (ht, ft) => other(ft) && ft[0] > ft[1]],
    ['OTHX', 'Any other draw', (ht, ft) => other(ft) && ft[0] === ft[1]],
    ['OTH2', `Any other ${A} win`, (ht, ft) => other(ft) && ft[1] > ft[0]],
  );
  m.push({ key: 'CS', name: 'Correct Score', group: 'score', ovr: 1.18, sels: cs });
  for (const [key, side, name] of [['HG', 0, `${H} Goals`], ['AG', 1, `${A} Goals`]]) {
    m.push({
      key, name, group: 'goals', ovr: 1.08,
      sels: [
        ['0', '0', (ht, ft) => ft[side] === 0],
        ['1', '1', (ht, ft) => ft[side] === 1],
        ['2', '2', (ht, ft) => ft[side] === 2],
        ['3+', '3 or more', (ht, ft) => ft[side] >= 3],
      ],
    });
  }
  return m;
}

const SCORE_KEYS = new Set(scoreMarkets('H', 'A').map((m) => m.key));

// ── Model state ─────────────────────────────────────────────────
export function stateFromRow(row) {
  return {
    status: row.status,
    minute: row.minute,
    hs: row.home_score ?? 0,
    as: row.away_score ?? 0,
    htH: row.ht_home,
    htA: row.ht_away,
    corners: row.home_corners == null || row.away_corners == null ? null : row.home_corners + row.away_corners,
    cards: row.home_cards == null || row.away_cards == null ? null : row.home_cards + row.away_cards,
    goalOrder: row.goal_order ? JSON.parse(row.goal_order) : null,
    lh: row.lambda_home,
    la: row.lambda_away,
    caps: typeof row.caps === 'string' ? JSON.parse(row.caps) : row.caps,
    suspended: row.status === 'SUSPENDED' || (row.suspended_until && row.suspended_until > Date.now()),
    stale: row.source !== 'demo' && LIVE_STATUSES.includes(row.status) && row.last_sync_at && Date.now() - row.last_sync_at > 5 * 60 * 1000,
  };
}

function outcomeTable(s, phase) {
  const [r1, r2] = remainingMinutes(phase, s.minute);
  const rh = s.lh / MINUTES;
  const ra = s.la / MINUTES;
  const d1h = poisson(rh * r1), d1a = poisson(ra * r1);
  const d2h = poisson(rh * r2), d2a = poisson(ra * r2);
  let baseHT;
  if (phase === 'PRE') baseHT = [0, 0];
  else if (phase === '1H') baseHT = [s.hs, s.as];
  else baseHT = [s.htH ?? s.hs, s.htA ?? s.as];
  const agg = new Map();
  for (let a = 0; a < d1h.length; a++) for (let b = 0; b < d1a.length; b++) {
    const p1 = d1h[a] * d1a[b];
    if (p1 < 1e-10) continue;
    const ht = [baseHT[0] + a, baseHT[1] + b];
    const ftBase = phase === 'PRE' || phase === '1H' ? ht : [s.hs, s.as];
    for (let c = 0; c < d2h.length; c++) for (let d = 0; d < d2a.length; d++) {
      const p = p1 * d2h[c] * d2a[d];
      if (p < 1e-10) continue;
      const key = `${ht[0]},${ht[1]},${ftBase[0] + c},${ftBase[1] + d}`;
      agg.set(key, (agg.get(key) || 0) + p);
    }
  }
  return [...agg].map(([k, p]) => {
    const [a, b, c, d] = k.split(',').map(Number);
    return { ht: [a, b], ft: [c, d], p };
  });
}

const toOdds = (p, ovr) => {
  if (!(p > 0)) return null;
  const o = Math.floor(100 / (p * ovr) + 1e-9);
  return Math.min(MAX_ODDS, Math.max(MIN_ODDS, o));
};

/**
 * Price every market for a match. Returns [] when betting is closed.
 * names: { home, away }
 */
export function priceMarkets(row) {
  const s = stateFromRow(row);
  const phase = phaseOf(s.status, s.minute);
  if (phase === 'END') return [];
  const inPlay = phase !== 'PRE';
  const suspended = !!(s.suspended || s.stale);
  const H = row.home_name, A = row.away_name;
  const out = [];

  // Score markets
  const table = outcomeTable(s, phase);
  for (const m of scoreMarkets(H, A)) {
    if (inPlay && (m.key === 'HT1X2' || m.key === 'HTFT') && phase !== '1H') continue; // first half over
    if (s.caps?.halfTime === false && (m.key === 'HT1X2' || m.key === 'HTFT')) continue; // source has no half-time scores
    const sels = m.sels.map(([key, label, fn]) => {
      let pWin = 0, pVoid = 0;
      for (const o of table) {
        const r = fn(o.ht, o.ft);
        if (r === 'VOID') pVoid += o.p;
        else if (r) pWin += o.p;
      }
      const p = pVoid > 0 ? pWin / Math.max(1e-9, 1 - pVoid) : pWin;
      return { key, label, p };
    });
    pushMarket(out, m, sels, suspended);
  }

  // Remaining expected goals for the team markets
  const [r1, r2] = remainingMinutes(phase, s.minute);
  const remFrac = (r1 + r2) / MINUTES;
  const lh = s.lh * remFrac, la = s.la * remFrac, lt = lh + la;
  const pNone = Math.exp(-lt);
  const p1 = lt > 0 ? (lh / lt) * (1 - pNone) : 0;
  const p2 = lt > 0 ? (la / lt) * (1 - pNone) : 0;
  const goals = s.hs + s.as;
  const orderKnown = Array.isArray(s.goalOrder) && s.goalOrder.length === goals;

  if (s.caps?.goalOrder) {
    if (goals === 0) {
      pushMarket(out, { key: 'FTS', name: 'First Team To Score', group: 'specials', ovr: 1.06 }, [
        { key: '1', label: H, p: p1 }, { key: 'N', label: 'No goal', p: pNone }, { key: '2', label: A, p: p2 },
      ], suspended);
    }
    if (goals === 0 || orderKnown) {
      const last = goals === 0 ? 'N' : s.goalOrder[goals - 1];
      pushMarket(out, { key: 'LTS', name: 'Last Team To Score', group: 'specials', ovr: 1.06 }, [
        { key: '1', label: H, p: p1 + (last === '1' ? pNone : 0) },
        { key: 'N', label: 'No goal', p: last === 'N' ? pNone : 0 },
        { key: '2', label: A, p: p2 + (last === '2' ? pNone : 0) },
      ], suspended);
    }
    if (inPlay) {
      const n = goals + 1;
      pushMarket(out, { key: `NG${n}`, name: `Next Goal (Goal ${n})`, group: 'main', ovr: 1.06 }, [
        { key: '1', label: H, p: p1 }, { key: 'N', label: 'No more goals', p: pNone }, { key: '2', label: A, p: p2 },
      ], suspended);
    }
  }

  if (s.caps?.corners && (!inPlay || (s.caps.liveCorners && s.corners != null))) {
    const cur = inPlay ? s.corners : 0;
    const pOver = poissonAtLeast(CORNERS_PER_MATCH * remFrac, 10 - cur);
    pushMarket(out, { key: 'CRN95', name: 'Total Corners Over/Under 9.5', group: 'specials', ovr: 1.07 }, [
      { key: 'O', label: 'Over 9.5', p: pOver }, { key: 'U', label: 'Under 9.5', p: 1 - pOver },
    ], suspended);
  }
  if (s.caps?.cards && (!inPlay || (s.caps.liveCards && s.cards != null))) {
    const cur = inPlay ? s.cards : 0;
    const pOver = poissonAtLeast(CARDS_PER_MATCH * remFrac, 4 - cur);
    pushMarket(out, { key: 'CRD35', name: 'Total Cards Over/Under 3.5', group: 'specials', ovr: 1.07 }, [
      { key: 'O', label: 'Over 3.5', p: pOver }, { key: 'U', label: 'Under 3.5', p: 1 - pOver },
    ], suspended);
  }
  return out;
}

function pushMarket(out, m, sels, suspended) {
  // A market whose outcome is effectively decided is withdrawn.
  if (sels.some((x) => x.p >= 0.975)) return;
  const selections = sels
    .map((x) => ({ key: x.key, label: x.label, odds: x.p >= 0.004 ? toOdds(x.p, m.ovr) : null }))
    .filter((x) => x.odds !== null || m.key === 'CS');
  if (selections.filter((x) => x.odds).length < 2) return;
  out.push({ key: m.key, name: m.name, group: m.group, suspended, selections });
}

// ── Settlement ──────────────────────────────────────────────────
/**
 * result: { ft:[h,a], ht:[h,a]|null, goalOrder:[..]|null, corners:n|null, cards:n|null }
 * Returns 'WON' | 'LOST' | 'VOID' | null (data not yet available).
 */
export function settleSelection(marketKey, selKey, result) {
  const { ft, ht } = result;
  if (!ft) return null;
  if (SCORE_KEYS.has(marketKey)) {
    const def = scoreMarkets('H', 'A').find((m) => m.key === marketKey);
    const sel = def.sels.find(([k]) => k === selKey);
    if (!sel) return 'VOID';
    if ((marketKey === 'HT1X2' || marketKey === 'HTFT') && !ht) return null;
    const r = sel[2](ht || [0, 0], ft);
    return r === 'VOID' ? 'VOID' : r ? 'WON' : 'LOST';
  }
  const total = ft[0] + ft[1];
  const order = Array.isArray(result.goalOrder) && result.goalOrder.length === total ? result.goalOrder : null;
  const pick = (team) => (team === selKey ? 'WON' : 'LOST');
  if (marketKey === 'FTS' || marketKey === 'LTS') {
    if (total === 0) return pick('N');
    if (!order) return null;
    return pick(marketKey === 'FTS' ? order[0] : order[total - 1]);
  }
  const ng = /^NG(\d+)$/.exec(marketKey);
  if (ng) {
    const n = Number(ng[1]);
    if (total < n) return pick('N');
    if (!order) return null;
    return pick(order[n - 1]);
  }
  if (marketKey === 'CRN95') {
    if (result.corners == null) return null;
    return (selKey === 'O') === (result.corners > 9.5) ? 'WON' : 'LOST';
  }
  if (marketKey === 'CRD35') {
    if (result.cards == null) return null;
    return (selKey === 'O') === (result.cards > 3.5) ? 'WON' : 'LOST';
  }
  return 'VOID';
}

export function resultFromRow(row) {
  if (row.home_score == null || row.away_score == null) return { ft: null };
  return {
    ft: [row.home_score, row.away_score],
    ht: row.ht_home == null || row.ht_away == null ? null : [row.ht_home, row.ht_away],
    goalOrder: row.goal_order ? JSON.parse(row.goal_order) : null,
    corners: row.home_corners == null || row.away_corners == null ? null : row.home_corners + row.away_corners,
    cards: row.home_cards == null || row.away_cards == null ? null : row.home_cards + row.away_cards,
  };
}

// ── Pre-match expected goals from team strength ratings ─────────
export function lambdasFor(homeStrength = 0, awayStrength = 0) {
  const d = homeStrength - awayStrength;
  return {
    lambda_home: +(1.42 * Math.exp(0.55 * d)).toFixed(3),
    lambda_away: +(1.12 * Math.exp(-0.55 * d)).toFixed(3),
  };
}

// Small cache so list views don't re-price unchanged matches
const cache = new Map();
export function cachedMarkets(row) {
  const key = [row.id, row.status, row.minute, row.home_score, row.away_score, row.ht_home, row.ht_away,
    row.home_corners, row.away_corners, row.home_cards, row.away_cards, row.goal_order,
    (row.suspended_until || 0) > Date.now(), row.last_sync_at && Date.now() - row.last_sync_at > 300000].join('|');
  const hit = cache.get(row.id);
  if (hit && hit.key === key) return hit.markets;
  const markets = priceMarkets(row);
  cache.set(row.id, { key, markets });
  if (cache.size > 2000) cache.delete(cache.keys().next().value);
  return markets;
}
