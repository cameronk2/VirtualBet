// Virtual money ledger (pence). Every balance change goes through credit/debit,
// which write an immutable wallet_tx row with before/after balances.
// There is NO payment, withdrawal or transfer functionality - by design.
import { q, tx } from './db.js';
import { RULES } from './config.js';
import { HttpError, isInt, now } from './util.js';
import { gbp } from './money.js';

function applyChange(userId, type, amount, reference, note) {
  const u = q('SELECT balance FROM users WHERE id = ?').get(userId);
  if (!u) throw new HttpError(404, 'Account not found.');
  const after = u.balance + amount;
  if (after < 0) throw new HttpError(400, 'Insufficient virtual balance.');
  q('UPDATE users SET balance = ? WHERE id = ?').run(after, userId);
  q(`INSERT INTO wallet_tx (user_id, type, amount, balance_before, balance_after, reference, note, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(userId, type, amount, u.balance, after, reference, note, now());
  return after;
}

/** Must be called inside tx(). */
export function credit(userId, type, amount, reference = null, note = null) {
  if (!isInt(amount) || amount < 0) throw new Error('credit amount must be a non-negative integer');
  return applyChange(userId, type, amount, reference, note);
}

/** Must be called inside tx(). */
export function debit(userId, type, amount, reference = null, note = null) {
  if (!isInt(amount) || amount <= 0) throw new Error('debit amount must be a positive integer');
  return applyChange(userId, type, -amount, reference, note);
}

export function freeDeposit(userId, { amount, acknowledged }) {
  if (!(Number.isSafeInteger(amount) && amount >= RULES.depositMin && amount <= RULES.depositMax && amount % RULES.depositStep === 0)) throw new HttpError(400, `Choose a whole-pound amount from ${gbp(RULES.depositMin)} to ${gbp(RULES.depositMax)}.`);
  if (acknowledged !== true) throw new HttpError(400, 'Please confirm you understand this is virtual money with no real value.');
  return tx(() => credit(userId, 'FREE_TOKENS', amount, null, `Free virtual deposit (${gbp(amount)})`));
}

export function dailyBonusStatus(user) {
  const next = user.last_daily_bonus_at ? user.last_daily_bonus_at + RULES.dailyBonusIntervalMs : 0;
  return { available: now() >= next, nextAvailableAt: next > now() ? next : null, amount: RULES.dailyBonus };
}

export function claimDailyBonus(userId) {
  return tx(() => {
    const u = q('SELECT last_daily_bonus_at FROM users WHERE id = ?').get(userId);
    const st = dailyBonusStatus(u);
    if (!st.available) throw new HttpError(400, 'Daily bonus already claimed. Come back later.', { nextAvailableAt: st.nextAvailableAt });
    q('UPDATE users SET last_daily_bonus_at = ? WHERE id = ?').run(now(), userId);
    return credit(userId, 'DAILY_BONUS', RULES.dailyBonus, null, 'Free daily bonus');
  });
}

export function resetWallet(userId, { confirm }) {
  if (confirm !== true) throw new HttpError(400, 'Please confirm the wallet reset.');
  return tx(() => {
    const u = q('SELECT balance FROM users WHERE id = ?').get(userId);
    return applyChange(userId, 'WALLET_RESET', RULES.startingBalance - u.balance, null, `Wallet reset to ${gbp(RULES.startingBalance)}`);
  });
}

export function listTransactions(userId, limit = 50, before = null) {
  const rows = before
    ? q('SELECT * FROM wallet_tx WHERE user_id = ? AND id < ? ORDER BY id DESC LIMIT ?').all(userId, before, limit)
    : q('SELECT * FROM wallet_tx WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit);
  return rows.map((r) => ({
    id: r.id, type: r.type, amount: r.amount, balanceBefore: r.balance_before, balanceAfter: r.balance_after,
    reference: r.reference, note: r.note, createdAt: r.created_at,
  }));
}
