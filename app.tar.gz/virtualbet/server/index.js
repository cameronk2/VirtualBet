import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { config, RULES, ROOT } from './config.js';
import { openDb, q } from './db.js';
import { HttpError, readJson, sendJson, now } from './util.js';
import * as auth from './auth.js';
import * as wallet from './wallet.js';
import { listMatches, getMatch, listLeagues, featuredMatches } from './matches.js';
import { placeBets, quoteSelections, listBets, getBet, effectiveLimit, setDailyLimit, stakedLast24h, cashOutBet, takeBreak } from './bets.js';
import { settlePending } from './settlement.js';
import { userStats, leaderboard, profitSince } from './stats.js';
import { startDemo } from './providers/demo.js';
import * as casino from './casino.js';
import { listAchievements, lifetime, takeUnlocked, award } from './progress.js';
import { CATALOGUE } from './games/registry.js';
import { startLiveData, providerStatus } from './providers/live.js';

openDb(config.databasePath);

const DIST = path.join(ROOT, 'dist');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.mp3': 'audio/mpeg', '.webp': 'image/webp', '.jpg': 'image/jpeg' };

function publicUser(u) {
  const lim = effectiveLimit(u.id);
  const fresh = q('SELECT * FROM users WHERE id = ?').get(u.id);
  return {
    id: fresh.id,
    username: fresh.username,
    balance: fresh.balance,
    createdAt: fresh.created_at,
    dailyBonus: wallet.dailyBonusStatus(fresh),
    dailyStakeLimit: lim.limit,
    pendingStakeLimit: lim.pending,
    pendingLimitAt: lim.pendingAt,
    stakedLast24h: stakedLast24h(fresh.id),
    realityCheckMinutes: fresh.reality_check_minutes,
    breakUntil: fresh.break_until && fresh.break_until > Date.now() ? fresh.break_until : null,
  };
}

// ── Routes ──────────────────────────────────────────────────────
const routes = [];
const route = (method, pattern, handler) => {
  const keys = [];
  const re = new RegExp(`^${pattern.replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)'))}$`);
  routes.push({ method, re, keys, handler });
};

route('GET', '/api/config', () => ({
  appName: 'VirtualBet',
  virtualOnly: true,
  demoEnabled: config.demoEnabled,
  demoSecondsPerMinute: config.demoSecondsPerMinute,
  provider: config.provider,
  providerStatus: config.provider === 'none' ? null : providerStatus,
  rules: { ...RULES },
}));

route('POST', '/api/auth/register', async (req, res) => {
  const body = await readJson(req);
  const id = auth.register(res, body, req.socket.remoteAddress);
  return { user: publicUser({ id }) };
});
route('POST', '/api/auth/login', async (req, res) => {
  const body = await readJson(req);
  const id = auth.login(res, body, req.socket.remoteAddress);
  return { user: publicUser({ id }) };
});
route('POST', '/api/auth/logout', async (req, res) => {
  await readJson(req);
  auth.logout(req, res);
  return { ok: true };
});
route('GET', '/api/me', (req) => {
  const u = auth.userFromRequest(req);
  return { user: u ? publicUser(u) : null };
});
route('PATCH', '/api/me', async (req) => {
  const u = auth.requireUser(req);
  const body = await readJson(req);
  if (body.username !== undefined) auth.changeUsername(u.id, body.username);
  return { user: publicUser(u) };
});

// Matches
route('GET', '/api/matches', (req, res, { query }) => ({
  matches: listMatches({ view: query.get('view') || 'all', league: query.get('league') }),
  serverTime: now(),
}));
route('GET', '/api/matches/featured', () => ({ matches: featuredMatches(), serverTime: now() }));
route('GET', '/api/matches/:id', (req, res, { params }) => {
  const m = getMatch(decodeURIComponent(params.id));
  if (!m) throw new HttpError(404, 'Match not found.');
  return { match: m, serverTime: now() };
});
route('GET', '/api/leagues', () => ({ leagues: listLeagues() }));

// Wallet (virtual money only - no payments, withdrawals or transfers exist)
route('GET', '/api/wallet', (req, res, { query }) => {
  const u = auth.requireUser(req);
  const before = Number(query.get('before')) || null;
  return { user: publicUser(u), transactions: wallet.listTransactions(u.id, 50, before), packages: RULES.depositPackages };
});
route('POST', '/api/wallet/deposit', async (req) => {
  const u = auth.requireUser(req);
  wallet.freeDeposit(u.id, await readJson(req));
  return { user: publicUser(u) };
});
route('POST', '/api/wallet/daily-bonus', async (req) => {
  const u = auth.requireUser(req);
  await readJson(req);
  wallet.claimDailyBonus(u.id);
  return { user: publicUser(u) };
});
route('POST', '/api/wallet/reset', async (req) => {
  const u = auth.requireUser(req);
  wallet.resetWallet(u.id, await readJson(req));
  return { user: publicUser(u) };
});

// Bets
route('POST', '/api/bets', async (req) => {
  const u = auth.requireUser(req);
  const result = placeBets(u.id, await readJson(req));
  return { ...result, user: publicUser(u) };
});
route('POST', '/api/bets/quote', async (req) => {
  const body = await readJson(req);
  return { quotes: quoteSelections(body.selections) };
});
route('GET', '/api/bets', (req, res, { query }) => {
  const u = auth.requireUser(req);
  return { bets: listBets(u.id, query.get('status') || 'all', Math.min(500, Number(query.get('limit')) || 200)) };
});
route('POST', '/api/bets/:ref/cashout', async (req, res, { params }) => {
  const u = auth.requireUser(req);
  const body = await readJson(req);
  const r = cashOutBet(u.id, decodeURIComponent(params.ref), body.value);
  return { ...r, user: publicUser(auth.requireUser(req)) };
});
route('GET', '/api/bets/:ref', (req, res, { params }) => {
  const u = auth.requireUser(req);
  const b = getBet(u.id, decodeURIComponent(params.ref));
  if (!b) throw new HttpError(404, 'Bet not found.');
  return { bet: b };
});

// Stats & leaderboard
route('GET', '/api/stats', (req, res, { query }) => {
  const u = auth.requireUser(req);
  const since = Number(query.get('sessionStart')) || null;
  return { stats: userStats(u.id), session: since ? profitSince(u.id, since) : null };
});
route('GET', '/api/leaderboard', (req) => {
  const u = auth.userFromRequest(req);
  return { rows: leaderboard(u?.id) };
});

// Blackjack (virtual money)
route('GET', '/api/blackjack', (req) => {
  const u = auth.requireUser(req);
  return { ...casino.getTable(u.id), user: publicUser(u) };
});
route('POST', '/api/blackjack/deal', async (req) => {
  const u = auth.requireUser(req);
  return { ...casino.deal(u.id, await readJson(req)), user: publicUser(u) };
});
route('POST', '/api/blackjack/action', async (req) => {
  const u = auth.requireUser(req);
  return { ...casino.action(u.id, await readJson(req)), user: publicUser(u) };
});

route('GET', '/api/spin21', (req) => {
  const u = auth.requireUser(req);
  return { ...casino.getTable(u.id, 'spin21'), user: publicUser(u) };
});
route('POST', '/api/spin21/deal', async (req) => {
  const u = auth.requireUser(req);
  return { ...casino.deal(u.id, await readJson(req), 'spin21'), user: publicUser(u) };
});
route('POST', '/api/spin21/action', async (req) => {
  const u = auth.requireUser(req);
  return { ...casino.action(u.id, await readJson(req), 'spin21'), user: publicUser(u) };
});

route('GET', '/api/casino', () => ({ catalogue: CATALOGUE }));
route('GET', '/api/casino/:game', (req, res, { params }) => {
  const u = auth.requireUser(req);
  return { ...casino.getCasino(u.id, params.game), user: publicUser(u) };
});
route('POST', '/api/casino/:game/:action', async (req, res, { params }) => {
  const u = auth.requireUser(req);
  return { ...casino.playCasino(u.id, params.game, params.action, await readJson(req)), user: publicUser(u) };
});
route('GET', '/api/achievements', (req) => listAchievements(auth.requireUser(req).id));
route('POST', '/api/achievements/event', async (req) => {
  const u = auth.requireUser(req);
  const body = await readJson(req);
  if (body?.t === 'hint') award(u.id, [{ t: 'hint' }]);
  return { ok: true };
});
route('GET', '/api/lifetime', (req) => lifetime(auth.requireUser(req).id));

route('GET', '/api/slots', (req) => {
  const u = auth.requireUser(req);
  return { ...casino.getSlots(u.id), user: publicUser(u) };
});
route('POST', '/api/slots/spin', async (req) => {
  const u = auth.requireUser(req);
  return { ...casino.slotsSpin(u.id, await readJson(req)), user: publicUser(u) };
});

// Responsible play settings
route('PUT', '/api/settings', async (req) => {
  const u = auth.requireUser(req);
  const body = await readJson(req);
  let limitResult = null;
  if (body.dailyStakeLimit !== undefined) limitResult = setDailyLimit(u.id, body.dailyStakeLimit);
  if (body.realityCheckMinutes !== undefined) {
    const m = body.realityCheckMinutes;
    if (![0, 15, 30, 45, 60, 90, 120].includes(m)) throw new HttpError(400, 'Invalid reality-check interval.');
    q('UPDATE users SET reality_check_minutes = ? WHERE id = ?').run(m, u.id);
  }
  if (body.takeBreakHours !== undefined) takeBreak(u.id, body.takeBreakHours);
  return { user: publicUser(u), limitResult };
});

// ── Server ──────────────────────────────────────────────────────
function serveStatic(req, res, pathname) {
  let file = path.join(DIST, path.normalize(pathname).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(DIST)) file = DIST;
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(DIST, 'index.html'); // SPA fallback
  if (!fs.existsSync(file)) {
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    return res.end('Frontend not built. Run "npm run build" first.');
  }
  const ext = path.extname(file);
  const immutable = /\/assets\//.test(file);
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': immutable ? 'public, max-age=31536000, immutable' : 'no-cache',
    'X-Content-Type-Options': 'nosniff',
  });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  if (!url.pathname.startsWith('/api/')) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'Method not allowed' });
    return serveStatic(req, res, url.pathname);
  }
  try {
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = r.re.exec(url.pathname);
      if (!m) continue;
      const params = Object.fromEntries(r.keys.map((k, i) => [k, m[i + 1]]));
      const out = await r.handler(req, res, { params, query: url.searchParams });
      if (out && typeof out === 'object') {
        const u = auth.userFromRequest(req);
        const unlocked = u ? takeUnlocked(u.id) : null;
        if (unlocked) out.unlocked = unlocked;
      }
      return sendJson(res, 200, out);
    }
    throw new HttpError(404, 'Not found');
  } catch (e) {
    if (e instanceof HttpError) return sendJson(res, e.status, { error: e.message, ...(e.extra || {}) });
    console.error(e);
    return sendJson(res, 500, { error: 'Something went wrong. Please try again.' });
  }
});

// Background jobs
if (config.demoEnabled) startDemo();
startLiveData();
setInterval(() => {
  try { settlePending(); } catch (e) { console.error('[settlement] failed', e); }
}, 3000);
setInterval(() => auth.purgeExpiredSessions(), 3600000);

server.listen(config.port, () => {
  console.log(`\n  VirtualBet running at http://localhost:${config.port}`);
  console.log('  VIRTUAL PLAY ONLY - NO REAL MONEY INVOLVED\n');
});
