// Pure match serialisation shared by the server and the in-browser build.
import { cachedMarkets, LIVE_STATUSES, phaseOf } from './markets.js';

export function minuteLabel(row) {
  const m = row.minute;
  switch (row.status) {
    case 'SCHEDULED': return null;
    case 'HT': return 'HT';
    case 'IN_PLAY_PENDING': return 'In play';
    case 'FINISHED': return 'FT';
    case 'ABANDONED': return 'Abandoned';
    case 'CANCELLED': return 'Cancelled';
    case 'POSTPONED': return 'Postponed';
    case 'SUSPENDED': return 'Suspended';
    default:
      if (m == null) return 'Live';
      if (row.status === 'LIVE_1H' && m > 45) return `45+${m - 45}'`;
      if (row.status === 'LIVE_2H' && m > 90) return `90+${m - 90}'`;
      return `${m}'${row.minute_estimated ? ' (est.)' : ''}`;
  }
}

export function serializeMatch(row, { full = false } = {}) {
  const markets = cachedMarkets(row);
  const started = row.status !== 'SCHEDULED' && row.status !== 'POSTPONED' && row.status !== 'CANCELLED';
  const out = {
    id: row.id,
    source: row.source,
    simulated: row.source === 'demo',
    real: row.source === 'real',
    lastUpdate: row.last_sync_at ?? null,
    league: { code: row.league_code, name: row.league_name, country: row.country },
    home: { name: row.home_name, short: row.home_short, crest: row.home_crest, color: row.home_color },
    away: { name: row.away_name, short: row.away_short, crest: row.away_crest, color: row.away_color },
    kickoff: row.kickoff_at,
    status: row.status,
    phase: phaseOf(row.status, row.minute),
    live: LIVE_STATUSES.includes(row.status),
    minute: row.minute,
    minuteLabel: minuteLabel(row),
    score: started && row.home_score != null ? { home: row.home_score, away: row.away_score } : null,
    ht: row.ht_home != null ? { home: row.ht_home, away: row.ht_away } : null,
    corners: row.home_corners != null ? { home: row.home_corners, away: row.away_corners } : null,
    cards: row.home_cards != null ? { home: row.home_cards, away: row.away_cards } : null,
    suspended: markets.some((m) => m.suspended),
    bettingOpen: markets.length > 0,
    marketCount: markets.length,
    oddsSimulated: true,
  };
  if (full) {
    out.markets = markets;
    out.events = row.events ? JSON.parse(row.events) : [];
    out.lastSyncAt = row.last_sync_at;
  } else {
    const pick = (k) => markets.find((m) => m.key === k) || null;
    out.quick = { '1X2': pick('1X2'), BTTS: pick('BTTS'), OU25: pick('OU25') };
  }
  return out;
}

