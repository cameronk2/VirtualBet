// Development: rebuild the frontend on change and restart the server on change.
// Works on Windows, macOS and Linux (no shell "&" needed).
import { spawn } from 'node:child_process';

const run = (args) => spawn(process.execPath, args, { stdio: 'inherit' });
const children = [
  run(['build.mjs', '--watch']),
  run(['--disable-warning=ExperimentalWarning', '--watch-path=server', 'server/index.js']),
];
const stop = () => { children.forEach((c) => c.kill()); process.exit(0); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
