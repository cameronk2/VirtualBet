// Deletes the SQLite database so a fresh one is created on next start.
import fs from 'node:fs';
import { config } from '../config.js';

for (const suffix of ['', '-wal', '-shm']) {
  const f = config.databasePath + suffix;
  if (fs.existsSync(f)) fs.rmSync(f);
}
console.log(`Database removed: ${config.databasePath}\nA new empty database will be created the next time you run "npm start".`);
