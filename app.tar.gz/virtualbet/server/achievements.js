// Achievements: badges only. They carry no prizes or bonuses, and there
// are no streaks or daily targets - nothing that rewards playing more or
// more often. Several reward safer play or learning the games.

export const ACHIEVEMENTS = [
  { id: 'kickoff', name: 'Kick-off', desc: 'Place your first sports bet', group: 'Sports' },
  { id: 'acca', name: 'Acca hero', desc: 'Win an accumulator with 3 or more legs', group: 'Sports' },
  { id: 'longshot', name: 'Long shot', desc: 'Win a bet at odds of 10.00 or bigger', group: 'Sports' },
  { id: 'natural', name: 'Natural', desc: 'Get a blackjack', group: 'Tables' },
  { id: 'split', name: 'Split decision', desc: 'Split a pair in blackjack', group: 'Tables' },
  { id: 'wheel', name: 'Round and round', desc: 'Trigger the Spin 21 bonus wheel', group: 'Tables' },
  { id: 'grand', name: 'Grand slam', desc: 'Land GRAND on the Spin 21 wheel', group: 'Tables' },
  { id: 'nose', name: 'On the nose', desc: 'Win a straight-up roulette bet', group: 'Tables' },
  { id: 'tie', name: 'Tie breaker', desc: 'Win a Tie bet in baccarat', group: 'Tables' },
  { id: 'flush', name: 'Running hot', desc: 'Get a straight flush in Three Card Poker', group: 'Tables' },
  { id: 'bonus', name: 'Bonus round', desc: 'Trigger free spins or Hold & Spin on any slot', group: 'Slots' },
  { id: 'bigcatch', name: 'Big catch', desc: 'Win 50x your stake or more on one slot spin', group: 'Slots' },
  { id: 'vaultfull', name: 'Full vault', desc: 'Fill all 15 spaces in Coin Vault', group: 'Slots' },
  { id: 'rocket', name: 'Rocket rider', desc: 'Cash out at 10x or more in Crash', group: 'Instant' },
  { id: 'edge', name: 'Edge of the board', desc: 'Land in an edge slot in Plinko', group: 'Instant' },
  { id: 'ticket', name: 'Lucky ticket', desc: 'Win 100x or more on a scratchcard', group: 'Instant' },
  { id: 'tourist', name: 'Tourist', desc: 'Try 8 different games', group: 'Explorer' },
  { id: 'control', name: 'In control', desc: 'Set a daily stake limit', group: 'Play safely' },
  { id: 'strategy', name: 'By the book', desc: 'Turn on the blackjack strategy hint', group: 'Play safely' },
];

/** Applies game events to the saved progress; returns newly unlocked badges. */
export function track(progress, events, now = Date.now()) {
  const p = progress || {};
  p.unlocked = p.unlocked || {};
  p.played = p.played || [];
  const unlock = [];
  const give = (id) => { if (!p.unlocked[id]) { p.unlocked[id] = now; unlock.push(ACHIEVEMENTS.find((a) => a.id === id)); } };
  for (const e of events || []) {
    if (!e) continue;
    if (e.t === 'played' && e.game && !p.played.includes(e.game)) { p.played.push(e.game); if (p.played.length >= 8) give('tourist'); }
    if (e.t === 'sportsBet') give('kickoff');
    if (e.t === 'sportsWin') { if (e.legs >= 3) give('acca'); if (e.odds >= 1000) give('longshot'); }
    if (e.t === 'blackjack') { if (e.natural) give('natural'); if (e.split) give('split'); if (e.wheel) give('wheel'); if (e.grand) give('grand'); }
    if (e.t === 'roulette' && e.straightWin) give('nose');
    if (e.t === 'baccarat' && e.tieWin) give('tie');
    if (e.t === 'threecard' && e.cat === 'straightFlush') give('flush');
    if (e.t === 'slot') { if (e.x >= 50) give('bigcatch'); if (e.feature) give('bonus'); if (e.full) give('vaultfull'); }
    if (e.t === 'crash' && e.cashedAt >= 10) give('rocket');
    if (e.t === 'plinko' && (e.slot === 0 || e.slot === 12)) give('edge');
    if (e.t === 'scratch' && e.mult >= 100) give('ticket');
    if (e.t === 'limit') give('control');
    if (e.t === 'hint') give('strategy');
  }
  return unlock.filter(Boolean);
}

/** Which product a wallet transaction belongs to (for the cost panel). */
export function productOf(tx) {
  if (tx.type.startsWith('BET_')) return 'sports';
  if (tx.type.startsWith('CASINO_')) return tx.reference || 'casino';
  if (tx.type.startsWith('BLACKJACK_')) return tx.reference === 'spin21' ? 'spin21' : 'blackjack';
  if (tx.type.startsWith('SLOTS_')) return 'lakeside';
  return null;
}
export const isStakeTx = (t) => ['BET_STAKE', 'BLACKJACK_BET', 'SLOTS_BET', 'CASINO_BET'].includes(t);
export const isReturnTx = (t) => ['BET_WINNINGS', 'BET_VOID_REFUND', 'BET_CASHOUT', 'BLACKJACK_WIN', 'SLOTS_WIN', 'CASINO_WIN'].includes(t);
