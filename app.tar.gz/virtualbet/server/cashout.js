// Cash Out (virtual money). Shared by the server and the phone build.
//
// Value = stake x (odds taken on every non-void leg) / (current odds of
// each leg still open) x 95%. Legs already won count at current odds 1.00.
// It is only offered while every open leg can be priced right now, so for
// real fixtures (no live data) Cash Out closes at kick-off; simulated
// matches can be cashed out in-play. Never more than the potential return.

export const CASHOUT_MARGIN = 0.95;

/**
 * @param stake integer pence
 * @param potential integer pence (potential return)
 * @param legs [{ odds (x100 taken), status, current: { odds, suspended } | null }]
 */
export function cashOutValue(stake, potential, legs) {
  if (legs.some((l) => l.status === 'LOST')) return { available: false, reason: 'A selection has lost' };
  const open = legs.filter((l) => l.status === 'OPEN');
  if (!open.length) return { available: false, reason: 'Settling now' };
  for (const l of open) {
    if (!l.current?.odds) return { available: false, reason: 'Not available once a real match has kicked off or the market has closed' };
    if (l.current.suspended) return { available: false, reason: 'Suspended for a moment' };
  }
  let ratio = 1;
  for (const l of legs) {
    if (l.status === 'VOID') continue;
    ratio *= l.odds / 100;
    if (l.status === 'OPEN') ratio /= l.current.odds / 100;
  }
  const raw = Math.floor(stake * ratio * CASHOUT_MARGIN);
  const value = Math.max(1, Math.min(raw, Number(potential) - 1));
  return { available: true, value };
}

/** Current price of each leg, using a `priceMarkets`-style pricer per match row. */
export function currentLegs(sels, rowFor, priceMarkets) {
  const priced = new Map();
  return sels.map((s) => {
    if (s.status !== 'OPEN') return { odds: s.odds, status: s.status, current: null };
    const row = rowFor(s.matchId);
    if (!row) return { odds: s.odds, status: s.status, current: null };
    if (!priced.has(row.id)) priced.set(row.id, priceMarkets(row));
    const market = priced.get(row.id).find((m) => m.key === s.marketKey);
    const sel = market?.selections.find((x) => x.key === s.selectionKey);
    return { odds: s.odds, status: s.status, current: sel?.odds ? { odds: sel.odds, suspended: !!market.suspended } : null };
  });
}
