// Blackjack against the house with the virtual wallet. All validation and
// the hidden dealer card stay on the server.
import crypto from 'node:crypto';
import { q, tx } from './db.js';
import { RULES } from './config.js';
import { HttpError, isInt, now } from './util.js';
import { credit, debit } from './wallet.js';
import { gbp } from './money.js';
import { act, extraStake, hint, MAX_SEATS, publicView, startRound } from './blackjack.js';
import { spin as slotSpin } from './slots.js';
import { GAMES, GameError, runGame } from './games/registry.js';
import { NO_LIMIT, TABLE_GAMES } from './games/common.js';
import { award } from './progress.js';
import { checkBreak, effectiveLimit, stakedLast24h } from './bets.js';

const rand = () => crypto.randomInt(0, 2 ** 32) / 2 ** 32;

function load(userId, game = 'blackjack') {
  const r = q(`SELECT hand, history FROM ${game} WHERE user_id = ?`).get(userId);
  const st = { hand: r?.hand ? JSON.parse(r.hand) : null, history: r ? JSON.parse(r.history) : [] };
  if (st.hand && st.hand.v !== 2) {
    // Unfinished hand from the older single-hand version: refund it
    if (st.hand.status === 'player' && !st.hand.paid) credit(userId, 'BLACKJACK_WIN', st.hand.totalStake, null, 'Blackjack - unfinished hand refunded after update');
    st.hand = null;
    st.history = st.history.map((x) => (x.staked == null ? { at: x.at, staked: x.stake, payout: x.payout, hands: 1 } : x));
  }
  return st;
}
function store(userId, st, game = 'blackjack') {
  q(`INSERT INTO ${game} (user_id, hand, history) VALUES (?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET hand = excluded.hand, history = excluded.history`)
    .run(userId, JSON.stringify(st.hand), JSON.stringify(st.history.slice(0, 20)));
}
function finish(userId, st, game = 'blackjack') {
  const h = st.hand;
  if (!h || h.status !== 'done' || h.paid) return;
  if (h.totalPayout > 0) credit(userId, 'BLACKJACK_WIN', h.totalPayout, game, `${game === 'spin21' ? 'Spin 21' : 'Blackjack'} return`);
  award(userId, [{ t: 'played', game }, {
    t: 'blackjack',
    natural: h.seats.some((x) => x.hands.some((hh) => hh.result === 'blackjack')),
    split: h.seats.some((x) => x.hands.length > 1),
    wheel: h.seats.some((x) => x.side?.spin?.result === 'wheel'),
    grand: h.seats.some((x) => x.side?.spin?.result === 'wheel' && x.side.spin.x >= 150),
  }]);
  h.paid = true;
  st.history.unshift({ at: now(), staked: h.totalStaked, payout: h.totalPayout, hands: h.seats.reduce((a, x) => a + x.hands.length, 0) });
}
const out = (st) => ({ round: publicView(st.hand), hint: hint(st.hand), history: st.history.slice(0, 20) });

const BJ_TABLES = new Set(['blackjack', 'spin21']);
const gameOf = (g) => { if (!BJ_TABLES.has(g)) throw new HttpError(404, 'Unknown table.'); return g; };

export function getTable(userId, game = 'blackjack') {
  gameOf(game);
  return tx(() => { const st = load(userId, game); store(userId, st, game); return out(st); });
}

export function deal(userId, { seats }, game = 'blackjack') {
  gameOf(game);
  return tx(() => {
    const st = load(userId, game);
    if (st.hand && st.hand.status === 'player') throw new HttpError(400, 'Finish the current round first.');
    if (!Array.isArray(seats) || seats.length < 1 || seats.length > MAX_SEATS) throw new HttpError(400, `Play 1 to ${MAX_SEATS} hands.`);
    for (const x of seats) {
      if (!isInt(x?.bet) || x.bet < RULES.minStake) throw new HttpError(400, `Minimum bet is ${gbp(RULES.minStake)} per hand.`);
      if (game === 'spin21') {
        if ((x.pp || 0) || (x.t213 || 0)) throw new HttpError(400, 'Spin 21 only has the Spin side bet.');
        if (x.spin && x.spin !== x.bet) throw new HttpError(400, 'The Spin bet must match your main bet.');
      } else {
        if (x.spin) throw new HttpError(400, 'The Spin bet is only on the Spin 21 table.');
        for (const k of ['pp', 't213']) {
          const v = x[k] || 0;
          if (!isInt(v) || v < 0 || (v > 0 && v < RULES.minStake)) throw new HttpError(400, `Side bets must be at least ${gbp(RULES.minStake)}.`);
        }
      }
    }
    const total = seats.reduce((a, x) => a + x.bet + (x.pp || 0) + (x.t213 || 0) + (x.spin || 0), 0);
    checkBreak(userId);
    const { limit } = effectiveLimit(userId);
    if (limit !== null && stakedLast24h(userId) + total > limit) throw new HttpError(400, 'This would exceed your daily stake limit.');
    debit(userId, 'BLACKJACK_BET', total, game, `${game === 'spin21' ? 'Spin 21' : 'Blackjack'} - ${seats.length} hand${seats.length > 1 ? 's' : ''}`);
    st.hand = startRound(seats.map((x) => ({ bet: x.bet, pp: x.pp || 0, t213: x.t213 || 0, spin: x.spin || 0 })), rand);
    finish(userId, st, game);
    store(userId, st, game);
    return out(st);
  });
}

export function action(userId, { action: a }, game = 'blackjack') {
  gameOf(game);
  return tx(() => {
    const st = load(userId, game);
    const h = st.hand;
    if (!h || h.status !== 'player') throw new HttpError(400, 'Deal a new round first.');
    let extra = 0;
    try { extra = extraStake(h, a); act(h, a); } catch (e) { throw new HttpError(400, e.message); }
    if (extra) debit(userId, 'BLACKJACK_BET', extra, game, a === 'split' ? 'Blackjack split' : 'Blackjack double down');
    finish(userId, st, game);
    store(userId, st, game);
    return out(st);
  });
}

// ── Slots ──
function loadSlots(userId) {
  const r = q('SELECT free, history FROM slots WHERE user_id = ?').get(userId);
  return { free: r?.free ? JSON.parse(r.free) : null, history: r ? JSON.parse(r.history) : [] };
}
export function getSlots(userId) {
  return loadSlots(userId);
}
export function slotsSpin(userId, { stake }) {
  return tx(() => {
    const st = loadSlots(userId);
    const free = st.free;
    let bet;
    if (free) bet = free.bet;
    else {
      bet = stake;
      if (!isInt(bet) || bet < RULES.minStake) throw new HttpError(400, `Minimum spin is ${gbp(RULES.minStake)}.`);
      if (bet > 10000) throw new HttpError(400, `Maximum spin is ${gbp(10000)}.`);
      checkBreak(userId);
      const { limit } = effectiveLimit(userId);
      if (limit !== null && stakedLast24h(userId) + bet > limit) throw new HttpError(400, 'This would exceed your daily stake limit.');
      debit(userId, 'SLOTS_BET', bet, null, 'Lakeside Lures spin');
    }
    const r = slotSpin(bet, rand, free);
    if (r.win > 0) credit(userId, 'SLOTS_WIN', r.win, null, free ? 'Lakeside Lures free spin win' : 'Lakeside Lures win');
    award(userId, [{ t: 'played', game: 'lakeside' }, { t: 'slot', game: 'lakeside', x: r.win / bet, feature: !!r.trigger?.freeSpins }]);
    st.free = r.free && !r.free.ended ? r.free : null;
    const finished = r.free?.ended ? { totalWin: r.free.totalWin, spins: r.free.spinsPlayed } : null;
    if (!free || finished) st.history.unshift({ at: now(), bet, win: finished ? finished.totalWin : r.win, free: !!finished });
    q(`INSERT INTO slots (user_id, free, history) VALUES (?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET free = excluded.free, history = excluded.history`)
      .run(userId, JSON.stringify(st.free), JSON.stringify(st.history.slice(0, 20)));
    return { result: r, staked: free ? 0 : bet, free: st.free, finished, history: st.history.slice(0, 20) };
  });
}

// ── Shared casino games (roulette, baccarat, poker, crash, plinko, scratchcards, new slots) ──
function loadGame(userId, id) {
  const r = q('SELECT state, history FROM casino_state WHERE user_id = ? AND game = ?').get(userId, id);
  return r ? { state: JSON.parse(r.state), history: JSON.parse(r.history) } : { state: GAMES[id].init(), history: [] };
}
export function getCasino(userId, id) {
  if (!GAMES[id]) throw new HttpError(404, 'Unknown game.');
  const g = loadGame(userId, id);
  return { view: GAMES[id].view(g.state, now()), history: g.history };
}
export function playCasino(userId, id, action, body) {
  if (!GAMES[id]) throw new HttpError(404, 'Unknown game.');
  return tx(() => {
    const g = loadGame(userId, id);
    let r;
    try { r = runGame(id, g.state, action, body, { rand, now: now(), minStake: RULES.minStake, maxStake: TABLE_GAMES.has(id) ? NO_LIMIT : RULES.maxStake }); }
    catch (e) { if (e instanceof GameError) throw new HttpError(400, e.message); throw e; }
    if (r.stake) {
      checkBreak(userId);
      const { limit } = effectiveLimit(userId);
      if (limit !== null && stakedLast24h(userId) + r.stake > limit) throw new HttpError(400, 'This would exceed your daily stake limit.');
      debit(userId, 'CASINO_BET', r.stake, id, GAMES[id].label);
    }
    if (r.payout > 0) credit(userId, 'CASINO_WIN', r.payout, id, `${GAMES[id].label} win`);
    g.state = r.state;
    if (r.settled && (r.settled.staked || r.settled.payout)) g.history = [{ at: now(), staked: r.settled.staked, payout: r.settled.payout }, ...g.history].slice(0, 30);
    q(`INSERT INTO casino_state (user_id, game, state, history) VALUES (?, ?, ?, ?)
       ON CONFLICT(user_id, game) DO UPDATE SET state = excluded.state, history = excluded.history`).run(userId, id, JSON.stringify(g.state), JSON.stringify(g.history));
    award(userId, [{ t: 'played', game: id }, ...(r.events || [])]);
    return { out: { ...r.out, staked: r.stake }, view: GAMES[id].view(g.state, now()), history: g.history };
  });
}
