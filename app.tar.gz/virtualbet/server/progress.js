// Server-side achievements (badges only) and lifetime totals.
import { q } from './db.js';
import { ACHIEVEMENTS, isReturnTx, isStakeTx, productOf, track } from './achievements.js';
import { CATALOGUE } from './games/registry.js';

const pending = new Map(); // userId -> newly unlocked badges not yet shown

export function award(userId, events) {
  const row = q('SELECT data FROM progress WHERE user_id = ?').get(userId);
  const p = row ? JSON.parse(row.data) : {};
  const got = track(p, events);
  q(`INSERT INTO progress (user_id, data) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data`).run(userId, JSON.stringify(p));
  if (got.length) pending.set(userId, [...(pending.get(userId) || []), ...got]);
  return got;
}

export function takeUnlocked(userId) {
  const list = pending.get(userId);
  if (!list?.length) return null;
  pending.delete(userId);
  return list;
}

export function listAchievements(userId) {
  const row = q('SELECT data FROM progress WHERE user_id = ?').get(userId);
  const p = row ? JSON.parse(row.data) : {};
  return { achievements: ACHIEVEMENTS.map((a) => ({ ...a, unlockedAt: p.unlocked?.[a.id] || null })), played: (p.played || []).length };
}

export function lifetime(userId) {
  const rows = q('SELECT type, reference, SUM(amount) AS total FROM wallet_tx WHERE user_id = ? GROUP BY type, reference').all(userId);
  const by = {};
  for (const r of rows) {
    const prod = productOf({ type: r.type, reference: r.reference });
    if (!prod) continue;
    const x = by[prod] || (by[prod] = { staked: 0, returned: 0 });
    if (isStakeTx(r.type)) x.staked -= r.total;
    if (isReturnTx(r.type)) x.returned += r.total;
  }
  const products = Object.entries(by).map(([id, v]) => ({ id, name: CATALOGUE.find((c) => c.id === id)?.name || (id === 'sports' ? 'Sports betting' : id), ...v, net: v.returned - v.staked }));
  const staked = products.reduce((a, x) => a + x.staked, 0), returned = products.reduce((a, x) => a + x.returned, 0);
  const u = q('SELECT created_at FROM users WHERE id = ?').get(userId);
  return { products: products.sort((a, b) => b.staked - a.staked), staked, returned, net: returned - staked, since: u?.created_at };
}
