// Blackjack engine v2 (pure; shared by the server and the in-browser build).
//
// Rules: 6 decks shuffled fresh each round, up to 3 seats (hands) per
// round, dealer peeks for blackjack with an Ace or 10 showing, dealer
// stands on all 17s, blackjack pays 3:2, double on any first two cards
// (including after a split), split any two equal-value cards up to 4
// hands per seat, split Aces receive one card each. Side bets: Perfect
// Pairs and 21+3. All amounts are integer pence (virtual money).
//
// Every card dealt is recorded as an event so clients can animate the
// round in the exact order it happened.

const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const SUITS = ['S', 'H', 'D', 'C'];
export const MAX_SEATS = 3;
export const MAX_HANDS_PER_SEAT = 4;
export const PP_PAYS = { perfect: 25, coloured: 12, mixed: 6 };
export const T213_PAYS = { suitedTrips: 100, straightFlush: 40, trips: 30, straight: 10, flush: 5 };

// ── SPIN 21 side bet (separate table) ──
// Must equal the main bet. Blackjack on the first two cards spins the
// wheel; an Ace without blackjack returns the spin bet (Ace Saver). Each
// of the 24 segments is equally likely. Numbers pay X:1 on the spin bet;
// RESPIN spins again at double value. Long-run return about 95%.
export const WHEEL = [
  { x: 4 }, { x: 8 }, { x: 5 }, { x: 150, label: 'GRAND' }, { x: 4 }, { x: 6 },
  { x: 5 }, { x: 10 }, { x: 4 }, { x: 30, label: 'MINI' }, { x: 5 }, { x: 8 },
  { x: 4 }, { respin: true }, { x: 6 }, { x: 5 }, { x: 12 }, { x: 4 },
  { x: 75, label: 'MAJOR' }, { x: 8 }, { x: 5 }, { x: 6 }, { x: 4 }, { x: 8 },
];
export const SPIN_ACE_PAYS = 0; // stake returned
function spinWheel(rand) {
  const spins = [];
  let mult = 1;
  for (let i = 0; i < 6; i++) {
    const idx = Math.floor(rand() * WHEEL.length);
    spins.push(idx);
    if (!WHEEL[idx].respin) return { spins, mult, x: WHEEL[idx].x * mult };
    mult *= 2;
  }
  return { spins, mult, x: 10 * mult }; // extremely unlikely chain: settle on the base prize
}

export function newShoe(rand, decks = 6) {
  const shoe = [];
  for (let d = 0; d < decks; d++) for (const s of SUITS) for (const r of RANKS) shoe.push(r + s);
  for (let i = shoe.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [shoe[i], shoe[j]] = [shoe[j], shoe[i]];
  }
  return shoe.slice(0, 80); // plenty for 3 seats with splits
}

const rankOf = (c) => c.slice(0, -1);
const suitOf = (c) => c.slice(-1);
const tenValue = (r) => ['10', 'J', 'Q', 'K'].includes(r);
const cardValue = (c) => { const r = rankOf(c); return r === 'A' ? 11 : tenValue(r) ? 10 : Number(r); };

export function handValue(cards) {
  let total = 0, aces = 0;
  for (const c of cards) {
    if (rankOf(c) === 'A') aces++;
    total += cardValue(c);
  }
  while (total > 21 && aces) { total -= 10; aces--; }
  return { total, soft: aces > 0 };
}
const isNatural = (h) => h.cards.length === 2 && !h.split && handValue(h.cards).total === 21;

// ── Side bets ──
export function perfectPairs(c1, c2) {
  if (rankOf(c1) !== rankOf(c2)) return null;
  if (suitOf(c1) === suitOf(c2)) return 'perfect';
  const red = (s) => s === 'H' || s === 'D';
  return red(suitOf(c1)) === red(suitOf(c2)) ? 'coloured' : 'mixed';
}
export function twentyOnePlus3(cards) {
  const idx = cards.map((c) => RANKS.indexOf(rankOf(c))).sort((a, b) => a - b);
  const flush = cards.every((c) => suitOf(c) === suitOf(cards[0]));
  const trips = idx[0] === idx[1] && idx[1] === idx[2];
  const consecutive = (a) => a[1] === a[0] + 1 && a[2] === a[1] + 1;
  const straight = !trips && (consecutive(idx) || (idx[0] === 0 && idx[1] === 11 && idx[2] === 12)); // Q-K-A
  if (trips && flush) return 'suitedTrips';
  if (straight && flush) return 'straightFlush';
  if (trips) return 'trips';
  if (straight) return 'straight';
  if (flush) return 'flush';
  return null;
}

// ── Round lifecycle ──
/** seats: [{ bet, pp, t213 }] (pence; side bets may be 0) */
export function startRound(seatBets, rand) {
  const shoe = newShoe(rand);
  const s = {
    v: 2, shoe, dealer: [], events: [], status: 'player', active: null,
    seats: seatBets.map((b) => ({ bet: b.bet, pp: b.pp || 0, t213: b.t213 || 0, spin: b.spin || 0, hands: [{ cards: [], bet: b.bet, doubled: false, done: false, split: false, splitAces: false, result: null, payout: 0 }], side: {} })),
    totalStaked: seatBets.reduce((a, b) => a + b.bet + (b.pp || 0) + (b.t213 || 0) + (b.spin || 0), 0),
    totalPayout: 0,
  };
  const draw = () => s.shoe.pop();
  for (let round = 0; round < 2; round++) {
    s.seats.forEach((seat, i) => {
      const c = draw();
      seat.hands[0].cards.push(c);
      s.events.push({ t: 'card', seat: i, hand: 0, card: c });
    });
    const d = draw();
    s.dealer.push(d);
    s.events.push({ t: 'dealer', card: d, hole: round === 1 });
  }
  // Side bets settle straight after the deal
  s.seats.forEach((seat) => {
    const [a, b] = seat.hands[0].cards;
    if (seat.pp) { const k = perfectPairs(a, b); seat.side.pp = { result: k, payout: k ? seat.pp * (PP_PAYS[k] + 1) : 0 }; }
    if (seat.t213) { const k = twentyOnePlus3([a, b, s.dealer[0]]); seat.side.t213 = { result: k, payout: k ? seat.t213 * (T213_PAYS[k] + 1) : 0 }; }
    if (seat.spin) {
      if (handValue([a, b]).total === 21) {
        const w = spinWheel(rand);
        seat.side.spin = { result: 'wheel', ...w, payout: seat.spin * (w.x + 1) };
      } else if (rankOf(a) === 'A' || rankOf(b) === 'A') seat.side.spin = { result: 'ace', payout: seat.spin * (SPIN_ACE_PAYS + 1) };
      else seat.side.spin = { result: null, payout: 0 };
    }
  });
  // Naturals are finished; dealer peeks with an Ace or 10-value up card
  s.seats.forEach((seat) => { if (isNatural(seat.hands[0])) seat.hands[0].done = true; });
  const up = rankOf(s.dealer[0]);
  const dealerBJ = handValue(s.dealer).total === 21;
  if ((up === 'A' || tenValue(up)) && dealerBJ) {
    s.seats.forEach((seat) => { seat.hands[0].done = true; });
    s.dealerPeekBJ = true;
  }
  advance(s);
  return s;
}

function nextActive(s) {
  for (let i = 0; i < s.seats.length; i++) {
    for (let h = 0; h < s.seats[i].hands.length; h++) if (!s.seats[i].hands[h].done) return { seat: i, hand: h };
  }
  return null;
}

function advance(s) {
  s.active = nextActive(s);
  if (!s.active) finishRound(s);
}

function finishRound(s) {
  const draw = () => s.shoe.pop();
  s.events.push({ t: 'reveal', card: s.dealer[1] });
  const live = s.seats.some((seat) => seat.hands.some((h) => handValue(h.cards).total <= 21 && !isNatural(h)));
  if (live && !s.dealerPeekBJ) {
    while (handValue(s.dealer).total < 17) {
      const c = draw();
      s.dealer.push(c);
      s.events.push({ t: 'dealer', card: c });
    }
  }
  const d = handValue(s.dealer).total;
  const dBJ = s.dealer.length === 2 && d === 21;
  let total = 0;
  for (const seat of s.seats) {
    for (const h of seat.hands) {
      const p = handValue(h.cards).total;
      const nat = isNatural(h);
      if (nat && dBJ) { h.result = 'push'; h.payout = h.bet; }
      else if (nat) { h.result = 'blackjack'; h.payout = h.bet + Math.floor((h.bet * 3) / 2); }
      else if (dBJ) { h.result = 'lose'; h.payout = 0; }
      else if (p > 21) { h.result = 'bust'; h.payout = 0; }
      else if (d > 21 || p > d) { h.result = 'win'; h.payout = h.bet * 2; }
      else if (p === d) { h.result = 'push'; h.payout = h.bet; }
      else { h.result = 'lose'; h.payout = 0; }
      total += h.payout;
    }
    total += (seat.side.pp?.payout || 0) + (seat.side.t213?.payout || 0) + (seat.side.spin?.payout || 0);
  }
  s.totalPayout = total;
  s.status = 'done';
  s.active = null;
}

function activeHand(s) {
  if (s.status !== 'player' || !s.active) throw new Error('This round is already finished.');
  return s.seats[s.active.seat].hands[s.active.hand];
}

export function allowed(s) {
  if (s.status !== 'player' || !s.active) return { hit: false, stand: false, double: false, split: false };
  const seat = s.seats[s.active.seat];
  const h = seat.hands[s.active.hand];
  const two = h.cards.length === 2;
  return {
    hit: !h.splitAces,
    stand: true,
    double: two && !h.splitAces,
    split: two && !h.splitAces && cardValue(h.cards[0]) === cardValue(h.cards[1]) && seat.hands.length < MAX_HANDS_PER_SEAT,
  };
}

/** Extra stake the action needs (the caller debits it before acting). */
export function extraStake(s, action) {
  if (action !== 'double' && action !== 'split') return 0;
  return activeHand(s).bet;
}

export function act(s, action) {
  const h = activeHand(s);
  const ok = allowed(s);
  if (!ok[action]) throw new Error(`You can't ${action} this hand.`);
  const { seat: si, hand: hi } = s.active;
  const draw = () => s.shoe.pop();
  const give = (hand, idx) => { const c = draw(); hand.cards.push(c); s.events.push({ t: 'card', seat: si, hand: idx, card: c }); };

  if (action === 'hit') {
    give(h, hi);
    const v = handValue(h.cards).total;
    if (v >= 21) h.done = true;
  } else if (action === 'stand') {
    h.done = true;
  } else if (action === 'double') {
    h.bet *= 2;
    h.doubled = true;
    s.totalStaked += h.bet / 2;
    give(h, hi);
    h.done = true;
  } else if (action === 'split') {
    const seat = s.seats[si];
    const aces = rankOf(h.cards[0]) === 'A';
    const moved = h.cards.pop();
    const nh = { cards: [moved], bet: h.bet, doubled: false, done: false, split: true, splitAces: aces, result: null, payout: 0 };
    h.split = true;
    h.splitAces = aces;
    seat.hands.splice(hi + 1, 0, nh);
    s.totalStaked += h.bet;
    s.events.push({ t: 'split', seat: si, hand: hi });
    give(h, hi);
    give(nh, hi + 1);
    for (const x of [h, nh]) if (aces || handValue(x.cards).total === 21) x.done = true;
  }
  advance(s);
  return s;
}

/** What the player may see: the hole card stays hidden until the round ends. */
export function publicView(s) {
  if (!s || s.v !== 2) return null;
  const done = s.status === 'done';
  const hide = (c) => (done ? c : '??');
  return {
    status: s.status,
    active: s.active,
    allowed: allowed(s),
    dealer: done ? s.dealer : [s.dealer[0], '??'],
    dealerValue: handValue(done ? s.dealer : [s.dealer[0]]),
    events: s.events.map((e) => (e.t === 'dealer' && e.hole ? { ...e, card: hide(e.card) } : e)).filter((e) => done || e.t !== 'reveal'),
    seats: s.seats.map((seat) => ({
      bet: seat.bet, pp: seat.pp, t213: seat.t213, spin: seat.spin || 0,
      side: done || seat.side.spin?.result !== 'wheel' ? seat.side : { ...seat.side, spin: { result: 'wheel', pending: true } },
      hands: seat.hands.map((h) => ({ cards: h.cards, bet: h.bet, doubled: h.doubled, done: h.done, split: h.split, result: done ? h.result : null, payout: done ? h.payout : 0, value: handValue(h.cards) })),
    })),
    totalStaked: s.totalStaked,
    totalPayout: done ? s.totalPayout : null,
  };
}

// ── Basic strategy hint (6 decks, dealer stands on 17, double after split) ──
export function hint(s) {
  if (!s || s.status !== 'player' || !s.active) return null;
  const h = s.seats[s.active.seat].hands[s.active.hand];
  const ok = allowed(s);
  const up = cardValue(s.dealer[0]) === 11 ? 11 : cardValue(s.dealer[0]);
  const { total, soft } = handValue(h.cards);
  const pairRank = h.cards.length === 2 && cardValue(h.cards[0]) === cardValue(h.cards[1]) ? cardValue(h.cards[0]) : null;
  const dbl = (fallback) => (ok.double ? 'double' : fallback);
  if (pairRank && ok.split) {
    const p = pairRank;
    if (p === 11 || p === 8) return 'split';
    if (p === 9 && ![7, 10, 11].includes(up)) return 'split';
    if ((p === 7 || p === 3 || p === 2) && up <= 7) return 'split';
    if (p === 6 && up <= 6) return 'split';
    if (p === 4 && (up === 5 || up === 6)) return 'split';
  }
  if (soft && total < 21) {
    if (total >= 19) return total === 19 && up === 6 ? dbl('stand') : 'stand';
    if (total === 18) return up <= 6 ? dbl('stand') : up <= 8 ? 'stand' : 'hit';
    if (total === 17) return up >= 3 && up <= 6 ? dbl('hit') : 'hit';
    if (total >= 15) return up >= 4 && up <= 6 ? dbl('hit') : 'hit';
    return up >= 5 && up <= 6 ? dbl('hit') : 'hit';
  }
  if (total >= 17) return 'stand';
  if (total >= 13) return up <= 6 ? 'stand' : 'hit';
  if (total === 12) return up >= 4 && up <= 6 ? 'stand' : 'hit';
  if (total === 11) return dbl('hit');
  if (total === 10) return up <= 9 ? dbl('hit') : 'hit';
  if (total === 9) return up >= 3 && up <= 6 ? dbl('hit') : 'hit';
  return 'hit';
}

export const RESULT_TEXT = { blackjack: 'Blackjack 3:2', win: 'Win', push: 'Push', lose: 'Lose', bust: 'Bust' };
export const SIDE_TEXT = {
  perfect: 'Perfect Pair', coloured: 'Coloured Pair', mixed: 'Mixed Pair',
  suitedTrips: 'Suited Trips', straightFlush: 'Straight Flush', trips: 'Three of a Kind', straight: 'Straight', flush: 'Flush',
};
