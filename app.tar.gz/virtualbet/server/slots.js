// "Lakeside Lures" - an original 5x3, 10-line fishing slot (pure engine,
// shared by the server and the in-browser build). Virtual money only.
//
// Fisherman WILD substitutes on lines and collects every FISH cash value
// on screen. 3+ SCATTERs award free spins, where wilds and fish are more
// common and every 4 wilds collected adds 10 spins and raises the
// multiplier (x2, x3, x10). All amounts are integer pence.

export const SYMBOLS = ['10', 'J', 'Q', 'K', 'A', 'BOX', 'FLY', 'ROD', 'BOAT', 'FISH', 'WILD', 'SCAT'];

// Pays in hundredths of the TOTAL bet for 3 / 4 / 5 of a kind on a line
export const PAYTABLE = {
  10: [50, 150, 500], J: [50, 150, 500], Q: [50, 150, 500], K: [50, 200, 750], A: [50, 200, 750],
  BOX: [100, 400, 1500], FLY: [100, 400, 1500], ROD: [150, 600, 2500], BOAT: [250, 1000, 5000],
  WILD: [250, 1000, 5000],
};
export const SCATTER_PAY = { 3: 200, 4: 1000, 5: 10000 }; // hundredths of total bet
export const SCATTER_SPINS = { 3: 10, 4: 15, 5: 20 };
export const LEVELS = [{ at: 4, mult: 2 }, { at: 8, mult: 3 }, { at: 12, mult: 10 }];
export const MAX_WIN_X = 5000;
export const LUCKY_NET_CHANCE = 0.015;

// 10 paylines (row index per reel)
export const LINES = [
  [1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2],
  [1, 0, 0, 0, 1], [1, 2, 2, 2, 1], [0, 0, 1, 2, 2], [2, 2, 1, 0, 0], [1, 2, 1, 0, 1],
];

const BASE_W = { 10: 30, J: 30, Q: 28, K: 24, A: 24, BOX: 12, FLY: 12, ROD: 9, BOAT: 6, FISH: 9, WILD: 1.3, SCAT: 4.2 };
const FREE_W = { 10: 26, J: 26, Q: 24, K: 22, A: 22, BOX: 11, FLY: 11, ROD: 8, BOAT: 6, FISH: 15, WILD: 3.6, SCAT: 0 };
// Fish cash values as multiples of the total bet (x100) with weights
// Rebalanced Nov 2026: line pays x10, top fish 500x (was 2,000x). Mean fish = 8.2x bet,
// solved so the total long-run return is 96% (see test/maths and the README).
export const FISH_VALUES = [[200, 44.5], [500, 26], [1000, 15], [1500, 8], [2000, 5], [2500, 3.5], [5000, 1.8], [10000, 0.6], [50000, 0.06]];

function pickWeighted(entries, rand) {
  const total = entries.reduce((a, [, w]) => a + w, 0);
  let r = rand() * total;
  for (const [v, w] of entries) if ((r -= w) <= 0) return v;
  return entries[entries.length - 1][0];
}
const BASE_E = Object.entries(BASE_W), FREE_E = Object.entries(FREE_W);

function drawGrid(rand, free) {
  const grid = [];
  for (let r = 0; r < 5; r++) {
    const col = [];
    for (let row = 0; row < 3; row++) {
      let s = pickWeighted(free ? FREE_E : BASE_E, rand);
      if (s === 'WILD' && r === 0) s = pickWeighted(free ? FREE_E : BASE_E, rand) === 'WILD' ? 'BOAT' : 'K'; // no wilds on reel 1
      if (s === 'SCAT' && col.includes('SCAT')) s = 'Q'; // at most one scatter per reel
      col.push(s === 'FISH' ? { s, v: pickWeighted(FISH_VALUES, rand) } : { s });
    }
    grid.push(col);
  }
  return grid;
}

function lineWins(grid, bet) {
  const wins = [];
  LINES.forEach((line, li) => {
    const syms = line.map((row, reel) => grid[reel][row].s);
    let base = syms.find((x) => x !== 'WILD');
    if (base === undefined) base = 'WILD';
    if (base === 'FISH' || base === 'SCAT') base = syms[0] === 'WILD' ? 'WILD' : null;
    if (!base) return;
    let n = 0;
    for (const x of syms) { if (x === base || x === 'WILD') n++; else break; }
    // A pure-wild run may pay better on its own
    let wn = 0;
    for (const x of syms) { if (x === 'WILD') wn++; else break; }
    const pay = (sym, count) => (count >= 3 && PAYTABLE[sym] ? PAYTABLE[sym][count - 3] : 0);
    let best = { sym: base, count: n, x: pay(base, n) };
    if (pay('WILD', wn) > best.x) best = { sym: 'WILD', count: wn, x: pay('WILD', wn) };
    if (best.x > 0) wins.push({ line: li, symbol: best.sym, count: best.count, amount: Math.floor((bet * best.x) / 100), cells: line.slice(0, best.count).map((row, reel) => [reel, row]) });
  });
  return wins;
}

/**
 * One spin. `free` is the free-spins state or null.
 * Returns { grid, wins, collect, scatter, win, free (new state or null), trigger }
 */
export function spin(bet, rand, free = null) {
  const inFree = !!free;
  const grid = drawGrid(rand, inFree);
  // LUCKY NET (base game): fish on screen but no fisherman - sometimes a net
  // drops a wild onto reels 2-5 so the fish can still be collected.
  let net = null;
  if (!inFree) {
    const cells = grid.flat();
    if (!cells.some((c) => c.s === 'WILD') && cells.some((c) => c.s === 'FISH') && rand() < LUCKY_NET_CHANCE) {
      const spots = [];
      for (let r = 1; r < 5; r++) for (let row = 0; row < 3; row++) if (!['FISH', 'SCAT'].includes(grid[r][row].s)) spots.push([r, row]);
      if (spots.length) {
        const [r, row] = spots[Math.floor(rand() * spots.length)];
        net = { reel: r, row, was: grid[r][row].s };
        grid[r][row] = { s: 'WILD', net: true };
      }
    }
  }
  const flat = grid.flat();
  const wins = lineWins(grid, bet);
  const wilds = flat.filter((c) => c.s === 'WILD').length;
  const fishSum = flat.filter((c) => c.s === 'FISH').reduce((a, c) => a + c.v, 0);
  const mult = inFree ? free.mult : 1;
  const collect = wilds && fishSum ? { wilds, fishX100: fishSum, mult, amount: Math.floor((bet * fishSum * wilds * mult) / 100) } : null;
  const scatters = flat.filter((c) => c.s === 'SCAT').length;
  const scatter = scatters >= 3 ? { count: scatters, amount: Math.floor((bet * SCATTER_PAY[Math.min(5, scatters)]) / 100), spins: SCATTER_SPINS[Math.min(5, scatters)] } : null;

  let win = wins.reduce((a, w) => a + w.amount * (inFree ? mult : 1), 0) + (collect?.amount || 0) + (scatter?.amount || 0);
  let next = null;
  let trigger = null;
  if (inFree) {
    next = { ...free, remaining: free.remaining - 1, spinsPlayed: free.spinsPlayed + 1, wilds: free.wilds + wilds };
    const level = [...LEVELS].reverse().find((l) => next.wilds >= l.at && free.wilds < l.at);
    if (level) { next.remaining += 10; next.mult = level.mult; trigger = { retrigger: true, mult: level.mult }; }
    if (next.totalWin + win > MAX_WIN_X * bet) { win = Math.max(0, MAX_WIN_X * bet - next.totalWin); next.remaining = 0; }
    next.totalWin += win;
    if (next.remaining <= 0) next.ended = true;
  } else if (scatter) {
    next = { bet, remaining: scatter.spins, spinsPlayed: 0, wilds: 0, mult: 1, totalWin: 0 };
    trigger = { freeSpins: scatter.spins };
  }
  win = Math.min(win, MAX_WIN_X * bet);
  return { grid, wins, collect, scatter, win, free: next, trigger, mult, net };
}
