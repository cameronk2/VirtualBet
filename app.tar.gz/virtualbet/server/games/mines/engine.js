// Gem Mines – round flow (server-authoritative, persisted state).
//
// idle → start (stake taken, board shuffled with the platform's crypto RNG)
// → run → reveal… → mine (lost, board shown) | cashout | every gem found
// (paid automatically). The mine positions stay in the saved state on the
// server and are never sent to the browser until the round is over. Every
// action advances the state exactly once, so double clicks, repeated
// requests or refreshes can't reveal twice, pay twice or change the board.
import { checkStake, fail } from '../common.js';
import { MAX_MINES, MIN_MINES, TILES, multiplier, survival } from './config.js';

export const init = () => ({ mode: 'idle', round: null, recent: [] });

function shuffle(rand) {
  const a = Array.from({ length: TILES }, (_, i) => i);
  for (let i = TILES - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
const roundView = (r) => r && {
  bet: r.bet, mines: r.mines, picks: r.picks, gems: r.picks.length,
  mult: multiplier(r.mines, r.picks.length), next: r.picks.length < TILES - r.mines ? { mult: multiplier(r.mines, r.picks.length + 1), chance: (TILES - r.mines - r.picks.length) / (TILES - r.picks.length) } : null,
};
export const view = (s) => ({ mode: s.mode, round: roundView(s.round), recent: (s.recent || []).slice(0, 30) });

function end(s, result, payout, now) {
  const r = s.round;
  const gems = r.picks.length;
  s.recent = [{ bet: r.bet, mines: r.mines, gems, mult: result === 'mine' ? 0 : multiplier(r.mines, gems), reached: gems ? multiplier(r.mines, gems) : 0, result, payout, at: now, board: r.board, picks: r.picks, hit: r.hit ?? null }, ...(s.recent || [])].slice(0, 30);
  s.round = null; s.mode = 'idle';
}

export function act(state, action, body, { rand, now, minStake, maxStake }) {
  const s = { ...init(), ...structuredClone(state || {}) };
  const out = { action };
  let stake = 0, payout = 0;

  if (action === 'start') {
    if (s.mode === 'run') fail('A round is already in play.');
    const mines = body?.mines;
    if (!Number.isInteger(mines) || mines < MIN_MINES || mines > MAX_MINES) fail(`Choose between ${MIN_MINES} and ${MAX_MINES} mines.`);
    stake = checkStake(body?.stake, { min: minStake, max: maxStake });
    const order = shuffle(rand);
    const board = Array(TILES).fill(0);                 // 1 = mine
    order.slice(0, mines).forEach((i) => { board[i] = 1; });
    s.round = { bet: stake, mines, board, picks: [] };
    s.mode = 'run';
    out.started = true;
  } else if (action === 'reveal') {
    if (s.mode !== 'run') fail('There is no round in play.');
    const r = s.round, tile = body?.tile;
    if (!Number.isInteger(tile) || tile < 0 || tile >= TILES) fail('Pick a tile on the board.');
    if (r.picks.includes(tile)) fail('That tile is already revealed.');
    out.tile = tile;
    if (r.board[tile] === 1) {
      r.hit = tile;
      out.mine = true; out.board = r.board; out.lost = r.bet; out.gems = r.picks.length; out.reached = multiplier(r.mines, r.picks.length);
      end(s, 'mine', 0, now);
    } else {
      r.picks.push(tile);
      const k = r.picks.length;
      out.gem = true; out.gems = k; out.mult = multiplier(r.mines, k); out.chance = survival(r.mines, k);
      if (k === TILES - r.mines) {                       // every gem found: paid automatically
        payout = Math.floor(r.bet * out.mult);
        out.cleared = true; out.win = payout; out.bet = r.bet; out.board = r.board;
        end(s, 'cleared', payout, now);
      }
    }
  } else if (action === 'cashout') {
    if (s.mode !== 'run') fail('There is no round in play.');
    const r = s.round;
    if (!r.picks.length) fail('Reveal at least one gem before cashing out.');
    out.mult = multiplier(r.mines, r.picks.length);
    payout = Math.floor(r.bet * out.mult);
    Object.assign(out, { cashed: true, win: payout, bet: r.bet, gems: r.picks.length, mines: r.mines, board: r.board });
    end(s, 'cashout', payout, now);
  } else fail('Unknown action.');

  out.payout = payout; out.mode = s.mode;
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'mines', cashed: !!(out.cashed || out.cleared), mult: out.mult || 0 }] };
}

export const mines = { id: 'mines', label: 'Gem Mines', init, view, act };
