// Gem Mines – every number that defines the game.
//
// 25 tiles, M mines (1-24). The chance of k safe reveals in a row is
//     P(k) = Π_{i=0..k-1} (25 - M - i) / (25 - i)
// The fair multiplier is 1 / P(k); the paid multiplier applies the RTP and is
// rounded DOWN to 2 decimal places (what is shown is exactly what is paid):
//     multiplier(M, k) = floor( RTP / P(k) × 100 ) / 100
// Cashing out after any number of reveals therefore returns RTP (a hair less
// after rounding). Change RTP (or the cap) here and everything follows.
export const TILES = 25;
export const MIN_MINES = 1;
export const MAX_MINES = 24;
export const RTP = 0.97;
/** Optional ceiling on any multiplier (null = none). A cap lowers RTP only on the rare rounds that reach it. */
export const MAX_MULTIPLIER = null;

/** Chance of k safe reveals in a row with M mines. */
export function survival(mines, k) {
  let p = 1;
  for (let i = 0; i < k; i++) p *= (TILES - mines - i) / (TILES - i);
  return p;
}

/** The paid multiplier after k safe reveals (k ≥ 1), from the formula above. */
export function multiplier(mines, k) {
  if (k <= 0) return 0;
  const m = Math.floor((RTP / survival(mines, k)) * 100 + 1e-7) / 100;
  return MAX_MULTIPLIER ? Math.min(m, MAX_MULTIPLIER) : m;
}

/** Full table for one mine count: [{ k, chance, mult }], k = 1 … 25 − M. */
export const schedule = (mines) => Array.from({ length: TILES - mines }, (_, i) => ({ k: i + 1, chance: survival(mines, i + 1), mult: multiplier(mines, i + 1) }));
