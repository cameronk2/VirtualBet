// Punto Banco baccarat, 8 decks, standard third-card rules.
// Player 1:1, Banker 0.95:1 (5% commission), Tie 8:1 (Player/Banker bets
// push on a tie), Player Pair / Banker Pair 11:1.
import { checkStake, fail, rankOf, shoe } from './common.js';

const val = (c) => { const r = rankOf(c); return r === 'A' ? 1 : ['10', 'J', 'Q', 'K'].includes(r) ? 0 : Number(r); };
export const total = (cards) => cards.reduce((a, c) => a + val(c), 0) % 10;

export function playCoup(rand) {
  const s = shoe(rand, 8, 6);
  const P = [s[0], s[2]], B = [s[1], s[3]];
  let i = 4;
  const order = [['P', s[0]], ['B', s[1]], ['P', s[2]], ['B', s[3]]];
  const pt = total(P), bt = total(B);
  if (pt < 8 && bt < 8) {
    let p3 = null;
    if (pt <= 5) { p3 = s[i++]; P.push(p3); order.push(['P', p3]); }
    const b = total(B);
    let draw;
    if (p3 === null) draw = b <= 5;
    else {
      const v = val(p3);
      draw = b <= 2 || (b === 3 && v !== 8) || (b === 4 && v >= 2 && v <= 7) || (b === 5 && v >= 4 && v <= 7) || (b === 6 && (v === 6 || v === 7));
    }
    if (draw) { const c = s[i++]; B.push(c); order.push(['B', c]); }
  }
  const p = total(P), b = total(B);
  return { player: P, banker: B, order, p, b, winner: p > b ? 'P' : b > p ? 'B' : 'T', natural: order.length === 4 && (p >= 8 || b >= 8) };
}

const FIELDS = ['player', 'banker', 'tie', 'pPair', 'bPair'];

export const baccarat = {
  id: 'baccarat',
  label: 'Baccarat',
  init: () => ({ road: [] }),
  view: (s) => ({ road: s.road.slice(-72) }),
  act(state, action, body, { rand, minStake, maxStake }) {
    if (action !== 'deal') fail('Unknown action.');
    let stake = 0;
    const bets = {};
    for (const f of FIELDS) {
      const v = body?.[f] || 0;
      if (v) checkStake(v, { min: minStake, max: maxStake, label: 'Each bet' });
      bets[f] = v;
      stake += v;
    }
    if (!stake) fail('Place a bet first.');
    const c = playCoup(rand);
    const pairP = rankOf(c.player[0]) === rankOf(c.player[1]);
    const pairB = rankOf(c.banker[0]) === rankOf(c.banker[1]);
    let payout = 0;
    if (c.winner === 'P') payout += bets.player * 2;
    if (c.winner === 'B') payout += bets.banker + Math.floor(bets.banker * 0.95);
    if (c.winner === 'T') payout += bets.tie * 9 + bets.player + bets.banker;
    if (pairP) payout += bets.pPair * 12;
    if (pairB) payout += bets.bPair * 12;
    const road = [...state.road, c.winner].slice(-120);
    return {
      stake, payout, state: { road },
      out: { ...c, pairP, pairB, bets, payout, stake },
      settled: { staked: stake, payout },
      events: [{ t: 'baccarat', winner: c.winner, tieWin: c.winner === 'T' && bets.tie > 0 }],
    };
  },
};
