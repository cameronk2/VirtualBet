// Polar Catch – exact long-run returns, computed from the config (no simulation).
import { BONUS_MULT, CATCH, FLAKE_MULTS, SEGMENTS, SPOTS, TAIL_SCALE } from './config.js';

const mean = (pairs, f = (v) => v) => { const t = pairs.reduce((a, [, w]) => a + w, 0); return pairs.reduce((a, [v, w]) => a + f(v) * w, 0) / t; };

/** Catch table with the tail (values above the median value) scaled. */
export function catchTable(id, scale = TAIL_SCALE[id]) {
  const vals = CATCH[id].values;
  const mid = vals[Math.floor(vals.length / 2)][0];
  return vals.map(([v, w]) => [v, v > mid ? w * scale : w]);
}

/** Return-to-player of a flake bet, as a fraction. */
export function flakeRtp() {
  const p = 23 / SEGMENTS;
  const lit = mean(FLAKE_MULTS.count) / 46;            // chance the landing flake segment is lit
  const extra = mean(FLAKE_MULTS.values, (m) => m - 1); // extra winnings per lit hit
  return p * (2 + lit * extra);
}

/** Return-to-player of a bonus bet (cap applied to each catch × multiplier). */
export function bonusRtp(id, scale) {
  const p = SPOTS[id].segments / SEGMENTS;
  const cap = SPOTS[id].maxPay;
  const mults = [[1, 1 - BONUS_MULT.chance], ...BONUS_MULT.values.map(([m, w]) => [m, (w / BONUS_MULT.values.reduce((a, [, x]) => a + x, 0)) * BONUS_MULT.chance])];
  const table = catchTable(id, scale);
  const ex = mean(table, (x) => mults.reduce((a, [m, pm]) => a + pm * Math.min(cap, x * m), 0));
  return p * (1 + ex);
}
