// Polar Catch – one round, resolved completely before anything animates.
//   1. pre-spin multipliers are drawn (flake segments and bonus categories)
//   2. the wheel stops on a segment (each of the 53 equally likely)
//   3. a flake pays 1:1 (or m:1 if lit); a bonus segment starts its fishing
//      round, which lands one catch (x bet) times the category multiplier
//   4. every bet is settled; the round total is capped at 5,000x the stake
import { checkStake, fail, pickWeighted } from '../common.js';
import { BONUS_IDS, BONUS_MULT, FLAKE_MULTS, MAX_WIN_X, SEGMENTS, SPOTS, SPOT_IDS, SPOT_MAX, SPOT_MIN, WHEEL } from './config.js';
import { catchTable } from './maths.js';

const pick = (pairs, rand) => pickWeighted(pairs, rand);

export function validateBets(bets) {
  if (!bets || typeof bets !== 'object') fail('Place a bet first.');
  const clean = {};
  for (const [k, v] of Object.entries(bets)) {
    if (!SPOT_IDS.includes(k)) fail('Unknown bet spot.');
    if (v === 0 || v == null) continue;
    clean[k] = checkStake(v, { min: SPOT_MIN, max: SPOT_MAX, label: `${SPOTS[k].name} bet` });
  }
  if (!Object.keys(clean).length) fail('Place a bet first.');
  return clean;
}

export function spinRound(bets, rand, force = {}) {
  // 1. multipliers
  const lit = {};
  const flakeIdx = WHEEL.map((s, i) => (SPOTS[s].kind === 'flake' ? i : -1)).filter((i) => i >= 0);
  const count = pick(FLAKE_MULTS.count, rand);
  const pool = flakeIdx.slice();
  for (let k = 0; k < count; k++) {
    const j = Math.floor(rand() * pool.length);
    lit[pool[j]] = pick(FLAKE_MULTS.values, rand);
    pool.splice(j, 1);
  }
  const bonusMult = {};
  for (const id of BONUS_IDS) if (rand() < BONUS_MULT.chance) bonusMult[id] = pick(BONUS_MULT.values, rand);
  // 2. wheel
  const segment = force.segment ?? Math.floor(rand() * SEGMENTS);
  const landed = WHEEL[segment];
  // 3. outcome
  let fishing = null;
  if (SPOTS[landed].kind === 'bonus') {
    const fish = force.fish ?? pick(catchTable(landed), rand);
    const mult = bonusMult[landed] || 1;
    fishing = { bonus: landed, fish, mult, pays: Math.min(SPOTS[landed].maxPay, fish * mult), capped: fish * mult > SPOTS[landed].maxPay };
  }
  // 4. settle (winnings "to 1" plus the stake back)
  const results = {};
  let total = 0, staked = 0;
  for (const [spot, bet] of Object.entries(bets)) {
    staked += bet;
    let ret = 0;
    if (spot === landed) ret = SPOTS[spot].kind === 'flake' ? bet * (1 + (lit[segment] || 1)) : bet * (1 + fishing.pays);
    results[spot] = { bet, ret };
    total += ret;
  }
  const payout = Math.min(total, staked * MAX_WIN_X);
  return { lit, bonusMult, segment, landed, fishing, results, staked, payout, capped: payout < total };
}

export const polarcatch = {
  id: 'polarcatch', label: 'Polar Catch',
  init: () => ({ recent: [], history: [] }),
  view: (s) => ({ history: (s.history || []).slice(0, 24), recent: (s.recent || []).slice(0, 15) }),
  act(state, action, body, { rand }) {
    if (action !== 'spin') fail('Unknown action.');
    const bets = validateBets(body?.bets);
    const r = spinRound(bets, rand);
    const history = [{ landed: r.landed, mult: r.lit[r.segment] || r.fishing?.mult || 1, fish: r.fishing?.fish ?? null }, ...(state.history || [])].slice(0, 40);
    const recent = [{ bet: r.staked, win: r.payout }, ...(state.recent || [])].slice(0, 20);
    return {
      stake: r.staked, payout: r.payout,
      state: { ...state, history, recent },
      out: { ...r, win: r.payout, bet: r.staked },
      settled: { staked: r.staked, payout: r.payout },
      events: [{ t: 'slot', game: 'polarcatch', x: r.payout / r.staked, feature: !!r.fishing }],
    };
  },
};
