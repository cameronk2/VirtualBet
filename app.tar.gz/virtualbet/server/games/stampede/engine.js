// Stampede Link – game flow (server-authoritative, persisted state).
//
// Modes: base → hold (8+ buffalo cash) and/or free (3+ gold coins). When
// both trigger on one spin, Hold & Spin plays first, then the free games.
// Hold & Spin can also trigger during free games; the free games resume
// afterwards. Every result is decided here before anything animates, and
// each action moves the saved state forward exactly once.
import { checkStake, fail } from '../common.js';
import { FREE_GAMES, GOLD_UPGRADES, HOLD_TRIGGER, JACKPOTS, MAX_FREE_GAMES, MAX_WIN_X, RETRIGGER, SCATTER_PAY, STAKE_MAX } from './config.js';
import { cellsOf, draw, evaluateWays } from './reels.js';
import { holdTotal, holdView, respin, startHold } from './hold.js';

export const init = () => ({ mode: 'base', queue: [], free: null, hold: null, recent: [], practice: false });
export const view = (s) => ({
  mode: s.mode, practice: !!s.practice, queue: (s.queue || []).map((q) => q.type),
  free: s.free && { bet: s.free.bet, remaining: s.free.remaining, played: s.free.played, total: s.free.total, gold: s.free.gold, upgrades: s.free.upgrades },
  hold: holdView(s.hold),
  recent: (s.recent || []).slice(0, 15),
});
const upgradesFor = (gold) => GOLD_UPGRADES.filter((u) => gold >= u.at).map((u) => u.sym);

function advance(s, out) {
  const next = s.queue.shift();
  if (next?.type === 'hold') {
    s.hold = startHold(next.grid, next.bet, next.source);
    s.mode = 'hold';
    out.started = { type: 'hold', cells: { ...s.hold.cells }, source: next.source };
  } else if (next?.type === 'free') {
    s.free = { bet: next.bet, remaining: next.games, played: 0, total: 0, gold: 0, upgrades: [], awarded: next.games };
    s.mode = 'free';
    out.started = { type: 'free', games: next.games };
  } else if (s.free) {
    s.mode = 'free';
  } else {
    s.mode = 'base'; s.practice = false;
  }
}

/** Pays this action's win, keeping a free-games round under the cap. */
function pay(s, raw, bet) {
  if (!s.free) return Math.min(raw, bet * MAX_WIN_X);
  const left = Math.max(0, s.free.bet * MAX_WIN_X - s.free.total);
  const p = Math.min(raw, left);
  s.free.total += p;
  return p;
}

function finishFreeIfDone(s, out) {
  const f = s.free;
  if (f && f.remaining <= 0 && s.mode !== 'hold' && !s.queue.length) {
    out.finished = { type: 'free', played: f.played, total: f.total, gold: f.gold, upgrades: f.upgrades };
    s.free = null;
    advance(s, out);
  }
}

export function act(state, action, body, { rand, minStake, inject }) {
  const s = { ...init(), ...structuredClone(state || {}) };
  const out = { action };
  const wasPractice = !!s.practice;
  let stake = 0, payout = 0, feature = false;

  if (action === 'spin' && (s.mode === 'base' || s.mode === 'free')) {
    const free = s.mode === 'free';
    const bet = free ? s.free.bet : checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    if (!free) stake = bet;
    const grid = inject?.grid || draw(rand, free);
    let upgrades = [], goldNew = 0;
    if (free) {
      goldNew = cellsOf(grid, 'GOLD').length;
      s.free.gold += goldNew;
      s.free.upgrades = upgradesFor(s.free.gold);
      upgrades = s.free.upgrades;
    }
    const wins = evaluateWays(grid, bet, { upgrades });
    const coins = cellsOf(grid, 'COIN'), cash = cellsOf(grid, 'CASH');
    const scatterWin = coins.length >= 3 ? bet * SCATTER_PAY[Math.min(5, coins.length)] : 0;
    const raw = wins.reduce((a, w) => a + w.amount, 0) + scatterWin;
    payout = pay(s, raw, bet);
    Object.assign(out, { grid, wins, coins, cash, scatterWin, win: payout, bet, free, upgrades, goldNew, gold: s.free?.gold });
    const holdTrig = cash.length >= HOLD_TRIGGER;
    let games = 0;
    if (!free && coins.length >= 3) games = FREE_GAMES[Math.min(5, coins.length)];
    if (free && coins.length >= 2) {
      games = Math.min(RETRIGGER[Math.min(5, coins.length)], MAX_FREE_GAMES - s.free.awarded);
      s.free.remaining += games; s.free.awarded += games;
    }
    out.triggers = { hold: holdTrig, free: games > 0 && !free, retrigger: free ? games : 0 };
    feature = holdTrig || out.triggers.free;
    if (free) { s.free.remaining--; s.free.played++; out.remaining = s.free.remaining; }
    if (holdTrig) s.queue.push({ type: 'hold', bet, grid, source: free ? 'free' : 'base' });
    if (out.triggers.free) s.queue.push({ type: 'free', bet, games });
    if (s.queue.length) advance(s, out);
    else finishFreeIfDone(s, out);
  } else if (action === 'respin') {
    if (s.mode !== 'hold') fail('There is no Hold & Spin in play.');
    const h = s.hold;
    const forced = s.practice && h.forced?.length ? [h.forced.shift()] : inject?.lands;
    const r = respin(h, rand, forced);
    Object.assign(out, r, { bet: h.bet });
    if (r.done) {
      const raw = Math.floor(h.bet * holdTotal(h));
      payout = pay(s, raw, h.bet);
      out.win = payout;
      out.holdDone = { totalX: holdTotal(h), win: payout, filled: r.filled, grand: r.full, jackpots: Object.values(h.cells).filter((c) => JACKPOTS[c.v]).map((c) => c.v), source: h.source, capped: payout < raw };
      s.hold = null;
      if (s.queue.length) advance(s, out);
      else if (s.free) { s.mode = 'free'; finishFreeIfDone(s, out); }
      else advance(s, out);
    }
  } else if (action === 'dev') {
    // Practice triggers for testing: cost nothing, pay nothing.
    if (s.mode !== 'base' || s.queue.length) fail('Finish the current feature first.');
    const bet = checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    s.practice = true;
    const grid = Array.from({ length: 5 }, () => Array.from({ length: 4 }, () => ({ s: 'K' })));
    const put = (cells, v) => cells.forEach(([c, r], i) => { grid[c][r] = { s: 'CASH', v: Array.isArray(v) ? v[i % v.length] : v }; });
    const EIGHT = [[0, 0], [1, 2], [2, 1], [2, 3], [3, 0], [3, 2], [4, 1], [4, 3]];
    if (body?.event === 'hold') put(EIGHT, [1, 2, 0.5, 5, 1, 3, 2, 1.5]);
    else if (body?.event === 'jackpots') put(EIGHT, ['MINI', 2, 'MINOR', 1, 'MAJOR', 3, 1, 2]);
    else if (body?.event === 'grand') put([...Array(19).keys()].map((i) => [Math.floor(i / 4), i % 4]), [1, 2, 0.5, 3]);
    else if (body?.event === 'mult') put(EIGHT, [1, 2, 0.5, 5, 1, 3, 2, 1.5]);
    else if (body?.event !== 'free') fail('Unknown test event.');
    if (body.event === 'free') s.queue.push({ type: 'free', bet, games: FREE_GAMES[3] });
    else s.queue.push({ type: 'hold', bet, grid, source: 'base' });
    advance(s, out);
    if (s.hold && body.event === 'grand') s.hold.forced = [{ c: 4, r: 3, v: 2 }];
    if (s.hold && body.event === 'mult') s.hold.forced = [{ c: 0, r: 2, v: 'X2' }, { c: 1, r: 0, v: 'X3' }];
  } else if (action === 'spin') {
    fail('Finish Hold & Spin first.');
  } else fail('Unknown action.');

  if (wasPractice || s.practice) { stake = 0; payout = 0; out.practice = true; if (s.free) s.free.total = 0; }
  out.payout = payout; out.mode = s.mode;
  if (stake || payout) s.recent = [{ bet: out.bet, win: payout, kind: action === 'respin' ? 'hold' : out.free ? 'free' : 'spin' }, ...(s.recent || [])].slice(0, 20);
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'slot', game: 'stampede', x: out.bet ? payout / out.bet : 0, feature }] };
}

export const stampede = { id: 'stampede', label: 'Stampede Link', init, view, act };
