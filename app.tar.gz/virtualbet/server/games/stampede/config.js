// Stampede Link – every number that defines the game.
//
// An original western slot built on the published rules of Aristocrat's
// Buffalo Link (see docs/stampede-mechanics.md): 5x4, 1,024 ways; wild on
// reels 2-5, with 2x/3x multipliers on reel 5 (and on every wild in free
// games, multiplying together); 3/4/5 gold coins = 8/15/20 free games,
// 2 coins retrigger; 8+ buffalo cash symbols = Hold & Spin (3 respins,
// reset to 3 when a symbol lands; values, Mini/Minor/Major; all 20 = Grand).
// Golden Buffalo collection in free games follows Buffalo Gold. Values are
// x total bet.
export const REELS = 5;
export const ROWS = 4;
export const STAKE_MAX = 10000;
export const MAX_WIN_X = 5000;

// Pays in thousandths of the total bet for 3 / 4 / 5 of a kind, per way.
export const PAYTABLE = {
  BUFFALO: [100, 400, 1200], EAGLE: [80, 250, 600], COUGAR: [60, 200, 500], WOLF: [50, 150, 400], ELK: [40, 120, 300],
  A: [20, 50, 150], K: [20, 50, 150], Q: [15, 40, 100], J: [15, 40, 100], T: [10, 30, 80], N: [10, 30, 80],
};
export const PAY_SCALE = 1.78;          // tuned by scripts/tune-stampede.mjs
export const LINE_SYMBOLS = Object.keys(PAYTABLE);
export const WILD_REELS = [1, 2, 3, 4];

// Gold coin scatters (any reel, at most one per reel).
export const SCATTER_PAY = { 3: 2, 4: 10, 5: 50 };      // x total bet
export const FREE_GAMES = { 3: 8, 4: 15, 5: 20 };
export const RETRIGGER = { 2: 5, 3: 8, 4: 15, 5: 20 };
export const MAX_FREE_GAMES = 100;

// Wild multipliers: reel 5 in the base game, every wild in free games.
export const WILD_MULTS = [[2, 65], [3, 35]];

// Golden Buffalo (free games): collected heads turn other animals into buffalo.
export const GOLD_UPGRADES = [{ at: 3, sym: 'WOLF' }, { at: 6, sym: 'ELK' }, { at: 9, sym: 'COUGAR' }, { at: 12, sym: 'EAGLE' }];

// Buffalo cash symbols and Hold & Spin.
export const HOLD_TRIGGER = 8;
export const HOLD_RESPINS = 3;
export const JACKPOTS = { MINI: 10, MINOR: 25, MAJOR: 150, GRAND: 2000 };
export const JP_NAME = { MINI: 'Mini', MINOR: 'Minor', MAJOR: 'Major', GRAND: 'Grand' };
export const CASH_VALUES = [
  [0.5, 24], [1, 26], [1.5, 14], [2, 12], [2.5, 7], [3, 6], [4, 4], [5, 3.2], [8, 1.6], [10, 1], [15, 0.5], [20, 0.25],
  ['MINI', 1.1], ['MINOR', 0.3], ['MAJOR', 0.03],
];
// Extra in Hold & Spin only: stampede multiplier coins double/triple every locked credit coin.
export const HOLD_MULTS = [['X2', 1.4], ['X3', 0.45]];
export const HOLD_LAND = 0.05;      // chance each empty cell lands a symbol per respin (tuned)

// Reel weights.
const base = { BUFFALO: 7, EAGLE: 8, COUGAR: 9, WOLF: 10, ELK: 10, A: 13, K: 13, Q: 14, J: 14, T: 15, N: 15 };
export const WEIGHTS = {
  base: Array.from({ length: REELS }, (_, r) => ({ ...base, WILD: WILD_REELS.includes(r) ? 7 : 0, CASH: 30, COIN: 4.3 })),
  free: Array.from({ length: REELS }, (_, r) => ({ ...base, BUFFALO: 6, GOLD: 2.6, WILD: WILD_REELS.includes(r) ? 8.5 : 0, CASH: 24, COIN: 2.6 })),
};
export const STACK_CHANCE = 0.12;   // a reel shows the spin's stack symbol on every row
export const STACK_SYMBOLS = [['BUFFALO', 30], ['EAGLE', 12], ['COUGAR', 12], ['WOLF', 12], ['ELK', 12], ['A', 6], ['K', 6], ['Q', 5], ['J', 5]];
