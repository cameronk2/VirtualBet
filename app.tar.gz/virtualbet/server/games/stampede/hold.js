// Stampede Link – Hold & Spin (pure, self-contained).
//
// A separate 5x4 grid. The triggering buffalo cash symbols lock in place.
// 3 respins; every empty cell spins. Any new symbol locks and resets the
// respins to 3; a respin with nothing new uses one up. Stampede multiplier
// coins (Hold & Spin only) double or triple every locked credit value when
// they land. Ends when the respins run out or all 20 cells are filled
// (the Grand). Pays the total of every locked value once, at the end.
import { CASH_VALUES, HOLD_LAND, HOLD_MULTS, HOLD_RESPINS, JACKPOTS, REELS, ROWS } from './config.js';
import { weighted } from './reels.js';

const SIZE = REELS * ROWS;
const LAND_TABLE = [...CASH_VALUES, ...HOLD_MULTS];
export const holdView = (h) => h && { bet: h.bet, cells: h.cells, respins: h.respins, spins: h.spins, source: h.source, done: !!h.done };

export function startHold(grid, bet, source) {
  const cells = {};
  grid.forEach((col, c) => col.forEach((cell, r) => { if (cell.s === 'CASH') cells[`${c},${r}`] = { v: cell.v }; }));
  return { bet, cells, respins: HOLD_RESPINS, spins: 0, source };
}

/** Value of one locked cell in x bet. */
export const cellX = (cell) => (typeof cell.v === 'number' ? cell.v : JACKPOTS[cell.v] || 0);

/** Total in x bet (credits + jackpots + Grand for a full grid). */
export function holdTotal(h) {
  const filled = Object.keys(h.cells).length;
  return Object.values(h.cells).reduce((a, c) => a + cellX(c), 0) + (filled >= SIZE ? JACKPOTS.GRAND : 0);
}

/** One respin. Mutates `h`. `forced` (tests/practice) lists cells to land: [{c, r, v}]. */
export function respin(h, rand, forced) {
  if (h.done) throw new Error('Hold & Spin has finished.');
  h.spins++;
  const landed = [];
  if (forced) for (const f of forced) { if (!h.cells[`${f.c},${f.r}`]) landed.push({ c: f.c, r: f.r, v: f.v }); }
  else for (let c = 0; c < REELS; c++) for (let r = 0; r < ROWS; r++) {
    if (h.cells[`${c},${r}`]) continue;
    if (rand() < HOLD_LAND) landed.push({ c, r, v: weighted(LAND_TABLE, rand) });
  }
  const boosts = [];
  for (const l of landed) h.cells[`${l.c},${l.r}`] = { v: l.v };
  // multiplier coins apply after everything has landed, in reading order
  for (const l of landed) if (l.v === 'X2' || l.v === 'X3') {
    const m = l.v === 'X2' ? 2 : 3, touched = [];
    for (const [k, cell] of Object.entries(h.cells)) if (typeof cell.v === 'number') { cell.v = +(cell.v * m).toFixed(2); touched.push(k); }
    boosts.push({ c: l.c, r: l.r, m, touched });
  }
  h.respins = landed.length ? HOLD_RESPINS : h.respins - 1;
  const full = Object.keys(h.cells).length >= SIZE;
  if (h.respins <= 0 || full) h.done = true;
  return { landed, boosts, respins: h.respins, full, done: !!h.done, totalX: holdTotal(h), filled: Object.keys(h.cells).length };
}
