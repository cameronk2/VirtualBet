// Stampede Link – reels and 1,024-ways evaluation with multiplying wilds (pure).
// A cell is { s } plus v (cash value) or m (wild multiplier).
import { CASH_VALUES, LINE_SYMBOLS, PAYTABLE, PAY_SCALE, REELS, ROWS, STACK_CHANCE, STACK_SYMBOLS, WEIGHTS, WILD_MULTS, WILD_REELS } from './config.js';

export function weighted(pairs, rand) {
  let t = 0; for (const [, w] of pairs) t += w;
  let x = rand() * t;
  for (const [v, w] of pairs) if ((x -= w) < 0) return v;
  return pairs[pairs.length - 1][0];
}
const tables = (set) => WEIGHTS[set].map((w) => { const all = Object.entries(w).filter(([, x]) => x > 0); return { all, noCoin: all.filter(([s]) => s !== 'COIN') }; });
const TABLES = { base: tables('base'), free: tables('free') };

export function makeCell(s, reel, free, rand) {
  if (s === 'CASH') return { s, v: weighted(CASH_VALUES, rand) };
  if (s === 'WILD' && (free || reel === REELS - 1)) return { s, m: weighted(WILD_MULTS, rand) };
  return { s };
}

/** A grid [reel][row]. At most one gold coin per reel; some reels stack the spin's stack symbol. */
export function draw(rand, free = false) {
  const stackSym = weighted(STACK_SYMBOLS, rand);
  return TABLES[free ? 'free' : 'base'].map((t, reel) => {
    if (rand() < STACK_CHANCE) return Array.from({ length: ROWS }, () => ({ s: stackSym }));
    let coin = false;
    return Array.from({ length: ROWS }, () => {
      const s = weighted(coin ? t.noCoin : t.all, rand);
      if (s === 'COIN') coin = true;
      return makeCell(s, reel, free, rand);
    });
  });
}

/**
 * 1,024 ways: a symbol on reel 1 pays when it (or a wild, reels 2-5)
 * appears on each adjacent reel. Ways multiply; wild multipliers multiply
 * every way through them (a way through a 2x and a 3x wild pays 6x).
 * Golden Buffalo and upgraded animals count as Buffalo.
 */
export function evaluateWays(grid, bet, { upgrades = [] } = {}) {
  const wins = [];
  const isBuf = (s) => s === 'BUFFALO' || s === 'GOLD' || upgrades.includes(s);
  for (const sym of LINE_SYMBOLS) {
    const reels = [];
    for (let r = 0; r < REELS; r++) {
      let n = 0, w = 0; const cells = [];
      grid[r].forEach((c, row) => {
        const hit = sym === 'BUFFALO' ? isBuf(c.s) : c.s === sym;
        if (hit) { n++; w++; cells.push([r, row]); }
        else if (c.s === 'WILD' && WILD_REELS.includes(r)) { n++; w += c.m || 1; cells.push([r, row]); }
      });
      if (!n) break;
      reels.push({ n, w, cells });
    }
    const count = reels.length;
    if (count < 3 || !grid[0].some((c) => (sym === 'BUFFALO' ? isBuf(c.s) : c.s === sym))) continue;
    const ways = reels.reduce((a, x) => a * x.n, 1), weightedWays = reels.reduce((a, x) => a * x.w, 1);
    const pay = PAYTABLE[sym][count - 3] * PAY_SCALE;
    const amount = Math.floor((bet * pay * weightedWays) / 1000);
    if (amount > 0) wins.push({ symbol: sym, count, ways, mult: +(weightedWays / ways).toFixed(3), pay, amount, cells: reels.flatMap((x) => x.cells), byReel: reels.map((x) => x.cells.map(([, row]) => row)) });
  }
  return wins.sort((a, b) => b.amount - a.amount);
}

export const cellsOf = (grid, s) => grid.flatMap((col, r) => col.map((c, row) => (c.s === s ? [r, row] : null)).filter(Boolean));
