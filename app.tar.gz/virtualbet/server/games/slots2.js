// Four original slot games (pure engines, virtual money, integer pence).
//   nebula   - Nebula Clusters: 6x6 cluster pays with cascades and a
//              growing multiplier; 4+ comets = free spins where it never resets
//   vault    - Coin Vault: 5x3, 10 lines; 6+ coins start Hold & Spin with
//              Mini/Minor/Major jackpots and a Grand for a full screen
//   fruit    - Fruit Shack: classic 3-reel fruit machine with holds and nudges
//   starlight- Starlight Observatory: 5x3, 10 lines; telescopes are wild and
//              scatter; free spins pick a symbol that expands to fill reels
import { checkStake, fail, LINES_10, lineWins, pickWeighted } from './common.js';

const MAX_SPIN = 10000; // £100
const capWin = (win, bet, x) => Math.min(win, bet * x);

// ═══════════════════════ NEBULA CLUSTERS ═══════════════════════
export const NEBULA_SYMS = ['RED', 'ORG', 'YEL', 'GRN', 'BLU', 'PUR'];
const NEB_W = { RED: 22, ORG: 21, YEL: 20, GRN: 17, BLU: 13, PUR: 8, SCAT: 2.0 };
const NEB_W_FREE = { ...NEB_W, SCAT: 1.4 };
// Pays in hundredths of the bet for cluster sizes 5,6,7,8,9-10,11-12,13-15,16+
export const NEB_PAY = {
  RED: [20, 30, 40, 60, 100, 200, 400, 1000], ORG: [20, 30, 40, 60, 100, 200, 400, 1000],
  YEL: [30, 40, 60, 80, 150, 300, 600, 1500], GRN: [40, 60, 80, 120, 200, 400, 1000, 2500],
  BLU: [60, 100, 150, 200, 400, 800, 2000, 5000], PUR: [100, 150, 250, 400, 800, 2000, 5000, 10000],
};
export let NEB_SCALE = 2.945;
export const NEB_MULTS = [1, 2, 3, 5, 8, 10];
const bucket = (n) => (n >= 16 ? 7 : n >= 13 ? 6 : n >= 11 ? 5 : n >= 9 ? 4 : n - 5);
const SIZE = 6;

function nebSym(rand, free) {
  return pickWeighted(Object.entries(free ? NEB_W_FREE : NEB_W), rand);
}
function findClusters(g) {
  const seen = new Set(), out = [];
  for (let c = 0; c < SIZE; c++) for (let r = 0; r < SIZE; r++) {
    const s = g[c][r];
    if (s === 'SCAT' || seen.has(`${c},${r}`)) continue;
    const cells = [], stack = [[c, r]];
    seen.add(`${c},${r}`);
    while (stack.length) {
      const [x, y] = stack.pop();
      cells.push([x, y]);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= SIZE || ny >= SIZE || seen.has(`${nx},${ny}`) || g[nx][ny] !== s) continue;
        seen.add(`${nx},${ny}`);
        stack.push([nx, ny]);
      }
    }
    if (cells.length >= 5) out.push({ sym: s, cells });
  }
  return out;
}

function nebulaSpin(bet, rand, free) {
  let g = Array.from({ length: SIZE }, () => Array.from({ length: SIZE }, () => nebSym(rand, !!free)));
  const steps = [];
  let level = free ? free.level : 0;
  let win = 0;
  for (let guard = 0; guard < 40; guard++) {
    const clusters = findClusters(g);
    const mult = NEB_MULTS[Math.min(level, NEB_MULTS.length - 1)];
    if (!clusters.length) { steps.push({ grid: g.map((c) => [...c]), clusters: [], mult, win: 0 }); break; }
    let stepWin = 0;
    for (const cl of clusters) {
      cl.amount = Math.floor((bet * NEB_PAY[cl.sym][bucket(cl.cells.length)] * NEB_SCALE * mult) / 100);
      stepWin += cl.amount;
    }
    steps.push({ grid: g.map((c) => [...c]), clusters, mult, win: stepWin });
    win += stepWin;
    level++;
    const gone = new Set(clusters.flatMap((cl) => cl.cells.map(([x, y]) => `${x},${y}`)));
    g = g.map((col, x) => {
      const keep = col.filter((_, y) => !gone.has(`${x},${y}`));
      const add = Array.from({ length: SIZE - keep.length }, () => nebSym(rand, !!free));
      return [...add, ...keep]; // new symbols fall in from the top (index 0 = top)
    });
  }
  const scat = steps[0].grid.flat().filter((s) => s === 'SCAT').length;
  return { steps, win, scat, level };
}

export const nebula = {
  id: 'nebula', label: 'Nebula Clusters',
  init: () => ({ free: null, recent: [] }),
  view: (s) => ({ free: s.free, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = free ? free.bet : checkStake(body?.stake, { min: minStake, max: MAX_SPIN });
    const r = nebulaSpin(bet, rand, free);
    let win = capWin(r.win, bet, 5000);
    let next = null, trigger = null;
    if (free) {
      next = { ...free, remaining: free.remaining - 1, level: r.level, total: free.total + win };
      if (r.scat >= 3) { next.remaining += 5; trigger = { extra: 5 }; }
    } else if (r.scat >= 4) {
      next = { bet, remaining: 10, level: 0, total: 0 };
      trigger = { freeSpins: 10 };
    }
    const finished = next && next.remaining <= 0 ? { total: next.total } : null;
    if (finished) next = null;
    return {
      stake: free ? 0 : bet, payout: win,
      state: { free: next, recent: (!free || finished) ? [{ bet, win: finished ? finished.total : win }, ...state.recent].slice(0, 20) : state.recent },
      out: { steps: r.steps, win, scat: r.scat, trigger, free: next, finished, bet },
      settled: free ? { staked: 0, payout: win } : { staked: bet, payout: win }, events: [{ t: 'slot', game: 'nebula', x: win / bet, feature: !!trigger?.freeSpins }],
    };
  },
};

// ═══════════════════════ COIN VAULT ═══════════════════════
const VAULT_W = { 10: 30, J: 30, Q: 28, K: 24, A: 24, BELL: 12, BAR: 9, SEVEN: 6, WILD: 2.2, COIN: 21 };
export let VAULT_SCALE = 3.2;
export const VAULT_PAY = {
  10: [20, 50, 150], J: [20, 50, 150], Q: [20, 60, 200], K: [25, 75, 250], A: [25, 75, 250],
  BELL: [50, 150, 500], BAR: [75, 250, 1000], SEVEN: [100, 500, 2500], WILD: [100, 500, 2500],
};
export let VAULT_COIN_P = 0.14;
// Coin values as multiples of the bet (x100); jackpots are named
const COIN_VALUES = [[50, 30], [100, 30], [200, 18], [300, 10], [500, 7], [1000, 3], [1500, 1.2], ['MINI', 0.8], ['MINOR', 0.35], ['MAJOR', 0.06]];
export const JACKPOTS = { MINI: 2000, MINOR: 5000, MAJOR: 20000, GRAND: 100000 };
const coinValue = (rand) => pickWeighted(COIN_VALUES, rand);
const coinX = (v) => (typeof v === 'string' ? JACKPOTS[v] : v);

function vaultGrid(rand) {
  const grid = [];
  for (let r = 0; r < 5; r++) {
    const col = [];
    for (let row = 0; row < 3; row++) {
      let s = pickWeighted(Object.entries(VAULT_W), rand);
      if (s === 'WILD' && r === 0) s = 'K';
      col.push(s === 'COIN' ? { s, v: coinValue(rand) } : { s });
    }
    grid.push(col);
  }
  return grid;
}

/** Runs the whole Hold & Spin feature; returns each respin for animation. */
export function holdAndSpin(grid, bet, rand) {
  const locked = grid.map((col) => col.map((c) => (c.s === 'COIN' ? { v: c.v } : null)));
  const rounds = [];
  let left = 3;
  while (left > 0) {
    const landed = [];
    for (let r = 0; r < 5; r++) for (let row = 0; row < 3; row++) {
      if (!locked[r][row] && rand() < VAULT_COIN_P) { locked[r][row] = { v: coinValue(rand) }; landed.push([r, row]); }
    }
    left = landed.length ? 3 : left - 1;
    rounds.push({ landed, left, locked: locked.map((c) => c.map((x) => (x ? { ...x } : null))) });
    if (locked.every((c) => c.every(Boolean))) break;
  }
  const coins = locked.flat().filter(Boolean);
  const full = coins.length === 15;
  const x = coins.reduce((a, c) => a + coinX(c.v), 0) + (full ? JACKPOTS.GRAND : 0);
  return { rounds, full, total: Math.floor((bet * x) / 100), coins: coins.length };
}

export const vault = {
  id: 'vault', label: 'Coin Vault',
  init: () => ({ recent: [] }),
  view: (s) => ({ recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const bet = checkStake(body?.stake, { min: minStake, max: MAX_SPIN });
    const grid = vaultGrid(rand);
    const wins = lineWins(grid, bet, Object.fromEntries(Object.entries(VAULT_PAY).map(([k, v]) => [k, v.map((x) => x * VAULT_SCALE)])), { skip: ['COIN'] });
    let win = wins.reduce((a, w) => a + w.amount, 0);
    const coins = grid.flat().filter((c) => c.s === 'COIN').length;
    let feature = null;
    if (coins >= 6) { feature = holdAndSpin(grid, bet, rand); win += feature.total; }
    win = capWin(win, bet, 5000);
    return {
      stake: bet, payout: win, state: { recent: [{ bet, win, feature: !!feature }, ...state.recent].slice(0, 20) },
      out: { grid, wins, feature, win, bet },
      settled: { staked: bet, payout: win }, events: [{ t: 'slot', game: 'vault', x: win / bet, full: feature?.full, feature: !!feature }],
    };
  },
};

// ═══════════════════════ FRUIT SHACK ═══════════════════════
// Real reel strips; the payline is the middle row. Holds and nudges are
// offered at random after a losing spin.
export const FRUIT_STRIPS = [
  ['CHERRY', 'LEMON', 'BAR', 'PLUM', 'ORANGE', 'BELL', 'LEMON', 'CHERRY', 'ORANGE', 'PLUM', 'SEVEN', 'LEMON', 'ORANGE', 'BELL', 'PLUM', 'CHERRY', 'LEMON', 'ORANGE', 'BAR', 'PLUM', 'LEMON', 'ORANGE'],
  ['LEMON', 'ORANGE', 'CHERRY', 'PLUM', 'BELL', 'LEMON', 'BAR', 'ORANGE', 'PLUM', 'LEMON', 'CHERRY', 'BELL', 'ORANGE', 'SEVEN', 'PLUM', 'LEMON', 'ORANGE', 'CHERRY', 'PLUM', 'BELL', 'LEMON', 'ORANGE'],
  ['ORANGE', 'PLUM', 'LEMON', 'BELL', 'CHERRY', 'ORANGE', 'PLUM', 'BAR', 'LEMON', 'ORANGE', 'BELL', 'PLUM', 'CHERRY', 'LEMON', 'SEVEN', 'ORANGE', 'PLUM', 'LEMON', 'BELL', 'ORANGE', 'CHERRY', 'PLUM'],
];
// Pays as multiples of the stake
export const FRUIT_PAY = { SEVEN: 100, BAR: 50, BELL: 18, PLUM: 12, ORANGE: 8, LEMON: 6, CHERRY: 10 };
export const FRUIT_CHERRY = { 1: 0, 2: 2 }; // cherries on the line (any position)
export let FRUIT_HOLD_P = 0.28;
export let FRUIT_NUDGE_P = 0.13;
const L = FRUIT_STRIPS[0].length;

export const fruitLine = (stops) => stops.map((p, i) => FRUIT_STRIPS[i][p]);
export function fruitPays(line) {
  if (line[0] === line[1] && line[1] === line[2]) return FRUIT_PAY[line[0]];
  const ch = line.filter((s) => s === 'CHERRY').length;
  return FRUIT_CHERRY[ch] || 0;
}
export const fruitWindow = (stops) => stops.map((p, i) => [FRUIT_STRIPS[i][(p - 1 + L) % L], FRUIT_STRIPS[i][p], FRUIT_STRIPS[i][(p + 1) % L]]);

/** Best way to use n nudges (each moves one reel down by one): returns per-reel counts or null. */
export function bestNudges(stops, n) {
  let best = null, bestPay = 0;
  for (let a = 0; a <= n; a++) for (let b = 0; a + b <= n; b++) for (let c = 0; a + b + c <= n; c++) {
    const s = [(stops[0] - a + L) % L, (stops[1] - b + L) % L, (stops[2] - c + L) % L];
    const p = fruitPays(fruitLine(s));
    if (p > bestPay) { bestPay = p; best = [a, b, c]; }
  }
  return best ? { moves: best, pay: bestPay } : null;
}
/** A sensible hold choice: hold any reels showing a pair of the best symbol. */
export function suggestHolds(line) {
  const order = ['SEVEN', 'BAR', 'BELL', 'PLUM', 'CHERRY', 'ORANGE', 'LEMON'];
  for (const sym of order) {
    const idx = line.map((s, i) => (s === sym ? i : -1)).filter((i) => i >= 0);
    if (idx.length >= 2) return [0, 1, 2].map((i) => idx.includes(i));
  }
  return [false, false, false];
}

export const fruit = {
  id: 'fruit', label: 'Fruit Shack',
  init: () => ({ stops: [0, 3, 5], offer: null, nudges: 0, lastStake: 0, recent: [] }),
  view: (s) => ({ stops: s.stops, window: fruitWindow(s.stops), offer: s.offer, nudges: s.nudges, lastStake: s.lastStake, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action === 'nudge') {
      if (!state.nudges) fail('No nudges left.');
      const reel = body?.reel;
      if (![0, 1, 2].includes(reel)) fail('Choose a reel to nudge.');
      const stops = [...state.stops];
      stops[reel] = (stops[reel] - 1 + L) % L;
      const pay = fruitPays(fruitLine(stops));
      const win = pay * state.lastStake;
      const nudges = pay ? 0 : state.nudges - 1;
      return {
        stake: 0, payout: win, state: { ...state, stops, nudges, offer: null },
        out: { stops, window: fruitWindow(stops), nudged: reel, win, nudges, pay },
        settled: { staked: 0, payout: win }, events: win ? [{ t: 'slot', game: 'fruit', x: pay }] : [],
      };
    }
    if (action === 'collect') return { stake: 0, payout: 0, state: { ...state, nudges: 0 }, out: { nudges: 0 } };
    if (action !== 'spin') fail('Unknown action.');
    const stake = checkStake(body?.stake, { min: minStake, max: 5000 });
    const holds = Array.isArray(body?.holds) ? body.holds.map(Boolean) : [false, false, false];
    if (holds.some(Boolean) && (!state.offer || stake !== state.lastStake)) fail('Holds are only available on the spin straight after they are offered, at the same stake.');
    if (holds.every(Boolean)) fail('You can hold at most two reels.');
    const stops = state.stops.map((p, i) => (holds[i] ? p : Math.floor(rand() * L)));
    const pay = fruitPays(fruitLine(stops));
    const win = pay * stake;
    let offer = null, nudges = 0;
    if (!pay) {
      if (!holds.some(Boolean) && rand() < FRUIT_HOLD_P) offer = { suggested: suggestHolds(fruitLine(stops)) };
      else if (rand() < FRUIT_NUDGE_P) nudges = 1 + Math.floor(rand() * 4);
    }
    return {
      stake, payout: win,
      state: { stops, offer, nudges, lastStake: stake, recent: [{ stake, win }, ...state.recent].slice(0, 20) },
      out: { stops, window: fruitWindow(stops), held: holds, win, pay, offer, nudges },
      settled: { staked: stake, payout: win }, events: [{ t: 'slot', game: 'fruit', x: pay }],
    };
  },
};

// ═══════════════════════ STARLIGHT OBSERVATORY ═══════════════════════
const STAR_W = { 10: 30, J: 30, Q: 28, K: 26, A: 26, MOON: 12, SATURN: 9, ROCKET: 6, ASTRO: 4, SCOPE: 3.6 };
const STAR_W_FREE = { ...STAR_W, SCOPE: 2.2 };
export const STAR_PAY = {
  10: [20, 60, 200], J: [20, 60, 200], Q: [20, 60, 200], K: [25, 75, 250], A: [25, 75, 250],
  MOON: [40, 150, 500], SATURN: [60, 200, 800], ROCKET: [80, 400, 2000], ASTRO: [100, 1000, 5000],
  SCOPE: [100, 1000, 5000],
};
export const STAR_SCATTER = { 3: 200, 4: 2000, 5: 20000 }; // hundredths of total bet
export let STAR_SCALE = 6.26;
const PREMIUM = new Set(['ROCKET', 'ASTRO']);
export const STAR_SPECIALS = ['10', 'J', 'Q', 'K', 'A', 'MOON', 'SATURN', 'ROCKET', 'ASTRO'];
const scaled = (pt) => Object.fromEntries(Object.entries(pt).map(([k, v]) => [k, v.map((x) => x * STAR_SCALE)]));

function starGrid(rand, free) {
  return Array.from({ length: 5 }, () => Array.from({ length: 3 }, () => ({ s: pickWeighted(Object.entries(free ? STAR_W_FREE : STAR_W), rand) })));
}

export const starlight = {
  id: 'starlight', label: 'Starlight Observatory',
  init: () => ({ free: null, recent: [] }),
  view: (s) => ({ free: s.free, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = free ? free.bet : checkStake(body?.stake, { min: minStake, max: MAX_SPIN });
    const grid = starGrid(rand, !!free);
    const pt = scaled(STAR_PAY);
    const wins = lineWins(grid, bet, pt, { wild: 'SCOPE' });
    let win = wins.reduce((a, w) => a + w.amount, 0);
    const scopes = grid.flat().filter((c) => c.s === 'SCOPE').length;
    const scatterWin = scopes >= 3 ? Math.floor((bet * STAR_SCATTER[Math.min(5, scopes)] * STAR_SCALE) / 100) : 0;
    win += scatterWin;
    let expand = null;
    if (free) {
      const sym = free.special;
      const reels = grid.map((col, i) => (col.some((c) => c.s === sym) ? i : -1)).filter((i) => i >= 0);
      if (reels.length >= (PREMIUM.has(sym) ? 2 : 3)) {
        const k = Math.min(5, reels.length);
        const x = (k >= 3 ? pt[sym][k - 3] : (sym === 'ASTRO' ? 10 : 5) * STAR_SCALE);
        const amount = Math.floor((bet * x * LINES_10.length) / 100 / 1);
        expand = { sym, reels, amount };
        win += amount;
      }
    }
    win = capWin(win, bet, 5000);
    let next = null, trigger = null;
    if (free) {
      next = { ...free, remaining: free.remaining - 1, total: free.total + win };
      if (scopes >= 3) { next.remaining += 10; trigger = { extra: 10 }; }
    } else if (scopes >= 3) {
      const special = STAR_SPECIALS[Math.floor(rand() * STAR_SPECIALS.length)];
      next = { bet, remaining: 10, total: 0, special };
      trigger = { freeSpins: 10, special };
    }
    const finished = next && free && next.remaining <= 0 ? { total: next.total } : null;
    if (finished) next = null;
    return {
      stake: free ? 0 : bet, payout: win,
      state: { free: next, recent: (!free || finished) ? [{ bet, win: finished ? finished.total : win }, ...state.recent].slice(0, 20) : state.recent },
      out: { grid, wins, scatterWin, scopes, expand, trigger, free: next, finished, win, bet },
      settled: free ? { staked: 0, payout: win } : { staked: bet, payout: win }, events: [{ t: 'slot', game: 'starlight', x: win / bet, feature: !!trigger?.freeSpins }],
    };
  },
};

// Tuning hooks used by the simulation script
export const _tune = {
  set nebScale(v) { NEB_SCALE = v; }, set vaultScale(v) { VAULT_SCALE = v; }, set vaultCoinP(v) { VAULT_COIN_P = v; }, set starScale(v) { STAR_SCALE = v; },
  set fruitHold(v) { FRUIT_HOLD_P = v; }, set fruitNudge(v) { FRUIT_NUDGE_P = v; },
};
