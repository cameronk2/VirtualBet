// Golden Wishes – reel draw and 20-line evaluation (pure).
// A grid is [reel][row] of symbol ids.
import { LAMP, LINES, LINE_SYMBOLS, PAYTABLE, PAY_SCALE, REELS, ROWS, STAR, WEIGHTS, WILD } from './config.js';

export function weighted(pairs, rand) {
  let t = 0; for (const [, w] of pairs) t += w;
  let x = rand() * t;
  for (const [v, w] of pairs) if ((x -= w) < 0) return v;
  return pairs[pairs.length - 1][0];
}

const tables = (set) => WEIGHTS[set].map((w) => Object.entries(w).filter(([, x]) => x > 0));
const TABLES = { base: tables('base'), free: tables('free') };
const SPECIAL = new Set([LAMP, STAR]);

/** A fresh grid. At most one lamp and one star per reel. */
export function draw(rand, free = false) {
  return TABLES[free ? 'free' : 'base'].map((t) => {
    const used = new Set();
    return Array.from({ length: ROWS }, () => {
      const pool = used.size ? t.filter(([s]) => !used.has(s)) : t;
      const s = weighted(pool, rand);
      if (SPECIAL.has(s)) used.add(s);
      return s;
    });
  });
}

/** Free spins: every reel holding a Genie becomes all Genie. Returns the reels that expanded. */
export function expandWilds(grid) {
  const reels = [];
  const out = grid.map((col, r) => {
    if (!col.includes(WILD)) return col;
    if (col.some((s) => s !== WILD)) reels.push(r);
    // lamps and stars under an expanding genie stay where they are (they still count)
    return col.map((s) => (SPECIAL.has(s) ? s : WILD));
  });
  return { grid: out, reels };
}

/** Line pay in pence for `count` of `sym` at total bet `bet`. */
export const linePay = (sym, count, bet, mult = 1) => Math.floor((bet * PAYTABLE[sym][count - 3] * PAY_SCALE * mult) / LINES.length);

/**
 * Left-to-right line wins. Genie substitutes for every line symbol; a line
 * starting with Genies pays whichever is larger: the Genie run itself or the
 * symbol it completes. Each line pays once (its best win), and lines add up.
 */
export function evaluateLines(grid, bet, mult = 1) {
  const wins = [];
  LINES.forEach((rows, line) => {
    const syms = rows.map((row, r) => grid[r][row]);
    let wildRun = 0;
    while (wildRun < REELS && syms[wildRun] === WILD) wildRun++;
    const target = syms.find((s) => s !== WILD);
    let best = null;
    if (wildRun >= 3) best = { symbol: WILD, count: wildRun };
    if (target && LINE_SYMBOLS.includes(target)) {
      let n = 0;
      while (n < REELS && (syms[n] === target || syms[n] === WILD)) n++;
      if (n >= 3) {
        const cand = { symbol: target, count: n };
        if (!best || linePay(target, n, 1e6) > linePay(WILD, best.count, 1e6)) best = cand;
      }
    }
    if (!best) return;
    const amount = linePay(best.symbol, best.count, bet, mult);
    if (amount > 0) wins.push({ line, symbol: best.symbol, count: best.count, amount, mult, cells: rows.slice(0, best.count).map((row, r) => [r, row]) });
  });
  return wins.sort((a, b) => b.amount - a.amount);
}

export const cellsOf = (grid, s) => grid.flatMap((col, r) => col.map((x, row) => (x === s ? [r, row] : null)).filter(Boolean));
