// Golden Wishes – Genie's Treasure (jackpot pick), pure.
//
// When the bonus starts the jackpot is drawn by JACKPOT_WEIGHTS and a board of
// 12 treasures is dealt: three jewels of that jackpot, plus 9 tiles of decoy
// jewels (never three of one other kind), cash prizes and at most one
// multiplier. The board order is shuffled with the platform RNG and kept on
// the server; each pick turns over the next treasure in that order, so which
// tile you tap cannot change the result. The bonus ends on the third
// matching jewel: that jackpot plus every prize found, times the multiplier.
import { JACKPOTS, JACKPOT_ORDER, JACKPOT_WEIGHTS, TREASURE_CASH, TREASURE_FILL, TREASURE_MULT, TREASURE_TILES } from './config.js';
import { weighted } from './reels.js';

export function dealTreasure(rand, forced) {
  const target = forced || weighted(Object.entries(JACKPOT_WEIGHTS), rand);
  const items = [{ k: 'JP', v: target }, { k: 'JP', v: target }, { k: 'JP', v: target }];
  const count = { [target]: 3 };
  let mults = 0;
  while (items.length < TREASURE_TILES) {
    const pool = TREASURE_FILL.filter(([k]) => (JACKPOTS[k] ? k !== target && (count[k] || 0) < 2 : k === 'MULT' ? mults < 1 : true));
    const k = weighted(pool, rand);
    if (JACKPOTS[k]) { count[k] = (count[k] || 0) + 1; items.push({ k: 'JP', v: k }); }
    else if (k === 'MULT') { mults++; items.push({ k: 'MULT', v: weighted(TREASURE_MULT, rand) }); }
    else items.push({ k: 'CASH', v: weighted(TREASURE_CASH, rand) });
  }
  for (let i = items.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [items[i], items[j]] = [items[j], items[i]]; }
  return { target, deck: items, picks: {}, order: [], done: false };
}

/** Totals of what has been turned over so far. */
export function treasureTotals(t) {
  const got = t.order.map((i) => t.picks[i]);
  const jp = {}; for (const g of got) if (g.k === 'JP') jp[g.v] = (jp[g.v] || 0) + 1;
  const cashX = got.filter((g) => g.k === 'CASH').reduce((a, g) => a + g.v, 0);
  const mult = got.filter((g) => g.k === 'MULT').reduce((a, g) => a * g.v, 1);
  const won = JACKPOT_ORDER.find((k) => jp[k] >= 3) || null;
  const totalX = ((won ? JACKPOTS[won] : 0) + cashX) * mult;
  return { jp, cashX, mult, won, totalX };
}

/** Turn over tile `tile` (0-11). Returns what was found. */
export function pickTreasure(t, tile) {
  if (t.done) throw new Error('done');
  const item = t.deck[t.order.length];
  t.picks[tile] = item; t.order.push(tile);
  const tot = treasureTotals(t);
  if (tot.won) t.done = true;
  return { tile, item, ...tot, done: t.done };
}

/** The unpicked tiles' contents, shown when the bonus ends. */
export function revealRest(t) {
  const rest = t.deck.slice(t.order.length);
  const out = {};
  let k = 0;
  for (let i = 0; i < TREASURE_TILES; i++) if (!t.picks[i]) out[i] = rest[k++];
  return out;
}

/** Public view: only what has been picked. */
export const treasureView = (t) => t && { picks: { ...t.picks }, order: [...t.order], ...treasureTotals(t), done: t.done, bet: t.bet, source: t.source };
