// Golden Wishes – every number that defines the game. Logic lives in
// reels.js / treasure.js / engine.js and reads only from here, so the
// return, volatility, symbol weights and jackpot odds can all be changed
// without touching code. After changing anything that moves the return,
// run `node scripts/tune-genie.mjs 2000000` and adjust PAY_SCALE (or the
// feature weights) until it reports the TARGET_RTP. See docs/genie-mechanics.md.
//
// An original Arabian Nights slot: 5 reels x 3 rows, 20 fixed lines.
//   • Genie        wild (all reels), also the top paying symbol
//   • Magic Lamp   3/4/5 anywhere → the Genie grants a wish (cash, multiplied
//                  cash, free spins or Genie's Treasure)
//   • Wishing Star 3/4/5 anywhere → pays and awards 10/15/20 free spins
//                  (wins ×2, Genie wilds expand to fill their reel)
//   • Genie's Treasure: pick treasures until three jewels match; that
//                  jackpot is won (Mini / Minor / Major / Grand), plus any
//                  prizes and multiplier found on the way.
// Money values are integer pence; prizes are multiples of the total bet.

export const TARGET_RTP = 0.96;
export const REELS = 5;
export const ROWS = 3;
export const STAKE_MAX = 10000;
export const MAX_WIN_X = 10000;          // cap per spin and per feature, x total bet

// 20 fixed lines (row index per reel, 0 = top).
export const LINES = [
  [1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2],
  [0, 0, 1, 2, 2], [2, 2, 1, 0, 0], [1, 0, 0, 0, 1], [1, 2, 2, 2, 1], [1, 0, 1, 2, 1],
  [1, 2, 1, 0, 1], [0, 1, 1, 1, 0], [2, 1, 1, 1, 2], [0, 1, 0, 1, 0], [2, 1, 2, 1, 2],
  [1, 1, 0, 1, 1], [1, 1, 2, 1, 1], [0, 0, 2, 0, 0], [2, 2, 0, 2, 2], [0, 2, 0, 2, 0],
];

// Line pays for 3 / 4 / 5 of a kind, in multiples of the line bet (total bet ÷ 20).
export const PAYTABLE = {
  GENIE: [50, 250, 1000],
  PRINCESS: [40, 150, 500],
  PALACE: [30, 120, 400],
  CHEST: [25, 100, 300],
  CROWN: [20, 80, 250],
  AMETHYST: [15, 50, 150],
  EMERALD: [15, 50, 150],
  RUBY: [12, 40, 125],
  A: [10, 30, 100], K: [10, 30, 100], Q: [8, 25, 80], J: [8, 25, 80], T: [5, 20, 60],
};
export const PAY_SCALE = 1.95;            // the RTP knob; tuned by scripts/tune-genie.mjs
export const WILD = 'GENIE';
export const LAMP = 'LAMP';
export const STAR = 'STAR';
export const LINE_SYMBOLS = Object.keys(PAYTABLE);

// Reel weights (higher = more common). LAMP and STAR are limited to one per reel.
// Volatility is shaped here: fewer low symbols / more features = higher volatility.
const BASE = { GENIE: 2.4, PRINCESS: 3, PALACE: 3.5, CHEST: 4, CROWN: 4.5, AMETHYST: 6, EMERALD: 6, RUBY: 6.5, A: 13, K: 13, Q: 14, J: 14, T: 15 };
export const WEIGHTS = {
  base: Array.from({ length: REELS }, () => ({ ...BASE, LAMP: 4.4, STAR: 3.3 })),
  free: Array.from({ length: REELS }, () => ({ ...BASE, GENIE: 2.6, LAMP: 4, STAR: 2.6 })),
};

// Wishing Star scatters: pay x total bet anywhere, and award free spins.
export const SCATTER_PAY = { 3: 2, 4: 10, 5: 50 };
export const FREE_SPINS = { 3: 10, 4: 15, 5: 20 };
export const RETRIGGER = { 3: 5, 4: 10, 5: 15 };
export const MAX_FREE_SPINS = 100;
export const FREE_MULT = 3;              // all line and star wins in free spins
export const FREE_MIN_X = 15;            // a free-spins round always pays at least this x bet (topped up at the end)
export const FREE_EXPAND = true;         // Genie wilds fill their reel in free spins

// Magic Lamp wish. The wish type is weighted by how many lamps landed;
// more lamps also boost cash prizes (LAMP_BOOST) and free spins.
export const WISH_TYPES = {
  3: [['CASH', 52], ['MULT', 24], ['FREE', 14], ['TREASURE', 10]],
  4: [['CASH', 38], ['MULT', 26], ['FREE', 18], ['TREASURE', 18]],
  5: [['CASH', 20], ['MULT', 25], ['FREE', 20], ['TREASURE', 35]],
};
export const LAMP_BOOST = { 3: 1, 4: 2, 5: 4 };
export const WISH_CASH = [[5, 30], [8, 28], [10, 18], [15, 12], [20, 7], [30, 4], [50, 1]];  // x bet
export const WISH_MULT_BASE = [[3, 45], [5, 35], [8, 20]];                                    // x bet...
export const WISH_MULTIPLIER = [[2, 40], [3, 30], [5, 20], [10, 10]];                         // ...times this
export const WISH_FREE = { 3: 8, 4: 10, 5: 15 };

// Genie's Treasure (jackpot pick). The jackpot is drawn by these weights
// when the bonus starts; the picks reveal it. Fixed multiples of the bet.
export const JACKPOTS = { MINI: 15, MINOR: 40, MAJOR: 150, GRAND: 1000 };
export const JACKPOT_ORDER = ['MINI', 'MINOR', 'MAJOR', 'GRAND'];
export const JP_NAME = { MINI: 'Mini', MINOR: 'Minor', MAJOR: 'Major', GRAND: 'Grand' };
export const JACKPOT_WEIGHTS = { MINI: 60, MINOR: 29, MAJOR: 9.4, GRAND: 1.6 };
export const TREASURE_TILES = 12;
// What fills the other 9 tiles: decoy jewels (never 3 of one kind), cash and one multiplier at most.
export const TREASURE_FILL = [['MINI', 3], ['MINOR', 3], ['MAJOR', 2.5], ['GRAND', 2], ['CASH', 4], ['MULT', 1]];
export const TREASURE_CASH = [[1, 40], [2, 35], [5, 18], [10, 7]];                            // x bet
export const TREASURE_MULT = [[2, 75], [3, 25]];                                               // multiplies the treasure total
