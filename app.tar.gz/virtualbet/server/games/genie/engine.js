// Golden Wishes – game flow (server-authoritative, persisted state).
//
// Modes: base → free (3+ Wishing Stars) and/or treasure (a Lamp wish).
// A spin's whole result, including any wish, is decided here before anything
// animates. When a spin triggers both, Genie's Treasure plays first, then the
// free spins. A wish during free spins can add spins or start Genie's
// Treasure; the free spins carry on afterwards. Every action moves the saved
// state forward exactly once, so repeated taps or reloads can't pay twice.
import { checkStake, fail } from '../common.js';
import { FREE_EXPAND, FREE_MIN_X, FREE_MULT, FREE_SPINS, JACKPOTS, LAMP, LAMP_BOOST, MAX_FREE_SPINS, MAX_WIN_X, RETRIGGER, SCATTER_PAY, STAKE_MAX, STAR, TREASURE_TILES, WISH_CASH, WISH_FREE, WISH_MULTIPLIER, WISH_MULT_BASE, WISH_TYPES } from './config.js';
import { cellsOf, draw, evaluateLines, expandWilds, weighted } from './reels.js';
import { dealTreasure, pickTreasure, revealRest, treasureView } from './treasure.js';

export const init = () => ({ mode: 'base', queue: [], free: null, treasure: null, recent: [], practice: false, spins: 0 });
export const view = (s) => ({
  mode: s.mode, practice: !!s.practice, queue: (s.queue || []).map((q) => q.type),
  free: s.free && { bet: s.free.bet, remaining: s.free.remaining, played: s.free.played, total: s.free.total, awarded: s.free.awarded },
  treasure: treasureView(s.treasure),
  recent: (s.recent || []).slice(0, 15),
});

/** The Genie's wish for `lamps` lamps (3-5). `force` picks the type (practice only). */
export function makeWish(lamps, rand, force) {
  const n = Math.min(5, lamps);
  const type = force || weighted(WISH_TYPES[n], rand);
  const boost = LAMP_BOOST[n];
  if (type === 'CASH') return { type, lamps: n, x: weighted(WISH_CASH, rand) * boost };
  if (type === 'MULT') { const base = weighted(WISH_MULT_BASE, rand) * boost, mult = weighted(WISH_MULTIPLIER, rand); return { type, lamps: n, base, mult, x: base * mult }; }
  if (type === 'FREE') return { type, lamps: n, spins: WISH_FREE[n] };
  return { type: 'TREASURE', lamps: n };
}

function advance(s, out, rand) {
  const next = s.queue.shift();
  if (next?.type === 'treasure') {
    s.treasure = { ...dealTreasure(rand, next.forced), bet: next.bet, source: next.source };
    s.mode = 'treasure';
    out.started = { type: 'treasure', source: next.source };
  } else if (next?.type === 'free') {
    s.free = { bet: next.bet, remaining: next.spins, played: 0, total: 0, awarded: next.spins };
    s.mode = 'free';
    out.started = { type: 'free', spins: next.spins };
  } else if (s.free) {
    s.mode = 'free';
  } else {
    s.mode = 'base'; s.practice = false;
  }
}

/** Pays this action's win, keeping a spin or a free-spins round under the cap. */
function pay(s, raw, bet) {
  if (!s.free) return Math.min(raw, bet * MAX_WIN_X);
  const left = Math.max(0, s.free.bet * MAX_WIN_X - s.free.total);
  const p = Math.min(raw, left);
  s.free.total += p;
  return p;
}

/** Ends a finished free-spins round. Returns the top-up (pence) that lifts it to the guaranteed minimum. */
function finishFreeIfDone(s, out, rand) {
  const f = s.free;
  if (f && f.remaining <= 0 && s.mode !== 'treasure' && !s.queue.length) {
    const topUp = Math.max(0, f.bet * FREE_MIN_X - f.total);
    f.total += topUp;
    out.finished = { type: 'free', played: f.played, total: f.total, topUp };
    s.free = null;
    advance(s, out, rand);
    return topUp;
  }
  return 0;
}

export function act(state, action, body, { rand, minStake, inject }) {
  const s = { ...init(), ...structuredClone(state || {}) };
  const out = { action };
  const wasPractice = !!s.practice;
  let stake = 0, payout = 0, feature = false;

  if (action === 'spin' && (s.mode === 'base' || s.mode === 'free')) {
    const free = s.mode === 'free';
    const bet = free ? s.free.bet : checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    if (!free) stake = bet;
    const drawn = inject?.grid || draw(rand, free);
    const { grid, reels: expanded } = free && FREE_EXPAND ? expandWilds(drawn) : { grid: drawn, reels: [] };
    const mult = free ? FREE_MULT : 1;
    const wins = evaluateLines(grid, bet, mult);
    const stars = cellsOf(grid, STAR), lamps = cellsOf(grid, LAMP);
    const scatterWin = stars.length >= 3 ? bet * SCATTER_PAY[Math.min(5, stars.length)] * mult : 0;
    let wish = null;
    if (lamps.length >= 3) wish = makeWish(lamps.length, rand, inject?.wish);
    const wishWin = wish && (wish.type === 'CASH' || wish.type === 'MULT') ? bet * wish.x : 0;
    const lineWin = wins.reduce((a, w) => a + w.amount, 0);
    payout = pay(s, lineWin + scatterWin + wishWin, bet);
    Object.assign(out, { drawn, grid, expanded, wins, stars, lamps, scatterWin, wish, wishWin, lineWin, win: payout, bet, free, mult, capped: payout < lineWin + scatterWin + wishWin });

    // features
    let spinsAdded = 0, freeTrig = false;
    if (!free && stars.length >= 3) freeTrig = true;
    if (free && stars.length >= 3) spinsAdded += RETRIGGER[Math.min(5, stars.length)];
    if (wish?.type === 'FREE') { if (free) spinsAdded += wish.spins; else if (!freeTrig) freeTrig = true; }
    if (free && spinsAdded) {
      const add = Math.min(spinsAdded, MAX_FREE_SPINS - s.free.awarded);
      s.free.remaining += add; s.free.awarded += add; spinsAdded = add;
    }
    const treasureTrig = wish?.type === 'TREASURE';
    out.triggers = { free: freeTrig, treasure: treasureTrig, retrigger: free ? spinsAdded : 0 };
    feature = freeTrig || treasureTrig || !!wish;
    if (free) { s.free.remaining--; s.free.played++; out.remaining = s.free.remaining; }
    if (treasureTrig) s.queue.push({ type: 'treasure', bet, source: free ? 'free' : 'base' });
    if (freeTrig) {
      const spins = (stars.length >= 3 ? FREE_SPINS[Math.min(5, stars.length)] : 0) + (wish?.type === 'FREE' ? wish.spins : 0);
      s.queue.push({ type: 'free', bet, spins: Math.min(spins, MAX_FREE_SPINS) });
    }
    if (s.queue.length) advance(s, out, rand);
    else { const top = finishFreeIfDone(s, out, rand); payout += top; out.win = payout; }
    if (!free) s.spins = (s.spins || 0) + 1;
  } else if (action === 'pick') {
    if (s.mode !== 'treasure') fail("There is no Genie's Treasure in play.");
    const t = s.treasure;
    const tile = body?.tile;
    if (!Number.isInteger(tile) || tile < 0 || tile >= TREASURE_TILES) fail('Pick a treasure.');
    if (t.picks[tile]) fail('That treasure is already open.');
    const r = pickTreasure(t, tile);
    Object.assign(out, r, { bet: t.bet });
    if (r.done) {
      const raw = Math.floor(t.bet * r.totalX);
      payout = pay(s, raw, t.bet);
      out.win = payout;
      out.rest = revealRest(t);
      out.treasureDone = { won: r.won, jackpotX: JACKPOTS[r.won], cashX: r.cashX, mult: r.mult, totalX: r.totalX, win: payout, source: t.source, capped: payout < raw };
      s.treasure = null;
      if (s.queue.length) advance(s, out, rand);
      else if (s.free) { s.mode = 'free'; const top = finishFreeIfDone(s, out, rand); payout += top; out.win = payout; }
      else advance(s, out, rand);
    }
  } else if (action === 'dev') {
    // Practice triggers for testing: cost nothing, pay nothing.
    if (s.mode !== 'base' || s.queue.length) fail('Finish the current feature first.');
    const bet = checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    s.practice = true;
    const ev = body?.event;
    if (ev === 'free') s.queue.push({ type: 'free', bet, spins: FREE_SPINS[3] });
    else if (['MINI', 'MINOR', 'MAJOR', 'GRAND'].includes(ev)) s.queue.push({ type: 'treasure', bet, source: 'base', forced: ev });
    else if (['CASH', 'MULT', 'FREE', 'TREASURE'].includes(ev)) {
      // a practice spin with three lamps and the chosen wish
      const grid = [['T', 'LAMP', 'Q'], ['J', 'RUBY', 'LAMP'], ['K', 'LAMP', 'A'], ['Q', 'T', 'CROWN'], ['EMERALD', 'J', 'T']];
      const r = act({ ...s, practice: true }, 'spin', { stake: bet }, { rand, minStake, inject: { grid, wish: ev } });
      r.state.practice = r.state.mode !== 'base'; r.out.practice = true;
      return { stake: 0, payout: 0, state: r.state, out: { ...r.out, payout: 0, view: view(r.state) }, settled: { staked: 0, payout: 0 }, events: [] };
    } else fail('Unknown test event.');
    advance(s, out, rand);
  } else if (action === 'spin') {
    fail("Finish Genie's Treasure first.");
  } else fail('Unknown action.');

  if (wasPractice || s.practice) { stake = 0; payout = 0; out.practice = true; }
  out.payout = payout; out.staked = stake; out.mode = s.mode;
  if (stake || payout) s.recent = [{ bet: out.bet, win: payout, kind: action === 'pick' ? 'treasure' : out.free ? 'free' : 'spin', jp: out.treasureDone?.won || undefined }, ...(s.recent || [])].slice(0, 20);
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'slot', game: 'genie', x: out.bet ? payout / out.bet : 0, feature }] };
}

export const genie = { id: 'genie', label: 'Golden Wishes', init, view, act };
