// Instant games: Crash, Plinko and Scratchcards.
import { checkStake, fail, pickWeighted } from './common.js';

// ── CRASH ──────────────────────────────────────────────────────────
// The crash point is fixed when the round starts: P(crash >= m) = 0.97 / m
// (3% house edge). The multiplier grows as e^(0.12·seconds). Cashing out
// is judged by the time the request arrives.
export const CRASH_RATE = 0.12;
export const multAt = (ms) => Math.floor(Math.exp((CRASH_RATE * ms) / 1000) * 100) / 100;
export const timeFor = (m) => (Math.log(m) / CRASH_RATE) * 1000;
function crashPoint(rand) {
  const u = rand();
  const m = Math.floor((0.97 / (1 - u)) * 100) / 100;
  return Math.min(1000, Math.max(1, m));
}

export const crash = {
  id: 'crash',
  label: 'Crash',
  init: () => ({ round: null, recent: [] }),
  view: (s, now) => ({ round: s.round ? { stake: s.round.stake, auto: s.round.auto, startAt: s.round.startAt, now } : null, recent: s.recent.slice(0, 20) }),
  act(state, action, body, { rand, now, minStake, maxStake }) {
    const r = state.round;
    // Resolve a round that has already crashed or hit its auto cash-out
    const settle = (m, cashed) => {
      const payout = cashed ? Math.floor((r.stake * Math.round(m * 100)) / 100) : 0;
      const recent = [r.crash, ...state.recent].slice(0, 30);
      return {
        stake: 0, payout, state: { round: null, recent },
        out: { done: true, crashedAt: r.crash, cashedAt: cashed ? m : null, payout, stake: r.stake },
        settled: { staked: r.stake, payout },
        events: [{ t: 'crash', cashedAt: cashed ? m : null, crash: r.crash }],
      };
    };
    if (action === 'start') {
      if (r) fail('A round is already running.');
      const stake = checkStake(body?.stake, { min: minStake, max: maxStake });
      let auto = body?.auto ? Number(body.auto) : null;
      if (auto !== null && !(auto >= 1.01 && auto <= 1000)) fail('Auto cash-out must be between 1.01x and 1000x.');
      if (auto) auto = Math.floor(auto * 100) / 100;
      const round = { stake, auto, crash: crashPoint(rand), startAt: now + 1200 }; // short countdown
      return { stake, payout: 0, state: { ...state, round }, out: { started: true, startAt: round.startAt, now, auto } };
    }
    if (!r) return { stake: 0, payout: 0, state, out: { idle: true } };
    const elapsed = Math.max(0, now - r.startAt);
    const crashMs = timeFor(r.crash);
    if (r.auto && r.auto <= r.crash && elapsed >= timeFor(r.auto)) return settle(r.auto, true);
    if (elapsed >= crashMs) return settle(r.crash, false);
    if (action === 'cashout') {
      if (now < r.startAt) fail('The round has not started yet.');
      const m = Math.max(1, Math.min(multAt(elapsed), r.crash));
      return settle(m, true);
    }
    if (action === 'tick') return { stake: 0, payout: 0, state, out: { running: true, mult: now < r.startAt ? 1 : multAt(elapsed), startAt: r.startAt, now } };
    fail('Unknown action.');
  },
};

// ── PLINKO ─────────────────────────────────────────────────────────
// 12 rows of pegs, the ball goes left or right at each one with equal
// chance, so it lands in slot k with probability C(12,k)/4096.
export const PLINKO = {
  low: [10, 3, 1.6, 1.4, 1.1, 0.95, 0.5, 0.95, 1.1, 1.4, 1.6, 3, 10],
  medium: [33, 11, 4, 2, 1.1, 0.55, 0.3, 0.55, 1.1, 2, 4, 11, 33],
  high: [170, 24, 8.1, 2, 0.6, 0.2, 0.2, 0.2, 0.6, 2, 8.1, 24, 170],
};
export const PLINKO_ROWS = 12;

export const plinko = {
  id: 'plinko',
  label: 'Plinko',
  init: () => ({ recent: [] }),
  view: (s) => ({ recent: s.recent.slice(0, 20) }),
  act(state, action, body, { rand, minStake, maxStake }) {
    if (action !== 'drop') fail('Unknown action.');
    const stake = checkStake(body?.stake, { min: minStake, max: Math.min(maxStake, 10000) });
    const risk = PLINKO[body?.risk] ? body.risk : 'low';
    const path = Array.from({ length: PLINKO_ROWS }, () => (rand() < 0.5 ? 0 : 1));
    const slot = path.reduce((a, b) => a + b, 0);
    const mult = PLINKO[risk][slot];
    const payout = Math.floor(stake * mult);
    return {
      stake, payout, state: { recent: [{ mult, risk }, ...state.recent].slice(0, 30) },
      out: { path, slot, mult, risk, payout, stake },
      settled: { staked: stake, payout },
      events: [{ t: 'plinko', mult, slot }],
    };
  },
};

// ── SCRATCHCARDS ──────────────────────────────────────────────────
// Match 3 identical prizes in a 3x3 grid to win that prize. Each ticket's
// outcome is fixed when it is bought; scratching only reveals it.
// Long-run return about 68% (similar to real scratchcards).
export const TICKETS = [100, 200, 500];
export const SCRATCH_PRIZES = [[1, 0.18], [2, 0.08], [5, 0.024], [10, 0.008], [20, 0.004], [100, 0.0004], [500, 0.00004]];
const PRIZE_POOL = [1, 2, 5, 10, 20, 100, 500];

export function makeTicket(rand) {
  const lose = 1 - SCRATCH_PRIZES.reduce((a, p) => a + p[1], 0);
  const win = pickWeighted([[0, lose], ...SCRATCH_PRIZES], rand);
  const cells = [];
  if (win) cells.push(win, win, win);
  const counts = new Map(win ? [[win, 3]] : []);
  while (cells.length < 9) {
    const v = PRIZE_POOL[Math.floor(rand() * PRIZE_POOL.length)];
    if ((counts.get(v) || 0) >= 2) continue;
    if (v === win) continue; // the winning prize appears exactly 3 times
    counts.set(v, (counts.get(v) || 0) + 1);
    cells.push(v);
  }
  for (let i = cells.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [cells[i], cells[j]] = [cells[j], cells[i]]; }
  return { cells, win };
}

export const scratch = {
  id: 'scratch',
  label: 'Scratchcards',
  init: () => ({ recent: [] }),
  view: (s) => ({ recent: s.recent.slice(0, 20) }),
  act(state, action, body, { rand }) {
    if (action !== 'buy') fail('Unknown action.');
    const price = body?.price;
    if (!TICKETS.includes(price)) fail('Choose a £1, £2 or £5 ticket.');
    const t = makeTicket(rand);
    const payout = t.win * price;
    return {
      stake: price, payout, state: { recent: [{ price, payout }, ...state.recent].slice(0, 30) },
      out: { cells: t.cells.map((m) => m * price), win: payout, price },
      settled: { staked: price, payout },
      events: [{ t: 'scratch', mult: t.win }],
    };
  },
};
