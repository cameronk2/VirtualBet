// Moonridge – Wild Expansion State Manager.
//
// Pure, deterministic bookkeeping for the Delayed Expanding Wilds. It knows
// nothing about rendering: the screen replays the events it emits.
//
//   LANDING → LOCKED → EXPANDING → FULL_COLUMN → DISAPPEARING → REMOVED
//
// A wild lands on one cell (LANDING) and counts as wild on that spin. When
// the spin settles it becomes LOCKED and stays put. At the start of each of
// the next spins it grows by one cell (EXPANDING); on a 4-row reel it fills
// the column on the third spin after landing (FULL_COLUMN), counts as a full
// wild reel for that spin, then DISAPPEARING → REMOVED when the spin settles.
// Every wild is tracked independently by id; removing one never touches
// another. Illegal or repeated transitions throw.

export const STAGE = Object.freeze({
  LANDING: 'LANDING', LOCKED: 'LOCKED', EXPANDING: 'EXPANDING',
  FULL_COLUMN: 'FULL_COLUMN', DISAPPEARING: 'DISAPPEARING', REMOVED: 'REMOVED',
});

const NEXT = {
  LANDING: ['LOCKED'],
  LOCKED: ['EXPANDING'],
  EXPANDING: ['EXPANDING', 'FULL_COLUMN'],
  FULL_COLUMN: ['DISAPPEARING'],
  DISAPPEARING: ['REMOVED'],
  REMOVED: [],
};

export class WildStateError extends Error {}

function to(w, stage, spin, events) {
  if (!NEXT[w.stage].includes(stage)) throw new WildStateError(`Wild ${w.id}: illegal transition ${w.stage} → ${stage}`);
  w.stage = stage;
  w.trail.push([stage, spin]);
  events?.push({ type: 'stage', id: w.id, reel: w.reel, stage });
}

/**
 * Rows the wild grows into, in order. It grows one cell per spin, toward the
 * side with more room first and then alternating, so it always spreads out
 * from where it landed until the column is full.
 */
export function growthOrder(startRow, rows) {
  const order = [];
  let up = startRow - 1, down = startRow + 1;
  let goDown = rows - 1 - startRow >= startRow;
  while (order.length < rows - 1) {
    if (goDown && down < rows) order.push(down++);
    else if (!goDown && up >= 0) order.push(up--);
    else if (down < rows) order.push(down++);
    else order.push(up--);
    goDown = !goDown;
  }
  return order;
}

const sync = (w, rows) => {
  w.remaining = rows - w.occupied.length;
  w.progress = w.occupied.length / rows;
  w.complete = w.occupied.length === rows;
};

/** A wild that has just landed. It is wild immediately, on this spin. */
export function createWild({ id, reel, row, kind, mult, spin, rows }) {
  const w = {
    id, reel, startRow: row, kind, mult,
    stage: STAGE.LANDING, occupied: [row], remaining: rows - 1, progress: 1 / rows,
    sticky: true, complete: false, removed: false,
    landedSpin: spin, lastStep: spin, order: growthOrder(row, rows), trail: [[STAGE.LANDING, spin]],
  };
  sync(w, rows);
  return w;
}

/**
 * Start of a spin: every standing wild grows by one cell. Runs once per wild
 * per spin (guarded by `lastStep`), so a replayed call cannot double-grow.
 */
export function advance(wilds, spin, rows, events = []) {
  for (const w of wilds) {
    if (w.lastStep >= spin) throw new WildStateError(`Wild ${w.id} already advanced on spin ${spin}`);
    if (w.stage !== STAGE.LOCKED && w.stage !== STAGE.EXPANDING) throw new WildStateError(`Wild ${w.id} cannot grow from ${w.stage}`);
    w.lastStep = spin;
    const row = w.order[w.occupied.length - 1];
    w.occupied.push(row);
    to(w, STAGE.EXPANDING, spin, null);
    events.push({ type: 'grow', id: w.id, reel: w.reel, row, size: w.occupied.length });
    sync(w, rows);
    if (w.complete) {
      to(w, STAGE.FULL_COLUMN, spin, null);
      events.push({ type: 'full', id: w.id, reel: w.reel });
    }
  }
  return events;
}

/**
 * End of a spin: new wilds lock; full columns play out and are removed.
 * Returns the wilds that carry over to the next spin.
 */
export function settle(wilds, spin, events = []) {
  const keep = [];
  for (const w of wilds) {
    if (w.stage === STAGE.LANDING) {
      to(w, STAGE.LOCKED, spin, null);
      events.push({ type: 'lock', id: w.id, reel: w.reel, row: w.startRow });
      keep.push(w);
    } else if (w.stage === STAGE.FULL_COLUMN) {
      to(w, STAGE.DISAPPEARING, spin, null);
      to(w, STAGE.REMOVED, spin, null);
      w.removed = true; w.sticky = false; w.occupied = [];
      events.push({ type: 'vanish', id: w.id, reel: w.reel });
    } else if (w.stage === STAGE.EXPANDING) {
      keep.push(w);
    } else {
      throw new WildStateError(`Wild ${w.id} cannot settle from ${w.stage}`);
    }
  }
  return keep;
}

/** reel → wild, for the reels that currently hold one. */
export const byReel = (wilds) => Object.fromEntries(wilds.map((w) => [w.reel, w]));

/** Public snapshot (what the screen and the saved state need). */
export const snapshot = (w) => ({
  id: w.id, reel: w.reel, startRow: w.startRow, kind: w.kind, mult: w.mult, stage: w.stage,
  occupied: [...w.occupied], remaining: w.remaining, progress: w.progress,
  sticky: w.sticky, complete: w.complete, removed: w.removed, landedSpin: w.landedSpin,
});
