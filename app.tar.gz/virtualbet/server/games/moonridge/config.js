// Moonridge – configuration. Everything that defines the maths lives here:
// layout, paytable, features, reel weight tables and the volatility profiles.
//
// Where the original game's rules could be verified (two public reviews,
// see docs/moonridge-mechanics.md) the values are copied as published:
// 5x4 reels, 40 lines, the line paytable, scatter pays, 20 free spins,
// the five jackpot values and the 5,666x maximum win. Reel weights are not
// public for any commercial slot, so those are ours, tuned by simulation.
import { LINES_40 } from '../slots3.js';

export const REELS = 5;
export const ROWS = 4;
export const LINES = LINES_40;

// Pays in hundredths of the TOTAL bet (60 = 0.6x), for 3 / 4 / 5 of a kind.
export const PAYTABLE = {
  WILD: [60, 180, 1250],
  GRAY: [30, 90, 500],
  BLACK: [25, 60, 375],
  WHITE: [18, 50, 250],
  EAGLE: [12, 30, 125],
  AMULET: [6, 25, 90],
  A: [6, 18, 60],
  K: [6, 18, 60],
  Q: [6, 18, 60],
};
export const LINE_SYMBOLS = ['GRAY', 'BLACK', 'WHITE', 'EAGLE', 'AMULET', 'A', 'K', 'Q'];

// Expanding (Delayed Expanding Wild) kinds and their multipliers.
export const EXPANDERS = { W2: 2, W3: 3, WG: 1 };
export const WILDS = new Set(['WILD', 'W2', 'W3', 'WG']);

// Bonus scatter: pays anywhere (x total bet) and 3+ start free spins.
export const SCATTER_PAY = { 3: 500, 4: 1000, 5: 2500 };
export const FREE_SPINS = 20;
export const RETRIGGER_PER_BONUS = 1; // each bonus symbol in free spins adds this many

// Jackpots: the same jackpot coin on 3+ adjacent reels. Hundredths of bet.
export const JACKPOTS = [
  { sym: 'J1', name: 'Mini', pay: 1250 },
  { sym: 'J2', name: 'Minor', pay: 6250 },
  { sym: 'J3', name: 'Maxi', pay: 12500 },
  { sym: 'J4', name: 'Major', pay: 31250 },
  { sym: 'J5', name: 'Grand', pay: 125000 },
];

export const MAX_WIN_X = 5666;
export const STAKE_MAX = 10000; // £100, the site-wide slot cap

// Symbols that take a whole reel's "special" slot: a reel never shows more
// than one of these at once (like spaced-out symbols on a physical strip).
export const SPECIAL = new Set(['W2', 'W3', 'WG', 'BONUS', 'J1', 'J2', 'J3', 'J4', 'J5']);

/**
 * Volatility profiles. Each is a full set of reel weights (per reel, per
 * symbol, base and free spins). The expanding-wild weights are multiplied by
 * a solved scale (one for the base game, one for free spins): those two
 * knobs are what the tuner (scripts/tune-moonridge.mjs) solves to hit the
 * target return. The paytable never changes.
 */
const base = { Q: 30, K: 30, A: 28, AMULET: 22, EAGLE: 18, WHITE: 14, BLACK: 12, GRAY: 10, WILD: 3 };
const jp = (k) => ({ J1: 3.2 * k, J2: 1.5 * k, J3: 1.04 * k, J4: 0.65 * k, J5: 0.35 * k });

export const PROFILES = {
  high: {
    label: 'High volatility (default)', target: 95,
    expand: { W2: 1.0, W3: 0.7, WG: 0.8 },
    expandFree: { W2: 2.2, W3: 1.6, WG: 1.4 },
    bonus: 4.4, bonusFree: 1.4, jackpot: 1,
    base,
  },
  medium: {
    label: 'Medium volatility', target: 95,
    expand: { W2: 1.6, W3: 0.45, WG: 1.2 },
    expandFree: { W2: 2.6, W3: 0.9, WG: 1.8 },
    bonus: 4.6, bonusFree: 1.4, jackpot: 1,
    base: { ...base, Q: 26, K: 26, A: 24 },
  },
  low: {
    label: 'Low volatility', target: 95,
    expand: { W2: 2.0, W3: 0.2, WG: 1.6 },
    expandFree: { W2: 2.8, W3: 0.4, WG: 2.2 },
    bonus: 4.2, bonusFree: 1.4, jackpot: 1,
    base: { ...base, Q: 22, K: 22, A: 20, AMULET: 20 },
  },
};

// Solved scales (see README "Moonridge maths"). Written by the tuner.
export const SOLVED = { high: { base: 0.37, free: 0.36 }, medium: { base: 0.29, free: 0.31 }, low: { base: 0.257, free: 0.285 } };

export const ACTIVE_PROFILE = (typeof process !== 'undefined' && process.env?.MOONRIDGE_PROFILE) || 'high';

/** Weight tables [reel][[symbol, weight]] for a profile, base or free. */
export function weightTables(profileId = ACTIVE_PROFILE, free = false, scales = SOLVED[profileId]) {
  const p = PROFILES[profileId];
  if (!p) throw new Error(`Unknown Moonridge profile ${profileId}`);
  const wildScale = free ? scales.free : scales.base;
  const ex = free ? p.expandFree : p.expand;
  return Array.from({ length: REELS }, () => {
    const t = { ...p.base };
    for (const [k, v] of Object.entries(ex)) t[k] = v * wildScale;
    t.BONUS = free ? p.bonusFree : p.bonus;
    for (const [k, v] of Object.entries(jp(p.jackpot))) t[k] = v;
    return Object.entries(t).filter(([, v]) => v > 0);
  });
}
