// Moonridge – maths engine (pure, integer pence, no rendering).
//
// One spin, in order:
//   1. Standing wilds advance one stage (grow a cell / fill the column).
//   2. Every cell they do not occupy is drawn from the reel weight tables.
//      Locked cells are never redrawn or overwritten.
//   3. Expanding wilds that land on a free reel start their own cycle.
//   4. Lines, scatter and jackpots are evaluated on the final grid.
//   5. Wilds settle: new ones lock, full columns disappear and are removed.
// All randomness comes from `rand` (crypto in production, seeded in tests).
import {
  REELS, ROWS, LINES, PAYTABLE, LINE_SYMBOLS, EXPANDERS, WILDS, SCATTER_PAY, FREE_SPINS,
  RETRIGGER_PER_BONUS, JACKPOTS, MAX_WIN_X, SPECIAL, ACTIVE_PROFILE, weightTables,
} from './config.js';
import { advance, byReel, createWild, settle, snapshot } from './wilds.js';

const cumulative = (table) => {
  let t = 0;
  const syms = [], cum = [];
  for (const [s, w] of table) { t += w; syms.push(s); cum.push(t); }
  return { syms, cum, total: t };
};
function draw(c, rand) {
  const x = rand() * c.total;
  let lo = 0, hi = c.cum.length - 1;
  while (lo < hi) { const m = (lo + hi) >> 1; if (x < c.cum[m]) hi = m; else lo = m + 1; }
  return c.syms[lo];
}

const cache = new Map();
/** Prepared reels for a profile: full and "no special" draw tables per reel. */
export function reelSet(profile = ACTIVE_PROFILE, free = false, scales) {
  const key = `${profile}|${free}|${scales ? `${scales.base},${scales.free}` : ''}`;
  if (!cache.has(key)) {
    const tables = weightTables(profile, free, scales);
    cache.set(key, tables.map((t) => ({ all: cumulative(t), plain: cumulative(t.filter(([s]) => !SPECIAL.has(s))) })));
  }
  return cache.get(key);
}

/**
 * Draws the unlocked cells. A reel shows at most one special symbol (an
 * expanding wild, bonus or jackpot coin); a reel that already holds an
 * expanding wild turns any new expanding wild into a plain wild.
 */
export function drawGrid(reels, held, rand) {
  const grid = [];
  for (let r = 0; r < REELS; r++) {
    const col = [];
    const lock = held[r];
    let special = false;
    for (let row = 0; row < ROWS; row++) {
      if (lock && lock.occupied.includes(row)) { col.push(null); continue; }
      let s = draw(special ? reels[r].plain : reels[r].all, rand);
      if (SPECIAL.has(s)) {
        special = true;
        if (lock && EXPANDERS[s] !== undefined) s = 'WILD';
      }
      col.push(s);
    }
    grid.push(col);
  }
  return grid;
}

/** Best pay on one line. Multiplier = product of the expanding wilds on the counted cells. */
function lineWin(line, sym, mult, bet, index) {
  const s = line.map((row, reel) => sym[reel][row]);
  let lead = 0;
  while (lead < REELS && WILDS.has(s[lead])) lead++;
  const multOf = (n) => { let m = 1; for (let i = 0; i < n; i++) m *= mult[i][line[i]]; return m; };
  let best = null;
  if (lead >= 3) {
    const m = multOf(lead), pay = PAYTABLE.WILD[lead - 3];
    best = { symbol: 'WILD', count: lead, pay, mult: m, amount: Math.floor((bet * pay * m) / 100) };
  }
  const target = s[lead];
  if (lead < REELS && PAYTABLE[target] && LINE_SYMBOLS.includes(target)) {
    let n = lead;
    while (n < REELS && (s[n] === target || WILDS.has(s[n]))) n++;
    if (n >= 3) {
      const m = multOf(n), pay = PAYTABLE[target][n - 3];
      const amount = Math.floor((bet * pay * m) / 100);
      if (!best || amount > best.amount) best = { symbol: target, count: n, pay, mult: m, amount };
    }
  }
  if (!best || best.amount <= 0) return null;
  return { line: index, ...best, cells: line.slice(0, best.count).map((row, reel) => [reel, row]) };
}

/** Lines, scatter and jackpot for a finished grid. */
export function evaluate(sym, mult, bet) {
  const wins = [];
  for (let i = 0; i < LINES.length; i++) { const w = lineWin(LINES[i], sym, mult, bet, i); if (w) wins.push(w); }
  const bonusCells = [];
  for (let r = 0; r < REELS; r++) for (let row = 0; row < ROWS; row++) if (sym[r][row] === 'BONUS') bonusCells.push([r, row]);
  const scatter = { count: bonusCells.length, cells: bonusCells, win: SCATTER_PAY[bonusCells.length] ? Math.floor((bet * SCATTER_PAY[bonusCells.length]) / 100) : 0 };
  // Jackpot: the same coin on 3+ adjacent reels (any reels). Highest pays once.
  const coin = sym.map((col) => col.find((s) => s && s[0] === 'J') || null);
  let jackpot = null;
  for (let t = JACKPOTS.length - 1; t >= 0 && !jackpot; t--) {
    const j = JACKPOTS[t];
    let run = 0, best = 0, end = -1;
    for (let r = 0; r < REELS; r++) { run = coin[r] === j.sym ? run + 1 : 0; if (run > best) { best = run; end = r; } }
    if (best >= 3) {
      const reels = Array.from({ length: best }, (_, k) => end - best + 1 + k);
      jackpot = { tier: t, name: j.name, reels, cells: reels.map((r) => [r, sym[r].indexOf(j.sym)]), win: Math.floor((bet * j.pay) / 100) };
    }
  }
  return { wins, scatter, jackpot };
}

/**
 * Resolves one spin. `inject` (tests only) supplies the drawn cells instead
 * of the RNG; the API never passes it.
 */
export function resolveSpin(state, { bet, rand, profile = ACTIVE_PROFILE, scales, inject }) {
  const free = state.free;
  const spinNo = state.spin + 1;
  const wilds = state.wilds;
  const before = wilds.map(snapshot);
  const events = [];

  // 1. standing wilds advance
  advance(wilds, spinNo, ROWS, events);
  const grown = wilds.map(snapshot);

  // 2. draw unlocked cells
  const held = byReel(wilds);
  const drawn = inject
    ? inject.map((col, r) => col.map((s, row) => (held[r]?.occupied.includes(row) ? null : held[r] && EXPANDERS[s] !== undefined ? 'WILD' : s)))
    : drawGrid(reelSet(profile, !!free, scales), held, rand);

  // 3. new expanding wilds
  let nextId = state.nextId;
  for (let r = 0; r < REELS; r++) {
    if (held[r]) continue;
    const row = drawn[r].findIndex((s) => EXPANDERS[s] !== undefined);
    if (row < 0) continue;
    const w = createWild({ id: nextId++, reel: r, row, kind: drawn[r][row], mult: EXPANDERS[drawn[r][row]], spin: spinNo, rows: ROWS });
    wilds.push(w);
    events.push({ type: 'land', id: w.id, reel: r, row, kind: w.kind, mult: w.mult });
  }

  // 4. evaluate
  const sym = drawn.map((col) => col.slice());
  const mult = Array.from({ length: REELS }, () => Array(ROWS).fill(1));
  for (const w of wilds) for (const row of w.occupied) { sym[w.reel][row] = w.kind; mult[w.reel][row] = w.mult; }
  const ev = evaluate(sym, mult, bet);
  const raw = ev.wins.reduce((a, w) => a + w.amount, 0) + ev.scatter.win + (ev.jackpot?.win || 0);
  const win = Math.min(raw, bet * MAX_WIN_X);

  // 5. settle
  const after = settle(wilds, spinNo, events);

  // Free spins
  let next = null, trigger = null;
  if (free) {
    const extra = ev.scatter.count * RETRIGGER_PER_BONUS;
    next = { ...free, remaining: free.remaining - 1 + extra, total: free.total + win, played: free.played + 1 };
    if (extra) trigger = { extra };
  } else if (ev.scatter.count >= 3) {
    next = { bet, remaining: FREE_SPINS, total: 0, played: 0 };
    trigger = { freeSpins: FREE_SPINS };
  }

  return {
    win, capped: raw > win, next, trigger, nextId, spinNo, wilds: after,
    out: {
      spin: spinNo, before, grown, drawn, grid: sym, mult,
      landed: wilds.filter((w) => w.landedSpin === spinNo).map(snapshot),
      completed: wilds.filter((w) => w.removed).map(snapshot),
      after: after.map(snapshot), events, wins: ev.wins, scatter: ev.scatter, jackpot: ev.jackpot,
    },
  };
}
