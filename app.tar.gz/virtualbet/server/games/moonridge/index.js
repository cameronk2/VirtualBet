// Moonridge – the casino game object (shared handler contract).
// Wolf Peak-style Delayed Expanding Wilds, original name, art and code.
import { checkStake, fail } from '../common.js';
import { STAKE_MAX } from './config.js';
import { resolveSpin } from './engine.js';
import { snapshot } from './wilds.js';

export const moonridge = {
  id: 'moonridge', label: 'Moonridge',
  init: () => ({ wilds: [], nextId: 1, spin: 0, free: null, recent: [] }),
  view: (s) => ({ wilds: (s.wilds || []).map(snapshot), free: s.free, recent: (s.recent || []).slice(0, 15), spin: s.spin || 0 }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    state.wilds ||= []; state.nextId ||= 1; state.spin ||= 0; state.recent ||= [];
    const free = state.free;
    const bet = free ? free.bet : checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    const r = resolveSpin(state, { bet, rand });
    let next = r.next, finished = null;
    if (free && next.remaining <= 0) { finished = { total: next.total, played: next.played }; next = null; }
    const paid = !free;
    return {
      stake: paid ? bet : 0, payout: r.win,
      state: {
        ...state, wilds: r.wilds, nextId: r.nextId, spin: r.spinNo, free: next,
        recent: paid || finished ? [{ bet, win: finished ? finished.total : r.win }, ...state.recent].slice(0, 20) : state.recent,
      },
      out: { ...r.out, trigger: r.trigger, capped: r.capped, free: next, finished, win: r.win, bet },
      settled: { staked: paid ? bet : 0, payout: r.win },
      events: [{ t: 'slot', game: 'moonridge', x: r.win / bet, feature: !!r.trigger?.freeSpins }],
    };
  },
};
