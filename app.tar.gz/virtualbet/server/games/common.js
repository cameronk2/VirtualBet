// Shared helpers for the casino game engines. All engines are pure: they
// take the saved state plus the player's request and return the new state,
// how much to take and pay (integer pence, virtual money), and what the
// player may see. The same code runs in the server and the phone build.

export const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
export const SUITS = ['S', 'H', 'D', 'C'];
export const rankOf = (c) => c.slice(0, -1);
export const suitOf = (c) => c.slice(-1);

export function shoe(rand, decks = 1, take = 52) {
  const s = [];
  for (let d = 0; d < decks; d++) for (const su of SUITS) for (const r of RANKS) s.push(r + su);
  // Partial Fisher-Yates: only the cards actually needed are drawn
  const n = Math.min(take, s.length);
  for (let i = 0; i < n; i++) {
    const j = i + Math.floor(rand() * (s.length - i));
    [s[i], s[j]] = [s[j], s[i]];
  }
  return s.slice(0, n);
}

export function pickWeighted(entries, rand) {
  const total = entries.reduce((a, e) => a + e[1], 0);
  let r = rand() * total;
  for (const e of entries) if ((r -= e[1]) <= 0) return e[0];
  return entries[entries.length - 1][0];
}

export class GameError extends Error {}
export const fail = (msg) => { throw new GameError(msg); };

/** Table games (roulette, baccarat, three card, blackjack) have no maximum bet. */
export const TABLE_GAMES = new Set(['roulette', 'baccarat', 'threecard']);
export const NO_LIMIT = Number.MAX_SAFE_INTEGER;

export function checkStake(v, { min, max = NO_LIMIT, label = 'Stake' }) {
  if (!Number.isSafeInteger(v) || v < min) fail(`${label} must be at least £${(min / 100).toFixed(2)}.`);
  if (v > max) fail(`${label} can be at most £${(max / 100).toFixed(2)}.`);
  return v;
}

/** Standard 10 paylines for 5x3 slots (row index per reel). */
export const LINES_10 = [
  [1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2],
  [1, 0, 0, 0, 1], [1, 2, 2, 2, 1], [0, 0, 1, 2, 2], [2, 2, 1, 0, 0], [1, 2, 1, 0, 1],
];

/**
 * Left-to-right line wins on a reels x rows grid of { s } cells.
 * paytable: { SYM: [x3, x4, x5] } in hundredths of the total bet.
 */
export function lineWins(grid, bet, paytable, { wild = 'WILD', lines = LINES_10, skip = [] } = {}) {
  const wins = [];
  lines.forEach((line, li) => {
    const syms = line.map((row, reel) => grid[reel][row].s);
    let base = syms.find((x) => x !== wild);
    if (base === undefined) base = wild;
    if (skip.includes(base)) base = syms[0] === wild ? wild : null;
    if (!base) return;
    let n = 0;
    for (const x of syms) { if (x === base || x === wild) n++; else break; }
    let wn = 0;
    for (const x of syms) { if (x === wild) wn++; else break; }
    const pay = (sym, c) => (c >= 3 && paytable[sym] ? paytable[sym][c - 3] : 0);
    let best = { sym: base, count: n, x: pay(base, n) };
    if (pay(wild, wn) > best.x) best = { sym: wild, count: wn, x: pay(wild, wn) };
    if (best.x > 0) wins.push({ line: li, symbol: best.sym, count: best.count, amount: Math.floor((bet * best.x) / 100), cells: line.slice(0, best.count).map((row, reel) => [reel, row]) });
  });
  return wins;
}
