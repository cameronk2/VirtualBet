// Mystery of the Mummy – jackpot pick.
// The jackpot is decided when the feature starts, and so is the order of
// the symbols that will be revealed. Tapping a tile only shows the next
// symbol in that order, so which tile is tapped cannot change the prize.
import { JACKPOTS, JACKPOT_TILES, JACKPOT_WEIGHTS } from './config.js';
import { weighted } from './reels.js';
import { fail } from '../common.js';

export function startJackpot(rand, tier = null) {
  const win = tier ?? weighted(JACKPOT_WEIGHTS.map((w, i) => [i, w]), rand);
  // Other tiers may appear up to twice before the winner's third.
  const others = [];
  JACKPOTS.forEach((_, i) => { if (i !== win) { const n = Math.floor(rand() * 3); for (let k = 0; k < n; k++) others.push(i); } });
  const before = [win, win, ...others];
  for (let i = before.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [before[i], before[j]] = [before[j], before[i]]; }
  return { tier: win, sequence: [...before, win], opened: [] };
}

/** Opens tile `index`; returns the revealed tier and whether the pick is over. */
export function pick(jp, index) {
  if (!Number.isInteger(index) || index < 0 || index >= JACKPOT_TILES) fail('Pick a covered tile.');
  if (jp.opened.some((o) => o.index === index)) fail('Pick a covered tile.');
  if (jp.opened.length >= jp.sequence.length) fail('The jackpot pick has finished.');
  const tier = jp.sequence[jp.opened.length];
  jp.opened.push({ index, tier });
  const done = jp.opened.length === jp.sequence.length;
  return { tier, done };
}

export const jackpotView = (jp) => jp && { opened: jp.opened, done: jp.opened.length === jp.sequence.length, tier: jp.opened.length === jp.sequence.length ? jp.tier : null };
