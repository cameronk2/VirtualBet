// Mystery of the Mummy – reel engine: weighted reel tables → a 5x3 grid.
// No rendering here; the screen only replays the grid it is given.
import { REELS, ROWS, REEL_GEM_VALUES, STACKS, WEIGHTS } from './config.js';

export function weighted(pairs, rand) {
  let total = 0;
  for (const [, w] of pairs) total += w;
  let x = rand() * total;
  for (const [v, w] of pairs) { if ((x -= w) < 0) return v; }
  return pairs[pairs.length - 1][0];
}

const tables = new Map();
function table(mode, reel) {
  const key = `${mode}${reel}`;
  if (!tables.has(key)) {
    const t = Object.entries(WEIGHTS[mode][reel]).filter(([, w]) => w > 0);
    tables.set(key, { all: t, plain: t.filter(([s]) => s !== 'FS' && s !== 'MUMMY') });
  }
  return tables.get(key);
}

/** One grid. At most one scatter and one Mummy per reel. Gems carry a value (x bet). */
export function drawGrid(mode, rand) {
  const grid = [];
  for (let r = 0; r < REELS; r++) {
    const t = table(mode, r);
    const st = STACKS[mode];
    if (rand() < st.chance[r]) {
      const s = weighted(Object.entries(st.symbols).filter(([, w]) => w > 0), rand);
      grid.push(Array.from({ length: ROWS }, () => ({ s })));
      continue;
    }
    let special = false;
    const col = [];
    for (let row = 0; row < ROWS; row++) {
      const s = weighted(special ? t.plain : t.all, rand);
      if (s === 'FS' || s === 'MUMMY') special = true;
      col.push(s === 'GEM' ? { s, v: weighted(REEL_GEM_VALUES, rand) } : { s });
    }
    grid.push(col);
  }
  return grid;
}
