// Mystery of the Mummy – Cash Collect bonus (self-contained, no rendering).
//
// State machine:  READY → SPINNING → COMPLETE
//
// A separate 5x5 grid. The triggering green gems are placed on it in the
// same columns (the 3 reel rows map to the bottom 3 rows). The Mummy starts
// 2x2 in the bottom-left. Each bonus spin, in order:
//   1. The Mummy moves one step (sideways, up/down or diagonally) toward
//      the nearest green gem it hasn't collected; with none waiting it
//      patrols the grid.
//   2. Cash prizes and green gems land on empty cells.
//   3. The Mummy collects everything under it: cash prizes that landed in
//      its area, and every green gem in its area (new or waiting).
//      Cash prizes outside it vanish; gems outside it wait for the Mummy.
//   4. Collected gems count toward growth (cumulative, never reset):
//      5 → 3x3 +3 spins, 9 → 4x4 +2, 12 → 5x5 +1.
// Only collected values are paid, once, when the spins run out.
import { CASH } from './config.js';
import { weighted } from './reels.js';

const N = CASH.size;
export const PHASE = Object.freeze({ READY: 'READY', SPINNING: 'SPINNING', COMPLETE: 'COMPLETE' });
const inZone = (z, c, r) => c >= z.col && c < z.col + z.size && r >= z.row && r < z.row + z.size;

/** Snake path over every position a Mummy of `size` can stand on. */
function patrol(size) {
  const room = N - size, path = [];
  for (let r = room; r >= 0; r--) {
    const row = [];
    for (let c = 0; c <= room; c++) row.push({ col: c, row: r });
    path.push(...((room - r) % 2 ? row.reverse() : row));
  }
  return path;
}

/** One step toward the nearest waiting gem (or along the patrol). */
export function nextZone(st) {
  st.pdir ||= 1;
  const z = st.zone, room = N - z.size;
  if (room === 0) return { ...z };
  const waiting = [];
  for (let c = 0; c < N; c++) for (let r = 0; r < N; r++) if (st.board[c][r]) waiting.push({ c, r, v: st.board[c][r].v });
  const gap = (lo, size, x) => (x < lo ? x - lo : x >= lo + size ? x - (lo + size - 1) : 0);
  if (waiting.length) {
    waiting.sort((a, b) => Math.max(Math.abs(gap(z.col, z.size, a.c)), Math.abs(gap(z.row, z.size, a.r))) - Math.max(Math.abs(gap(z.col, z.size, b.c)), Math.abs(gap(z.row, z.size, b.r))) || b.v - a.v || a.c - b.c || a.r - b.r);
    const g = waiting[0];
    const col = Math.min(room, Math.max(0, z.col + Math.sign(gap(z.col, z.size, g.c))));
    const row = Math.min(room, Math.max(0, z.row + Math.sign(gap(z.row, z.size, g.r))));
    return { ...z, col, row };
  }
  // no gems waiting: walk the snake path back and forth (always one step)
  const path = patrol(z.size);
  const i = Math.max(0, path.findIndex((p) => p.col === z.col && p.row === z.row));
  if (!path[i + st.pdir]) st.pdir = -st.pdir;
  return { ...z, ...path[i + st.pdir] };
}

/** Collects every waiting gem under the Mummy. Mutates; returns what was collected. */
function collectGems(st) {
  const got = [];
  for (let c = 0; c < N; c++) for (let r = 0; r < N; r++) {
    const g = st.board[c][r];
    if (g && inZone(st.zone, c, r)) {
      st.board[c][r] = null;
      st.total += g.v; st.gems++;
      got.push({ kind: 'gem', c, r, v: g.v });
    }
  }
  return got;
}

/** Grow → collect → grow… until nothing changes. Returns [{ size, spins, zone, collected }]. */
function growAndCollect(st) {
  const stages = [];
  for (;;) {
    const ups = grow(st);
    if (!ups.length) break;
    ups.forEach((u, i) => stages.push({ ...u, collected: i === ups.length - 1 ? collectGems(st) : [] }));
  }
  return stages;
}

/** Applies every growth level the cumulative gem count has reached. */
function grow(st) {
  const ups = [];
  while (st.level < CASH.powerUps.length && st.gems >= CASH.powerUps[st.level].gems) {
    const p = CASH.powerUps[st.level++];
    const centreC = st.zone.col + st.zone.size / 2, centreR = st.zone.row + st.zone.size / 2;
    st.zone.size = p.size;
    st.zone.col = Math.min(N - p.size, Math.max(0, Math.round(centreC - p.size / 2)));
    st.zone.row = Math.min(N - p.size, Math.max(0, Math.round(centreR - p.size / 2)));
    st.respins += p.spins;
    ups.push({ size: p.size, spins: p.spins, zone: { ...st.zone } });
  }
  return ups;
}

export function startCash(grid, rand) {
  const board = Array.from({ length: N }, () => Array(N).fill(null));
  const offset = N - grid[0].length;
  const placed = [];
  grid.forEach((col, c) => col.forEach((cell, row) => {
    if (cell.s === 'GEM') { board[c][row + offset] = { v: cell.v }; placed.push({ kind: 'gem', c, r: row + offset, v: cell.v }); }
  }));
  const st = { phase: PHASE.READY, board, zone: { col: 0, row: N - CASH.zone, size: CASH.zone }, respins: CASH.respins, gems: 0, total: 0, level: 0, step: 0, coins: 0, pdir: 1 };
  const collected = collectGems(st);
  const growth = growAndCollect(st);
  return { cash: st, start: { placed, collected, growth } };
}

/** One bonus spin. Mutates `st`; returns the events in the order they happen. */
export function respin(st, rand) {
  if (st.phase === PHASE.COMPLETE) throw new Error('The bonus has finished.');
  if (st.respins <= 0) throw new Error('No bonus spins left.');
  st.phase = PHASE.SPINNING;
  st.step++;
  st.respins--;
  // 1. move
  const from = { ...st.zone };
  st.zone = nextZone(st);
  const moved = { ...st.zone };
  // 2. land
  const landed = [];
  for (let c = 0; c < N; c++) for (let r = 0; r < N; r++) {
    if (st.board[c][r]) continue;
    const x = rand();
    if (x < CASH.gemChance) {
      const v = weighted(CASH.gemValues, rand);
      st.board[c][r] = { v };
      landed.push({ kind: 'gem', c, r, v });
    } else if (x < CASH.gemChance + CASH.coinChance) {
      landed.push({ kind: 'coin', c, r, v: weighted(CASH.coinValues, rand) });
    }
  }
  // 3. collect
  const collected = [];
  for (const l of landed) if (l.kind === 'coin') {
    l.hit = inZone(st.zone, l.c, l.r);
    if (l.hit) { st.total += l.v; st.coins++; collected.push({ ...l }); }
  }
  collected.push(...collectGems(st));
  // 4. grow; a bigger Mummy collects the gems now under it, which can
  //    grow it again. Each stage is reported in order.
  const growth = growAndCollect(st);
  if (st.respins <= 0) st.phase = PHASE.COMPLETE;
  return { from, moved, zone: { ...st.zone }, landed, collected, growth, respins: st.respins, gems: st.gems, total: st.total, done: st.phase === PHASE.COMPLETE };
}

export const cashView = (st) => st && { phase: st.phase, board: st.board, zone: st.zone, respins: st.respins, gems: st.gems, total: st.total, level: st.level, coins: st.coins, step: st.step };
