// Mystery of the Mummy – win evaluation (lines left to right, scatter anywhere).
import { LINES, LINE_SYMBOLS, PAYTABLE, REELS, SCATTER_PAY } from './config.js';

const isWild = (s) => s === 'WILD';

function lineWin(line, grid, bet, index) {
  const s = line.map((row, reel) => grid[reel][row].s);
  let lead = 0;
  while (lead < REELS && isWild(s[lead])) lead++;
  let best = null;
  if (lead >= 3) best = { symbol: 'WILD', count: lead, pay: PAYTABLE.WILD[lead - 3] };
  const target = s[lead];
  if (lead < REELS && LINE_SYMBOLS.includes(target)) {
    let n = lead;
    while (n < REELS && (s[n] === target || isWild(s[n]))) n++;
    if (n >= 3) {
      const pay = PAYTABLE[target][n - 3];
      if (!best || pay > best.pay) best = { symbol: target, count: n, pay };
    }
  }
  if (!best) return null;
  return { line: index, ...best, amount: Math.floor((bet * best.pay) / 100), cells: line.slice(0, best.count).map((row, reel) => [reel, row]) };
}

export function evaluate(grid, bet) {
  const wins = [];
  LINES.forEach((line, i) => { const w = lineWin(line, grid, bet, i); if (w && w.amount > 0) wins.push(w); });
  const fs = [];
  grid.forEach((col, r) => col.forEach((c, row) => { if (c.s === 'FS') fs.push([r, row]); }));
  const scatterWin = SCATTER_PAY[fs.length] ? Math.floor((bet * SCATTER_PAY[fs.length]) / 100) : 0;
  return { wins, scatter: { count: fs.length, cells: fs, win: scatterWin } };
}
