// Mystery of the Mummy – game flow (pure; integer pence; RNG injected).
//
// Modes: base → (jackpot pick | Cash Collect | Free Games). A spin can
// trigger several features; they queue and run one after another
// (jackpot, then Cash Collect, then Free Games). Every result is computed
// here before anything is shown, and each action moves the state forward
// exactly once, so nothing can be charged or paid twice.
import { checkStake, fail } from '../common.js';
import { CASH, FREE_GAMES, JACKPOTS, JACKPOT_TRIGGER, MAX_WIN_X, RANDOM_FS_TRIGGER, RETRIGGER, REELS, ROWS, STAKE_MAX } from './config.js';
import { drawGrid } from './reels.js';
import { evaluate } from './evaluate.js';
import { cashView, respin, startCash } from './cash.js';
import { jackpotView, pick, startJackpot } from './jackpot.js';

export const init = () => ({ mode: 'base', free: null, cash: null, jackpot: null, queue: [], practice: false, recent: [], round: 0 });

export const view = (s) => ({
  mode: s.mode, free: s.free, practice: !!s.practice,
  cash: s.cash && { ...cashView(s.cash), bet: s.cash.bet },
  jackpot: s.jackpot && { ...jackpotView(s.jackpot), bet: s.jackpot.bet },
  queue: (s.queue || []).map((q) => q.type), recent: (s.recent || []).slice(0, 15),
});

const cap = (win, bet) => Math.min(win, bet * MAX_WIN_X);

/** Detects every feature a grid triggers (deterministic given rand). */
export function triggers(grid, ev, inFree, rand) {
  const t = {};
  const wilds = grid.flatMap((col, r) => col.map((c, row) => (c.s === 'WILD' ? [r, row] : null)).filter(Boolean));
  for (const cell of wilds) if (rand() < JACKPOT_TRIGGER) { t.jackpot = { cell }; break; }
  const mummy = grid[0].findIndex((c) => c.s === 'MUMMY');
  const gems = grid.flatMap((col, r) => col.map((c, row) => (c.s === 'GEM' ? [r, row] : null)).filter(Boolean));
  if (gems.length && mummy >= 0) t.cash = { mummy: [0, mummy], gems };
  else for (const g of gems) if (rand() < CASH.randomGemTrigger) { t.cash = { random: g, gems }; break; }
  if (ev.scatter.count >= 3) t.free = inFree ? { retrigger: RETRIGGER } : { spins: FREE_GAMES };
  else if (!inFree) for (const c of ev.scatter.cells) if (rand() < RANDOM_FS_TRIGGER) { t.free = { spins: FREE_GAMES, random: c }; break; }
  return t;
}

/** Starts the next queued feature, or returns to Free Games / base. */
function advance(state, rand, out) {
  const next = state.queue.shift();
  if (next?.type === 'jackpot') {
    state.jackpot = { ...startJackpot(rand, next.tier ?? null), bet: next.bet };
    state.mode = 'jackpot';
    out.started = { type: 'jackpot' };
  } else if (next?.type === 'cash') {
    const { cash, start } = startCash(next.grid, rand);
    state.cash = { ...cash, bet: next.bet };
    state.mode = 'cash';
    out.started = { type: 'cash', ...start, cash: cashView(state.cash) };
  } else if (next?.type === 'free') {
    state.free = { bet: next.bet, remaining: FREE_GAMES, total: 0, played: 0 };
    state.mode = 'free';
    out.started = { type: 'free', spins: FREE_GAMES };
  } else if (state.free && state.free.remaining > 0) {
    state.mode = 'free';
  } else {
    if (state.free) out.finished = { total: state.free.total, played: state.free.played };
    state.free = null;
    state.mode = 'base';
    state.practice = false;
  }
}

function credit(state, win) { if (state.free && state.mode !== 'base') state.free.total += win; }

export function act(state, action, body, { rand, minStake, inject }) {
  const s = { ...init(), ...state };
  s.queue = [...(s.queue || [])];
  const out = { action };
  const wasPractice = !!s.practice;
  let stake = 0, payout = 0, feature = false;

  if (action === 'spin') {
    if (s.mode !== 'base' && s.mode !== 'free') fail(s.mode === 'cash' ? 'Finish Cash Collect first.' : 'Finish the jackpot pick first.');
    const inFree = s.mode === 'free';
    const bet = inFree ? s.free.bet : checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    stake = inFree || s.practice ? 0 : bet;
    // `inject` exists only in tests (the API never sets it).
    const grid = inject?.grid || drawGrid(inFree ? 'free' : 'base', rand);
    const ev = evaluate(grid, bet);
    const t = triggers(grid, ev, inFree, rand);
    const win = cap(ev.wins.reduce((a, w) => a + w.amount, 0) + ev.scatter.win, bet);
    payout = win;
    Object.assign(out, { grid, wins: ev.wins, scatter: ev.scatter, triggers: t, win, bet, free: inFree });
    if (inFree) {
      s.free = { ...s.free, remaining: s.free.remaining - 1 + (t.free?.retrigger || 0), total: s.free.total + win, played: s.free.played + 1 };
    }
    if (t.jackpot) s.queue.push({ type: 'jackpot', bet });
    if (t.cash) s.queue.push({ type: 'cash', bet, grid });
    if (t.free?.spins) s.queue.push({ type: 'free', bet });
    feature = !!(t.jackpot || t.cash || t.free?.spins);
    if (inFree && s.free.remaining <= 0 && !s.queue.length) advance(s, rand, out);
    else if (s.queue.length) advance(s, rand, out);
  } else if (action === 'pick') {
    if (s.mode !== 'jackpot') fail('There is no jackpot pick in play.');
    const jp = { ...s.jackpot, opened: [...s.jackpot.opened] };
    const r = pick(jp, Number(body?.index));
    s.jackpot = jp;
    Object.assign(out, { index: Number(body.index), tier: r.tier, done: r.done, opened: jp.opened });
    if (r.done) {
      const j = JACKPOTS[jp.tier];
      payout = cap(j.x * jp.bet, jp.bet);
      Object.assign(out, { jackpot: { tier: jp.tier, name: j.name, x: j.x }, win: payout, bet: jp.bet });
      credit(s, payout);
      s.jackpot = null;
      advance(s, rand, out);
    }
  } else if (action === 'respin') {
    if (s.mode !== 'cash') fail('There is no Cash Collect in play.');
    const cash = structuredClone(s.cash);
    const r = respin(cash, rand);
    s.cash = cash;
    Object.assign(out, r, { level: cash.level, bet: cash.bet });
    if (r.done) {
      payout = cap(cash.total * cash.bet, cash.bet);
      Object.assign(out, { win: payout, capped: payout < cash.total * cash.bet });
      credit(s, payout);
      s.cash = null;
      advance(s, rand, out);
    }
  } else if (action === 'dev') {
    // Practice triggers for testing. They cost nothing and pay nothing.
    if (s.mode !== 'base' || s.queue.length) fail('Finish the current feature first.');
    const bet = checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    s.practice = true;
    const ev = body?.event;
    if (ev === 'free') s.queue.push({ type: 'free', bet });
    else if (ev === 'cash') {
      const grid = Array.from({ length: REELS }, (_, r) => Array.from({ length: ROWS }, (_, row) => ({ s: 'Q' })));
      grid[0][1] = { s: 'MUMMY' }; grid[2][0] = { s: 'GEM', v: 5 }; grid[4][2] = { s: 'GEM', v: 2 };
      s.queue.push({ type: 'cash', bet, grid });
    } else if (ev === 'jackpot') {
      const tier = Number.isInteger(body?.tier) && body.tier >= 0 && body.tier < JACKPOTS.length ? body.tier : null;
      s.queue.push({ type: 'jackpot', bet, tier });
    } else fail('Unknown test event.');
    advance(s, rand, out);
    out.practice = true;
  } else fail('Unknown action.');

  if (wasPractice || s.practice || out.practice) { payout = 0; stake = 0; out.practice = true; }
  out.mode = s.mode;
  out.payout = payout;
  if (!out.practice && (stake || payout)) s.recent = [{ bet: out.bet, win: payout, kind: action }, ...(s.recent || [])].slice(0, 20);
  return {
    stake, payout, state: s,
    out: { ...out, view: view(s) },
    settled: { staked: stake, payout },
    events: [{ t: 'slot', game: 'mummy', x: out.bet ? payout / out.bet : 0, feature }],
  };
}
