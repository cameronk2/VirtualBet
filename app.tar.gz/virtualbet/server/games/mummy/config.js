// Mystery of the Mummy – every number that defines the game, in one place.
//
// Rules follow public reviews of Aristocrat's Mo' Mummy (see
// docs/mummy-mechanics.md for sources and for each unconfirmed detail).
// Verified: 5x3, 20 fixed lines, wins from reel 1 for 3+, Wild substitutes;
// 3+ Free Games scatters = 6 free games with A/K/Q/J removed; a Mummy on
// reel 1 plus a green gem starts Cash Collect (5 respins, 2x2 Mummy zone
// growing to 3x3 +3, 4x4 +2, 5x5 +1, coins pay only inside the zone, gems
// anywhere, all paid at the end, values 1x-1,000x); a landing Wild can start
// the jackpot pick (first of five jackpots revealed 3 times: 20x, 60x,
// 100x, 200x, 2,000x); maximum win 2,118x.
import { LINES_20 } from '../slots3.js';

export const REELS = 5;
export const ROWS = 3;
export const LINES = LINES_20;
export const STAKE_MAX = 10000;      // £100 (site-wide slot cap)
export const MAX_WIN_X = 2118;       // per spin or per feature round
export const TARGET_RTP = 95;        // ours; not the original's certified maths

// Line pays in hundredths of the total bet for 3 / 4 / 5 of a kind.
// Verified: 5-of-a-kind tops (Wild 4x, premiums up to 3x, A/K/Q/J 2x).
// The 3 and 4 values are not published; ours.
export const PAYTABLE = {
  WILD: [100, 240, 400],
  PHARAOH: [75, 180, 300],
  ANUBIS: [60, 150, 250],
  BOOK: [50, 120, 200],
  EYE: [50, 120, 200],
  ANKH: [40, 100, 200],
  A: [25, 60, 200],
  K: [25, 60, 200],
  Q: [20, 50, 200],
  J: [20, 50, 200],
};
export const LINE_SYMBOLS = ['PHARAOH', 'ANUBIS', 'BOOK', 'EYE', 'ANKH', 'A', 'K', 'Q', 'J'];
export const LOW = new Set(['A', 'K', 'Q', 'J']);

// Free Games
export const FREE_GAMES = 6;
export const RETRIGGER = 6;            // 3+ scatters during Free Games (amount unconfirmed)
export const SCATTER_PAY = { 3: 200, 4: 500, 5: 2000 }; // ours (not published)

// Jackpots (online fixed values)
export const JACKPOTS = [
  { id: 'mini', name: 'Mini', x: 20 },
  { id: 'minor', name: 'Minor', x: 60 },
  { id: 'maxi', name: 'Maxi', x: 100 },
  { id: 'major', name: 'Major', x: 200 },
  { id: 'grand', name: 'Grand', x: 2000 },
];
export const JACKPOT_TILES = 15;
// Chance that a landed Wild starts the jackpot pick, and which jackpot it is.
export const JACKPOT_TRIGGER = 0.0008;
export const JACKPOT_WEIGHTS = [620, 250, 90, 36, 4];

// Cash Collect
export const CASH = {
  size: 5,                               // separate 5x5 bonus grid
  respins: 5,                            // initial bonus spins
  zone: 2,                               // the Mummy starts 2x2
  // Cumulative green gems collected → new Mummy size and extra spins.
  // 5 gems: 3x3 (+3) · 4 more (9): 4x4 (+2) · 3 more (12): 5x5 (+1)
  powerUps: [{ gems: 5, size: 3, spins: 3 }, { gems: 9, size: 4, spins: 2 }, { gems: 12, size: 5, spins: 1 }],
  gemChance: 0.06,                       // per open cell per bonus spin
  coinChance: 0.068,                     // tuned for the target return
  // Cash prizes, multiples of the TOTAL bet, with weights.
  coinValues: [[1, 400], [2, 260], [5, 150], [10, 70], [20, 26], [50, 8], [100, 2.5], [250, 0.6], [500, 0.15], [1000, 0.04]],
  // Green gems also carry a value (paid only when the Mummy collects them).
  gemValues: [[1, 300], [2, 220], [3, 150], [5, 100], [10, 40], [20, 12], [60, 3]],
  randomGemTrigger: 0.003,               // a gem without a Mummy can start the bonus at random
};
export const VALUE_LABEL = { 20: 'MINI', 60: 'MINOR' };

// Reel weights per reel. MUMMY only on reel 1, WILD and GEM on reels 2-5.
const base = { J: 30, Q: 30, K: 28, A: 26, ANKH: 18, EYE: 16, BOOK: 14, ANUBIS: 11, PHARAOH: 9 };
export const WEIGHTS = {
  base: [
    { ...base, FS: 6.5, MUMMY: 6 },
    { ...base, WILD: 20, FS: 6.5, GEM: 3 },
    { ...base, WILD: 20, FS: 6.5, GEM: 3 },
    { ...base, WILD: 20, FS: 6.5, GEM: 3 },
    { ...base, WILD: 20, FS: 6.5, GEM: 3 },
  ],
  // Free Games: A/K/Q/J removed.
  free: [
    { ANKH: 18, EYE: 16, BOOK: 14, ANUBIS: 11, PHARAOH: 9, FS: 2.2, MUMMY: 14 },
    { ANKH: 18, EYE: 16, BOOK: 14, ANUBIS: 11, PHARAOH: 9, WILD: 12, FS: 2.2, GEM: 6 },
    { ANKH: 18, EYE: 16, BOOK: 14, ANUBIS: 11, PHARAOH: 9, WILD: 12, FS: 2.2, GEM: 6 },
    { ANKH: 18, EYE: 16, BOOK: 14, ANUBIS: 11, PHARAOH: 9, WILD: 12, FS: 2.2, GEM: 6 },
    { ANKH: 18, EYE: 16, BOOK: 14, ANUBIS: 11, PHARAOH: 9, WILD: 12, FS: 2.2, GEM: 6 },
  ],
};
// Stacks: a reel sometimes shows one symbol on all three rows (as on the
// stacked reel strips land-based games use). Chance per reel, and which symbol.
export const STACKS = {
  base: { chance: [0.25, 0.25, 0.25, 0.25, 0.25], symbols: { J: 10, Q: 10, K: 9, A: 9, ANKH: 7, EYE: 6, BOOK: 5, ANUBIS: 4, PHARAOH: 3, WILD: 0 } },
  free: { chance: [0.3, 0.3, 0.3, 0.3, 0.3], symbols: { ANKH: 7, EYE: 6, BOOK: 5, ANUBIS: 4, PHARAOH: 3 } },
};
// Gem values shown on the base reels (they matter only if Cash Collect starts).
export const REEL_GEM_VALUES = [[1, 300], [2, 220], [3, 150], [5, 100], [10, 40], [20, 12], [60, 3]];
// Free Games scatters: a single one can start the feature at random.
export const RANDOM_FS_TRIGGER = 0.008;
