// Mystery of the Mummy – casino contract (original game inspired by Mo' Mummy).
import { act, init, view } from './engine.js';

export const mummy = { id: 'mummy', label: 'Mystery of the Mummy', init, view, act };
