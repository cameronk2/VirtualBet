// Keno 40 – one action per round (server-authoritative).
//
// `play {stake, picks, mode}` validates the picks, takes the stake, draws 10
// unique numbers from 1–40 with the platform's cryptographic RNG (partial
// Fisher–Yates, no replacement), counts matches, pays bet × table multiplier
// and records the round, all in one step. The screen then animates the draw
// it was given. A round can't be half-played, repeated or paid twice.
import { checkStake, fail } from '../common.js';
import { DRAW, MAX_PICKS, MODE_IDS, POOL, TABLES, tableMode } from './config.js';

const blankStats = () => ({ rounds: 0, wagered: 0, paid: 0, biggestWin: 0, biggestMult: 0, bestMatches: 0, bestMatchesOf: 0 });
export const init = () => ({ recent: [], stats: blankStats() });
export const view = (s) => ({ mode: 'idle', recent: (s.recent || []).slice(0, 30), stats: { ...blankStats(), ...(s.stats || {}) } });

export function drawNumbers(rand) {
  const a = Array.from({ length: POOL }, (_, i) => i + 1);
  for (let i = 0; i < DRAW; i++) { const j = i + Math.floor(rand() * (POOL - i)); [a[i], a[j]] = [a[j], a[i]]; }
  return a.slice(0, DRAW);
}

export function act(state, action, body, { rand, now, minStake, maxStake }) {
  const s = { ...init(), ...structuredClone(state || {}) };
  s.stats = { ...blankStats(), ...s.stats };
  if (action !== 'play') fail('Unknown action.');
  const mode = body?.mode;
  if (!MODE_IDS.includes(mode)) fail('Choose a game mode.');
  const picks = body?.picks;
  if (!Array.isArray(picks) || picks.length < 1 || picks.length > MAX_PICKS) fail(`Pick between 1 and ${MAX_PICKS} numbers.`);
  if (!picks.every((x) => Number.isInteger(x) && x >= 1 && x <= POOL)) fail(`Numbers must be from 1 to ${POOL}.`);
  if (new Set(picks).size !== picks.length) fail('Each number can only be picked once.');
  const stake = checkStake(body?.stake, { min: minStake, max: maxStake });

  const drawn = drawNumbers(rand);
  const set = new Set(picks);
  const hits = drawn.filter((x) => set.has(x));
  const n = picks.length, k = hits.length;
  const mult = TABLES[tableMode(mode)][n][k];
  const payout = Math.floor(stake * mult);

  const rec = { at: now, mode, bet: stake, picks: [...picks].sort((a, b) => a - b), drawn, matches: k, mult, payout, result: payout > stake ? 'win' : payout > 0 ? 'part' : 'loss' };
  s.recent = [rec, ...(s.recent || [])].slice(0, 30);
  const st = s.stats;
  st.rounds += 1; st.wagered += stake; st.paid += payout;
  if (payout > st.biggestWin) { st.biggestWin = payout; st.biggestMult = mult; }
  if (k > st.bestMatches || (k === st.bestMatches && n < st.bestMatchesOf)) { st.bestMatches = k; st.bestMatchesOf = n; }

  const out = { action, drawn, hits, matches: k, picks: rec.picks, mult, win: payout, bet: stake, mode, payout };
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'keno', matches: k, picks: n, mult }] };
}

export const keno = { id: 'keno', label: 'Keno 40', init, view, act };
