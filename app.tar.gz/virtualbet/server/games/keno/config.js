// Keno 40 – every number that defines the game.
//
// 40 numbers, 10 drawn without replacement, the player picks n = 1..10.
// Chance of k matches (hypergeometric):
//     P(n, k) = C(n, k) · C(40 − n, 10 − k) / C(40, 10)
// Each mode builds its payout tables from these probabilities, so no number
// is invented: every paying match count k ≥ kMin(n) gets a raw weight
//     w(k) = (1 / P(n, k))^α            (α sets how top-heavy the table is)
// and the whole table is scaled by s so that, with an optional ceiling on
// any multiplier, the expected return is exactly the mode's RTP:
//     Σ_k P(n, k) · min(s · w(k), cap) = RTP
// Multipliers are then rounded DOWN to 2 decimals (what is shown is what is
// paid), so each table returns RTP minus at most a fraction of a penny.
// Change RTP, α, kMin or cap here; tables, screen and tests follow.
export const POOL = 40;
export const DRAW = 10;
export const MAX_PICKS = 10;

export const MODES = {
  classic: { label: 'Classic', rtp: 0.97, alpha: 0.62, cap: 10000, kMin: [0, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4] },
  high: { label: 'High risk', rtp: 0.97, alpha: 0.86, cap: 100000, kMin: [0, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6] },
};
// Quick Keno plays the Classic tables with automatic picks and a fast draw.
export const MODE_IDS = ['classic', 'quick', 'high'];
export const tableMode = (mode) => (mode === 'high' ? 'high' : 'classic');

const C = (n, k) => { if (k < 0 || k > n) return 0; let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return r; };
const TOTAL = C(POOL, DRAW);
/** Chance of exactly k matches with n picks. */
export const prob = (n, k) => (C(n, k) * C(POOL - n, DRAW - k)) / TOTAL;

function build({ rtp, alpha, cap, kMin }, n) {
  const w = Array.from({ length: n + 1 }, (_, k) => (k >= kMin[n] ? (1 / prob(n, k)) ** alpha : 0));
  const ret = (s) => w.reduce((a, x, k) => a + prob(n, k) * Math.min(s * x, cap), 0);
  let lo = 0, hi = 1;
  while (ret(hi) < rtp) hi *= 2;
  for (let i = 0; i < 200; i++) { const mid = (lo + hi) / 2; if (ret(mid) < rtp) lo = mid; else hi = mid; }
  return w.map((x) => (x ? Math.floor(Math.min(hi * x, cap) * 100 + 1e-7) / 100 : 0));
}

/** TABLES[mode][n][k] = multiplier for k matches with n picks. */
export const TABLES = Object.fromEntries(Object.entries(MODES).map(([id, m]) => [id, Array.from({ length: MAX_PICKS + 1 }, (_, n) => (n ? build(m, n) : []))]));
/** Exact return of one table. */
export const tableRtp = (mode, n) => TABLES[mode][n].reduce((a, x, k) => a + prob(n, k) * x, 0);
