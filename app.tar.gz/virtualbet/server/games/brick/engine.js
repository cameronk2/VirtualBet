// Brick by Brick – game flow (server-authoritative, persisted state).
//
// Modes: base → wheel (3+ saws, or a brick house's wheel token) and/or
// free spins (6+ hats, or a wheel feature). Features queue: the wheel plays
// before hat free spins when both trigger on one spin. Every result is
// decided here before anything animates, and each action moves the saved
// state forward exactly once.
import { checkStake, fail } from '../common.js';
import { EXTRA_SPIN_HATS, FREE_SPINS, HAT_TRIGGER, JACKPOTS, JP_NAME, MAX_WIN_X, SAW_TRIGGER, STAKE_MAX } from './config.js';
import { cellsOf, drawBase, drawFree, evaluateWays } from './reels.js';
import { applyHat, mansions, megaHat, randomSaws, revealHouses, sawSweep, spinWheel } from './features.js';

export const init = () => ({ mode: 'base', queue: [], free: null, wheel: null, recent: [], practice: false });
export const view = (s) => ({
  mode: s.mode, practice: !!s.practice, queue: (s.queue || []).map((q) => q.type),
  free: s.free && { bet: s.free.bet, kind: s.free.kind, remaining: s.free.remaining, played: s.free.played, frames: s.free.frames },
  wheel: s.wheel && { bet: s.wheel.bet, saws: s.wheel.saws, source: s.wheel.source },
  recent: (s.recent || []).slice(0, 15),
});
const cap = (amount, bet) => Math.min(amount, bet * MAX_WIN_X);
const KINDS = { BUZZSAW: 'buzzsaw', MANSIONS: 'mansions', MEGAHAT: 'megahat' };

function startFree(s, kind, bet, { hats = [], saws = [] }, rand) {
  const frames = {};
  let pre = null;
  if (kind === 'hats') hats.forEach(([c, r]) => { frames[`${c},${r}`] = 1; });
  if (kind === 'buzzsaw') pre = { sweep: sawSweep(frames, saws, rand) };
  if (kind === 'mansions') pre = { bricks: mansions(frames, saws) };
  if (kind === 'megahat') pre = { mega: megaHat(frames, rand) };
  s.free = { bet, kind, remaining: FREE_SPINS, played: 0, frames, prizes: 0 };
  s.mode = 'free';
  return { type: 'free', kind, spins: FREE_SPINS, frames: { ...frames }, pre };
}

/** Starts the next queued feature, or returns to base. */
function advance(s, rand, out) {
  const next = s.queue.shift();
  if (next?.type === 'wheel') {
    s.wheel = { bet: next.bet, saws: next.saws, source: next.source, wedge: spinWheel(rand) };
    s.mode = 'wheel';
    out.started = { type: 'wheel', saws: next.saws, source: next.source };
  } else if (next?.type === 'free') {
    out.started = startFree(s, next.kind, next.bet, next, rand);
  } else {
    s.mode = 'base'; s.free = null; s.wheel = null; s.practice = false;
  }
}

export function act(state, action, body, { rand, minStake, inject }) {
  const s = { ...init(), ...structuredClone(state || {}) };
  const out = { action };
  const wasPractice = !!s.practice;
  let stake = 0, payout = 0, feature = false;

  if (action === 'spin' && s.mode === 'base') {
    const bet = checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    stake = bet;
    const grid = inject?.grid || drawBase(rand);
    const wins = evaluateWays(grid, bet);
    const hats = cellsOf(grid, 'HAT'), saws = cellsOf(grid, 'SAW');
    payout = cap(wins.reduce((a, w) => a + w.amount, 0), bet);
    Object.assign(out, { grid, wins, hats, saws, win: payout, bet });
    const sawTrig = saws.length >= SAW_TRIGGER, hatTrig = hats.length >= HAT_TRIGGER;
    if (sawTrig) s.queue.push({ type: 'wheel', bet, saws, source: 'saws' });
    if (hatTrig) s.queue.push({ type: 'free', kind: 'hats', bet, hats });
    out.triggers = { saws: sawTrig, hats: hatTrig };
    feature = sawTrig || hatTrig;
    if (s.queue.length) advance(s, rand, out);
  } else if (action === 'spin' && s.mode === 'free') {
    const f = s.free;
    const grid = inject?.grid || drawFree(rand);
    const hats = cellsOf(grid, 'HAT');
    const applied = hats.map(([c, r]) => applyHat(f.frames, c, r, rand));
    f.prizes += applied.reduce((a, x) => a + (x.prize || 0), 0);
    const extra = hats.length >= EXTRA_SPIN_HATS ? 1 : 0;
    f.remaining = f.remaining - 1 + extra;
    f.played++;
    Object.assign(out, { grid, hats, applied, extra, remaining: f.remaining, frames: { ...f.frames }, kind: f.kind, bet: f.bet });
    if (f.remaining <= 0) {
      const rv = revealHouses(f.frames, rand, f.kind === 'hats');
      const raw = Math.floor(f.bet * (rv.totalX + f.prizes));
      payout = cap(raw, f.bet);
      out.reveal = { houses: rv.houses, totalX: rv.totalX, prizesX: f.prizes, win: payout, capped: payout < raw };
      out.win = payout;
      out.finished = { kind: f.kind, played: f.played, total: payout };
      for (let i = 0; i < rv.wheels; i++) s.queue.push({ type: 'wheel', bet: f.bet, saws: randomSaws(rand), source: 'brick' });
      s.free = null;
      advance(s, rand, out);
    }
  } else if (action === 'wheel') {
    if (s.mode !== 'wheel') fail('There is no wheel to spin.');
    const w = s.wheel;
    out.wedge = w.wedge; out.bet = w.bet;
    if (JACKPOTS[w.wedge]) {
      payout = cap(w.bet * JACKPOTS[w.wedge], w.bet);
      out.jackpot = { id: w.wedge, name: JP_NAME[w.wedge], x: JACKPOTS[w.wedge] };
      out.win = payout;
      s.wheel = null;
      advance(s, rand, out);
    } else {
      s.wheel = null;
      out.started = startFree(s, KINDS[w.wedge], w.bet, { saws: w.saws }, rand);
    }
  } else if (action === 'dev') {
    // Practice triggers for testing: cost nothing, pay nothing.
    if (s.mode !== 'base' || s.queue.length) fail('Finish the current feature first.');
    const bet = checkStake(body?.stake, { min: minStake, max: STAKE_MAX });
    s.practice = true;
    const hats = [[0, 0], [1, 1], [2, 2], [3, 0], [4, 1], [2, 0]], saws = [[0, 1], [2, 1], [4, 0]];
    if (body?.event === 'hats') s.queue.push({ type: 'free', kind: 'hats', bet, hats });
    else if (body?.event === 'saws') s.queue.push({ type: 'wheel', bet, saws, source: 'saws' });
    else fail('Unknown test event.');
    if (body?.wedge) { advance(s, rand, out); s.wheel.wedge = String(body.wedge); }
    else advance(s, rand, out);
  } else if (action === 'spin') {
    fail(s.mode === 'wheel' ? 'Spin the bonus wheel first.' : 'Finish the feature first.');
  } else fail('Unknown action.');

  if (wasPractice || s.practice) { stake = 0; payout = 0; out.practice = true; }
  out.payout = payout; out.mode = s.mode;
  if (stake || payout) s.recent = [{ bet: out.bet, win: payout }, ...(s.recent || [])].slice(0, 20);
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'slot', game: 'brick', x: out.bet ? payout / out.bet : 0, feature }] };
}

export const brick = { id: 'brick', label: 'Brick by Brick', init, view, act };
