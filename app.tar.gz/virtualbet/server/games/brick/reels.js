// Brick by Brick – reel engine and 243-ways evaluation (pure).
import { LINE_SYMBOLS, PAYTABLE, REELS, ROWS, STACK_CHANCE, WEIGHTS, WILD_REELS } from './config.js';

export function weighted(pairs, rand) {
  let t = 0; for (const [, w] of pairs) t += w;
  let x = rand() * t;
  for (const [v, w] of pairs) if ((x -= w) < 0) return v;
  return pairs[pairs.length - 1][0];
}
const tables = WEIGHTS.base.map((w) => {
  const all = Object.entries(w).filter(([, x]) => x > 0);
  return { all, noSaw: all.filter(([s]) => s !== 'SAW'), paying: all.filter(([s]) => LINE_SYMBOLS.includes(s)) };
});

/** Base-game grid [reel][row]. At most one saw per reel; some reels stack one symbol. */
export function drawBase(rand) {
  // One stack symbol per spin: every reel that stacks shows the same symbol
  // (like the synchronised stacks on land-based reel strips).
  const stackSym = weighted(tables[0].paying, rand);
  return tables.map((t) => {
    if (rand() < STACK_CHANCE) return Array(ROWS).fill(stackSym);
    let saw = false;
    return Array.from({ length: ROWS }, () => { const s = weighted(saw ? t.noSaw : t.all, rand); if (s === 'SAW') saw = true; return s; });
  });
}

/** Free-spin grid: hats or empty cells only. */
export const drawFree = (rand) => Array.from({ length: REELS }, () => Array.from({ length: ROWS }, () => (rand() < WEIGHTS.freeHat ? 'HAT' : null)));

/** 243 ways: every matching symbol (or wild on reels 2-4) on adjacent reels from reel 1. */
export function evaluateWays(grid, bet) {
  const wins = [];
  for (const sym of LINE_SYMBOLS) {
    const counts = [], cells = [];
    for (let r = 0; r < REELS; r++) {
      const hits = [];
      grid[r].forEach((s, row) => { if (s === sym || (s === 'WILD' && WILD_REELS.includes(r))) hits.push([r, row]); });
      if (!hits.length) break;
      counts.push(hits.length); cells.push(...hits);
    }
    const n = counts.length;
    if (n < 3 || !grid[0].includes(sym)) continue;
    const ways = counts.reduce((a, c) => a * c, 1);
    const amount = Math.floor((bet * PAYTABLE[sym][n - 3] * ways) / 100);
    if (amount > 0) wins.push({ symbol: sym, count: n, ways, pay: PAYTABLE[sym][n - 3], amount, cells });
  }
  return wins;
}

export const cellsOf = (grid, sym) => grid.flatMap((col, r) => col.map((s, row) => (s === sym ? [r, row] : null)).filter(Boolean));
