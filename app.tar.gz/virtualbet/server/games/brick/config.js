// Brick by Brick – every number that defines the game.
//
// An original house-building slot built on the published rules of Light &
// Wonder's Huff N' More Puff / Huff N' Even More Puff (see
// docs/brick-mechanics.md). Verified: 5x3, 243 ways from the left, wild on
// reels 2-4 (not for hats or saws); 6+ hard hats = 6 free spins with a
// straw frame on every triggering hat; hats frame or upgrade a spot
// (straw → stick → brick), a hat on a brick upgrades another frame, 3+ hats
// in a free spin = +1 spin; the wolf blows down straw, then stick, then
// brick houses and pays what's inside (straw 0.5-2x, stick 2-8x or
// Mini/Mini x2/Minor, brick 10-250x or Mini..Grand, brick can award a
// wheel spin); 3+ buzz saws = one wheel spin: Buzz Saw / Mansions / Mega
// Hat (6 free spins each) or Mini/Minor/Major/Grand. Values x total bet.
export const REELS = 5;
export const ROWS = 3;
export const STAKE_MAX = 10000;
export const MAX_WIN_X = 5500;
export const TARGET_RTP = 96;

// Pays in hundredths of the total bet for 3 / 4 / 5 of a kind (per way).
export const PAYTABLE = {
  P1: [25, 75, 150], P2: [25, 60, 120], P3: [20, 50, 100],
  TOOLBOX: [10, 30, 50], TAPE: [10, 25, 40],
  A: [10, 15, 20], K: [10, 15, 20], Q: [10, 12, 15], J: [10, 12, 15],
  T: [5, 8, 10], N: [5, 8, 10],
};
export const LINE_SYMBOLS = Object.keys(PAYTABLE);
export const WILD_REELS = [1, 2, 3];

export const JACKPOTS = { MINI: 20, MINI2: 40, MINOR: 100, MAJOR: 1000, GRAND: 5000 };
export const JP_NAME = { MINI: 'Mini', MINI2: 'Mini ×2', MINOR: 'Minor', MAJOR: 'Major', GRAND: 'Grand' };

// What's inside each house (x total bet, or a jackpot / wheel token).
export const HOUSE = {
  1: [[0.5, 40], [1, 30], [1.5, 18], [2, 12]],
  2: [[2, 30], [3, 25], [4, 18], [5, 12], [8, 8], ['MINI', 4], ['MINI2', 2], ['MINOR', 1]],
  3: [[10, 30], [15, 22], [20, 16], [30, 11], [50, 8], [100, 5], [250, 2], ['MINI', 3], ['MINI2', 2], ['MINOR', 1.5], ['MAJOR', 0.25], ['GRAND', 0.02], ['WHEEL', 1.2]],
};
export const TIER_NAME = { 1: 'Straw', 2: 'Stick', 3: 'Brick' };

export const FREE_SPINS = 6;
export const HAT_TRIGGER = 6;
export const SAW_TRIGGER = 3;
export const EXTRA_SPIN_HATS = 3;

// The bonus wheel (one spin).
export const WHEEL = [
  ['BUZZSAW', 30], ['MANSIONS', 22], ['MEGAHAT', 30], ['MINI', 10], ['MINOR', 6], ['MAJOR', 0.5], ['GRAND', 0.05],
];
export const MEGA_HATS = [[[2, 2], 50], [[3, 3], 35], [[5, 3], 15]];   // [cols, rows]

// Reel weights. Hats can land on every reel; saws at most once per reel.
const base = { P1: 6, P2: 7, P3: 8, TOOLBOX: 10, TAPE: 10, A: 13, K: 13, Q: 14, J: 14, T: 15, N: 15 };
export const WEIGHTS = {
  base: Array.from({ length: REELS }, (_, r) => ({ ...base, WILD: WILD_REELS.includes(r) ? 30 : 0, HAT: 22, SAW: 5.2 })),
  freeHat: 0.080,          // chance a cell shows a hat in free spins (tuned)
};
export const STACK_CHANCE = 0.15;  // a reel shows the spin's stack symbol on all rows
