// Brick by Brick – frames, houses, the wolf's reveal and the bonus wheel (pure).
import { HOUSE, JACKPOTS, MEGA_HATS, REELS, ROWS, WHEEL } from './config.js';
import { weighted } from './reels.js';

const key = (c, r) => `${c},${r}`;
const allCells = () => Array.from({ length: REELS * ROWS }, (_, i) => [Math.floor(i / ROWS), i % ROWS]);

/**
 * A hard hat lands on (c, r): frame an empty spot (straw) or upgrade its
 * frame (straw → stick → brick). On a brick, upgrade a different frame
 * instead; with none left to upgrade, start a straw frame elsewhere; with
 * every spot already brick, the hat is worth a 2x prize. Mutates `frames`.
 */
export function applyHat(frames, c, r, rand) {
  const k = key(c, r);
  const t = frames[k] || 0;
  if (t < 3) { frames[k] = t + 1; return { cell: [c, r], from: t, to: t + 1 }; }
  const up = Object.entries(frames).filter(([, v]) => v < 3).map(([kk]) => kk);
  if (up.length) { const pk = up[Math.floor(rand() * up.length)]; const from = frames[pk]; frames[pk] = from + 1; return { cell: [c, r], redirect: pk.split(',').map(Number), from, to: from + 1 }; }
  const empty = allCells().filter(([cc, rr]) => !frames[key(cc, rr)]);
  if (empty.length) { const [cc, rr] = empty[Math.floor(rand() * empty.length)]; frames[key(cc, rr)] = 1; return { cell: [c, r], redirect: [cc, rr], from: 0, to: 1 }; }
  return { cell: [c, r], prize: 2 };
}

/** Buzz Saw feature: saws slide right off the reels, rightmost first; every cell they touch counts as a hat. */
export function sawSweep(frames, saws, rand) {
  const steps = [];
  for (const [c, r] of [...saws].sort((a, b) => b[0] - a[0] || a[1] - b[1])) {
    const path = [];
    for (let cc = c; cc < REELS; cc++) path.push(applyHat(frames, cc, r, rand));
    steps.push({ saw: [c, r], path });
  }
  return steps;
}

/** Mansions: brick frames wherever a saw landed. */
export function mansions(frames, saws) { for (const [c, r] of saws) frames[key(c, r)] = 3; return saws.map(([c, r]) => ({ cell: [c, r], to: 3 })); }

/** Mega Hat: one giant hat covers a block; straw frames on every covered cell. */
export function megaHat(frames, rand) {
  const [w, h] = weighted(MEGA_HATS, rand);
  const col = Math.floor(rand() * (REELS - w + 1)), row = Math.floor(rand() * (ROWS - h + 1));
  const cells = [];
  for (let c = col; c < col + w; c++) for (let r = row; r < row + h; r++) { frames[key(c, r)] = Math.max(frames[key(c, r)] || 0, 1); cells.push([c, r]); }
  return { col, row, w, h, cells };
}

/** The wolf blows down straw, then stick, then brick houses. Each reveals its prize. */
export function revealHouses(frames, rand, allowWheel) {
  const houses = Object.entries(frames).map(([k, tier]) => {
    const [c, r] = k.split(',').map(Number);
    let v = weighted(HOUSE[tier], rand);
    if (v === 'WHEEL' && !allowWheel) v = 10;
    return { cell: [c, r], tier, prize: v, x: typeof v === 'number' ? v : JACKPOTS[v] || 0 };
  }).sort((a, b) => a.tier - b.tier || a.cell[0] - b.cell[0] || a.cell[1] - b.cell[1]);
  return { houses, totalX: houses.reduce((a, h) => a + h.x, 0), wheels: houses.filter((h) => h.prize === 'WHEEL').length };
}

export const spinWheel = (rand) => weighted(WHEEL, rand);

/** Three saw spots for a wheel won from a brick house (no saws on the reels). */
export function randomSaws(rand) {
  const reels = [0, 1, 2, 3, 4];
  for (let i = reels.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [reels[i], reels[j]] = [reels[j], reels[i]]; }
  reels.length = 3;
  return reels.map((c) => [c, Math.floor(rand() * ROWS)]);
}
