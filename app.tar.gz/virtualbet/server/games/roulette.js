// European roulette (single zero). Every bet is a set of numbers; it pays
// 36/n - 1 to 1 (straight 35:1 ... even-money 1:1). Only sets that are
// real positions on the layout are accepted. House edge 2.7%.
import { fail } from './common.js';

export const WHEEL_ORDER = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
export const RED = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
export const colourOf = (n) => (n === 0 ? 'green' : RED.has(n) ? 'red' : 'black');

const key = (nums) => [...nums].sort((a, b) => a - b).join('-');
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);

// Every legal bet on the layout
const LEGAL = new Set();
(() => {
  const add = (nums) => LEGAL.add(key(nums));
  for (let n = 0; n <= 36; n++) add([n]);
  for (let n = 1; n <= 36; n++) {
    if (n % 3 !== 0) add([n, n + 1]); // horizontal split (same street)
    if (n <= 33) add([n, n + 3]); // vertical split
  }
  add([0, 1]); add([0, 2]); add([0, 3]); add([0, 1, 2]); add([0, 2, 3]); add([0, 1, 2, 3]);
  for (let s = 0; s < 12; s++) {
    const a = s * 3 + 1;
    add([a, a + 1, a + 2]); // street
    if (s < 11) {
      add(range(a, a + 5)); // six line
      add([a, a + 1, a + 3, a + 4]); add([a + 1, a + 2, a + 4, a + 5]); // corners
    }
  }
  for (let d = 0; d < 3; d++) add(range(d * 12 + 1, d * 12 + 12)); // dozens
  for (let c = 1; c <= 3; c++) add(range(1, 36).filter((n) => n % 3 === c % 3)); // columns
  add(range(1, 18)); add(range(19, 36));
  add(range(1, 36).filter((n) => n % 2 === 0)); add(range(1, 36).filter((n) => n % 2 === 1));
  add([...RED]); add(range(1, 36).filter((n) => !RED.has(n)));
})();

export const payoutFor = (count) => 36 / count - 1;

export const roulette = {
  id: 'roulette',
  label: 'Roulette',
  init: () => ({ history: [] }),
  view: (s) => ({ history: s.history.slice(0, 100) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const bets = body?.bets;
    if (!Array.isArray(bets) || !bets.length) fail('Place at least one bet.');
    if (bets.length > 160) fail('Too many separate bets.');
    let stake = 0;
    const clean = bets.map((b) => {
      const nums = Array.isArray(b?.nums) ? b.nums.map(Number) : [];
      if (!nums.length || nums.some((n) => !Number.isInteger(n) || n < 0 || n > 36) || new Set(nums).size !== nums.length) fail('Invalid bet.');
      if (!LEGAL.has(key(nums))) fail('That is not a valid roulette bet.');
      if (!Number.isSafeInteger(b.amount) || b.amount < minStake) fail(`Each bet must be at least £${(minStake / 100).toFixed(2)}.`);
      stake += b.amount;
      return { nums, amount: b.amount };
    });
    const n = Math.floor(rand() * 37);
    let payout = 0;
    const wins = [];
    for (const b of clean) {
      if (b.nums.includes(n)) {
        const p = b.amount * (payoutFor(b.nums.length) + 1);
        payout += p;
        wins.push({ nums: b.nums, amount: b.amount, payout: p });
      }
    }
    const history = [n, ...state.history].slice(0, 200);
    const events = [{ t: 'roulette', n, straightWin: wins.some((w) => w.nums.length === 1) }];
    return { stake, payout, state: { history }, out: { number: n, colour: colourOf(n), wins, payout, stake }, settled: { staked: stake, payout }, events };
  },
};
