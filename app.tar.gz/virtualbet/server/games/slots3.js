// Five original premium slots (pure engines, virtual money, integer pence).
// Outcomes come only from `rand` (crypto RNG in both backends); the screens
// just animate the result they are given. Every game targets a 96% return,
// verified by simulation (see README). Max win 5,000x the stake per spin.
//
//   atlantis  - 5x3, 20 lines. Atlantis Wild. 3+ chests: Hidden Treasure
//               pick-until-collect (3 tridents = Poseidon's Jackpot, 500x;
//               can award free spins where every wild raises the multiplier)
//   neon      - 5x4, 1,024 ways. Cyber Wild; multiplier symbols multiply the
//               spin's win; 3+ OVERDRIVE = bonus round whose multiplier meter
//               only ever grows within that round
//   dragon    - 5x3, 25 lines. Dragon Wild expands up its reel; Golden
//               Fortune multiplier on wins; 3 lanterns = Lucky Lantern ladder;
//               3+ pearls = Dragon's Treasure free spins with sticky dragons
//   cosmic    - 6x5 pay-anywhere (8+), tumbling symbols, gravity-orb
//               multipliers, Meteor Shower wilds, Black Hole free spins that
//               transform symbols
//   pharaoh   - 5x3, 10 lines plus an Ancient Multiplier reel. Pharaoh Wild
//               doubles wins; Pyramid mystery stacks; Golden Scarab free spins
//               that upgrade the multiplier reel
import { checkStake, fail, LINES_10, lineWins, pickWeighted } from './common.js';

const MAX_SPIN = 10000; // £100 per spin, like the other slots
const MAX_X = 5000;
const cap = (win, bet) => Math.min(win, bet * MAX_X);
const W = (o) => Object.entries(o);
const shuffle = (a, rand) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

// Payline sets for 5x3 (row per reel). 20 and 25 extend the standard 10.
const EXTRA_LINES = [
  [0, 1, 0, 1, 0], [2, 1, 2, 1, 2], [1, 0, 1, 2, 1], [0, 1, 1, 1, 0], [2, 1, 1, 1, 2],
  [0, 0, 2, 0, 0], [2, 2, 0, 2, 2], [1, 1, 0, 1, 1], [1, 1, 2, 1, 1], [0, 2, 0, 2, 0],
  [2, 0, 2, 0, 2], [0, 2, 2, 2, 0], [2, 0, 0, 0, 2], [1, 0, 2, 0, 1], [1, 2, 0, 2, 1],
];
export const LINES_20 = [...LINES_10, ...EXTRA_LINES.slice(0, 10)];
export const LINES_25 = [...LINES_10, ...EXTRA_LINES];

/** Shared bookkeeping for a spin: stake, free-spin totals, history, events. */
function spinResult(state, { game, bet, free, win, next, out, feature = false, extraState = {} }) {
  const finished = free && next && next.remaining <= 0 ? { total: next.total } : null;
  if (finished) next = null;
  const paid = !free;
  return {
    stake: paid ? bet : 0, payout: win,
    state: { ...state, ...extraState, free: next, recent: (paid || finished) ? [{ bet, win: finished ? finished.total : win }, ...state.recent].slice(0, 20) : state.recent },
    out: { ...out, free: next, finished, win, bet },
    settled: { staked: paid ? bet : 0, payout: win },
    events: [{ t: 'slot', game, x: win / bet, feature }],
  };
}
const startBet = (state, body, minStake, busyMsg) => {
  if (state.bonus) fail(busyMsg || 'Finish the bonus first.');
  return state.free ? state.free.bet : checkStake(body?.stake, { min: minStake, max: MAX_SPIN });
};

// ═══════════════════════ ATLANTIS – KINGDOM OF THE DEEP ═══════════════════════
export let AT_S = 4.578; // solved for a 96% return (see README)
export const AT_PAY = {
  SHELL: [10, 25, 75], STAR: [10, 25, 75], CORAL: [10, 30, 100], SEAHORSE: [20, 60, 200], TURTLE: [25, 80, 250],
  KRAKEN: [40, 120, 500], MASK: [50, 200, 750], TRIDENT: [75, 300, 1500], WILD: [100, 500, 2500],
};
const atW = (reel, free) => W({ SHELL: 30, STAR: 30, CORAL: 28, SEAHORSE: 16, TURTLE: 12, KRAKEN: 8, MASK: 6, TRIDENT: 4, CHEST: free ? 2 : 3.4, ...(reel >= 1 && reel <= 3 ? { WILD: free ? 4 : 3.2 } : {}) });
const AT_W = [0, 1, 2, 3, 4].map((r) => atW(r, false)), AT_WF = [0, 1, 2, 3, 4].map((r) => atW(r, true));
export const AT_COINS = [[100, 30], [200, 25], [300, 18], [500, 14], [1000, 9], [2500, 4]]; // x bet (hundredths)
export const AT_JACKPOT = 50000; // Poseidon's Jackpot: 500x, fixed
export const AT_FREE_SPINS = 8;
export const AT_MAX_MULT = 10;

function treasureChests(rand) {
  const items = [{ k: 'collect' }, { k: 'collect' }];
  const r = rand();
  const tridents = r < 0.08 ? 3 : r < 0.25 ? 2 : r < 0.55 ? 1 : 0;
  for (let i = 0; i < tridents; i++) items.push({ k: 'trident' });
  if (rand() < 0.5) items.push({ k: 'free', spins: AT_FREE_SPINS });
  while (items.length < 12) items.push({ k: 'coin', x: pickWeighted(AT_COINS, rand) });
  return shuffle(items, rand);
}
const chestValue = (item, b) => (item.k === 'coin' ? Math.floor((b.bet * item.x * AT_S * b.chestMult) / 100) : 0);
const publicBonus = (b) => b && { bet: b.bet, chestMult: b.chestMult, picked: b.picked.map((i) => ({ i, ...b.items[i], amount: chestValue(b.items[i], b) })), tridents: b.tridents, total: b.total, freeSpins: b.freeSpins };

export const atlantis = {
  id: 'atlantis', label: 'Atlantis – Kingdom of the Deep',
  init: () => ({ free: null, bonus: null, recent: [] }),
  view: (s) => ({ free: s.free, bonus: publicBonus(s.bonus), recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action === 'pick') {
      const b = state.bonus;
      if (!b) fail('There is no treasure bonus in play.');
      const i = body?.index;
      if (!Number.isInteger(i) || i < 0 || i >= b.items.length || b.picked.includes(i)) fail('Pick a closed chest.');
      b.picked.push(i);
      const item = b.items[i];
      let jackpot = 0;
      if (item.k === 'coin') b.total += chestValue(item, b);
      if (item.k === 'trident') { b.tridents++; if (b.tridents === 3) { jackpot = Math.floor((b.bet * AT_JACKPOT) / 100); b.total += jackpot; } }
      if (item.k === 'free') b.freeSpins += item.spins;
      const done = item.k === 'collect' || b.picked.length >= b.items.length - 1;
      const out = { pick: { i, ...item, amount: chestValue(item, b) }, jackpot, bonus: publicBonus(b), done, bet: b.bet };
      if (!done) return { stake: 0, payout: 0, state, out };
      const win = cap(b.total, b.bet);
      const free = b.freeSpins ? { bet: b.bet, remaining: b.freeSpins, total: 0, mult: 1 } : null;
      return {
        stake: 0, payout: win,
        state: { ...state, bonus: null, free, recent: [{ bet: b.bet, win }, ...state.recent].slice(0, 20) },
        out: { ...out, revealed: b.items.map((it) => ({ ...it, amount: chestValue(it, b) })), win, freeStart: free },
        settled: { staked: 0, payout: win }, events: [{ t: 'slot', game: 'atlantis', x: win / b.bet, feature: true }],
      };
    }
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = startBet(state, body, minStake, 'Open the treasure chests first.');
    const grid = (free ? AT_WF : AT_W).map((w) => Array.from({ length: 3 }, () => ({ s: pickWeighted(w, rand) })));
    const pt = Object.fromEntries(Object.entries(AT_PAY).map(([k, v]) => [k, v.map((x) => x * AT_S)]));
    const wins = lineWins(grid, bet, pt, { wild: 'WILD', lines: LINES_20, skip: ['CHEST'] });
    let win = wins.reduce((a, w) => a + w.amount, 0);
    const wilds = grid.flat().filter((c) => c.s === 'WILD').length;
    const chests = grid.flat().filter((c) => c.s === 'CHEST').length;
    let next = null, multBefore = 1, mult = 1, bonus = null, trigger = null;
    if (free) {
      multBefore = free.mult;
      mult = Math.min(AT_MAX_MULT, free.mult + wilds); // every Atlantis Wild raises the multiplier
      win = Math.floor(win * mult);
      next = { ...free, mult, remaining: free.remaining - 1, total: 0 };
      if (chests >= 3) { next.remaining += 5; trigger = { extra: 5 }; }
    } else if (chests >= 3) {
      bonus = { bet, items: treasureChests(rand), picked: [], tridents: 0, total: 0, freeSpins: 0, chestMult: chests - 2 };
      trigger = { treasure: true, chestMult: chests - 2 };
    }
    win = cap(win, bet);
    if (next) next.total = free.total + win;
    return spinResult(state, {
      game: 'atlantis', bet, free, win, next, feature: !!trigger?.treasure, extraState: { bonus },
      out: { grid, wins, wilds, chests, multBefore, mult, trigger, bonus: publicBonus(bonus) },
    });
  },
};

// ═══════════════════════ NEON OVERDRIVE ═══════════════════════
export let NE_S = 2.865; // solved for a 96% return (see README)
export const NE_SYMS = ['NODE', 'CHIP', 'DISC', 'CORE', 'VISOR', 'DRONE', 'BIKE', 'ANDROID'];
export const NE_PAY = { NODE: [2, 4, 8], CHIP: [2, 4, 8], DISC: [3, 5, 10], CORE: [3, 6, 12], VISOR: [5, 10, 25], DRONE: [6, 15, 30], BIKE: [10, 25, 60], ANDROID: [15, 40, 100] }; // per way
const neW = (reel, free) => W({ NODE: free ? 11 : 15, CHIP: free ? 11 : 15, DISC: free ? 11 : 14, CORE: free ? 11 : 14, VISOR: 13, DRONE: 12, BIKE: 10, ANDROID: 8, MULT: free ? 2.4 : 1.6, OVER: free ? 1.6 : 2.2, ...(reel >= 1 ? { WILD: 2.2 } : {}) });
const NE_W = [0, 1, 2, 3, 4].map((r) => neW(r, false)), NE_WF = [0, 1, 2, 3, 4].map((r) => neW(r, true));
export const NE_MULTS = [[2, 50], [3, 25], [5, 15], [10, 8], [25, 2]];
export const NE_FREE = { 3: 8, 4: 10, 5: 12 };

export function waysWins(grid, bet, pt, syms, wild = 'WILD') {
  const wins = [];
  for (const sym of syms) {
    let ways = 1, n = 0;
    const cells = [];
    for (let r = 0; r < grid.length; r++) {
      const hits = grid[r].map((c, row) => (c.s === sym || c.s === wild ? row : -1)).filter((x) => x >= 0);
      if (!hits.length) break;
      ways *= hits.length; n++;
      hits.forEach((row) => cells.push([r, row]));
    }
    if (n >= 3 && pt[sym]?.[n - 3]) wins.push({ symbol: sym, count: n, ways, amount: Math.floor((bet * pt[sym][n - 3] * ways) / 100), cells });
  }
  return wins.filter((w) => w.cells.some(([r, row]) => grid[r][row].s === w.symbol));
}

export const neon = {
  id: 'neon', label: 'Neon Overdrive',
  init: () => ({ free: null, recent: [] }),
  view: (s) => ({ free: s.free, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = startBet(state, body, minStake);
    const grid = (free ? NE_WF : NE_W).map((w) => Array.from({ length: 4 }, () => {
      const s = pickWeighted(w, rand);
      return s === 'MULT' ? { s, v: pickWeighted(NE_MULTS, rand) } : { s };
    }));
    const pt = Object.fromEntries(Object.entries(NE_PAY).map(([k, v]) => [k, v.map((x) => x * NE_S)]));
    const wins = waysWins(grid, bet, pt, NE_SYMS);
    const base = wins.reduce((a, w) => a + w.amount, 0);
    const multSum = grid.flat().filter((c) => c.s === 'MULT').reduce((a, c) => a + c.v, 0);
    const overs = grid.flat().filter((c) => c.s === 'OVER').length;
    let mult = 1, meterBefore = null, next = null, trigger = null;
    if (free) {
      meterBefore = free.meter;
      const meter = free.meter + multSum; // the Overdrive meter only ever grows within the round
      mult = meter;
      next = { ...free, meter, remaining: free.remaining - 1 };
      if (overs >= 3) { next.remaining += 5; trigger = { extra: 5 }; }
    } else {
      mult = base && multSum ? multSum : 1;
      if (overs >= 3) { next = { bet, remaining: NE_FREE[Math.min(5, overs)], total: 0, meter: 1 }; trigger = { freeSpins: next.remaining }; }
    }
    const win = cap(Math.floor(base * mult), bet);
    if (free) next.total = free.total + win;
    return spinResult(state, {
      game: 'neon', bet, free, win, next, feature: !!trigger?.freeSpins,
      out: { grid, wins, base, multSum, mult, meterBefore, overs, trigger },
    });
  },
};

// ═══════════════════════ DRAGON'S FORTUNE – THE GOLDEN EMPIRE ═══════════════════════
export let DR_S = 4.14; // solved for a 96% return (see README)
export const DR_PAY = {
  JADE: [10, 25, 75], COIN: [10, 25, 75], FAN: [10, 30, 90], KNOT: [10, 30, 90], KOI: [20, 60, 200],
  INGOT: [25, 80, 300], LION: [40, 150, 600], PHOENIX: [60, 250, 1000], DRAGON: [80, 400, 2000],
};
const drW = (reel, free) => W({
  JADE: 28, COIN: 28, FAN: 26, KNOT: 26, KOI: 14, INGOT: 11, LION: 7, PHOENIX: 5, PEARL: free ? 1.6 : 2.6,
  ...(reel >= 1 && reel <= 3 ? { DRAGON: free ? 1.6 : 2.6 } : {}), ...(!free && reel % 2 === 0 ? { LANTERN: 9 } : {}),
});
const DR_W = [0, 1, 2, 3, 4].map((r) => drW(r, false)), DR_WF = [0, 1, 2, 3, 4].map((r) => drW(r, true));
export const DR_FORTUNE_P = 0.14;
export const DR_FORTUNE = [[2, 55], [3, 25], [5, 14], [8, 6]];
export const DR_LADDER = [200, 500, 1000, 2000, 5000, 10000, 25000, 100000]; // fixed: 2x ... 1,000x
export const DR_CLIMB = 0.5;
export const DR_FREE = { 3: 8, 4: 10, 5: 12 };

export const dragon = {
  id: 'dragon', label: "Dragon's Fortune",
  init: () => ({ free: null, recent: [] }),
  view: (s) => ({ free: s.free, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = startBet(state, body, minStake);
    const landed = (free ? DR_WF : DR_W).map((w) => Array.from({ length: 3 }, () => ({ s: pickWeighted(w, rand) })));
    // Dragon Wilds breathe fire and fill their reel; in free spins they stay put
    const fresh = landed.map((col, i) => (col.some((c) => c.s === 'DRAGON') ? i : -1)).filter((i) => i >= 0);
    const sticky = free ? free.sticky : [];
    const expanded = [...new Set([...sticky, ...fresh])].sort();
    const grid = landed.map((col, i) => (expanded.includes(i) ? col.map(() => ({ s: 'DRAGON' })) : col));
    const pt = Object.fromEntries(Object.entries(DR_PAY).map(([k, v]) => [k, v.map((x) => x * DR_S)]));
    const wins = lineWins(grid, bet, pt, { wild: 'DRAGON', lines: LINES_25, skip: ['PEARL', 'LANTERN'] });
    let lineWin = wins.reduce((a, w) => a + w.amount, 0);
    let fortune = null;
    if (lineWin && rand() < DR_FORTUNE_P) { fortune = pickWeighted(DR_FORTUNE, rand); lineWin *= fortune; }
    // Lucky Lantern ladder: 3 lanterns (reels 1, 3, 5) climb a ladder of fixed prizes
    const lanterns = landed.filter((col) => col.some((c) => c.s === 'LANTERN')).length;
    let ladder = null;
    if (lanterns === 3) {
      let level = 0;
      while (level < DR_LADDER.length - 1 && rand() < DR_CLIMB) level++;
      ladder = { level, x: DR_LADDER[level], amount: Math.floor((bet * DR_LADDER[level]) / 100) };
    }
    const pearls = landed.flat().filter((c) => c.s === 'PEARL').length;
    let win = cap(lineWin + (ladder?.amount || 0), bet);
    let next = null, trigger = null;
    if (free) {
      next = { ...free, sticky: expanded, remaining: free.remaining - 1, total: free.total + win };
      if (pearls >= 3) { next.remaining += 4; trigger = { extra: 4 }; }
    } else if (pearls >= 3) {
      next = { bet, remaining: DR_FREE[Math.min(5, pearls)], total: 0, sticky: [] };
      trigger = { freeSpins: next.remaining };
    }
    return spinResult(state, {
      game: 'dragon', bet, free, win, next, feature: !!(trigger?.freeSpins || ladder),
      out: { landed, grid, expanded, fresh, wins, fortune, ladder, pearls, trigger },
    });
  },
};

// ═══════════════════════ COSMIC COLLAPSE – GALACTIC SLOTS ═══════════════════════
export let CO_S = 0.574; // solved for a 96% return (see README)
export const CO_SYMS = ['ASTEROID', 'COMET', 'MOON', 'CRYSTAL', 'SATELLITE', 'PLANET', 'SUN', 'GALAXY'];
export const CO_PAY = { ASTEROID: [25, 75, 200], COMET: [30, 90, 250], MOON: [40, 100, 300], CRYSTAL: [50, 120, 400], SATELLITE: [80, 150, 500], PLANET: [100, 250, 800], SUN: [150, 400, 1200], GALAXY: [250, 750, 2500] }; // 8-9, 10-11, 12+
const CO_W = W({ ASTEROID: 14, COMET: 13, MOON: 12.5, CRYSTAL: 12, SATELLITE: 11, PLANET: 10, SUN: 9, GALAXY: 8, WILD: 0.7, GRAVITY: 0.6, HOLE: 1.75 });
const CO_WF = W({ ASTEROID: 14, COMET: 13, MOON: 12.5, CRYSTAL: 12, SATELLITE: 11, PLANET: 10, SUN: 9, GALAXY: 8, WILD: 0.7, GRAVITY: 0.8, HOLE: 1.0 });
export const CO_ORBS = [[2, 40], [3, 25], [5, 18], [10, 10], [25, 4]];
export const CO_GMAX = 100; // the Black Hole round's gravity multiplier tops out at x100
export const CO_METEOR_P = 0.04;
export const CO_COLS = 6, CO_ROWS = 5;
const CO_LOW = ['ASTEROID', 'COMET', 'MOON', 'CRYSTAL'], CO_HIGH = ['SATELLITE', 'PLANET', 'SUN'];
const tier = (n) => (n >= 12 ? 2 : n >= 10 ? 1 : 0);
const coCell = (w, rand) => { const s = pickWeighted(w, rand); return s === 'GRAVITY' ? { s, v: pickWeighted(CO_ORBS, rand) } : { s }; };

export const cosmic = {
  id: 'cosmic', label: 'Cosmic Collapse',
  init: () => ({ free: null, recent: [] }),
  view: (s) => ({ free: s.free, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = startBet(state, body, minStake);
    const w = free ? CO_WF : CO_W;
    let grid = Array.from({ length: CO_COLS }, () => Array.from({ length: CO_ROWS }, () => coCell(w, rand)));
    // Black Hole: in free spins every low symbol of one kind becomes a higher one
    let transform = null;
    if (free) {
      const from = CO_LOW[Math.floor(rand() * CO_LOW.length)], to = CO_HIGH[Math.floor(rand() * CO_HIGH.length)];
      const cells = [];
      grid.forEach((col, c) => col.forEach((x, r) => { if (x.s === from) { cells.push([c, r]); x.s = to; } }));
      transform = { from, to, cells };
    }
    // Meteor Shower: occasionally meteors strike and turn 3-6 symbols into Cosmic Wilds
    let meteors = null;
    if (!free && rand() < CO_METEOR_P) {
      const open = [];
      grid.forEach((col, c) => col.forEach((x, r) => { if (CO_SYMS.includes(x.s)) open.push([c, r]); }));
      shuffle(open, rand);
      meteors = open.slice(0, 3 + Math.floor(rand() * 4));
      meteors.forEach(([c, r]) => { grid[c][r] = { s: 'WILD' }; });
    }
    const steps = [];
    let total = 0;
    for (let guard = 0; guard < 40; guard++) {
      const flat = grid.flat();
      const wilds = flat.filter((x) => x.s === 'WILD').length;
      const wins = [];
      for (const sym of CO_SYMS) {
        const n = flat.filter((x) => x.s === sym).length;
        if (n && n + wilds >= 8) wins.push({ symbol: sym, count: n + wilds, amount: Math.floor((bet * CO_PAY[sym][tier(n + wilds)] * CO_S) / 100) });
      }
      const stepWin = wins.reduce((a, x) => a + x.amount, 0);
      const removed = [];
      if (wins.length) grid.forEach((col, c) => col.forEach((x, r) => { if (x.s === 'WILD' || wins.some((wn) => wn.symbol === x.s)) removed.push([c, r]); }));
      steps.push({ grid: grid.map((col) => col.map((x) => ({ ...x }))), wins, removed, win: stepWin });
      if (!wins.length) break;
      total += stepWin;
      const gone = new Set(removed.map(([c, r]) => `${c}-${r}`));
      grid = grid.map((col, c) => {
        const keep = col.filter((_, r) => !gone.has(`${c}-${r}`));
        const add = Array.from({ length: CO_ROWS - keep.length }, () => coCell(w, rand));
        return [...add, ...keep];
      });
    }
    const final = steps[steps.length - 1].grid;
    const orbSum = final.flat().filter((x) => x.s === 'GRAVITY').reduce((a, x) => a + x.v, 0);
    const holes = final.flat().filter((x) => x.s === 'HOLE').length;
    let mult = 1, next = null, trigger = null;
    if (free) {
      const gmult = Math.min(CO_GMAX, free.gmult + (total && orbSum ? orbSum : 0)); // gravity builds through the round
      mult = gmult || 1;
      next = { ...free, gmult, remaining: free.remaining - 1 };
      if (holes >= 3) { next.remaining += 5; trigger = { extra: 5 }; }
    } else {
      mult = total && orbSum ? orbSum : 1;
      if (holes >= 4) { next = { bet, remaining: 10, total: 0, gmult: 0 }; trigger = { freeSpins: 10 }; }
    }
    const win = cap(Math.floor(total * mult), bet);
    if (free) next.total = free.total + win;
    return spinResult(state, {
      game: 'cosmic', bet, free, win, next, feature: !!trigger?.freeSpins,
      out: { steps, base: total, orbSum, mult, transform, meteors, holes, trigger },
    });
  },
};

// ═══════════════════════ PHARAOH'S GOLD – SECRETS OF EGYPT ═══════════════════════
export let PH_S = 2.315; // solved for a 96% return (see README)
export const PH_PAY = {
  ANKH: [10, 30, 100], LOTUS: [10, 30, 100], EYE: [15, 40, 125], CAT: [25, 80, 300], SPHINX: [40, 150, 500],
  MASK: [60, 250, 1000], PHARAOH: [100, 500, 2500],
};
const PH_SYMS = ['ANKH', 'LOTUS', 'EYE', 'CAT', 'SPHINX', 'MASK'];
const phW = (reel, free) => W({ ANKH: 28, LOTUS: 28, EYE: 26, CAT: 15, SPHINX: 11, MASK: 7, SCARAB: free ? 2.6 : 3, ...(reel >= 1 ? { PHARAOH: 3 } : {}) });
const PH_W = [0, 1, 2, 3, 4].map((r) => phW(r, false)), PH_WF = [0, 1, 2, 3, 4].map((r) => phW(r, true));
export const PH_MULT_REEL = [[1, 60], [2, 22], [3, 10], [5, 6], [10, 2]];
export const PH_MYSTERY_P = 0.12;
const PH_REVEAL = W({ ANKH: 20, LOTUS: 20, EYE: 18, CAT: 14, SPHINX: 11, MASK: 8, PHARAOH: 6 });
export const PH_LEVELS = [{ at: 3, min: 2 }, { at: 6, min: 3 }, { at: 9, min: 5 }]; // scarabs collected -> lowest multiplier
export const phMultReel = (scarabs = 0) => {
  const min = PH_LEVELS.filter((l) => scarabs >= l.at).reduce((a, l) => Math.max(a, l.min), 1);
  return PH_MULT_REEL.filter(([v]) => v >= min);
};

export const pharaoh = {
  id: 'pharaoh', label: "Pharaoh's Gold",
  init: () => ({ free: null, recent: [] }),
  view: (s) => ({ free: s.free, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = startBet(state, body, minStake);
    const landed = (free ? PH_WF : PH_W).map((w) => Array.from({ length: 3 }, () => ({ s: pickWeighted(w, rand) })));
    // Pyramid mystery stacks: 2-3 stone blocks on a reel, all revealing one symbol
    const mystery = [];
    landed.forEach((col, reel) => {
      if (rand() < PH_MYSTERY_P) {
        const h = 2 + Math.floor(rand() * 2), top = Math.floor(rand() * (4 - h));
        for (let r = top; r < top + h; r++) { if (col[r].s !== 'SCARAB') { col[r] = { s: 'MYSTERY' }; mystery.push([reel, r]); } }
      }
    });
    let reveal = null;
    if (mystery.length) {
      reveal = pickWeighted(PH_REVEAL, rand);
      if (reveal === 'PHARAOH') mystery.forEach(([reel]) => { if (reel === 0) reveal = 'MASK'; }); // wilds never on reel 1
    }
    const grid = landed.map((col) => col.map((c) => (c.s === 'MYSTERY' ? { s: reveal } : c)));
    const pt = Object.fromEntries(Object.entries(PH_PAY).map(([k, v]) => [k, v.map((x) => x * PH_S)]));
    const wins = lineWins(grid, bet, pt, { wild: 'PHARAOH', skip: ['SCARAB'] }).map((w) => {
      const doubled = w.symbol !== 'PHARAOH' && w.cells.some(([r, row]) => grid[r][row].s === 'PHARAOH');
      return doubled ? { ...w, amount: w.amount * 2, doubled: true } : w; // Pharaoh Wild doubles its wins
    });
    const lineWin = wins.reduce((a, w) => a + w.amount, 0);
    const scarabs = grid.flat().filter((c) => c.s === 'SCARAB').length;
    const level = free ? free.scarabs : 0;
    const reelVals = phMultReel(level);
    const mult = pickWeighted(reelVals, rand); // Ancient Multiplier reel spins every time
    const scatterWin = scarabs >= 3 ? Math.floor((bet * [0, 0, 0, 200, 1000, 5000][Math.min(5, scarabs)] * PH_S) / 100) : 0;
    const win = cap(lineWin * mult + scatterWin, bet);
    let next = null, trigger = null;
    if (free) {
      const collected = free.scarabs + scarabs;
      next = { ...free, scarabs: collected, remaining: free.remaining - 1 + scarabs, total: free.total + win };
      const lvl = PH_LEVELS.filter((l) => collected >= l.at && free.scarabs < l.at);
      if (scarabs) trigger = { extra: scarabs, upgraded: lvl.length ? lvl[lvl.length - 1].min : null };
    } else if (scarabs >= 3) {
      next = { bet, remaining: 10, total: 0, scarabs: 0 };
      trigger = { freeSpins: 10 };
    }
    return spinResult(state, {
      game: 'pharaoh', bet, free, win, next, feature: !!trigger?.freeSpins,
      out: { landed, grid, mystery, reveal, wins, lineWin, mult, reelVals: reelVals.map(([v]) => v), scarabs, scatterWin, trigger },
    });
  },
};

// Tuning hooks for the RTP simulation script
export const _tune3 = {
  set at(v) { AT_S = v; }, set ne(v) { NE_S = v; }, set dr(v) { DR_S = v; }, set co(v) { CO_S = v; }, set ph(v) { PH_S = v; }, set fr(v) { FR_S = v; },
};

/** Measured behaviour (simulation, 200k+ spins each) shown in each game's info panel. */
export const STATS3 = {
  atlantis: { hit: '41%', feature: 'Hidden Treasure about 1 in 185 spins' },
  neon: { hit: '53%', feature: 'Overdrive about 1 in 130 spins' },
  dragon: { hit: '37%', feature: 'Lucky Lanterns about 1 in 235 spins; free spins about 1 in 480' },
  cosmic: { hit: '32%', feature: 'Black Hole round about 1 in 240 spins' },
  pharaoh: { hit: '33%', feature: 'Golden Scarab free spins about 1 in 175 spins' },
};

// ═══════════════════════ FROSTFANG – HOWL OF THE NORTHERN LIGHTS ═══════════════════════
// 5 reels x 4 rows, 40 lines. Frostfang Wilds land on reels 2-5, expand to fill
// their reel and carry a multiplier (x2-x10). Line wins through wild reels are
// multiplied by the SUM of those reels' multipliers.
//   Howl Respins (base game): wild reels stay put and the other reels respin for
//   free. Every new wild expands too, and adds +1 to every wild already there.
//   Respins continue while new wilds land.
//   Full Moon free spins: 3/4/5 moons = 8/10/12 spins. Wild reels stay for the
//   whole round and keep growing (+1 to all for each new wild), max x25 per reel.
const FR_ROWS = 4;
export const LINES_40 = [
  [0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2], [3, 3, 3, 3, 3],
  [0, 1, 2, 1, 0], [1, 2, 3, 2, 1], [3, 2, 1, 2, 3], [2, 1, 0, 1, 2],
  [0, 1, 1, 1, 0], [1, 2, 2, 2, 1], [2, 3, 3, 3, 2], [3, 2, 2, 2, 3], [2, 1, 1, 1, 2], [1, 0, 0, 0, 1],
  [0, 0, 1, 0, 0], [1, 1, 2, 1, 1], [2, 2, 3, 2, 2], [3, 3, 2, 3, 3], [2, 2, 1, 2, 2], [1, 1, 0, 1, 1],
  [0, 1, 0, 1, 0], [1, 2, 1, 2, 1], [2, 3, 2, 3, 2], [3, 2, 3, 2, 3], [2, 1, 2, 1, 2], [1, 0, 1, 0, 1],
  [0, 0, 1, 2, 3], [3, 3, 2, 1, 0], [0, 1, 2, 3, 3], [3, 2, 1, 0, 0],
  [0, 1, 2, 2, 2], [3, 2, 1, 1, 1], [1, 2, 3, 3, 3], [2, 1, 0, 0, 0],
  [0, 2, 0, 2, 0], [3, 1, 3, 1, 3], [1, 3, 1, 3, 1], [2, 0, 2, 0, 2], [0, 3, 0, 3, 0], [3, 0, 3, 0, 3],
];
export let FR_S = 1.211; // solved for a 96% return (base + free-round decomposition, see README)
export const FR_PAY = {
  RUNE_B: [5, 15, 40], RUNE_G: [5, 15, 40], RUNE_P: [5, 20, 50], RUNE_R: [5, 20, 50],
  OWL: [10, 25, 75], ELK: [10, 30, 100], BEAR: [15, 40, 150], EAGLE: [20, 60, 200], WOLF: [25, 100, 500],
};
export const FR_SYMS = Object.keys(FR_PAY);
const frW = (reel, mode) => W({
  RUNE_B: 26, RUNE_G: 26, RUNE_P: 24, RUNE_R: 24, OWL: 13, ELK: 11, BEAR: 9, EAGLE: 7, WOLF: 5,
  ...(mode === 'respin' ? {} : { MOON: mode === 'free' ? 2 : 2.6 }),
  ...(reel >= 1 ? { WILD: mode === 'free' ? 1.1 : mode === 'respin' ? 1.1 : 1.15 } : {}),
});
const FR_W = [0, 1, 2, 3, 4].map((r) => frW(r, 'base')), FR_WR = [0, 1, 2, 3, 4].map((r) => frW(r, 'respin')), FR_WF = [0, 1, 2, 3, 4].map((r) => frW(r, 'free'));
export const FR_MULTS = [[2, 55], [3, 28], [5, 13], [10, 4]];
export const FR_MAX_MULT = 25;
export const FR_FREE = { 3: 8, 4: 10, 5: 12 };

const frGrid = (weights, rand, held) => weights.map((w, reel) => (held[reel] ? Array.from({ length: FR_ROWS }, () => ({ s: 'WILD' })) : Array.from({ length: FR_ROWS }, () => ({ s: pickWeighted(w, rand) }))));
/** Expand new wilds: each fresh wild reel gets a multiplier and adds +1 to existing ones. */
function frExpand(grid, wilds, rand) {
  const fresh = [];
  grid.forEach((col, reel) => { if (wilds[reel] === undefined && col.some((c) => c.s === 'WILD')) fresh.push(reel); });
  const before = { ...wilds };
  const next = { ...wilds };
  for (const reel of Object.keys(next)) next[reel] = Math.min(FR_MAX_MULT, next[reel] + fresh.length);
  for (const reel of fresh) next[reel] = pickWeighted(FR_MULTS, rand);
  const out = grid.map((col, reel) => (next[reel] !== undefined ? col.map(() => ({ s: 'WILD' })) : col));
  return { grid: out, wilds: next, fresh, before };
}
function frWins(grid, bet, wilds) {
  const pt = Object.fromEntries(Object.entries(FR_PAY).map(([k, v]) => [k, v.map((x) => x * FR_S)]));
  return lineWins(grid, bet, pt, { wild: 'WILD', lines: LINES_40, skip: ['MOON'] }).map((w) => {
    const m = Object.entries(wilds).filter(([reel]) => Number(reel) < w.count).reduce((a, [, v]) => a + v, 0);
    return m ? { ...w, base: w.amount, mult: m, amount: w.amount * m } : w;
  });
}

export const frost = {
  id: 'frost', label: 'Frostfang',
  init: () => ({ free: null, recent: [] }),
  view: (s) => ({ free: s.free, recent: s.recent.slice(0, 15) }),
  act(state, action, body, { rand, minStake }) {
    if (action !== 'spin') fail('Unknown action.');
    const free = state.free;
    const bet = startBet(state, body, minStake);
    const steps = [];
    let total = 0, moons = 0, next = null, trigger = null;
    if (free) {
      // Wild reels from earlier free spins stay put
      const held = Object.fromEntries(Object.keys(free.wilds).map((r) => [r, true]));
      const landed = frGrid(FR_WF, rand, held);
      const ex = frExpand(landed, free.wilds, rand);
      const wins = frWins(ex.grid, bet, ex.wilds);
      const win = wins.reduce((a, w) => a + w.amount, 0);
      moons = landed.flat().filter((c) => c.s === 'MOON').length;
      steps.push({ landed, grid: ex.grid, wilds: ex.wilds, before: ex.before, fresh: ex.fresh, held: Object.keys(free.wilds).map(Number), wins, win });
      total = win;
      next = { ...free, wilds: ex.wilds, remaining: free.remaining - 1 };
      if (moons >= 3) { next.remaining += 5; trigger = { extra: 5 }; }
    } else {
      let wilds = {}, held = {};
      let landed = frGrid(FR_W, rand, held);
      moons = landed.flat().filter((c) => c.s === 'MOON').length;
      for (let guard = 0; guard < 6; guard++) {
        const ex = frExpand(landed, wilds, rand);
        const wins = frWins(ex.grid, bet, ex.wilds);
        const win = wins.reduce((a, w) => a + w.amount, 0);
        steps.push({ landed, grid: ex.grid, wilds: ex.wilds, before: ex.before, fresh: ex.fresh, held: Object.keys(held).map(Number), wins, win, respin: guard > 0 });
        total += win;
        // Howl Respin: only while new wilds keep landing
        if (!ex.fresh.length || Object.keys(ex.wilds).length >= 4) break;
        wilds = ex.wilds;
        held = Object.fromEntries(Object.keys(wilds).map((r) => [r, true]));
        landed = frGrid(FR_WR, rand, held);
      }
      if (moons >= 3) { next = { bet, remaining: FR_FREE[Math.min(5, moons)], total: 0, wilds: {} }; trigger = { freeSpins: next.remaining }; }
    }
    const win = cap(total, bet);
    if (free) next.total = free.total + win;
    return spinResult(state, {
      game: 'frost', bet, free, win, next, feature: !!trigger?.freeSpins,
      out: { steps, moons, trigger, respins: steps.length - 1 },
    });
  },
};
