// Cluck Crossing – every number that defines the game.
//
// Each difficulty is a road of N lanes. Lane i is crossed safely with
// probability 1 - RISK[i]; the risk rises steadily from `firstRisk` on the
// first lane to the last lane, solved so that the final multiplier lands on
// `topMultiplier`. The multiplier after k safe lanes is
//
//     M[k] = RTP / P(survive lanes 1..k)      (rounded DOWN to 2 dp)
//
// so cashing out after ANY lane returns RTP (a hair less after rounding):
// P(survive k) * M[k] <= RTP. Change RTP, lanes, firstRisk or topMultiplier
// here and every table, the UI and the tests follow.
export const RTP = 0.97;

export const DIFFICULTIES = {
  easy: { label: 'Easy', lanes: 24, firstRisk: 0.04, topMultiplier: 24 },
  medium: { label: 'Medium', lanes: 22, firstRisk: 0.12, topMultiplier: 250 },
  hard: { label: 'Hard', lanes: 20, firstRisk: 0.2, topMultiplier: 2500 },
  hardcore: { label: 'Hardcore', lanes: 15, firstRisk: 0.4, topMultiplier: 10000 },
};
export const DIFF_IDS = Object.keys(DIFFICULTIES);

/** Per-lane risk rising linearly from firstRisk to the value that hits topMultiplier. */
function risksFor({ lanes, firstRisk, topMultiplier }) {
  const target = Math.log(topMultiplier / RTP);              // = -sum ln(1 - r_i)
  const sum = (last) => { let s = 0; for (let i = 0; i < lanes; i++) s -= Math.log(1 - (firstRisk + ((last - firstRisk) * i) / Math.max(1, lanes - 1))); return s; };
  let lo = firstRisk, hi = 0.95;
  for (let k = 0; k < 80; k++) { const mid = (lo + hi) / 2; if (sum(mid) < target) lo = mid; else hi = mid; }
  return Array.from({ length: lanes }, (_, i) => firstRisk + ((lo - firstRisk) * i) / Math.max(1, lanes - 1));
}

export const TABLES = Object.fromEntries(DIFF_IDS.map((id) => {
  const risks = risksFor(DIFFICULTIES[id]);
  let p = 1;
  const mults = risks.map((r) => { p *= 1 - r; return Math.floor((RTP / p) * 100 + 1e-6) / 100; });
  return [id, { ...DIFFICULTIES[id], risks, mults }];
}));
