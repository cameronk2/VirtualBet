// Cluck Crossing – round flow (server-authoritative, persisted state).
//
// idle → start (stake taken) → run → step… → hit (lost) | cashout | last lane
// (paid automatically). Each lane's outcome is rolled on the server with the
// platform's cryptographic RNG only when the player asks to cross it; the
// screen just animates the answer. Every action advances the saved state
// exactly once, so a repeated click or a refresh can't move, pay or charge twice.
import { checkStake, fail } from '../common.js';
import { DIFF_IDS, TABLES } from './config.js';

export const init = () => ({ mode: 'idle', round: null, recent: [] });
const roundView = (r) => r && {
  bet: r.bet, difficulty: r.difficulty, lane: r.lane, lanes: TABLES[r.difficulty].lanes,
  mult: r.lane ? TABLES[r.difficulty].mults[r.lane - 1] : 0,
  next: r.lane < TABLES[r.difficulty].lanes ? { mult: TABLES[r.difficulty].mults[r.lane], chance: +(1 - TABLES[r.difficulty].risks[r.lane]).toFixed(4) } : null,
};
export const view = (s) => ({ mode: s.mode, round: roundView(s.round), recent: (s.recent || []).slice(0, 25) });

function end(s, result, payout, now) {
  const r = s.round, t = TABLES[r.difficulty];
  s.recent = [{ bet: r.bet, difficulty: r.difficulty, lane: r.lane, lanes: t.lanes, mult: result === 'hit' ? 0 : t.mults[r.lane - 1], reached: r.lane ? t.mults[r.lane - 1] : 0, result, payout, at: now }, ...(s.recent || [])].slice(0, 25);
  s.round = null; s.mode = 'idle';
}

export function act(state, action, body, { rand, now, minStake, maxStake }) {
  const s = { ...init(), ...structuredClone(state || {}) };
  const out = { action };
  let stake = 0, payout = 0;

  if (action === 'start') {
    if (s.mode === 'run') fail('A round is already in play.');
    const difficulty = body?.difficulty;
    if (!DIFF_IDS.includes(difficulty)) fail('Choose a difficulty.');
    stake = checkStake(body?.stake, { min: minStake, max: maxStake });
    s.round = { bet: stake, difficulty, lane: 0 };
    s.mode = 'run';
    out.started = true;
  } else if (action === 'step') {
    if (s.mode !== 'run') fail('There is no round in play.');
    const r = s.round, t = TABLES[r.difficulty];
    if (r.lane >= t.lanes) fail('The chicken has already crossed.');
    const hit = rand() < t.risks[r.lane];
    if (hit) {
      out.hit = true; out.lane = r.lane + 1; out.lost = r.bet;
      end(s, 'hit', 0, now);
    } else {
      r.lane++;
      out.safe = true; out.lane = r.lane; out.mult = t.mults[r.lane - 1];
      if (r.lane === t.lanes) {                       // reached the far side: paid automatically
        payout = Math.floor(r.bet * out.mult);
        out.finished = true; out.win = payout;
        end(s, 'finish', payout, now);
      }
    }
  } else if (action === 'cashout') {
    if (s.mode !== 'run') fail('There is no round in play.');
    const r = s.round;
    if (r.lane < 1) fail('Cross at least one lane before cashing out.');
    out.mult = TABLES[r.difficulty].mults[r.lane - 1]; out.lane = r.lane;
    payout = Math.floor(r.bet * out.mult);
    out.cashed = true; out.win = payout; out.bet = r.bet;
    end(s, 'cashout', payout, now);
  } else fail('Unknown action.');

  out.payout = payout; out.mode = s.mode;
  return { stake, payout, state: s, out: { ...out, view: view(s) }, settled: { staked: stake, payout }, events: [{ t: 'chicken', cashed: !!out.cashed || !!out.finished, mult: out.mult || 0 }] };
}

export const chicken = { id: 'chicken', label: 'Cluck Crossing', init, view, act };
