// Three Card Poker against the dealer.
// Ante (+ optional Pair Plus) -> see your cards -> Play (bet equal to the
// ante) or Fold. Dealer qualifies with Queen-high or better.
// Ante bonus: straight 1:1, trips 4:1, straight flush 5:1.
// Pair Plus: pair 1, flush 4, straight 6, trips 30, straight flush 40.
import { checkStake, fail, RANKS, rankOf, shoe, suitOf } from './common.js';

export const PAIR_PLUS = { pair: 1, flush: 4, straight: 6, trips: 30, straightFlush: 40 };
export const ANTE_BONUS = { straight: 1, trips: 4, straightFlush: 5 };
export const HAND_NAME = { straightFlush: 'Straight Flush', trips: 'Three of a Kind', straight: 'Straight', flush: 'Flush', pair: 'Pair', high: 'High Card' };
const CAT = { high: 0, pair: 1, flush: 2, straight: 3, trips: 4, straightFlush: 5 };

const rv = (c) => { const i = RANKS.indexOf(rankOf(c)); return i === 0 ? 14 : i + 1; }; // A high

export function evaluate(cards) {
  const v = cards.map(rv).sort((a, b) => b - a);
  const flush = cards.every((c) => suitOf(c) === suitOf(cards[0]));
  let straightHigh = 0;
  if (v[0] - v[1] === 1 && v[1] - v[2] === 1) straightHigh = v[0];
  if (v[0] === 14 && v[1] === 3 && v[2] === 2) straightHigh = 3; // A-2-3 is the lowest straight
  const trips = v[0] === v[2];
  const pair = !trips && (v[0] === v[1] || v[1] === v[2]);
  let cat = 'high', tie = v;
  if (straightHigh && flush) { cat = 'straightFlush'; tie = [straightHigh]; }
  else if (trips) { cat = 'trips'; tie = [v[0]]; }
  else if (straightHigh) { cat = 'straight'; tie = [straightHigh]; }
  else if (flush) cat = 'flush';
  else if (pair) { const p = v[0] === v[1] ? v[0] : v[1]; const k = v[0] === v[1] ? v[2] : v[0]; cat = 'pair'; tie = [p, k]; }
  return { cat, score: [CAT[cat], ...tie] };
}
const cmp = (a, b) => { for (let i = 0; i < Math.max(a.length, b.length); i++) { const d = (a[i] || 0) - (b[i] || 0); if (d) return d; } return 0; };
const qualifies = (e) => CAT[e.cat] > 0 || e.score[1] >= 12;

/** Optimal simple strategy: play Q-6-4 or better. */
export function shouldPlay(cards) {
  const e = evaluate(cards);
  if (CAT[e.cat] > 0) return true;
  return cmp(e.score.slice(1), [12, 6, 4]) >= 0;
}

export const threecard = {
  id: 'threecard',
  label: 'Three Card Poker',
  init: () => ({ hand: null, recent: [] }),
  view: (s) => ({ hand: s.hand ? { ante: s.hand.ante, pp: s.hand.pp, player: s.hand.player, playerHand: evaluate(s.hand.player).cat, hint: shouldPlay(s.hand.player) ? 'play' : 'fold' } : null, recent: s.recent }),
  act(state, action, body, { rand, minStake, maxStake }) {
    if (action === 'deal') {
      if (state.hand) fail('Finish the current hand first.');
      const ante = checkStake(body?.ante, { min: minStake, max: maxStake, label: 'Ante' });
      const pp = body?.pp || 0;
      if (pp) checkStake(pp, { min: minStake, max: maxStake, label: 'Pair Plus' });
      const s = shoe(rand, 1, 6);
      const hand = { ante, pp, player: s.slice(0, 3), dealer: s.slice(3, 6) };
      return { stake: ante + pp, payout: 0, state: { ...state, hand }, out: { phase: 'decide', ...threecard.view({ hand, recent: [] }).hand } };
    }
    if (action !== 'play' && action !== 'fold') fail('Unknown action.');
    const h = state.hand;
    if (!h) fail('Deal a hand first.');
    const pe = evaluate(h.player), de = evaluate(h.dealer);
    const play = action === 'play';
    let payout = 0;
    const lines = [];
    // Pair Plus pays on the player's hand regardless of fold
    if (h.pp) {
      const m = PAIR_PLUS[pe.cat];
      if (m) { payout += h.pp * (m + 1); lines.push({ bet: 'Pair Plus', result: HAND_NAME[pe.cat], amount: h.pp * (m + 1) }); }
      else lines.push({ bet: 'Pair Plus', result: 'Lose', amount: 0 });
    }
    let outcome = 'fold';
    if (play) {
      const bonus = ANTE_BONUS[pe.cat] ? h.ante * ANTE_BONUS[pe.cat] : 0;
      if (!qualifies(de)) { outcome = 'noQualify'; payout += h.ante * 2 + h.ante; }
      else {
        const c = cmp(pe.score, de.score);
        if (c > 0) { outcome = 'win'; payout += h.ante * 4; }
        else if (c === 0) { outcome = 'push'; payout += h.ante * 2; }
        else outcome = 'lose';
      }
      if (bonus) { payout += bonus; lines.push({ bet: 'Ante bonus', result: HAND_NAME[pe.cat], amount: bonus }); }
    }
    const staked = h.ante + h.pp + (play ? h.ante : 0);
    const recent = [{ outcome, net: payout - staked }, ...state.recent].slice(0, 10);
    return {
      stake: play ? h.ante : 0, payout,
      state: { hand: null, recent },
      out: { phase: 'done', player: h.player, dealer: h.dealer, playerHand: pe.cat, dealerHand: de.cat, dealerQualifies: qualifies(de), outcome, lines, payout, staked },
      settled: { staked, payout },
      events: [{ t: 'threecard', cat: pe.cat, outcome }],
    };
  },
};
