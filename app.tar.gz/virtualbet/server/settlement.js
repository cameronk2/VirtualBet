// Automatic settlement. Only matches whose result is VERIFIED by the
// data source (result_verified = 1) are used; anything else stays open.
import { q, tx } from './db.js';
import { credit } from './wallet.js';
import { resultFromRow, settleSelection, VOID_STATUSES } from './markets.js';
import { potentialReturn } from './money.js';
import { now } from './util.js';
import { award } from './progress.js';
import { notifySettled } from './push.js';

const DATA_TIMEOUT_MS = 48 * 3600 * 1000; // void if result detail never becomes available
const POSTPONED_VOID_MS = 72 * 3600 * 1000;

export function settlePending() {
  const t = now();
  let settledSelections = 0;
  let settledBets = 0;

  const rows = q(`SELECT s.id AS sel_id, s.market_key, s.selection_key, m.*
    FROM bet_selections s JOIN matches m ON m.id = s.match_id
    WHERE s.status = 'OPEN' AND (
      (m.status = 'FINISHED' AND m.result_verified = 1)
      OR m.status IN ('ABANDONED', 'CANCELLED')
      OR (m.status = 'POSTPONED' AND m.kickoff_at < ?)
    )`).all(t - POSTPONED_VOID_MS);

  if (rows.length) {
    tx(() => {
      for (const r of rows) {
        let status = null;
        let reason = null;
        if (VOID_STATUSES.includes(r.status) || r.status === 'POSTPONED') {
          status = 'VOID';
          reason = `Match ${r.status.toLowerCase()}`;
        } else {
          status = settleSelection(r.market_key, r.selection_key, resultFromRow(r));
          if (status === null && t - (r.finished_at || r.kickoff_at) > DATA_TIMEOUT_MS) {
            status = 'VOID';
            reason = 'Verified result data for this market was not available';
          }
        }
        if (status) {
          q(`UPDATE bet_selections SET status = ?, void_reason = ?, settled_at = ? WHERE id = ? AND status = 'OPEN'`).run(status, reason, t, r.sel_id);
          settledSelections++;
        }
      }
    });
  }

  // Settle bets whose outcome is now determined.
  const open = q(`SELECT b.id, b.ref, b.user_id, b.stake, b.type,
      SUM(s.status = 'OPEN') AS open_n, SUM(s.status = 'LOST') AS lost_n, COUNT(*) AS n
    FROM bets b JOIN bet_selections s ON s.bet_id = b.id
    WHERE b.status = 'OPEN' GROUP BY b.id`).all();

  const done = []; // for "bet settled" notifications, sent after the database work
  for (const b of open) {
    if (b.lost_n === 0 && b.open_n > 0) continue; // still waiting on legs
    tx(() => {
      const cur = q('SELECT status FROM bets WHERE id = ?').get(b.id);
      if (cur.status !== 'OPEN') return; // already settled (idempotent)
      if (b.lost_n > 0) {
        // One losing leg loses the whole bet (single or accumulator).
        q(`UPDATE bets SET status = 'LOST', actual_return = 0, settled_at = ? WHERE id = ?`).run(t, b.id);
      } else {
        const sels = q('SELECT status, odds FROM bet_selections WHERE bet_id = ?').all(b.id);
        const winning = sels.filter((s) => s.status === 'WON').map((s) => s.odds);
        if (winning.length === 0) {
          q(`UPDATE bets SET status = 'VOID', actual_return = ?, settled_at = ? WHERE id = ?`).run(b.stake, t, b.id);
          credit(b.user_id, 'BET_VOID_REFUND', b.stake, b.ref, 'Stake returned - bet void');
        } else {
          // Void legs are removed from the accumulator (counted at odds 1.00).
          const ret = potentialReturn(b.stake, winning);
          q(`UPDATE bets SET status = 'WON', actual_return = ?, settled_at = ? WHERE id = ?`).run(ret, t, b.id);
          credit(b.user_id, 'BET_WINNINGS', ret, b.ref, `Winning ${b.type === 'ACCA' ? 'accumulator' : 'single'} return`);
          const legs = q('SELECT COUNT(*) AS n FROM bet_selections WHERE bet_id = ?').get(b.id).n;
          const odds = q('SELECT total_odds FROM bets WHERE id = ?').get(b.id).total_odds;
          award(b.user_id, [{ t: 'sportsWin', legs, odds }]);
        }
      }
      settledBets++;
      const fin = q('SELECT status, actual_return FROM bets WHERE id = ?').get(b.id);
      const first = q('SELECT selection_label FROM bet_selections WHERE bet_id = ? ORDER BY id LIMIT 1').get(b.id);
      done.push({ userId: b.user_id, ref: b.ref, type: b.type, legs: b.n, stake: b.stake, status: fin.status, ret: fin.actual_return, label: first?.selection_label || 'Single' });
    });
  }
  if (done.length) notifySettled(done);
  return { settledSelections, settledBets };
}
