# Moonridge — research notes: what is verified about Wolf Peak

Moonridge is an original game (own name, art, sound and code) that recreates
the gameplay of **Wolf Peak** by King Show Games (released 14 Nov 2023).
No proprietary assets, names or code were used. These notes record what
public sources confirm and what had to be decided.

## Sources

- SlotCatalog – Wolf Peak: https://slotcatalog.com/en/slots/Wolf-Peak
- VegasSlotsOnline – Wolf Peak review: https://www.vegasslotsonline.com/king-show-games/wolf-peak
- MintySlots – Wolf Peak: https://mintyslots.com/king-show-games/wolf-peak/
- e-vegas – Wolf Peak jackpot review: https://www.e-vegas.com/jackpot-slot-review-wolf-peak-by-king-show-games/

## Verified (two or more sources agree, or one detailed source with no conflict)

| Item | Wolf Peak | Moonridge |
|---|---|---|
| Layout | 5 reels × 4 rows | same |
| Lines | 40 fixed lines | same (our own 40 line shapes; the original line shapes are not published) |
| Line pays (x total bet, 3/4/5) | Wild 0.6/1.8/12.5 · Gray wolf 0.3/0.9/5 · Black wolf 0.25/0.6/3.75 · White wolf 0.18/0.5/2.5 · Eagle 0.12/0.3/1.25 · Necklace 0.06/0.25/0.9 · A/K/Q 0.06/0.18/0.6 | identical values |
| Wild | wolf howling at the moon; substitutes for all but bonus/scatter | same |
| Special wilds | 2x, 3x and gold wilds | x2, x3, Gold |
| Delayed Expanding Wild | "The triggering symbol will lock in place and expand to fill the reel over the next three spins" | same: locks, grows one row per spin, fills on the 3rd spin |
| Free spins | 3 bonus symbols anywhere = 20 free spins; more bonus symbols in the feature add spins | 3+ = 20; each bonus in the feature adds 1 |
| Scatter pays | 3/4/5 = 5x / 10x / 25x total bet | same |
| Jackpots | 3+ jackpot symbols on adjacent reels; values 12.5x, 62.5x, 125x, 312.5x, 1,250x | Mini/Minor/Maxi/Major/Grand at exactly those values |
| RTP | 95% (SlotCatalog notes "RTP ranges") | 95% |
| Volatility | High | High is the default profile |
| Max win | 5,666x | 5,666x cap per spin |
| Bonus buy | No | No |

## Not confirmed – our decisions (flagged in the in-game rules too)

1. **Growth pattern.** Sources say it fills the reel "over the next three
   spins". On a 4-row reel that is exactly one row per spin, which we use.
   Which direction it grows is not documented: ours spreads toward the side
   with more room first, then alternates.
2. **When the full column pays.** We count the full column as wild on the spin
   it fills, then remove it (as the brief requires).
3. **Does the plain Wild expand?** Sources say the 2x, 3x and gold wilds
   trigger the feature, so the plain wild only substitutes.
4. **Gold wild.** Its special role is not described; ours expands with no
   multiplier.
5. **Combining multipliers.** Not documented. Ours multiply (x2 and x3 = x6).
6. **Second expanding wild on the same reel.** Not documented. Ours becomes a
   plain wild (one expanding wild per reel at a time).
7. **Bonus vs scatter.** One review lists them separately, another treats them
   as one symbol. Moonridge uses a single Bonus symbol that pays and triggers.
8. **Retrigger size.** "More bonus symbols add spins": ours adds 1 per symbol.
9. **Jackpot symbol details.** "Jackpot sub-symbols on adjacent reels": ours
   are five coloured coins; the same coin on 3+ adjacent reels pays its tier,
   highest only.
10. **Reel strips / weights.** Never published for commercial slots. Ours are
    weighted reel tables, tuned by simulation to 95%.
11. **Autoplay.** One review lists autoplay as unavailable. It was requested
    for this build, so Moonridge has autoplay with a required loss limit (see
    README).

## Wild Expansion State Manager

`server/games/moonridge/wilds.js` — LANDING → LOCKED → EXPANDING →
FULL_COLUMN → DISAPPEARING → REMOVED. Every wild has an id, reel, start row,
stage, occupied rows, remaining rows, sticky flag, progress, completion and
removal flags. Illegal or repeated transitions throw (`WildStateError`); a
wild can only grow once per spin (`lastStep`). Covered by `test/moonridge.test.js`.
