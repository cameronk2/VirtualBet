# Brick by Brick – mechanics and sources

Brick by Brick recreates the gameplay of Light & Wonder's *Huff N' Puff* family with original art, characters, names and sound. Light & Wonder publishes no paytables or odds, so the rules below come from public reviews and guides; every number that isn't published is our own and lives in `server/games/brick/config.js`.

## Sources

- https://www.casinos.com/slots/huff-n-puff
- https://www.royalrivercasino.com/blog/huff-n-puff-slot-machine-how-to-play-win
- https://www.sportsbettingdime.com/online-casino/slots/huff-n-puff/
- https://huffnmore-puff.com/
- https://www.aboutslots.com/casino-slots/huff-n-even-more-puff

## Rules taken from the sources

| Rule | Here |
|---|---|
| 5 reels, 3 rows, 243 ways | Same |
| Wild on reels 2–4, not for hats/saws | Same (Wolf Wild) |
| Pig characters, tools, card ranks | Original Foreman, Carpenter and Painter pigs; toolbox; tape measure; A–9 signs |
| 6+ hard hats → free spins; a frame on each triggering hat | 6 free spins, straw frames |
| Hats in free spins frame/upgrade: straw → stick → brick | Same |
| Hat on a brick upgrades another frame | Same; if none can be upgraded, a new straw frame; if all 15 are brick, 2x prize |
| 3+ hats in one free spin add a spin | +1 spin |
| Wolf blows down straw, then stick, then brick, revealing prizes | Same |
| Stick and brick houses can hold jackpots; brick can hold a wheel spin | Same (wheel only in the Hard Hat Bonus) |
| 3+ buzz saws → one wheel spin | Same, max one saw per reel |
| Wheel: Buzz Saw, Mansions, Mega Hat, Mini–Grand | Same |
| Buzz Saw: saws slide right off the reels, converting what they cross | Each crossed spot gets a hat (frame or upgrade), rightmost saw first |
| Mansions: brick frames where saws landed | Same |
| Mega Hat: one giant hat frames a block | 2×2 (50%), 3×3 (35%), 5×3 (15%) |

## Our own choices (not published)

- Symbol pays (per way, % of bet), reel weights, synchronised stacks (15% per reel), free-spin hat chance (8.0% per cell).
- House prize tables, wheel weights, jackpot sizes (Mini 20x, Mini ×2 40x, Minor 100x, Major 1,000x, Grand 5,000x — fixed, not progressive).
- Free spins show only hats (we couldn't confirm what else lands).
- Max win 5,500x per spin or bonus. RTP about 96% (our own, not a certified figure).

## Not included

Later variants' gold buzz saws, Super features, upgrade wedges, mystery symbols and 6-row grids.

## Flow and safety

Modes `base → wheel → free`, with a queue (wheel before hats when both trigger). Every result — grid, wheel wedge, saw sweep, Mega Hat placement, each free spin and every house prize — is drawn on the server before the screen animates. Each action advances the saved state exactly once, so a refresh resumes at the same point and nothing can be charged or paid twice. Free spins pay only once, at the reveal.
