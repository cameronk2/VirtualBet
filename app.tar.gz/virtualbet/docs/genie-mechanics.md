# Golden Wishes – mechanics and maths

An original Arabian Nights slot (art, names, sound and maths are our own), in the spirit of classic genie-themed jackpot slots.

## Files

| Part | File |
|---|---|
| Configuration (every number) | `server/games/genie/config.js` |
| Reels, wild expansion, 20-line evaluation | `server/games/genie/reels.js` |
| Genie's Treasure (jackpot pick) | `server/games/genie/treasure.js` |
| Game flow, wishes, free spins, validation | `server/games/genie/engine.js` |
| Screen | `client/src/pages/premium/genie/Genie.jsx` (+ `Wish.jsx`, `Treasure.jsx`, `Jackpot.jsx`, `Scene.jsx`) |
| Art (all SVG) | `client/src/components/SlotArtGenie.jsx` |
| Sound (incl. synthesised genie voice) | `genieSfx()` and the `genie` soundtrack in `client/src/lib/sound.js` |
| Tests | `test/genie.test.js` (16 tests) |
| RTP simulation | `scripts/tune-genie.mjs <spins> [seed]` |

## Rules

- 5 reels × 3 rows, 20 fixed lines, left to right from reel 1. Each line pays its single best win; lines add up.
- **Genie** is wild on every reel (not for lamps or stars) and the top-paying symbol. A line starting with genies pays the better of the genie run or the symbol it completes.
- **Wishing Star** (max one per reel, anywhere): 3/4/5 pay 2x/10x/50x the bet and award 10/15/20 free spins.
- **Magic Lamp** (max one per reel, anywhere): 3/4/5 grant one wish, drawn with the spin: instant prize, multiplied prize, free spins or Genie's Treasure. More lamps shift the odds towards the bigger wishes and boost prizes (×1/×2/×4).
- **Free spins**: same bet, all line and star wins ×3, every Genie fills its reel, and the round pays at least 15x the bet (topped up on its last spin). 3+ stars add 5/10/15 spins (max 100 per round). Lamps still grant wishes; free-spin wishes add 8/10/15 spins.
- **Genie's Treasure**: 12 treasures. The jackpot is drawn by `JACKPOT_WEIGHTS` when the bonus starts, and the server deals the board then: three jewels of that jackpot, decoy jewels (never three of another kind), cash prizes and at most one ×2/×3 multiplier, shuffled with the platform RNG. Each pick turns over the next treasure in that order, so the tile tapped never changes the result. The bonus ends on the third matching jewel: (jackpot + cash found) × multiplier.
- **Jackpots**: Mini 15x, Minor 40x, Major 150x, Grand 1,000x the bet. They are fixed multiples, not progressive, and the plaques update when the bet changes.
- Maximum win 10,000x the bet per spin or per free-spins round.

## Measured return (9 million spins, 3 seeds, `PAY_SCALE` 1.95)

Rebalanced on 9 Nov 2026 so the features are worth landing: free spins ×3 with more genies and a 15x guaranteed minimum, wish prizes from 5x, jackpots Mini 15x / Minor 40x / Major 150x / Grand 1,000x; line pays lowered to keep the total at 96%.

| | |
|---|---|
| Total RTP | **96.3%** (95.64 / 96.41 / 96.91) |
| Lines | 42.5 |
| Free spins | 28.2 (about 1 in 182 spins, averaging 40x, never under 15x) |
| Wish prizes | 12.1 (a wish about 1 in 83; cash and multiplied wishes average about 14x, at least 5x) |
| Genie's Treasure | 12.2 (about 1 in 750, averaging about 90x) |
| Star pays | 1.3 |
| Hit rate | 23.3% (any win) |
| Largest single result seen | about 3,050x |

## Tuning

- **RTP**: change `PAY_SCALE` (scales line pays, which also drive free spins), then run `node scripts/tune-genie.mjs 3000000` with a few seeds.
- **Volatility**: raise `LAMP`/`STAR` weights or `JACKPOT_WEIGHTS.GRAND` and lower `PAY_SCALE` for a more volatile game (and the reverse for a calmer one).
- **Jackpot odds**: `JACKPOT_WEIGHTS` (per treasure) and the `TREASURE` share in `WISH_TYPES` (per wish).

## Fairness and safety

- Server-authoritative: every result is drawn with the platform crypto RNG inside the engine; the client only animates it. Outcomes never read the balance, history or session.
- Stakes are validated (integer pence, £0.10–£100, and covered by the balance in `server/casino.js`). Free spins and picks take no stake.
- Every action advances the saved state once (spin → free/treasure, pick → next tile), so repeat taps, double taps on a tile and reloads can't pay twice. Picks are validated (integer 0–11, not already opened, treasure in play).
- Auto-spin needs a spin count and a loss limit, and stops on every feature, on an optional big win, when the balance runs short, or on Stop.
- `#dev` (or `localStorage.vb_dev = 1`) shows practice triggers for every wish, free spins and each jackpot. Practice rounds cost and pay nothing and are labelled on screen.
