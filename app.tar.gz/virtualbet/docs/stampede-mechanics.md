# Stampede Link – mechanics and sources

Stampede Link recreates the gameplay of Aristocrat's *Buffalo Link* (2021, MarsX cabinet), with the Golden Buffalo collection from *Buffalo Gold*. Art, names and sound are original. Aristocrat publishes no paytables or odds, so every value that isn't published is our own and lives in `server/games/stampede/config.js`.

## Sources

- https://www.casinos.com/slots/buffalo-link
- https://www.intergameonline.com/casino/news/aristocrat-gaming-launches-buffalo-link
- https://www.bonus.com/aristocrat-launches-buffalo-link-slot

## Rules taken from the sources

| Rule | Here |
|---|---|
| 5×4 grid, 1,024 ways | Same |
| Buffalo top symbol; eagle, cougar, wolf, elk, royals | Same (original art) |
| Wild with 2x / 3x multipliers on reel 5 | Wild on reels 2–5; reel-5 wilds always ×2 (65%) or ×3 (35%) |
| Free games: 3/4/5 gold coins = 8/15/20; 2 retrigger | Same; 2/3/4/5 coins add 5/8/15/20 (cap 100 games) |
| Free games: multiplying wilds | Every wild ×2 or ×3; a way multiplies all its wilds together |
| Hold & Spin: buffalo cash symbols with credit values or jackpots | Same |
| Hold & Spin trigger: 8 cash symbols (one review; Link family uses 6) | **8**, chosen by the owner |
| 3 respins, a new symbol resets to 3 | Same |
| Mini / Minor / Major on coins; Grand for all 20 | Same; fixed (not progressive) multiples of the bet |
| Hold & Spin can trigger in free games | Same; the free games resume afterwards |
| Golden Buffalo (Buffalo Gold): collected heads turn animals into buffalo | Collected for the whole free-games feature: 3 → wolves, 6 → elk, 9 → cougars, 12 → eagles |

## Our own choices (not published)

- Symbol pays, reel weights, synchronised stacks (12% per reel), scatter pays (2x/10x/50x).
- Cash values 0.5x–20x, jackpot chances, jackpot sizes (Mini 10x, Minor 25x, Major 150x, Grand 2,000x).
- Hold & Spin landing chance per empty cell per respin (5%).
- **Stampede coins** (×2 / ×3, Hold & Spin only) that multiply every locked credit coin. The brief asked for multiplier coins; Buffalo Link has none, so this is ours.
- "Linked buffalo": the link mechanic is the real ways evaluation (chosen by the owner). Each winning chain is drawn connecting every matching symbol on adjacent reels.
- Max win 5,000x per spin or feature. RTP about 96% (our own).

## Not included

- Linked/progressive jackpots across machines.
- The **must-hit-by mystery meter** (a counter that climbs toward a guaranteed bonus). It is a "keep spinning, it's about to hit" incentive, which the site's rules exclude.

## Flow and safety

Modes `base → hold / free`, with a queue (Hold & Spin before free games when both trigger). Every result — grid, each respin's landings, multiplier boosts — is drawn on the server before the screen animates. Each action advances the saved state exactly once, so a refresh resumes at the same point and nothing can be charged or paid twice. Hold & Spin pays once, when it ends.
