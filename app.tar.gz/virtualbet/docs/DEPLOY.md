# Putting VirtualBet online as its own app

The Claude artifact is a preview. To give people a normal link (and an icon on
their phone) with no Claude sign-in, run the Node server on a web host. Players
then create VirtualBet accounts on your site; balances and bets are stored in
your own database.

## Option 1: Render (easiest, about 10 minutes)

1. Put this folder in a GitHub repository (github.com > New repository > upload
   the files, or `git push`).
2. On render.com: sign up, then **New > Blueprint**, pick the repository.
   Render reads `render.yaml`: it builds the Docker image, adds a 1 GB disk for
   the database and serves the app over HTTPS at `https://virtualbet-xxxx.onrender.com`.
3. Optional, real fixtures and live scores: get a free key at
   football-data.org, then in the service's **Environment** tab add
   `FOOTBALL_DATA_KEY` with the key and save. The app switches from demo
   matches to real data by itself (an `API_FOOTBALL_KEY` from api-football.com
   works the same way). Keys only ever live in environment variables, never
   in the code.
4. Optional: **Settings > Custom Domains** to use your own domain.

The plan in `render.yaml` is `starter` because a persistent disk needs a paid
instance. Without a disk (free plan) the app works but everyone's accounts are
wiped whenever the server restarts.

## Option 2: Fly.io

    fly launch --copy-config --no-deploy
    fly volumes create data --size 1
    fly deploy

## Option 3: any server with Docker

    docker build -t virtualbet .
    docker run -d -p 80:3000 -v virtualbet-data:/app/data virtualbet

Put it behind HTTPS (Caddy, nginx or the host's load balancer). Keep
`COOKIE_SECURE=true` when serving over HTTPS; set it to `false` only for plain
`http://` testing.

## Installing it like an app

The hosted site is a Progressive Web App:

- **iPhone (Safari):** Share > Add to Home Screen.
- **Android (Chrome):** menu > Install app (or Add to Home screen).

It then opens full screen from its own icon, with no browser bars.

## Before sharing publicly

VirtualBet uses virtual money only and has no payments, but it is still a
gambling-style product. Check the rules where you and your players live (for
example age gating and how simulated gambling apps can be advertised), and
keep the "virtual play only" messaging visible.

## Bet-result notifications

Players can turn on **Account > Notifications > Bet results** to get a
notification when a bet wins, loses or is made void. On iPhone this needs
iOS 16.4 or later and the app added to the Home Screen (Apple only allows web
notifications for installed apps). No setup is needed on the server: its
signing keys are created on first start and kept in the database.
Optionally set `VAPID_SUBJECT` to `mailto:you@yourdomain` so push services
can contact you.
