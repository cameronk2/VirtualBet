# Mystery of the Mummy — research notes: what is known about Mo' Mummy

Mystery of the Mummy is an original game (own name, art, sound and code)
built on the published rules of Aristocrat's **Mo' Mummy** (land-based 2023,
online "Mighty Pyramid" / "Valley of Riches" versions 2025). No proprietary
assets or code were used.

## Important finding

The brief asked for persistent wilds that expand over several spins. No
source describes that in Mo' Mummy: its wild substitutes and can trigger the
jackpot pick. The thing that grows over several spins is the **Mummy zone in
Cash Collect** (2x2 → 3x3 → 4x4 → 5x5). The game was built on the real rules
(confirmed with the owner before building).

## Sources

- SlotCatalog – Mo Mummy: Mighty Pyramid: https://slotcatalog.com/en/slots/mo-mummy-mighty-pyramid
- SweepsKings – Mo Mummy review: https://sweepskings.com/sweepstakes-casinos/slots/mo-mummy/
- Casinos.com – Mo Mummy: https://www.casinos.com/slots/mo-mummy
- BetMGM – Mo' Mummy Valley of Riches: https://casino.betmgm.com/en/blog/money-slots/mo-mummy-valley-of-riches/

## Verified and implemented

| Rule | Source(s) | Here |
|---|---|---|
| 5 reels × 3 rows, 20 fixed lines, 3+ from reel 1 | SlotCatalog, SweepsKings, BetMGM | same |
| Wild substitutes; 5 wilds 4x bet; premiums (Pharaoh, Book, Ankh, Eye of Horus, Anubis) up to 3x; A/K/Q/J 2x | SlotCatalog | same 5-of-a-kind values |
| 3/4/5 Free Games scatters = 6 free games; retriggers possible; can also start at random | SlotCatalog, BetMGM, Casinos.com, SweepsKings | same |
| Free Games remove A/K/Q/J | SlotCatalog, SweepsKings | same |
| Mummy on reel 1 + green gem = Cash Collect; a gem alone can start it at random | SlotCatalog, SweepsKings | same |
| Cash Collect: 5 respins; 2x2 Mummy zone; gems collected anywhere, coins only in the zone; power-ups 3x3 (+3), 4x4 (+2), 5x5 (+1); paid at the end; values 1x–1,000x; Mini 20x and Minor 60x appear as values | SweepsKings, SlotCatalog | same |
| Wild landing can trigger the jackpot pick; first jackpot revealed 3 times wins; 15 covered tiles | SlotCatalog, SweepsKings | same |
| Online fixed jackpots Mini 20x, Minor 60x, Maxi 100x, Major 200x, Grand 2,000x | SlotCatalog | same |
| Max win 2,118x | SlotCatalog | cap per spin / per feature |

## Not published – our values

1. 3- and 4-of-a-kind pays (5-of-a-kind values are the published ones).
2. Free Games scatter pays (3/4/5 = 2x/5x/20x here).
3. Spins added by a retrigger (6 here) and whether 4/5 scatters give more (no).
4. Gems needed for each power-up: now 5 / 9 / 12 cumulative, as specified by the owner's Cash Collect brief (8 Nov 2026).
5. How the Mummy moves: here it starts bottom-left and each bonus spin takes one step (any direction, including diagonal) toward the nearest uncollected green gem; with none waiting it patrols the grid. Cash prizes pay only if they land under it; green gems wait where they land until it reaches them (owner's brief: the Mummy collects what lands in its area; uncollected prizes are never paid).
6. Board shape during Cash Collect (sources say "a row is added" and "5x5"; here the 5x3 reels grow to 5x5).
7. Whether Cash Collect and jackpots can trigger inside Free Games (yes here).
8. "Feature tokens build up" / collection pots: described vaguely; here the random
   triggers are a plain fixed chance per symbol, with no meter that fills
   (a filling meter would push players to keep spinning).
9. Reel weights, stacks, and RTP. Sources give 94.09% and 95.06%. Ours is
   tuned to about 95% by simulation and is not the original's certified maths.
10. Multipliers: none are described for Mo' Mummy, so none were added.
11. Autoplay: not added for paid spins (site policy); Free Games and
    Cash Collect respins play automatically.
