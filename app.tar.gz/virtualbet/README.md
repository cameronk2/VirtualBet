# VirtualBet ⚽

**VIRTUAL PLAY ONLY – NO REAL MONEY INVOLVED**

A sportsbook-style football betting **simulator**. Every account starts with a free virtual balance of £100. All £ amounts are virtual: free, with no real value, and they can never be bought, withdrawn, transferred or exchanged. Amounts are shown in pounds so you can practise with realistic stakes (free virtual deposits of any whole-pound amount from £5 to £1,000 (slider in £5 steps, −/+ buttons for £1, quick picks £10–£1,000; validated on the server); sports and slot stakes from £0.10 to £500, and no maximum on the table games (Blackjack, Spin 21, Roulette, Baccarat, Three Card Poker), where your balance and your own daily limit are the only caps; a free £5 daily bonus). Internally every amount is an integer number of pence. There is no payment code of any kind in this project.

- **Frontend:** React 19 + Tailwind CSS v4 (bundled with esbuild)
- **Backend:** Node.js (built-in `http`, no framework)
- **Database:** SQLite via Node's built-in `node:sqlite` - no database server to install
- **Auth:** username + password (scrypt hashing), HTTP-only session cookies
- **Runtime dependencies:** none. The four dev dependencies are only for building the frontend.

---


**Hosting it as a real app:** see [docs/DEPLOY.md](docs/DEPLOY.md) (Render blueprint, Fly.io config and Dockerfile included; installs to the home screen as a PWA).

## 1. Launch the app

Requirements: **Node.js 22.13 or newer** (Node 24 LTS recommended). Check with `node -v`.

```bash
cd virtualbet
npm install          # installs react, react-dom, tailwindcss, esbuild (build tools only)
npm run build        # builds the frontend into dist/
npm start            # starts the server
```

Open **http://localhost:3000**, click **Join**, and you'll receive 10,000 free tokens.

With no API key configured the app runs in **demo mode**: clearly labelled *simulated* matches across 11 competitions, kicking off every 5 minutes and playing out in accelerated time (1 match minute = 8 seconds by default), so you always have live in-play matches to bet on.

Other commands:

| Command | What it does |
|---|---|
| `npm run dev` | Rebuilds the frontend on change and restarts the server on change |
| `npm test` | Runs odds/settlement maths tests and a full place→settle integration test |
| `npm run db:reset` | Deletes the database (a fresh one is created on next start) |

### Phone / single-file version

`node build-artifact.mjs` builds `dist-standalone/virtualbet.html`, a version that runs entirely in the browser with no server. It always uses simulated matches (the schedule is derived from the clock, so bets settle correctly even if you close the app), and uses the same odds, settlement and token maths as the full app. This is the version published as a Claude artifact for opening on iPhone.

## 2. Create the database

Nothing to do - the SQLite file is created automatically at `./data/virtualbet.db` (configurable with `DATABASE_PATH`) on first start, with all tables and indexes. To start again from scratch, stop the server and run `npm run db:reset`.

Tables: `users`, `sessions`, `wallet_tx` (immutable ledger with before/after balances), `matches`, `bets`, `bet_selections`, `placements` (duplicate-submission protection), `demo_leaders`.

## 3. Configure live football data

Copy the sample config and edit it:

```bash
cp .env.example .env
```

### Option A - API-Football (recommended: covers every requested competition)

1. Sign up at https://dashboard.api-football.com and copy your API key.
2. In `.env`:
   ```
   FOOTBALL_API_PROVIDER=api-football
   API_FOOTBALL_KEY=your_key_here
   ```
3. Restart (`npm start`).

Covers Premier League, Championship, League One, League Two, Scottish Premiership, Champions League, Europa League, Conference League, La Liga, Serie A, Bundesliga, Ligue 1, FA Cup, EFL Cup, Eredivisie and Primeira Liga (edit `API_FOOTBALL_LEAGUES` to change). Provides live minute, goal events, cards and post-match corner statistics, so every market can be settled.

**Request budget:** the free tier allows 100 requests/day. Live polling only runs while a tracked match is in play, but for the free tier set `LIVE_POLL_SECONDS=900` and `FIXTURES_POLL_MINUTES=180`. Paid tiers can use the defaults (60s / 30 min).

### Option B - football-data.org

1. Register at https://www.football-data.org/client/register.
2. In `.env`:
   ```
   FOOTBALL_API_PROVIDER=football-data
   FOOTBALL_DATA_KEY=your_key_here
   ```

The free tier covers PL, Championship, Champions League, La Liga, Serie A, Bundesliga, Ligue 1, Eredivisie and Primeira Liga - **not** League One, League Two, the Scottish Premiership or the Europa League. It gives scores only (no goal events, corners or cards), so VirtualBet automatically hides the markets it couldn't settle (first/last team to score, next goal, corners, cards). If the provider omits the live minute, it is estimated from kick-off time and shown as "(est.)".

### Running real and demo matches together

Set `ENABLE_DEMO_MATCHES=true` alongside a provider. Real matches are badged "Live data · provider"; demo matches are badged "Simulated".

## How the important parts work

**Odds are always simulated.** Neither provider's included tier supplies bookmaker odds, so VirtualBet prices every market with its own Poisson goal model (team strength → expected goals, with a 4–18% bookmaker-style margin depending on the market). In-play, the model reprices from the current score and minute every few seconds. Odds are labelled as simulated everywhere they appear and are never presented as bookmaker prices.

**Scores are never invented.** For real matches, scores, minutes and statuses come only from the provider. In demo mode each match's events are generated when the fixture is created and revealed minute by minute; future events are never sent to the browser and the odds engine never sees them.

**Settlement** runs every 3 seconds on the server:
- Only matches the provider reports as finished with a full-time score (`result_verified = 1`) are settled. Markets settle on the 90-minute result.
- If data a market needs (e.g. corners) isn't available, that selection waits; after 48 hours without verified data it is voided and the stake returned.
- Abandoned/cancelled matches void their selections; postponed matches void after 72 hours.
- Accumulators: one losing leg loses the bet; void legs are removed and the return recalculated from the remaining odds; all-void returns the stake.
- Settlement is idempotent and every payout is written to the wallet ledger.

**Token accounting** is integer-only (odds stored ×100, returns computed with BigInt and rounded down to whole tokens). The browser never decides a balance: stakes, odds, limits and balances are all re-checked server-side inside a single SQLite transaction. Each bet submission carries an idempotency key, so double-clicks or retries can't place a bet twice.

## Completed features

- Sportsbook UI: dark navy/green theme, responsive desktop/tablet/mobile layout, competition sidebar, sticky bet slip (bottom sheet on mobile), odds-movement flashes, permanent "virtual play only" banner
- Accounts: register, log in, log out, profile, change username; each account has its own wallet and bet history
- Virtual wallet: 10,000 welcome tokens, free Deposit window (1k/5k/10k/25k/50k) with confirmation and "no monetary value" acknowledgement, free 500-token daily bonus every 24h, full transaction history (date, type, amount, previous and new balance)
- Dashboard: balance, live matches, featured matches, popular markets, upcoming fixtures, personal stats, recently settled bets
- Live Football and Upcoming pages with competition filters, auto-refreshing scores and minutes
- Match page with 18 market types: Full Time Result, Double Chance, Draw No Bet, BTTS, Over/Under 0.5/1.5/2.5/3.5, Half Time Result, HT/FT, Correct Score, home/away team goals, First/Last Team to Score, Next Goal (in-play), Total Corners, Total Cards
- In-play betting: odds reprice with score and clock, decided markets are withdrawn, markets suspend briefly after goals (and when the live feed is stale or the match is suspended), and close at full time
- Bet slip: singles, accumulators (combined odds), per-bet stakes, quick stakes, potential return/profit, odds-change detection with "accept changes", min 10 / max 5,000 per bet, balance check, unique bet references, duplicate-submission protection, receipt
- Automatic settlement (won/lost/void, void legs in accas)
- My Bets (Open / Settled / All, colour-coded, click for full details) and Bet History table with filters
- **Cash Out** on open bets: value = stake × odds taken ÷ current odds of unsettled legs × 95%, capped below the potential return. It's only offered while every open leg can still be priced, so real fixtures close for Cash Out at kick-off and simulated matches can be cashed out in-play. Two-tap confirm; if the value moves, the server rejects the request and shows the new value
- Fixture search (team or competition) on the Fixtures page
- Statistics: totals, win %, staked/returned, P/L, best win, biggest loss, average odds, most profitable market; charts for P/L over time, won vs lost, and performance by market
- Leaderboard (real users + labelled demo players, no prizes)
- Play safely: **Take a break** (24 hours, 3 days, 1 week or 30 days; blocks every bet and casino stake on the server, can't be ended early), daily stake limit (decreases apply immediately, increases after 24h cooling-off), optional reality-check reminders, session timer, session/today/all-time P/L tracker, wallet reset, links to UK support services
- No real-money payments, withdrawals, purchases, prizes or transfers anywhere

### Casino (virtual money, all outcomes decided server-side)

| Game | Type | Long-run return |
| --- | --- | --- |
| Blackjack | Up to 3 hands, splits, doubles, Perfect Pairs and 21+3 side bets, strategy hint | ~99.5% main game |
| Spin 21 | Blackjack with a matched Spin bet; blackjack triggers a bonus wheel (MINI/MAJOR/GRAND) | ~96% Spin bet |
| Roulette | European single zero, full board, racetrack call bets, hot/cold numbers | 97.3% |
| Baccarat | Punto banco with pair bets and bead road | 98.9% (Banker) |
| Three Card Poker | Ante/Play and Pair Plus | ~97% |
| Lakeside Lures | 5×3 slot, 10 lines, fish worth 2x–500x collected by the wild, free spins with rising multiplier | ~96% |
| Nebula Clusters | 6×6 cluster pays, cascades, rising multiplier free spins | ~96% |
| Coin Vault | 10 lines, Hold & Spin with four fixed jackpots | ~96% |
| Fruit Shack | Classic 3-reel fruit machine with holds and nudges | ~96% (good play) |
| Starlight Observatory | Free spins with a randomly chosen expanding symbol | ~96% |
| Crash | Rising multiplier, manual or auto cash-out | 97% |
| Plinko | 12 rows, three risk levels | ~97% |
| Scratchcards | Match three, £1/£2/£5 tickets | ~68% |

Payout tables were tuned by Monte Carlo simulation and every game shows its rules and return. Slot returns were re-verified in November 2026 with `Math.random` over 1.4–4.2 million spins per game (Lakeside 95.8%, Coin Vault 95.7%, Fruit Shack 96.2%, Starlight ~96.2%, Nebula ~96%); expect about ±0.5% statistical uncertainty. An earlier tuning pass used a weak seeded generator that overstated Nebula and Starlight by 1–2 points, now corrected.

Lakeside Lures was rebalanced at the same time: line wins pay 10x more than before (three low symbols return half the stake), fish values were lowered and capped at 500x (was 2,000x), and the total stays at 96%.

**Honest results:** on every slot, a spin that returns less than it cost is shown as "Returned £x of £y" with the net loss, with no win colours, sound or vibration. Only returns above the stake (or any free-spin win) are shown as wins.

### Premium slots (November 2026)

Six original premium slots, each with its own engine (`server/games/slots3.js`), screen (`client/src/pages/premium/`), symbol art (`client/src/components/SlotArt3.jsx` and `SlotArtFrost.jsx`, inline SVG) and synthesised sound theme (`client/src/lib/sound.js`). They share `client/src/components/Premium.jsx` (reels, win tiers, big-win overlay, particles, sound menu, info panel, spin bar) and run through the same casino handler as every other game, so they use the existing balance, daily limit, Take a break, history, badges and lifetime totals.

| Game | Grid | Mechanics |
| --- | --- | --- |
| Atlantis – Kingdom of the Deep | 5×3, 20 lines | Atlantis Wild; 3+ chests open Hidden Treasure (pick until COLLECT; 3 tridents = Poseidon's Jackpot, fixed 500x; may award free spins); free spins where every wild raises the multiplier (max x10) |
| Neon Overdrive | 5×4, 1,024 ways | Cyber Wild; multiplier chips (x2–x25) add up and multiply the spin's win; 3+ OVERDRIVE = bonus round whose meter only grows within that round |
| Dragon's Fortune – The Golden Empire | 5×3, 25 lines | Dragon Wild breathes fire and fills its reel; Golden Fortune multiplier (x2–x8) on 14% of wins; 3 lanterns = Lucky Lantern ladder (2x–1,000x, 50% per step); Dragon's Treasure free spins with sticky dragons |
| Cosmic Collapse | 6×5, pays anywhere 8+ | Tumbles; gravity orbs (x2–x25) multiply the tumble; Meteor Shower wilds (4% of spins); Black Hole free spins that transform a low symbol into a higher one, with a round gravity multiplier up to x100 |
| Pharaoh's Gold – Secrets of Egypt | 5×3, 10 lines + multiplier reel | Pharaoh Wild doubles wins; Ancient Multiplier reel (x1–x10) on every spin; Pyramid mystery stacks; Golden Scarab free spins where scarabs add spins and raise the multiplier reel's minimum |
| Frostfang – Howl of the Northern Lights | 5×4, 40 lines | Frostfang Wilds (reels 2–5) expand to fill their reel with a x2–x10 multiplier; line wins through wild reels multiply by the sum of their multipliers; every new wild adds +1 to the wilds already standing (max x25). Howl Respins: wild reels stay put while the others respin free, for as long as new wilds land. Full Moon free spins: wilds stay for the whole round and keep growing. |

**Maths.** Every game targets a 96% return and caps a single spin at 5,000x. Each paytable is scaled by one constant (`AT_S`, `NE_S`, `DR_S`, `CO_S`, `PH_S`). The constants were solved with common-random-number simulations (same seed at two scales, so the return splits into a part that scales with the paytable and a fixed part). The rare fixed prizes (Poseidon's 500x jackpot, the 1,000x lantern step) were then counted at their exact expected value rather than sampled: jackpot 2.08 points, lantern ladder 7.48 points. Results were then re-checked with fresh `Math.random` runs: Atlantis 96.0% (1.2M spins), Neon Overdrive 95.9% (400k), Dragon's Fortune 96.1% (600k), Cosmic Collapse 95.8% (700k), Pharaoh's Gold 95.8% (400k). Expect roughly ±0.5–1 point of statistical uncertainty on the heavier-tailed games. Frostfang's sticky, growing multipliers make plain random runs too noisy (±3 points even over a million spins), so its return is measured as base game plus free-spin trigger rate × average Full Moon round, from 3M base spins and 220k simulated rounds: base game 85.3 + Full Moon 10.7 = 96.0% (about ±0.6 points); Full Moon triggers about 1 in 205 spins, Howl Respins about 1 in 8.

**Fairness.** Outcomes come only from the crypto RNG in the backend (server: `crypto.randomInt`; phone build: `crypto.getRandomValues`) before any animation plays. Treasure chests are sealed when the bonus triggers and their contents never reach the browser until opened. The shared `useGame` hook refuses a second request while one is in flight, the engines reject spins during an open treasure bonus and double picks, and the handler checks the balance before charging. Tests: `test/premium.test.js`.

**Deliberate limits.** Auto-play is offered for free spins only, not paid spins, in line with UK rules on online slots and the project's no-pressure design. Neon's "progressive" multiplier only builds within an Overdrive round and never carries over between paid spins, so there's nothing to chase. No new dependencies.
- **Badges**: 19 achievements for learning the games and playing safely. Badge-only: no prizes, streaks or daily targets.
- **"Real-money check"** (Account › Real-money check, and on Home): lifetime staked vs returned per game, and what you'd be up or down if it had been real money.
- The daily stake limit covers sports and every casino game.

### Moonridge (Wolf Peak-style mechanics)

An original game (own name, art, sound and code) that recreates the gameplay of King Show Games' *Wolf Peak*: 5×4, 40 lines, the published line and scatter pays, 20 free spins, five fixed jackpots (12.5x–1,250x) and a 5,666x maximum win. Research notes, including which rules could not be confirmed and what was chosen instead, are in `docs/moonridge-mechanics.md`.

- **Delayed Expanding Wilds**: x2, x3 and Gold wilds lock where they land, grow one row at the start of each spin, fill the reel on the 3rd spin after landing, count as a full wild reel for that spin, then disappear. Several can be active at once (one per reel), each tracked separately. They persist between sessions and carry into and out of free spins.
- **Code**: `server/games/moonridge/` — `config.js` (layout, paytable, features, reel weights, volatility profiles), `wilds.js` (the Wild Expansion State Manager), `engine.js` (pure maths: draws only unlocked cells, evaluates lines, scatter and jackpots), `index.js` (casino contract). Screen: `client/src/pages/premium/Moonridge.jsx`, art in `client/src/components/SlotArtMoon.jsx`.
- **Maths**: three profiles (`high` default, `medium`, `low`; pick with the `MOONRIDGE_PROFILE` env var). The paytable is never scaled. Each profile solves two knobs (how often expanding wilds land in the base game and in free spins) with `node scripts/tune-moonridge.mjs`, which also has a reproducible seeded `full` mode. High profile: 95.3–95.8% across 12M simulated spins while tuning, final scale set for 95% (lines ~64, free spins ~26, scatter ~2.8, jackpots ~1.9 points); wins on ~51% of spins (many below the bet); free spins ~1 in 185; ~9 expanding wilds per 100 spins. Expect about ±1 point of noise because big multiplied wins are rare.
- **Autoplay**: only on this game, because it was explicitly requested. It needs a spin count and a loss limit. It stops on any free-spins trigger, on an optional big single win, when you leave the tab, or when the balance can't cover the bet. Daily limits and breaks still apply on the server.
- **Tests**: `test/moonridge.test.js` covers single and multiple wild cycles, locked cells never being redrawn, illegal transitions, every paytable entry, multipliers, free spins, jackpots, the cap and 6,000 real API spins.

### Mystery of the Mummy (Mo' Mummy rules)

An original Egyptian game built on the published rules of Aristocrat's *Mo' Mummy*: 5×3, 20 lines, Free Games (6 games, A/K/Q/J removed, retriggers), Cash Collect (Mummy on reel 1 + a green gem; separate 5×5 grid; 5 bonus spins; the Mummy walks toward green gems and collects everything under it; 5 / 9 / 12 gems grow it to 3×3 / 4×4 / 5×5 with +3 / +2 / +1 spins; cash prizes 1x–1,000x pay only if collected; state machine READY → SPINNING → COMPLETE in `cash.js`) and a wild-triggered jackpot pick (Mini 20x to Grand 2,000x). Max win 2,118x. Sources, and every rule that had to be decided, are in `docs/mummy-mechanics.md`. Note: Mo' Mummy has no persistent expanding wilds; its growing mechanic is the Cash Collect Mummy.

- **Code**: `server/games/mummy/` — `config.js` (every tunable number: paytable, weights, stacks, feature chances, jackpots, max win), `reels.js` (reel engine), `evaluate.js` (lines and scatter), `cash.js` (Cash Collect), `jackpot.js` (pick), `engine.js` (game flow and feature queue), `index.js`. Screen: `client/src/pages/premium/mummy/` (`Mummy.jsx`, `Scene.jsx`, `CashCollect.jsx`, `JackpotPick.jsx`); art in `client/src/components/SlotArtMummy.jsx`; sounds `mummySfx()` in `lib/sound.js`.
- **Fairness**: every result (including the whole jackpot reveal order) is decided on the server before anything animates; the tile you tap only shows the next symbol. Each action moves the saved state forward once, so a refresh resumes the feature exactly and nothing can be charged or paid twice.
- **Maths**: about 95% (3M simulated spins: 95.5–96.1% before the final small adjustment). Lines ~28, Cash Collect ~60, jackpots ~3.7, Free Games ~3.5, relic pays ~0.6 points. Cash Collect about 1 in 81 spins, Free Games 1 in 185, jackpot pick 1 in 1,370. Reproduce with `node scripts/tune-mummy.mjs <spins> <seed>`.
- **Test mode**: add `#dev` to the page URL (or set `localStorage.vb_dev = '1'`) to show buttons that start Free Games, Cash Collect or any jackpot as a *practice* round, which costs nothing and pays nothing (enforced on the server). Hidden from normal players.
- **Tests**: `test/mummy.test.js` (15 tests: losing spins, every paytable entry, wild substitution, free games and retriggers, low symbols removed, Cash Collect triggers, coins vs gems, power-ups, single payout, jackpot fairness, feature queueing, practice mode, 20,000-spin money check, stake limits).

### Polar Catch (fishing wheel game)

An original Arctic fishing wheel game in the style of fishing-wheel game shows (no live presenter; server RNG). 53 segments: Blue Flake ×23, White Flake ×23, Frost Minnows ×4, Amber Salmon ×2, Ruby Kings ×1. Flakes pay 1:1, or up to 10:1 when a pre-spin multiplier (x3–x10) lights their segment. Fish segments start a fishing round: one catch (3–100x / 4–200x / 10–500x) times that bonus's pre-spin multiplier (x2–x10), capped at 999:1 / 1,999:1 / 4,999:1. "All Bonuses" bets all three fish spots. Round cap 5,000x the stake. Returns are exact, not simulated: flakes 97.10%, Minnows 95.69%, Salmon 95.60%, Kings 95.17% (`server/games/polarcatch/maths.js`; tune with `node scripts/tune-polarcatch.mjs`). Code: `server/games/polarcatch/`, screen `client/src/pages/premium/polarcatch/`, art `components/SlotArtPolar.jsx`, tests `test/polarcatch.test.js`.

### Brick by Brick (Huff N' Puff-style)

An original house-building slot built on the published rules of Light & Wonder's *Huff N' Puff* family (mainly *Huff N' More Puff* / *Huff N' Even More Puff*): 5×3, 243 ways, Wolf Wild on reels 2–4. Two separate features:

- **Hard Hat Bonus**: 6+ hard hats anywhere → 6 free spins; each triggering hat leaves a straw frame. Only hats land in free spins: empty spot → straw frame, frame → upgrade (straw → stick → brick); a hat on a brick upgrades another frame. 3+ hats in one spin = +1 spin. At the end the wolf blows the houses down, straw then stick then brick, revealing prizes (straw 0.5–2x, stick 2–8x or Mini/Mini×2/Minor, brick 10–250x, jackpots up to Grand, or a wheel spin).
- **Buzz Saw Wheel**: 3+ buzz saws (max one per reel) → one wheel spin (the player taps Spin; the wedge is fixed on the server when the saws land): **Buzz Saw** (saws slide right to the edge, framing/upgrading every spot), **Mansions** (brick frame on every saw spot), **Mega Hat** (2×2 / 3×3 / 5×3 hat of straw frames) — each followed by 6 free spins and the reveal — or a Mini 20x / Minor 100x / Major 1,000x / Grand 5,000x jackpot. If both trigger, the wheel plays first.

- **Code**: `server/games/brick/` — `config.js` (paytable, weights, stacks, house prize tables, wheel weights, Mega Hat sizes, max win 5,500x), `reels.js` (reels and 243-ways evaluation), `features.js` (hats, saw sweep, mansions, Mega Hat, reveal, wheel), `engine.js` (modes base / wheel / free, feature queue, practice mode). Screen: `client/src/pages/premium/brick/` (`Brick.jsx`, `Wheel.jsx`, `Scene.jsx`); art `components/SlotArtBrick.jsx` (original pigs, wolf, hat, saw, houses); sounds `brickSfx()` in `lib/sound.js` (separate intro stings for the hat bonus — marimba and whistle with hammer taps — and the saw features — revving saw and synth riff).
- **Character**: the wolf reacts to spins, small wins, big wins, hat triggers, saw triggers, each free spin and each stage of the reveal (huffs, speech bubbles, shocked/sad/happy faces).
- **Maths**: about 96% (`node scripts/tune-brick.mjs <spins> <seed>`; the script also reports a variance-reduced figure that replaces jackpot draws with their expected value: 95.6–96.8% across 4 × 600k spins, mean 96.4%). Base game ~39 points, Hard Hat Bonus ~23, wheel features ~29, wheel jackpots ~5. Hard Hat Bonus about 1 in 210 spins, wheel about 1 in 255. Sources and every value we had to choose: `docs/brick-mechanics.md`.
- **Test mode**: `#dev` or `localStorage.vb_dev = '1'` shows practice buttons for 6 hats, 3 saws and every wheel wedge (costs and pays nothing; enforced on the server).
- **Tests**: `test/brick.test.js` (11 tests: ways and wilds, forced six hats, every hat stage, the wolf's reveal, forced three saws, every wedge, sweep order, brick wheel tokens, practice and refresh safety, 15,000 API spins money check).

### Stampede Link (Buffalo Link-style)

An original western slot built on the published rules of Aristocrat's *Buffalo Link*: 5×4, 1,024 ways, Buffalo Wild on reels 2–5 (reel-5 wilds ×2/×3), free games (3/4/5 gold coins = 8/15/20, 2+ retrigger, every wild ×2/×3 and multiplying), the Golden Buffalo collection from *Buffalo Gold* (3/6/9/12 heads turn wolves, elk, cougars, eagles into buffalo) and **Hold & Spin**: 8+ buffalo cash lock on a separate 5×4 grid, 3 respins that reset to 3 whenever a buffalo lands, credit values 0.5x–20x, Mini 10x / Minor 25x / Major 150x coins, stampede ×2/×3 coins that multiply every locked credit, and the Grand (2,000x) for filling all 20 spots. Winning ways are drawn as linked chains across the reels.

- **Code**: `server/games/stampede/` — `config.js` (every number), `reels.js` (reels, 1,024 ways with multiplying wilds), `hold.js` (Hold & Spin), `engine.js` (modes base / hold / free, queue, practice). Screen: `client/src/pages/premium/stampede/` (`Stampede.jsx`, `HoldSpin.jsx`, `Scene.jsx`); art `components/SlotArtStampede.jsx`; sounds `stampedeSfx()` in `lib/sound.js` (western whistle soundtrack with a galloping beat).
- **Maths**: about 96% (`node scripts/tune-stampede.mjs <spins> <seed>`). Ways ~51 points, Hold & Spin ~29, free games ~14.5, coin pays ~1.4. Hold & Spin about 1 in 95 spins, free games about 1 in 175, Grand about 1 in 90,000 spins. Sources and our own choices: `docs/stampede-mechanics.md`. The original's must-hit-by mystery meter is deliberately left out (it encourages chasing).
- **Test mode**: `#dev` shows practice buttons for Hold & Spin, jackpot coins, multipliers, the Grand (19 locked) and free games.
- **Tests**: `test/stampede.test.js` (13 tests: ways, wild multipliers, Golden Buffalo upgrades, scatter/free games/retriggers, the 8-cash trigger, locked coins, respin resets and countdown, jackpots, multipliers, the Grand, feature queueing, practice/refresh, 20,000 API spins money check).

### Keno 40

40 numbers in an 8×5 grid, pick 1–10, 10 numbers drawn without replacement. Modes: **Classic** (you pick), **Quick** (choose how many, it picks and draws straight away, Classic tables) and **High risk** (top-heavy tables).

- **Maths** (`server/games/keno/config.js`): P(n, k) = C(n,k)·C(40−n,10−k)/C(40,10). Each paying k ≥ kMin(n) gets weight (1/P)^α (Classic α 0.62, High risk 0.86); the table is scaled by bisection so Σ P·min(s·w, cap) = RTP (97% both modes; caps 10,000x / 100,000x), then rounded down to 2 dp. Every table returns 96.6–97.0%. Change `rtp`, `alpha`, `kMin` or `cap` and the tables, screen and tests follow.
- **Flow** (`engine.js`): one `play {stake, picks, mode}` action validates the picks (1–10 unique integers 1–40), takes the stake, draws with Fisher–Yates on the crypto RNG, pays, and records the round and lifetime statistics (rounds, wagered, paid, biggest win, most matches).
- **Screen**: `client/src/pages/premium/keno/Keno.jsx` (ball machine with tumbling balls, balls released one at a time and flown into the results tray, matching tiles glow gold, last ball drum-roll, results card with counting payout, paytable strip and full table, recent games with picked/drawn numbers, lifetime stats). Full screen on phones by default. Art `components/SlotArtKeno.jsx`, sounds `kenoSfx()`.
- **Tests**: `test/keno.test.js` (8 tests: hypergeometric probabilities, all 20 tables' RTP and shape, High risk variance, uniform draws over 30,000 rounds, every pick count × match count × mode payout, validation, stats/history/reload, 60,000-round RTP simulations).

### Gem Mines

5×5 board, 1–24 mines chosen before the round (locked once it starts). Each gem raises the multiplier; cash out any time after the first gem; a mine loses the bet and shows the whole board; finding every gem pays automatically.

- **Maths** (`server/games/mines/config.js`): P(k) = Π_{i<k} (25−M−i)/(25−i); fair multiplier 1/P(k); paid multiplier = floor(RTP / P(k) × 100) / 100 with `RTP = 0.97` (configurable), so cashing out after any number of gems returns 97%. Examples: 1 mine 1st gem 1.01x, 3 mines 1.10x, 24 mines 24.25x; highest possible 5,044,291x (12 mines, all 13 gems). Optional `MAX_MULTIPLIER` cap (off by default).
- **Flow** (`engine.js`): `start` (stake taken; board shuffled with Fisher–Yates on the platform's crypto RNG), `reveal {tile}`, `cashout`. The board stays in the saved server state and is only sent once the round is over; repeated or out-of-turn requests are refused (same tile twice, a second round, cash-out with no gems or after a loss). History stores bet, mines, gems, multiplier, result, payout, time and the full board, viewable from Recent games.
- **Screen**: `client/src/pages/premium/mines/Mines.jsx` (3D tile flips, gem pop and float, mine explosion and shockwave, board reveal, grid shake, win/lose cards, previous-game viewer), art `components/SlotArtMines.jsx`, sounds `minesSfx()` in `lib/sound.js`. Keyboard: Enter play/cash out, R random tile.
- **Tests**: `test/mines.test.js` (9 tests: formula for all 24 mine counts and every reveal, exact mine counts and hidden board, uniform placement over 20,000 boards, cash-outs, losses, auto-pay, every invalid request, reload, 40,000-round RTP simulations).

### Cluck Crossing (Chicken Road-style instant game)

Pick a difficulty and a bet, then cross lane by lane; each safe lane raises the multiplier, cash out any time after the first lane, a vehicle ends the round, reaching the far side pays automatically.

- **Maths** (`server/games/chicken/config.js`): one `RTP` setting (97%) plus per-difficulty `lanes`, `firstRisk` and `topMultiplier` — Easy 24 lanes / 4% first-lane risk / 24x, Medium 22 / 12% / 250x, Hard 20 / 20% / 2,500x, Hardcore 15 / 40% / 10,000x. Risk rises linearly lane by lane (solved so the last lane lands on `topMultiplier`), and each multiplier is `RTP ÷ chance of surviving that far`, rounded down to 2 dp, so cashing out after any lane returns the RTP. Change any number and the tables, screen and tests follow.
- **Flow** (`engine.js`): actions `start` (stake taken), `step` (lane rolled on the server with the platform's crypto RNG only when asked), `cashout`. One round at a time; every action advances the saved state once, so double clicks, double cash-outs and refreshes can't pay or move twice. History keeps bet, difficulty, lane, multiplier, result, payout and time.
- **Screen**: `client/src/pages/premium/chicken/Chicken.jsx` (scrolling road with parallax skyline, two-way traffic, barriers on crossed lanes, posable chicken: idle, nervous, walk, happy, hit, victory), art `components/SlotArtChicken.jsx`, sounds `chickenSfx()` in `lib/sound.js`. Keyboard: space/→ cross, C cash out, Enter start.
- **Tests**: `test/chicken.test.js` (8 tests: per-difficulty tables and RTP at every lane, state flow, hits, exact risk thresholds, auto-pay at the finish, stake/round limits, reload, 40,000-round RTP simulations).

## Roulette on phones, quieter music, full screen everywhere (9 Nov 2026)

- **Roulette (full screen)**: the wheel only appears over the table while it spins (and for a moment after); a slim strip shows recent numbers and the result; bet types and call bets share one swipeable row; number rows stretch to the available height (about 25px on an iPhone 14, was 18) and are three times wider; bet chips sit inside their number; Spin shares a row with Undo / Clear / Rebet / ×2. Fixed: the new number no longer appears in the history strip before the ball lands.
- **Music**: background music now sits well under the effects (`MUSIC_TRIM` 0.22, stings `STING_TRIM` 0.45 in `lib/sound.js`); the synthesised themes are also softened (low-pass 2.8 kHz). The volume slider scales within that.
- **Full screen**: every game opens full screen on every device (phones, tablets and desktop); ✕ returns to the page for that visit only and is no longer remembered. Mines, Keno and Blackjack follow the same rule. The full-screen frame is up to 860px wide on desktop.

## Golden Wishes: clearer symbols, better bonuses (9 Nov 2026)

- **Symbol tiers**: wild, lamp and star have neon frames (cyan / gold / magenta), "WILD" and "BONUS" labels, a constant pulsing aura and a bounce when they land; premium pictures stay full size; gems are slightly smaller; card letters are smaller, darker and muted. Same treatment on the classic reels and paytable.
- **Bonuses rebalanced** (96% kept): free spins ×3 with more genies, guaranteed at least 15x the bet (average about 40x, was 22x); wish prizes start at 5x (were 2x; average about 14x); jackpots Mini 15x, Minor 40x, Major 150x; line pays scaled down to compensate. Details in `docs/genie-mechanics.md`; new tests cover the guarantee and minimum wishes.

## Golden Wishes painted art and recorded music (9 Nov 2026)

- **Art**: all 15 symbols, the full-reel genie wild and the backdrop are painted images generated with ElevenLabs (GPT Image 2.5) from our own prompts, all styled from one reference genie tile so the set matches. They live in `client/src/assets/genie/*.webp` (320px tiles, about 560 KB in total) and are bundled as data URLs (`.webp/.jpg/.png` use esbuild's `dataurl` loader). The canvas reels, classic reels, paytable and backdrop all use them; the hand-drawn SVG art remains the fallback.
- **Music**: `lib/sound.js` can now play recorded soundtracks: `registerTracks(game, { base, free, bonus, win, jackpot })`, gapless self-crossfading loops, `setMusicScene()` crossfades between base / free spins / treasure, and `playSting()` plays win and jackpot stings over the loop. Put MP3s in `client/audio/genie/` named `base.mp3`, `free.mp3`, `bonus.mp3`, `win.mp3`, `jackpot.mp3`; the builds detect them (`__AUDIO__`), copy them to `dist/audio/`, and the standalone page publishes them beside itself. Without them the synthesised theme plays. Installed tracks: base = "Caravan of Cards" (90s), free = "Carpet Skies" (75s), bonus = "Vault of Amber" (60s), win = "Golden Jackpot Fanfare" (8s), jackpot = "Golden Triumph" (14s); loudness-normalised and silence-trimmed with ffmpeg, 128 kbps. Stings play on their own bus, and the synthesised win and jackpot fanfares are skipped while recorded stings exist.

## Enhanced graphics pilot – Golden Wishes (9 Nov 2026)

- **Canvas renderer** (no new dependencies): `client/src/lib/fx2d.js` (easing, tweens, animation loop, SVG → texture, glow sprites, particle system) plus `pages/premium/genie/CanvasReels.jsx`, `CanvasScene.jsx` and `textures.jsx`.
- **Reels**: motion-blurred strips, a small wind-up before the spin, stops with overshoot and settle, landing bursts for lamps, stars and genies, glowing pulsing winners with a travelling glint, dimmed losers, paylines drawn in with a light trail and line badges, a full-reel genie rising from smoke for expanding wilds, anticipation sparks, and physics coin rain.
- **Background**: animated sky that shifts colour with the mode (base / free spins / treasure), slow light rays, twinkling and shooting stars, drifting smoke, rising golden motes and the palace skyline. Fewer particles on phones; it pauses when the tab is hidden and goes still for reduced-motion users.
- **Switch**: ⚙ → "Enhanced graphics" (on by default; remembered as `gn_hd`). Off brings back the classic DOM reels. If canvas isn't available it falls back automatically.
- PixiJS and GSAP were the first choice but couldn't be downloaded in the build environment; the renderer is written so the same effects could move to Pixi later.

## Golden Wishes – genie jackpot slot (9 Nov 2026)

- **Game**: original 5×3, 20-line Arabian Nights slot (`/casino/genie`). Genie wild (top symbol), Princess, Golden Palace, Treasure Chest, Crown, three gems and jewelled card letters, all hand-drawn SVG (`components/SlotArtGenie.jsx`). An animated genie host floats beside the jackpots and reacts to wins, features and jackpots with poses, a speech bubble and a synthesised "voice".
- **Features**: Magic Lamp wishes (3+ lamps: instant prize, multiplied prize with a rolling multiplier, free spins or Genie's Treasure); Wishing Star free spins (×2 wins, expanding genies, retriggers); Genie's Treasure jackpot pick (match three jewels: Mini 10x, Minor 25x, Major 100x, Grand 1,000x the bet, plus prizes × multiplier). Each jackpot has its own colour, sound and celebration; the Grand fills the screen.
- **Presentation**: drawn paylines (all, then one by one), coin showers, Big / Mega / Epic win tiers (the shared celebration now accepts per-game tier names), lamp rub → smoke → genie reveal, landing and anticipation effects, Arabian soundtrack.
- **Controls**: bet −/+, spin, Auto (spin count and a loss limit are required; stops on any feature, an optional big win, low balance or Stop), Turbo, Pays, Rules, settings, sound menu, last win and balance. Full screen on phones (fits iPhone SE and 14 sizes with no scrolling).
- **Maths**: 96.07% measured over 12M spins; full breakdown and tuning notes in `docs/genie-mechanics.md`. Config in `server/games/genie/config.js`; simulation `scripts/tune-genie.mjs`; 16 tests in `test/genie.test.js`.

## Full screen on phones and smoother Baccarat (9 Nov 2026)

- **Full screen** (`client/src/components/Popout.jsx`): every game opens full screen on phones (under 768px wide), above the site header and tab bar, with a slim bar (✕ exit, game name, balance, sound and rules). The game is scaled down to fit the visible height so nothing needs scrolling (checked at iPhone 14 and iPhone SE sizes). ✕ returns to the normal page and the choice is remembered (`vb_pop`); "⤢ Full screen" switches back on (also available on desktop). `PremiumShell` and `GameShell` use it automatically; Lakeside uses `PopoutWrap`; Mines, Keno and Blackjack keep their own full-screen layouts. Bead road, roulette history card and long hints are hidden in full screen (`.pop-hide`); roulette shows a compact last-6 strip beside the wheel instead.
- **Baccarat dealing** (`pages/Baccarat.jsx`): cards slide from the shoe face down, flip over one at a time and each total updates after its card turns. Fixed card slots stop the layout jumping, earlier cards no longer re-animate, and the third card pauses briefly before it comes.

## Audit (8 Nov 2026): sound, win presentation and QA

- **Sound engine** (`client/src/lib/sound.js`, rewritten): master → effects bus + music bus, each with its own on/off and volume slider (`components/SoundMenu.jsx`, used by every game). Every game has a sound theme (scale, lead instrument, effect voicing) and its own synthesised soundtrack (tempo, instruments, drum pattern): e.g. Mummy = oud and darbuka in a Hijaz scale, Neon = synthwave, Dragon = guzheng-style pluck and taiko, Frost = bells, Vault = swung heist jazz, Fruit = chiptune, tables = lounge/jazz. All sustained low drones were removed. Music starts on the first action, never restarts between spins, ducks under big-win fanfares and stops when the tab is hidden.
- **Win presentation** (`components/WinCelebration.jsx`): one tiered celebration used by every slot and by roulette, crash, plinko and scratchcards: BIG (10x) → MEGA (25x) → SUPER (50x). The counter climbs through the tiers; each step restamps the title, adds rotating rays, rings, flashes and more particles, and steps the fanfare up. Each game has its own colours and particle style (bubbles, sparks, embers, stars, snow, fireflies, sand, gems, coins). First tap skips the count, second closes.
- **Fixes**: classic slots (Nebula, Vault, Starlight) now fit the screen height on desktop; themed loading splash for premium games; Moonridge win art no longer drowns the text.
- **QA tools**: `scripts/rtp-audit.mjs` (long-run return for every server game) and the browser harnesses described in the audit report.

## What still needs an external API

- **Real fixtures, live scores and real results** - need an API key (Option A or B above). Demo mode works without one.
- **Next goalscorer (player) market** - not implemented. It requires reliable confirmed line-ups and player-level goal data; it could be added on API-Football (line-ups endpoint) but isn't included in this version.
- **Real bookmaker odds** - not used; all odds come from the built-in simulation model. API-Football's odds endpoints could be wired in later, but they'd still be shown as reference only.
- **Live corners for real matches** - API-Football's live feed doesn't include corners, so the corners market is pre-match only for real matches (settled from post-match statistics).

The API-Football and football-data.org adapters were written against the providers' documented response formats but haven't yet been exercised with real keys, so check the server log on first connection. Problems are logged and also shown on the home page.

## Project structure

```
server/
  index.js          HTTP server, routes, background jobs
  config.js         .env loading, betting/wallet rules
  db.js             SQLite schema and helpers
  auth.js           accounts and sessions
  wallet.js         token ledger (credit/debit only)
  markets.js        market catalogue, odds model, settlement rules
  bets.js           bet placement, quotes, daily limits
  settlement.js     automatic settlement
  stats.js          statistics and leaderboard
  money.js          exact integer odds/return maths
  providers/demo.js simulated matches
  providers/live.js API-Football and football-data.org adapters
client/src/         React app (pages, components, bet slip state)
test/               node:test suites
build.mjs           esbuild + Tailwind build
```

## Notes

- Serving over HTTPS? Set `COOKIE_SECURE=true`.
- The demo team list approximates recent seasons and may not match the current one; badges are generated shields, not club crests.
- If real-money gambling is a problem for you or someone you know, free confidential help is available in the UK from the National Gambling Helpline (0808 8020 133), GamCare and BeGambleAware.
