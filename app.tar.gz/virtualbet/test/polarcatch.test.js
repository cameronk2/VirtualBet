// Polar Catch: wheel make-up, payouts, multipliers, caps and returns.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { spinRound, validateBets } from '../server/games/polarcatch/engine.js';
import { BONUS_IDS, CATCH, SPOTS, WHEEL } from '../server/games/polarcatch/config.js';
import { bonusRtp, flakeRtp } from '../server/games/polarcatch/maths.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (seed = 1) => ({ rand: seeded(seed), now: 0, minStake: 10, maxStake: 50000 });
const idx = (spot) => WHEEL.indexOf(spot);

test('wheel: 53 segments, 23 + 23 flakes, 4 + 2 + 1 bonus', () => {
  assert.equal(WHEEL.length, 53);
  const n = (s) => WHEEL.filter((x) => x === s).length;
  assert.deepEqual([n('blue'), n('white'), n('minnow'), n('salmon'), n('king')], [23, 23, 4, 2, 1]);
});

test('exact returns match the targets', () => {
  assert.ok(Math.abs(flakeRtp() * 100 - 97.1) < 0.01);
  for (const id of BONUS_IDS) assert.ok(Math.abs(bonusRtp(id) * 100 - CATCH[id].target) < 0.01, id);
});

test('flake pays 1:1, or m:1 on a lit segment; other bets lose', () => {
  for (let s = 1; s < 300; s++) {
    const r = spinRound({ blue: 100, white: 100, king: 100 }, seeded(s), { segment: idx('blue') + 2 * (s % 5) });
    const landed = r.landed;
    if (landed === 'blue' || landed === 'white') {
      const m = r.lit[r.segment] || 1;
      assert.equal(r.results[landed].ret, 100 * (1 + m));
      const other = landed === 'blue' ? 'white' : 'blue';
      assert.equal(r.results[other].ret, 0);
      assert.equal(r.results.king.ret, 0);
      assert.equal(r.payout, 100 * (1 + m));
    }
    for (const [i, m] of Object.entries(r.lit)) { assert.ok(SPOTS[WHEEL[i]].kind === 'flake'); assert.ok([3, 4, 5, 7, 10].includes(m)); }
  }
});

test('bonus rounds: catch × category multiplier, capped per bonus, stake returned', () => {
  for (const id of BONUS_IDS) {
    for (let s = 1; s < 200; s++) {
      const r = spinRound({ [id]: 100 }, seeded(s), { segment: idx(id) });
      const f = r.fishing;
      assert.equal(f.bonus, id);
      assert.equal(f.mult, r.bonusMult[id] || 1);
      assert.equal(f.pays, Math.min(SPOTS[id].maxPay, f.fish * f.mult));
      assert.equal(r.results[id].ret, 100 * (1 + f.pays));
      assert.ok(CATCH[id].values.some(([v]) => v === f.fish));
    }
    const top = spinRound({ [id]: 100 }, () => 0.01, { segment: idx(id), fish: 5000 });
    assert.equal(top.fishing.pays, SPOTS[id].maxPay, 'cap');
  }
});

test('the round total is capped at 5,000x the stake', () => {
  const r = spinRound({ king: 100, blue: 10 }, () => 0.01, { segment: idx('king'), fish: 4999 });
  assert.equal(r.payout, Math.min(r.results.king.ret, 110 * 5000));
});

test('bets are validated', () => {
  assert.throws(() => validateBets({}), /Place a bet/);
  assert.throws(() => validateBets({ blue: 5 }), /at least/);
  assert.throws(() => validateBets({ blue: 10001 }), /at most/);
  assert.throws(() => validateBets({ shark: 100 }), /Unknown/);
  assert.deepEqual(validateBets({ blue: 100, white: 0 }), { blue: 100 });
});

test('real API: stake is the sum of bets, payout matches results, simulation agrees with the maths', () => {
  let st = null;
  const totals = Object.fromEntries(['blue', 'minnow'].map((k) => [k, { p: 0, w: 0 }]));
  const c = ctx(99);
  for (let i = 0; i < 120000; i++) {
    const r = runGame('polarcatch', st, 'spin', { bets: { blue: 100, minnow: 100 } }, c);
    assert.equal(r.stake, 200);
    assert.equal(r.payout, Object.values(r.out.results).reduce((a, x) => a + x.ret, 0));
    totals.blue.p += 100; totals.blue.w += r.out.results.blue.ret;
    totals.minnow.p += 100; totals.minnow.w += r.out.results.minnow.ret;
    st = r.state;
  }
  assert.ok(Math.abs(totals.blue.w / totals.blue.p - flakeRtp()) < 0.012, `blue ${totals.blue.w / totals.blue.p}`);
  assert.ok(Math.abs(totals.minnow.w / totals.minnow.p - bonusRtp('minnow')) < 0.06, `minnow ${totals.minnow.w / totals.minnow.p}`);
});
