// Stampede Link: 1,024 ways, multiplying wilds, Golden Buffalo, free games
// and Hold & Spin, with every bonus condition forced.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { act, init } from '../server/games/stampede/engine.js';
import { evaluateWays } from '../server/games/stampede/reels.js';
import { holdTotal, respin, startHold } from '../server/games/stampede/hold.js';
import { FREE_GAMES, GOLD_UPGRADES, HOLD_RESPINS, JACKPOTS, MAX_WIN_X, PAYTABLE, PAY_SCALE, RETRIGGER, SCATTER_PAY } from '../server/games/stampede/config.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (seed = 1, inject) => ({ rand: seeded(seed), minStake: 10, inject });
// A grid with no wins: reel 1 symbols never appear on reel 2.
const DEAD = [['A', 'K', 'Q', 'J'], ['T', 'N', 'T', 'N'], ['A', 'K', 'Q', 'J'], ['ELK', 'WOLF', 'ELK', 'WOLF'], ['A', 'K', 'Q', 'J']];
const grid = (edits = {}) => DEAD.map((col, c) => col.map((s, r) => { const e = edits[`${c},${r}`]; return e ? (typeof e === 'string' ? { s: e } : e) : { s }; }));
const cash = (v) => ({ s: 'CASH', v });
const EIGHT = [[0, 0], [0, 1], [1, 0], [1, 3], [2, 2], [3, 1], [4, 0], [4, 3]];
const withCash = (cells, vals, extra = {}) => grid({ ...Object.fromEntries(cells.map(([c, r], i) => [`${c},${r}`, cash(vals[i % vals.length])])), ...extra });
const pay = (sym, n, ways, bet) => Math.floor((bet * PAYTABLE[sym][n - 3] * PAY_SCALE * ways) / 1000);

test('a dead spin charges the stake and pays nothing', () => {
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid() }));
  assert.equal(r.stake, 100); assert.equal(r.payout, 0); assert.equal(r.state.mode, 'base');
});

test('1,024 ways: every symbol pays its table value and ways multiply', () => {
  for (const sym of Object.keys(PAYTABLE)) for (let n = 3; n <= 5; n++) {
    const g = grid(); for (let c = 0; c < 5; c++) for (let r = 0; r < 4; r++) g[c][r] = { s: 'COIN' };
    for (let c = 0; c < n; c++) g[c][1] = { s: sym };
    const w = evaluateWays(g, 10000).find((x) => x.symbol === sym);
    assert.equal(w.amount, pay(sym, n, 1, 10000), `${sym} x${n}`);
  }
  const g = grid({ '0,0': 'BUFFALO', '0,2': 'BUFFALO', '1,0': 'BUFFALO', '1,1': 'BUFFALO', '1,2': 'BUFFALO', '2,3': 'BUFFALO' });
  const w = evaluateWays(g, 100).find((x) => x.symbol === 'BUFFALO');
  assert.equal(w.ways, 2 * 3 * 1); assert.equal(w.count, 3); assert.equal(w.amount, pay('BUFFALO', 3, 6, 100));
});

test('wilds substitute on reels 2-5 only; multipliers multiply every way through them', () => {
  const g = grid({ '0,0': 'BUFFALO', '1,0': { s: 'WILD' }, '2,0': 'BUFFALO', '3,0': 'BUFFALO', '4,0': { s: 'WILD', m: 3 } });
  const w = evaluateWays(g, 1000).find((x) => x.symbol === 'BUFFALO');
  assert.equal(w.count, 5); assert.equal(w.ways, 1); assert.equal(w.amount, pay('BUFFALO', 5, 3, 1000));
  const g2 = grid({ '0,0': 'EAGLE', '1,0': { s: 'WILD', m: 2 }, '2,0': { s: 'WILD', m: 3 }, '2,1': 'EAGLE' });
  const w2 = evaluateWays(g2, 1000).find((x) => x.symbol === 'EAGLE');
  assert.equal(w2.ways, 2); assert.equal(w2.mult, 4, 'a 2x·3x way (6) plus a 2x way (2) = 8 over 2 ways');
  assert.equal(w2.amount, pay('EAGLE', 3, 8, 1000));
  const g3 = grid({ '0,0': { s: 'WILD' }, '1,0': 'COUGAR', '2,0': 'COUGAR' });
  assert.ok(!evaluateWays(g3, 100).some((x) => x.symbol === 'COUGAR'), 'no win without the symbol on reel 1');
});

test('Golden Buffalo counts as Buffalo, and collected heads upgrade animals in free games', () => {
  const g = grid({ '0,0': 'GOLD', '1,0': 'BUFFALO', '2,0': 'GOLD' });
  assert.equal(evaluateWays(g, 1000).find((x) => x.symbol === 'BUFFALO').count, 3);
  const g2 = grid({ '0,0': 'BUFFALO', '1,0': 'WOLF', '2,0': 'BUFFALO' });
  assert.ok(!evaluateWays(g2, 1000).some((x) => x.symbol === 'BUFFALO' && x.count >= 3));
  assert.equal(evaluateWays(g2, 1000, { upgrades: ['WOLF'] }).find((x) => x.symbol === 'BUFFALO').count, 4, 'the wolves on reels 2 and 4 now count');
  // in play: three gold heads turn wolves into buffalo
  let st = act(init(), 'dev', { event: 'free', stake: 100 }, ctx()).state;
  const r = act(st, 'spin', {}, ctx(2, { grid: grid({ '0,0': 'GOLD', '0,1': 'GOLD', '4,2': 'GOLD', '1,0': 'BUFFALO', '2,0': 'WOLF' }) }));
  assert.equal(r.out.gold, 3); assert.deepEqual(r.out.upgrades, [GOLD_UPGRADES[0].sym]);
  assert.ok(r.out.wins.some((w) => w.symbol === 'BUFFALO' && w.count >= 3));
  assert.equal(r.state.free.gold, 3, 'the collection persists');
});

test('3/4/5 gold coins pay and award 8/15/20 free games; 2 coins retrigger; free games cost nothing', () => {
  for (const n of [3, 4, 5]) {
    const g = grid(Object.fromEntries([...Array(n).keys()].map((c) => [`${c},3`, 'COIN'])));
    const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: g }));
    assert.equal(r.out.started.type, 'free'); assert.equal(r.state.free.remaining, FREE_GAMES[n]);
    assert.equal(r.out.scatterWin, 100 * SCATTER_PAY[n]);
  }
  const two = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,3': 'COIN', '2,3': 'COIN' }) }));
  assert.equal(two.out.started, undefined, 'two coins do nothing in the base game');
  let st = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,3': 'COIN', '2,3': 'COIN', '4,3': 'COIN' }) })).state;
  const r = act(st, 'spin', {}, ctx(3, { grid: grid({ '1,3': 'COIN', '3,3': 'COIN' }) }));
  assert.equal(r.stake, 0); assert.equal(r.out.triggers.retrigger, RETRIGGER[2]);
  assert.equal(r.state.free.remaining, FREE_GAMES[3] - 1 + RETRIGGER[2]);
});

test('8 buffalo cash start Hold & Spin with them locked; 7 do not', () => {
  const seven = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: withCash(EIGHT.slice(0, 7), [1]) }));
  assert.equal(seven.state.mode, 'base'); assert.equal(seven.payout, 0, 'cash only pays inside Hold & Spin');
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: withCash(EIGHT, [1, 2, 'MINI']) }));
  assert.equal(r.state.mode, 'hold'); assert.equal(r.out.started.type, 'hold');
  assert.equal(Object.keys(r.state.hold.cells).length, 8); assert.equal(r.state.hold.respins, HOLD_RESPINS);
  assert.deepEqual(r.state.hold.cells['0,0'], { v: 1 });
});

test('Hold & Spin: new symbols lock and reset to 3, empty respins count down, pays once at the end', () => {
  let st = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: withCash(EIGHT, [1]) })).state;
  let r = act(st, 'respin', {}, ctx(2, { lands: [] }));
  assert.equal(r.state.hold.respins, 2); assert.equal(r.payout, 0);
  r = act(r.state, 'respin', {}, ctx(2, { lands: [] }));
  assert.equal(r.state.hold.respins, 1);
  r = act(r.state, 'respin', {}, ctx(2, { lands: [{ c: 2, r: 0, v: 5 }] }));
  assert.equal(r.state.hold.respins, 3, 'reset'); assert.deepEqual(r.state.hold.cells['2,0'], { v: 5 });
  assert.equal(Object.keys(r.state.hold.cells).length, 9, 'earlier symbols stay locked');
  for (let i = 0; i < 2; i++) { r = act(r.state, 'respin', {}, ctx(2, { lands: [] })); assert.equal(r.payout, 0); }
  r = act(r.state, 'respin', {}, ctx(2, { lands: [] }));
  assert.equal(r.out.holdDone.totalX, 8 + 5); assert.equal(r.payout, 1300); assert.equal(r.state.mode, 'base');
  assert.throws(() => act(r.state, 'respin', {}, ctx()), /no Hold & Spin/);
});

test('jackpot coins pay their jackpots; stampede multipliers boost locked credits; a full grid pays the Grand', () => {
  const h = startHold(withCash(EIGHT, ['MINI', 'MINOR', 'MAJOR', 1, 2, 1, 1, 1]), 100, 'base');
  assert.equal(holdTotal(h), JACKPOTS.MINI + JACKPOTS.MINOR + JACKPOTS.MAJOR + 6);
  const ev = respin(h, seeded(1), [{ c: 2, r: 0, v: 'X2' }]);
  assert.equal(ev.boosts[0].m, 2); assert.equal(holdTotal(h), JACKPOTS.MINI + JACKPOTS.MINOR + JACKPOTS.MAJOR + 12, 'jackpots are not multiplied');
  respin(h, seeded(1), [{ c: 2, r: 1, v: 'X3' }]);
  assert.equal(holdTotal(h), JACKPOTS.MINI + JACKPOTS.MINOR + JACKPOTS.MAJOR + 36);
  // full grid
  const all = [...Array(19).keys()].map((i) => [Math.floor(i / 4), i % 4]);
  const g = respin(Object.assign(startHold(withCash(all, [1]), 100, 'base')), seeded(1), [{ c: 4, r: 3, v: 1 }]);
  assert.equal(g.full, true); assert.equal(g.done, true); assert.equal(g.totalX, 20 + JACKPOTS.GRAND);
});

test('both trigger: Hold & Spin first, then the free games; Hold & Spin inside free games resumes them', () => {
  const g = withCash(EIGHT, [1], { '0,2': 'COIN', '2,3': 'COIN', '3,3': 'COIN' });
  let r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: g }));
  assert.equal(r.state.mode, 'hold'); assert.deepEqual(r.state.queue.map((q) => q.type), ['free']);
  for (let i = 0; i < 3; i++) r = act(r.state, 'respin', {}, ctx(2, { lands: [] }));
  assert.equal(r.out.started.type, 'free'); assert.equal(r.state.mode, 'free');
  const before = r.state.free.remaining;
  r = act(r.state, 'spin', {}, ctx(3, { grid: withCash(EIGHT, [2]) }));
  assert.equal(r.state.mode, 'hold'); assert.equal(r.state.free.remaining, before - 1);
  for (let i = 0; i < 3; i++) r = act(r.state, 'respin', {}, ctx(2, { lands: [] }));
  assert.equal(r.state.mode, 'free'); assert.equal(r.payout, 1600); assert.equal(r.state.free.total, 1600);
});

test('free games end with a summary and return to the base game', () => {
  let st = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,3': 'COIN', '2,3': 'COIN', '4,3': 'COIN' }) })).state;
  let r;
  for (let i = 0; i < FREE_GAMES[3]; i++) r = act(st = r ? r.state : st, 'spin', {}, ctx(5, { grid: grid() }));
  assert.equal(r.out.finished.played, FREE_GAMES[3]); assert.equal(r.state.mode, 'base'); assert.equal(r.state.free, null);
});

test('practice triggers (hold, jackpots, multipliers, grand, free) cost and pay nothing and survive a reload', () => {
  for (const event of ['hold', 'jackpots', 'mult', 'grand', 'free']) {
    let r = runGame('stampede', null, 'dev', { event, stake: 100 }, ctx());
    let st = JSON.parse(JSON.stringify(r.state));
    const seen = new Set();
    for (let i = 0; i < 400 && st.mode !== 'base'; i++) {
      r = runGame('stampede', st, st.mode === 'hold' ? 'respin' : 'spin', {}, ctx(i + 3));
      assert.equal(r.stake, 0); assert.equal(r.payout, 0);
      if (r.out.boosts?.length) seen.add('boost');
      if (r.out.holdDone?.grand) seen.add('grand');
      st = JSON.parse(JSON.stringify(r.state));
    }
    assert.equal(st.mode, 'base'); assert.equal(st.practice, false);
    if (event === 'mult') assert.ok(seen.has('boost'));
    if (event === 'grand') assert.ok(seen.has('grand'));
  }
});

test('a repeated or out-of-turn action is refused (no double payouts)', () => {
  const st = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: withCash(EIGHT, [1]) })).state;
  assert.throws(() => act(st, 'spin', { stake: 100 }, ctx()), /Hold & Spin/);
  assert.throws(() => act(init(), 'respin', {}, ctx()), /no Hold & Spin/);
  assert.throws(() => act(st, 'dev', { event: 'hold', stake: 100 }, ctx()), /Finish/);
});

test('real API: 20,000 spins, every feature plays out, money adds up, cap respected', () => {
  let st = null, paid = 0, n = 0;
  const seen = new Set();
  const c = ctx(4242);
  while (n < 20000 || (st && st.mode !== 'base')) {
    const mode = st?.mode || 'base';
    const r = runGame('stampede', st, mode === 'hold' ? 'respin' : 'spin', mode === 'base' ? { stake: 100 } : {}, c);
    if (mode === 'base') { n++; assert.equal(r.stake, 100); } else assert.equal(r.stake, 0);
    if (r.out.started) seen.add(r.out.started.type);
    if (r.out.boosts?.length) seen.add('boost');
    if (r.out.holdDone?.jackpots.length) seen.add('jackpot');
    if (r.out.upgrades?.length) seen.add('upgrade');
    assert.ok(Number.isSafeInteger(r.payout) && r.payout >= 0 && r.payout <= 100 * MAX_WIN_X);
    paid += r.stake; st = r.state;
  }
  assert.equal(paid, 2000000);
  for (const k of ['hold', 'free', 'boost', 'jackpot', 'upgrade']) assert.ok(seen.has(k), k);
});
