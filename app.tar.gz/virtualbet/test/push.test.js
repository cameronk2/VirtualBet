// Bet notifications: payload encryption must be readable by a browser
// (RFC 8291), the VAPID token must verify, and only real push services are
// ever contacted.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import { openDb, q } from '../server/db.js';

openDb(path.join(os.tmpdir(), `vb-push-${process.pid}-${Date.now()}.db`));
const push = await import('../server/push.js');

const hmac = (k, d) => crypto.createHmac('sha256', k).update(d).digest();
// What the browser does with the message (the receiving side of RFC 8291)
function browserDecrypt(buf, ua, auth) {
  const salt = buf.subarray(0, 16);
  const idlen = buf[20];
  const asPublic = buf.subarray(21, 21 + idlen);
  const ct = buf.subarray(21 + idlen);
  const shared = ua.computeSecret(asPublic);
  const prkKey = hmac(auth, shared);
  const ikm = hmac(prkKey, Buffer.concat([Buffer.from('WebPush: info\0'), ua.getPublicKey(), asPublic, Buffer.from([1])]));
  const prk = hmac(salt, ikm);
  const cek = hmac(prk, Buffer.from('Content-Encoding: aes128gcm\0\x01')).subarray(0, 16);
  const nonce = hmac(prk, Buffer.from('Content-Encoding: nonce\0\x01')).subarray(0, 12);
  const d = crypto.createDecipheriv('aes-128-gcm', cek, nonce);
  d.setAuthTag(ct.subarray(ct.length - 16));
  const pt = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
  assert.equal(pt[pt.length - 1], 2, 'last-record delimiter');
  return pt.subarray(0, pt.length - 1).toString();
}

function fakeBrowser() {
  const ua = crypto.createECDH('prime256v1'); ua.generateKeys();
  const auth = crypto.randomBytes(16);
  return { ua, auth, sub: { endpoint: `https://web.push.apple.com/QG${crypto.randomBytes(8).toString('hex')}`, keys: { p256dh: ua.getPublicKey().toString('base64url'), auth: auth.toString('base64url') } } };
}

test('a browser can decrypt the notification', () => {
  const b = fakeBrowser();
  const msg = JSON.stringify({ title: 'Bet won: +£4.20 virtual', body: 'Arsenal paid £9.20' });
  const enc = push.encrypt(msg, b.sub.keys.p256dh, b.sub.keys.auth);
  assert.equal(browserDecrypt(enc, b.ua, b.auth), msg);
});

test('VAPID token is a valid ES256 JWT for the push service', () => {
  const h = push.vapidHeader('https://web.push.apple.com/abc');
  const [, token, key] = /^vapid t=([^,]+), k=(.+)$/.exec(h);
  const [head, body, sig] = token.split('.');
  const claims = JSON.parse(Buffer.from(body, 'base64url'));
  assert.equal(claims.aud, 'https://web.push.apple.com');
  assert.ok(claims.exp > Date.now() / 1000 && claims.exp < Date.now() / 1000 + 86400);
  assert.match(claims.sub, /^(mailto:|https:)/);
  const raw = Buffer.from(key, 'base64url');
  const pub = crypto.createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: raw.subarray(1, 33).toString('base64url'), y: raw.subarray(33).toString('base64url') }, format: 'jwk' });
  assert.ok(crypto.verify('sha256', Buffer.from(`${head}.${body}`), { key: pub, dsaEncoding: 'ieee-p1363' }, Buffer.from(sig, 'base64url')));
  assert.equal(push.vapidPublicKey(), key, 'same key every time');
});

test('only real push services are accepted', () => {
  for (const ok of ['https://web.push.apple.com/x', 'https://fcm.googleapis.com/fcm/send/x', 'https://updates.push.services.mozilla.com/wpush/v2/x', 'https://wns2-par02p.notify.windows.com/w/?token=x']) assert.ok(push.allowedEndpoint(ok), ok);
  for (const bad of ['http://web.push.apple.com/x', 'https://localhost/x', 'https://169.254.169.254/latest', 'https://evil.com/push.apple.com', 'https://web.push.apple.com:8443/x', 'not a url']) assert.ok(!push.allowedEndpoint(bad), bad);
});

test('settled bets reach the right user, gone devices are removed, opt-out is respected', async () => {
  q("INSERT INTO users (username, password_hash, balance, created_at) VALUES ('pushuser', 'x', 0, 0)").run();
  q("INSERT INTO users (username, password_hash, balance, created_at) VALUES ('other', 'x', 0, 0)").run();
  const uid = q("SELECT id FROM users WHERE username = 'pushuser'").get().id;
  const other = q("SELECT id FROM users WHERE username = 'other'").get().id;
  const a = fakeBrowser(); const gone = fakeBrowser(); const o = fakeBrowser();
  push.subscribe(uid, a.sub); push.subscribe(uid, gone.sub); push.subscribe(other, o.sub);
  assert.throws(() => push.subscribe(uid, { ...a.sub, endpoint: 'https://127.0.0.1/x' }));
  const got = [];
  push._setSender(async (url, init) => {
    got.push({ url, init });
    return { status: url === gone.sub.endpoint ? 410 : 201 };
  });
  push.notifySettled([{ userId: uid, ref: 'VB-1', type: 'SINGLE', legs: 1, stake: 500, status: 'WON', ret: 920, label: 'Arsenal' }]);
  await new Promise((r) => setTimeout(r, 50));
  assert.equal(got.length, 2, 'both of this user\'s devices, not the other user');
  const mine = got.find((g) => g.url === a.sub.endpoint);
  assert.equal(mine.init.headers['Content-Encoding'], 'aes128gcm');
  const msg = JSON.parse(browserDecrypt(mine.init.body, a.ua, a.auth));
  assert.equal(msg.title, 'Bet won: +£4.20 virtual');
  assert.match(msg.body, /Arsenal paid £9\.20/);
  assert.equal(msg.url, '/my-bets?tab=settled&bet=VB-1');
  assert.equal(push.deviceCount(uid), 1, 'device that answered 410 is forgotten');
  // turned off -> nothing sent
  const { setNotifySettled } = await import('../server/prefs.js');
  setNotifySettled(uid, false);
  got.length = 0;
  push.notifySettled([{ userId: uid, ref: 'VB-2', type: 'SINGLE', legs: 1, stake: 500, status: 'LOST', ret: 0, label: 'Arsenal' }]);
  await new Promise((r) => setTimeout(r, 50));
  assert.equal(got.length, 0);
});
