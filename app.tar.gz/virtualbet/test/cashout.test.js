import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cashOutValue } from '../server/cashout.js';

test('cash out values', () => {
  // unchanged odds -> 95% of stake
  let r = cashOutValue(1000, 2500, [{ odds: 250, status: 'OPEN', current: { odds: 250 } }]);
  assert.deepEqual(r, { available: true, value: 950 });
  // shortened odds -> profit
  r = cashOutValue(1000, 2500, [{ odds: 250, status: 'OPEN', current: { odds: 125 } }]);
  assert.equal(r.value, 1900);
  // acca with one won leg
  r = cashOutValue(1000, 6000, [{ odds: 200, status: 'WON' }, { odds: 300, status: 'OPEN', current: { odds: 150 } }]);
  assert.equal(r.value, 3800);
  // void leg ignored
  r = cashOutValue(1000, 3000, [{ odds: 200, status: 'VOID' }, { odds: 300, status: 'OPEN', current: { odds: 300 } }]);
  assert.equal(r.value, 950);
  // capped below potential
  r = cashOutValue(1000, 2500, [{ odds: 250, status: 'OPEN', current: { odds: 101 } }]);
  assert.equal(r.value, 2351);
  r = cashOutValue(1000, 1100, [{ odds: 110, status: 'OPEN', current: { odds: 100.5 } }]);
  assert.ok(r.value <= 1099);
  assert.equal(cashOutValue(1000, 2500, [{ odds: 250, status: 'LOST' }, { odds: 2, status: 'OPEN', current: { odds: 2 } }]).available, false);
  assert.equal(cashOutValue(1000, 2500, [{ odds: 250, status: 'OPEN', current: null }]).available, false);
  assert.equal(cashOutValue(1000, 2500, [{ odds: 250, status: 'OPEN', current: { odds: 250, suspended: true } }]).available, false);
});
