// Moonridge: the Delayed Expanding Wild cycle, maths and money integrity.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { resolveSpin, evaluate } from '../server/games/moonridge/engine.js';
import { advance, createWild, growthOrder, settle, STAGE, WildStateError } from '../server/games/moonridge/wilds.js';
import { FREE_SPINS, JACKPOTS, MAX_WIN_X, PAYTABLE, ROWS, SCATTER_PAY } from '../server/games/moonridge/config.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (seed = 1) => ({ rand: seeded(seed), now: 0, minStake: 10, maxStake: 50000 });
const fresh = () => ({ wilds: [], nextId: 1, spin: 0, free: null, recent: [] });
// A dead grid: no line can pay (columns rotate through unrelated symbols).
const DEAD = [['Q', 'K', 'A', 'EAGLE'], ['AMULET', 'WHITE', 'BLACK', 'GRAY'], ['K', 'A', 'Q', 'AMULET'], ['GRAY', 'EAGLE', 'WHITE', 'BLACK'], ['A', 'Q', 'K', 'EAGLE']];
const grid = (edits = {}) => DEAD.map((col, r) => col.map((s, row) => edits[`${r},${row}`] ?? s));
/** One engine spin with chosen cells; returns the result and the carried state. */
function spin(state, cells, bet = 100) {
  const r = resolveSpin(structuredClone(state), { bet, rand: () => 0.5, inject: cells });
  return { r, state: { ...state, wilds: r.wilds, nextId: r.nextId, spin: r.spinNo, free: r.next && r.next.remaining > 0 ? r.next : null } };
}

test('growth order: every start row fills the 4-row column in exactly 3 steps', () => {
  for (let row = 0; row < ROWS; row++) {
    const o = growthOrder(row, ROWS);
    assert.equal(o.length, 3);
    assert.deepEqual([row, ...o].sort(), [0, 1, 2, 3]);
  }
});

test('single wild: lands, locks, survives, expands one cell per spin, fills, disappears', () => {
  let s = fresh();
  // Spin 1: a x2 wild lands on reel 3, row 1
  let { r, state } = spin(s, grid({ '2,1': 'W2' }));
  assert.equal(r.out.landed.length, 1);
  const id = r.out.landed[0].id;
  assert.deepEqual(r.out.events.filter((e) => e.id === id).map((e) => e.type), ['land', 'lock']);
  assert.equal(state.wilds.length, 1);
  let w = state.wilds[0];
  assert.equal(w.stage, STAGE.LOCKED);
  assert.deepEqual(w.occupied, [1]);
  assert.equal(w.remaining, 3);
  assert.equal(w.sticky, true);
  assert.equal(r.out.grid[2][1], 'W2', 'wild on the landing spin');

  // Spins 2-3: it stays in place and grows by one cell each spin.
  // The drawn grid tries to put other symbols in its cells; they never win.
  const sizes = [];
  for (let k = 0; k < 2; k++) {
    ({ r, state } = spin(state, grid({ '2,0': 'GRAY', '2,1': 'GRAY', '2,2': 'GRAY', '2,3': 'GRAY' })));
    w = state.wilds[0];
    assert.equal(w.id, id, 'same wild');
    assert.equal(w.stage, STAGE.EXPANDING);
    assert.equal(w.startRow, 1);
    assert.ok(w.occupied.includes(1), 'original cell stays occupied');
    for (const row of w.occupied) { assert.equal(r.out.grid[2][row], 'W2'); assert.equal(r.out.drawn[2][row], null, 'locked cells are not redrawn'); }
    sizes.push(w.occupied.length);
  }
  assert.deepEqual(sizes, [2, 3]);

  // Spin 4: fills the column, counts as a full wild reel, then is removed
  ({ r, state } = spin(state, grid()));
  assert.ok(r.out.events.some((e) => e.type === 'full' && e.id === id));
  assert.ok(r.out.events.some((e) => e.type === 'vanish' && e.id === id));
  assert.deepEqual(r.out.grid[2], ['W2', 'W2', 'W2', 'W2'], 'full column on the completing spin');
  assert.equal(r.out.completed[0].stage, STAGE.REMOVED);
  assert.deepEqual(r.out.completed[0].occupied, []);
  assert.equal(state.wilds.length, 0, 'removed from the active state');

  // Spin 5: the column is back to normal
  ({ r, state } = spin(state, grid()));
  assert.deepEqual(r.out.grid[2], DEAD[2]);
  assert.equal(state.wilds.length, 0);
});

test('a completed wild was never removed early and never stayed late', () => {
  let s = fresh(), life = {};
  for (let i = 0; i < 4000; i++) {
    const r = runGame('moonridge', s, 'spin', { stake: 100 }, ctx(9000 + i));
    for (const w of r.out.landed) life[w.id] = { landed: r.out.spin };
    for (const w of r.out.completed) {
      assert.equal(r.out.spin - life[w.id].landed, 3, 'fills on the 3rd spin after landing');
      assert.deepEqual(r.out.grid[w.reel], Array(4).fill(w.kind));
      delete life[w.id];
    }
    for (const w of r.state.wilds) {
      assert.ok(w.occupied.length < 4, 'no full column carries over');
      assert.equal(w.occupied.length, r.out.spin - w.landedSpin + 1, 'one cell per spin');
    }
    s = r.state;
  }
});

test('multiple wilds: independent ids, progress and removal', () => {
  let s = fresh();
  let { r, state } = spin(s, grid({ '1,3': 'W3' }));        // spin 1: reel 2
  const a = state.wilds[0].id;
  ({ r, state } = spin(state, grid({ '3,0': 'WG' })));      // spin 2: reel 4
  const b = state.wilds.find((w) => w.reel === 3).id;
  assert.notEqual(a, b);
  assert.deepEqual(state.wilds.map((w) => [w.reel, w.occupied.length]).sort(), [[1, 2], [3, 1]]);
  ({ r, state } = spin(state, grid()));                     // spin 3
  assert.deepEqual(state.wilds.map((w) => [w.reel, w.occupied.length]).sort(), [[1, 3], [3, 2]]);
  ({ r, state } = spin(state, grid()));                     // spin 4: reel 2 completes
  assert.ok(r.out.completed.some((w) => w.id === a));
  assert.deepEqual(state.wilds.map((w) => [w.id, w.occupied.length]), [[b, 3]], 'reel 4 wild keeps its progress');
  assert.equal(state.wilds[0].startRow, 0);
  ({ r, state } = spin(state, grid()));                     // spin 5: reel 4 completes
  assert.ok(r.out.completed.some((w) => w.id === b));
  assert.equal(state.wilds.length, 0);
});

test('several wilds landing on the same spin each run their own cycle', () => {
  let { r, state } = spin(fresh(), grid({ '0,0': 'W2', '2,3': 'W3', '4,1': 'WG' }));
  assert.equal(r.out.landed.length, 3);
  assert.equal(new Set(state.wilds.map((w) => w.id)).size, 3);
  for (let k = 0; k < 3; k++) ({ r, state } = spin(state, grid()));
  assert.equal(r.out.completed.length, 3);
  assert.equal(state.wilds.length, 0);
});

test('a new expanding wild on a reel that already has one becomes a plain wild', () => {
  let { state } = spin(fresh(), grid({ '2,0': 'W2' }));
  const { r, state: s2 } = spin(state, grid({ '2,3': 'W3' }));
  assert.equal(s2.wilds.length, 1);
  assert.equal(r.out.grid[2][3], 'WILD');
  assert.equal(r.out.landed.length, 0);
});

test('state machine refuses illegal or repeated transitions', () => {
  const w = createWild({ id: 1, reel: 0, row: 0, kind: 'W2', mult: 2, spin: 1, rows: 4 });
  assert.throws(() => advance([w], 2, 4), WildStateError, 'cannot grow before locking');
  settle([w], 1);
  assert.equal(w.stage, STAGE.LOCKED);
  assert.throws(() => settle([w], 1), WildStateError, 'cannot lock twice');
  advance([w], 2, 4);
  assert.throws(() => advance([w], 2, 4), WildStateError, 'cannot grow twice on one spin');
  advance([w], 3, 4); advance([w], 4, 4);
  assert.equal(w.stage, STAGE.FULL_COLUMN);
  assert.throws(() => advance([w], 5, 4), WildStateError, 'a full column cannot grow');
  assert.deepEqual(settle([w], 4), []);
  assert.equal(w.stage, STAGE.REMOVED);
  assert.deepEqual(w.trail.map(([s]) => s), ['LANDING', 'LOCKED', 'EXPANDING', 'EXPANDING', 'EXPANDING', 'FULL_COLUMN', 'DISAPPEARING', 'REMOVED']);
});

test('paytable: every symbol pays its published value for 3, 4 and 5', () => {
  for (const [sym, pays] of Object.entries(PAYTABLE)) {
    for (let n = 3; n <= 5; n++) {
      const s = DEAD.map((c) => c.slice());
      for (let r = 0; r < n; r++) s[r][0] = sym;
      if (n < 5) s[n][0] = 'BONUS';
      const m = s.map(() => [1, 1, 1, 1]);
      const ev = evaluate(s, m, 10000);
      const line0 = ev.wins.find((w) => w.line === 0);
      assert.equal(line0.amount, pays[n - 3] * 100, `${sym} x${n}`);
    }
  }
});

test('wild multipliers multiply each other on a line; plain wilds substitute', () => {
  const s = DEAD.map((c) => c.slice());
  s[0][0] = 'GRAY'; s[1][0] = 'W2'; s[2][0] = 'W3'; s[3][0] = 'WILD'; s[4][0] = 'GRAY';
  const m = s.map(() => [1, 1, 1, 1]); m[1][0] = 2; m[2][0] = 3;
  const w = evaluate(s, m, 100).wins.find((x) => x.line === 0);
  assert.equal(w.symbol, 'GRAY'); assert.equal(w.count, 5); assert.equal(w.mult, 6);
  assert.equal(w.amount, Math.floor(100 * PAYTABLE.GRAY[2] * 6 / 100));
});

test('bonus symbols pay anywhere, start 20 free spins, and add spins in the round', () => {
  let { r, state } = spin(fresh(), grid({ '0,0': 'BONUS', '2,2': 'BONUS', '4,3': 'BONUS' }));
  assert.equal(r.out.scatter.win, SCATTER_PAY[3]);
  assert.equal(r.trigger.freeSpins, FREE_SPINS);
  assert.equal(state.free.remaining, FREE_SPINS);
  ({ r, state } = spin(state, grid({ '1,1': 'BONUS', '3,0': 'BONUS' })));
  assert.equal(state.free.remaining, FREE_SPINS - 1 + 2);
  assert.equal(r.trigger.extra, 2);
});

test('jackpots: the same coin on 3+ adjacent reels, highest tier only', () => {
  const s = DEAD.map((c) => c.slice());
  s[1][2] = 'J1'; s[2][0] = 'J1'; s[3][3] = 'J1';
  assert.equal(evaluate(s, s.map(() => [1, 1, 1, 1]), 100).jackpot.win, JACKPOTS[0].pay);
  s[2][0] = 'J2';
  assert.equal(evaluate(s, s.map(() => [1, 1, 1, 1]), 100).jackpot, null, 'mixed coins do not pay');
  for (let r = 0; r < 5; r++) s[r][1] = 'J5';
  for (let r = 0; r < 5; r++) for (let k = 0; k < 4; k++) if (k !== 1 && s[r][k][0] === 'J') s[r][k] = 'Q';
  const jp = evaluate(s, s.map(() => [1, 1, 1, 1]), 100).jackpot;
  assert.equal(jp.name, 'Grand'); assert.equal(jp.win, 125000); assert.equal(jp.reels.length, 5);
});

test('wins are capped at 5,666x the stake', () => {
  // Four full x3 columns: huge line wins
  const st = fresh();
  st.wilds = [0, 1, 2, 3].map((reel, i) => { const w = createWild({ id: i + 1, reel, row: 0, kind: 'W3', mult: 3, spin: 1, rows: 4 }); settle([w], 1); advance([w], 2, 4); advance([w], 3, 4); return w; });
  st.spin = 3; st.nextId = 5;
  const { r } = spin(st, grid({ '4,0': 'GRAY', '4,1': 'GRAY', '4,2': 'GRAY', '4,3': 'GRAY' }));
  assert.equal(r.win, 100 * MAX_WIN_X);
  assert.equal(r.capped, true);
});

test('real API: charges, pays whole pence, free spins are free, wild state persists', () => {
  let st = null, paid = 0, frees = 0, features = 0, n = 0;
  while (n < 6000 || st?.free) {
    const wasFree = !!st?.free;
    const r = runGame('moonridge', st, 'spin', { stake: 100 }, ctx(77 + n + frees));
    if (wasFree) { assert.equal(r.stake, 0); frees++; } else { assert.equal(r.stake, 100); n++; }
    assert.ok(Number.isSafeInteger(r.payout) && r.payout >= 0);
    assert.equal(r.payout, r.out.win);
    assert.ok(r.payout <= 100 * MAX_WIN_X);
    const sum = r.out.wins.reduce((a, w) => a + w.amount, 0) + r.out.scatter.win + (r.out.jackpot?.win || 0);
    assert.equal(r.payout, Math.min(sum, 100 * MAX_WIN_X), 'payout is exactly the evaluated wins');
    // every occupied cell shows its wild
    for (const w of r.out.after) for (const row of w.occupied) assert.equal(r.out.grid[w.reel][row], w.kind);
    if (r.events[0].feature) features++;
    paid += r.stake; st = r.state;
  }
  assert.equal(paid, 6000 * 100);
  assert.ok(features > 0 && frees > 0);
});

test('stakes are validated and the same random numbers give the same spin', () => {
  assert.throws(() => runGame('moonridge', null, 'spin', { stake: 5 }, ctx()), /at least/);
  assert.throws(() => runGame('moonridge', null, 'spin', { stake: 10001 }, ctx()), /at most/);
  assert.deepEqual(runGame('moonridge', null, 'spin', { stake: 200 }, ctx(42)).out, runGame('moonridge', null, 'spin', { stake: 200 }, ctx(42)).out);
});
