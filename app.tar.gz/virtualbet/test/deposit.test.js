// Free virtual deposits: any whole-pound amount from £5 to £1,000 (slider).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const { openDb, q } = await import('../server/db.js');
const { freeDeposit } = await import('../server/wallet.js');
openDb(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'vbdep-')), 'test.db'));
const uid = Number(q("INSERT INTO users (username, password_hash, balance, created_at) VALUES ('dep', 'x', 0, 0)").run().lastInsertRowid);
const bal = () => q('SELECT balance FROM users WHERE id = ?').get(uid).balance;

test('deposit slider amounts: £5 to £1,000 in whole pounds', () => {
  for (const ok of [500, 3700, 10_000, 54_300, 100_000]) freeDeposit(uid, { amount: ok, acknowledged: true });
  assert.equal(bal(), 500 + 3700 + 10_000 + 54_300 + 100_000);
  for (const bad of [400, 3750, 100_100, 1_000_000, -500, 0, 37.5, '2000', null]) {
    assert.throws(() => freeDeposit(uid, { amount: bad, acknowledged: true }), /whole-pound amount/, String(bad));
  }
  assert.throws(() => freeDeposit(uid, { amount: 2000, acknowledged: false }), /virtual money/);
  assert.equal(bal(), 168_500);
});
