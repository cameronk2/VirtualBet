import { test } from 'node:test';
import assert from 'node:assert/strict';
import { FISH_VALUES, PAYTABLE, spin } from '../server/slots.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);

test('Lakeside paytable: three low symbols return half the stake, pays rise with symbol and count', () => {
  for (const s of ['10', 'J', 'Q', 'K', 'A']) assert.equal(PAYTABLE[s][0], 50); // 0.5x total stake
  for (const [s, p] of Object.entries(PAYTABLE)) assert.ok(p[0] < p[1] && p[1] < p[2], s);
  assert.ok(PAYTABLE.BOAT[2] > PAYTABLE.ROD[2] && PAYTABLE.ROD[2] > PAYTABLE.BOX[2] && PAYTABLE.BOX[2] > PAYTABLE.A[2]);
});

test('Lakeside fish values: 2x to 500x, mean 8.2x (solved for a 96% return)', () => {
  const vals = FISH_VALUES.map(([v]) => v);
  assert.equal(Math.min(...vals), 200);
  assert.equal(Math.max(...vals), 50000);
  const w = FISH_VALUES.reduce((a, [, x]) => a + x, 0);
  const mean = FISH_VALUES.reduce((a, [v, x]) => a + v * x, 0) / w / 100;
  assert.ok(Math.abs(mean - 8.2) < 0.01, `mean ${mean}`);
});

test('Lakeside pays scale exactly with the stake (every denomination)', () => {
  for (let k = 1; k <= 3000; k++) {
    const a = spin(100, seeded(k)), b = spin(1000, seeded(k)), c = spin(50000, seeded(k));
    assert.equal(b.win, a.win * 10);
    assert.equal(c.win, a.win * 500);
    for (const w of a.wins) assert.equal(w.amount, PAYTABLE[w.symbol][w.count - 3]); // at £1, pence == hundredths
  }
});
