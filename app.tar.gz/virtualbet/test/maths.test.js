import { test } from 'node:test';
import assert from 'node:assert/strict';
import { potentialReturn, combinedOddsX100 } from '../server/money.js';
import { settleSelection, priceMarkets, lambdasFor } from '../server/markets.js';

test('single bet: 500 @ 2.00 returns 1,000', () => {
  assert.equal(potentialReturn(500, [200]), 1000);
});

test('accumulator: 1.80 x 2.00 x 1.50 = 5.40, 100 stake returns 540', () => {
  assert.equal(combinedOddsX100([180, 200, 150]), 540);
  assert.equal(potentialReturn(100, [180, 200, 150]), 540);
});

test('returns round down to whole tokens, no float error', () => {
  assert.equal(potentialReturn(33, [173]), 57); // 57.09
  assert.equal(potentialReturn(10, [101, 101, 101]), 10); // 10.303
  assert.equal(potentialReturn(5000, Array(20).fill(150)), Math.floor(5000 * 1.5 ** 20));
});

test('void legs are removed from an accumulator', () => {
  assert.equal(potentialReturn(100, [180, 150]), 270); // 2.00 leg voided
  assert.equal(potentialReturn(100, []), 100); // everything void -> stake back
});

const R = (h, a, hth = 0, hta = 0, extra = {}) => ({ ft: [h, a], ht: [hth, hta], goalOrder: null, corners: null, cards: null, ...extra });

test('match result & double chance settle correctly', () => {
  assert.equal(settleSelection('1X2', '1', R(2, 1)), 'WON');
  assert.equal(settleSelection('1X2', 'X', R(2, 1)), 'LOST');
  assert.equal(settleSelection('DC', 'X2', R(1, 1)), 'WON');
  assert.equal(settleSelection('DC', '12', R(1, 1)), 'LOST');
});

test('draw no bet voids on a draw', () => {
  assert.equal(settleSelection('DNB', '1', R(0, 0)), 'VOID');
  assert.equal(settleSelection('DNB', '2', R(0, 1)), 'WON');
});

test('goals markets', () => {
  assert.equal(settleSelection('OU25', 'O', R(2, 1)), 'WON');
  assert.equal(settleSelection('OU25', 'U', R(2, 1)), 'LOST');
  assert.equal(settleSelection('OU05', 'U', R(0, 0)), 'WON');
  assert.equal(settleSelection('BTTS', 'Y', R(1, 1)), 'WON');
  assert.equal(settleSelection('BTTS', 'N', R(3, 0)), 'WON');
  assert.equal(settleSelection('HG', '3+', R(4, 0)), 'WON');
  assert.equal(settleSelection('AG', '0', R(4, 0)), 'WON');
});

test('half time, HT/FT and correct score', () => {
  assert.equal(settleSelection('HT1X2', 'X', R(2, 1, 0, 0)), 'WON');
  assert.equal(settleSelection('HTFT', 'X/1', R(2, 1, 0, 0)), 'WON');
  assert.equal(settleSelection('HTFT', '1/1', R(2, 1, 0, 0)), 'LOST');
  assert.equal(settleSelection('CS', '2-1', R(2, 1)), 'WON');
  assert.equal(settleSelection('CS', 'OTH1', R(5, 1)), 'WON');
  assert.equal(settleSelection('CS', 'OTH1', R(3, 1)), 'LOST');
  assert.equal(settleSelection('HT1X2', '1', { ft: [1, 0], ht: null }), null); // no verified HT score -> wait
});

test('team-to-score markets need a verified goal order', () => {
  assert.equal(settleSelection('FTS', 'N', R(0, 0)), 'WON');
  assert.equal(settleSelection('FTS', '1', R(1, 1)), null);
  assert.equal(settleSelection('FTS', '2', R(1, 1, 0, 0, { goalOrder: ['2', '1'] })), 'WON');
  assert.equal(settleSelection('LTS', '1', R(1, 1, 0, 0, { goalOrder: ['2', '1'] })), 'WON');
  assert.equal(settleSelection('NG3', 'N', R(1, 1)), 'WON');
  assert.equal(settleSelection('NG2', '1', R(1, 1, 0, 0, { goalOrder: ['2', '1'] })), 'WON');
  assert.equal(settleSelection('FTS', '1', R(2, 0, 0, 0, { goalOrder: ['1'] })), null); // inconsistent order rejected
});

test('corners & cards wait for data', () => {
  assert.equal(settleSelection('CRN95', 'O', R(1, 0)), null);
  assert.equal(settleSelection('CRN95', 'O', R(1, 0, 0, 0, { corners: 11 })), 'WON');
  assert.equal(settleSelection('CRD35', 'U', R(1, 0, 0, 0, { cards: 3 })), 'WON');
});

test('odds engine produces sane, margin-included prices', () => {
  const row = {
    id: 't', status: 'SCHEDULED', minute: null, home_score: null, away_score: null, ht_home: null, ht_away: null,
    home_corners: null, away_corners: null, home_cards: null, away_cards: null, goal_order: null,
    ...lambdasFor(0.2, 0), caps: { goalOrder: true, corners: true, cards: true }, home_name: 'Home', away_name: 'Away', source: 'demo',
  };
  const mk = priceMarkets(row);
  const r = mk.find((m) => m.key === '1X2');
  const book = r.selections.reduce((a, s) => a + 100 / s.odds, 0);
  assert.ok(book > 1.03 && book < 1.09, `overround ${book}`);
  for (const m of mk) for (const s of m.selections) if (s.odds) assert.ok(s.odds >= 101);

  // In play at 2-0 in the 80th minute the home win is near-certain -> withdrawn; next goal market exists
  const live = priceMarkets({ ...row, status: 'LIVE_2H', minute: 80, home_score: 2, away_score: 0, ht_home: 1, ht_away: 0, goal_order: '["1","1"]', home_corners: 4, away_corners: 3, home_cards: 1, away_cards: 2 });
  assert.ok(live.some((m) => m.key === 'NG3'));
  assert.ok(!live.some((m) => m.key === 'HT1X2'));
  assert.ok(!live.some((m) => m.key === 'OU15'));
  assert.equal(priceMarkets({ ...row, status: 'FINISHED' }).length, 0);
});

import { handValue, startRound, act, allowed, perfectPairs, twentyOnePlus3 } from '../server/blackjack.js';
test('blackjack: values, side bets, splits and payouts', () => {
  assert.deepEqual(handValue(['AS', 'KH']), { total: 21, soft: true });
  assert.equal(handValue(['AS', 'AH', '9C']).total, 21);
  assert.equal(handValue(['KS', 'QH', '5C']).total, 25);
  assert.equal(perfectPairs('8H', '8H'), 'perfect');
  assert.equal(perfectPairs('8H', '8D'), 'coloured');
  assert.equal(perfectPairs('8H', '8S'), 'mixed');
  assert.equal(perfectPairs('8H', '9H'), null);
  assert.equal(twentyOnePlus3(['QH', 'KH', 'AH']), 'straightFlush');
  assert.equal(twentyOnePlus3(['2C', '3D', 'AH']), 'straight');
  assert.equal(twentyOnePlus3(['7C', '7C', '7C']), 'suitedTrips');
  assert.equal(twentyOnePlus3(['7C', '7D', '7H']), 'trips');
  assert.equal(twentyOnePlus3(['2H', '9H', 'KH']), 'flush');
  let seed = 7;
  const rand = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  let splits = 0;
  for (let i = 0; i < 3000; i++) {
    const s = startRound([{ bet: 1000, pp: 100, t213: 100 }, { bet: 500 }], rand);
    let staked = 1700, guard = 0;
    while (s.status === 'player' && guard++ < 40) {
      const ok = allowed(s);
      const a = ok.split ? 'split' : ok.double && i % 4 === 0 ? 'double' : handValue(s.seats[s.active.seat].hands[s.active.hand].cards).total < 15 ? 'hit' : 'stand';
      if (a === 'split' || a === 'double') staked += s.seats[s.active.seat].hands[s.active.hand].bet;
      if (a === 'split') splits++;
      act(s, a);
    }
    assert.equal(s.status, 'done');
    assert.equal(s.totalStaked, staked);
    let expected = 0;
    for (const seat of s.seats) {
      for (const h of seat.hands) expected += { blackjack: h.bet + Math.floor(h.bet * 1.5), win: h.bet * 2, push: h.bet, lose: 0, bust: 0 }[h.result];
      expected += (seat.side.pp?.payout || 0) + (seat.side.t213?.payout || 0);
    }
    assert.equal(s.totalPayout, expected);
  }
  assert.ok(splits > 50);
});

import { WHEEL } from '../server/blackjack.js';
test('spin 21 side bet: wheel on blackjack, ace saver, payouts', () => {
  let seed = 11;
  const rand = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  let wheels = 0, aces = 0;
  for (let i = 0; i < 20000; i++) {
    const s = startRound([{ bet: 500, spin: 500 }], rand);
    const sp = s.seats[0].side.spin;
    const [a, b] = s.seats[0].hands[0].cards;
    const bj = handValue([a, b]).total === 21;
    if (bj) {
      wheels++;
      assert.equal(sp.result, 'wheel');
      const last = WHEEL[sp.spins[sp.spins.length - 1]];
      assert.ok(!last.respin);
      assert.equal(sp.x, last.x * sp.mult);
      assert.equal(sp.payout, 500 * (sp.x + 1));
    } else if (a.startsWith('A') || b.startsWith('A')) { aces++; assert.equal(sp.payout, 500); }
    else assert.equal(sp.payout, 0);
    assert.equal(s.totalStaked, 1000);
  }
  assert.ok(wheels > 700 && aces > 1500);
});
