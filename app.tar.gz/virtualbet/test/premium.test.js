// The five premium slots: rules, bonus flows and money integrity.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { waysWins, NE_SYMS } from '../server/games/slots3.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (seed = 1) => ({ rand: seeded(seed), now: 0, minStake: 10, maxStake: 50000 });
const GAMES = ['atlantis', 'neon', 'dragon', 'cosmic', 'pharaoh', 'frost'];

function play(id, spins, seed = 7, stake = 100) {
  const c = ctx(seed);
  let st = null, paid = 0, won = 0, maxX = 0, frees = 0, features = 0;
  for (let n = 0; n < spins || st?.free || st?.bonus;) {
    let r;
    if (st?.bonus) {
      const left = [...Array(12).keys()].filter((k) => !st.bonus.picked.includes(k));
      r = runGame(id, st, 'pick', { index: left[0] }, c);
    } else {
      const wasFree = !!st?.free;
      r = runGame(id, st, 'spin', { stake }, c);
      if (wasFree) { assert.equal(r.stake, 0, `${id}: free spins cost nothing`); frees++; } else { assert.equal(r.stake, stake, `${id}: paid spin charges the stake`); n++; }
    }
    assert.ok(Number.isSafeInteger(r.payout) && r.payout >= 0, `${id}: payout is whole pence`);
    assert.equal(r.payout, r.out.win ?? r.payout, `${id}: payout matches the shown win`);
    if (r.stake) maxX = Math.max(maxX, r.payout / r.stake);
    if (r.events?.[0]?.feature) features++;
    st = r.state; paid += r.stake; won += r.payout;
  }
  return { paid, won, maxX, frees, features };
}

test('every premium slot charges, pays and runs its features cleanly', () => {
  for (const id of GAMES) {
    const r = play(id, 4000, 11);
    assert.ok(r.paid === 4000 * 100, `${id} paid`);
    assert.ok(r.maxX <= 5000, `${id} respects the 5,000x cap`);
    assert.ok(r.features > 0, `${id} triggered a feature`);
  }
});

test('same random numbers give the same result (no hidden randomness)', () => {
  for (const id of GAMES) {
    const a = runGame(id, null, 'spin', { stake: 200 }, ctx(42)), b = runGame(id, null, 'spin', { stake: 200 }, ctx(42));
    assert.deepEqual(a.out, b.out, id);
  }
});

test('stakes are validated', () => {
  for (const id of GAMES) {
    assert.throws(() => runGame(id, null, 'spin', { stake: 5 }, ctx()), /at least/);
    assert.throws(() => runGame(id, null, 'spin', { stake: 10001 }, ctx()), /at most/);
    assert.throws(() => runGame(id, null, 'spin', { stake: 12.5 }, ctx()), /at least/);
  }
});

test('Atlantis treasure: hidden contents, no spinning mid-bonus, valid picks only, jackpot and free spins', () => {
  const items = [{ k: 'trident' }, { k: 'trident' }, { k: 'trident' }, { k: 'free', spins: 8 }, { k: 'coin', x: 500 }, { k: 'collect' }, { k: 'collect' }, ...Array(5).fill({ k: 'coin', x: 100 })];
  let st = { free: null, bonus: { bet: 100, items, picked: [], tridents: 0, total: 0, freeSpins: 0, chestMult: 1 }, recent: [] };
  assert.throws(() => runGame('atlantis', st, 'spin', { stake: 100 }, ctx()), /treasure/i);
  assert.throws(() => runGame('atlantis', st, 'pick', { index: 12 }, ctx()), /closed chest/);
  let r = runGame('atlantis', st, 'pick', { index: 0 }, ctx());
  assert.equal(r.payout, 0);
  st = r.state;
  assert.throws(() => runGame('atlantis', st, 'pick', { index: 0 }, ctx()), /closed chest/, 'cannot pick the same chest twice');
  r = runGame('atlantis', st, 'pick', { index: 1 }, ctx()); st = r.state;
  r = runGame('atlantis', st, 'pick', { index: 2 }, ctx()); st = r.state;
  assert.equal(r.out.jackpot, 50000, "Poseidon's Jackpot is 500x");
  r = runGame('atlantis', st, 'pick', { index: 3 }, ctx()); st = r.state;
  r = runGame('atlantis', st, 'pick', { index: 5 }, ctx());
  assert.equal(r.out.done, true);
  assert.equal(r.payout, 50000, 'pays once, at the end');
  assert.equal(r.state.bonus, null);
  assert.equal(r.state.free.remaining, 8);
  assert.throws(() => runGame('atlantis', r.state, 'pick', { index: 6 }, ctx()), /no treasure/);
});

test('Atlantis view hides sealed chests', async () => {
  const { atlantis } = await import('../server/games/slots3.js');
  const st = { free: null, bonus: { bet: 100, items: Array(12).fill({ k: 'coin', x: 100 }), picked: [3], tridents: 0, total: 447, freeSpins: 0, chestMult: 1 }, recent: [] };
  const v = atlantis.view(st);
  assert.equal(v.bonus.items, undefined);
  assert.equal(v.bonus.picked.length, 1);
});

test('Neon ways: counts every combination across adjacent reels', () => {
  const g = (rows) => rows.map((col) => col.map((s) => ({ s })));
  const grid = g([['NODE', 'NODE', 'CHIP', 'DISC'], ['NODE', 'WILD', 'CHIP', 'DISC'], ['VISOR', 'NODE', 'CHIP', 'DISC'], ['BIKE', 'BIKE', 'BIKE', 'BIKE'], ['DRONE', 'DRONE', 'DRONE', 'DRONE']]);
  const pt = { NODE: [10, 20, 30], CHIP: [10, 20, 30], DISC: [10, 20, 30], CORE: [1, 1, 1], VISOR: [1, 1, 1], DRONE: [1, 1, 1], BIKE: [1, 1, 1], ANDROID: [1, 1, 1] };
  const w = waysWins(grid, 100, pt, NE_SYMS);
  const node = w.find((x) => x.symbol === 'NODE');
  assert.equal(node.ways, 2 * 2 * 1);
  assert.equal(node.amount, Math.floor((100 * 10 * 4) / 100));
  assert.ok(w.find((x) => x.symbol === 'CHIP').ways === 2, 'wild counts for CHIP too');
});

test('Cosmic tumbles end on a step with no wins, and removed cells are winners or wilds', () => {
  for (let s = 1; s < 400; s++) {
    const r = runGame('cosmic', null, 'spin', { stake: 100 }, ctx(s));
    const steps = r.out.steps;
    assert.equal(steps[steps.length - 1].wins.length, 0);
    for (const st of steps) for (const [c, row] of st.removed) {
      const cell = st.grid[c][row].s;
      assert.ok(cell === 'WILD' || st.wins.some((w) => w.symbol === cell));
    }
  }
});

test('Pharaoh mystery stacks all reveal the same symbol; multiplier comes from the reel', () => {
  let seen = 0;
  for (let s = 1; s < 600; s++) {
    const r = runGame('pharaoh', null, 'spin', { stake: 100 }, ctx(s));
    if (r.out.mystery.length) {
      seen++;
      const revealed = r.out.mystery.map(([reel, row]) => r.out.grid[reel][row].s);
      assert.ok(revealed.every((x) => x === r.out.reveal));
    }
    assert.ok(r.out.reelVals.includes(r.out.mult));
  }
  assert.ok(seen > 0);
});

test('Dragon wilds fill their reel and stick through free spins', () => {
  let st = { free: { bet: 100, remaining: 3, total: 0, sticky: [2] }, recent: [] };
  for (let i = 0; i < 3; i++) {
    const r = runGame('dragon', st, 'spin', {}, ctx(100 + i));
    assert.equal(r.stake, 0);
    assert.ok(r.out.grid[2].every((c) => c.s === 'DRAGON'), 'sticky reel stays wild');
    for (const reel of r.out.expanded) assert.ok(r.out.grid[reel].every((c) => c.s === 'DRAGON'));
    st = r.state;
    if (st.free) assert.ok(st.free.sticky.includes(2));
  }
  assert.equal(st.free, null, 'round ends');
});

test('Frostfang: wilds expand, hold through Howl Respins, grow, and multiply by their sum', async () => {
  const { FR_MAX_MULT, LINES_40 } = await import('../server/games/slots3.js');
  let respins = 0, grew = 0;
  for (let seed = 1; seed < 3000; seed++) {
    const r = runGame('frost', null, 'spin', { stake: 100 }, ctx(seed));
    const steps = r.out.steps;
    steps.forEach((st, i) => {
      for (const reel of Object.keys(st.wilds)) assert.ok(st.grid[reel].every((c) => c.s === 'WILD'), 'wild reels are fully wild');
      assert.ok(!st.wilds[0], 'reel 1 is never wild');
      if (i > 0) {
        respins++;
        for (const reel of steps[i - 1].held.concat(Object.keys(steps[i - 1].wilds).map(Number))) assert.ok(st.held.includes(Number(reel)), 'wild reels stay put through respins');
        assert.ok(steps[i - 1].fresh.length > 0, 'respins only follow new wilds');
      }
      for (const [reel, m] of Object.entries(st.before)) {
        const expect = Math.min(FR_MAX_MULT, m + st.fresh.length);
        assert.equal(st.wilds[reel], expect, 'each new wild adds +1 to standing wilds');
        if (st.wilds[reel] > m) grew++;
      }
      for (const w of st.wins) {
        const sum = Object.entries(st.wilds).filter(([reel]) => Number(reel) < w.count).reduce((a, [, v]) => a + v, 0);
        if (sum) assert.equal(w.amount, w.base * sum, 'line multiplier is the sum of the wild reels on it');
        assert.ok(LINES_40[w.line]);
      }
    });
    assert.equal(r.payout, Math.min(r.out.steps.reduce((a, st) => a + st.win, 0), 100 * 5000));
  }
  assert.ok(respins > 100 && grew > 50, `respins ${respins}, growth ${grew}`);
});

test('Frostfang free spins keep their wilds for the whole round', () => {
  let st = { free: { bet: 100, remaining: 5, total: 0, wilds: { 2: 3 } }, recent: [] };
  for (let i = 0; i < 5; i++) {
    const r = runGame('frost', st, 'spin', {}, ctx(500 + i));
    assert.equal(r.stake, 0);
    assert.ok(r.out.steps[0].grid[2].every((c) => c.s === 'WILD'));
    assert.ok(r.out.steps[0].wilds[2] >= 3);
    st = r.state;
    if (st.free) assert.ok(st.free.wilds[2] >= 3, 'wild reel persists');
  }
  assert.equal(st.free, null);
});
