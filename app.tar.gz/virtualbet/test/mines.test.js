// Gem Mines: the multiplier formula, board generation, every state and money safety.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { act, init, view } from '../server/games/mines/engine.js';
import { RTP, TILES, multiplier, schedule, survival } from '../server/games/mines/config.js';

let seed = 99;
const rnd = () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (extra = {}) => ({ rand: rnd, now: 1_700_000_000_000, minStake: 10, maxStake: 50000, ...extra });
const start = (mines = 3, stake = 100) => act(init(), 'start', { stake, mines }, ctx());
const safeTiles = (st) => st.round.board.map((b, i) => (b ? -1 : i)).filter((i) => i >= 0 && !st.round.picks.includes(i));
const mineTile = (st) => st.round.board.indexOf(1);

test('multipliers follow RTP / P(survival) for every mine count 1-24 and every reveal', () => {
  for (let m = 1; m <= 24; m++) {
    let prev = 0;
    for (let k = 1; k <= TILES - m; k++) {
      let p = 1; for (let i = 0; i < k; i++) p *= (25 - m - i) / (25 - i);
      assert.ok(Math.abs(survival(m, k) - p) < 1e-15);
      const exact = RTP / p, x = multiplier(m, k);
      assert.ok(x <= exact + 1e-6 && x > exact - 0.0100001, `M=${m} k=${k}: ${x} vs ${exact}`);
      assert.ok(x > prev, 'rises with every reveal'); prev = x;
      assert.ok(p * x <= RTP + 1e-9, 'never pays more than the RTP');
    }
    if (m > 1) assert.ok(multiplier(m, 1) > multiplier(m - 1, 1), 'more mines pay more');
  }
  assert.equal(multiplier(1, 1), 1.01); assert.equal(multiplier(3, 1), 1.10); assert.equal(multiplier(24, 1), 24.25);
  assert.equal(schedule(5).length, 20);
});

test('the board has exactly M mines, no duplicates, and stays hidden from the view', () => {
  for (let m = 1; m <= 24; m++) {
    const r = start(m);
    assert.equal(r.state.round.board.length, 25);
    assert.equal(r.state.round.board.filter(Boolean).length, m);
    const v = JSON.stringify(r.out) + JSON.stringify(view(r.state));
    assert.ok(!v.includes('board'), 'board never leaves the server during a round');
  }
});

test('mine placement is uniform (no predictable pattern)', () => {
  const counts = Array(25).fill(0), n = 20000;
  for (let i = 0; i < n; i++) start(5).state.round.board.forEach((b, t) => { counts[t] += b; });
  const exp = n * 5 / 25;
  for (const c of counts) assert.ok(Math.abs(c - exp) < 5 * Math.sqrt(exp), `tile count ${c} vs ${exp}`);
});

test('reveal gems, cash out after one and after several; payout = bet × multiplier, once', () => {
  let r = start(3, 250);
  assert.equal(r.stake, 250);
  assert.throws(() => act(r.state, 'cashout', {}, ctx()), /at least one gem/);
  r = act(r.state, 'reveal', { tile: safeTiles(r.state)[0] }, ctx());
  assert.equal(r.out.gem, true); assert.equal(r.out.mult, multiplier(3, 1)); assert.equal(r.stake, 0); assert.equal(r.payout, 0);
  let c = act(r.state, 'cashout', {}, ctx());
  assert.equal(c.payout, Math.floor(250 * multiplier(3, 1)));
  assert.throws(() => act(c.state, 'cashout', {}, ctx()), /no round/, 'no double cash-out');
  for (let i = 0; i < 4; i++) r = act(r.state, 'reveal', { tile: safeTiles(r.state)[0] }, ctx());
  c = act(r.state, 'cashout', {}, ctx());
  assert.equal(c.out.gems, 5); assert.equal(c.payout, Math.floor(250 * multiplier(3, 5)));
  const h = c.state.recent[0];
  assert.deepEqual([h.bet, h.mines, h.gems, h.mult, h.result, h.payout, h.at], [250, 3, 5, multiplier(3, 5), 'cashout', c.payout, 1_700_000_000_000]);
  assert.equal(h.board.length, 25);
});

test('hitting a mine loses the bet, reveals the board and ends the round', () => {
  let r = start(10, 100);
  r = act(r.state, 'reveal', { tile: safeTiles(r.state)[0] }, ctx());
  const st = r.state;
  r = act(st, 'reveal', { tile: mineTile(st) }, ctx());
  assert.equal(r.out.mine, true); assert.equal(r.payout, 0); assert.equal(r.out.board.filter(Boolean).length, 10);
  assert.equal(r.state.mode, 'idle'); assert.equal(r.state.recent[0].result, 'mine'); assert.equal(r.state.recent[0].hit, mineTile(st));
  assert.throws(() => act(r.state, 'cashout', {}, ctx()), /no round/);
});

test('finding every gem pays automatically', () => {
  for (const m of [1, 12, 24]) {
    let r = start(m, 100);
    while (r.state.mode === 'run') r = act(r.state, 'reveal', { tile: safeTiles(r.state)[0] }, ctx());
    assert.equal(r.out.cleared, true); assert.equal(r.payout, Math.floor(100 * multiplier(m, 25 - m)));
  }
});

test('invalid requests are refused: second round, same tile twice, bad tiles, bad mines, bad stakes', () => {
  const r = start(3);
  assert.throws(() => act(r.state, 'start', { stake: 100, mines: 5 }, ctx()), /already in play/, 'mine count is locked in a round');
  const t = safeTiles(r.state)[0], r2 = act(r.state, 'reveal', { tile: t }, ctx());
  assert.throws(() => act(r2.state, 'reveal', { tile: t }, ctx()), /already revealed/);
  for (const tile of [-1, 25, 2.5, '3', null]) assert.throws(() => act(r2.state, 'reveal', { tile }, ctx()), /Pick a tile/);
  for (const m of [0, 25, 3.5, '3']) assert.throws(() => act(init(), 'start', { stake: 100, mines: m }, ctx()), /between 1 and 24/);
  for (const stake of [-100, 0, 5, 50001, 12.5]) assert.throws(() => act(init(), 'start', { stake, mines: 3 }, ctx()));
  assert.equal(act(init(), 'start', { stake: 10, mines: 3 }, ctx()).stake, 10);
  assert.equal(act(init(), 'start', { stake: 50000, mines: 3 }, ctx()).stake, 50000);
});

test('a reload mid-round keeps the same board', () => {
  let r = runGame('mines', null, 'start', { stake: 100, mines: 6 }, ctx());
  const saved = JSON.parse(JSON.stringify(r.state)), board = saved.round.board.join('');
  r = runGame('mines', saved, 'reveal', { tile: safeTiles(saved)[0] }, ctx());
  assert.equal(r.state.round.board.join(''), board);
});

test('simulated play returns the RTP for several mine counts and cash-out points', () => {
  for (const [m, k] of [[1, 5], [3, 1], [3, 4], [5, 3], [10, 2], [20, 1]]) {
    let paid = 0, won = 0;
    const n = 40000;
    for (let i = 0; i < n; i++) {
      let r = act(init(), 'start', { stake: 100, mines: m }, ctx()); paid += 100;
      // pick tiles blindly in a random order, as a player would
      const order = Array.from({ length: 25 }, (_, t) => t).sort(() => rnd() - 0.5);
      for (let j = 0; j < k && r.state.mode === 'run'; j++) r = act(r.state, 'reveal', { tile: order[j] }, ctx());
      if (r.state.mode === 'run') r = act(r.state, 'cashout', {}, ctx());
      won += r.payout;
    }
    const p = survival(m, k), sd = Math.sqrt(p * (1 - p) / n) * multiplier(m, k);
    assert.ok(Math.abs(won / paid - RTP) < 4 * sd + 0.01, `M=${m} k=${k}: ${(won / paid).toFixed(4)}`);
  }
});
