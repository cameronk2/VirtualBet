// Keno 40: hypergeometric maths, every payout table, the draw, validation and money.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { act, drawNumbers, init } from '../server/games/keno/engine.js';
import { DRAW, MODES, POOL, TABLES, prob, tableRtp } from '../server/games/keno/config.js';

let seed = 4242;
const rnd = () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (rand = rnd) => ({ rand, now: 1_700_000_000_000, minStake: 10, maxStake: 50000 });
const C = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return r; };

test('probabilities are the hypergeometric distribution and sum to 1', () => {
  for (let n = 1; n <= 10; n++) {
    let sum = 0;
    for (let k = 0; k <= n; k++) { const p = (C(n, k) * C(40 - n, 10 - k)) / C(40, 10); assert.ok(Math.abs(prob(n, k) - p) < 1e-15); sum += prob(n, k); }
    assert.ok(Math.abs(sum - 1) < 1e-12);
  }
  assert.ok(Math.abs(prob(1, 1) - 0.25) < 1e-15);
  assert.ok(Math.abs(prob(10, 10) - 1 / 847660528) < 1e-20);
});

test('every table (2 modes × 10 pick counts) returns its RTP: never more, at most 0.5 points less', () => {
  for (const [id, m] of Object.entries(MODES)) for (let n = 1; n <= 10; n++) {
    const t = TABLES[id][n], r = tableRtp(id, n);
    assert.equal(t.length, n + 1);
    assert.ok(r <= m.rtp + 1e-9 && r > m.rtp - 0.005, `${id} n=${n}: ${r}`);
    for (let k = 0; k <= n; k++) {
      assert.ok(t[k] >= 0 && t[k] <= m.cap, 'within cap');
      if (k < m.kMin[n]) assert.equal(t[k], 0); else assert.ok(t[k] > 0);
      if (k > m.kMin[n]) assert.ok(t[k] >= t[k - 1], 'more matches never pay less');
      assert.ok(Math.abs(Math.round(t[k] * 100) - t[k] * 100) < 1e-6, '2 dp');
    }
  }
});

test('High risk is higher variance: bigger top prizes, fewer paying results', () => {
  for (let n = 2; n <= 10; n++) {
    assert.ok(TABLES.high[n][n] >= TABLES.classic[n][n], `top prize n=${n}`);
    const hit = (id) => TABLES[id][n].reduce((a, x, k) => a + (x > 0 ? prob(n, k) : 0), 0);
    assert.ok(hit('high') <= hit('classic'), `pay chance n=${n}`);
    const varOf = (id) => TABLES[id][n].reduce((a, x, k) => a + prob(n, k) * x * x, 0) - tableRtp(id, n) ** 2;
    assert.ok(varOf('high') > varOf('classic'), `variance n=${n}`);
  }
});

test('the draw: 10 unique numbers from 1-40, every number equally likely', () => {
  const counts = Array(41).fill(0), N = 30000;
  for (let i = 0; i < N; i++) {
    const d = drawNumbers(rnd);
    assert.equal(d.length, DRAW); assert.equal(new Set(d).size, DRAW);
    for (const x of d) { assert.ok(Number.isInteger(x) && x >= 1 && x <= POOL); counts[x]++; }
  }
  const exp = (N * DRAW) / POOL;
  for (let x = 1; x <= 40; x++) assert.ok(Math.abs(counts[x] - exp) < 5 * Math.sqrt(exp), `number ${x}: ${counts[x]}`);
});

test('every pick count and every match count pays bet × table multiplier', () => {
  for (const mode of ['classic', 'quick', 'high']) for (let n = 1; n <= 10; n++) {
    const tid = mode === 'high' ? 'high' : 'classic';
    for (let k = 0; k <= n; k++) {
      // force the draw: the first k picks are drawn, then non-picked numbers
      const picks = Array.from({ length: n }, (_, i) => i + 1);
      const want = [...picks.slice(0, k), ...Array.from({ length: 40 }, (_, i) => i + 1).filter((x) => x > n).slice(0, 10 - k)];
      let i = 0;
      const pool = Array.from({ length: 40 }, (_, j) => j + 1);
      const rigged = () => { const target = want[i]; const idx = pool.indexOf(target, i); const r = (idx - i + 0.5) / (40 - i); [pool[i], pool[idx]] = [pool[idx], pool[i]]; i++; return r; };
      const r = act(init(), 'play', { stake: 250, picks, mode }, ctx(rigged));
      assert.equal(r.out.matches, k, `${mode} n=${n} k=${k}`);
      assert.equal(r.out.mult, TABLES[tid][n][k]);
      assert.equal(r.payout, Math.floor(250 * TABLES[tid][n][k])); assert.equal(r.stake, 250);
      assert.equal(r.state.recent[0].matches, k);
    }
  }
});

test('invalid picks, modes and stakes are refused', () => {
  const bad = [[], Array.from({ length: 11 }, (_, i) => i + 1), [0], [41], [1, 1], [2.5], ['3'], null];
  for (const picks of bad) assert.throws(() => act(init(), 'play', { stake: 100, picks, mode: 'classic' }, ctx()));
  assert.throws(() => act(init(), 'play', { stake: 100, picks: [1], mode: 'turbo' }, ctx()), /mode/);
  for (const stake of [-100, 0, 5, 50001, 1.5]) assert.throws(() => act(init(), 'play', { stake, picks: [1], mode: 'classic' }, ctx()));
  assert.equal(act(init(), 'play', { stake: 10, picks: [1], mode: 'classic' }, ctx()).stake, 10);
  assert.equal(act(init(), 'play', { stake: 50000, picks: [1], mode: 'classic' }, ctx()).stake, 50000);
  assert.throws(() => act(init(), 'reveal', {}, ctx()), /Unknown/);
});

test('history and lifetime statistics come from completed rounds and survive a reload', () => {
  let st = null, wag = 0, paid = 0, big = 0, best = 0;
  for (let i = 0; i < 200; i++) {
    const r = runGame('keno', st, 'play', { stake: 100, picks: [1, 2, 3, 4, 5, 6, 7, 8], mode: i % 2 ? 'high' : 'classic' }, ctx());
    st = JSON.parse(JSON.stringify(r.state));
    wag += r.stake; paid += r.payout; big = Math.max(big, r.payout); best = Math.max(best, r.out.matches);
  }
  assert.deepEqual([st.stats.rounds, st.stats.wagered, st.stats.paid, st.stats.biggestWin, st.stats.bestMatches], [200, wag, paid, big, best]);
  assert.equal(st.recent.length, 30);
  const h = st.recent[0];
  assert.ok(h.at && h.picks.length === 8 && h.drawn.length === 10 && ['win', 'part', 'loss'].includes(h.result));
});

test('simulated play returns the RTP for each mode', () => {
  for (const [mode, n] of [['classic', 1], ['classic', 4], ['classic', 6], ['quick', 3], ['high', 2], ['high', 4]]) {
    let paid = 0, won = 0;
    const N = 60000, picks = Array.from({ length: n }, (_, i) => i * 3 + 1);
    for (let i = 0; i < N; i++) { const r = act(init(), 'play', { stake: 100, picks, mode }, ctx()); paid += r.stake; won += r.payout; }
    const t = TABLES[mode === 'high' ? 'high' : 'classic'][n];
    const ev = tableRtp(mode === 'high' ? 'high' : 'classic', n), sd = Math.sqrt(t.reduce((a, x, k) => a + prob(n, k) * x * x, 0) - ev * ev);
    assert.ok(Math.abs(won / paid - ev) < 5 * sd / Math.sqrt(N), `${mode} n=${n}: ${(won / paid).toFixed(4)} vs ${ev.toFixed(4)}`);
  }
});
