// Mystery of the Mummy: lines, features, queueing, and money integrity.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { act, init } from '../server/games/mummy/engine.js';
import { evaluate } from '../server/games/mummy/evaluate.js';
import { startCash, respin } from '../server/games/mummy/cash.js';
import { startJackpot, pick } from '../server/games/mummy/jackpot.js';
import { CASH, FREE_GAMES, JACKPOTS, MAX_WIN_X, PAYTABLE, RETRIGGER, SCATTER_PAY } from '../server/games/mummy/config.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const never = () => 0.999999; // no random triggers
const ctx = (seed = 1, extra = {}) => ({ rand: seeded(seed), now: 0, minStake: 10, maxStake: 50000, ...extra });
const DEAD = [['J', 'Q', 'K'], ['ANKH', 'EYE', 'BOOK'], ['A', 'J', 'Q'], ['K', 'ANUBIS', 'PHARAOH'], ['Q', 'K', 'A']];
const grid = (edits = {}) => DEAD.map((col, r) => col.map((s, row) => { const e = edits[`${r},${row}`]; return typeof e === 'object' ? e : { s: e ?? s }; }));
const spin = (st, g, bet = 100, rand = never) => act(st, 'spin', { stake: bet }, { rand, minStake: 10, inject: { grid: g } });

test('losing spin: stake charged, nothing paid, no feature', () => {
  const r = spin(init(), grid());
  assert.equal(r.stake, 100); assert.equal(r.payout, 0); assert.equal(r.state.mode, 'base'); assert.equal(r.out.wins.length, 0);
});

test('paytable: every symbol pays its table value for 3, 4 and 5 on line 1', () => {
  for (const [sym, pays] of Object.entries(PAYTABLE)) for (let n = 3; n <= 5; n++) {
    const g = DEAD.map((c) => c.map((s) => ({ s })));
    for (let r = 0; r < n; r++) g[r][1] = { s: sym };
    if (n < 5) g[n][1] = { s: 'FS' };
    const w = evaluate(g, 10000).wins.find((x) => x.line === 0);
    assert.equal(w.amount, pays[n - 3] * 100, `${sym} x${n}`);
  }
});

test('wild substitutes, and pays as wild when that is worth more', () => {
  const g = grid({ '0,1': 'PHARAOH', '1,1': 'WILD', '2,1': 'WILD', '3,1': 'PHARAOH' });
  const w = evaluate(g, 100).wins.find((x) => x.line === 0);
  assert.equal(w.symbol, 'PHARAOH'); assert.equal(w.count, 4);
  const g2 = grid({ '0,1': 'WILD', '1,1': 'WILD', '2,1': 'WILD', '3,1': 'J' });
  assert.equal(evaluate(g2, 100).wins.find((x) => x.line === 0).symbol, 'WILD');
});

test('3 scatters pay and start 6 Free Games; free spins cost nothing; 3 more retrigger +6', () => {
  let r = spin(init(), grid({ '0,0': 'FS', '2,2': 'FS', '4,1': 'FS' }));
  assert.equal(r.out.scatter.win, SCATTER_PAY[3]);
  assert.equal(r.state.mode, 'free'); assert.equal(r.state.free.remaining, FREE_GAMES);
  assert.equal(r.out.started.type, 'free');
  r = spin(r.state, grid({ '1,0': 'FS', '3,2': 'FS', '4,1': 'FS' }));
  assert.equal(r.stake, 0);
  assert.equal(r.state.free.remaining, FREE_GAMES - 1 + RETRIGGER);
  let st = r.state;
  while (st.mode === 'free') { r = spin(st, grid()); assert.equal(r.stake, 0); st = r.state; }
  assert.ok(r.out.finished && r.out.finished.played === 1 + FREE_GAMES - 1 + RETRIGGER);
  assert.equal(st.mode, 'base');
});

test('Free Games reels never show A/K/Q/J', () => {
  let st = { ...init(), mode: 'free', free: { bet: 100, remaining: 400, total: 0, played: 0 } };
  for (let i = 0; i < 300; i++) {
    const r = runGame('mummy', st, 'spin', {}, ctx(i + 3));
    for (const col of r.out.grid) for (const c of col) assert.ok(!['A', 'K', 'Q', 'J'].includes(c.s), c.s);
    st = r.state; if (st.mode !== 'free') break;
  }
});

test('Mummy on reel 1 + a gem starts Cash Collect on a separate 5x5 grid with 5 spins', () => {
  const r = spin(init(), grid({ '0,2': 'MUMMY', '2,0': { s: 'GEM', v: 5 }, '3,1': { s: 'GEM', v: 2 } }));
  assert.equal(r.state.mode, 'cash');
  const c = r.state.cash;
  assert.equal(c.phase, 'READY');
  assert.deepEqual(c.zone, { col: 0, row: 3, size: 2 });
  assert.equal(c.respins, CASH.respins);
  assert.deepEqual(c.board[2][2], { v: 5 }, 'gem placed in its column (bottom 3 rows)');
  assert.deepEqual(c.board[3][3], { v: 2 });
  assert.equal(c.total, 0, 'nothing is collected until the Mummy reaches it');
  assert.throws(() => act(r.state, 'spin', { stake: 100 }, { rand: never, minStake: 10 }), /Cash Collect/);
});

test('A Mummy without a gem does nothing; a gem without a Mummy only starts it at random', () => {
  assert.equal(spin(init(), grid({ '0,0': 'MUMMY' })).state.mode, 'base');
  assert.equal(spin(init(), grid({ '2,0': { s: 'GEM', v: 3 } })).state.mode, 'base');
  assert.equal(spin(init(), grid({ '2,0': { s: 'GEM', v: 3 } }), 100, () => 0).state.mode !== 'base', true);
});

const emptyStart = () => startCash(DEAD.map((c) => c.map((s) => ({ s }))), never).cash;
const quiet = () => 0.99; // nothing lands

test('Cash Collect growth: 5 gems → 3x3 +3, 9 → 4x4 +2, 12 → 5x5 +1, cumulative', () => {
  const st = emptyStart();
  // waiting gems right next to the Mummy so each spin collects some
  const feed = (n) => { let k = 0; for (let c = 0; c < 5 && k < n; c++) for (let r = 0; r < 5 && k < n; r++) if (!st.board[c][r] && !(c >= st.zone.col && c < st.zone.col + st.zone.size && r >= st.zone.row && r < st.zone.row + st.zone.size)) { st.board[c][r] = { v: 1 }; k++; } };
  const sizes = [], spins = [];
  let guard = 0;
  while (st.level < 3 && guard++ < 40) {
    st.respins = Math.max(st.respins, 2);
    feed(2);
    const before = st.respins;
    const ev = respin(st, quiet);
    let gems = st.gems - ev.growth.reduce((a, u) => a + u.collected.length, 0);
    for (const u of ev.growth) { sizes.push([u.size, gems]); spins.push(u.spins); gems += u.collected.length; }
    assert.equal(st.respins, before - 1 + ev.growth.reduce((a, u) => a + u.spins, 0), 'extra spins added to the counter');
    for (const g of [...ev.collected, ...ev.growth.flatMap((u) => u.collected)]) assert.equal(g.kind, 'gem');
  }
  assert.deepEqual(spins, [3, 2, 1]);
  assert.deepEqual(sizes.map(([s]) => s), [3, 4, 5]);
  const at = sizes.map(([, g]) => g);
  assert.ok(at[0] >= 5 && at[1] >= 9 && at[2] >= 12, `grew at ${at}`);
  assert.deepEqual(st.zone, { col: 0, row: 0, size: 5 });
});

test('Cash Collect: prizes pay only under the Mummy, gems wait, nothing collected twice, the Mummy never shrinks', () => {
  for (let seed = 1; seed < 400; seed++) {
    const rand = seeded(seed);
    const g = DEAD.map((c) => c.map((s) => ({ s })));
    g[2][1] = { s: 'GEM', v: 3 };
    const { cash } = startCash(g, rand);
    let paidFor = 0, size = cash.zone.size, respins = cash.respins;
    while (cash.phase !== 'COMPLETE') {
      const prev = cash.zone;
      const prevBoard = cash.board.map((col) => col.slice());
      const ev = respin(cash, rand);
      assert.ok(Math.abs(ev.moved.col - prev.col) <= 1 && Math.abs(ev.moved.row - prev.row) <= 1, 'one step at a time');
      const z = ev.moved;
      const inside = (c, r) => c >= z.col && c < z.col + z.size && r >= z.row && r < z.row + z.size;
      for (const l of ev.landed) if (l.kind === 'coin') assert.equal(l.hit, inside(l.c, l.r));
      for (const it of ev.collected) {
        assert.ok(inside(it.c, it.r), 'only collected inside the Mummy');
        if (it.kind === 'gem') { assert.ok(prevBoard[it.c][it.r] || ev.landed.some((l) => l.kind === 'gem' && l.c === it.c && l.r === it.r), 'a real gem'); assert.equal(cash.board[it.c][it.r], null, 'removed once collected'); }
        paidFor += it.v;
      }
      for (const u of ev.growth) for (const it of u.collected) { assert.ok(it.c >= u.zone.col && it.c < u.zone.col + u.zone.size && it.r >= u.zone.row && it.r < u.zone.row + u.zone.size); paidFor += it.v; }
      respins = respins - 1 + ev.growth.reduce((a, u) => a + u.spins, 0);
      assert.equal(cash.respins, respins);
      assert.ok(cash.zone.size >= size, 'never shrinks'); size = cash.zone.size;
      assert.ok(cash.zone.col >= 0 && cash.zone.row >= 0 && cash.zone.col + size <= 5 && cash.zone.row + size <= 5);
      for (let c = 0; c < 5; c++) for (let r = 0; r < 5; r++) if (cash.board[c][r]) assert.ok(!(c >= cash.zone.col && c < cash.zone.col + size && r >= cash.zone.row && r < cash.zone.row + size), 'no gem left under the Mummy');
    }
    assert.equal(cash.total, paidFor, 'total = exactly what was collected');
    assert.throws(() => respin(cash, rand), /finished/);
  }
});

test('Cash Collect pays its total once, at the end', () => {
  let r = spin(init(), grid({ '0,0': 'MUMMY', '4,2': { s: 'GEM', v: 10 } }));
  let st = r.state, paid = 0, steps = 0;
  const c = ctx(5);
  while (st.mode === 'cash') { r = runGame('mummy', st, 'respin', {}, c); paid += r.payout; if (st.mode === 'cash' && r.state.mode === 'cash') assert.equal(r.payout, 0); st = r.state; steps++; }
  assert.equal(paid, r.out.win);
  assert.equal(paid, Math.min(r.out.total * 100, 100 * MAX_WIN_X));
  assert.throws(() => runGame('mummy', st, 'respin', {}, c), /no Cash Collect/);
  assert.ok(steps >= CASH.respins);
});

test('Jackpot pick: decided at the start; tile choice cannot change it', () => {
  for (let s = 1; s < 200; s++) {
    const a = startJackpot(seeded(s)), b = structuredClone(a);
    const order1 = [...Array(15).keys()], order2 = order1.slice().reverse();
    let ra, rb;
    for (const i of order1) { ra = pick(a, i); if (ra.done) break; }
    for (const i of order2) { rb = pick(b, i); if (rb.done) break; }
    assert.equal(ra.tier, rb.tier);
    // the winner is the first tier seen three times, and nothing else reached three
    const counts = {};
    let first = null;
    for (const o of a.opened) { counts[o.tier] = (counts[o.tier] || 0) + 1; if (counts[o.tier] === 3 && first === null) first = o.tier; }
    assert.equal(first, a.tier);
    assert.equal(a.opened.length, a.sequence.length);
  }
  const jp = startJackpot(seeded(3));
  pick(jp, 4);
  assert.throws(() => pick(jp, 4), /covered/);
  assert.throws(() => pick(jp, 15), /covered/);
});

test('a landing Wild can start the jackpot pick; it pays the jackpot once', () => {
  let r = spin(init(), grid({ '2,1': 'WILD' }), 100, () => 0.0001);
  assert.equal(r.state.mode, 'jackpot');
  let st = r.state, paid = 0;
  for (let i = 0; i < 15 && st.mode === 'jackpot'; i++) { r = runGame('mummy', st, 'pick', { index: i }, ctx()); paid += r.payout; st = r.state; }
  assert.equal(paid, JACKPOTS[r.out.jackpot.tier].x * 100);
  assert.throws(() => runGame('mummy', st, 'pick', { index: 0 }, ctx()), /no jackpot/);
});

test('several triggers on one spin queue: jackpot, then Cash Collect, then Free Games', () => {
  const g = grid({ '0,0': 'MUMMY', '1,0': 'WILD', '2,0': { s: 'GEM', v: 3 }, '0,2': 'FS', '3,0': 'FS', '4,0': 'FS' });
  let r = spin(init(), g, 100, () => 0.0001);
  assert.equal(r.state.mode, 'jackpot');
  assert.deepEqual(r.state.queue.map((q) => q.type), ['cash', 'free']);
  let st = r.state;
  for (let i = 0; st.mode === 'jackpot'; i++) st = runGame('mummy', st, 'pick', { index: i }, ctx()).state;
  assert.equal(st.mode, 'cash');
  while (st.mode === 'cash') st = runGame('mummy', st, 'respin', {}, ctx(8)).state;
  assert.equal(st.mode, 'free');
});

test('practice (test-mode) features cost nothing and pay nothing', () => {
  for (const event of ['free', 'cash', 'jackpot']) {
    let r = runGame('mummy', null, 'dev', { event, stake: 100, tier: 4 }, ctx());
    assert.equal(r.stake, 0); assert.equal(r.payout, 0); assert.ok(r.out.practice);
    let st = r.state, n = 0;
    while (st.mode !== 'base' && n++ < 200) {
      const a = st.mode === 'jackpot' ? ['pick', { index: st.jackpot.opened.length }] : st.mode === 'cash' ? ['respin', {}] : ['spin', {}];
      r = runGame('mummy', st, a[0], a[1], ctx(n));
      assert.equal(r.stake, 0); assert.equal(r.payout, 0, `${event} pays nothing`);
      st = r.state;
    }
    assert.equal(st.practice, false);
  }
  assert.throws(() => runGame('mummy', { ...init(), mode: 'free', free: { bet: 100, remaining: 3, total: 0, played: 0 } }, 'dev', { event: 'cash', stake: 100 }, ctx()), /Finish/);
});

test('real API: 20,000 spins with features; money integrity and the cap', () => {
  let st = null, paid = 0, won = 0, n = 0, feats = { free: 0, cash: 0, jackpot: 0 };
  const c = ctx(4242);
  while (n < 20000 || (st && st.mode !== 'base')) {
    const mode = st?.mode || 'base';
    let r;
    if (mode === 'jackpot') r = runGame('mummy', st, 'pick', { index: st.jackpot.opened.length }, c);
    else if (mode === 'cash') r = runGame('mummy', st, 'respin', {}, c);
    else { r = runGame('mummy', st, 'spin', { stake: 100 }, c); if (mode === 'base') { n++; assert.equal(r.stake, 100); } else assert.equal(r.stake, 0); }
    if (r.out.started) feats[r.out.started.type]++;
    assert.ok(Number.isSafeInteger(r.payout) && r.payout >= 0 && r.payout <= 100 * MAX_WIN_X);
    paid += r.stake; won += r.payout; st = r.state;
  }
  assert.equal(paid, 20000 * 100);
  assert.ok(feats.free > 0 && feats.cash > 0, JSON.stringify(feats));
});

test('stakes validated; same random numbers give the same spin', () => {
  assert.throws(() => runGame('mummy', null, 'spin', { stake: 5 }, ctx()), /at least/);
  assert.throws(() => runGame('mummy', null, 'spin', { stake: 10001 }, ctx()), /at most/);
  assert.deepEqual(runGame('mummy', null, 'spin', { stake: 10 }, ctx(9)).out, runGame('mummy', null, 'spin', { stake: 10 }, ctx(9)).out);
  assert.equal(runGame('mummy', null, 'spin', { stake: 10000 }, ctx(9)).stake, 10000);
});
