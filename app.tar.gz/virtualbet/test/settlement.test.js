// Integration test: place bets through the real placement code, finish the
// matches, run settlement and check balances + ledger.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dbFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'vb-')), 'test.db');
const { openDb, q, tx } = await import('../server/db.js');
const { credit } = await import('../server/wallet.js');
const { placeBets } = await import('../server/bets.js');
const { settlePending } = await import('../server/settlement.js');
const { priceMarkets, lambdasFor } = await import('../server/markets.js');
openDb(dbFile);

const caps = JSON.stringify({ goalOrder: true, corners: true, cards: true, liveCorners: true, liveCards: true });
function addMatch(id, home, away) {
  const lam = lambdasFor(0, 0);
  q(`INSERT INTO matches (id, source, league_code, league_name, home_name, away_name, kickoff_at, status, lambda_home, lambda_away, caps, updated_at)
     VALUES (?, 'demo', 'PL', 'Premier League', ?, ?, ?, 'SCHEDULED', ?, ?, ?, ?)`).run(id, home, away, Date.now() + 3600000, lam.lambda_home, lam.lambda_away, caps, Date.now());
}
const oddsOf = (id, market, sel) => priceMarkets(q('SELECT * FROM matches WHERE id = ?').get(id)).find((m) => m.key === market).selections.find((s) => s.key === sel).odds;
const balance = (uid) => q('SELECT balance FROM users WHERE id = ?').get(uid).balance;
const finish = (id, h, a, ht = [0, 0], status = 'FINISHED') => q(`UPDATE matches SET status = ?, home_score = ?, away_score = ?, ht_home = ?, ht_away = ?,
  result_verified = ?, finished_at = ?, goal_order = ? WHERE id = ?`).run(status, h, a, ht[0], ht[1], status === 'FINISHED' ? 1 : 0, Date.now(),
  JSON.stringify([...Array(h).fill('1'), ...Array(a).fill('2')]), id);

const uid = Number(q(`INSERT INTO users (username, password_hash, balance, created_at) VALUES ('t', 'x', 0, ?)`).run(Date.now()).lastInsertRowid);
tx(() => credit(uid, 'WELCOME_BONUS', 10000));
['A', 'B', 'C', 'D'].forEach((id) => addMatch(id, `Home${id}`, `Away${id}`));

test('placement deducts stakes, settlement pays winners, voids and accas correctly', () => {
  const sel = (matchId, market, selection) => ({ matchId, market, selection, odds: oddsOf(matchId, market, selection) });
  const a1 = sel('A', '1X2', '1'), b1 = sel('B', '1X2', '2'), c1 = sel('C', 'BTTS', 'Y'), dDnb = sel('D', 'DNB', '1');
  const r = placeBets(uid, {
    idempotencyKey: 'test-key-123',
    bets: [
      { type: 'SINGLE', stake: 500, selections: [a1] },          // wins
      { type: 'SINGLE', stake: 200, selections: [b1] },          // loses
      { type: 'SINGLE', stake: 300, selections: [dDnb] },        // void (draw)
      { type: 'ACCA', stake: 100, selections: [a1, c1, dDnb] },  // wins, D leg void
      { type: 'ACCA', stake: 100, selections: [a1, b1] },        // loses
    ],
  });
  assert.equal(r.refs.length, 5);
  assert.equal(balance(uid), 10000 - 1200);

  // Duplicate submission returns the same bets and charges nothing
  const again = placeBets(uid, { idempotencyKey: 'test-key-123', bets: [{ type: 'SINGLE', stake: 500, selections: [a1] }] });
  assert.deepEqual(again.refs, r.refs);
  assert.equal(balance(uid), 8800);

  // Unverified result must not settle
  q(`UPDATE matches SET status = 'FINISHED', home_score = 2, away_score = 1, result_verified = 0 WHERE id = 'A'`).run();
  settlePending();
  assert.equal(q(`SELECT COUNT(*) n FROM bets WHERE status != 'OPEN'`).get().n, 0);

  finish('A', 2, 1, [1, 0]);
  finish('B', 1, 0);
  finish('C', 1, 1);
  finish('D', 0, 0);
  settlePending();

  const bets = Object.fromEntries(q('SELECT ref, status, actual_return FROM bets').all().map((b) => [b.ref, b]));
  const [w, l, v, acca, accaLost] = r.refs.map((ref) => bets[ref]);
  assert.equal(w.status, 'WON');
  assert.equal(w.actual_return, Math.floor((500 * a1.odds) / 100));
  assert.equal(l.status, 'LOST');
  assert.equal(v.status, 'VOID');
  assert.equal(v.actual_return, 300);
  assert.equal(acca.status, 'WON');
  assert.equal(acca.actual_return, Math.floor((100 * a1.odds * c1.odds) / 10000)); // void leg removed
  assert.equal(accaLost.status, 'LOST');
  const expected = 8800 + w.actual_return + 300 + acca.actual_return;
  assert.equal(balance(uid), expected);

  // Ledger is consistent: every row chains before -> after
  const rows = q('SELECT * FROM wallet_tx WHERE user_id = ? ORDER BY id').all(uid);
  for (let i = 1; i < rows.length; i++) assert.equal(rows[i].balance_before, rows[i - 1].balance_after);
  assert.equal(rows.at(-1).balance_after, expected);

  // Settlement is idempotent
  settlePending();
  assert.equal(balance(uid), expected);
});

test('abandoned match voids the stake', () => {
  addMatch('E', 'HomeE', 'AwayE');
  const before = balance(uid);
  placeBets(uid, { idempotencyKey: 'abandon-key-1', bets: [{ type: 'SINGLE', stake: 250, selections: [{ matchId: 'E', market: '1X2', selection: 'X', odds: oddsOf('E', '1X2', 'X') }] }] });
  assert.equal(balance(uid), before - 250);
  q(`UPDATE matches SET status = 'ABANDONED' WHERE id = 'E'`).run();
  settlePending();
  assert.equal(balance(uid), before);
});

test('stake rules are enforced server-side', () => {
  addMatch('F', 'HomeF', 'AwayF');
  const s = { matchId: 'F', market: '1X2', selection: '1', odds: oddsOf('F', '1X2', '1') };
  assert.throws(() => placeBets(uid, { idempotencyKey: 'k-min-0001', bets: [{ type: 'SINGLE', stake: 9, selections: [s] }] }), /Minimum stake/);
  assert.throws(() => placeBets(uid, { idempotencyKey: 'k-max-0001', bets: [{ type: 'SINGLE', stake: 50001, selections: [s] }] }), /Maximum stake/);
  assert.throws(() => placeBets(uid, { idempotencyKey: 'k-odd-0001', bets: [{ type: 'SINGLE', stake: 10, selections: [{ ...s, odds: s.odds + 1 }] }] }), /Odds have changed/);
  assert.throws(() => placeBets(uid, { idempotencyKey: 'k-acc-0001', bets: [{ type: 'ACCA', stake: 10, selections: [s, { ...s, market: 'BTTS', selection: 'Y', odds: oddsOf('F', 'BTTS', 'Y') }] }] }), /different matches/);
  const bal = balance(uid);
  q('UPDATE users SET balance = 50 WHERE id = ?').run(uid);
  assert.throws(() => placeBets(uid, { idempotencyKey: 'k-bal-0001', bets: [{ type: 'SINGLE', stake: 100, selections: [s] }] }), /more than your balance/);
  q('UPDATE users SET balance = ? WHERE id = ?').run(bal, uid);
  q(`UPDATE matches SET status = 'FINISHED' WHERE id = 'F'`).run();
  assert.throws(() => placeBets(uid, { idempotencyKey: 'k-fin-0001', bets: [{ type: 'SINGLE', stake: 10, selections: [s] }] }), /no longer available/);
});

test('cash out pays the quoted value once and settlement leaves it alone', async () => {
  const { cashOutBet, getBet } = await import('../server/bets.js');
  addMatch('CO1', 'HomeCO', 'AwayCO');
  const e1 = { matchId: 'CO1', market: '1X2', selection: '1', odds: oddsOf('CO1', '1X2', '1') };
  const before = balance(uid);
  const r = placeBets(uid, { idempotencyKey: 'test-key-cashout', bets: [{ type: 'SINGLE', stake: 1000, selections: [e1] }] });
  const ref = r.refs[0];
  const co = getBet(uid, ref).cashOut;
  assert.equal(co.available, true);
  assert.equal(co.value, 950); // odds unchanged: 95% of stake
  assert.throws(() => cashOutBet(uid, ref, co.value + 1), (e) => e.code === 'CASHOUT_CHANGED' || /changed/.test(e.message));
  const out = cashOutBet(uid, ref, co.value);
  assert.equal(out.bet.status, 'CASHED_OUT');
  assert.equal(balance(uid), before - 1000 + 950);
  assert.throws(() => cashOutBet(uid, ref, co.value), /already been settled/);
  finish('CO1', 3, 0);
  settlePending();
  const b = getBet(uid, ref);
  assert.equal(b.status, 'CASHED_OUT');
  assert.equal(b.actualReturn, 950);
  assert.equal(balance(uid), before - 50); // no second payout
});
