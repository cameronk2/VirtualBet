// The bet slip shows returns calculated in the browser; the server settles with
// its own maths. They must always agree to the penny.
import test from 'node:test';
import assert from 'node:assert/strict';
import { potentialReturn as clientReturn, combinedOdds as clientCombined, toPence, cleanAmount } from '../client/src/lib/format.js';
import { potentialReturn as serverReturn, combinedOddsX100 } from '../server/money.js';

test('bet slip returns match server settlement for singles and accas', () => {
  let seed = 7;
  const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
  for (let i = 0; i < 20000; i++) {
    const legs = 1 + Math.floor(rnd() * 8);
    const odds = Array.from({ length: legs }, () => 101 + Math.floor(rnd() * 2000));
    const stake = 10 + Math.floor(rnd() * 50000);
    assert.equal(clientReturn(stake, odds), serverReturn(stake, odds), `stake ${stake} odds ${odds}`);
    assert.equal(clientCombined(odds), combinedOddsX100(odds));
  }
});

test('known examples', () => {
  assert.equal(clientReturn(500, [184]), 920); // £5 @ 1.84 -> £9.20
  assert.equal(clientReturn(1000, [150, 200, 210]), 6300); // £10 treble
  assert.equal(clientReturn(333, [333]), 1108); // rounds down to the penny
  assert.equal(clientCombined([150, 200, 210]), 630);
});

test('stake entry from the iPhone keypad', () => {
  assert.equal(toPence(cleanAmount('2.50')), 250);
  assert.equal(toPence(cleanAmount('2,50')), 250); // comma-decimal keypad
  assert.equal(toPence(cleanAmount('£10')), 1000);
  assert.equal(toPence(cleanAmount('1.239')), 123);
  assert.equal(toPence(cleanAmount('')), 0);
  assert.equal(toPence(cleanAmount('0.1')), 10);
});
