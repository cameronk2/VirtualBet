import { test } from 'node:test';
import assert from 'node:assert/strict';
import { roulette, payoutFor } from '../server/games/roulette.js';
import { baccarat, playCoup, total } from '../server/games/baccarat.js';
import { threecard, evaluate, shouldPlay } from '../server/games/threecard.js';
import { crash, plinko, scratch, PLINKO, makeTicket, multAt, timeFor } from '../server/games/instant.js';

const mk = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (rand, now = 0) => ({ rand, now, minStake: 10, maxStake: 50000 });

test('roulette: payouts and invalid bets', () => {
  assert.equal(payoutFor(1), 35); assert.equal(payoutFor(2), 17); assert.equal(payoutFor(18), 1); assert.equal(payoutFor(12), 2);
  assert.throws(() => roulette.act(roulette.init(), 'spin', { bets: [{ nums: [1, 5], amount: 100 }] }, ctx(mk(1))), /not a valid/);
  const rand = mk(3); let st = roulette.init(), staked = 0, paid = 0;
  for (let i = 0; i < 200000; i++) {
    const r = roulette.act(st, 'spin', { bets: [{ nums: [17], amount: 100 }, { nums: [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36], amount: 100 }] }, ctx(rand));
    staked += r.stake; paid += r.payout; st = r.state;
  }
  const rtp = paid / staked; assert.ok(rtp > 0.95 && rtp < 0.995, `rtp ${rtp}`);
});

test('baccarat: totals, drawing and returns', () => {
  assert.equal(total(['9H', '8S']), 7); assert.equal(total(['KH', '5S', 'AC']), 6);
  const rand = mk(5); let st = baccarat.init(), s = { p: [0, 0], b: [0, 0], t: [0, 0] };
  for (let i = 0; i < 300000; i++) {
    for (const [k, f] of [['p', 'player'], ['b', 'banker'], ['t', 'tie']]) {
      const r = baccarat.act(st, 'deal', { [f]: 1000 }, ctx(rand)); s[k][0] += r.stake; s[k][1] += r.payout; st = r.state;
    }
  }
  const rtp = (k) => s[k][1] / s[k][0];
  assert.ok(Math.abs(rtp('b') - 0.9894) < 0.006, `banker ${rtp('b')}`);
  assert.ok(Math.abs(rtp('p') - 0.9876) < 0.006, `player ${rtp('p')}`);
  assert.ok(rtp('t') > 0.8 && rtp('t') < 0.93, `tie ${rtp('t')}`);
});

test('three card poker: ranking and return with Q-6-4 strategy', () => {
  assert.equal(evaluate(['AH', '2H', '3H']).cat, 'straightFlush');
  assert.equal(evaluate(['QS', 'KD', 'AH']).cat, 'straight');
  assert.equal(evaluate(['2C', '9C', 'KC']).cat, 'flush');
  assert.equal(evaluate(['7C', '7D', 'KC']).cat, 'pair');
  assert.ok(shouldPlay(['QS', '6D', '4H'])); assert.ok(!shouldPlay(['QS', '6D', '3H']));
  const rand = mk(9); let st = threecard.init(), staked = 0, paid = 0;
  for (let i = 0; i < 200000; i++) {
    let r = threecard.act(st, 'deal', { ante: 1000 }, ctx(rand)); staked += r.stake; st = r.state;
    r = threecard.act(st, shouldPlay(st.hand.player) ? 'play' : 'fold', {}, ctx(rand)); staked += r.stake; paid += r.payout; st = r.state;
  }
  const edge = (staked - paid) / (staked / 1); // per total staked
  assert.ok(edge > 0.01 && edge < 0.035, `edge ${edge}`);
});

test('crash: timing and payouts', () => {
  assert.equal(multAt(0), 1); assert.ok(Math.abs(timeFor(2) - 5776) < 5);
  let st = crash.init();
  let r = crash.act(st, 'start', { stake: 1000, auto: 1.5 }, ctx(() => 0.5, 0)); st = r.state; // crash 1.94
  assert.equal(st.round.crash, 1.94);
  r = crash.act(st, 'tick', {}, ctx(Math.random, 1200 + timeFor(1.6)));
  assert.equal(r.out.done, true); assert.equal(r.payout, 1500);
  st = crash.act(crash.init(), 'start', { stake: 1000 }, ctx(() => 0.5, 0)).state;
  r = crash.act(st, 'cashout', {}, ctx(Math.random, 1200 + timeFor(3))); assert.equal(r.payout, 0); // already crashed at 1.94
  const rand = mk(13); let tot = 0; const N = 200000;
  for (let i = 0; i < N; i++) { const s2 = crash.act(crash.init(), 'start', { stake: 100, auto: 2 }, ctx(rand, 0)).state; const z = crash.act(s2, 'tick', {}, ctx(rand, 1e9)); tot += z.payout; }
  assert.ok(Math.abs(tot / (N * 100) - 0.97) < 0.01);
});

test('plinko: exact returns are about 97%', () => {
  const C = [1, 12, 66, 220, 495, 792, 924, 792, 495, 220, 66, 12, 1];
  for (const [risk, m] of Object.entries(PLINKO)) {
    const ev = m.reduce((a, x, k) => a + x * C[k], 0) / 4096;
    assert.ok(ev > 0.96 && ev < 0.98, `${risk} ${ev}`);
  }
  const r = plinko.act(plinko.init(), 'drop', { stake: 100, risk: 'medium' }, ctx(mk(2)));
  assert.equal(r.out.slot, r.out.path.reduce((a, b) => a + b, 0));
});

test('scratchcards: winning tickets show exactly three matches', () => {
  const rand = mk(21); let paid = 0, staked = 0;
  for (let i = 0; i < 200000; i++) {
    const t = makeTicket(rand);
    const counts = {}; t.cells.forEach((c) => (counts[c] = (counts[c] || 0) + 1));
    const triples = Object.entries(counts).filter(([, n]) => n >= 3);
    if (t.win) { assert.equal(triples.length, 1); assert.equal(Number(triples[0][0]), t.win); assert.equal(triples[0][1], 3); }
    else assert.equal(triples.length, 0);
    const r = scratch.act(scratch.init(), 'buy', { price: 100 }, ctx(rand));
    staked += 100; paid += t.win * 100; void r;
  }
  assert.ok(Math.abs(paid / staked - 0.68) < 0.03, `${paid / staked}`);
});

import { nebula, vault, fruit, starlight, holdAndSpin, bestNudges, fruitLine, fruitPays } from '../server/games/slots2.js';
import { track } from '../server/achievements.js';
test('slots: engines run, money adds up, features resolve', () => {
  const rand = mk(77);
  for (const g of [nebula, vault, starlight]) {
    let st = g.init();
    for (let i = 0; i < 3000; i++) {
      const r = g.act(st, 'spin', { stake: 100 }, ctx(rand));
      assert.ok(r.payout >= 0 && r.payout <= 100 * 5000);
      st = r.state;
      let guard = 0;
      while (st.free && guard++ < 500) st = g.act(st, 'spin', {}, ctx(rand)).state;
      assert.ok(!st.free);
    }
  }
  const full = holdAndSpin(Array.from({ length: 5 }, () => Array.from({ length: 3 }, () => ({ s: 'COIN', v: 100 }))), 100, rand);
  assert.ok(full.full && full.total >= 100 * 1000);
  const b = bestNudges([1, 1, 1], 4);
  if (b) assert.ok(b.pay > 0);
  assert.equal(fruitPays(['SEVEN', 'SEVEN', 'SEVEN']), 100);
  assert.equal(fruitPays(['CHERRY', 'LEMON', 'CHERRY']), 2);
  assert.ok(fruitLine([0, 0, 0]).length === 3);
  let st = fruit.init();
  assert.throws(() => fruit.act(st, 'spin', { stake: 100, holds: [true, false, false] }, ctx(rand)), /Holds are only/);
});
test('achievements: badges unlock once', () => {
  const p = {};
  assert.equal(track(p, [{ t: 'sportsBet' }])[0].id, 'kickoff');
  assert.equal(track(p, [{ t: 'sportsBet' }]).length, 0);
  const many = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map((game) => ({ t: 'played', game }));
  assert.equal(track(p, many)[0].id, 'tourist');
});

test('table games have no maximum bet (balance is the limit)', async () => {
  const { runGame } = await import('../server/games/registry.js');
  const { NO_LIMIT } = await import('../server/games/common.js');
  let seed = 7; const rand = () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
  const ctx = { rand, now: Date.now(), minStake: 10, maxStake: NO_LIMIT };
  const big = 250_000_00; // £250,000
  const r = runGame('roulette', null, 'spin', { bets: [{ nums: [17], amount: big }, { nums: Array.from({ length: 18 }, (_, i) => i * 2 + 1), amount: big }] }, ctx);
  assert.equal(r.stake, big * 2);
  const b = runGame('baccarat', null, 'deal', { player: big, banker: 0, tie: 0, pPair: 0, bPair: 0 }, ctx);
  assert.equal(b.stake, big);
  const t = runGame('threecard', null, 'deal', { ante: big, pp: big }, ctx);
  assert.equal(t.stake, big * 2);
  // slots keep their normal cap
  assert.throws(() => runGame('fruit', null, 'spin', { stake: big }, { ...ctx, maxStake: 50000 }));
});
