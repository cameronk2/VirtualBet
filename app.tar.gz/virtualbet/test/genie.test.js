// Golden Wishes: 20 lines, Genie wilds, Wishing Star free spins (×2, expanding
// genies), Magic Lamp wishes and Genie's Treasure jackpots.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { act, init, makeWish } from '../server/games/genie/engine.js';
import { evaluateLines, expandWilds, linePay, draw } from '../server/games/genie/reels.js';
import { dealTreasure, pickTreasure, treasureTotals } from '../server/games/genie/treasure.js';
import { FREE_MIN_X, FREE_MULT, FREE_SPINS, JACKPOTS, LINES, MAX_FREE_SPINS, MAX_WIN_X, PAYTABLE, PAY_SCALE, RETRIGGER, SCATTER_PAY, TREASURE_TILES, WISH_FREE } from '../server/games/genie/config.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (seed = 1, inject) => ({ rand: seeded(seed), minStake: 10, inject });
// No line can win: reel 1 symbols never appear on reel 2.
const DEAD = [['A', 'K', 'Q'], ['T', 'J', 'T'], ['A', 'K', 'Q'], ['RUBY', 'CROWN', 'RUBY'], ['A', 'K', 'Q']];
const grid = (edits = {}) => DEAD.map((col, c) => col.map((s, r) => edits[`${c},${r}`] || s));
const row = (r, syms) => { const g = grid(); syms.forEach((s, c) => { if (s) g[c][r] = s; }); return g; };

test('a dead spin charges the stake and pays nothing', () => {
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid() }));
  assert.equal(r.stake, 100); assert.equal(r.payout, 0); assert.equal(r.out.wins.length, 0); assert.equal(r.state.mode, 'base');
});

test('every symbol pays its paytable value for 3, 4 and 5 on a line, scaled by bet', () => {
  for (const sym of Object.keys(PAYTABLE)) for (let n = 3; n <= 5; n++) for (const bet of [10, 200, 10000]) {
    const g = grid(); for (let c = 0; c < n; c++) g[c][1] = sym;
    if (n < 5) g[n][1] = sym === 'T' ? 'A' : 'T';
    const w = evaluateLines(g, bet).filter((x) => x.line === 0);
    assert.equal(w.length, 1, `${sym} x${n}`);
    assert.equal(w[0].amount, Math.floor((bet * PAYTABLE[sym][n - 3] * PAY_SCALE) / LINES.length), `${sym} x${n} @${bet}`);
    assert.equal(w[0].count, n);
  }
});

test('every one of the 20 lines is evaluated, and simultaneous wins add up without duplicates', () => {
  for (let l = 0; l < LINES.length; l++) {
    const g = grid({}); LINES[l].forEach((r, c) => { g[c][r] = 'PRINCESS'; });
    const wins = evaluateLines(g, 2000);
    assert.ok(wins.some((w) => w.line === l && w.symbol === 'PRINCESS' && w.count === 5), `line ${l + 1}`);
    assert.equal(new Set(wins.map((w) => w.line)).size, wins.length, 'one win per line');
  }
  // full screen of one symbol: all 20 lines pay 5 of a kind
  const full = Array.from({ length: 5 }, () => ['CROWN', 'CROWN', 'CROWN']);
  const wins = evaluateLines(full, 2000);
  assert.equal(wins.length, 20);
  const r = act(init(), 'spin', { stake: 2000 }, ctx(1, { grid: full }));
  assert.equal(r.payout, 20 * linePay('CROWN', 5, 2000));
});

test('Genie substitutes, pays on its own, and a line pays only its best win', () => {
  let w = evaluateLines(row(1, ['RUBY', 'GENIE', 'RUBY', 'GENIE', 'A']), 2000).find((x) => x.line === 0);
  assert.equal(w.symbol, 'RUBY'); assert.equal(w.count, 4);
  w = evaluateLines(row(1, ['GENIE', 'GENIE', 'GENIE', 'T', 'A']), 2000).find((x) => x.line === 0);
  assert.equal(w.symbol, 'GENIE'); assert.equal(w.count, 3);                          // 3 genies beat 4 tens
  w = evaluateLines(row(1, ['GENIE', 'GENIE', 'PRINCESS', 'PRINCESS', 'PRINCESS']), 2000).find((x) => x.line === 0);
  assert.equal(w.symbol, 'PRINCESS'); assert.equal(w.count, 5);                       // 5 princess beat 2 genies
  // genie never completes lamps or stars
  assert.equal(evaluateLines(row(1, ['LAMP', 'GENIE', 'LAMP', 'A', 'K']), 2000).filter((x) => x.line === 0).length, 0);
  // a line must start on reel 1
  assert.equal(evaluateLines(row(1, ['A', 'CROWN', 'CROWN', 'CROWN', 'CROWN']), 2000).filter((x) => x.line === 0).length, 0);
});

test('Wishing Stars pay anywhere and start free spins; free spins double wins and expand genies', () => {
  const g = grid({ '0,0': 'STAR', '2,2': 'STAR', '4,1': 'STAR' });
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: g }));
  assert.equal(r.out.scatterWin, 100 * SCATTER_PAY[3]); assert.equal(r.payout, 100 * SCATTER_PAY[3]);
  assert.equal(r.state.mode, 'free'); assert.equal(r.state.free.remaining, FREE_SPINS[3]); assert.equal(r.out.started.type, 'free');
  // a free spin costs nothing; genie on reel 2 expands; wins are doubled
  const fg = grid({ '0,1': 'EMERALD', '1,0': 'GENIE', '2,1': 'EMERALD' });
  const f = act(r.state, 'spin', { stake: 999999 }, ctx(2, { grid: fg }));
  assert.equal(f.stake, 0); assert.deepEqual(f.out.expanded, [1]);
  assert.ok(f.out.grid[1].every((s) => s === 'GENIE'));
  assert.equal(f.out.wins.find((w) => w.line === 0).amount, linePay('EMERALD', 3, 100, FREE_MULT));
  assert.equal(f.state.free.remaining, FREE_SPINS[3] - 1);
  assert.deepEqual(expandWilds([['STAR', 'GENIE', 'A']]).grid[0], ['STAR', 'GENIE', 'GENIE']);
});

test('a free-spins round is topped up to the guaranteed minimum, once, on its last spin', () => {
  let s = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,0': 'STAR', '1,0': 'STAR', '2,0': 'STAR' }) })).state;
  let paid = 0, last;
  while (s.mode === 'free') { last = act(s, 'spin', {}, ctx(7, { grid: grid() })); paid += last.payout; s = last.state; }
  assert.equal(paid, 100 * FREE_MIN_X); assert.equal(last.out.finished.topUp, 100 * FREE_MIN_X); assert.equal(last.out.finished.total, 100 * FREE_MIN_X);
  // a round that already paid more gets no top-up
  s = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,0': 'STAR', '1,0': 'STAR', '2,0': 'STAR' }) })).state;
  const full = Array.from({ length: 5 }, () => ['CROWN', 'CROWN', 'CROWN']);
  paid = 0;
  while (s.mode === 'free') { last = act(s, 'spin', {}, ctx(8, { grid: s.free.played === 0 ? full : grid() })); paid += last.payout; s = last.state; }
  assert.equal(last.out.finished.topUp, 0); assert.ok(paid > 100 * FREE_MIN_X);
});

test('free spins retrigger, finish, and stay under the spin cap', () => {
  let s = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,0': 'STAR', '1,0': 'STAR', '2,0': 'STAR' }) })).state;
  const re = act(s, 'spin', {}, ctx(2, { grid: grid({ '0,0': 'STAR', '1,0': 'STAR', '2,0': 'STAR', '3,0': 'STAR' }) }));
  assert.equal(re.out.triggers.retrigger, RETRIGGER[4]);
  assert.equal(re.state.free.remaining, FREE_SPINS[3] - 1 + RETRIGGER[4]);
  s = re.state; s.free.awarded = MAX_FREE_SPINS - 2;
  const capped = act(s, 'spin', {}, ctx(3, { grid: grid({ '0,0': 'STAR', '1,0': 'STAR', '2,0': 'STAR' }) }));
  assert.equal(capped.out.triggers.retrigger, 2);
  s = capped.state; let total = 0, last;
  while (s.mode === 'free') { last = act(s, 'spin', {}, ctx(4, { grid: grid() })); total += last.payout; s = last.state; }
  assert.equal(last.out.finished.type, 'free'); assert.equal(s.mode, 'base'); assert.equal(s.free, null);
});

test('Magic Lamps: 3+ grant a wish; cash and multiplied cash are paid with the spin', () => {
  const lamps = grid({ '0,1': 'LAMP', '2,0': 'LAMP', '4,2': 'LAMP' });
  const c = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: lamps, wish: 'CASH' }));
  assert.equal(c.out.wish.type, 'CASH'); assert.equal(c.payout, 100 * c.out.wish.x); assert.equal(c.state.mode, 'base');
  const m = act(init(), 'spin', { stake: 100 }, ctx(5, { grid: lamps, wish: 'MULT' }));
  assert.equal(m.out.wish.x, m.out.wish.base * m.out.wish.mult); assert.equal(m.payout, 100 * m.out.wish.x);
  const f = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: lamps, wish: 'FREE' }));
  assert.equal(f.state.mode, 'free'); assert.equal(f.state.free.remaining, WISH_FREE[3]);
  assert.equal(act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,1': 'LAMP', '2,0': 'LAMP' }) })).out.wish, null);
  // more lamps → bigger boost
  const r = seeded(9); for (let i = 0; i < 500; i++) { assert.ok(makeWish(3, r, 'CASH').x >= 5); assert.ok(makeWish(5, r, 'CASH').x >= 20); assert.ok(makeWish(3, r, 'MULT').x >= 6); }
});

test("Genie's Treasure: picks until three jewels match; pays jackpot + prizes × multiplier exactly once", () => {
  for (const jp of ['MINI', 'MINOR', 'MAJOR', 'GRAND']) for (let seed = 1; seed < 30; seed++) {
    const lamps = grid({ '0,1': 'LAMP', '2,0': 'LAMP', '4,2': 'LAMP' });
    let r = act(init(), 'spin', { stake: 200 }, ctx(seed, { grid: lamps, wish: 'TREASURE' }));
    assert.equal(r.state.mode, 'treasure');
    r.state.treasure = { ...dealTreasure(seeded(seed), jp), bet: 200, source: 'base' };
    // board: exactly one jewel kind has 3; others at most 2; at most one multiplier
    const deck = r.state.treasure.deck, count = {};
    deck.forEach((d) => { if (d.k === 'JP') count[d.v] = (count[d.v] || 0) + 1; });
    assert.equal(count[jp], 3); Object.entries(count).forEach(([k, n]) => k !== jp && assert.ok(n <= 2));
    assert.ok(deck.filter((d) => d.k === 'MULT').length <= 1); assert.equal(deck.length, TREASURE_TILES);
    let s = r.state, paid = 0, picks = 0, last;
    for (const tile of [11, 0, 5, 3, 7, 1, 2, 4, 6, 8, 9, 10]) {
      if (s.mode !== 'treasure') break;
      last = act(s, 'pick', { tile }, ctx(seed)); paid += last.payout; picks++; s = last.state;
    }
    assert.equal(last.out.treasureDone.won, jp);
    const t = last.out;
    assert.equal(paid, Math.floor(200 * (JACKPOTS[jp] + t.cashX) * t.mult));
    assert.equal(Object.keys(t.rest).length, TREASURE_TILES - picks);
    assert.equal(s.mode, 'base');
  }
});

test('treasure picks are validated: range, repeats and mode', () => {
  const s = { ...init(), mode: 'treasure', treasure: { ...dealTreasure(seeded(3), 'MINI'), bet: 100, source: 'base' } };
  assert.throws(() => act(s, 'pick', { tile: 12 }, ctx()), /Pick a treasure/);
  assert.throws(() => act(s, 'pick', { tile: '1' }, ctx()), /Pick a treasure/);
  const a = act(s, 'pick', { tile: 4 }, ctx());
  assert.throws(() => act(a.state, 'pick', { tile: 4 }, ctx()), /already open/);
  assert.throws(() => act(init(), 'pick', { tile: 0 }, ctx()), /no Genie's Treasure/);
  assert.throws(() => act(s, 'spin', { stake: 100 }, ctx()), /Finish Genie's Treasure/);
  // the tile tapped never changes what is found: the n-th pick is the n-th treasure dealt
  const b = act(s, 'pick', { tile: 9 }, ctx());
  assert.deepEqual(a.out.item, b.out.item);
});

test('treasure during free spins returns to the free spins afterwards', () => {
  let s = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ '0,0': 'STAR', '1,0': 'STAR', '2,0': 'STAR' }) })).state;
  const r = act(s, 'spin', {}, ctx(2, { grid: grid({ '0,1': 'LAMP', '2,0': 'LAMP', '4,2': 'LAMP' }), wish: 'TREASURE' }));
  assert.equal(r.state.mode, 'treasure'); assert.equal(r.state.treasure.source, 'free');
  s = r.state; let tile = 0;
  while (s.mode === 'treasure') s = act(s, 'pick', { tile: tile++ }, ctx()).state;
  assert.equal(s.mode, 'free'); assert.equal(s.free.remaining, FREE_SPINS[3] - 1);
});

test('stars and a treasure wish on one spin: treasure first, then the free spins', () => {
  const g = grid({ '0,0': 'STAR', '1,0': 'STAR', '2,2': 'STAR', '0,1': 'LAMP', '2,0': 'LAMP', '4,2': 'LAMP' });
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: g, wish: 'TREASURE' }));
  assert.equal(r.state.mode, 'treasure'); assert.deepEqual(r.out.view.queue, ['free']);
  let s = r.state, tile = 0, last;
  while (s.mode === 'treasure') { last = act(s, 'pick', { tile: tile++ }, ctx()); s = last.state; }
  assert.equal(last.out.started.type, 'free'); assert.equal(s.free.remaining, FREE_SPINS[3]);
});

test('stakes are validated; min and max bets work; no stake can be passed in free spins', () => {
  assert.throws(() => act(init(), 'spin', { stake: 5 }, ctx()), /at least/);
  assert.throws(() => act(init(), 'spin', { stake: 10001 }, ctx()), /at most/);
  assert.throws(() => act(init(), 'spin', { stake: 100.5 }, ctx()), /at least/);
  assert.throws(() => act(init(), 'spin', { stake: '100' }, ctx()), /at least/);
  assert.equal(act(init(), 'spin', { stake: 10 }, ctx(1, { grid: grid() })).stake, 10);
  assert.equal(act(init(), 'spin', { stake: 10000 }, ctx(1, { grid: grid() })).stake, 10000);
  assert.throws(() => act(init(), 'dance', {}, ctx()), /Unknown action/);
});

test('every grid has at most one lamp and one star per reel', () => {
  const r = seeded(77);
  for (let i = 0; i < 20000; i++) for (const free of [false, true]) {
    const g = draw(r, free);
    for (const col of g) { assert.ok(col.filter((s) => s === 'LAMP').length <= 1); assert.ok(col.filter((s) => s === 'STAR').length <= 1); }
  }
});

test('practice triggers cost and pay nothing, and end in the base game', () => {
  for (const ev of ['free', 'MINI', 'GRAND', 'CASH', 'MULT', 'FREE', 'TREASURE']) {
    let r = act(init(), 'dev', { event: ev, stake: 100 }, ctx(3));
    let s = r.state, guard = 0, staked = r.stake, paid = r.payout, tile = 0;
    while (s.mode !== 'base' && guard++ < 300) {
      r = s.mode === 'treasure' ? act(s, 'pick', { tile: tile++ % 12 }, ctx(guard)) : act(s, 'spin', {}, ctx(guard));
      if (s.mode === 'treasure' && r.state.mode !== 'treasure') tile = 0;
      s = r.state; staked += r.stake; paid += r.payout;
    }
    assert.equal(s.mode, 'base', ev); assert.equal(staked, 0, ev); assert.equal(paid, 0, ev); assert.equal(s.practice, false, ev);
  }
});

test('runs through the shared casino registry; the win cap holds', () => {
  const r = runGame('genie', null, 'spin', { stake: 100 }, ctx(1));
  assert.equal(r.stake, 100);
  const t = { ...dealTreasure(seeded(1), 'GRAND'), bet: 100, source: 'base' };
  t.deck = t.deck.map((d) => (d.k === 'CASH' ? { k: 'CASH', v: 4000 } : d));
  let s = { ...init(), mode: 'treasure', treasure: t }, total = 0, tile = 0;
  while (s.mode === 'treasure') { const x = act(s, 'pick', { tile: tile++ }, ctx()); total += x.payout; s = x.state; }
  assert.ok(total <= 100 * MAX_WIN_X);
});

test('long-run return is close to the 96% target and every jackpot is reachable', () => {
  const rand = seeded(2024), c = { rand, minStake: 10 };
  let s = init(), staked = 0, paid = 0, n = 0, tile = 0; const jp = {};
  while (n < 120000 || s.mode !== 'base') {
    let r;
    if (s.mode === 'treasure') { r = act(s, 'pick', { tile: tile++ }, c); if (r.out.treasureDone) { jp[r.out.treasureDone.won] = 1; tile = 0; } }
    else if (s.mode === 'free') r = act(s, 'spin', {}, c);
    else { r = act(s, 'spin', { stake: 1000 }, c); n++; }
    staked += r.stake; paid += r.payout; s = r.state;
  }
  const rtp = paid / staked;
  assert.ok(rtp > 0.85 && rtp < 1.08, `rtp ${rtp}`);
  assert.ok(jp.MINI && jp.MINOR, 'jackpots reached');
  assert.equal(treasureTotals({ picks: {}, order: [] }).won, null);
  assert.ok(pickTreasure);
});
