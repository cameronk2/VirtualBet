// Cluck Crossing: maths per difficulty, every state, and money safety.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { act, init } from '../server/games/chicken/engine.js';
import { DIFF_IDS, RTP, TABLES } from '../server/games/chicken/config.js';

const ctx = (r = 0.999, extra = {}) => ({ rand: typeof r === 'function' ? r : () => r, now: 1_700_000_000_000, minStake: 10, maxStake: 50000, ...extra });
const SAFE = () => 0.999, HIT = () => 0;
const started = (difficulty = 'medium', stake = 100) => act(init(), 'start', { stake, difficulty }, ctx()).state;

test('each difficulty has its own lanes, risks and multipliers, and every cash-out point returns RTP', () => {
  const tops = {};
  for (const d of DIFF_IDS) {
    const t = TABLES[d];
    assert.equal(t.risks.length, t.lanes); assert.equal(t.mults.length, t.lanes);
    let p = 1;
    t.risks.forEach((r, i) => {
      assert.ok(r > 0 && r < 1);
      if (i) { assert.ok(r >= t.risks[i - 1], 'risk never falls'); assert.ok(t.mults[i] > t.mults[i - 1], 'multiplier always rises'); }
      p *= 1 - r;
      const ret = p * t.mults[i];
      assert.ok(ret <= RTP + 1e-9 && ret > RTP - 0.01 * p * 100 / 100 - 0.01, `${d} lane ${i + 1} returns ${ret}`);
    });
    tops[d] = t;
  }
  assert.ok(tops.easy.risks[0] < tops.medium.risks[0] && tops.medium.risks[0] < tops.hard.risks[0] && tops.hard.risks[0] < tops.hardcore.risks[0]);
  assert.ok(tops.easy.mults[0] < tops.medium.mults[0] && tops.medium.mults[0] < tops.hard.mults[0] && tops.hard.mults[0] < tops.hardcore.mults[0]);
});

test('start takes the stake; steps move lane by lane; cash out pays bet × current multiplier once', () => {
  let r = act(init(), 'start', { stake: 250, difficulty: 'hard' }, ctx());
  assert.equal(r.stake, 250); assert.equal(r.state.mode, 'run'); assert.equal(r.out.view.round.next.mult, TABLES.hard.mults[0]);
  assert.throws(() => act(r.state, 'cashout', {}, ctx()), /at least one lane/);
  for (let i = 1; i <= 3; i++) { r = act(r.state, 'step', {}, ctx(SAFE)); assert.equal(r.out.lane, i); assert.equal(r.payout, 0); assert.equal(r.stake, 0); }
  const st = r.state;
  r = act(st, 'cashout', {}, ctx());
  assert.equal(r.payout, Math.floor(250 * TABLES.hard.mults[2])); assert.equal(r.state.mode, 'idle');
  assert.equal(r.state.recent[0].result, 'cashout'); assert.equal(r.state.recent[0].mult, TABLES.hard.mults[2]); assert.equal(r.state.recent[0].at, 1_700_000_000_000);
  assert.throws(() => act(r.state, 'cashout', {}, ctx()), /no round/, 'no double cash-out');
  assert.throws(() => act(r.state, 'step', {}, ctx()), /no round/);
});

test('a hit loses the bet and ends the round; no cash-out after losing', () => {
  let r = act(started('easy', 100), 'step', {}, ctx(SAFE));
  r = act(r.state, 'step', {}, ctx(HIT));
  assert.equal(r.out.hit, true); assert.equal(r.out.lane, 2); assert.equal(r.payout, 0); assert.equal(r.state.mode, 'idle');
  assert.equal(r.state.recent[0].result, 'hit'); assert.equal(r.state.recent[0].payout, 0);
  assert.throws(() => act(r.state, 'cashout', {}, ctx()), /no round/);
});

test('the outcome uses the lane risk exactly (roll < risk = hit)', () => {
  for (const d of DIFF_IDS) {
    const risk = TABLES[d].risks[0];
    assert.equal(act(started(d), 'step', {}, ctx(risk - 1e-9)).out.hit, true);
    assert.equal(act(started(d), 'step', {}, ctx(risk)).out.safe, true);
  }
});

test('crossing every lane pays the top multiplier automatically', () => {
  for (const d of DIFF_IDS) {
    let r = { state: started(d, 100) };
    for (let i = 0; i < TABLES[d].lanes; i++) r = act(r.state, 'step', {}, ctx(SAFE));
    assert.equal(r.out.finished, true); assert.equal(r.payout, Math.floor(100 * TABLES[d].mults.at(-1))); assert.equal(r.state.mode, 'idle');
  }
});

test('one round at a time; stake limits and difficulty are enforced', () => {
  const st = started();
  assert.throws(() => act(st, 'start', { stake: 100, difficulty: 'easy' }, ctx()), /already in play/);
  assert.throws(() => act(init(), 'start', { stake: 5, difficulty: 'easy' }, ctx()), /at least/);
  assert.throws(() => act(init(), 'start', { stake: 50001, difficulty: 'easy' }, ctx()), /at most/);
  assert.throws(() => act(init(), 'start', { stake: 100, difficulty: 'insane' }, ctx()), /difficulty/);
  assert.equal(act(init(), 'start', { stake: 10, difficulty: 'easy' }, ctx()).stake, 10);
  assert.equal(act(init(), 'start', { stake: 50000, difficulty: 'easy' }, ctx()).stake, 50000);
});

test('the saved state survives a reload mid-round', () => {
  let r = runGame('chicken', null, 'start', { stake: 100, difficulty: 'medium' }, ctx());
  r = runGame('chicken', JSON.parse(JSON.stringify(r.state)), 'step', {}, ctx(SAFE));
  const saved = JSON.parse(JSON.stringify(r.state));
  assert.equal(saved.round.lane, 1);
  r = runGame('chicken', saved, 'cashout', {}, ctx());
  assert.equal(r.payout, Math.floor(100 * TABLES.medium.mults[0]));
});

test('simulated play matches the configured RTP for every difficulty and target lane', () => {
  let seed = 7;
  const rand = () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
  for (const d of DIFF_IDS) for (const target of [1, 3, Math.ceil(TABLES[d].lanes / 3)]) {
    let paid = 0, won = 0;
    const n = 40000;
    for (let k = 0; k < n; k++) {
      let r = act(init(), 'start', { stake: 100, difficulty: d }, ctx(rand)); paid += r.stake;
      for (let i = 0; i < target && r.state.mode === 'run'; i++) r = act(r.state, 'step', {}, ctx(rand));
      if (r.state.mode === 'run') r = act(r.state, 'cashout', {}, ctx(rand));
      won += r.payout;
    }
    const rtp = won / paid, p = TABLES[d].risks.slice(0, target).reduce((a, x) => a * (1 - x), 1);
    const sd = Math.sqrt(p * (1 - p) / n) * TABLES[d].mults[target - 1];
    assert.ok(Math.abs(rtp - RTP) < 4 * sd + 0.01, `${d} cash at ${target}: ${rtp.toFixed(4)}`);
  }
});
