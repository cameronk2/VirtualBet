// Brick by Brick: ways, six-hat free spins, three-saw wheel and every wheel feature.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runGame } from '../server/games/registry.js';
import { act, init } from '../server/games/brick/engine.js';
import { evaluateWays } from '../server/games/brick/reels.js';
import { applyHat, mansions, megaHat, revealHouses, sawSweep } from '../server/games/brick/features.js';
import { FREE_SPINS, HOUSE, JACKPOTS, MAX_WIN_X, PAYTABLE } from '../server/games/brick/config.js';

const seeded = (seed) => () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
const ctx = (seed = 1, inject) => ({ rand: seeded(seed), minStake: 10, inject });
const DEAD = [['A', 'K', 'Q'], ['J', 'T', 'N'], ['TAPE', 'TOOLBOX', 'P3'], ['A', 'K', 'Q'], ['J', 'T', 'N']];
const grid = (edits = {}) => DEAD.map((col, r) => col.map((s, row) => edits[`${r},${row}`] ?? s));
const emptyFree = () => Array.from({ length: 5 }, () => [null, null, null]);
const SIX_HATS = { '0,0': 'HAT', '1,1': 'HAT', '2,2': 'HAT', '3,0': 'HAT', '4,1': 'HAT', '2,0': 'HAT' };
const THREE_SAWS = { '0,1': 'SAW', '2,1': 'SAW', '4,0': 'SAW' };

test('a dead spin charges the stake and pays nothing', () => {
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid() }));
  assert.equal(r.stake, 100); assert.equal(r.payout, 0); assert.equal(r.state.mode, 'base');
});

test('243 ways: every symbol pays its table value; ways multiply; wild substitutes on reels 2-4 only', () => {
  for (const [sym, pays] of Object.entries(PAYTABLE)) for (let n = 3; n <= 5; n++) {
    const g = DEAD.map((c) => c.map(() => 'HAT'));
    for (let r = 0; r < n; r++) g[r][1] = sym;
    const w = evaluateWays(g, 10000).find((x) => x.symbol === sym);
    assert.equal(w.amount, pays[n - 3] * 100, `${sym} x${n}`);
  }
  const g = DEAD.map((c) => c.map(() => 'HAT'));
  g[0][0] = 'P1'; g[0][1] = 'P1'; g[1][2] = 'WILD'; g[2][0] = 'P1'; g[2][1] = 'WILD';
  const w = evaluateWays(g, 100).find((x) => x.symbol === 'P1');
  assert.equal(w.ways, 2 * 1 * 2); assert.equal(w.amount, Math.floor(100 * PAYTABLE.P1[0] * 4 / 100));
  const g2 = DEAD.map((c) => c.map(() => 'HAT')); g2[0][0] = 'WILD'; g2[1][0] = 'P1'; g2[2][0] = 'P1';
  assert.equal(evaluateWays(g2, 100).length, 0, 'wild on reel 1 does not count');
});

test('six hats: free spins start with a straw frame on every triggering hat', () => {
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid(SIX_HATS) }));
  assert.equal(r.out.triggers.hats, true);
  assert.equal(r.state.mode, 'free');
  assert.equal(r.state.free.kind, 'hats');
  assert.equal(r.state.free.remaining, FREE_SPINS);
  assert.deepEqual(Object.keys(r.state.free.frames).sort(), ['0,0', '1,1', '2,2', '3,0', '4,1', '2,0'].sort());
  assert.ok(Object.values(r.state.free.frames).every((t) => t === 1));
  assert.throws(() => act(r.state, 'wheel', {}, ctx()), /no wheel/);
  const five = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ ...SIX_HATS, '2,0': 'P3' }) }));
  assert.equal(five.state.mode, 'base', 'five hats do not trigger');
});

test('hat stages: frame → stick → brick; a hat on a brick upgrades another frame; 3 hats = +1 spin', () => {
  const frames = {};
  assert.deepEqual(applyHat(frames, 1, 1, seeded(1)), { cell: [1, 1], from: 0, to: 1 });
  applyHat(frames, 1, 1, seeded(1)); applyHat(frames, 1, 1, seeded(1));
  assert.equal(frames['1,1'], 3);
  frames['0,0'] = 1;
  const r = applyHat(frames, 1, 1, seeded(1));
  assert.deepEqual(r.redirect, [0, 0]); assert.equal(frames['0,0'], 2);
  // all brick → new straw frame elsewhere
  const all = { '1,1': 3 };
  const r2 = applyHat(all, 1, 1, seeded(2));
  assert.equal(r2.to, 1); assert.equal(Object.keys(all).length, 2);
  // free spin with 3 hats gives +1
  let st = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid(SIX_HATS) })).state;
  const g = emptyFree(); g[0][2] = 'HAT'; g[1][2] = 'HAT'; g[3][2] = 'HAT';
  const s1 = act(st, 'spin', {}, ctx(3, { grid: g }));
  assert.equal(s1.stake, 0);
  assert.equal(s1.out.extra, 1);
  assert.equal(s1.state.free.remaining, FREE_SPINS);
});

test('the wolf: houses revealed straw → stick → brick, paid once at the end', () => {
  let st = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid(SIX_HATS) })).state;
  let r, paid = 0;
  for (let i = 0; i < 20 && st.mode === 'free'; i++) { r = act(st, 'spin', {}, ctx(10 + i, { grid: emptyFree() })); paid += r.payout; if (st.mode === 'free' && r.state.mode === 'free') assert.equal(r.payout, 0); st = r.state; }
  const tiers = r.out.reveal.houses.map((h) => h.tier);
  assert.deepEqual(tiers, [...tiers].sort());
  for (const h of r.out.reveal.houses) assert.ok(HOUSE[h.tier].some(([v]) => v === h.prize || (h.prize === 10 && h.tier === 3)), `${h.tier} ${h.prize}`);
  assert.equal(paid, Math.min(Math.floor(100 * (r.out.reveal.totalX + r.out.reveal.prizesX)), 100 * MAX_WIN_X));
  assert.equal(r.out.finished.played, FREE_SPINS);
});

test('three saws: the wheel starts first; tapping it reveals the pre-decided wedge', () => {
  const r = act(init(), 'spin', { stake: 100 }, ctx(1, { grid: grid({ ...THREE_SAWS, ...SIX_HATS, '2,1': 'SAW' }) }));
  assert.equal(r.state.mode, 'wheel');
  assert.deepEqual(r.state.queue.map((q) => q.type), ['free'], 'hat free spins wait behind the wheel');
  assert.throws(() => act(r.state, 'spin', { stake: 100 }, ctx()), /wheel/);
  const wedge = r.state.wheel.wedge;
  const w = act(r.state, 'wheel', {}, ctx(99));
  assert.equal(w.out.wedge, wedge, 'outcome fixed when the wheel appeared');
});

test('every wheel wedge: jackpots pay; Buzz Saw, Mansions and Mega Hat start 6 free spins correctly', () => {
  const saws = [[0, 1], [2, 1], [4, 0]];
  for (const wedge of ['MINI', 'MINOR', 'MAJOR', 'GRAND', 'BUZZSAW', 'MANSIONS', 'MEGAHAT']) {
    const st = { ...init(), mode: 'wheel', wheel: { bet: 100, saws, source: 'saws', wedge } };
    const r = act(st, 'wheel', {}, ctx(5));
    if (JACKPOTS[wedge]) { assert.equal(r.payout, 100 * JACKPOTS[wedge]); assert.equal(r.state.mode, 'base'); continue; }
    assert.equal(r.payout, 0);
    assert.equal(r.state.mode, 'free'); assert.equal(r.state.free.remaining, FREE_SPINS);
    const f = r.state.free.frames;
    if (wedge === 'MANSIONS') for (const [c, rr] of saws) assert.equal(f[`${c},${rr}`], 3, 'brick frame on every saw');
    if (wedge === 'BUZZSAW') {
      // each saw sweeps right: every cell from the saw to reel 5 on its row is hit
      for (const [c, rr] of saws) for (let cc = c; cc < 5; cc++) assert.ok(f[`${cc},${rr}`] >= 1);
      assert.ok(f['4,1'] >= 2, 'cells swept twice are upgraded');
    }
    if (wedge === 'MEGAHAT') { const m = r.out.started.pre.mega; assert.equal(m.cells.length, m.w * m.h); for (const [c, rr] of m.cells) assert.ok(f[`${c},${rr}`] >= 1); }
  }
});

test('sweep order: rightmost saw first; a megahat block stays on the reels', () => {
  const steps = sawSweep({}, [[0, 0], [3, 0]], seeded(1));
  assert.deepEqual(steps.map((s) => s.saw), [[3, 0], [0, 0]]);
  for (let s = 1; s < 50; s++) { const m = megaHat({}, seeded(s)); assert.ok(m.col + m.w <= 5 && m.row + m.h <= 3); }
  assert.deepEqual(mansions({}, [[1, 1]]), [{ cell: [1, 1], to: 3 }]);
});

test('a brick house can award a wheel spin (hat free spins only)', () => {
  let seen = 0;
  for (let s = 1; s < 3000 && !seen; s++) { const rv = revealHouses({ '0,0': 3, '1,0': 3, '2,0': 3, '3,0': 3 }, seeded(s), true); seen += rv.wheels; }
  assert.ok(seen > 0);
  for (let s = 1; s < 500; s++) assert.equal(revealHouses({ '0,0': 3 }, seeded(s), false).wheels, 0);
});

test('practice triggers cost nothing and pay nothing; refresh-safe state', () => {
  for (const [event, wedge] of [['hats'], ['saws', 'MANSIONS'], ['saws', 'GRAND']]) {
    let r = runGame('brick', null, 'dev', { event, stake: 100, wedge }, ctx());
    let st = JSON.parse(JSON.stringify(r.state)); // survives a save/reload
    for (let i = 0; i < 60 && st.mode !== 'base'; i++) {
      r = runGame('brick', st, st.mode === 'wheel' ? 'wheel' : 'spin', {}, ctx(i));
      assert.equal(r.stake, 0); assert.equal(r.payout, 0);
      st = JSON.parse(JSON.stringify(r.state));
    }
    assert.equal(st.mode, 'base'); assert.equal(st.practice, false);
  }
});

test('real API: 15,000 spins, features play out, money adds up, cap respected', () => {
  let st = null, paid = 0, n = 0;
  const seen = new Set();
  const c = ctx(777);
  while (n < 15000 || (st && st.mode !== 'base')) {
    const mode = st?.mode || 'base';
    const r = runGame('brick', st, mode === 'wheel' ? 'wheel' : 'spin', mode === 'base' ? { stake: 100 } : {}, c);
    if (mode === 'base') { n++; assert.equal(r.stake, 100); } else assert.equal(r.stake, 0);
    if (r.out.started) seen.add(r.out.started.type === 'free' ? r.out.started.kind : 'wheel');
    if (r.out.jackpot) seen.add('jackpot');
    assert.ok(Number.isSafeInteger(r.payout) && r.payout >= 0 && r.payout <= 100 * MAX_WIN_X);
    paid += r.stake; st = r.state;
  }
  assert.equal(paid, 1500000);
  for (const k of ['hats', 'wheel', 'buzzsaw', 'mansions', 'megahat']) assert.ok(seen.has(k), k);
});
