// Virtual horse racing for the single-file build (everything runs in this browser). The same engine
// as the server (server/racing/core.js): race cards, the simulation, odds, pricing and settlement,
// with the timetable, bets and records kept in this device's storage.
import { COURSES, FORMATS, buildHorses, courseById, formatById } from '../../server/racing/data.js';
import { BET_TYPES, checkBet, composite, fracLabel, makeCard, outcome, potential, priceBet, resultOf, settle, simulate } from '../../server/racing/core.js';

const SLOT_MS = 3 * 60 * 1000, AHEAD_MS = 30 * 60 * 1000, CLOSE_MS = 5000, REST_MS = 25 * 60 * 1000;
const RACE_LIST = ['sprint', 'sprint_h', 'mile', 'sprint', 'middle', 'mile', 'middle_h', 'staying', 'sprint_h', 'champ'];
const SIMS = 260; // fewer odds simulations than the server, so phones stay quick
let HORSES = null;
const base = () => (HORSES ||= buildHorses());

export function createRacing({ state, save, change, requireUser, fail, now, checkBreak, effectiveLimit, staked24h, rand, award }) {
  const R = () => (state.racing ||= { horses: {}, races: [], bets: [], favs: { horses: [], courses: [] }, nextId: 1, nextBet: 1 });
  const horse = (id) => { const h = base()[id - 1]; const s = R().horses[id] || {}; return { ...h, runs: s.runs || 0, wins: s.wins || 0, places: s.places || 0, earnings: s.earnings || 0, form: s.form || '', lastRunAt: s.lastRunAt || null }; };
  const allHorses = () => base().map((h) => horse(h.id));
  const busy = (off) => { const ids = new Set(); for (const r of R().races) if ((r.off != null && Math.abs(r.off - off) < REST_MS) || (r.kind === 'quick' && r.status === 'open')) r.card.runners.forEach((x) => ids.add(x.horseId)); return ids; };
  const plan = (k) => ({ course: COURSES[Math.floor(k / 5) % COURSES.length].id, format: RACE_LIST[(k * 7 + Math.floor(k / 5)) % RACE_LIST.length] });

  function ensure(t, limit = 1) {
    const first = Math.floor(t / SLOT_MS) + 1, last = Math.floor((t + AHEAD_MS) / SLOT_MS);
    let made = 0;
    for (let k = first; k <= last && made < limit; k++) {
      if (R().races.some((r) => r.slot === k)) continue;
      const off = k * SLOT_MS, p = plan(k), b = busy(off);
      const card = makeCard({ pool: allHorses().filter((h) => !b.has(h.id)), rand, courseId: p.course, formatId: p.format, off, sims: SIMS });
      R().races.push({ id: R().nextId++, kind: 'sched', slot: k, course: p.course, off, status: 'open', card, created: t });
      made++;
    }
    return made;
  }
  function run(r, t) {
    const horses = r.card.runners.map((x) => horse(x.horseId));
    const sim = simulate(r.card, horses, rand, { trace: true });
    r.result = resultOf(r.card, sim);
    r.trace = { ...sim.trace, order: sim.order.map((i) => r.card.runners[i].no) };
    r.duration = sim.trace.frames.length * sim.trace.every;
    r.off = r.off ?? t; r.status = 'finished';
  }
  function settleRace(r, t) {
    if (r.settledAt) return;
    r.settledAt = t;
    const prize = [0.6, 0.2, 0.1, 0.05, 0.03, 0.02];
    for (const p of r.result.positions) {
      const x = r.card.runners.find((y) => y.no === p.no);
      const s = (R().horses[x.horseId] ||= {});
      s.runs = (s.runs || 0) + 1; s.wins = (s.wins || 0) + (p.pos === 1 ? 1 : 0); s.places = (s.places || 0) + (p.pos <= 3 ? 1 : 0);
      s.earnings = (s.earnings || 0) + Math.round(r.card.prize * (prize[p.pos - 1] || 0)); s.form = (String(p.pos <= 9 ? p.pos : 0) + (s.form || '')).slice(0, 12); s.lastRunAt = r.off;
      (s.history ||= []).unshift({ raceId: r.id, no: x.no, jockey: x.jockey, pos: p.pos, time: p.time, margin: p.margin, odds: fracLabel(x.odds), off: r.off, kind: r.kind });
      s.history = s.history.slice(0, 25);
    }
    for (const b of R().bets.filter((x) => x.raceId === r.id && x.status === 'open')) {
      const ret = settle(b, r.result);
      b.status = outcome(b, r.result, ret); b.returns = ret; b.settledAt = t;
      if (ret > 0) change('RACING_WIN', ret, 'racing', `Racing return · ${r.card.name} · ${BET_TYPES[b.type].name}`);
    }
  }
  function tick(t) {
    let changed = false;
    for (const r of R().races) {
      if (r.kind === 'sched' && r.status === 'open' && r.off <= t) { run(r, t); changed = true; }
      if (r.status === 'finished' && !r.settledAt && r.off + r.duration * 1000 <= t) { settleRace(r, t); changed = true; }
    }
    if (ensure(t, R().races.filter((r) => r.kind === 'sched' && r.status === 'open').length < 3 ? 2 : 1)) changed = true;
    // keep storage small: drop old finished races that nobody bet on
    const keep = new Set(R().bets.map((b) => b.raceId));
    const before = R().races.length;
    R().races = R().races.filter((r) => r.status === 'open' || keep.has(r.id) || r.off > t - 6 * 3600000);
    const fin = R().races.filter((r) => r.status === 'finished' && !keep.has(r.id)).sort((a, b) => b.off - a.off);
    if (fin.length > 40) { const drop = new Set(fin.slice(40).map((r) => r.id)); R().races = R().races.filter((r) => !drop.has(r.id)); }
    if (changed || R().races.length !== before) save();
  }
  const phase = (r, t) => (r.status === 'open' ? (r.kind === 'quick' ? 'ready' : t < r.off - CLOSE_MS ? 'open' : 'closing') : t < r.off + (r.duration || 0) * 1000 + 1500 ? 'live' : 'result');
  function view(r, t, full = true) {
    const card = r.card, ph = phase(r, t);
    const out = { id: r.id, kind: r.kind, owner: r.kind === 'quick' ? 1 : null, off: r.off, phase: ph, course: card.course, courseName: card.courseName, name: card.name, type: card.type, format: card.format, formatName: formatById[card.format]?.name, handicap: card.handicap, distance: card.distance, distanceLabel: card.distanceLabel, furlongs: card.furlongs, going: card.going, goingName: card.goingName, field: card.field, terms: card.terms, prize: card.prize, duration: r.duration,
      runners: card.runners.map((x) => ({ ...x, oddsLabel: fracLabel(x.odds), chance: undefined, placeChance: undefined })) };
    if (ph === 'live' || ph === 'result') { out.result = r.result; if (full) out.trace = r.trace; out.favourite = [...card.runners].sort((a, b) => a.odds.dec - b.odds.dec)[0].no; }
    if (!full) delete out.runners;
    return out;
  }
  const summary = (r, t) => { const v = view(r, t, false); v.top = r.card.runners.slice().sort((a, b) => a.odds.dec - b.odds.dec).slice(0, 3).map((x) => ({ no: x.no, name: x.name, odds: fracLabel(x.odds), silks: x.silks })); if (v.result) v.winner = r.card.runners.find((x) => x.no === v.result.positions[0].no)?.name; return v; };
  const betView = (b) => { const r = R().races.find((x) => x.id === b.raceId); const t = now(); const v = { ...b, ref: `R${String(b.id).padStart(6, '0')}`, typeName: BET_TYPES[b.type].name, names: r ? b.picks.map((no) => r.card.runners.find((x) => x.no === no)?.name) : [], race: r && { id: r.id, name: r.card.name, courseName: r.card.courseName, off: r.off, phase: phase(r, t), kind: r.kind } }; if (r && phase(r, t) === 'live') { v.status = 'running'; v.returns = 0; } return v; };
  const getRace = (id) => { const r = R().races.find((x) => x.id === id); if (!r) fail(404, 'Race not found.'); return r; };

  return function handle(method, p, qy, body) {
    if (!p.startsWith('/api/racing')) return undefined;
    const t = now();
    tick(t);
    const key = `${method} ${p}`;
    let m;
    if (key === 'GET /api/racing') {
      const sched = R().races.filter((r) => r.kind === 'sched');
      const upcoming = sched.filter((r) => r.status === 'open').sort((a, b) => a.off - b.off).slice(0, 12).map((r) => summary(r, t));
      const recent = sched.filter((r) => r.status === 'finished').sort((a, b) => b.off - a.off).slice(0, 30).map((r) => summary(r, t));
      const day = new Date(t); day.setHours(0, 0, 0, 0);
      return { now: t, slotMs: SLOT_MS, next: upcoming[0] || null, live: recent.filter((r) => r.phase === 'live'), upcoming, results: recent.filter((r) => r.phase === 'result').slice(0, 20),
        today: sched.filter((r) => r.off >= day.getTime() && r.off < day.getTime() + 86400000).sort((a, b) => a.off - b.off).map((r) => summary(r, t)),
        quick: R().races.filter((r) => r.kind === 'quick').sort((a, b) => b.id - a.id).slice(0, 5).map((r) => summary(r, t)),
        courses: COURSES.map(({ scene, ...c }) => ({ ...c, next: upcoming.find((u) => u.course === c.id)?.off || null })), formats: FORMATS.map((f) => ({ id: f.id, name: f.name, type: f.type, furlongs: f.furlongs, fields: f.fields })) };
    }
    if (key === 'GET /api/racing/races') {
      const st = qy.get('status') || 'upcoming';
      const list = R().races.filter((r) => r.kind === 'sched' && (st === 'results' ? r.status === 'finished' : r.status === 'open')).sort((a, b) => (st === 'results' ? b.off - a.off : a.off - b.off)).map((r) => summary(r, t));
      return { races: list.filter((r) => st !== 'results' || r.phase === 'result').slice(0, 40) };
    }
    if (method === 'GET' && (m = /^\/api\/racing\/races\/(\d+)$/.exec(p))) {
      const r = getRace(Number(m[1])); const v = view(r, t);
      v.myBets = R().bets.filter((b) => b.raceId === r.id).map(betView);
      return v;
    }
    if (key === 'POST /api/racing/quick') {
      requireUser();
      const fmt = formatById[body?.format]; if (!fmt) fail(400, 'Choose a race type.');
      if (body.field != null && !fmt.fields.includes(body.field)) fail(400, `${fmt.name} races have ${fmt.fields.join(', ')} runners.`);
      if (R().races.filter((r) => r.kind === 'quick' && r.status === 'open').length >= 3) fail(400, 'Run or finish one of your virtual races first (up to 3 can be waiting).');
      const b = busy(t);
      const card = makeCard({ pool: allHorses().filter((h) => !b.has(h.id)), rand, courseId: courseById[body.course] ? body.course : COURSES[Math.floor(rand() * COURSES.length)].id, formatId: fmt.id, field: body.field || undefined, sims: SIMS });
      const r = { id: R().nextId++, kind: 'quick', course: card.course, off: null, status: 'open', card, created: t };
      R().races.push(r); save();
      return { ...view(r, t), myBets: [] };
    }
    if (method === 'POST' && (m = /^\/api\/racing\/races\/(\d+)\/start$/.exec(p))) {
      const pr = requireUser(); const r = getRace(Number(m[1]));
      if (r.kind !== 'quick') fail(404, 'Race not found.');
      if (r.status !== 'open') fail(400, 'This race has already been run.');
      checkBreak(pr);
      run(r, t); settleRace(r, t); save();
      const v = view(r, t); v.myBets = R().bets.filter((b) => b.raceId === r.id).map(betView);
      return { race: v };
    }
    if (key === 'POST /api/racing/quote') {
      const r = getRace(body?.raceId);
      return { bets: (Array.isArray(body?.bets) ? body.bets.slice(0, 20) : []).map((b) => {
        const picks = Array.isArray(b?.picks) ? b.picks.map(Number) : [];
        const err = checkBet(r.card, { type: b?.type, picks, stake: b?.stake });
        const price = err ? null : priceBet(r.card, b.type, picks);
        const lines = BET_TYPES[b?.type]?.lines || 1;
        const bet = price ? { type: b.type, picks, stake: b.stake, lines, total: b.stake * lines, price } : null;
        return { error: err || (price ? null : 'Not available'), price, lines, total: bet?.total ?? 0, potential: bet ? potential(bet) : 0 };
      }) };
    }
    if (key === 'POST /api/racing/bets') {
      const pr = requireUser();
      const { raceId, bets, nonce } = body || {};
      if (typeof nonce !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(nonce)) fail(400, 'Bet reference missing. Please try again.');
      if (!Array.isArray(bets) || !bets.length || bets.length > 20) fail(400, 'Add between 1 and 20 bets to the slip.');
      const r = getRace(raceId);
      if (r.status !== 'open' || (r.kind === 'sched' && t >= r.off - CLOSE_MS)) fail(400, 'Betting on this race has closed.');
      if (R().bets.some((b) => b.nonce === nonce)) fail(409, 'These bets have already been placed.');
      const priced = bets.map((b) => {
        const picks = Array.isArray(b?.picks) ? b.picks.map(Number) : [];
        const err = checkBet(r.card, { type: b?.type, picks, stake: b?.stake }); if (err) fail(400, err);
        const price = priceBet(r.card, b.type, picks); if (!price) fail(400, 'That bet is not available on this race.');
        const lines = BET_TYPES[b.type].lines; const x = { type: b.type, picks, stake: b.stake, lines, total: b.stake * lines, price }; x.potential = potential(x); return x;
      });
      const total = priced.reduce((a, b) => a + b.total, 0);
      checkBreak(pr);
      const limit = effectiveLimit(pr);
      if (limit != null && staked24h() + total > limit) fail(400, 'This would exceed your daily stake limit.');
      if (total > pr.balance) fail(400, `Not enough virtual balance: these bets cost £${(total / 100).toFixed(2)}.`);
      change('RACING_BET', -total, 'racing', `Racing · ${r.card.name} · ${priced.length} bet${priced.length > 1 ? 's' : ''}`);
      const placed = priced.map((b) => { const x = { id: R().nextBet++, raceId, ...b, status: 'open', returns: 0, nonce, at: t, settledAt: null }; R().bets.unshift(x); return x; });
      R().bets = R().bets.slice(0, 500);
      award?.([{ t: 'played', game: 'racing' }]);
      save();
      return { placed: placed.map(betView), total };
    }
    if (key === 'GET /api/racing/bets') {
      requireUser(); const st = qy.get('status') || 'all';
      return { bets: R().bets.filter((b) => st === 'all' || (st === 'open' ? b.status === 'open' : b.status !== 'open')).slice(0, 100).map(betView) };
    }
    if (key === 'GET /api/racing/stats') {
      requireUser();
      const set = R().bets.filter((b) => b.status !== 'open'), open = R().bets.filter((b) => b.status === 'open');
      const staked = set.reduce((a, b) => a + b.total, 0), returned = set.reduce((a, b) => a + b.returns, 0);
      const favs = new Map();
      for (const b of R().bets) { const r = R().races.find((x) => x.id === b.raceId); if (!r) continue; for (const no of b.picks) { const x = r.card.runners.find((y) => y.no === no); if (x) favs.set(x.horseId, { id: x.horseId, name: x.name, n: (favs.get(x.horseId)?.n || 0) + 1 }); } }
      return { bets: set.length, staked, returned, profit: returned - staked, winRate: set.length ? set.filter((b) => b.returns > 0).length / set.length : 0, best: Math.max(0, ...set.map((b) => b.returns - b.total)), open: open.length, openStake: open.reduce((a, b) => a + b.total, 0), favouriteHorses: [...favs.values()].sort((a, b) => b.n - a.n).slice(0, 5), recent: R().bets.slice(0, 10).map(betView) };
    }
    if (key === 'GET /api/racing/leaderboard') {
      const period = qy.get('period') || 'week'; const since = period === 'all' ? 0 : t - (period === 'month' ? 30 : 7) * 86400000;
      const set = R().bets.filter((b) => b.status !== 'open' && b.at >= since);
      const name = state.profile?.username || 'You';
      const row = set.length ? [{ name, bets: set.length, profit: set.reduce((a, b) => a + b.returns - b.total, 0), winners: set.filter((b) => b.returns > 0).length, winRate: set.filter((b) => b.returns > 0).length / set.length, best: Math.max(0, ...set.map((b) => b.returns - b.total)) }] : [];
      return { period, profit: row, winners: row, best: row.filter((r) => r.best > 0), winRate: row.filter((r) => r.bets >= 10), active: row };
    }
    if (key === 'GET /api/racing/horses') {
      const s = (qy.get('q') || '').toLowerCase();
      return { horses: allHorses().filter((h) => h.name.toLowerCase().includes(s)).sort((a, b) => b.wins - a.wins || a.name.localeCompare(b.name)).slice(0, 30).map((h) => ({ id: h.id, name: h.name, age: h.age, sex: h.sex, coat: h.coat, trainer: h.trainer, form: h.form, runs: h.runs, wins: h.wins, places: h.places, rating: composite(h), silks: h.silks })) };
    }
    if (method === 'GET' && (m = /^\/api\/racing\/horses\/(\d+)$/.exec(p))) {
      const id = Number(m[1]); if (!base()[id - 1]) fail(404, 'Horse not found.');
      const h = horse(id); const hist = (R().horses[id]?.history || []).filter((x) => x.kind !== 'quick' && x.off + 60000 < t);
      const runsList = hist.map((x) => { const r = R().races.find((y) => y.id === x.raceId); return { ...x, race: r?.card.name || 'Race', course: r?.card.courseName || '', distance: r?.card.distanceLabel || '', going: r?.card.goingName || '', field: r?.card.field || '' }; });
      const jockeys = [...runsList.reduce((mm, r) => mm.set(r.jockey, (mm.get(r.jockey) || 0) + 1), new Map())].map(([n, c]) => ({ name: n, n: c }));
      const next = R().races.filter((r) => r.kind === 'sched' && r.status === 'open').sort((a, b) => a.off - b.off).find((r) => r.card.runners.some((x) => x.horseId === id));
      return { ...h, rating: composite(h), runsList, jockeys, next: next ? summary(next, t) : null, favourite: R().favs.horses.includes(id) };
    }
    if (method === 'GET' && (m = /^\/api\/racing\/courses\/([a-z]+)$/.exec(p))) {
      const c = courseById[m[1]]; if (!c) fail(404, 'Racecourse not found.');
      const rs = R().races.filter((r) => r.kind === 'sched' && r.course === c.id);
      return { ...c, upcoming: rs.filter((r) => r.status === 'open').sort((a, b) => a.off - b.off).slice(0, 6).map((r) => summary(r, t)), results: rs.filter((r) => r.status === 'finished').sort((a, b) => b.off - a.off).map((r) => summary(r, t)).filter((r) => r.phase === 'result').slice(0, 12), races: rs.filter((r) => r.status === 'finished').length };
    }
    if (key === 'GET /api/racing/favourites') return { horses: R().favs.horses, courses: R().favs.courses };
    if (key === 'POST /api/racing/favourites') {
      const { kind, ref, on } = body || {}; const list = kind === 'horse' ? R().favs.horses : kind === 'course' ? R().favs.courses : null;
      if (!list) fail(400, 'Unknown favourite.');
      const v = kind === 'horse' ? Number(ref) : ref; const i = list.indexOf(v);
      if (on && i < 0) list.push(v); if (!on && i >= 0) list.splice(i, 1); save();
      return { horses: R().favs.horses, courses: R().favs.courses };
    }
    if (key === 'GET /api/racing/streams') return { streams: [] };
    return undefined;
  };
}
