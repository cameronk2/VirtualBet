import { useMemo } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { Link, navigate, useLocation } from '../lib/router.jsx';
import { usePolling } from '../lib/hooks.js';
import { money, signed } from '../lib/format.js';
import { CATALOGUE } from '../../../server/games/catalogue.js';
import { LOBBY_ART3, Logo3, SlotDefs3 } from '../components/SlotArt3.jsx';

// Small original emblems for each game tile
const ART = {
  lakeside: (
    <g><circle cx="50" cy="38" r="16" fill="#fde68a" opacity=".9" /><path d="M10 62c10-6 20 6 30 0s20 6 30 0 20 6 30 0v38H10z" fill="#0c4a6e" opacity=".85" />
      <path d="M38 70c8-8 22-8 30 0-8 8-22 8-30 0z" fill="#84cc16" stroke="#1a2e05" strokeWidth="2" /><path d="M68 70l9-7v14z" fill="#4d7c0f" /><circle cx="44" cy="68" r="1.8" fill="#111" /></g>
  ),
  nebula: (
    <g>{[[30, 30, '#f43f5e'], [52, 26, '#a855f7'], [72, 40, '#38bdf8'], [40, 54, '#facc15'], [62, 62, '#22c55e'], [28, 72, '#fb923c']].map(([x, y, c], i) => (
      <polygon key={i} points={`${x},${y - 11} ${x + 10},${y} ${x},${y + 11} ${x - 10},${y}`} fill={c} stroke="#fff" strokeOpacity=".7" strokeWidth="1.5" />))}
      <circle cx="80" cy="18" r="2" fill="#fff" /><circle cx="18" cy="48" r="1.5" fill="#fff" /></g>
  ),
  vault: (
    <g><circle cx="50" cy="50" r="30" fill="#78350f" stroke="#fbbf24" strokeWidth="4" /><circle cx="50" cy="50" r="20" fill="#fbbf24" stroke="#92400e" strokeWidth="3" />
      <text x="50" y="57" textAnchor="middle" fontSize="20" fontWeight="900" fill="#78350f" fontFamily="system-ui">£</text>
      {[0, 60, 120, 180, 240, 300].map((a) => <rect key={a} x="48" y="14" width="4" height="8" fill="#fbbf24" transform={`rotate(${a} 50 50)`} />)}</g>
  ),
  starlight: (
    <g><circle cx="66" cy="32" r="14" fill="#e2e8f0" /><circle cx="61" cy="28" r="14" fill="#1e1b4b" />
      <path d="M24 76l26-30 6 5-26 30z" fill="#cbd5e1" stroke="#0f172a" strokeWidth="2" /><path d="M30 84l8-10M40 84l-6-8" stroke="#cbd5e1" strokeWidth="3" />
      {[[20, 22], [40, 14], [84, 60], [78, 80]].map(([x, y], i) => <path key={i} d={`M${x} ${y - 5}l1.5 3.5 3.5 1.5-3.5 1.5-1.5 3.5-1.5-3.5-3.5-1.5 3.5-1.5z`} fill="#fde68a" />)}</g>
  ),
  fruit: (
    <g><path d="M44 30c4 14 14 22 18 30M56 30c-4 10-14 18-20 30" stroke="#15803d" strokeWidth="3" fill="none" /><path d="M46 26c6-6 14-4 18 2-8 2-12 2-18-2z" fill="#22c55e" />
      <circle cx="36" cy="66" r="13" fill="#dc2626" stroke="#7f1d1d" strokeWidth="2" /><circle cx="64" cy="66" r="13" fill="#dc2626" stroke="#7f1d1d" strokeWidth="2" />
      <circle cx="32" cy="61" r="3" fill="#fecaca" /><circle cx="60" cy="61" r="3" fill="#fecaca" /></g>
  ),
  blackjack: (
    <g><rect x="22" y="22" width="34" height="48" rx="4" fill="#fff" transform="rotate(-12 39 46)" /><rect x="44" y="26" width="34" height="48" rx="4" fill="#fff" transform="rotate(10 61 50)" />
      <text x="34" y="44" fontSize="14" fontWeight="900" fill="#0b1520" transform="rotate(-12 39 46)">A</text><text x="58" y="48" fontSize="14" fontWeight="900" fill="#dc2626" transform="rotate(10 61 50)">K</text>
      <text x="58" y="66" fontSize="16" fill="#dc2626" transform="rotate(10 61 50)">♥</text><text x="31" y="62" fontSize="16" fill="#0b1520" transform="rotate(-12 39 46)">♠</text></g>
  ),
  spin21: (
    <g>{Array.from({ length: 12 }, (_, i) => <path key={i} d="M50 50L50 18A32 32 0 0 1 66 22.3z" fill={['#facc15', '#0e7490', '#ec4899', '#155e75', '#7c3aed', '#0e7490'][i % 6]} transform={`rotate(${i * 30} 50 50)`} />)}
      <circle cx="50" cy="50" r="32" fill="none" stroke="#facc15" strokeWidth="3" /><circle cx="50" cy="50" r="10" fill="#0b1520" stroke="#facc15" strokeWidth="2" /><path d="M50 12l-5-8h10z" fill="#fff" /></g>
  ),
  roulette: (
    <g>{Array.from({ length: 18 }, (_, i) => <path key={i} d="M50 50L50 16A34 34 0 0 1 61.6 18z" fill={i === 0 ? '#16a34a' : i % 2 ? '#111827' : '#dc2626'} transform={`rotate(${i * 20} 50 50)`} />)}
      <circle cx="50" cy="50" r="34" fill="none" stroke="#b45309" strokeWidth="4" /><circle cx="50" cy="50" r="16" fill="#92400e" stroke="#fbbf24" strokeWidth="2" /><circle cx="50" cy="24" r="4" fill="#fff" /></g>
  ),
  baccarat: (
    <g><rect x="16" y="30" width="30" height="42" rx="4" fill="#fff" /><rect x="54" y="30" width="30" height="42" rx="4" fill="#fff" />
      <text x="31" y="58" textAnchor="middle" fontSize="18" fontWeight="900" fill="#1d4ed8">9</text><text x="69" y="58" textAnchor="middle" fontSize="18" fontWeight="900" fill="#dc2626">8</text>
      <text x="31" y="86" textAnchor="middle" fontSize="8" fontWeight="800" fill="#bfdbfe">PLAYER</text><text x="69" y="86" textAnchor="middle" fontSize="8" fontWeight="800" fill="#fecaca">BANKER</text></g>
  ),
  threecard: (
    <g>{[-16, 0, 16].map((r, i) => <rect key={i} x="36" y="22" width="28" height="42" rx="4" fill="#fff" stroke="#0f172a" strokeWidth="1" transform={`rotate(${r} 50 80)`} />)}
      <text x="50" y="50" textAnchor="middle" fontSize="16" fill="#0b1520">♣</text><text x="50" y="86" textAnchor="middle" fontSize="9" fontWeight="800" fill="#99f6e4">3 CARD</text></g>
  ),
  crash: (
    <g><path d="M12 84C40 82 60 66 82 20" stroke="#a3e635" strokeWidth="4" fill="none" strokeLinecap="round" />
      <path d="M78 16l10-4-3 10z" fill="#fff" /><text x="18" y="40" fontSize="18" fontWeight="900" fill="#ecfccb" fontFamily="system-ui">2.4x</text></g>
  ),
  plinko: (
    <g>{Array.from({ length: 5 }, (_, r) => Array.from({ length: r + 2 }, (_, c) => <circle key={`${r}${c}`} cx={50 - (r + 1) * 7 + c * 14} cy={22 + r * 13} r="2.5" fill="#fff" opacity=".8" />))}
      <circle cx="53" cy="16" r="5" fill="#f472b6" stroke="#fff" strokeWidth="1.5" />
      {['#f43f5e', '#fb923c', '#facc15', '#fb923c', '#f43f5e'].map((c, i) => <rect key={i} x={17 + i * 14} y="86" width="12" height="7" rx="2" fill={c} />)}</g>
  ),
  scratch: (
    <g><rect x="18" y="20" width="64" height="60" rx="6" fill="#fef9c3" stroke="#a16207" strokeWidth="2" />
      {[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={24 + c * 19} y={26 + r * 17} width="15" height="13" rx="2" fill={r === 1 && c === 2 ? '#fde68a' : '#a3a3a3'} />))}
      <text x="70.5" y="57" textAnchor="middle" fontSize="8" fontWeight="900" fill="#78350f">£5</text></g>
  ),
};

const MAX_X = { moonridge: '5,666', mummy: '2,118', brick: '5,500', stampede: '5,000', chicken: '10,000', mines: '5,044,291', keno: '100,000', genie: '10,000' };

function NewBadge() {
  return <span className="rounded-full border border-cz-neon2/40 bg-cz-bg/70 px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-[0.14em] text-cz-neon2 backdrop-blur-sm">New</span>;
}

function Tile({ g, stats }) {
  return (
    <Link to={g.path} className="cz-card cz-glow group flex flex-col overflow-hidden rounded-2xl">
      {/* Art keeps each game's own colours, set on a darkened panel so it pops */}
      <div className="relative aspect-[5/4] overflow-hidden bg-cz-bg2">
        <div className={`absolute inset-0 bg-gradient-to-br opacity-50 ${g.hue}`} />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,transparent_20%,rgba(5,5,5,.55)_100%)]" />
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[#111113] to-transparent" />
        <svg viewBox="0 0 100 100" className="relative mx-auto h-full w-auto p-2.5 drop-shadow-[0_8px_14px_rgba(0,0,0,0.55)] transition-transform duration-300 group-hover:scale-[1.06]" aria-hidden="true">{ART[g.id] || LOBBY_ART3[g.id]}</svg>
        {g.isNew && <span className="absolute right-2 top-2"><NewBadge /></span>}
      </div>
      <div className="flex flex-1 flex-col px-3 pb-3 pt-1.5">
        <div className="line-clamp-2 min-h-[2.5em] text-[15px] font-bold leading-[1.25] text-cz-text sm:line-clamp-1 sm:min-h-0">{g.name}</div>
        <div className="mt-0.5 line-clamp-1 text-[11.5px] text-cz-muted">{g.tag}</div>
        <div className="mt-2.5 flex items-center justify-between gap-2 text-[10.5px] font-semibold">
          <span className="rounded-md border border-white/[0.07] bg-white/[0.03] px-1.5 py-0.5 tabular-nums text-cz-muted">RTP {g.rtp}</span>
          {stats ? <span className={`tabular-nums ${stats > 0 ? 'text-cz-win' : 'text-cz-muted'}`}>{signed(stats)}</span> : null}
        </div>
      </div>
    </Link>
  );
}

function Featured({ g }) {
  return (
    <Link to={g.path} className="cz-card cz-glow group relative flex w-[82vw] max-w-[330px] shrink-0 snap-start flex-col overflow-hidden rounded-2xl p-3 sm:w-80">
      <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-cz-neon/10 blur-2xl" />
      <div className="relative flex items-center gap-3">
        <div className="relative h-[88px] w-[88px] shrink-0 overflow-hidden rounded-xl bg-cz-bg2 ring-1 ring-white/10">
          <div className={`absolute inset-0 bg-gradient-to-br opacity-60 ${g.hue}`} />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,transparent_30%,rgba(5,5,5,.5)_100%)]" />
          <svg viewBox="0 0 100 100" className="relative h-full w-full p-1 drop-shadow-[0_6px_10px_rgba(0,0,0,0.5)] transition-transform duration-300 group-hover:scale-110" aria-hidden="true">{LOBBY_ART3[g.id]}</svg>
        </div>
        <div className="min-w-0 flex-1">
          <Logo3 game={g.id} className="h-11 w-full" />
          <div className="mt-1 line-clamp-1 text-[12px] text-cz-muted">{g.desc}</div>
        </div>
      </div>
      <div className="relative mt-3 flex items-center justify-between gap-3 border-t border-white/[0.06] pt-3">
        <div className="min-w-0">
          <div className="line-clamp-1 text-[12px] font-medium text-zinc-200">{g.tag}</div>
          <div className="text-[11px] tabular-nums text-cz-muted">RTP {g.rtp} · up to <span className="text-cz-neon2">{MAX_X[g.id] || '5,000'}x</span></div>
        </div>
        <span className="btn-cz h-10 shrink-0 px-5">Play</span>
      </div>
    </Link>
  );
}

const CATS = [['all', 'All'], ['slots', 'Slots'], ['tables', 'Tables'], ['instant', 'Instant']];

export default function Casino() {
  const { user, setDepositOpen } = useApp();
  const { query } = useLocation();
  const cat = query.get('cat') || 'all';
  const { data: life } = usePolling(user ? '/api/lifetime' : null, 30000, [user?.id]);
  const byId = useMemo(() => Object.fromEntries((life?.products || []).map((p) => [p.id, p.net])), [life]);
  const games = CATALOGUE.filter((g) => cat === 'all' || g.cat === cat);
  const played = CATALOGUE.filter((g) => byId[g.id] !== undefined);
  const count = (k) => (k === 'all' ? CATALOGUE.length : CATALOGUE.filter((g) => g.cat === k).length);

  return (
    <div className="space-y-6 text-cz-text">
      <SlotDefs3 />
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-[linear-gradient(160deg,#151517_0%,#0C0C0E_55%,#08080A_100%)] p-5 shadow-[0_20px_40px_-24px_rgba(0,0,0,.9)] sm:p-8">
        <div className="pointer-events-none absolute -right-16 -top-20 h-60 w-60 rounded-full bg-cz-neon/[0.12] blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-10 h-52 w-52 rounded-full bg-cz-neon2/[0.06] blur-3xl" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cz-neon/60 to-transparent" />
        <div className="relative">
          <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.22em] text-cz-neon"><span className="h-1.5 w-1.5 rounded-full bg-cz-neon shadow-[0_0_8px_#F2FF00]" />VirtualBet Casino</div>
          <h1 className="mt-2 text-[32px] font-extrabold leading-[1.05] tracking-tight sm:text-5xl">{CATALOGUE.length} games.<br /><span className="cz-gradient-text">Zero real money.</span></h1>
          <p className="mt-2.5 max-w-lg text-sm leading-relaxed text-cz-muted">Slots, table games and instant wins from one virtual balance. Every game shows its long-run return, so the house edge is never hidden.</p>
          {user && (
            <div className="mt-4 flex items-center justify-between gap-3 rounded-2xl border border-white/[0.07] bg-cz-bg/60 p-3 pl-4 backdrop-blur-sm sm:inline-flex sm:min-w-[340px]">
              <div className="leading-tight">
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-cz-muted">Virtual balance</div>
                <div className="mt-0.5 font-cond text-2xl font-bold tabular-nums text-cz-text">{money(user.balance)}</div>
              </div>
              <button onClick={() => setDepositOpen(true)} className="btn-cz h-11">Add funds</button>
            </div>
          )}
        </div>
      </section>

      {/* Categories */}
      <div className="grid grid-cols-4 gap-1 rounded-2xl border border-white/[0.07] bg-cz-bg2 p-1 sm:max-w-md" role="tablist" aria-label="Game type">
        {CATS.map(([k, label]) => {
          const on = cat === k;
          return (
            <button key={k} role="tab" aria-selected={on} onClick={() => navigate(k === 'all' ? '/casino' : `/casino?cat=${k}`, { replace: true })}
              className={`flex h-10 items-center justify-center gap-1.5 rounded-xl text-[13px] font-bold transition-all duration-200 ${on ? 'bg-[linear-gradient(135deg,#F2FF00,#FFE600)] text-black shadow-[0_6px_18px_-8px_rgba(242,255,0,.75)]' : 'text-cz-muted hover:text-cz-text active:bg-white/[0.04]'}`}>
              {label}<span className={`text-[10px] tabular-nums ${on ? 'text-black/55' : 'text-zinc-600'}`}>{count(k)}</span>
            </button>
          );
        })}
      </div>

      {(cat === 'all' || cat === 'slots') && (
        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-[17px] font-bold tracking-tight">Premium slots <NewBadge /></h2>
            <span className="text-[11px] text-cz-muted">Swipe</span>
          </div>
          <div className="scrollbar-none -mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto scroll-px-4 px-4 pb-3 pt-1 sm:mx-0 sm:px-0">
            {CATALOGUE.filter((g) => g.isNew).map((g) => <Featured key={g.id} g={g} />)}
          </div>
        </section>
      )}

      <section>
        <h2 className="mb-3 text-[17px] font-bold tracking-tight">{cat === 'all' ? 'All games' : CATS.find(([k]) => k === cat)?.[1] === 'Tables' ? 'Table games' : CATS.find(([k]) => k === cat)?.[1] === 'Instant' ? 'Instant wins' : 'Slots'}</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {games.map((g) => <Tile key={g.id} g={g} stats={byId[g.id]} />)}
        </div>
      </section>

      {user && played.length > 0 && cat === 'all' && (
        <section className="cz-card rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-[17px] font-bold tracking-tight">Your casino so far</h2>
            <Link to="/account?tab=totals" className="text-xs font-semibold text-cz-neon hover:text-cz-neon2">Full breakdown ›</Link>
          </div>
          <p className="mb-3 mt-0.5 text-xs text-cz-muted">Net result per game since you started.</p>
          <div className="grid gap-1.5 sm:grid-cols-2">
            {played.map((g) => (
              <div key={g.id} className="flex items-center justify-between rounded-xl border border-white/[0.05] bg-cz-bg2 px-3 py-2.5 text-sm">
                <span className="text-zinc-200">{g.name}</span>
                <span className={`font-bold tabular-nums ${byId[g.id] > 0 ? 'text-cz-win' : byId[g.id] < 0 ? 'text-rose-400' : 'text-cz-muted'}`}>{signed(byId[g.id])}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
