import { lockScroll } from '../lib/scrollLock.js';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../state/AppContext.jsx';
import { api } from '../lib/api.js';
import { GameHeader, SoundToggle, useGameSound } from '../components/GameShell.jsx';
import { navigate } from '../lib/router.jsx';
import { money, signed } from '../lib/format.js';
import { sfx } from '../lib/sound.js';
import { handValue, PP_PAYS, RESULT_TEXT, SIDE_TEXT, T213_PAYS, WHEEL } from '../../../server/blackjack.js';
import { Spinner } from '../components/ui.jsx';
import BonusWheel from '../components/BonusWheel.jsx';
import { LoginPrompt } from './MyBets.jsx';

const CHIPS = [
  { v: 100, label: '£1', cls: 'bg-slate-100 text-navy-950 ring-slate-300' },
  { v: 500, label: '£5', cls: 'bg-red-600 text-white ring-red-300' },
  { v: 1000, label: '£10', cls: 'bg-sky-600 text-white ring-sky-300' },
  { v: 2500, label: '£25', cls: 'bg-emerald-600 text-white ring-emerald-300' },
  { v: 10000, label: '£100', cls: 'bg-zinc-900 text-gold-400 ring-gold-500' },
  { v: 50000, label: '£500', cls: 'bg-violet-700 text-white ring-violet-300' },
  { v: 100000, label: '£1k', cls: 'bg-amber-500 text-navy-950 ring-amber-200' },
];
const SUIT = { S: '♠', H: '♥', D: '♦', C: '♣' };
const STEP_MS = 360;
const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const EMPTY_SEAT = () => ({ bet: 0, pp: 0, t213: 0, spinOn: false });
const RESULT_CLS = { blackjack: 'bg-gold-500 text-navy-950', win: 'bg-brand-500 text-navy-950', push: 'bg-slate-300 text-navy-950', lose: 'bg-red-600 text-white', bust: 'bg-red-600 text-white' };

function Card({ code, size = 'md', anim, overlap }) {
  const dims = size === 'xs' ? 'h-[50px] w-9 text-[10px]' : size === 'sm' ? 'h-[62px] w-11 text-[11px]' : 'h-20 w-14 text-sm sm:h-24 sm:w-16';
  const animCls = reduceMotion ? '' : anim === 'flip' ? 'animate-card-flip' : anim === 'deal' ? 'animate-card-deal' : '';
  const ml = overlap ? (size === 'xs' ? '-ml-6' : size === 'sm' ? '-ml-7' : '-ml-8') : '';
  if (code === '??') {
    return (
      <div className={`${animCls} ${ml} relative ${dims} shrink-0 rounded-md border-2 border-white/85 bg-gradient-to-br from-red-800 to-red-950 shadow-[0_3px_8px_rgba(0,0,0,0.5)]`}>
        <div className="absolute inset-1 rounded-sm border border-white/25 bg-[repeating-linear-gradient(45deg,rgba(255,255,255,0.10)_0_4px,transparent_4px_8px)]" />
      </div>
    );
  }
  const rank = code.slice(0, -1), suit = code.slice(-1);
  const red = suit === 'H' || suit === 'D';
  return (
    <div className={`${animCls} ${ml} relative ${dims} shrink-0 rounded-md bg-white shadow-[0_3px_8px_rgba(0,0,0,0.5)] ${red ? 'text-red-600' : 'text-navy-950'}`}>
      <div className="absolute left-1 top-0.5 text-left font-extrabold leading-none">{rank}<div className="text-[0.9em] leading-none">{SUIT[suit]}</div></div>
      <div className={`absolute inset-0 flex items-center justify-center ${size === 'xs' ? 'text-base' : size === 'sm' ? 'text-xl' : 'text-2xl sm:text-3xl'}`}>{SUIT[suit]}</div>
    </div>
  );
}

function ValueBadge({ cards, hidden }) {
  const vis = cards.filter((c) => c !== '??');
  if (!vis.length) return null;
  const v = handValue(vis);
  const bj = cards.length === 2 && !hidden && v.total === 21;
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-bold tabular-nums ${v.total > 21 ? 'bg-red-600 text-white' : bj ? 'bg-gold-500 text-navy-950' : 'bg-black/50 text-white'}`}>
      {bj ? 'BJ' : v.total}{v.soft && v.total < 21 && !bj ? ' soft' : ''}{hidden ? ' +?' : ''}
    </span>
  );
}

function BetSpot({ label, amount, onTap, big, pays, disabled }) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onTap}
      className={`flex shrink-0 flex-col items-center justify-center rounded-full border-2 border-dashed transition-colors ${amount ? 'border-gold-400 bg-gold-400/15' : 'border-emerald-200/40 hover:border-emerald-100/70'} ${big ? 'h-16 w-16' : 'h-11 w-11'}`}
      aria-label={`${label} bet ${amount ? money(amount) : 'empty'}`}
    >
      <span className={`font-bold leading-none ${big ? 'text-[10px]' : 'text-[8px]'} text-emerald-50/80`}>{label}</span>
      <span className={`font-extrabold tabular-nums leading-tight text-white ${big ? 'text-xs' : 'text-[9px]'}`}>{amount ? (amount >= 100000 ? `£${+(amount / 100000).toFixed(1)}k` : money(amount).replace('.00', '')) : pays || '+'}</span>
    </button>
  );
}

export default function Blackjack({ variant = 'classic' }) {
  const spin21 = variant === 'spin21';
  const music = useGameSound(spin21 ? 'spin21' : 'blackjack');
  const base = spin21 ? '/api/spin21' : '/api/blackjack';
  const { user, setUser, config, toast } = useApp();
  const rules = config?.rules || { minStake: 10, maxStake: 50000 };
  const [round, setRound] = useState(null);
  const [hint, setHint] = useState(null);
  const [history, setHistory] = useState([]);
  const [numSeats, setNumSeats] = useState(1);
  const [seats, setSeats] = useState([{ bet: 500, pp: 0, t213: 0, spinOn: spin21 }, EMPTY_SEAT(), EMPTY_SEAT()]);
  const [wheelQueue, setWheelQueue] = useState([]);
  const [lastBets, setLastBets] = useState(null);
  const [chip, setChip] = useState(500);
  const [busy, setBusy] = useState(false);
  const [animating, setAnimating] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [editing, setEditing] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const fitRef = useRef(null);
  const [fit, setFit] = useState(1);
  const [full, setFull] = useState(true); // every game opens full screen; ✕ leaves it for this visit
  const setFullPref = (v) => setFull(v);
  useEffect(() => {
    if (!full) return undefined;
    return lockScroll();
  }, [full]);
  const tableRef = useRef(null);
  const controlsRef = useRef(null);
  const [view, setView] = useState({ dealer: [], seats: [], showResult: false, flip: false });
  const played = useRef(0);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  // Apply one dealt-card event to the on-screen table
  const applyEvent = (v, e) => {
    const n = { ...v, dealer: [...v.dealer], seats: v.seats.map((s) => ({ hands: s.hands.map((h) => ({ cards: [...h.cards] })) })) };
    if (e.t === 'card') {
      while (n.seats.length <= e.seat) n.seats.push({ hands: [] });
      while (n.seats[e.seat].hands.length <= e.hand) n.seats[e.seat].hands.push({ cards: [] });
      n.seats[e.seat].hands[e.hand].cards.push(e.card);
      n.last = `s${e.seat}h${e.hand}c${n.seats[e.seat].hands[e.hand].cards.length - 1}`;
    } else if (e.t === 'split') {
      const hands = n.seats[e.seat].hands;
      hands.splice(e.hand + 1, 0, { cards: [hands[e.hand].cards.pop()] });
      n.last = null;
    } else if (e.t === 'dealer') {
      n.dealer.push(e.hole ? '??' : e.card);
      n.last = `d${n.dealer.length - 1}`;
    } else if (e.t === 'reveal') {
      n.dealer[1] = e.card;
      n.flip = true;
      n.last = 'd1';
    }
    return n;
  };

  const play = useCallback((r, fresh, after) => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
    if (!r) { setView({ dealer: [], seats: [], showResult: false, flip: false }); played.current = 0; after?.(); return; }
    let base = fresh ? { dealer: [], seats: [], showResult: false, flip: false } : null;
    if (fresh) played.current = 0;
    const events = r.events.slice(played.current);
    played.current = r.events.length;
    const finish = () => { setView((v) => ({ ...v, showResult: r.status === 'done' })); setAnimating(false); after?.(); };
    if (base) setView(base);
    else setView((v) => ({ ...v, showResult: false }));
    if (reduceMotion || !events.length) {
      setView((v) => events.reduce(applyEvent, base || v));
      finish();
      return;
    }
    setAnimating(true);
    let t = 0;
    events.forEach((e) => {
      t += e.t === 'reveal' ? STEP_MS + 150 : e.t === 'split' ? 250 : STEP_MS;
      timers.current.push(setTimeout(() => { setView((v) => applyEvent(v, e)); if (e.t !== 'split') sfx.card(); }, t));
    });
    timers.current.push(setTimeout(finish, t + 300));
  }, []);

  const load = useCallback(async () => {
    try {
      const d = await api.get(base);
      setRound(d.round); setHint(d.hint); setHistory(d.history);
      if (d.round) {
        played.current = d.round.events.length;
        setView({ ...d.round.events.reduce(applyEvent, { dealer: [], seats: [], flip: false }), showResult: d.round.status === 'done', flip: false, last: null });
      }
    } catch (e) { toast(e.message, 'error'); }
  }, [toast]);
  useEffect(() => { if (user) load(); }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Full screen: shrink the felt to fit when a round needs more room than the screen has
  // eslint-disable-next-line react-hooks/rules-of-hooks
  useLayoutEffect(() => {
    const inner = fitRef.current, box = inner?.parentElement;
    if (!full || !inner || !box) { if (fit !== 1) setFit(1); return; }
    const need = inner.scrollHeight, have = box.clientHeight;
    const k = need > have + 1 ? Math.max(0.6, have / need) : 1;
    if (Math.abs(k - fit) > 0.01) setFit(k);
  });
  useEffect(() => {
    if (!full) return undefined;
    const on = () => setFit(1);
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, [full]);

  if (user === null) return <LoginPrompt what="blackjack" />;

  const playing = round?.status === 'player';
  const settled = round?.status === 'done' && view.showResult;
  const betting = !playing && !animating;
  const activeSeats = seats.slice(0, numSeats);
  const total = activeSeats.reduce((a, s) => a + s.bet + (spin21 ? (s.spinOn ? s.bet : 0) : s.pp + s.t213), 0);
  const canDeal = activeSeats.every((s) => s.bet >= rules.minStake) && total <= (user?.balance ?? 0);

  const addChip = (i, field) => {
    sfx.chip();
    setSeats((cur) => cur.map((s, j) => {
      if (j !== i) return s;
      return { ...s, [field]: s[field] + chip }; // no table maximum: your balance is the limit
    }));
  };

  const run = async (path, body, fresh) => {
    setBusy(true);
    try {
      music();
      const d = await api.post(path, body);
      setRound(d.round); setHint(d.hint); setHistory(d.history);
      play(d.round, fresh, () => {
        setUser(d.user);
        if (d.round?.status === 'done') {
          const wheels = d.round.seats.map((seat, i) => ({ seat, i })).filter(({ seat }) => seat.side?.spin?.result === 'wheel' && !seat.side.spin.pending);
          if (wheels.length) setWheelQueue(wheels.map(({ seat, i }) => ({ spin: seat.side.spin, stake: seat.spin, handLabel: d.round.seats.length > 1 ? `Hand ${i + 1}` : 'Your blackjack' })));
          else {
            const net = d.round.totalPayout - d.round.totalStaked;
            if (net > 0) sfx.win(); else if (net < 0) sfx.lose();
          }
        }
      });
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  const deal = () => {
    setLastBets({ numSeats, seats: activeSeats.map((s) => ({ ...s })) });
    setEditing(false);
    // Bring the table back into view if the player scrolled down to the chips
    const el = tableRef.current;
    if (el && el.getBoundingClientRect().top < 100) el.scrollIntoView({ behavior: window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
    run(`${base}/deal`, { seats: activeSeats.map((x) => (spin21 ? { bet: x.bet, spin: x.spinOn ? x.bet : 0 } : { bet: x.bet, pp: x.pp, t213: x.t213 })) }, true);
  };

  const r = round;
  const dealerHidden = view.dealer.includes('??');
  const net = settled ? r.totalPayout - r.totalStaked : null;
  const sessionNet = history.reduce((a, h) => a + h.payout - h.staked, 0);
  const smallCards = (view.seats.length || numSeats) > 1 || view.seats.some((s) => s.hands.length > 1);

  const dealLabel = busy ? <Spinner className="h-4 w-4" /> : total > (user?.balance ?? 0) ? 'Low balance' : !activeSeats.every((x) => x.bet >= rules.minStake) ? 'Bet every hand' : `${r?.status === 'done' ? 'Deal again' : 'Deal'} · ${money(total).replace('.00', '')}`;
  const actionButtons = (
    <div className="grid grid-cols-4 gap-2">
      {[['hit', 'Hit', 'btn-primary'], ['stand', 'Stand', 'btn bg-gold-500 text-navy-950 hover:bg-gold-400'], ['double', 'Double', 'btn-ghost'], ['split', 'Split', 'btn-ghost']].map(([a, label, cls]) => (
        <button key={a} className={`${cls} h-12 px-1 text-sm ${showHint && hint === a && !animating ? 'ring-2 ring-offset-2 ring-offset-navy-950 ring-gold-400' : ''}`}
          disabled={busy || animating || !r?.allowed?.[a]} onClick={() => run(`${base}/action`, { action: a }, false)}>{label}</button>
      ))}
    </div>
  );
  const hintToggle = (
    <label className="flex items-center justify-center gap-2 text-xs text-slate-400">
            <input type="checkbox" className="h-4 w-4 accent-brand-500" checked={showHint} onChange={(e) => { setShowHint(e.target.checked); if (e.target.checked) api.post('/api/achievements/event', { t: 'hint' }).catch(() => {}); }} />
            Show basic strategy hint{showHint && hint && !animating ? <b className="text-gold-400"> · {hint[0].toUpperCase() + hint.slice(1)}</b> : ''}
          </label>
  );
  const chipRow = (
    <div className="flex justify-center gap-1.5">
      {CHIPS.map((c) => (
        <button key={c.v} onClick={() => { setChip(c.v); setEditing(true); sfx.chip(); }}
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-[3px] border-dashed border-white/40 text-[10px] font-extrabold shadow-lg ring-2 transition-transform sm:h-12 sm:w-12 sm:text-xs ${c.cls} ${chip === c.v ? '-translate-y-1 scale-110 ring-4' : ''}`}
          aria-pressed={chip === c.v} aria-label={`Chip ${c.label}`}>{c.label}</button>
      ))}
    </div>
  );
  const clearBtn = <button className="btn-ghost h-11 px-2 text-sm" onClick={() => { setEditing(true); setSeats([EMPTY_SEAT(), EMPTY_SEAT(), EMPTY_SEAT()]); }}>Clear</button>;
  const rebetBtn = <button className="btn-ghost h-11 px-2 text-sm" disabled={!lastBets} onClick={() => { setNumSeats(lastBets.numSeats); setSeats([...lastBets.seats, EMPTY_SEAT(), EMPTY_SEAT()].slice(0, 3)); }}>Rebet</button>;
  const doubleBtn = <button className="btn-ghost h-11 px-2 text-sm" onClick={() => setSeats((cur) => cur.map((x) => ({ ...x, bet: x.bet * 2, pp: x.pp * 2, t213: x.t213 * 2 })))}>×2</button>;
  const tableCls = 'relative overflow-hidden border-amber-900/70 bg-[radial-gradient(ellipse_at_top,#1a6b51_0%,#0f4a39_55%,#0a2f25_100%)] shadow-[inset_0_0_60px_rgba(0,0,0,0.45),0_10px_30px_rgba(0,0,0,0.5)]';
  const title = spin21 ? 'Spin 21' : 'Blackjack';

  // ── Full-screen table: everything on one screen, no scrolling ──
  if (full) {
    // Rendered at the top of the page so nothing on the page (tab bar, banners) can cover the table
    return createPortal(
      <div className="fixed inset-0 z-[45] flex flex-col bg-navy-950" style={{ height: '100dvh', paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }} role="dialog" aria-label={`${title} table`}>
        <div className="flex items-center gap-2 px-3 py-1.5">
          <button onClick={() => navigate('/casino')} className="flex h-9 w-9 items-center justify-center rounded-full bg-navy-800 text-lg text-slate-200 hover:bg-navy-700" aria-label="Leave table">✕</button>
          <div className="min-w-0 flex-1 leading-tight">
            <div className="truncate font-cond text-lg font-extrabold uppercase text-white">{title}</div>
            <div className={`text-[11px] font-semibold tabular-nums ${sessionNet > 0 ? 'text-brand-400' : sessionNet < 0 ? 'text-red-400' : 'text-slate-400'}`}>Session {signed(sessionNet)}</div>
          </div>
          <div className="text-right leading-tight"><div className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Balance</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(user?.balance)}</div></div>
          <SoundToggle game={spin21 ? 'spin21' : 'blackjack'} />
          <button onClick={() => setShowRules(true)} className="flex h-8 w-8 items-center justify-center rounded-full bg-navy-800 text-sm font-bold text-slate-200" aria-label="Rules">?</button>
          <button onClick={() => setFullPref(false)} className="hidden h-8 items-center rounded-md bg-navy-800 px-2 text-xs font-semibold text-slate-200 sm:flex">Page view</button>
        </div>
        <section ref={tableRef} className={`${tableCls} mx-2 min-h-0 flex-1 overflow-hidden rounded-2xl border-2`}>
        {/* Shoe */}
        <div className="absolute right-3 top-3 h-12 w-9 rotate-6 rounded-md border-2 border-white/70 bg-gradient-to-br from-red-800 to-red-950 shadow-lg" aria-hidden="true" />
        <div ref={full ? fitRef : undefined} style={full && fit < 1 ? { transform: `scale(${fit})`, transformOrigin: 'top center' } : undefined} className={`relative p-4 sm:p-6 ${full ? `flex min-h-full flex-col justify-around gap-2 ${betting ? 'pt-10' : 'pt-3'}` : `space-y-4 ${betting ? 'pt-10' : ''}`}`}>
          {/* Dealer */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-emerald-100/80">Dealer {!(editing && !playing && !animating) && <ValueBadge cards={view.dealer} hidden={dealerHidden} />}</div>
            <div className="flex min-h-20 items-center pl-8 sm:min-h-24">
              {(editing && !playing && !animating ? [] : view.dealer).map((c, i) => <Card key={`d${i}-${c === '??' ? 'b' : 'f'}`} code={c} anim={view.last === `d${i}` ? (i === 1 && view.flip && c !== '??' ? 'flip' : 'deal') : null} overlap />)}
            </div>
          </div>

          <div className={`text-center text-[10px] font-bold uppercase tracking-[0.25em] text-emerald-100/30 ${full && !betting ? 'hidden [@media(min-height:700px)]:block' : ''}`}>Blackjack pays 3 to 2 · Dealer stands on all 17s</div>

          {betting && (
            <div className="absolute left-2 top-2 z-10 flex items-center gap-1 rounded-lg bg-black/35 p-1 text-[10px] font-bold uppercase text-emerald-50/80">
              <span className="px-1">Hands</span>
              {[1, 2, 3].map((n) => (
                <button key={n} onClick={() => { setEditing(true); setNumSeats(n); setSeats((cur) => cur.map((x, i) => (i < n && !x.bet ? { ...x, bet: cur[0].bet || 500, spinOn: spin21 && cur[0].spinOn } : x))); }}
                  className={`h-6 w-6 rounded-md text-xs ${numSeats === n ? 'bg-brand-500 text-navy-950' : 'text-white hover:bg-white/10'}`} aria-pressed={numSeats === n}>{n}</button>
              ))}
            </div>
          )}
          {/* Seats */}
          {(playing || animating || (r && r.status === 'done' && !editing)) && view.seats.length > 0 ? (
            <div className={`grid gap-2 ${view.seats.length === 1 ? 'grid-cols-1' : view.seats.length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
              {view.seats.map((seat, si) => {
                const pubSeat = r?.seats?.[si];
                return (
                  <div key={si} className="flex min-w-0 flex-col items-center gap-2">
                    <div className={seat.hands.length > 1 ? 'flex flex-wrap justify-center gap-1' : 'contents'}>
                    {seat.hands.map((h, hi) => {
                      const split = seat.hands.length > 1;
                      const size = split && (view.seats.length > 1 || seat.hands.length > 2) ? 'xs' : smallCards ? 'sm' : 'md';
                      const ph = pubSeat?.hands?.[hi];
                      const isActive = playing && !animating && r.active?.seat === si && r.active?.hand === hi;
                      return (
                        <div key={hi} className={`flex ${split ? '' : 'w-full'} flex-col items-center gap-1 rounded-xl p-1 transition-all ${isActive ? 'bg-gold-400/10 ring-2 ring-gold-400 shadow-[0_0_18px_rgba(250,204,21,0.35)]' : ''}`}>
                          <div className={`flex items-center ${size === 'xs' ? 'min-h-[50px] pl-6' : size === 'sm' ? 'min-h-[62px] pl-7' : 'min-h-20 pl-8 sm:min-h-24'}`}>
                            {h.cards.map((c, ci) => <Card key={ci} code={c} size={size} anim={view.last === `s${si}h${hi}c${ci}` ? 'deal' : null} overlap />)}
                          </div>
                          <div className="flex flex-wrap items-center justify-center gap-1">
                            <ValueBadge cards={h.cards} />
                            {ph && size !== 'xs' && <span className="rounded-full bg-black/40 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-50/90">{money(ph.bet)}{ph.doubled ? ' ×2' : ''}</span>}
                            {settled && ph?.result && <span className={`animate-fade-in rounded-full px-1.5 py-0.5 text-[10px] font-extrabold ${RESULT_CLS[ph.result]}`}>{RESULT_TEXT[ph.result]}{ph.payout > 0 ? ` +${size === 'xs' ? money(ph.payout).replace('.00', '') : money(ph.payout)}` : ''}</span>}
                          </div>
                          {isActive && <div className="text-[10px] font-bold uppercase tracking-wider text-gold-400">Your move</div>}
                        </div>
                      );
                    })}
                    </div>
                    {pubSeat && pubSeat.spin > 0 && !animating && (
                      <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${pubSeat.side.spin?.result === 'wheel' ? 'animate-win-pulse bg-gold-500 text-navy-950' : pubSeat.side.spin?.result === 'ace' ? 'bg-sky-500 text-navy-950' : 'bg-black/30 text-emerald-50/60'}`}>
                        SPIN {pubSeat.side.spin?.result === 'wheel' ? (pubSeat.side.spin.pending ? 'Blackjack! Wheel at end of round' : `Wheel +${money(pubSeat.side.spin.payout)}`) : pubSeat.side.spin?.result === 'ace' ? 'Ace Saver - stake back' : 'no blackjack'}
                      </span>
                    )}
                    {pubSeat && (pubSeat.pp > 0 || pubSeat.t213 > 0) && !animating && (
                      <div className="flex flex-wrap justify-center gap-1">
                        {pubSeat.pp > 0 && <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${pubSeat.side.pp?.result ? 'bg-gold-500 text-navy-950' : 'bg-black/30 text-emerald-50/60'}`}>PP {pubSeat.side.pp?.result ? `${SIDE_TEXT[pubSeat.side.pp.result]} +${money(pubSeat.side.pp.payout)}` : 'no pair'}</span>}
                        {pubSeat.t213 > 0 && <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${pubSeat.side.t213?.result ? 'bg-gold-500 text-navy-950' : 'bg-black/30 text-emerald-50/60'}`}>21+3 {pubSeat.side.t213?.result ? `${SIDE_TEXT[pubSeat.side.t213.result]} +${money(pubSeat.side.t213.payout)}` : 'no win'}</span>}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className={`grid gap-2 ${numSeats === 1 ? 'grid-cols-1' : numSeats === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
              {activeSeats.map((s, i) => (
                <div key={i} className="flex flex-col items-center gap-2 rounded-xl bg-black/15 p-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-100/60">Hand {i + 1}</div>
                  <BetSpot label="BET" amount={s.bet} big onTap={() => addChip(i, 'bet')} />
                  {spin21 ? (
                    <button type="button" onClick={() => { sfx.chip(); setEditing(true); setSeats((cur) => cur.map((x, j) => (j === i ? { ...x, spinOn: !x.spinOn } : x))); }}
                      className={`relative flex h-14 w-14 flex-col items-center justify-center rounded-full border-2 transition-all ${s.spinOn ? 'border-gold-400 bg-[conic-gradient(#facc15_0_25%,#0e7490_0_50%,#ec4899_0_75%,#7c3aed_0)] shadow-[0_0_14px_rgba(250,204,21,0.6)]' : 'border-dashed border-emerald-200/40'}`}
                      aria-pressed={s.spinOn} aria-label={`Spin bet ${s.spinOn ? 'on' : 'off'}`}>
                      <span className={`rounded-full px-1.5 text-[10px] font-black ${s.spinOn ? 'bg-navy-950 text-gold-400' : 'text-emerald-50/80'}`}>SPIN</span>
                      <span className="mt-0.5 rounded-full bg-black/50 px-1 text-[9px] font-bold text-white">{s.spinOn ? money(s.bet).replace('.00', '') : 'off'}</span>
                    </button>
                  ) : (
                  <div className="flex gap-1.5">
                    <BetSpot label="PAIRS" amount={s.pp} pays="25:1" onTap={() => addChip(i, 'pp')} />
                    <BetSpot label="21+3" amount={s.t213} pays="100:1" onTap={() => addChip(i, 't213')} />
                  </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {settled && !editing && (
            <div className="animate-fade-in mx-auto w-fit rounded-xl bg-black/45 px-5 py-2 text-center backdrop-blur">
              <div className={`${full ? 'text-xl' : 'text-2xl'} font-extrabold ${net > 0 ? 'text-gold-400' : net < 0 ? 'text-red-400' : 'text-slate-100'}`}>{net > 0 ? `You win ${money(net)}` : net < 0 ? `You lose ${money(-net)}` : 'Break even'}</div>
              <div className="text-[11px] text-emerald-50/80">Staked {money(r.totalStaked)} · returned {money(r.totalPayout)}</div>
              {!wheelQueue.length && !full && (
                <div className="mt-2 flex gap-2">
                  <button className="btn-primary h-11 flex-1 whitespace-nowrap px-4 text-sm" disabled={busy || !canDeal} onClick={deal}>
                    {total > (user?.balance ?? 0) ? 'Not enough balance' : `Deal again · ${money(total)}`}
                  </button>
                  <button className="btn h-11 whitespace-nowrap bg-white/10 px-3 text-sm text-white hover:bg-white/20" onClick={() => { setEditing(true); controlsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }}>Change bets</button>
                </div>
              )}
            </div>
          )}
        </div>
        </section>
        <div className="space-y-2 px-3 pb-2 pt-2">
          {playing || animating ? (<>{actionButtons}{hintToggle}</>) : (
            <>
              {chipRow}
              <div className="grid grid-cols-[1fr_1fr_0.7fr_2fr] gap-2">
                {clearBtn}{rebetBtn}{doubleBtn}
                <button className="btn-primary h-11 px-2 text-sm" disabled={busy || !canDeal} onClick={deal}>{dealLabel}</button>
              </div>
            </>
          )}
        </div>
        {showRules && (
          <div className="absolute inset-0 z-40 flex flex-col bg-navy-950/97 p-3" role="dialog" aria-label="Rules">
            <div className="mb-2 flex items-center justify-between"><span className="font-cond text-lg font-extrabold uppercase text-white">Rules</span><button className="btn-ghost h-9 px-3" onClick={() => setShowRules(false)}>Close</button></div>
            <div className="min-h-0 flex-1 overflow-y-auto">
      {spin21 ? (
        <details className="card overflow-hidden" open>
          <summary className="cursor-pointer px-4 py-3 text-sm font-bold text-white hover:bg-navy-800">How Spin 21 works</summary>
          <div className="space-y-2 border-t border-navy-700 p-4 text-xs text-slate-300">
            <p><b className="text-gold-400">SPIN bet</b>: optional on each hand, and it always matches that hand's main bet. Tap SPIN on the felt to switch it on or off.</p>
            <p><b className="text-gold-400">Blackjack</b> (Ace + 10-value card as your first two cards) spins the bonus wheel at the end of the round, whatever the dealer has. Your main bet still pays 3:2 as normal.</p>
            <p><b className="text-sky-300">Ace Saver</b>: an Ace in your first two cards without blackjack returns your Spin bet. Anything else loses the Spin bet; the main hand plays on as normal.</p>
            <p>The wheel has 24 equal segments, paying on the Spin bet: 4x-12x, <b className="text-pink-400">MINI 30x</b>, <b className="text-orange-400">MAJOR 75x</b>, <b className="text-gold-400">GRAND 150x</b>, and <b className="text-violet-300">RESPIN</b>, which spins again at double value (up to 1,200x on a triple respin to GRAND).</p>
            <div className="flex flex-wrap gap-1">{WHEEL.map((w, i) => <span key={i} className="rounded bg-navy-800 px-1.5 py-0.5 tabular-nums">{w.respin ? 'RESPIN' : `${w.label ? `${w.label} ` : ''}${w.x}x`}</span>)}</div>
            <p className="text-slate-500">Blackjack comes up about once every 21 hands. The Spin bet returns about 96% over the long run, so the house keeps roughly 4p of every £1. Main game rules are the same as the classic table.</p>
          </div>
        </details>
      ) : (
      <details className="card overflow-hidden">
        <summary className="cursor-pointer px-4 py-3 text-sm font-bold text-white hover:bg-navy-800">Rules & side bet pays</summary>
        <div className="space-y-2 border-t border-navy-700 p-4 text-xs text-slate-300">
          <p>Six decks, shuffled every round. Dealer checks for blackjack with an Ace or 10 showing and stands on all 17s. Blackjack pays 3:2. Double on any first two cards, including after a split. Split any two cards of equal value, up to four hands; split Aces get one card each, and 21 after a split counts as 21, not blackjack.</p>
          <p><b className="text-gold-400">Perfect Pairs</b> (your first two cards): Perfect pair {PP_PAYS.perfect}:1 · Coloured pair {PP_PAYS.coloured}:1 · Mixed pair {PP_PAYS.mixed}:1.</p>
          <p><b className="text-gold-400">21+3</b> (your first two cards + dealer up card): Suited trips {T213_PAYS.suitedTrips}:1 · Straight flush {T213_PAYS.straightFlush}:1 · Three of a kind {T213_PAYS.trips}:1 · Straight {T213_PAYS.straight}:1 · Flush {T213_PAYS.flush}:1.</p>
          <p className="text-slate-500">Main game house edge is about 0.5% with perfect basic strategy; side bets carry a much bigger edge (roughly 3-6%).</p>
        </div>
      </details>
      )}
            </div>
          </div>
        )}
        {wheelQueue.length > 0 && (
          <BonusWheel key={wheelQueue.length} {...wheelQueue[0]} onDone={() => setWheelQueue((q) => q.slice(1))} />
        )}
      </div>,
      document.body,
    );
  }

  // ── Page view ──
  return (
    <div className="space-y-3">
      <GameHeader game={spin21 ? 'spin21' : 'blackjack'} title={title} rtp={spin21 ? '99.5% · Spin 96%' : '99.5%'}
        subtitle={spin21 ? 'Match your bet on SPIN · blackjack spins the bonus wheel · up to 1,000x' : 'Up to 3 hands · split & double · Perfect Pairs and 21+3 side bets'}
        extra={<button onClick={() => setFullPref(true)} className="whitespace-nowrap rounded-md bg-brand-500 px-2 py-1 text-xs font-bold text-navy-950">Full screen</button>} />

      <section ref={tableRef} className={`${tableCls} scroll-mt-[118px] rounded-2xl border-2 md:scroll-mt-4`}>
        {/* Shoe */}
        <div className="absolute right-3 top-3 h-12 w-9 rotate-6 rounded-md border-2 border-white/70 bg-gradient-to-br from-red-800 to-red-950 shadow-lg" aria-hidden="true" />
        <div ref={full ? fitRef : undefined} style={full && fit < 1 ? { transform: `scale(${fit})`, transformOrigin: 'top center' } : undefined} className={`relative p-4 sm:p-6 ${full ? `flex min-h-full flex-col justify-around gap-2 ${betting ? 'pt-10' : 'pt-3'}` : `space-y-4 ${betting ? 'pt-10' : ''}`}`}>
          {/* Dealer */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-emerald-100/80">Dealer {!(editing && !playing && !animating) && <ValueBadge cards={view.dealer} hidden={dealerHidden} />}</div>
            <div className="flex min-h-20 items-center pl-8 sm:min-h-24">
              {(editing && !playing && !animating ? [] : view.dealer).map((c, i) => <Card key={`d${i}-${c === '??' ? 'b' : 'f'}`} code={c} anim={view.last === `d${i}` ? (i === 1 && view.flip && c !== '??' ? 'flip' : 'deal') : null} overlap />)}
            </div>
          </div>

          <div className={`text-center text-[10px] font-bold uppercase tracking-[0.25em] text-emerald-100/30 ${full && !betting ? 'hidden [@media(min-height:700px)]:block' : ''}`}>Blackjack pays 3 to 2 · Dealer stands on all 17s</div>

          {betting && (
            <div className="absolute left-2 top-2 z-10 flex items-center gap-1 rounded-lg bg-black/35 p-1 text-[10px] font-bold uppercase text-emerald-50/80">
              <span className="px-1">Hands</span>
              {[1, 2, 3].map((n) => (
                <button key={n} onClick={() => { setEditing(true); setNumSeats(n); setSeats((cur) => cur.map((x, i) => (i < n && !x.bet ? { ...x, bet: cur[0].bet || 500, spinOn: spin21 && cur[0].spinOn } : x))); }}
                  className={`h-6 w-6 rounded-md text-xs ${numSeats === n ? 'bg-brand-500 text-navy-950' : 'text-white hover:bg-white/10'}`} aria-pressed={numSeats === n}>{n}</button>
              ))}
            </div>
          )}
          {/* Seats */}
          {(playing || animating || (r && r.status === 'done' && !editing)) && view.seats.length > 0 ? (
            <div className={`grid gap-2 ${view.seats.length === 1 ? 'grid-cols-1' : view.seats.length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
              {view.seats.map((seat, si) => {
                const pubSeat = r?.seats?.[si];
                return (
                  <div key={si} className="flex min-w-0 flex-col items-center gap-2">
                    <div className={seat.hands.length > 1 ? 'flex flex-wrap justify-center gap-1' : 'contents'}>
                    {seat.hands.map((h, hi) => {
                      const split = seat.hands.length > 1;
                      const size = split && (view.seats.length > 1 || seat.hands.length > 2) ? 'xs' : smallCards ? 'sm' : 'md';
                      const ph = pubSeat?.hands?.[hi];
                      const isActive = playing && !animating && r.active?.seat === si && r.active?.hand === hi;
                      return (
                        <div key={hi} className={`flex ${split ? '' : 'w-full'} flex-col items-center gap-1 rounded-xl p-1 transition-all ${isActive ? 'bg-gold-400/10 ring-2 ring-gold-400 shadow-[0_0_18px_rgba(250,204,21,0.35)]' : ''}`}>
                          <div className={`flex items-center ${size === 'xs' ? 'min-h-[50px] pl-6' : size === 'sm' ? 'min-h-[62px] pl-7' : 'min-h-20 pl-8 sm:min-h-24'}`}>
                            {h.cards.map((c, ci) => <Card key={ci} code={c} size={size} anim={view.last === `s${si}h${hi}c${ci}` ? 'deal' : null} overlap />)}
                          </div>
                          <div className="flex flex-wrap items-center justify-center gap-1">
                            <ValueBadge cards={h.cards} />
                            {ph && size !== 'xs' && <span className="rounded-full bg-black/40 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-50/90">{money(ph.bet)}{ph.doubled ? ' ×2' : ''}</span>}
                            {settled && ph?.result && <span className={`animate-fade-in rounded-full px-1.5 py-0.5 text-[10px] font-extrabold ${RESULT_CLS[ph.result]}`}>{RESULT_TEXT[ph.result]}{ph.payout > 0 ? ` +${size === 'xs' ? money(ph.payout).replace('.00', '') : money(ph.payout)}` : ''}</span>}
                          </div>
                          {isActive && <div className="text-[10px] font-bold uppercase tracking-wider text-gold-400">Your move</div>}
                        </div>
                      );
                    })}
                    </div>
                    {pubSeat && pubSeat.spin > 0 && !animating && (
                      <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${pubSeat.side.spin?.result === 'wheel' ? 'animate-win-pulse bg-gold-500 text-navy-950' : pubSeat.side.spin?.result === 'ace' ? 'bg-sky-500 text-navy-950' : 'bg-black/30 text-emerald-50/60'}`}>
                        SPIN {pubSeat.side.spin?.result === 'wheel' ? (pubSeat.side.spin.pending ? 'Blackjack! Wheel at end of round' : `Wheel +${money(pubSeat.side.spin.payout)}`) : pubSeat.side.spin?.result === 'ace' ? 'Ace Saver - stake back' : 'no blackjack'}
                      </span>
                    )}
                    {pubSeat && (pubSeat.pp > 0 || pubSeat.t213 > 0) && !animating && (
                      <div className="flex flex-wrap justify-center gap-1">
                        {pubSeat.pp > 0 && <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${pubSeat.side.pp?.result ? 'bg-gold-500 text-navy-950' : 'bg-black/30 text-emerald-50/60'}`}>PP {pubSeat.side.pp?.result ? `${SIDE_TEXT[pubSeat.side.pp.result]} +${money(pubSeat.side.pp.payout)}` : 'no pair'}</span>}
                        {pubSeat.t213 > 0 && <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${pubSeat.side.t213?.result ? 'bg-gold-500 text-navy-950' : 'bg-black/30 text-emerald-50/60'}`}>21+3 {pubSeat.side.t213?.result ? `${SIDE_TEXT[pubSeat.side.t213.result]} +${money(pubSeat.side.t213.payout)}` : 'no win'}</span>}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className={`grid gap-2 ${numSeats === 1 ? 'grid-cols-1' : numSeats === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
              {activeSeats.map((s, i) => (
                <div key={i} className="flex flex-col items-center gap-2 rounded-xl bg-black/15 p-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-100/60">Hand {i + 1}</div>
                  <BetSpot label="BET" amount={s.bet} big onTap={() => addChip(i, 'bet')} />
                  {spin21 ? (
                    <button type="button" onClick={() => { sfx.chip(); setEditing(true); setSeats((cur) => cur.map((x, j) => (j === i ? { ...x, spinOn: !x.spinOn } : x))); }}
                      className={`relative flex h-14 w-14 flex-col items-center justify-center rounded-full border-2 transition-all ${s.spinOn ? 'border-gold-400 bg-[conic-gradient(#facc15_0_25%,#0e7490_0_50%,#ec4899_0_75%,#7c3aed_0)] shadow-[0_0_14px_rgba(250,204,21,0.6)]' : 'border-dashed border-emerald-200/40'}`}
                      aria-pressed={s.spinOn} aria-label={`Spin bet ${s.spinOn ? 'on' : 'off'}`}>
                      <span className={`rounded-full px-1.5 text-[10px] font-black ${s.spinOn ? 'bg-navy-950 text-gold-400' : 'text-emerald-50/80'}`}>SPIN</span>
                      <span className="mt-0.5 rounded-full bg-black/50 px-1 text-[9px] font-bold text-white">{s.spinOn ? money(s.bet).replace('.00', '') : 'off'}</span>
                    </button>
                  ) : (
                  <div className="flex gap-1.5">
                    <BetSpot label="PAIRS" amount={s.pp} pays="25:1" onTap={() => addChip(i, 'pp')} />
                    <BetSpot label="21+3" amount={s.t213} pays="100:1" onTap={() => addChip(i, 't213')} />
                  </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {settled && !editing && (
            <div className="animate-fade-in mx-auto w-fit rounded-xl bg-black/45 px-5 py-2 text-center backdrop-blur">
              <div className={`${full ? 'text-xl' : 'text-2xl'} font-extrabold ${net > 0 ? 'text-gold-400' : net < 0 ? 'text-red-400' : 'text-slate-100'}`}>{net > 0 ? `You win ${money(net)}` : net < 0 ? `You lose ${money(-net)}` : 'Break even'}</div>
              <div className="text-[11px] text-emerald-50/80">Staked {money(r.totalStaked)} · returned {money(r.totalPayout)}</div>
              {!wheelQueue.length && !full && (
                <div className="mt-2 flex gap-2">
                  <button className="btn-primary h-11 flex-1 whitespace-nowrap px-4 text-sm" disabled={busy || !canDeal} onClick={deal}>
                    {total > (user?.balance ?? 0) ? 'Not enough balance' : `Deal again · ${money(total)}`}
                  </button>
                  <button className="btn h-11 whitespace-nowrap bg-white/10 px-3 text-sm text-white hover:bg-white/20" onClick={() => { setEditing(true); controlsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }}>Change bets</button>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {playing || animating ? (
        <div className="sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 -mx-1 space-y-2 rounded-xl bg-navy-950/90 p-1 backdrop-blur md:static md:mx-0 md:bg-transparent md:p-0 md:backdrop-blur-none">
          {actionButtons}{hintToggle}
        </div>
      ) : (
        <div ref={controlsRef} className="card scroll-mt-[118px] space-y-3 p-4">
          <div className="text-center text-[11px] text-slate-400">{r?.status === 'done' && !editing ? 'Deal again with the same bets, or pick a chip to change them' : 'Pick a chip, then tap a bet spot on the table'}</div>
          {chipRow}
          <div className="grid grid-cols-3 gap-2">{clearBtn}{rebetBtn}{doubleBtn}</div>
          <button className="btn-primary h-12 w-full text-base" disabled={busy || !canDeal} onClick={deal}>{dealLabel}</button>
        </div>
      )}

      <div className="flex items-center justify-between px-1 text-xs text-slate-400">
        <span>Last {history.length} rounds</span>
        <span className={`font-bold tabular-nums ${sessionNet > 0 ? 'text-brand-400' : sessionNet < 0 ? 'text-red-400' : 'text-slate-200'}`}>{signed(sessionNet)}</span>
      </div>

      {spin21 ? (
        <details className="card overflow-hidden" open>
          <summary className="cursor-pointer px-4 py-3 text-sm font-bold text-white hover:bg-navy-800">How Spin 21 works</summary>
          <div className="space-y-2 border-t border-navy-700 p-4 text-xs text-slate-300">
            <p><b className="text-gold-400">SPIN bet</b>: optional on each hand, and it always matches that hand's main bet. Tap SPIN on the felt to switch it on or off.</p>
            <p><b className="text-gold-400">Blackjack</b> (Ace + 10-value card as your first two cards) spins the bonus wheel at the end of the round, whatever the dealer has. Your main bet still pays 3:2 as normal.</p>
            <p><b className="text-sky-300">Ace Saver</b>: an Ace in your first two cards without blackjack returns your Spin bet. Anything else loses the Spin bet; the main hand plays on as normal.</p>
            <p>The wheel has 24 equal segments, paying on the Spin bet: 4x-12x, <b className="text-pink-400">MINI 30x</b>, <b className="text-orange-400">MAJOR 75x</b>, <b className="text-gold-400">GRAND 150x</b>, and <b className="text-violet-300">RESPIN</b>, which spins again at double value (up to 1,200x on a triple respin to GRAND).</p>
            <div className="flex flex-wrap gap-1">{WHEEL.map((w, i) => <span key={i} className="rounded bg-navy-800 px-1.5 py-0.5 tabular-nums">{w.respin ? 'RESPIN' : `${w.label ? `${w.label} ` : ''}${w.x}x`}</span>)}</div>
            <p className="text-slate-500">Blackjack comes up about once every 21 hands. The Spin bet returns about 96% over the long run, so the house keeps roughly 4p of every £1. Main game rules are the same as the classic table.</p>
          </div>
        </details>
      ) : (
      <details className="card overflow-hidden">
        <summary className="cursor-pointer px-4 py-3 text-sm font-bold text-white hover:bg-navy-800">Rules & side bet pays</summary>
        <div className="space-y-2 border-t border-navy-700 p-4 text-xs text-slate-300">
          <p>Six decks, shuffled every round. Dealer checks for blackjack with an Ace or 10 showing and stands on all 17s. Blackjack pays 3:2. Double on any first two cards, including after a split. Split any two cards of equal value, up to four hands; split Aces get one card each, and 21 after a split counts as 21, not blackjack.</p>
          <p><b className="text-gold-400">Perfect Pairs</b> (your first two cards): Perfect pair {PP_PAYS.perfect}:1 · Coloured pair {PP_PAYS.coloured}:1 · Mixed pair {PP_PAYS.mixed}:1.</p>
          <p><b className="text-gold-400">21+3</b> (your first two cards + dealer up card): Suited trips {T213_PAYS.suitedTrips}:1 · Straight flush {T213_PAYS.straightFlush}:1 · Three of a kind {T213_PAYS.trips}:1 · Straight {T213_PAYS.straight}:1 · Flush {T213_PAYS.flush}:1.</p>
          <p className="text-slate-500">Main game house edge is about 0.5% with perfect basic strategy; side bets carry a much bigger edge (roughly 3-6%).</p>
        </div>
      </details>
      )}
      {wheelQueue.length > 0 && (
        <BonusWheel key={wheelQueue.length} {...wheelQueue[0]} onDone={() => setWheelQueue((q) => q.slice(1))} />
      )}
    </div>
  );
}
