// Bonus Buy pages: the player's purchase history, and the admin area (settings, statistics,
// purchases and the change log). The admin page is only reachable for users the server marks
// as admins (ADMIN_USERS); the API refuses everyone else whatever this page shows.
import { useEffect, useState } from 'react';
import { api } from '../lib/api.js';
import { useApp } from '../state/AppContext.jsx';
import { dateTime, money, signed } from '../lib/format.js';
import { Empty, ErrorBox, Loading, StatTile } from '../components/ui.jsx';
import { Link } from '../lib/router.jsx';

const tone = (v) => (v > 0 ? 'pos' : v < 0 ? 'neg' : null);

export function BonusBuyHistory() {
  const { user } = useApp();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => { if (user) api.get('/api/bonusbuy/history').then(setData).catch(setError); }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!user) return <div className="card p-6 text-center text-sm text-slate-400"><Link to="/login" className="text-brand-400">Log in</Link> to see your bonus buys.</div>;
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const list = data.purchases;
  const cost = list.reduce((a, p) => a + p.cost, 0), paid = list.reduce((a, p) => a + p.payout, 0);
  const best = list.reduce((a, p) => (p.payout > (a?.payout ?? -1) ? p : a), null);
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold text-white">Bonus buys</h1>
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        <StatTile label="Bonuses bought" value={list.length} sub="last 50 shown" />
        <StatTile label="Spent" value={money(cost)} />
        <StatTile label="Paid back" value={money(paid)} />
        <StatTile label="Net" value={signed(paid - cost)} tone={tone(paid - cost)} sub={best ? `Best: ${money(best.payout)} on ${best.gameName}` : null} />
      </div>
      {!list.length ? <div className="card"><Empty title="No bonus buys yet">Use the Bonus Buy button next to Spin on any slot.</Empty></div> : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[680px] text-sm">
            <thead className="bg-navy-800 text-left text-[11px] uppercase tracking-wider text-slate-400">
              <tr><th className="px-3 py-2">Date</th><th className="px-3 py-2">Slot</th><th className="px-3 py-2">Bonus</th><th className="px-3 py-2 text-right">Bet</th><th className="px-3 py-2 text-right">Price</th><th className="px-3 py-2 text-right">Paid</th><th className="px-3 py-2 text-right">Net</th></tr>
            </thead>
            <tbody className="divide-y divide-navy-700">
              {list.map((p) => (
                <tr key={p.id}>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-400">{dateTime(p.at)}</td>
                  <td className="px-3 py-2 text-white">{p.gameName}</td>
                  <td className="px-3 py-2 text-slate-200">{p.name}{p.status === 'open' && <span className="ml-1 rounded bg-amber-400/20 px-1 text-[10px] font-bold text-amber-300">in play</span>}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{money(p.bet)}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{money(p.cost)} <span className="text-[11px] text-slate-500">({p.costX}x)</span></td>
                  <td className="px-3 py-2 text-right tabular-nums">{money(p.payout)}</td>
                  <td className={`px-3 py-2 text-right font-bold tabular-nums ${p.net >= 0 ? 'text-brand-400' : 'text-red-400'}`}>{signed(p.net)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function BonusBuyAdmin() {
  const { user, toast } = useApp();
  const [data, setData] = useState(null);
  const [cfg, setCfg] = useState(null);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const load = () => api.get('/api/admin/bonusbuy').then((d) => { setData(d); setCfg(structuredClone(d.config)); setError(null); }).catch(setError);
  useEffect(() => { if (user) load(); }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!user) return <div className="card p-6 text-center text-sm text-slate-400">Log in as an admin.</div>;
  if (error) return <ErrorBox error={error} />;
  if (!data || !cfg) return <Loading />;
  const set = (fn) => setCfg((c) => { const n = structuredClone(c); fn(n); return n; });
  const save = async () => {
    setSaving(true);
    try { const d = await api.put('/api/admin/bonusbuy', cfg); setData(d); setCfg(structuredClone(d.config)); toast('Bonus Buy settings saved', 'success'); }
    catch (e) { toast(e.message, 'error'); }
    finally { setSaving(false); }
  };
  const statOf = (g, o) => data.stats.find((s) => s.game === g && s.option === o);
  const totals = data.stats.reduce((a, s) => ({ n: a.n + s.n, staked: a.staked + s.staked, paid: a.paid + s.paid }), { n: 0, staked: 0, paid: 0 });
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-xl font-extrabold text-white">Bonus Buy admin</h1>
        <div className="flex gap-2">
          <button className="btn-ghost h-10 px-3 text-sm" onClick={() => setCfg(structuredClone(data.defaults))}>Reset to defaults</button>
          <button className="btn h-10 bg-brand-500 px-4 text-sm font-bold text-navy-950 disabled:opacity-50" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save changes'}</button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        <StatTile label="Bonuses bought" value={totals.n} />
        <StatTile label="Total spent" value={money(totals.staked)} />
        <StatTile label="Total paid" value={money(totals.paid)} />
        <StatTile label="Observed return" value={totals.staked ? `${((totals.paid / totals.staked) * 100).toFixed(1)}%` : '–'} />
      </div>
      <div className="card space-y-3 p-3">
        <label className="flex items-center gap-2 text-sm font-bold text-white"><input type="checkbox" className="h-5 w-5 accent-brand-500" checked={cfg.enabled} onChange={(e) => set((c) => { c.enabled = e.target.checked; })} />Bonus Buy switched on (all slots)</label>
        <div className="flex flex-wrap gap-3 text-sm">
          <label className="flex items-center gap-2 text-slate-300">Min bet (p)<input type="number" min="10" step="10" className="h-9 w-24 rounded-lg border border-navy-600 bg-navy-900 px-2 text-white" value={cfg.minStake} onChange={(e) => set((c) => { c.minStake = Math.round(Number(e.target.value)); })} /></label>
          <label className="flex items-center gap-2 text-slate-300">Max bet (p)<input type="number" min="10" step="10" className="h-9 w-24 rounded-lg border border-navy-600 bg-navy-900 px-2 text-white" value={cfg.maxStake} onChange={(e) => set((c) => { c.maxStake = Math.round(Number(e.target.value)); })} /></label>
        </div>
        <p className="text-xs text-slate-500">Price = total bet × cost multiplier. The default multipliers come from simulating every bought bonus with the real game code (scripts/sim-bonusbuy.mjs) and are set for about a 96% return; "average return" below is that measured value. Changing a multiplier changes that option's return to roughly average ÷ multiplier.</p>
      </div>
      <div className="space-y-2">
        {data.games.map((g) => (
          <div key={g.id} className="card p-3">
            <label className="mb-2 flex items-center gap-2 font-bold text-white"><input type="checkbox" className="h-5 w-5 accent-brand-500" checked={cfg.games[g.id].enabled} onChange={(e) => set((c) => { c.games[g.id].enabled = e.target.checked; })} />{g.name}</label>
            <div className="space-y-2">
              {g.options.map((o) => {
                const oc = cfg.games[g.id].options[o.id], st = statOf(g.id, o.id), avg = o.price?.avg;
                return (
                  <div key={o.id} className="grid grid-cols-[auto_1fr] items-center gap-x-3 gap-y-1 rounded-lg bg-navy-800 p-2 text-sm sm:grid-cols-[auto_1fr_auto_auto]">
                    <input type="checkbox" className="h-5 w-5 accent-brand-500" checked={oc.enabled} onChange={(e) => set((c) => { c.games[g.id].options[o.id].enabled = e.target.checked; })} aria-label={`${o.name} on`} />
                    <div><div className="font-semibold text-slate-100">{o.name}</div><div className="text-[11px] text-slate-500">Average return {avg != null ? `${avg}x` : '–'} · theoretical RTP {avg ? `${((avg / oc.cost) * 100).toFixed(1)}%` : '–'}</div></div>
                    <label className="col-start-2 flex items-center gap-1.5 text-slate-300 sm:col-start-auto">Cost<input type="number" min="1" max="5000" step="1" className="h-9 w-20 rounded-lg border border-navy-600 bg-navy-900 px-2 text-white" value={oc.cost} onChange={(e) => set((c) => { c.games[g.id].options[o.id].cost = Number(e.target.value); })} />x</label>
                    <div className="col-start-2 text-[11px] text-slate-400 sm:col-start-auto sm:text-right">{st ? <>{st.n} bought · {money(st.staked)} in · {money(st.paid)} out<br />observed {st.staked ? ((st.paid / st.staked) * 100).toFixed(1) : 0}%{st.open ? ` · ${st.open} in play` : ''}</> : 'No purchases yet'}</div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        {Object.entries(data.unsupported).map(([id, why]) => <div key={id} className="rounded-lg border border-navy-700 p-2 text-xs text-slate-500"><b className="text-slate-300">{id}</b>: {why}</div>)}
      </div>
      <div className="card overflow-x-auto">
        <div className="border-b border-navy-700 px-3 py-2 text-sm font-bold text-white">Recent purchases</div>
        {!data.recent.length ? <p className="p-3 text-sm text-slate-500">None yet.</p> : (
          <table className="w-full min-w-[640px] text-xs">
            <thead className="text-left text-slate-400"><tr><th className="px-3 py-1.5">When</th><th>Player</th><th>Slot</th><th>Bonus</th><th className="text-right">Price</th><th className="text-right">Paid</th><th className="px-3 text-right">Status</th></tr></thead>
            <tbody className="divide-y divide-navy-700 text-slate-300">
              {data.recent.map((p) => <tr key={p.id}><td className="whitespace-nowrap px-3 py-1.5">{dateTime(p.at)}</td><td>{p.username}</td><td>{p.gameName}</td><td>{p.name}</td><td className="text-right tabular-nums">{money(p.cost)}</td><td className="text-right tabular-nums">{money(p.payout)}</td><td className="px-3 text-right">{p.status}</td></tr>)}
            </tbody>
          </table>
        )}
      </div>
      <div className="card p-3">
        <div className="mb-1 text-sm font-bold text-white">Change log</div>
        {!data.log.length ? <p className="text-sm text-slate-500">No changes yet.</p> : (
          <ul className="space-y-1 text-xs text-slate-300">{data.log.map((l) => <li key={l.id}><span className="text-slate-500">{dateTime(l.at)} · {l.username}:</span> {l.change.join('; ')}</li>)}</ul>
        )}
      </div>
    </div>
  );
}
