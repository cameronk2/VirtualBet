// Shared posing for the Quaternius CC0 base characters (65-joint skeleton, bones point along +Y):
// aim a bone at a point, rotate in world space, two-bone arm IK and finger poses.
import * as THREE from '../../../vendor/three/three.module.js';

export function makeRig(model) {
  const B = {}; model.traverse((o) => { if (o.isBone) B[o.name] = o; });
  model.updateMatrixWorld(true);
  const bind = {}; for (const [n, b] of Object.entries(B)) bind[n] = b.quaternion.clone();
  const wp = (b) => b.getWorldPosition(new THREE.Vector3());
  const len = (a, b) => wp(B[a]).distanceTo(wp(B[b]));
  const armLen = { L: [len('upperarm_l', 'lowerarm_l'), len('lowerarm_l', 'hand_l')], R: [len('upperarm_r', 'lowerarm_r'), len('lowerarm_r', 'hand_r')] };
  const q1 = new THREE.Quaternion(), q2 = new THREE.Quaternion(), v1 = new THREE.Vector3(), v2 = new THREE.Vector3();
  function reset() { for (const [n, q] of Object.entries(bind)) B[n].quaternion.copy(q); model.updateMatrixWorld(true); }
  function aim(bone, child, target) {
    bone.updateMatrixWorld(true);
    const bp = wp(bone), cp = wp(child);
    v1.subVectors(cp, bp).normalize(); v2.subVectors(target, bp).normalize();
    q1.setFromUnitVectors(v1, v2);
    bone.getWorldQuaternion(q2); q1.multiply(q2);
    bone.parent.getWorldQuaternion(q2); bone.quaternion.copy(q2.invert().multiply(q1));
    bone.updateMatrixWorld(true);
  }
  function rotWorld(bone, axis, ang) {
    if (!bone || !ang) return;
    bone.updateMatrixWorld(true);
    bone.getWorldQuaternion(q2); q1.setFromAxisAngle(axis, ang).multiply(q2);
    bone.parent.getWorldQuaternion(q2); bone.quaternion.copy(q2.invert().multiply(q1));
    bone.updateMatrixWorld(true);
  }
  /** Two-bone arm IK. Returns the point the hand actually reached. */
  function arm(side, target, pole) {
    const s = side === 'L' ? '_l' : '_r';
    const up = B[`upperarm${s}`], lo = B[`lowerarm${s}`], ha = B[`hand${s}`];
    const [a, b] = armLen[side];
    const S = wp(up); const dir = target.clone().sub(S); let d = dir.length();
    d = Math.max(0.05, Math.min(d, (a + b) * 0.995)); dir.normalize();
    const T = S.clone().addScaledVector(dir, d);
    const x = (a * a - b * b + d * d) / (2 * d), h = Math.sqrt(Math.max(0, a * a - x * x));
    const pl = pole.clone().sub(dir.clone().multiplyScalar(pole.dot(dir))).normalize();
    const E = S.clone().addScaledVector(dir, x).addScaledVector(pl, h);
    aim(up, lo, E); aim(lo, ha, T);
    return T;
  }
  /** Points the hand (wrist → middle knuckle) along `dir` (world). */
  function handDir(side, dir) {
    const s = side === 'L' ? '_l' : '_r';
    const ha = B[`hand${s}`]; const t = wp(ha).add(dir.clone().normalize().multiplyScalar(0.1));
    aim(ha, B[`middle_01${s}`], t);
  }
  /** Curls fingers about the knuckle line. amt per finger: { index, middle, ring, pinky, thumb } (radians-ish). */
  function fingers(side, amt) {
    const s = side === 'L' ? '_l' : '_r';
    B[`hand${s}`].updateMatrixWorld(true);
    const axis = wp(B[`index_01${s}`]).sub(wp(B[`pinky_01${s}`])).normalize();
    const sign = side === 'L' ? -1 : 1;
    for (const f of ['index', 'middle', 'ring', 'pinky']) {
      const a = amt[f] ?? amt.all ?? 0;
      for (const k of ['01', '02', '03']) rotWorld(B[`${f}_${k}${s}`], axis, sign * a * (k === '01' ? 0.55 : 0.9));
    }
    const th = amt.thumb ?? amt.all ?? 0; rotWorld(B[`thumb_02${s}`], axis, sign * th * 0.4); rotWorld(B[`thumb_03${s}`], axis, sign * th * 0.4);
  }
  return { B, bind, wp, reset, aim, rotWorld, arm, handDir, fingers };
}
