// Clyde Blackjack: a first-person seat at a Glasgow blackjack table. The table, croupier, cards and
// chips are 3D (scene.js); this page holds the bets, talks to the server and plays each round's
// events in order. Side bets: Pairs, 21+3 and Top 3. Virtual money only.
import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../../state/AppContext.jsx';
import { api } from '../../lib/api.js';
import { navigate } from '../../lib/router.jsx';
import { money } from '../../lib/format.js';
import { lockScroll } from '../../lib/scrollLock.js';
import { useGameSound } from '../../components/GameShell.jsx';
import SoundMenu from '../../components/SoundMenu.jsx';
import { Modal, Spinner } from '../../components/ui.jsx';
import { LoginPrompt } from '../MyBets.jsx';
import { handValue, CLYDE_PP_PAYS as PP_PAYS, CLYDE_T213_PAYS as T213_PAYS, TOP3_PAYS, SIDE_TEXT } from '../../../../server/blackjack.js';
import { CHIPS } from './textures.js';
import { sfx, say, preloadClyde } from './audio.js';

const SPOTS = [['main', 'Main bet'], ['pp', 'Pairs'], ['t213', '21+3'], ['top3', 'Top 3']];
const EMPTY = { main: 0, pp: 0, t213: 0, top3: 0 };
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } };
// a 502/503 means the server is restarting (e.g. installing an update): nothing was staked
const errText = (e) => (/\(50[234]\)/.test(e?.message || '') ? 'The table is restarting after an update. No bet was taken; try again in a minute.' : e.message);
const totalOf = (b) => b.main + b.pp + b.t213 + b.top3;
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const valueText = (cards) => { if (!cards.length) return ''; const v = handValue(cards); return v.soft && v.total < 21 && cards.length ? `${v.total - 10}/${v.total}` : String(v.total); };

export default function ClydeBlackjack() {
  const { user, setUser, toast } = useApp();
  const music = useGameSound('clyde');
  const cv = useRef(null), table = useRef(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(null);
  const [quality, setQuality] = useState(() => pref('cl_q', 'auto'));
  const [bets, setBets] = useState(EMPTY);
  const [last, setLast] = useState(() => pref('cl_last', null));
  const [chip, setChip] = useState(() => { const c = pref('cl_chip', 100); return CHIPS.some((x) => x.v === c) ? c : 100; });
  const [round, setRound] = useState(null);       // server view
  const [phase, setPhase] = useState('bets');      // bets | dealing | play | dealer | result
  const [shown, setShown] = useState({ dealer: [], hands: [[]] });
  const [banner, setBanner] = useState(null);
  const [sides, setSides] = useState([]);
  const [info, setInfo] = useState(false);
  const [busy, setBusy] = useState(false);
  const [fast, setFast] = useState(() => pref('cl_fast', false));
  const [hud, setHud] = useState({ dealer: null, hands: [], pops: {} });
  const [pops, setPops] = useState([]);           // small "+£55" figures beside paid bets
  const [net, setNet] = useState(null);           // the last round's overall win / loss
  const popId = useRef(0);
  const pop = (spot, amount) => { const id = ++popId.current; setPops((p) => [...p, { id, spot, text: `+${money(amount)}` }]); setTimeout(() => setPops((p) => p.filter((x) => x.id !== id)), 3200); };
  const played = useRef(0);
  const balance = user?.balance ?? 0;

  useEffect(() => lockScroll(), []);
  useEffect(() => { preloadClyde(); }, []);
  // the 3D table
  useEffect(() => {
    let alive = true, t = null;
    setReady(false);
    import('./scene.js').then(({ createTable }) => createTable(cv.current, { quality })).then((x) => {
      if (!alive) { x.dispose(); return; }
      t = x; table.current = x; x.setFast(fast); x.onSfx((n) => sfx(n)); setReady(true);
    }).catch((e) => { console.warn('3D table unavailable', e); if (alive) setFailed(String(e?.message || e).slice(0, 140)); });
    const r = () => t?.resize(); window.addEventListener('resize', r);
    return () => { alive = false; window.removeEventListener('resize', r); t?.dispose(); table.current = null; };
  }, [quality]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { table.current?.setFast(fast); }, [fast]);
  useEffect(() => { if (ready) table.current?.setBets(bets); }, [bets, ready]);
  useEffect(() => { table.current?.setGlow(phase === 'bets' && bets.main > 0); }, [phase, bets.main, ready]);
  // greet once the table is up
  useEffect(() => { if (ready) { const k = setTimeout(() => say('welcome'), 700); return () => clearTimeout(k); } return undefined; }, [ready]);

  // keep the totals floating over the cards
  useEffect(() => {
    if (!ready) return undefined;
    let raf = 0;
    const tick = () => {
      const t = table.current; if (!t) return;
      setHud({ dealer: shown.dealer.length ? t.screenOf('dealer') : null, hands: shown.hands.map((h, i) => (h.length ? t.screenOf('player', i) : null)), pops: Object.fromEntries(pops.map((x) => [x.id, t.spotScreen(x.spot)])) });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [ready, shown, pops]);

  // a round in progress when you arrive (e.g. after a reload): show it as it stands
  const resumed = useRef(false);
  useEffect(() => {
    if (!ready || !user || resumed.current) return;
    resumed.current = true;
    api.get('/api/clyde').then(async (d) => {
      if (d.round && d.round.status === 'player') {
        const s = d.round.seats[0];
        setBets({ main: s.bet, pp: s.pp, t213: s.t213, top3: s.top3 || 0 });
        setRound(d.round); played.current = 0; table.current?.setFocus('cards', true);
        await playEvents(d.round, true);
        setPhase('play');
      }
    }).catch(() => {});
  }, [ready, user]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── betting ──
  const addChip = useCallback((spot) => {
    if (phase !== 'bets' || busy) return;
    setBets((b) => {
      const n = { ...b, [spot]: b[spot] + chip };
      if (totalOf(n) > balance) { toast('Not enough virtual balance for that chip.', 'error'); return b; }
      return n;
    });
    sfx('chip');
  }, [phase, busy, chip, balance, toast]);
  const onCanvasTap = (e) => {
    const s = table.current?.pick(e.clientX, e.clientY);
    if (s) addChip(s);
  };

  // ── playing the server's events in order ──
  async function playEvents(r, instant = false) {
    const t = table.current; if (!t) return;
    const ev = r.events.slice(played.current);
    played.current = r.events.length;
    const fastNow = fast || instant;
    for (const e of ev) {
      if (e.t === 'card') {
        await t.deal('player', e.card, { hand: e.hand });
        setShown((s) => { const hands = s.hands.map((h) => [...h]); while (hands.length <= e.hand) hands.push([]); hands[e.hand].push(e.card); return { ...s, hands }; });
      } else if (e.t === 'dealer') {
        await t.deal('dealer', e.card, { faceUp: !e.hole });
        setShown((s) => ({ ...s, dealer: [...s.dealer, e.hole ? '??' : e.card] }));
      } else if (e.t === 'split') {
        await t.split(e.hand);
        setShown((s) => { const hands = s.hands.map((h) => [...h]); const moved = hands[e.hand].pop(); hands.splice(e.hand + 1, 0, [moved]); return { ...s, hands }; });
      } else if (e.t === 'reveal') {
        await t.reveal(e.card);
        setShown((s) => ({ ...s, dealer: s.dealer.map((c, i) => (i === 1 ? e.card : c)) }));
        await wait(fastNow ? 150 : 350);
      }
      if (!fastNow) await wait(90);
    }
  }

  /** Side bets are settled before play goes on: the view drops to your bets, the dealer pays each winner
   *  (or takes each loser) one by one, then the view goes back up to the cards. */
  async function settleSides(r, backToCards) {
    const seat = r.seats[0]; const t = table.current;
    const todo = [['pp', 'Pairs', PP_PAYS], ['t213', '21+3', T213_PAYS], ['top3', 'Top 3', TOP3_PAYS]].filter(([k]) => seat[k] && seat.side?.[k]);
    if (!todo.length) return;
    await t.setFocus('bets');
    // every losing side bet goes in one sweep, then each winner is paid in turn
    const out = todo.map(([k, label, pays]) => (seat.side[k].result
      ? { k, text: `${label}: ${SIDE_TEXT[seat.side[k].result]} pays ${pays[seat.side[k].result]}:1`, win: true }
      : { k, text: `${label}: no win`, win: false }));
    setSides(out);
    const losers = todo.filter(([k]) => !seat.side[k].result).map(([k]) => k);
    if (losers.length) await t.collect(losers);
    for (const [k] of todo.filter(([k2]) => seat.side[k2].result)) { say(k); pop(k, seat.side[k].payout - seat[k]); await t.payOut(k, seat.side[k].payout, seat[k]); }
    // settled: those stakes are gone from the felt and must not be redrawn for the rest of the hand
    setBets((b) => ({ ...b, pp: 0, t213: 0, top3: 0 }));
    setTimeout(() => setSides([]), 1500);
    if (backToCards) await t.setFocus('cards');
  }

  async function finishRound(r) {
    const t = table.current;
    setPhase('result');
    const seat = r.seats[0];
    const stake = seat.hands.reduce((a, h) => a + h.bet, 0);
    const pay = seat.hands.reduce((a, h) => a + h.payout, 0);
    const res = seat.hands.map((h) => h.result);
    const dv = handValue(r.dealer).total;
    let text = '', tone = 'lose';
    if (res.includes('blackjack')) { text = 'Blackjack! Pays 3 to 2'; tone = 'win'; say('bj'); }
    else if (pay > stake) { text = dv > 21 ? 'Dealer bust: you win' : 'You win'; tone = 'win'; say(dv > 21 ? 'dbust' : 'win'); }
    else if (pay === stake && pay > 0) { text = 'Push: stake back'; tone = 'push'; say('push'); }
    else if (pay > 0) { text = `Returned ${money(pay)}`; tone = 'push'; }
    else if (res.every((x) => x === 'bust')) { text = 'Bust'; say('bust'); }
    else { text = r.dealer.length === 2 && dv === 21 ? 'Dealer has blackjack' : 'Dealer wins'; say(r.dealer.length === 2 && dv === 21 ? 'dealer_bj' : 'lose'); }
    setBanner({ text, tone, pay, stake });
    await t.setFocus('bets'); // look down at your bet to watch it paid or taken
    if (tone === 'win') { sfx(res.includes('blackjack') ? 'bj' : 'win'); pop('main', pay - stake); await t.payOut('main', pay, stake); }
    else if (pay > 0) await t.returnChips('main');
    else await t.collect('main');
    await wait(fast ? 900 : 1700);
    await t.clearCards();
    setShown({ dealer: [], hands: [[]] }); setBanner(null); t.setFocus('bets');
    const staked = stake + seat.pp + seat.t213 + (seat.top3 || 0);
    const back = pay + ['pp', 't213', 'top3'].reduce((a, k) => a + (seat.side?.[k]?.payout || 0), 0);
    setNet(back - staked);
    setBets(EMPTY);
    setPhase('bets');
    say('bets');
  }

  const deal = async () => {
    if (!bets.main) { toast('Put a bet on the main circle first.', 'error'); return; }
    if (totalOf(bets) > balance) { toast('Not enough virtual balance.', 'error'); return; }
    setBusy(true); music();
    try {
      say('nomore'); sfx('chips'); setNet(null);
      // look up at the cards first; the first card only leaves the shoe once the view is there
      const look = table.current?.setFocus('cards');
      const d = await api.post('/api/clyde/deal', { seats: [{ bet: bets.main, pp: bets.pp, t213: bets.t213, top3: bets.top3 }] }).catch((e) => { table.current?.setFocus('bets'); throw e; });
      setLast(bets); save('cl_last', bets);
      played.current = 0; setRound(d.round); setPhase('dealing');
      await look;
      await playEvents(d.round);
      await settleSides(d.round, d.round.status !== 'done');
      if (d.round.status === 'done') { setPhase('dealer'); await finishRound(d.round); }
      else setPhase('play');
      setUser(d.user);
    } catch (e) { toast(errText(e), 'error'); } finally { setBusy(false); }
  };

  const act = async (a) => {
    if (busy || phase !== 'play') return;
    setBusy(true);
    try {
      const g = table.current?.gesture(a);
      // you call it out yourself (a Scottish lad at the table); the dealer answers doubles and splits
      if (a === 'hit') say('p_hit'); else if (a === 'stand') say('p_stand'); else if (a === 'double') say('double'); else if (a === 'split') say('split');
      const reqP = api.post('/api/clyde/action', { action: a });
      await g;
      const d = await reqP;
      if (a === 'double' || a === 'split') { const add = round.seats[0].hands[round.active?.hand || 0].bet; setBets((b) => ({ ...b, main: b.main + add })); }
      setRound(d.round);
      if (d.round.status === 'done') setPhase('dealer');
      await playEvents(d.round);
      if (d.round.status === 'done') await finishRound(d.round);
      else {
      }
      setUser(d.user);
    } catch (e) { toast(errText(e), 'error'); } finally { setBusy(false); }
  };

  if (user === null) return <LoginPrompt what="Clyde Blackjack" />;
  if (!user) return <div className="flex justify-center py-16"><Spinner /></div>;

  const allowed = round?.allowed || {};
  const activeHand = round?.active?.hand ?? 0;
  const total = totalOf(bets);
  const dealerVal = shown.dealer.filter((c) => c !== '??');

  return createPortal(
    <div className="fixed inset-0 z-[45] select-none overflow-hidden bg-black text-white" style={{ height: '100dvh' }} role="dialog" aria-label="Clyde Blackjack table">
      <canvas ref={cv} onClick={onCanvasTap} className="absolute inset-0 h-full w-full" />
      {!ready && !failed && <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#0b0605] text-sm text-amber-100/80"><Spinner />Setting up the table in the Clyde Room…</div>}
      {failed && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#0b0605] p-6 text-center text-sm text-amber-100/90">
          <p>The 3D table couldn't start on this device ({failed}).</p>
          <button type="button" onClick={() => navigate('/blackjack')} className="rounded-full bg-amber-400 px-5 py-2 font-bold text-black">Play classic Blackjack</button>
        </div>
      )}

      {/* top bar */}
      <div className="absolute inset-x-0 top-0 z-10 flex items-center gap-2 bg-gradient-to-b from-black/80 to-transparent px-2 pb-6" style={{ paddingTop: 'max(8px, env(safe-area-inset-top))' }}>
        <button type="button" onClick={() => navigate('/casino')} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-black/50 text-lg ring-1 ring-white/20" aria-label="Leave the table and return to the casino">✕</button>
        <div className="min-w-0 leading-tight">
          <div className="truncate font-[Cinzel,Georgia,serif] text-[15px] font-bold tracking-wide text-amber-100">Clyde Blackjack</div>
          <div className="text-[10px] text-amber-100/60">The Clyde Room · Glasgow</div>
        </div>
        <div className="ml-auto text-right leading-tight"><div className="text-[9px] font-semibold uppercase tracking-wider text-white/60">Balance</div><div className="font-cond text-base font-bold tabular-nums">{money(balance)}</div></div>
        <SoundMenu game="clyde" />
        <button type="button" onClick={() => setInfo(true)} className="flex h-8 w-8 items-center justify-center rounded-md bg-black/50 text-sm font-bold ring-1 ring-white/20" aria-label="Rules and payouts">i</button>
      </div>

      {/* totals over the cards */}
      {hud.dealer && dealerVal.length > 0 && <Badge at={hud.dealer} text={valueText(dealerVal)} dealer />}
      {hud.hands.map((p, i) => (p && shown.hands[i]?.length ? <Badge key={i} at={p} text={valueText(shown.hands[i])} active={phase === 'play' && i === activeHand && shown.hands.length > 1} /> : null))}

      {pops.map((x) => (hud.pops?.[x.id] ? (
        <div key={x.id} className="cl-pop pointer-events-none absolute z-[6] -translate-x-1/2 -translate-y-full" style={{ left: hud.pops[x.id].x, top: hud.pops[x.id].y }}>
          <div className="rounded-full bg-amber-300 px-2 py-0.5 font-cond text-sm font-extrabold tabular-nums text-amber-950 shadow-lg ring-1 ring-amber-100">{x.text}</div>
        </div>
      ) : null))}
      {/* results */}
      {banner && (
        <div className="pointer-events-none absolute inset-x-0 top-[22%] z-10 flex justify-center">
          <div className={`cl-pop rounded-2xl px-5 py-2.5 text-center shadow-2xl ring-1 backdrop-blur-sm ${banner.tone === 'win' ? 'bg-emerald-900/80 ring-amber-300/70' : banner.tone === 'push' ? 'bg-slate-900/80 ring-white/30' : 'bg-black/70 ring-white/20'}`}>
            <div className="font-[Cinzel,Georgia,serif] text-xl font-bold text-amber-100">{banner.text}</div>
            {banner.pay > 0 && <div className="text-sm font-semibold text-emerald-200">{money(banner.pay)} back on {money(banner.stake)}</div>}
          </div>
        </div>
      )}
      {sides.length > 0 && (
        <div className="pointer-events-none absolute inset-x-0 top-[13%] z-10 flex flex-col items-center gap-1">
          {sides.map((s) => <div key={s.k} className={`cl-pop rounded-full px-3 py-1 text-xs font-bold shadow ${s.win ? 'bg-amber-300 text-amber-950' : 'bg-black/60 text-white/70'}`}>{s.text}</div>)}
        </div>
      )}

      {/* controls */}
      <div className="absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black/90 via-black/70 to-transparent px-2 pt-8" style={{ paddingBottom: 'max(10px, env(safe-area-inset-bottom))' }}>
        {phase === 'bets' && net !== null && (
          <div className="mb-2 flex justify-center">
            <div className={`rounded-full px-3 py-1 text-xs font-bold tabular-nums shadow ring-1 ${net > 0 ? 'bg-emerald-800/90 text-emerald-100 ring-emerald-300/50' : net < 0 ? 'bg-black/70 text-red-200 ring-red-300/30' : 'bg-black/60 text-white/80 ring-white/20'}`}>
              Last round: {net > 0 ? `won ${money(net)}` : net < 0 ? `lost ${money(-net)}` : 'broke even'}
            </div>
          </div>
        )}
        {phase === 'bets' && (
          <div className="mx-auto max-w-xl space-y-2">
            <div className="grid grid-cols-4 gap-1.5">
              {SPOTS.map(([k, label]) => (
                <button key={k} type="button" onClick={() => addChip(k)} disabled={busy || !ready}
                  className={`flex h-14 flex-col items-center justify-center rounded-xl text-[11px] font-bold uppercase tracking-wide ring-1 active:scale-95 ${k === 'main' ? 'bg-emerald-800/90 ring-emerald-300/60' : 'bg-black/60 ring-white/25'}`}>
                  {label}<span className="mt-0.5 font-cond text-sm tabular-nums text-amber-200">{bets[k] ? money(bets[k]) : '–'}</span>
                </button>
              ))}
            </div>
            <div className="flex items-center justify-center gap-5" role="radiogroup" aria-label="Chip value">
              {CHIPS.map((c) => (
                <button key={c.v} type="button" role="radio" aria-checked={chip === c.v} disabled={c.v > balance} onClick={() => { setChip(c.v); save('cl_chip', c.v); sfx('chip'); }}
                  className={`relative h-14 w-14 shrink-0 rounded-full text-xs font-extrabold shadow-lg transition-transform disabled:opacity-30 ${chip === c.v ? '-translate-y-1 scale-110 ring-2 ring-amber-200' : ''}`}
                  style={{ background: `repeating-conic-gradient(${c.edge} 0 12deg, ${c.col} 12deg 45deg)`, color: c.ink }}>
                  <span className="absolute inset-[5px] flex items-center justify-center rounded-full" style={{ background: c.col }}>{c.label}</span>
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1.5">
              <button type="button" onClick={() => setBets(EMPTY)} disabled={!total || busy} className="h-12 rounded-xl bg-white/10 px-3 text-xs font-semibold disabled:opacity-40">Clear</button>
              <button type="button" onClick={() => last && setBets({ ...last })} disabled={!last || busy || total > 0} className="h-12 rounded-xl bg-white/10 px-3 text-xs font-semibold disabled:opacity-40">Rebet</button>
              <button type="button" onClick={() => setBets((b) => (totalOf(b) * 2 <= balance ? { main: b.main * 2, pp: b.pp * 2, t213: b.t213 * 2, top3: b.top3 * 2 } : b))} disabled={!total || busy} className="h-12 rounded-xl bg-white/10 px-3 text-xs font-semibold disabled:opacity-40">×2</button>
              <button type="button" onClick={deal} disabled={!bets.main || busy || !ready} className="h-12 flex-1 rounded-xl bg-[linear-gradient(180deg,#fde68a,#d4a017)] text-base font-extrabold text-amber-950 shadow-lg active:scale-95 disabled:opacity-40">
                {bets.main ? `Deal · ${money(total)}` : 'Bet on the main circle'}
              </button>
            </div>
          </div>
        )}
        {phase === 'play' && (
          <div className="mx-auto grid max-w-xl grid-cols-4 gap-1.5">
            <ActBtn label="Hit" sub="tap the felt" on={() => act('hit')} disabled={busy || !allowed.hit} tone="bg-emerald-700" />
            <ActBtn label="Stand" sub="wave your hand" on={() => act('stand')} disabled={busy || !allowed.stand} tone="bg-red-800" />
            <ActBtn label="Double" sub={round ? money(round.seats[0].hands[activeHand]?.bet || 0) : ''} on={() => act('double')} disabled={busy || !allowed.double || (round && round.seats[0].hands[activeHand]?.bet > balance)} tone="bg-amber-700" />
            <ActBtn label="Split" sub="two hands" on={() => act('split')} disabled={busy || !allowed.split || (round && round.seats[0].hands[activeHand]?.bet > balance)} tone="bg-sky-800" />
          </div>
        )}
        {(phase === 'dealing' || phase === 'dealer' || phase === 'result') && <div className="py-4 text-center text-sm text-white/70">{phase === 'dealing' ? 'Dealing…' : phase === 'dealer' ? 'Dealer plays…' : ''}</div>}
        <div className="mx-auto mt-1.5 flex max-w-xl items-center justify-between text-[10px] text-white/50">
          <span>Chips £1 · £5 · £25 · £100 · virtual money only</span>
          <span className="flex gap-1.5">
            <button type="button" onClick={() => { const v = !fast; setFast(v); save('cl_fast', v); }} className={`rounded px-1.5 py-0.5 ${fast ? 'bg-amber-300 text-black' : 'bg-white/10'}`}>Quick</button>
            <button type="button" onClick={() => { const q = quality === 'low' ? 'auto' : 'low'; setQuality(q); save('cl_q', q); }} className="rounded bg-white/10 px-1.5 py-0.5">{quality === 'low' ? 'Lite' : 'HD'}</button>
          </span>
        </div>
      </div>

      <Modal open={info} onClose={() => setInfo(false)} title="Clyde Blackjack: rules and payouts">
        <div className="space-y-3 text-sm text-slate-300">
          <p>Six decks, shuffled every round. Dealer stands on all 17s and peeks for blackjack. Blackjack pays 3 to 2. Double on any first two cards (also after a split). Split pairs up to four hands; split aces get one card each. One box per player.</p>
          <p>Signals: <b>Hit</b> taps the felt, <b>Stand</b> waves a flat hand over your cards, just as at a real table, and you call it out loud.</p>
          <div>
            <h3 className="mb-1 font-bold text-white">Side bets (settled on the first two cards)</h3>
            <table className="w-full text-xs"><tbody>
              <tr className="border-b border-white/10"><td className="py-1 font-semibold text-white">Pairs</td><td>Perfect pair 30:1 · Coloured pair 12:1 · Mixed pair 5:1</td><td className="text-right">98.1%</td></tr>
              <tr className="border-b border-white/10"><td className="py-1 font-semibold text-white">21+3</td><td>Your two cards and the dealer's up card make a flush, straight, three of a kind, straight flush or suited trips: all pay 9:1</td><td className="text-right">96.8%</td></tr>
              <tr><td className="py-1 font-semibold text-white">Top 3</td><td>Your two cards and the dealer's up card: suited trips 270:1 · straight flush 180:1 · trips 90:1</td><td className="text-right">88.9%</td></tr>
            </tbody></table>
            <p className="mt-1 text-xs text-slate-400">The right-hand column is each side bet's long-run return, worked out exactly for a fresh six-deck shoe. The main game returns about 99.5% with basic strategy.</p>
          </div>
          <p className="rounded-lg border border-amber-300/30 bg-amber-300/5 p-2 text-xs">The Clyde Room is an imagined Glasgow card room, not a real casino. Everything is animated in your browser and paid in virtual money.</p>
          <p className="text-[11px] text-slate-500">Dealer voice: Piper en_GB-alba-medium; player's calls: Piper en_GB-vctk-medium, speaker p241 (both CC-BY 4.0, trained on the VCTK corpus, University of Edinburgh). Croupier and hand: Quaternius Universal Base Characters (CC0).</p>
        </div>
      </Modal>
    </div>,
    document.body,
  );
}

function Badge({ at, text, dealer, active }) {
  return (
    <div className="pointer-events-none absolute z-[5] -translate-x-1/2 -translate-y-1/2" style={{ left: at.x, top: at.y }}>
      <div className={`rounded-full px-2.5 py-0.5 font-cond text-sm font-bold tabular-nums shadow-lg ${dealer ? 'bg-black/75 text-white ring-1 ring-white/30' : active ? 'bg-amber-300 text-amber-950' : 'bg-emerald-900/90 text-white ring-1 ring-amber-200/60'}`}>{text}</div>
    </div>
  );
}
function ActBtn({ label, sub, on, disabled, tone }) {
  return (
    <button type="button" onClick={on} disabled={disabled} className={`flex h-16 flex-col items-center justify-center rounded-2xl ${tone} text-lg font-extrabold shadow-lg ring-1 ring-white/20 active:scale-95 disabled:opacity-35`}>
      {label}<span className="text-[10px] font-medium normal-case text-white/70">{sub}</span>
    </button>
  );
}
