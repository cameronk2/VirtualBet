// Clyde Blackjack: the 3D first-person table. A Glasgow card room at night: green baize with a
// printed layout, padded leather rail, a croupier in waistcoat and shirt sleeves, a chip float, the
// shoe, a lamp over the table, panelled walls, tartan carpet and the river through an arched window.
// Cards, chips and the croupier's hands are animated in code; your own hand makes the hit and
// stand signals. Post-processing: depth of field on the room, gentle bloom, vignette and grain.
import * as THREE from '../../../vendor/three/three.module.js';
import { GLTFLoader } from '../../../vendor/three/GLTFLoader.js';
import { clone as cloneSkinned } from '../../../vendor/three/SkeletonUtils.js';
import { RoomEnvironment } from '../../../vendor/three/RoomEnvironment.js';
import { RoundedBoxGeometry } from '../../../vendor/three/RoundedBoxGeometry.js';
import { EffectComposer } from '../../../vendor/three/EffectComposer.js';
import { RenderPass } from '../../../vendor/three/RenderPass.js';
import { UnrealBloomPass } from '../../../vendor/three/UnrealBloomPass.js';
import { ShaderPass } from '../../../vendor/three/ShaderPass.js';
import { OutputPass } from '../../../vendor/three/OutputPass.js';
import { FELT, CHIPS, canvasTex, carpetTex, cardBack, cardTexture, chipTextures, feltTextures, panelTex, tartan, toChips, windowView } from './textures.js';
import { makeRig } from './rig.js';

const MODELS = typeof __MODELS__ !== 'undefined' ? __MODELS__ : '/models/'; // eslint-disable-line no-undef
const INLINE = (() => { try { return __CROUPIER_URL__; } catch { return null; } })(); // eslint-disable-line no-undef
let asset = null;
function loadModel() {
  if (!asset) {
    if (INLINE) {
      const bin = atob(INLINE.slice(INLINE.indexOf(',') + 1)); const buf = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
      asset = new GLTFLoader().parseAsync(buf.buffer, '');
    } else asset = new GLTFLoader().loadAsync(`${MODELS}croupier.glb`);
    asset.catch(() => { asset = null; });
  }
  return asset;
}

const TAU = Math.PI * 2;
export const TY = 0.76;                       // felt height
const C = new THREE.Vector2(FELT.CX, FELT.CZ); // the dealer's centre point
const R = FELT.R;                             // felt radius
const CARD_W = 0.0635, CARD_H = 0.089;
const CHIP_R = 0.0195, CHIP_T = 0.0034;
const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
const easeOut = (x) => 1 - (1 - x) ** 3;
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const onArc = (a, r) => new THREE.Vector3(C.x - Math.sin(a) * r, TY, C.y + Math.cos(a) * r);

// the five places round the table; the middle one is yours
const SEAT_ANGLES = [0.92, 0.46, 0, -0.46, -0.92];
// side-bet boxes in a row, the main bet's plain white box below them nearest you
const MAIN_R = 0.865, BOX_R = 0.75, BOX = 0.074, MAIN_BOX = 0.1;
function spotLayout() {
  return SEAT_ANGLES.map((a) => {
    const main = onArc(a, MAIN_R);
    const tang = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
    const mid = onArc(a, BOX_R);
    const box = (k, kind) => { const p = mid.clone().addScaledVector(tang, k * (BOX + 0.006)); return { x: p.x, z: p.z, w: BOX, h: BOX, kind }; };
    return { a, rot: a, main, mainBox: { x: main.x, z: main.z, w: MAIN_BOX, h: MAIN_BOX, kind: 'main' }, boxes: [box(-1, 'pp'), box(0, 'top3'), box(1, 't213')] };
  });
}

// ── materials for the croupier and your arm (regions by bind-pose position) ──
function personMaterial(kind) {
  const m = new THREE.MeshPhysicalMaterial({ color: '#ffffff', roughness: 0.6, sheen: 0.25, sheenColor: new THREE.Color('#c8b8a8'), sheenRoughness: 0.7 });
  m.customProgramCacheKey = () => `clyde-${kind}`; // the two variants share source text, so give each its own program
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vBind;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvBind = position;');
    const head = `#include <common>
varying vec3 vBind;
float h1(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }`;
    let body;
    if (kind === 'croupier') {
      body = `#include <color_fragment>
float ax = abs(vBind.x), y = vBind.y, fz = vBind.z;
vec3 skin = vec3(0.5, 0.26, 0.17);
vec3 shirt = vec3(0.93, 0.93, 0.95) * (0.92 + 0.08 * sin(vBind.x * 90.0 + vBind.y * 40.0));
float isHand = step(0.665, ax);
float isNeck = step(1.47, y) * step(ax, 0.2);
float legs = step(y, 0.86);
float vopen = step(1.22, y) * step(ax, (y - 1.22) * 0.55) * step(0.0, fz);
float vest = step(0.86, y) * step(y, 1.47) * step(ax, 0.21) * (1.0 - vopen);
float tie = vopen * step(ax, 0.016) * step(y, 1.46);
float button = vest * step(0.03, fz) * step(ax, 0.008) * step(fract((y - 1.0) * 14.0), 0.18) * step(y, 1.22);
vec3 col = shirt;
col = mix(col, vec3(0.035, 0.035, 0.04), vest);
col = mix(col, vec3(0.45, 0.06, 0.1), tie);
col = mix(col, vec3(0.2), button);
col = mix(col, vec3(0.05, 0.05, 0.06), legs);
col = mix(col, skin, isHand);
col = mix(col, skin, isNeck * (1.0 - tie) * step(1.5, y));
diffuseColor.rgb = col;`;
    } else {
      // your arm: a navy jacket sleeve, a white cuff, then the hand; everything else is hidden
      body = `#include <color_fragment>
float ax = -vBind.x;
if (ax < 0.43 || vBind.y < 1.3) discard;
vec3 col = vec3(0.07, 0.09, 0.16) * (0.9 + 0.1 * sin(vBind.x * 120.0));
col = mix(col, vec3(0.94, 0.94, 0.96), step(0.6, ax));
col = mix(col, vec3(0.5, 0.27, 0.18), step(0.665, ax));
diffuseColor.rgb = col;`;
    }
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', head).replace('#include <color_fragment>', body)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
roughnessFactor = ${kind === 'croupier' ? 'mix(0.55, 0.35, step(0.97, vBind.y) * step(vBind.y, 1.47) * step(abs(vBind.x), 0.21))' : '0.6'};`);
  };
  return m;
}

/** Vignette and film grain, applied last. */
const FinishShader = {
  // a light sharpen and a soft edge darkening; no blur, no grain
  uniforms: { tDiffuse: { value: null }, uTime: { value: 0 }, uVig: { value: 0.22 }, uTexel: { value: new THREE.Vector2(1 / 1024, 1 / 1024) }, uSharp: { value: 0.32 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform float uTime, uVig, uSharp; uniform vec2 uTexel; varying vec2 vUv;
void main(){
  vec4 c = texture2D(tDiffuse, vUv);
  vec3 n = texture2D(tDiffuse, vUv + vec2(0.0, uTexel.y)).rgb + texture2D(tDiffuse, vUv - vec2(0.0, uTexel.y)).rgb
         + texture2D(tDiffuse, vUv + vec2(uTexel.x, 0.0)).rgb + texture2D(tDiffuse, vUv - vec2(uTexel.x, 0.0)).rgb;
  c.rgb = max(c.rgb + (c.rgb * 4.0 - n) * uSharp, 0.0);
  vec2 d = vUv - 0.5; float v = smoothstep(0.85, 0.25, length(d * vec2(1.0, 1.15)));
  c.rgb *= mix(1.0 - uVig, 1.0, v);
  gl_FragColor = c; }`,
};

export async function createTable(canvas, { quality = 'auto', maxFps = 0 } = {}) {
  // the felt and chips are painted with web fonts: give them a moment to arrive first
  try { await Promise.race([Promise.all(['800 40px "Barlow Condensed"', '600 40px Barlow', '700 40px Cinzel'].map((f) => document.fonts.load(f))), new Promise((r) => setTimeout(r, 2500))]); } catch { /* fonts optional */ }
  const cores = navigator.hardwareConcurrency || 4;
  const weak = quality === 'low' || (quality === 'auto' && /Android/.test(navigator.userAgent) && cores <= 4);
  const hd = !weak;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, hd ? 2.5 : 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.68; // a dim card room: the lamp pools on the felt, the room falls away
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#0a0606');
  const pm = new THREE.PMREMGenerator(renderer);
  scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; pm.dispose();
  scene.environmentIntensity = 0.07;
  scene.fog = new THREE.Fog('#120a08', 6, 16);
  const camera = new THREE.PerspectiveCamera(50, 1, 0.08, 30); // a near plane this far out keeps depth precise on phones
  const eye = new THREE.Vector3(0, 1.14, 0.44), look = new THREE.Vector3(0, TY, -0.3);

  // ── lights: a warm lamp over the table, soft fill from the room ──
  scene.add(new THREE.HemisphereLight('#ffe9cc', '#2a120a', 0.08));
  const lamp = new THREE.SpotLight('#ffe7c4', 6.5, 6, 0.6, 0.75, 1.2);
  lamp.position.set(0, 2.55, -0.32); lamp.target.position.set(0, TY, -0.32);
  lamp.castShadow = true; lamp.shadow.mapSize.set(hd ? 2048 : 1024, hd ? 2048 : 1024); lamp.shadow.bias = -0.0002; lamp.shadow.normalBias = 0.01; lamp.shadow.radius = 4;
  scene.add(lamp, lamp.target);
  const key2 = new THREE.SpotLight('#fff4e0', 0.9, 6, 0.5, 0.9, 1.2); key2.position.set(-1.2, 2.2, 1.0); key2.target.position.set(0, TY, -0.6); scene.add(key2, key2.target);
  const rim = new THREE.PointLight('#ffb36b', 0.9, 5, 2); rim.position.set(1.6, 1.8, -1.8); scene.add(rim);

  // ── the room ──
  const room = new THREE.Group(); scene.add(room);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshStandardMaterial({ map: carpetTex(), roughness: 0.95 }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; room.add(floor);
  const wallMat = new THREE.MeshStandardMaterial({ map: panelTex(), roughness: 0.55, metalness: 0.05 });
  const wallUpper = new THREE.MeshStandardMaterial({ color: '#3b1d22', roughness: 0.9 });
  const mkWall = (w, x, z, ry) => {
    const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry;
    const low = new THREE.Mesh(new THREE.PlaneGeometry(w, 1.6), wallMat.clone()); low.material.map = wallMat.map.clone(); low.material.map.needsUpdate = true; low.material.map.repeat.set(w / 2.4, 1); low.position.y = 0.8; g.add(low);
    const up = new THREE.Mesh(new THREE.PlaneGeometry(w, 3.4), wallUpper); up.position.y = 3.3; g.add(up);
    const rail = new THREE.Mesh(new THREE.BoxGeometry(w, 0.08, 0.06), new THREE.MeshStandardMaterial({ color: '#b08a42', metalness: 0.8, roughness: 0.35 })); rail.position.set(0, 1.62, 0.02); g.add(rail);
    room.add(g); return g;
  };
  mkWall(16, 0, -6.5, 0); mkWall(16, -7.5, 0, Math.PI / 2); mkWall(16, 7.5, 0, -Math.PI / 2); mkWall(16, 0, 7.5, Math.PI);
  // the arched window onto the river, set in sandstone
  {
    const win = new THREE.Group(); win.position.set(0, 0, -6.45); room.add(win);
    const view = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 3.1), new THREE.MeshBasicMaterial({ map: windowView(), toneMapped: false, color: new THREE.Color(0.9, 0.9, 0.95) }));
    view.position.set(0, 2.55, -0.05); win.add(view);
    const stone = new THREE.MeshStandardMaterial({ color: '#b59a76', roughness: 0.92 });
    const arch = new THREE.Shape(); arch.moveTo(-2.6, 0.9); arch.lineTo(2.6, 0.9); arch.lineTo(2.6, 4.6); arch.lineTo(-2.6, 4.6); arch.lineTo(-2.6, 0.9);
    const hole = new THREE.Path(); hole.moveTo(-2.0, 1.05); hole.lineTo(2.0, 1.05); hole.lineTo(2.0, 3.0); hole.absarc(0, 3.0, 2.0, 0, Math.PI, false); hole.lineTo(-2.0, 1.05); arch.holes.push(hole);
    const frame = new THREE.Mesh(new THREE.ExtrudeGeometry(arch, { depth: 0.18, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03, bevelSegments: 2 }), stone); frame.position.z = -0.1; win.add(frame);
    const mull = new THREE.MeshStandardMaterial({ color: '#1b120c', roughness: 0.6 });
    for (const x of [-0.7, 0.7]) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.05, 3.6, 0.05), mull); b.position.set(x, 2.8, 0.0); win.add(b); }
    const tb = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.05, 0.05), mull); tb.position.set(0, 2.2, 0); win.add(tb);
  }
  // chandeliers: crystal clusters with warm light
  const crystal = new THREE.MeshStandardMaterial({ color: '#fff6dc', emissive: '#ffcf87', emissiveIntensity: 2.4, roughness: 0.2, metalness: 0.1 });
  for (const [x, z] of [[-2.6, -2.8], [2.6, -2.8], [0, -4.6], [-4.5, 1.5], [4.5, 1.5]]) {
    const g = new THREE.Group(); g.position.set(x, 3.6, z);
    for (let k = 0; k < 26; k++) { const a = (k / 26) * TAU, rr = 0.28 + (k % 3) * 0.12; const m = new THREE.Mesh(new THREE.IcosahedronGeometry(0.03 + (k % 4) * 0.008, 0), crystal); m.position.set(Math.cos(a) * rr, -(k % 5) * 0.09, Math.sin(a) * rr); g.add(m); }
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 12), crystal); g.add(core);
    const l = new THREE.PointLight('#ffcf87', 2.5, 7, 2); l.position.y = -0.2; g.add(l);
    room.add(g);
  }
  // wall lights
  for (let k = -3; k <= 3; k++) {
    if (k === 0) continue;
    const s = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 8), new THREE.MeshStandardMaterial({ color: '#fff', emissive: '#ffb45e', emissiveIntensity: 3 }));
    s.position.set(k * 2.1, 2.1, -6.38); room.add(s);
  }
  // neighbouring tables, slot machines and people in the room (soft in the depth of field)
  const feltFar = new THREE.MeshStandardMaterial({ color: '#1d5a4c', roughness: 0.9 });
  const railFar = new THREE.MeshStandardMaterial({ color: '#2a1410', roughness: 0.5 });
  const personMat = new THREE.MeshStandardMaterial({ color: '#161218', roughness: 0.8 });
  for (const [x, z, ry] of [[-3.3, -2.2, 0.5], [3.4, -2.4, -0.5], [-4.2, 2.6, 2.4], [0.2, -4.4, 0]]) {
    const t = new THREE.Group(); t.position.set(x, 0, z); t.rotation.y = ry;
    const top = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.04, 40, 1, false, -Math.PI / 2, Math.PI), feltFar); top.position.y = TY; t.add(top);
    const rl = new THREE.Mesh(new THREE.TorusGeometry(1.03, 0.05, 10, 40, Math.PI), railFar); rl.rotation.x = Math.PI / 2; rl.rotation.z = Math.PI; rl.position.y = TY + 0.03; t.add(rl);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.95, TY, 30, 1, false, -Math.PI / 2, Math.PI), railFar); base.position.y = TY / 2; t.add(base);
    const l = new THREE.SpotLight('#ffe0b0', 14, 5, 0.6, 0.7, 1.8); l.position.set(0, 2.5, 0.3); l.target.position.set(0, TY, 0.3); t.add(l, l.target);
    for (let p = 0; p < 4; p++) {
      const a = -1 + p * 0.65, guy = new THREE.Group(); guy.position.set(-Math.sin(a) * 1.35, 0, Math.cos(a) * 1.35);
      const b = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 0.55, 4, 8), personMat); b.position.y = 1.05; guy.add(b);
      const hd2 = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 10), new THREE.MeshStandardMaterial({ color: '#6b4a3a', roughness: 0.7 })); hd2.position.y = 1.55; guy.add(hd2);
      if ((p + Math.round(x)) % 2) t.add(guy);
    }
    room.add(t);
  }
  {
    const screen = (seed) => canvasTex(256, 256, (g, w, h) => { const cols = ['#a21caf', '#2563eb', '#dc2626', '#ca8a04', '#059669']; const grd = g.createLinearGradient(0, 0, w, h); grd.addColorStop(0, cols[seed % 5]); grd.addColorStop(1, cols[(seed + 2) % 5]); g.fillStyle = grd; g.fillRect(0, 0, w, h); g.fillStyle = 'rgba(255,255,255,.85)'; for (let i = 0; i < 9; i++) { g.beginPath(); g.arc(40 + (i % 3) * 88, 50 + Math.floor(i / 3) * 70, 24, 0, TAU); g.fill(); } });
    for (let k = 0; k < 9; k++) {
      const m = new THREE.Group(); m.position.set(-7.0, 0, -5 + k * 1.0); m.rotation.y = Math.PI / 2;
      const cab = new THREE.Mesh(new THREE.BoxGeometry(0.75, 1.75, 0.6), new THREE.MeshStandardMaterial({ color: '#141018', roughness: 0.4, metalness: 0.5 })); cab.position.y = 0.88; m.add(cab);
      const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.58, 0.48), new THREE.MeshBasicMaterial({ map: screen(k), toneMapped: false })); scr.position.set(0, 1.25, 0.31); m.add(scr);
      const top = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.18, 0.5), new THREE.MeshStandardMaterial({ color: '#000', emissive: ['#f0abfc', '#93c5fd', '#fde68a'][k % 3], emissiveIntensity: 1.4 })); top.position.y = 1.86; m.add(top);
      room.add(m);
    }
  }

  // ── the table ──
  const spots = spotLayout();
  const felt = feltTextures(spots.map((s) => ({ rot: s.rot, boxes: s.boxes, mainBox: s.mainBox })));
  const shape = new THREE.Shape();
  const DEAL_EDGE = C.y - 0.12;
  shape.moveTo(R, -DEAL_EDGE);
  for (let k = 0; k <= 64; k++) { const a = -Math.PI / 2 + (k / 64) * Math.PI; const p = onArc(a, R); shape.lineTo(p.x, -p.z); }
  shape.lineTo(-R, -DEAL_EDGE); shape.lineTo(R, -DEAL_EDGE);
  const fg = new THREE.ShapeGeometry(shape, 64);
  { const pos = fg.attributes.position, uv = fg.attributes.uv; for (let i = 0; i < pos.count; i++) { const x = pos.getX(i), z = -pos.getY(i); uv.setXY(i, (x + FELT.FX) / (2 * FELT.FX), 1 - (z - FELT.Z0) / (FELT.Z1 - FELT.Z0)); } }
  const feltMat = new THREE.MeshStandardMaterial({ map: felt.map, bumpMap: felt.bump, bumpScale: 0.5, roughness: 0.95 });
  const feltMesh = new THREE.Mesh(fg, feltMat); feltMesh.rotation.x = -Math.PI / 2; feltMesh.position.y = TY; feltMesh.receiveShadow = true; scene.add(feltMesh);
  // body of the table under the felt, the padded rail and the dealer's edge
  const wood = new THREE.MeshPhysicalMaterial({ color: '#4a2412', roughness: 0.35, clearcoat: 0.8, clearcoatRoughness: 0.25 });
  const body = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: 0.09, bevelEnabled: false, curveSegments: 64 }), wood);
  body.rotation.x = -Math.PI / 2; body.position.y = TY - 0.096; body.castShadow = true; body.receiveShadow = true; scene.add(body);
  const railPts = []; for (let k = 0; k <= 80; k++) { const a = -Math.PI / 2 - 0.02 + (k / 80) * (Math.PI + 0.04); railPts.push(onArc(a, R + 0.045).setY(TY + 0.025)); }
  const leather = new THREE.MeshPhysicalMaterial({ color: '#1a0d0b', roughness: 0.45, sheen: 0.6, sheenColor: new THREE.Color('#6b3a2a'), clearcoat: 0.25, clearcoatRoughness: 0.5 });
  const railMesh = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(railPts), 160, 0.058, 20, false), leather);
  railMesh.scale.y = 0.7; railMesh.position.y = (TY + 0.025) * 0.3; railMesh.castShadow = true; railMesh.receiveShadow = true; scene.add(railMesh);
  const brass = new THREE.MeshStandardMaterial({ color: '#c7a25a', metalness: 1, roughness: 0.28 });
  const trimPts = railPts.map((p) => p.clone().setY(TY - 0.012)); const trim = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(trimPts), 160, 0.006, 8, false), brass); scene.add(trim);
  const dEdge = new THREE.Mesh(new THREE.BoxGeometry(2 * R + 0.1, 0.06, 0.12), wood); dEdge.position.set(0, TY - 0.02, DEAL_EDGE - 0.06); scene.add(dEdge);
  // tap targets for your place
  const me = spots[2];
  const pickables = [];
  const addPick = (spot, p, w, h, rot = 0) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ visible: false })); m.rotation.set(-Math.PI / 2, 0, -rot); m.position.copy(p).setY(TY + 0.004); m.userData.spot = spot; scene.add(m); pickables.push(m); };
  addPick('main', me.main, MAIN_BOX, MAIN_BOX, me.rot);
  for (const b of me.boxes) addPick(b.kind, new THREE.Vector3(b.x, TY, b.z), b.w, b.h, me.rot);

  // chip float (the dealer's rack): stacks lying in rows, chip edges painted along them
  {
    const tray = new THREE.Mesh(new RoundedBoxGeometry(0.66, 0.035, 0.16, 3, 0.008), new THREE.MeshPhysicalMaterial({ color: '#0c0c0e', roughness: 0.25, clearcoat: 0.8 }));
    tray.position.set(0, TY + 0.005, DEAL_EDGE + 0.06); tray.receiveShadow = true; scene.add(tray);
    const cols = [3, 3, 3, 2, 2, 2, 2, 1, 1, 1, 1, 0, 0, 0];
    cols.forEach((ci, k) => {
      const c = CHIPS[ci];
      const tex = canvasTex(64, 512, (g, w, h) => { const n = 36; for (let i = 0; i < n; i++) { g.fillStyle = c.col; g.fillRect(0, (i / n) * h, w, h / n - 1.5); g.fillStyle = c.edge; for (let s = 0; s < 4; s++) g.fillRect((s / 4) * w + 3, (i / n) * h, w / 8, h / n - 1.5); g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(0, ((i + 1) / n) * h - 1.5, w, 1.5); } });
      const tube = new THREE.Mesh(new THREE.CylinderGeometry(CHIP_R, CHIP_R, 0.13, 32, 1, true), new THREE.MeshPhysicalMaterial({ map: tex, roughness: 0.4, clearcoat: 0.4 }));
      tube.rotation.x = Math.PI / 2; tube.position.set(-0.3 + k * 0.0435, TY + 0.03, DEAL_EDGE + 0.065); tube.castShadow = true; scene.add(tube);
      const capTex = chipTextures(c).face; const capM = new THREE.MeshPhysicalMaterial({ map: capTex, roughness: 0.35, clearcoat: 0.5 });
      const cap = new THREE.Mesh(new THREE.CircleGeometry(CHIP_R, 32), capM); cap.position.copy(tube.position).add(new THREE.Vector3(0, 0, 0.0651)); scene.add(cap);
    });
  }
  // the shoe (dealer's left = your right) and the discard holder
  const shoePos = new THREE.Vector3(0.46, TY, -0.56);
  {
    const sh = new THREE.Group(); sh.position.copy(shoePos); sh.rotation.y = -0.5; scene.add(sh);
    const glass = new THREE.MeshPhysicalMaterial({ color: '#2b2f3a', roughness: 0.08, metalness: 0.1, clearcoat: 1, transparent: true, opacity: 0.88 });
    const box = new THREE.Mesh(new RoundedBoxGeometry(0.11, 0.09, 0.2, 3, 0.01), glass); box.position.y = 0.045; box.castShadow = true; sh.add(box);
    const deck = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.07, 0.15), new THREE.MeshStandardMaterial({ map: canvasTex(32, 256, (g, w, h) => { g.fillStyle = '#f5f3ea'; g.fillRect(0, 0, w, h); g.fillStyle = 'rgba(0,0,0,.18)'; for (let y = 0; y < h; y += 2) g.fillRect(0, y, w, 0.6); }), roughness: 0.8 }));
    deck.position.set(0, 0.04, -0.01); deck.rotation.x = 0.35; sh.add(deck);
    const lip = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.012, 0.05), new THREE.MeshPhysicalMaterial({ color: '#111', roughness: 0.3 })); lip.position.set(0, 0.006, 0.12); sh.add(lip);
    const top = new THREE.Mesh(new THREE.PlaneGeometry(0.064, 0.09), new THREE.MeshStandardMaterial({ map: cardBack(), transparent: true, alphaTest: 0.5 })); top.rotation.x = -Math.PI / 2 + 0.35; top.position.set(0, 0.078, 0.01); sh.add(top);
  }
  const discardPos = new THREE.Vector3(-0.46, TY, -0.58);
  {
    const d = new THREE.Mesh(new RoundedBoxGeometry(0.09, 0.07, 0.12, 2, 0.006), new THREE.MeshPhysicalMaterial({ color: '#c9d3dc', roughness: 0.05, transmission: 0.0, transparent: true, opacity: 0.35, clearcoat: 1 }));
    d.position.copy(discardPos).setY(TY + 0.035); d.rotation.y = 0.5; scene.add(d);
    const pile = new THREE.Mesh(new THREE.BoxGeometry(0.066, 0.02, 0.091), new THREE.MeshStandardMaterial({ color: '#efece3', roughness: 0.8 })); pile.position.copy(discardPos).setY(TY + 0.012); pile.rotation.y = 0.5; scene.add(pile);
  }
  // the lamp above the table (seen when looking up a little)
  {
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.42, 0.22, 40, 1, true), new THREE.MeshStandardMaterial({ color: '#1d3b2f', side: THREE.DoubleSide, roughness: 0.5, metalness: 0.3 }));
    shade.position.set(0, 2.62, -0.32); scene.add(shade);
    const bulb = new THREE.Mesh(new THREE.CircleGeometry(0.4, 40), new THREE.MeshBasicMaterial({ color: '#fff3d6' })); bulb.rotation.x = Math.PI / 2; bulb.position.set(0, 2.52, -0.32); scene.add(bulb);
  }

  // ── people: the croupier and your arm ──
  const gltf = await loadModel();
  const crou = cloneSkinned(gltf.scene); const crouMat = personMaterial('croupier');
  crou.traverse((o) => { if (o.isMesh) { o.material = o.name === 'Eyes' ? new THREE.MeshStandardMaterial({ color: '#222' }) : o.name === 'Eyebrows' ? new THREE.MeshStandardMaterial({ color: '#2b1a10' }) : crouMat; o.castShadow = true; o.receiveShadow = true; o.frustumCulled = false; } });
  crou.position.set(0, -0.05, DEAL_EDGE - 0.24); scene.add(crou);
  {
    // a plain black dealer's apron, waist to knee, wrapping the front and sides
    const apron = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.235, 0.5, 40, 1, true, -1.45, 2.9),
      new THREE.MeshStandardMaterial({ color: '#0b0b0d', roughness: 0.85, side: THREE.DoubleSide }));
    apron.scale.set(1.05, 1, 0.72); apron.position.set(0, 0.74, 0.0); apron.castShadow = true;
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.203, 0.203, 0.035, 40, 1, true, -1.45, 2.9), new THREE.MeshStandardMaterial({ color: '#1a1a1e', roughness: 0.6, side: THREE.DoubleSide }));
    band.scale.set(1.05, 1, 0.72); band.position.set(0, 0.99, 0.0);
    crou.add(apron, band);
  }
  const cr = makeRig(crou);
  const mine = cloneSkinned(gltf.scene); const armMat = personMaterial('arm');
  mine.traverse((o) => { if (o.isMesh) { if (o.name !== 'Eyes' && o.name !== 'Eyebrows') { o.material = armMat; o.castShadow = false; o.frustumCulled = false; } else o.visible = false; } });
  mine.rotation.y = Math.PI; mine.position.set(0.0, eye.y - 1.64, eye.z + 0.08); scene.add(mine);
  const mineZ = mine.position.z;
  const pr = makeRig(mine);

  // ── cards and chips ──
  const cardGeo = new THREE.PlaneGeometry(CARD_W, CARD_H);
  const backMat = new THREE.MeshPhysicalMaterial({ map: cardBack(), alphaTest: 0.5, roughness: 0.42, sheen: 0.3 });
  // card stock: a slightly off-white satin finish so the faces don't blow out under the lamp
  const cardFace = (card) => new THREE.MeshStandardMaterial({ map: cardTexture(card), color: '#9e9a93', alphaTest: 0.5, roughness: 0.72, envMapIntensity: 0.4 });
  function makeCard(card) {
    const g = new THREE.Group();
    const front = new THREE.Mesh(cardGeo, card ? cardFace(card) : backMat);
    const back = new THREE.Mesh(cardGeo, backMat); back.rotation.y = Math.PI; back.position.z = -0.0004;
    front.castShadow = back.castShadow = true; front.receiveShadow = false; back.receiveShadow = false; // no shadow stripes from the card beneath
    g.add(front, back); g.userData = { card, front, back, flip: Math.PI, yaw: 0, pos: new THREE.Vector3(), lift: 0, stack: 0 };
    scene.add(g); return g;
  }
  const qa = new THREE.Quaternion(), qb = new THREE.Quaternion(), qc = new THREE.Quaternion(), AX = new THREE.Vector3(1, 0, 0), AY = new THREE.Vector3(0, 1, 0);
  function placeCard(g) {
    const u = g.userData;
    // each card in a hand lies a little above the one before, so the newest is always cleanly on top
    g.position.copy(u.pos).setY(u.pos.y + 0.0006 + u.stack * 0.003 + u.lift + Math.abs(Math.sin(u.flip)) * CARD_W * 0.5);
    // a card lying face up shows only its face (no back drawn underneath to flicker through)
    u.back.visible = Math.cos(u.flip) < 0.999 || u.lift > 0;
    qa.setFromAxisAngle(AY, u.yaw); qb.setFromAxisAngle(AX, -Math.PI / 2); qc.setFromAxisAngle(AY, u.flip);
    g.quaternion.copy(qa).multiply(qb).multiply(qc);
  }
  const chipGeo = new THREE.CylinderGeometry(CHIP_R, CHIP_R, CHIP_T, 48);
  function makeChip(c) {
    const t = chipTextures(c);
    const side = new THREE.MeshPhysicalMaterial({ map: t.side, roughness: 0.42, clearcoat: 0.35 });
    const face = new THREE.MeshPhysicalMaterial({ map: t.face, roughness: 0.38, clearcoat: 0.45 });
    const m = new THREE.Mesh(chipGeo, [side, face, face]); m.castShadow = true; m.receiveShadow = true;
    scene.add(m); return m;
  }

  // ── tweens ──
  const tweens = new Set();
  const tween = (dur, fn) => new Promise((res) => { tweens.add({ t0: performance.now(), dur, fn, res }); });

  // ── table state ──
  const stacks = { main: [], pp: [], top3: [], t213: [] };
  const spotPos = (spot) => (spot === 'main' ? me.main.clone() : (() => { const b = me.boxes.find((x) => x.kind === spot); return new THREE.Vector3(b.x, TY, b.z); })());
  const jitter = (i, k) => (Math.sin(i * 12.9 + k * 7.1) * 0.0012);
  const CHIP_UP = Math.PI / 2; // turns a chip so its value reads upright from your seat
  function layStack(spot, list, base) {
    const lift = 0.0012;
    list.forEach((m, i) => { m.position.set(base.x + jitter(i, 1), TY + CHIP_T / 2 + lift + i * CHIP_T, base.z + jitter(i, 2)); m.rotation.y = CHIP_UP + (i === list.length - 1 ? 0.06 : i * 0.7); });
  }
  /** Shows the bets as chip stacks; new chips drop onto their stack. */
  function setBets(b) {
    for (const spot of Object.keys(stacks)) {
      const want = toChips(b[spot] || 0);
      const cur = stacks[spot];
      const same = cur.length === want.length && cur.every((m, i) => m.userData.v === want[i].v);
      if (same) continue;
      const base = spotPos(spot);
      cur.forEach((m) => scene.remove(m));
      stacks[spot] = want.map((c) => { const m = makeChip(c); m.userData.v = c.v; return m; });
      layStack(spot, stacks[spot], base);
      const top = stacks[spot][stacks[spot].length - 1];
      if (top) { const y = top.position.y; tween(220, (k) => { top.position.y = y + 0.05 * (1 - easeOut(k)); }); }
    }
  }
  /** Chips won: the dealer stacks the winnings beside your bet, then both come back to you. */
  async function payOut(spot, amount, stake) {
    const base = spotPos(spot);
    const won = toChips(amount - stake).map((c, i) => { const m = makeChip(c); m.rotation.y = CHIP_UP + i * 0.5; return m; });
    const side = base.clone().add(new THREE.Vector3(0.045, 0, -0.01));
    const from = new THREE.Vector3(0, TY + 0.04, DEAL_EDGE + 0.06);
    reach('R', side.clone().setY(TY + 0.05), 600);
    sfxHook('chips');
    await Promise.all(won.map((m, i) => { m.position.copy(from); const to = new THREE.Vector3(side.x + jitter(i, 3), TY + CHIP_T / 2 + 0.0015 + i * CHIP_T, side.z + jitter(i, 4)); const st = from.clone(); return tween(420 + i * 25, (k) => { const e = ease(k); m.position.lerpVectors(st, to, e); m.position.y += Math.sin(e * Math.PI) * 0.04; }); }));
    await sleep(500);
    const all = [...stacks[spot], ...won]; stacks[spot] = [];
    await Promise.all(all.map((m) => { const st = m.position.clone(); const to = st.clone().add(new THREE.Vector3(0.02, 0, 0.55)); return tween(520, (k) => { m.position.lerpVectors(st, to, ease(k)); }); }));
    all.forEach((m) => scene.remove(m));
  }
  /** Chips lost: swept to the dealer's float. */
  async function collect(spot) {
    const all = stacks[spot]; stacks[spot] = [];
    if (!all.length) return;
    reach('L', all[0].position.clone().setY(TY + 0.05), 700);
    setTimeout(() => sfxHook('collect'), 250);
    const to = new THREE.Vector3(0, TY + 0.03, DEAL_EDGE + 0.06);
    await Promise.all(all.map((m, i) => { const st = m.position.clone(); return tween(560 + i * 10, (k) => { m.position.lerpVectors(st, to, ease(k)); }); }));
    all.forEach((m) => scene.remove(m));
  }
  /** Returns a push / side-bet stake straight back to you. */
  async function returnChips(spot) {
    const all = stacks[spot]; stacks[spot] = [];
    await Promise.all(all.map((m) => { const st = m.position.clone(); const to = st.clone().add(new THREE.Vector3(0, 0, 0.55)); return tween(500, (k) => { m.position.lerpVectors(st, to, ease(k)); }); }));
    all.forEach((m) => scene.remove(m));
  }

  // cards on the table
  const hands = { dealer: [], player: [[]] };
  let handCount = 1;
  function slot(target, hand, i) {
    if (target === 'dealer') { const p = new THREE.Vector3(-0.07 + i * 0.075, TY, -0.44); return { p, yaw: 0 }; }
    const spread = handCount > 1 ? (hand - (handCount - 1) / 2) * 0.16 : 0;
    const base = onArc(0, 0.55).add(new THREE.Vector3(spread, 0, 0));
    // each new card sits up and to the right, leaving the corner number of the cards beneath showing
    return { p: base.add(new THREE.Vector3(0.021 * i, 0, -0.03 * i)), yaw: 0.0 };
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let fast = false;
  /** Deals one card from the shoe to `target` ('dealer' | 'player'), face up or down. */
  async function deal(target, card, { hand = 0, faceUp = true } = {}) {
    const list = target === 'dealer' ? hands.dealer : (hands.player[hand] || (hands.player[hand] = []));
    const i = list.length;
    const g = makeCard(faceUp ? card : null); g.userData.card = card; list.push(g);
    const { p, yaw } = slot(target, hand, i);
    const st = shoePos.clone().add(new THREE.Vector3(-0.04, 0.03, 0.09));
    const u = g.userData; u.pos.copy(st); u.yaw = -0.5; u.flip = Math.PI; u.stack = i; placeCard(g);
    g.renderOrder = i; // later cards draw over earlier ones
    if (u.front.material !== backMat) { u.front.material.polygonOffset = true; u.front.material.polygonOffsetFactor = -1 - i; u.front.material.polygonOffsetUnits = -4 * (i + 1); }
    const dur = fast ? 340 : 520;
    const handTo = (k) => u.pos.clone().setY(TY + 0.03);
    reachFollow('R', handTo, dur * 0.85);
    await tween(dur, (k) => {
      const e = easeOut(k);
      u.pos.lerpVectors(st, p, e); u.lift = Math.sin(k * Math.PI) * 0.012;
      u.yaw = -0.5 + (yaw + 0.5) * e;
      u.flip = faceUp ? Math.PI * (1 - clamp01((k - 0.35) / 0.55)) : Math.PI;
      placeCard(g);
    });
    u.lift = 0; placeCard(g);
    sfxHook('card');
  }
  /** Turns the dealer's hole card over. */
  async function reveal(card) {
    const g = hands.dealer[1]; if (!g) return;
    g.userData.front.material = cardFace(card);
    g.userData.card = card;
    reach('R', g.userData.pos.clone().setY(TY + 0.03), 500);
    await tween(fast ? 300 : 460, (k) => { g.userData.flip = Math.PI * (1 - ease(k)); placeCard(g); });
    sfxHook('flip');
  }
  /** After a split the two hands spread apart. */
  async function split(hand) {
    const list = hands.player[hand]; const moved = list.pop();
    hands.player.splice(hand + 1, 0, [moved]); handCount = hands.player.length;
    await relayout();
  }
  async function relayout() {
    const moves = [];
    hands.player.forEach((list, h) => list.forEach((g, i) => { g.userData.stack = i; g.renderOrder = i; const { p } = slot('player', h, i); const st = g.userData.pos.clone(); moves.push(tween(320, (k) => { g.userData.pos.lerpVectors(st, p, ease(k)); placeCard(g); })); }));
    await Promise.all(moves);
  }
  /** Clears the cards to the discard holder. */
  async function clearCards() {
    const all = [...hands.dealer, ...hands.player.flat()];
    reach('L', new THREE.Vector3(0, TY + 0.04, -0.3), 700);
    await Promise.all(all.map((g, i) => { const st = g.userData.pos.clone(); const f0 = g.userData.flip; return tween(560 + i * 30, (k) => { const e = ease(k); g.userData.pos.lerpVectors(st, discardPos.clone().setY(TY + 0.03), e); g.userData.flip = f0 + (Math.PI - f0) * Math.min(1, e * 2); g.userData.yaw = 0.5 * e; placeCard(g); }); }));
    all.forEach((g) => scene.remove(g));
    hands.dealer = []; hands.player = [[]]; handCount = 1;
  }

  // ── animation of the croupier and your arm ──
  let crouAnim = null; // { side, target(fn), t0, dur }
  function reach(side, target, dur) { crouAnim = { side, target: () => target, t0: performance.now(), dur }; }
  function reachFollow(side, fn, dur) { crouAnim = { side, target: fn, t0: performance.now(), dur }; }
  let myAnim = null; // { kind, t0, dur, res }
  function gesture(kind, slow = 1) {
    return new Promise((res) => { myAnim = { kind, t0: performance.now(), dur: (kind === 'hit' ? 900 : kind === 'stand' ? 1000 : 900) * slow, res, taps: 0 }; });
  }

  const v = (x, y, z) => new THREE.Vector3(x, y, z);
  let sfxHook = () => {};
  function poseCroupier(t, now) {
    cr.reset();
    cr.rotWorld(cr.B.spine_02, AX, 0.12 + Math.sin(t * 1.3) * 0.006);  // leans a little over the table
    cr.rotWorld(cr.B.spine_03, AX, 0.08);
    cr.rotWorld(cr.B.Head, AX, 0.35); cr.rotWorld(cr.B.Head, AY, Math.sin(t * 0.4) * 0.12);
    const restL = v(-0.26 + 0.0, TY + 0.03, DEAL_EDGE + 0.02).add(v(0.5, 0, 0)), restR = v(-0.24, TY + 0.03, DEAL_EDGE + 0.02);
    // croupier's right hand is on your left (he faces you)
    let tR = v(-0.2, TY + 0.03, DEAL_EDGE - 0.0), tL = v(0.2, TY + 0.03, DEAL_EDGE - 0.0);
    if (crouAnim) {
      const k = clamp01((now - crouAnim.t0) / crouAnim.dur);
      const out = k < 0.75 ? ease(k / 0.75) : 1 - ease((k - 0.75) / 0.25);
      const tgt = crouAnim.target(k);
      if (crouAnim.side === 'R') tR = tR.clone().lerp(tgt, out); else tL = tL.clone().lerp(tgt, out);
      if (k >= 1) crouAnim = null;
    }
    void restL; void restR;
    cr.arm('R', tR, v(-0.8, -0.3, -0.6)); cr.handDir('R', v(0.15, -0.6, 1)); cr.fingers('R', { all: 0.35, thumb: 0.2 });
    cr.arm('L', tL, v(0.8, -0.3, -0.6)); cr.handDir('L', v(-0.15, -0.6, 1)); cr.fingers('L', { all: 0.35, thumb: 0.2 });
  }
  function poseMine(now) {
    pr.reset();
    // resting by your side, below the edge of the table and out of view
    const sh = pr.wp(pr.B.upperarm_r);
    let target = sh.clone().add(v(0.08, -0.46, 0.06)), dir = v(0, -1, 0.1), f = { all: 0.5, thumb: 0.3 };
    if (myAnim) {
      const k = clamp01((now - myAnim.t0) / myAnim.dur);
      const inOut = k < 0.25 ? ease(k / 0.25) : k > 0.8 ? 1 - ease((k - 0.8) / 0.2) : 1;
      const over = onArc(0, 0.64).add(v(0.085, 0, 0.0)); // just to the right of your cards
      if (myAnim.kind === 'hit') {
        // two taps on the felt beside the cards with the index finger
        const tap = k > 0.25 && k < 0.8 ? Math.abs(Math.sin(((k - 0.25) / 0.55) * Math.PI * 2)) : 1;
        // a knock on the felt each time the finger lands
        const lands = [0.27, 0.53, 0.79].filter((x) => k >= x).length;
        while (myAnim.taps < lands) { myAnim.taps++; sfxHook('tap'); }
        const p = over.clone().setY(TY + 0.025 + 0.05 * tap);
        target = target.clone().lerp(p, inOut); dir = v(-0.3, -0.6, -1); f = { index: 0.05, middle: 1.4, ring: 1.5, pinky: 1.5, thumb: 0.8 };
      } else if (myAnim.kind === 'stand') {
        // a flat hand waved side to side over the cards
        const sw = k > 0.25 && k < 0.8 ? Math.sin(((k - 0.25) / 0.55) * Math.PI * 3) * 0.06 : 0;
        if (!myAnim.taps && k > 0.25) { myAnim.taps = 1; sfxHook('wave'); }
        const p = over.clone().add(v(sw, 0.08, 0));
        target = target.clone().lerp(p, inOut); dir = v(-0.15, -0.35, -1); f = { all: 0.05, thumb: 0.1 };
      } else if (myAnim.kind === 'double' || myAnim.kind === 'split') {
        // one finger (double) or two (split) pointed at the cards
        const p = over.clone().setY(TY + 0.06);
        target = target.clone().lerp(p, inOut); dir = v(-0.3, -0.45, -1);
        f = myAnim.kind === 'double' ? { index: 0.05, middle: 1.4, ring: 1.5, pinky: 1.5, thumb: 0.8 } : { index: 0.05, middle: 0.05, ring: 1.5, pinky: 1.5, thumb: 0.8 };
      }
      // you lean in towards the table while you signal
      mine.position.z = mineZ - 0.22 * inOut; mine.updateMatrixWorld(true);
      if (k >= 1) { const r = myAnim.res; myAnim = null; r(); }
    } else { mine.position.z = mineZ; mine.updateMatrixWorld(true); }
    pr.arm('R', target, v(0.9, -0.6, 0.2));
    pr.handDir('R', dir);
    pr.fingers('R', f);
  }

  // ── post-processing ──
  // multisampled render target so edges stay crisp through the post-processing chain
  const rt = new THREE.WebGLRenderTarget(1, 1, { type: THREE.HalfFloatType, samples: hd ? 4 : 0 });
  const composer = new EffectComposer(renderer, rt);
  composer.addPass(new RenderPass(scene, camera));
  const bokeh = null; // no depth-of-field blur: everything on the table stays sharp
  const bloom = new UnrealBloomPass(new THREE.Vector2(512, 512), hd ? 0.1 : 0.06, 0.3, 0.97);
  composer.addPass(bloom);
  const finish = new ShaderPass(FinishShader); composer.addPass(finish);
  composer.addPass(new OutputPass());

  let forceFov = 0;
  function resize() {
    const w = canvas.clientWidth || 1, h = canvas.clientHeight || 1;
    renderer.setSize(w, h, false); composer.setSize(w, h);
    const pr2 = renderer.getPixelRatio(); finish.uniforms.uTexel.value.set(1 / (w * pr2), 1 / (h * pr2));
    const a = w / h; camera.aspect = a;
    camera.fov = forceFov || (a < 0.75 ? 56 : a < 1.2 ? 50 : 42);
    camera.updateProjectionMatrix();
  }
  // Where you look: down at your chips while betting, up at the cards while the hand plays
  // (portrait screens; wider screens see both from one place). The view eases between the two.
  const VIEWS = {
    portrait: { bets: [v(0, 1.22, 0.46), v(0, TY, 0.1)], cards: [v(0, 1.2, 0.3), v(0, TY, -0.38)] },
    wide: { bets: [v(0, 1.2, 0.5), v(0, TY, -0.1)], cards: [v(0, 1.12, 0.26), v(0, TY, -0.36)] },
  };
  let focus = 'bets';
  const camLook = look.clone();
  function viewTarget() {
    if (forceFov) return [eye, look];
    return VIEWS[camera.aspect < 0.75 ? 'portrait' : 'wide'][focus];
  }
  function stepCamera(k) {
    const [e, l] = viewTarget();
    camera.position.lerp(e, k); camLook.lerp(l, k);
    camera.lookAt(camLook);
    if (bokeh) bokeh.uniforms.focus.value = camera.position.distanceTo(camLook);
  }
  resize(); stepCamera(1);

  // ── loop ──
  let raf = 0, alive = true; const t0 = performance.now();
  let breathe = 0;
  let lastDraw = 0;
  function frame(now) {
    if (!alive) return;
    if (maxFps && now - lastDraw < 1000 / maxFps) { raf = requestAnimationFrame(frame); return; }
    lastDraw = now;
    const t = (now - t0) / 1000;
    for (const tw of [...tweens]) { const k = clamp01((now - tw.t0) / tw.dur); tw.fn(k); if (k >= 1) { tweens.delete(tw); tw.res(); } }
    poseCroupier(t, now); poseMine(now);
    // a seated player's eye moves a little
    breathe = Math.sin(t * 0.9) * 0.004;
    stepCamera(0.045); camera.position.y += breathe * 0.05;
    finish.uniforms.uTime.value = t;
    composer.render();
    raf = requestAnimationFrame(frame);
  }
  let glow = false;
  raf = requestAnimationFrame(frame);

  // ── input and HUD helpers ──
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function pick(clientX, clientY) {
    const r = canvas.getBoundingClientRect();
    ndc.set(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    const hit = ray.intersectObjects(pickables, false)[0];
    return hit ? hit.object.userData.spot : null;
  }
  /** Screen position (CSS px within the canvas) of a hand's cards, for the totals. */
  function screenOf(target, hand = 0) {
    const list = target === 'dealer' ? hands.dealer : hands.player[hand] || [];
    const p = list.length ? list[list.length - 1].userData.pos.clone() : (target === 'dealer' ? slot('dealer', 0, 0).p : slot('player', hand, 0).p);
    p.y += 0.02; if (target !== 'dealer') p.z += 0.07; else p.z -= 0.06;
    const s = p.project(camera);
    return { x: (s.x + 1) / 2 * canvas.clientWidth, y: (1 - s.y) / 2 * canvas.clientHeight };
  }

  return {
    resize, setBets, deal, reveal, split, clearCards, payOut, collect, returnChips, gesture, pick, screenOf,
    setGlow(on) { glow = on; }, setFast(on) { fast = on; }, onSfx(fn) { sfxHook = fn; },
    get handCount() { return handCount; },
    /** Test hook: move the seat's view (eye, look, fov) and redraw. */
    _view(e, l, fov) { eye.set(...e); look.set(...l); forceFov = fov; resize(); stepCamera(1); },
    setFocus(f, instant = false) { focus = f === 'cards' ? 'cards' : 'bets'; if (instant) stepCamera(1); },
    dispose() { alive = false; cancelAnimationFrame(raf); scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); composer.dispose?.(); renderer.dispose(); },
  };
}
