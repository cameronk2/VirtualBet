// Clyde Blackjack audio (client/audio/clyde, made by tools/music/clyde.py with free tools): a quiet
// lounge loop, one effects sprite and one dealer-voice sprite. The dealer is the Piper "alba" voice
// (CC-BY 4.0, trained on the VCTK corpus: a Scottish speaker). Falls back to synthesised effects.
import { playSprite, playVoiceSprite, preloadUrls, registerTracks, registerVoiceGame, themeSfx } from '../../lib/sound.js';
import { SFX, VOICE } from './sprites.js';

const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
// the single-file build inlines these three files (it has no room for more published files)
const INLINE = typeof __CLYDE_AUDIO__ !== 'undefined' ? __CLYDE_AUDIO__ : null;
const au = (f) => (INLINE ? INLINE[f] || null : AUD.files.includes(`clyde/${f}.mp3`) ? `${AUD.base}clyde/${f}.mp3` : null);
if (au('music/base')) registerTracks('clyde', { base: au('music/base') });
const SFX_URL = au('sfx'), VOICE_URL = au('voice');
if (VOICE_URL) registerVoiceGame('clyde');

const synth = themeSfx('blackjack');
const FALLBACK = { deal: () => synth.click(), deal2: () => synth.click(), flip: () => synth.click(), chip: () => synth.coin(), chips: () => synth.coin(), collect: () => synth.click(), win: () => synth.win(1), bj: () => synth.win(2) };
const ALIAS = { card: 'deal' };
export function sfx(name, opts) {
  name = ALIAS[name] || name;
  const clip = SFX[name];
  if (SFX_URL && clip) return playSprite(SFX_URL, clip, opts);
  FALLBACK[name]?.(); return false;
}
let busyUntil = 0, queued = null;
/** A voice line. `name` may have numbered takes (name_1, name_2…); one is chosen at random.
 *  Dealer lines never talk over each other: one arriving while she is still speaking waits its turn
 *  (only the latest waits; anything older is dropped). Your own calls (p_…) play at once. */
export function say(name, opts) {
  if (!VOICE_URL) return false;
  const takes = Object.keys(VOICE).filter((k) => k === name || new RegExp(`^${name}_\\d+$`).test(k));
  if (!takes.length) return false;
  const clip = VOICE[takes[Math.floor(Math.random() * takes.length)]];
  const now = performance.now();
  if (name.startsWith('p_')) return playVoiceSprite(VOICE_URL, clip, opts);
  if (now < busyUntil) {
    clearTimeout(queued);
    queued = setTimeout(() => { queued = null; say(name, opts); }, busyUntil - now + 120);
    return true;
  }
  busyUntil = now + clip[1] * 1000;
  return playVoiceSprite(VOICE_URL, clip, opts);
}
export function preloadClyde() { preloadUrls([SFX_URL, VOICE_URL]); }
