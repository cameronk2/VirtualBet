// Clyde Blackjack textures, all painted in code: the printed felt, cards (tartan backs), casino
// chips, the tartan carpet, oak panelling and the night view of the Clyde through the window.
import * as THREE from '../../../vendor/three/three.module.js';

const TAU = Math.PI * 2;
export function canvasTex(w, h, draw, { srgb = true, repeat, aniso = 8 } = {}) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  t.anisotropy = aniso;
  return t;
}
const rnd = (s) => () => ((s = (s * 16807) % 2147483647) / 2147483647);

// ── the felt: a planar map over x ∈ [-FX, FX], z ∈ [Z0, Z1] ─────────────────
export const FELT = { FX: 1.08, Z0: -0.84, Z1: 0.34, CX: 0, CZ: -0.74, R: 1.0 };
const FELT_COL = '#1d5a4c';
/** Felt image: colour, printed lines and words, the player's betting boxes. Also returns a bump map. */
export function feltTextures(spots) {
  const W = 2048, H = Math.round(W * (FELT.Z1 - FELT.Z0) / (2 * FELT.FX));
  const px = (x) => ((x + FELT.FX) / (2 * FELT.FX)) * W, pz = (z) => ((z - FELT.Z0) / (FELT.Z1 - FELT.Z0)) * H;
  const m = W / (2 * FELT.FX); // px per metre
  const map = canvasTex(W, H, (g) => {
    g.fillStyle = FELT_COL; g.fillRect(0, 0, W, H);
    // soft lamp pool and fibre mottling
    const pool = g.createRadialGradient(px(0), pz(-0.25), 50, px(0), pz(-0.25), W * 0.6); pool.addColorStop(0, 'rgba(255,255,230,.06)'); pool.addColorStop(1, 'rgba(0,0,0,.18)'); g.fillStyle = pool; g.fillRect(0, 0, W, H);
    const r = rnd(11);
    for (let i = 0; i < 26000; i++) { g.fillStyle = `rgba(${r() < 0.5 ? '255,255,255' : '0,0,0'},${r() * 0.035})`; g.fillRect(r() * W, r() * H, 1 + r() * 2, 1 + r() * 2); }
    const cx = px(FELT.CX), cz = pz(FELT.CZ);
    g.strokeStyle = 'rgba(245,245,235,.92)'; g.fillStyle = 'rgba(245,245,235,.92)';
    // arc text helper (text centred on angle a0, along a circle of radius rr around the dealer)
    const arcText = (text, rr, a0, size, colour, weight = 800, font = 'Barlow Condensed, Arial Narrow, sans-serif', spacing = 1.0) => {
      g.save(); g.font = `${weight} ${size}px ${font}`; g.fillStyle = colour;
      const widths = [...text].map((ch) => g.measureText(ch).width * spacing);
      const total = widths.reduce((a, b) => a + b, 0);
      let a = a0 + total / 2 / rr;
      for (let i = 0; i < text.length; i++) {
        const w = widths[i];
        a -= (w / 2) / rr;
        g.save(); g.translate(cx + Math.sin(a) * rr * -1, cz + Math.cos(a) * rr); g.rotate(a); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text[i], 0, 0); g.restore();
        a -= (w / 2) / rr;
      }
      g.restore();
    };
    arcText('BLACKJACK PAYS 3 TO 2', 0.43 * m, 0, 0.036 * m, '#d23a2e', 800, 'Barlow Condensed, Arial Narrow, sans-serif', 1.02);
    arcText('Dealer must stand on all 17s and must draw to 16', 0.515 * m, 0, 0.019 * m, 'rgba(245,245,235,.95)', 600, 'Barlow, Arial, sans-serif');
    arcText('INSURANCE PAYS 2 TO 1', 0.59 * m, 0, 0.028 * m, '#d23a2e', 800);
    // the table's name and a thistle near the dealer
    g.save(); g.translate(cx, cz + 0.2 * m); g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = `700 ${0.032 * m}px Cinzel, Georgia, serif`; g.fillStyle = 'rgba(232,206,140,.85)'; g.fillText('THE CLYDE ROOM', 0, 0);
    g.font = `600 ${0.018 * m}px Barlow, Arial, sans-serif`; g.fillStyle = 'rgba(232,206,140,.7)'; g.fillText('GLASGOW', 0, 0.03 * m);
    // thistle emblem
    const t = 0.028 * m; g.translate(0, -0.055 * m); g.strokeStyle = 'rgba(232,206,140,.8)'; g.lineWidth = 3;
    g.beginPath(); g.moveTo(0, t * 1.3); g.lineTo(0, t * 0.1); g.stroke();
    g.beginPath(); g.ellipse(0, -t * 0.05, t * 0.45, t * 0.35, 0, 0, TAU); g.stroke();
    for (let k = -3; k <= 3; k++) { g.beginPath(); g.moveTo(k * t * 0.12, -t * 0.3); g.lineTo(k * t * 0.2, -t * 0.95); g.stroke(); }
    g.beginPath(); g.moveTo(0, t * 0.8); g.quadraticCurveTo(-t * 0.8, t * 0.5, -t * 0.9, t * 0.9); g.moveTo(0, t * 0.8); g.quadraticCurveTo(t * 0.8, t * 0.5, t * 0.9, t * 0.9); g.stroke();
    g.restore();
    // the player positions around the arc: a row of side-bet boxes and the main bet box for each
    const lineW = Math.max(3, 0.004 * m);
    for (const sp of spots) {
      g.lineWidth = lineW; g.strokeStyle = 'rgba(245,245,235,.9)';
      // side-bet boxes: Pairs (card icons), Top 3, 21+3 ("3")
      // the main bet: an empty white box
      { const b = sp.mainBox; g.save(); g.translate(px(b.x), pz(b.z)); g.rotate(sp.rot); g.lineWidth = lineW * 1.2; g.strokeRect(-b.w * m / 2, -b.h * m / 2, b.w * m, b.h * m); g.restore(); }
      for (const b of sp.boxes) {
        const x0 = px(b.x - b.w / 2), z0 = pz(b.z - b.h / 2);
        g.save(); g.translate(px(b.x), pz(b.z)); g.rotate(sp.rot); g.translate(-px(b.x), -pz(b.z));
        g.strokeRect(x0, z0, b.w * m, b.h * m);
        const ccx = px(b.x), ccz = pz(b.z);
        if (b.kind === 'pp') {
          for (let k = 0; k < 3; k++) {
            g.save(); g.translate(ccx + (k - 1) * b.w * m * 0.18, ccz + (k - 1) * b.h * m * 0.06); g.rotate((k - 1) * 0.35);
            g.fillStyle = 'rgba(245,245,235,.9)'; g.strokeStyle = 'rgba(245,245,235,.9)'; g.lineWidth = 2;
            g.strokeRect(-b.w * m * 0.13, -b.h * m * 0.2, b.w * m * 0.26, b.h * m * 0.38);
            g.fillStyle = k === 1 ? '#d23a2e' : 'rgba(245,245,235,.95)'; g.font = `700 ${b.h * m * 0.22}px Arial`; g.textAlign = 'center'; g.textBaseline = 'middle';
            g.fillText(['♣', '♥', '♠'][k], 0, 0);
            g.restore();
          }
        } else {
          g.fillStyle = 'rgba(245,245,235,.95)'; g.textAlign = 'center'; g.textBaseline = 'middle';
          if (b.kind === 'top3') { g.font = `500 ${b.h * m * 0.3}px Barlow Condensed, Arial Narrow, sans-serif`; g.fillText('TOP', ccx, ccz - b.h * m * 0.17); g.font = `500 ${b.h * m * 0.4}px Barlow, Arial, sans-serif`; g.fillText('3', ccx, ccz + b.h * m * 0.2); }
          else { g.font = `700 ${b.h * m * 0.72}px Barlow, Arial, sans-serif`; g.fillText('3', ccx, ccz + b.h * m * 0.04); }
        }
        g.restore();
      }
    }
    // the edge of the playing area
    g.lineWidth = lineW; g.strokeStyle = 'rgba(245,245,235,.55)';
    g.beginPath(); g.arc(cx, cz, 0.94 * m, 0.1, Math.PI - 0.1); g.stroke();
  }, { aniso: 16 });
  const bump = canvasTex(1024, 1024, (g, w, h) => {
    g.fillStyle = '#808080'; g.fillRect(0, 0, w, h);
    const r = rnd(5);
    for (let i = 0; i < 90000; i++) { const v = 100 + r() * 60; g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(r() * w, r() * h, 1, 1 + r() * 2); }
  }, { srgb: false, repeat: [10, 6], aniso: 8 });
  return { map, bump };
}

// ── cards ─────────────────────────────────────────────────────────────────
const SUIT = { S: '♠', H: '♥', D: '♦', C: '♣' };
const RED = { H: true, D: true };
const PIPS = { // [x, y] in a 0..1 box, y down
  A: [[0.5, 0.5]], 2: [[0.5, 0.2], [0.5, 0.8]], 3: [[0.5, 0.2], [0.5, 0.5], [0.5, 0.8]],
  4: [[0.3, 0.2], [0.7, 0.2], [0.3, 0.8], [0.7, 0.8]], 5: [[0.3, 0.2], [0.7, 0.2], [0.5, 0.5], [0.3, 0.8], [0.7, 0.8]],
  6: [[0.3, 0.2], [0.7, 0.2], [0.3, 0.5], [0.7, 0.5], [0.3, 0.8], [0.7, 0.8]],
  7: [[0.3, 0.2], [0.7, 0.2], [0.5, 0.35], [0.3, 0.5], [0.7, 0.5], [0.3, 0.8], [0.7, 0.8]],
  8: [[0.3, 0.2], [0.7, 0.2], [0.5, 0.35], [0.3, 0.5], [0.7, 0.5], [0.5, 0.65], [0.3, 0.8], [0.7, 0.8]],
  9: [[0.3, 0.18], [0.7, 0.18], [0.3, 0.39], [0.7, 0.39], [0.5, 0.5], [0.3, 0.61], [0.7, 0.61], [0.3, 0.82], [0.7, 0.82]],
  10: [[0.3, 0.18], [0.7, 0.18], [0.5, 0.29], [0.3, 0.4], [0.7, 0.4], [0.3, 0.6], [0.7, 0.6], [0.5, 0.71], [0.3, 0.82], [0.7, 0.82]],
};
const roundRect = (g, x, y, w, h, r) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };
const CW = 400, CH = 560;
function courtFigure(g, rank, suit, x, y, w, h) {
  // a simple, original court card: a framed panel with a crowned bust, mirrored top and bottom
  const red = RED[suit];
  const ink = red ? '#c8102e' : '#141414';
  g.save(); g.fillStyle = '#f6e7a8'; g.fillRect(x, y, w, h); g.strokeStyle = ink; g.lineWidth = 3; g.strokeRect(x, y, w, h);
  const half = (flip) => {
    g.save(); if (flip) { g.translate(x + w, y + h); g.rotate(Math.PI); g.translate(-x, -y); }
    const cx = x + w / 2, top = y + h * 0.05;
    const robe = rank === 'K' ? '#1e40af' : rank === 'Q' ? '#b91c1c' : '#15803d';
    g.fillStyle = robe; g.beginPath(); g.moveTo(x + w * 0.12, y + h * 0.5); g.quadraticCurveTo(cx, top + h * 0.2, x + w * 0.88, y + h * 0.5); g.closePath(); g.fill();
    g.fillStyle = '#e8c39e'; g.beginPath(); g.arc(cx, top + h * 0.16, w * 0.13, 0, TAU); g.fill();
    g.fillStyle = '#facc15'; g.beginPath(); // crown / cap
    if (rank === 'J') { g.ellipse(cx, top + h * 0.06, w * 0.16, h * 0.04, 0, Math.PI, TAU); }
    else { g.moveTo(cx - w * 0.15, top + h * 0.08); for (let k = 0; k <= 4; k++) g.lineTo(cx - w * 0.15 + k * w * 0.075, top + (k % 2 ? h * 0.0 : h * 0.03)); g.lineTo(cx + w * 0.15, top + h * 0.08); }
    g.closePath(); g.fill();
    g.strokeStyle = '#7a5a10'; g.lineWidth = 2; g.stroke();
    g.fillStyle = '#facc15'; g.fillRect(x + w * 0.2, y + h * 0.4, w * 0.6, h * 0.03);
    g.fillStyle = ink; g.font = `700 ${w * 0.18}px Georgia, serif`; g.textAlign = 'center'; g.fillText(SUIT[suit], x + w * 0.22, y + h * 0.32);
    g.restore();
  };
  half(false); half(true);
  g.strokeStyle = ink; g.lineWidth = 2; g.beginPath(); g.moveTo(x + 6, y + h / 2); g.lineTo(x + w - 6, y + h / 2); g.stroke();
  g.restore();
}
const cardCache = new Map();
export function cardTexture(card) {
  if (cardCache.has(card)) return cardCache.get(card);
  const rank = card.slice(0, -1), suit = card.slice(-1);
  const ink = RED[suit] ? '#c8102e' : '#141414';
  const t = canvasTex(CW, CH, (g) => {
    g.clearRect(0, 0, CW, CH);
    roundRect(g, 2, 2, CW - 4, CH - 4, 26); g.fillStyle = '#fbfaf6'; g.fill();
    g.strokeStyle = 'rgba(0,0,0,.12)'; g.lineWidth = 2; g.stroke();
    // UK casino style: big corner indices on a pale panel
    const corner = (flip) => {
      g.save(); if (flip) { g.translate(CW, CH); g.rotate(Math.PI); }
      g.fillStyle = ink; g.textAlign = 'center'; g.textBaseline = 'top';
      g.font = `700 ${rank === '10' ? 74 : 86}px Georgia, 'Times New Roman', serif`; g.fillText(rank, 56, 22);
      g.font = '700 64px Georgia, serif'; g.fillText(SUIT[suit], 56, 112);
      g.restore();
    };
    corner(false); corner(true);
    const bx = 104, by = 60, bw = CW - 208, bh = CH - 120;
    if (['J', 'Q', 'K'].includes(rank)) courtFigure(g, rank, suit, bx, by, bw, bh);
    else {
      g.fillStyle = '#f3ecd0'; g.fillRect(bx, by, bw, bh);
      g.fillStyle = ink; g.textAlign = 'center'; g.textBaseline = 'middle';
      const big = rank === 'A';
      g.font = `${big ? 170 : 84}px Georgia, serif`;
      for (const [u, v] of PIPS[rank]) {
        g.save(); g.translate(bx + u * bw, by + v * bh); if (v > 0.55) g.rotate(Math.PI); g.fillText(SUIT[suit], 0, 4); g.restore();
      }
    }
  }, { aniso: 16 });
  t.generateMipmaps = true; t.minFilter = THREE.LinearMipmapLinearFilter;
  cardCache.set(card, t);
  return t;
}
let backTex = null;
export function cardBack() {
  if (backTex) return backTex;
  backTex = canvasTex(CW, CH, (g) => {
    g.clearRect(0, 0, CW, CH);
    roundRect(g, 2, 2, CW - 4, CH - 4, 26); g.fillStyle = '#fbfaf6'; g.fill();
    g.save(); roundRect(g, 22, 22, CW - 44, CH - 44, 14); g.clip();
    tartan(g, CW, CH, 0.55);
    g.restore();
    g.strokeStyle = '#fbfaf6'; g.lineWidth = 6; roundRect(g, 22, 22, CW - 44, CH - 44, 14); g.stroke();
    // a small thistle medallion
    g.fillStyle = 'rgba(251,250,246,.92)'; g.beginPath(); g.arc(CW / 2, CH / 2, 46, 0, TAU); g.fill();
    g.fillStyle = '#7c2d6b'; g.beginPath(); g.ellipse(CW / 2, CH / 2 - 8, 16, 18, 0, 0, TAU); g.fill();
    g.fillStyle = '#166534'; g.fillRect(CW / 2 - 3, CH / 2 + 6, 6, 24); g.beginPath(); g.ellipse(CW / 2, CH / 2 + 12, 22, 8, 0, 0, TAU); g.fill();
  }, { aniso: 16 });
  return backTex;
}
/** A red tartan sett (original colours) painted into the given box. */
export function tartan(g, w, h, scale = 1, cols = { base: '#9b111e', dark: '#1a3a2a', navy: '#14213d', line: '#e8d27a', white: '#f2efe6' }) {
  g.fillStyle = cols.base; g.fillRect(0, 0, w, h);
  const s = 160 * scale;
  const bands = [[0, 0.22, cols.dark, 0.9], [0.3, 0.12, cols.navy, 0.85], [0.47, 0.025, cols.line, 0.9], [0.62, 0.12, cols.navy, 0.85], [0.8, 0.015, cols.white, 0.8]];
  for (let o = -s; o < Math.max(w, h) + s; o += s) {
    for (const [p, wd, c, a] of bands) {
      g.globalAlpha = a * 0.55; g.fillStyle = c;
      g.fillRect(o + p * s, 0, wd * s, h); g.fillRect(0, o + p * s, w, wd * s);
    }
  }
  g.globalAlpha = 1;
  // twill texture
  g.strokeStyle = 'rgba(0,0,0,.08)'; g.lineWidth = 1;
  for (let k = -h; k < w; k += 4) { g.beginPath(); g.moveTo(k, 0); g.lineTo(k + h, h); g.stroke(); }
}

// ── chips ─────────────────────────────────────────────────────────────────
export const CHIPS = [
  { v: 10, label: '10p', col: '#e8e4da', edge: '#2563eb', ink: '#1e3a8a' },
  { v: 50, label: '50p', col: '#2563eb', edge: '#f8fafc', ink: '#f8fafc' },
  { v: 100, label: '£1', col: '#e2e8f0', edge: '#0f172a', ink: '#0f172a' },
  { v: 500, label: '£5', col: '#c81e1e', edge: '#f8fafc', ink: '#f8fafc' },
  { v: 1000, label: '£10', col: '#e7a2a9', edge: '#1f2937', ink: '#3b0712' },
  { v: 2500, label: '£25', col: '#15803d', edge: '#f8fafc', ink: '#f8fafc' },
  { v: 10000, label: '£100', col: '#111827', edge: '#f59e0b', ink: '#fbbf24' },
];
const chipCache = new Map();
export function chipTextures(c) {
  if (chipCache.has(c.v)) return chipCache.get(c.v);
  const face = canvasTex(256, 256, (g) => {
    g.fillStyle = c.col; g.beginPath(); g.arc(128, 128, 128, 0, TAU); g.fill();
    // edge spots
    g.fillStyle = c.edge; for (let k = 0; k < 8; k++) { g.save(); g.translate(128, 128); g.rotate((k / 8) * TAU); g.fillRect(-14, -128, 28, 26); g.restore(); }
    g.strokeStyle = c.edge; g.lineWidth = 5; g.beginPath(); g.arc(128, 128, 84, 0, TAU); g.stroke();
    g.fillStyle = 'rgba(255,255,255,.12)'; g.beginPath(); g.arc(128, 128, 80, 0, TAU); g.fill();
    g.fillStyle = c.ink; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = `800 ${c.label.length > 3 ? 50 : 62}px Barlow, Arial, sans-serif`; g.fillText(c.label, 128, 120);
    g.font = '700 18px Cinzel, Georgia, serif'; g.fillText('CLYDE', 128, 166);
    g.save(); g.translate(128, 128); g.font = '700 15px Barlow, Arial'; for (let k = 0; k < 4; k++) { g.rotate(TAU / 4); g.fillText('GLASGOW', 0, -100); } g.restore();
  }, { aniso: 8 });
  const side = canvasTex(256, 16, (g, w, h) => {
    g.fillStyle = c.col; g.fillRect(0, 0, w, h);
    g.fillStyle = c.edge; for (let k = 0; k < 8; k++) g.fillRect((k / 8) * w + 2, 0, w / 8 * 0.45, h);
  }, { aniso: 4 });
  const out = { face, side };
  chipCache.set(c.v, out);
  return out;
}
/** Splits an amount into chips, largest first. */
export function toChips(amount) {
  const out = []; let left = amount;
  for (const c of [...CHIPS].reverse()) { while (left >= c.v && out.length < 30) { out.push(c); left -= c.v; } }
  return out;
}

// ── the room ──────────────────────────────────────────────────────────────
export function carpetTex() {
  return canvasTex(1024, 1024, (g, w, h) => {
    tartan(g, w, h, 1.5, { base: '#5b0f1a', dark: '#1d2a20', navy: '#16203a', line: '#b8963e', white: '#cfc6b0' });
    const r = rnd(3); for (let i = 0; i < 40000; i++) { g.fillStyle = `rgba(0,0,0,${r() * 0.12})`; g.fillRect(r() * w, r() * h, 2, 2); }
  }, { repeat: [14, 14], aniso: 8 });
}
export function panelTex() {
  return canvasTex(1024, 512, (g, w, h) => {
    const grd = g.createLinearGradient(0, 0, 0, h); grd.addColorStop(0, '#3a2214'); grd.addColorStop(1, '#22130b'); g.fillStyle = grd; g.fillRect(0, 0, w, h);
    const r = rnd(8);
    for (let i = 0; i < 400; i++) { g.strokeStyle = `rgba(${r() < 0.5 ? '90,55,30' : '20,10,5'},${0.2 + r() * 0.3})`; g.lineWidth = 1 + r() * 2; const y = r() * h; g.beginPath(); g.moveTo(0, y); g.bezierCurveTo(w * 0.3, y + (r() - 0.5) * 20, w * 0.6, y + (r() - 0.5) * 20, w, y + (r() - 0.5) * 10); g.stroke(); }
    // raised panels with gilt mouldings
    for (let k = 0; k < 4; k++) { const x = 24 + k * (w / 4); g.strokeStyle = 'rgba(214,176,92,.55)'; g.lineWidth = 4; g.strokeRect(x, 40, w / 4 - 48, h - 80); g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 3; g.strokeRect(x + 8, 48, w / 4 - 64, h - 96); }
  }, { repeat: [6, 1], aniso: 8 });
}
/** The night view through the arched window: the river, the cantilever crane, a bow bridge and city lights. */
export function windowView() {
  return canvasTex(2048, 1024, (g, w, h) => {
    const sky = g.createLinearGradient(0, 0, 0, h * 0.62); sky.addColorStop(0, '#070b1c'); sky.addColorStop(0.7, '#1b2347'); sky.addColorStop(1, '#3a2e4a'); g.fillStyle = sky; g.fillRect(0, 0, w, h);
    const r = rnd(21);
    for (let i = 0; i < 160; i++) { g.fillStyle = `rgba(255,255,255,${0.3 + r() * 0.6})`; g.fillRect(r() * w, r() * h * 0.4, 1.5, 1.5); }
    const horizon = h * 0.62;
    // skyline
    g.fillStyle = '#0b0f1e';
    let x = 0; while (x < w) { const bw = 40 + r() * 120, bh = 60 + r() * 220; g.fillRect(x, horizon - bh, bw, bh); x += bw + 4; }
    for (let i = 0; i < 1400; i++) { const wx = r() * w, wy = horizon - r() * 260; g.fillStyle = `rgba(255,${200 + r() * 40},${120 + r() * 60},${r() * 0.7})`; g.fillRect(wx, wy, 3, 4); }
    // a domed concert hall shell (armadillo-like plates)
    g.fillStyle = '#9aa3b5'; for (let k = 0; k < 6; k++) { g.beginPath(); g.ellipse(w * 0.32 + k * 34, horizon - 10, 180 - k * 22, 90 - k * 10, 0, Math.PI, TAU); g.fill(); g.fillStyle = k % 2 ? '#8a93a6' : '#aab3c4'; }
    // the cantilever crane
    g.strokeStyle = '#111827'; g.fillStyle = '#111827'; g.lineWidth = 6;
    const cx = w * 0.68; g.fillRect(cx - 18, horizon - 330, 36, 330);
    g.fillRect(cx - 260, horizon - 360, 520, 28); g.fillRect(cx - 40, horizon - 400, 80, 40);
    for (let k = -260; k < 260; k += 26) { g.beginPath(); g.moveTo(cx + k, horizon - 332); g.lineTo(cx + k + 13, horizon - 360); g.stroke(); }
    g.fillStyle = 'rgba(250,204,21,.9)'; for (let k = -250; k < 260; k += 40) g.fillRect(cx + k, horizon - 364, 4, 4);
    // a bow-string bridge
    g.strokeStyle = '#e5e7eb'; g.lineWidth = 5; g.beginPath(); g.moveTo(w * 0.08, horizon + 8); g.quadraticCurveTo(w * 0.2, horizon - 160, w * 0.32, horizon + 8); g.stroke();
    g.lineWidth = 2; for (let k = 1; k < 14; k++) { const t = k / 14, bx = w * 0.08 + t * w * 0.24, by = horizon + 8 - Math.sin(t * Math.PI) * 84; g.beginPath(); g.moveTo(bx, by); g.lineTo(bx, horizon + 8); g.stroke(); }
    g.fillStyle = '#1f2937'; g.fillRect(w * 0.06, horizon + 6, w * 0.28, 8);
    // the river with reflected lights
    const rv = g.createLinearGradient(0, horizon, 0, h); rv.addColorStop(0, '#141a33'); rv.addColorStop(1, '#05070f'); g.fillStyle = rv; g.fillRect(0, horizon + 14, w, h);
    for (let i = 0; i < 900; i++) { const rx = r() * w, ry = horizon + 20 + r() * (h - horizon - 20); g.fillStyle = `rgba(255,${180 + r() * 60},${100 + r() * 80},${r() * 0.35 * (1 - (ry - horizon) / (h - horizon))})`; g.fillRect(rx, ry, 6 + r() * 30, 2); }
  }, { aniso: 4 });
}
