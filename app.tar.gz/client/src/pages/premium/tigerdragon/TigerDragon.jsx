// Gong Fortune – game screen. Every result comes from the server before
// anything moves; this file only reveals it: 5 x 3 reels with 243 ways,
// Mystery Gongs after non-winning spins, the Tiger Bonus (Hold & Respin on
// 5 x 3), the Dragon Bonus (one spin on 5 x 8) and the Tiger & Dragon Bonus
// (5 x 8 with rows that unlock and a 32-gong jackpot), plus bonus buys.
import BonusBuy from '../../../components/BonusBuy.jsx';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { BigWin, Burst, FeatureIntro, PremiumShell, RecentList, SidePanel, sleep, usePremium, useReelStops } from '../../../components/Premium.jsx';
import { WinAmount } from '../../../components/GameShell.jsx';
import { Modal } from '../../../components/ui.jsx';
import { Gong, TD_NAMES, TDLogo, TDSym } from '../../../components/SlotArtTigerDragon.jsx';
import { playCue, playSample, playSting, playVoice, preloadUrls, registerTracks, registerVoiceGame, setMusicScene, tigerDragonSfx } from '../../../lib/sound.js';
import { TD_DECOR, TD_IMG, TD_PANEL } from '../../../assets/tigerdragon/index.js';
import HEADER from '../../../assets/tigerdragon/header.webp';
import HEADER_M from '../../../assets/tigerdragon/header_m.webp';
import { money } from '../../../lib/format.js';
import {
  ARROW_CHANCE, BONUS_ROWS, BUY_COMBINED_X, BUY_RANDOM_WEIGHTS, BUY_RANDOM_X, COMBINED_TRIGGER, CREDITS_PER_SPIN, DRAGON_TRIGGER, JACKPOT_GONGS, JACKPOT_X,
  LUCK_CHANCE, MAX_WIN_X, PAYTABLE, RESPINS, ROWS, STAKES, START_ROWS, TIGER_TRIGGER, UNLOCKS,
} from '../../../../../server/games/tigerdragon/config.js';

const REELS = 5;
const C = (s) => ({ s });
const START = [['LANTERN', 'TIGER', 'FAN'], ['ENVELOPE', 'LOTUS', 'BANGLE'], ['DRAGON', 'LANTERN', 'ORNAMENT'], ['FAN', 'ENVELOPE', 'LOTUS'], ['BANGLE', 'ORNAMENT', 'LANTERN']].map((c) => c.map(C));
const BLUR = ['ENVELOPE', 'FAN', 'LOTUS', 'TIGER', 'BANGLE', 'LANTERN', 'ORNAMENT', 'DRAGON'];
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v ? '1' : '0'); } catch { /* private mode */ } };
const devMode = () => { try { return location.hash.includes('dev') || localStorage.getItem('vb_dev') === '1'; } catch { return false; } };
const key = (c, r) => `${c}-${r}`;
const NAME = { tiger: 'Tiger Bonus', dragon: 'Dragon Bonus', combined: 'Tiger & Dragon Bonus' };

// Recorded audio (client/audio/tigerdragon/{music,voice,sfx}/*.mp3), when present at build time.
// Without the files the game falls back to its synthesised sounds and plays no voice.
const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
const aud = (f) => (AUD.files.includes(`tigerdragon/${f}.mp3`) ? `${AUD.base}tigerdragon/${f}.mp3` : null);
const TRACKS = Object.fromEntries(['base', 'bonus', 'dragon', 'win', 'jackpot'].map((k) => [k, aud(`music/${k}`)]).filter(([, u]) => u));
if (TRACKS.base) registerTracks('tigerdragon', TRACKS);
const VOICE = Object.fromEntries(['luck', 'tiger', 'dragon', 'combined', 'jackpot', 'bigwin', 'megawin'].map((k) => [k, aud(`voice/${k}`)]));
if (VOICE.tiger) registerVoiceGame('tigerdragon');
const SFX = Object.fromEntries(['gong_big', 'gong_big_2', 'gong_soft', 'gong_lock', 'gong_reset', 'cue_holdspin', 'cue_dragon', 'cue_luck', 'cue_near', 'cue_complete',
  'reveal_s', 'reveal_m', 'reveal_b', 'roar_tiger', 'roar_dragon', 'spin_use', 'spin_last', ...[1, 2, 3, 4, 5, 6].map((n) => `gong_land_${n}`)].map((k) => [k, aud(`sfx/${k}`)]));
const LANDS = [1, 2, 3, 4, 5, 6].map((n) => SFX[`gong_land_${n}`]).filter(Boolean);
// when the announcer speaks inside each feature cue (seconds from the cue's start)
const VOICE_AT = { luck: 1.0, holdspin: 0.9, dragon: 1.5 };
const stakeLabel = (x) => (x < 100 ? `${x}p` : money(x));

/** Painted backdrop: red lacquer, pagoda, swinging lanterns, drifting gold clouds. */
function Backdrop({ type }) {
  return (
    <div className={`td-bg absolute inset-0 overflow-hidden ${type === 'dragon' ? 'td-bg-dragon' : type === 'combined' ? 'td-bg-both' : ''}`}>
      <img src={TD_DECOR.pagoda} alt="" className="absolute bottom-[6%] left-1/2 w-[38%] -translate-x-1/2 opacity-25" />
      <img src={TD_DECOR.lantern} alt="" className="td-swing absolute -top-2 left-[3%] w-[9%] max-w-[54px] opacity-90" />
      <img src={TD_DECOR.lantern} alt="" className="td-swing absolute -top-2 right-[3%] w-[9%] max-w-[54px] opacity-90" style={{ animationDelay: '-1.3s' }} />
      <img src={TD_DECOR.cloud} alt="" className="td-drift absolute -bottom-2 left-[-6%] w-[46%] opacity-70" />
      <img src={TD_DECOR.cloud2} alt="" className="td-drift absolute -bottom-1 right-[-8%] w-[50%] opacity-60" style={{ animationDelay: '-6s', animationDirection: 'reverse' }} />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(0,0,0,.55)_100%)]" />
    </div>
  );
}
const nextUnlock = (count) => UNLOCKS.find(([at]) => count < at);

// ── Base reels ────────────────────────────────────────────────
function Reel({ index, cells, spinning, landKey, lit, turbo, tease, gongs }) {
  return (
    <div className={`relative overflow-hidden ${index ? 'td-divider' : ''} ${tease ? 'td-tease' : ''}`} style={{ aspectRatio: `1 / ${ROWS}` }}>
      {spinning ? (
        <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 60}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-1 opacity-80 blur-[1.5px]"><TDSym s={BLUR[(k * 3 + index * 2) % BLUR.length]} bare /></div>)}
        </div>
      ) : (
        <div key={landKey} className="p3-land-bounce">
          {cells.map((cell, row) => {
            const k = key(index, row), on = lit?.has(k), g = gongs?.[k];
            const scatter = cell.s === 'TIGER' || cell.s === 'DRAGON';
            return (
              <div key={row} data-td={k} className={`relative aspect-square ${scatter ? 'p-0.5' : 'p-1'} ${lit?.size && !on && !g ? 'p3-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'p3-win' : ''} ${scatter && on ? 'td-roar' : ''} ${scatter ? `td-scatter ${cell.s === 'DRAGON' ? 'td-scatter-dragon' : 'td-scatter-tiger'}` : ''}`} style={{ '--glow': cell.s === 'DRAGON' ? '#34d399' : '#fbbf24' }}>
                  <TDSym s={cell.s} bare />
                  {scatter && <span className="td-ribbon" aria-hidden="true">{cell.s === 'DRAGON' ? 'Dragon' : 'Tiger'}<b>Bonus</b></span>}
                </div>
                {g && <div className={`absolute inset-0 p-0.5 td-drop ${g.lit ? 'td-cluster' : ''}`}><Gong g={g.shown ? g.g : undefined} reveal={g.shown} tile /></div>}
                {on && <Burst key={landKey} game="tigerdragon" n={8} spread={40} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Bonus board ───────────────────────────────────────────────
/** An empty spot on a respin: a blurred strip of gongs racing past until its column stops. */
function CoinStrip({ seed, slow }) {
  const items = [1, 0, 0, 1, 0, 1];
  return (
    <div className={`td-coinstrip ${slow ? 'slow' : ''}`} style={{ animationDelay: `-${(seed * 97) % 400}ms` }} aria-hidden="true">
      {[...items, ...items].map((g, i) => (
        <div key={i} className="aspect-square p-[8%]">{g ? <img src={TD_IMG.GONG} alt="" className="h-full w-full" draggable="false" /> : null}</div>
      ))}
    </div>
  );
}

/**
 * LUCK HAS ARRIVED: a full-screen moment. Timeline (seconds, matching cue_luck + the voice):
 * 0 gong struck · 0.4-2.2 build-up · 2.2 title slams in with the announcer · 3.75 second gong · then fade.
 */
const PARTICLES = Array.from({ length: 34 }, (_, i) => ({ x: (i * 37) % 100, d: ((i * 53) % 30) / 10, dur: 2.4 + ((i * 17) % 20) / 10, s: 6 + ((i * 29) % 12), kind: i % 5 }));
function LuckScreen({ luck }) {
  if (!luck) return null;
  const k = luck.turbo ? 0.4 : 1;
  return createPortal(
    <div className="td-luck fixed inset-0 z-[90] flex items-center justify-center overflow-hidden" style={{ '--k': k, '--total': `${luck.total}ms` }} role="alert" aria-label="Luck has arrived">
      <div className="td-luck-bg absolute inset-0" />
      <div className="td-luck-rays absolute left-1/2 top-[44%] -translate-x-1/2 -translate-y-1/2" />
      <img src={TD_DECOR.lantern} alt="" className="td-luck-lantern absolute left-[3%] top-0 w-[18vmin] max-w-[110px]" />
      <img src={TD_DECOR.lantern} alt="" className="td-luck-lantern r absolute right-[3%] top-0 w-[18vmin] max-w-[110px]" />
      <img src={TD_DECOR.cloud} alt="" className="td-luck-cloud absolute -left-[8%] bottom-[2%] w-[60vmin] max-w-[420px]" />
      <img src={TD_DECOR.cloud2} alt="" className="td-luck-cloud r absolute -right-[8%] bottom-[6%] w-[60vmin] max-w-[420px]" />
      {PARTICLES.map((p, i) => (
        p.kind === 0 ? <img key={i} src={TD_DECOR.coin} alt="" className="td-luck-p absolute top-0" style={{ left: `${p.x}%`, width: p.s * 2.2, animationDelay: `calc(${p.d}s * var(--k))`, animationDuration: `${p.dur}s` }} />
          : <span key={i} className="td-luck-spark absolute top-0" style={{ left: `${p.x}%`, width: p.s / 2, height: p.s / 2, animationDelay: `calc(${p.d}s * var(--k))`, animationDuration: `${p.dur}s` }} />
      ))}
      <div className="relative flex flex-col items-center px-4 text-center">
        <div className="td-luck-gong relative w-[min(52vw,34vh,300px)]">
          <span className="td-luck-halo absolute inset-[-18%] rounded-full" />
          <img src={TD_IMG.GONG} alt="" className="relative w-full drop-shadow-[0_10px_30px_rgba(0,0,0,.7)]" />
          <span className="td-luck-ring absolute inset-0 rounded-full" />
          <span className="td-luck-ring two absolute inset-0 rounded-full" />
        </div>
        <h2 className="td-luck-title mt-[2.5vh]">
          <span style={{ animationDelay: 'calc(1.25s * var(--k))' }}>LUCK</span>{' '}
          <span style={{ animationDelay: 'calc(2.72s * var(--k))' }}>HAS</span>{' '}
          <span style={{ animationDelay: 'calc(2.98s * var(--k))' }}>ARRIVED!</span>
        </h2>
        <p className="td-luck-sub" style={{ animationDelay: 'calc(3.6s * var(--k))' }}>{luck.type ? `${NAME[luck.type]} awarded` : 'A bonus is yours'}</p>
      </div>
    </div>, document.body);
}

/** Coins that fly from paying gongs to the Win box. */
function CoinFlight({ flight }) {
  if (!flight) return null;
  return createPortal(
    <div className="pointer-events-none fixed inset-0 z-[80]" aria-hidden="true">
      {flight.coins.map((k, i) => (
        <img key={`${flight.id}-${i}`} src={TD_IMG.GONG} alt="" className="td-fly absolute h-7 w-7"
          style={{ left: k.x - 14, top: k.y - 14, '--dx': `${flight.tx - k.x}px`, '--dy': `${flight.ty - k.y}px`, animationDelay: `${i * 45}ms` }} />
      ))}
    </div>, document.body);
}

function Board({ b }) {
  const rows = b.rows;
  return (
    <div className={`td-board relative mx-auto rounded-2xl p-1.5 ${b.type === 'dragon' ? 'td-board-dragon' : b.type === 'tiger' ? 'td-board-tiger' : 'td-board-both'}`}
      style={{ maxWidth: rows > 3 ? 'min(100%, calc((100dvh - 330px) * 0.625))' : undefined }}>
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${REELS}, minmax(0, 1fr))` }}>
        {Array.from({ length: rows }, (_, r) => {
          const closed = b.type === 'combined' && r < BONUS_ROWS - b.open;
          const opening = b.opening?.includes(r);
          const need = closed ? UNLOCKS.find(([, n]) => n === BONUS_ROWS - r)?.[0] : null;
          return Array.from({ length: REELS }, (_, c) => {
            const k = key(c, r), cell = b.cells[k];
            if (closed) {
              return (
                <div key={k} className="td-shut relative aspect-square rounded-lg">
                  {c === 2 && <span className="absolute inset-0 flex flex-col items-center justify-center text-center text-[9px] font-extrabold leading-tight text-amber-200/90 sm:text-[11px]"><span aria-hidden="true">🔒</span>{need} gongs</span>}
                </div>
              );
            }
            const spinningHere = !cell && b.spin && c >= (b.stopped || 0);
            return (
              <div key={k} data-td={k} className={`relative aspect-square overflow-hidden rounded-lg ${opening ? 'td-open' : ''} ${cell ? 'overflow-visible' : 'bg-black/45 ring-1 ring-amber-300/15'} ${spinningHere && b.slowCol === c ? 'td-tease' : ''}`}>
                {spinningHere && <CoinStrip seed={c * 8 + r} slow={b.slowCol === c} />}
                {!cell && !spinningHere && b.spin && <div key={`s${b.spinN}`} className="td-blank-stop absolute inset-0" />}
                {cell && (
                  <div className={`absolute inset-0 ${cell.fresh ? 'td-slam' : ''} ${cell.lit ? 'td-cluster' : ''} ${cell.dim ? 'opacity-45' : ''}`}>
                    <Gong g={cell.shown ? cell.g : undefined} locked={!cell.shown} reveal={cell.shown} />
                    {cell.fresh && <Burst game="tigerdragon" n={12} spread={44} />}
                  </div>
                )}
              </div>
            );
          });
        })}
      </div>
    </div>
  );
}

function BonusHud({ b }) {
  const next = b.type === 'combined' ? nextUnlock(b.count) : null;
  return (
    <div className="mb-1.5 grid grid-cols-3 items-center gap-1.5 text-center">
      <div className="rounded-lg bg-black/55 px-1.5 py-1 ring-1 ring-amber-300/30">
        <div className="text-[9px] font-bold uppercase tracking-wider text-amber-200/80">{b.type === 'dragon' ? 'Spin' : 'Spins left'}</div>
        <div className={`flex justify-center gap-1 py-0.5 ${b.type !== 'dragon' && b.spinsLeft === 1 && !b.spin ? 'td-last' : ''}`} aria-label={`${b.spinsLeft} spins left`}>
          {Array.from({ length: b.type === 'dragon' ? 1 : RESPINS }, (_, i) => <span key={i} className={`h-3 w-3 rounded-full ${i < b.spinsLeft ? 'bg-amber-300 shadow-[0_0_8px_#fcd34d]' : 'bg-white/15'} ${b.reset && i < b.spinsLeft ? 'td-pop' : ''}`} />)}
        </div>
      </div>
      <div className="rounded-lg bg-black/55 px-1.5 py-1 ring-1 ring-amber-300/30">
        <div className="text-[9px] font-bold uppercase tracking-wider text-amber-200/80">Gongs</div>
        <div className="font-cond text-xl font-extrabold leading-none text-white tabular-nums">{b.count}{b.type === 'combined' && <span className="text-xs text-amber-200/70"> / {JACKPOT_GONGS}</span>}</div>
      </div>
      <div className="rounded-lg bg-black/55 px-1.5 py-1 ring-1 ring-amber-300/30">
        <div className="text-[9px] font-bold uppercase tracking-wider text-amber-200/80">{b.type === 'combined' ? 'Rows open' : 'Grid'}</div>
        <div className="text-[11px] font-bold leading-tight text-white">{b.type === 'combined' ? <>{b.open} / 8{next && <span className="block text-[9px] font-semibold text-amber-200/70">next at {next[0]}</span>}</> : `5 × ${b.rows}`}</div>
      </div>
    </div>
  );
}

/** The money adding up, inside the fixed-height message panel: the cluster being paid and the running total. */
function Tally({ clusters, live, practice }) {
  const k = clusters[clusters.length - 1];
  const total = clusters.reduce((a, x) => a + (x.win || 0), 0);
  return (
    <div className="w-full space-y-0.5" aria-live="polite">
      <div key={clusters.length} className="td-tally-in flex items-center justify-between gap-2 text-xs">
        <span className="flex min-w-0 items-center gap-1 overflow-hidden font-bold text-amber-100">
          {k.gongs.map((g, i) => <span key={i} className={`shrink-0 rounded px-1 ${g.a != null ? 'bg-green-700 text-white' : 'bg-amber-200 text-red-900'}`}>{g.a != null ? `↑${g.a}` : g.n}</span>)}
          <span className="shrink-0 text-white/70">→</span><span className="truncate font-cond text-sm text-white">{k.text}</span>
        </span>
        <span className="shrink-0 font-bold tabular-nums text-amber-300">{money(k.win)}</span>
      </div>
      <div className="flex items-center justify-between text-[11px] font-bold text-amber-100/80">
        <span>{clusters.length === 1 ? '1 cluster' : `${clusters.length} clusters`}{practice ? ' · practice, no pay' : ''}</span>
        <span className="font-cond text-lg leading-none text-amber-300 tabular-nums">{money(practice ? total : live ?? total)}</span>
      </div>
    </div>
  );
}

/** Cluster read-out: "5 · 3 · ↑5 → 853" and its win. */
function ClusterLine({ k, bet }) {
  return (
    <div className="td-pop flex items-center justify-between gap-2 rounded-lg bg-black/55 px-2 py-1 text-xs ring-1 ring-amber-300/40">
      <span className="flex flex-wrap items-center gap-1 font-bold text-amber-100">
        {k.gongs.map((g, i) => <span key={i} className={`rounded px-1 ${g.a != null ? 'bg-green-700 text-white' : 'bg-amber-200 text-red-900'}`}>{g.a != null ? `↑${g.a}` : g.n}</span>)}
        <span className="text-white/70">→</span><span className="font-cond text-sm text-white">{k.text}</span>
      </span>
      <span className="shrink-0 font-bold text-amber-300 tabular-nums">{money(k.win)}</span>
    </div>
  );
}

export default function TigerDragon() {
  const { user, view, history, play, commit, guard: rawGuard, shake, doShake } = usePremium('tigerdragon');
  const synth = useMemo(() => tigerDragonSfx(), []);
  // Recorded effects first; the synthesised version only plays if a file is missing.
  const fx = useMemo(() => {
    let landN = 0;
    const smp = (url, opts, fallback) => { if (!url || !playSample(url, opts)) fallback?.(); };
    // Levels are deliberately low: the music, gongs and voice sit together without crowding.
    return {
      ...synth,
      // one soft gong per column that stops with gongs in it; a touch fuller when several land together
      gongLand: (count = 1, intensity = 0, nth = 0) => {
        const url = LANDS[landN++ % (LANDS.length || 1)];
        smp(url, { gain: (0.42 + Math.min(3, count) * 0.04 + intensity * 0.06) * (nth ? 0.72 : 1), rate: 0.985 + Math.random() * 0.03 + intensity * 0.03 }, () => synth.gongLand(0));
      },
      gongLock: () => smp(SFX.gong_lock, { gain: 0.22, rate: 0.97 + Math.random() * 0.06 }, synth.gongLock),
      softGong: (gain = 0.35) => smp(SFX.gong_soft, { gain }, synth.bonusStart),
      bigGong: (rate = 1, gain = 0.5) => smp(SFX.gong_big, { gain, rate }, synth.bonusStart),
      reset: () => smp(SFX.gong_reset, { gain: 0.24 }),
      spinUse: (last) => smp(last ? SFX.spin_last : SFX.spin_use, { gain: last ? 0.45 : 0.3 }, synth.respin),
      near: () => smp(SFX.cue_near, { gain: 0.35 }, synth.tension),
      complete: () => smp(SFX.cue_complete, { gain: 0.5 }, synth.bonusStart),
      unlock: (rows) => smp(SFX.gong_reset, { gain: 0.3, rate: 0.9 + (rows - 4) * 0.05 }, () => synth.unlock(rows)),
      revealValue: (g, k = 0) => {
        if (g?.a != null) { smp(SFX.reveal_m, { gain: 0.32, rate: 1.12 }, synth.arrow); return; }
        const n = g?.n ?? 1;
        if (n >= 50) smp(SFX.reveal_b, { gain: 0.38 }, () => synth.reveal(k));
        else if (n >= 10) smp(SFX.reveal_m, { gain: 0.28, rate: 0.96 + (k % 5) * 0.02 }, () => synth.reveal(k));
        else smp(SFX.reveal_s, { gain: 0.25, rate: 0.94 + (k % 6) * 0.03 }, () => synth.reveal(k));
      },
      bigCluster: () => smp(SFX.reveal_b, { gain: 0.4 }),
      scatterLand: (n) => synth.scatter(n),
    };
  }, [synth]);
  const reels = useReelStops(REELS);
  const [cells, setCells] = useState(START);
  const [lit, setLit] = useState(null);
  const [gongs, setGongs] = useState(null);         // Mystery Gongs on the reels
  const [spinning, setSpinning] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [tease, setTease] = useState([]);
  const [stake, setStakeRaw] = useState(() => { try { const v = Number(localStorage.getItem('td_stake')); return STAKES.includes(v) ? v : 50; } catch { return 50; } });
  const setStake = (v) => { setStakeRaw(v); try { localStorage.setItem('td_stake', String(v)); } catch { /* private mode */ } };
  const [luck, setLuck] = useState(null);           // Luck Has Arrived presentation
  const [banner, setBanner] = useState(null);
  const [res, setRes] = useState(null);
  const [board, setBoard] = useState(null);         // bonus in progress on screen
  const [clusters, setClusters] = useState([]);
  const [intro, setIntro] = useState(null);
  const [summary, setSummary] = useState(null);
  const [big, setBig] = useState(null);
  const [running, setRunning] = useState(false);
  const [introDone, setIntroDone] = useState(false);
  const [liveWin, setLiveWin] = useState(null);    // counts up as coins land in the Win box
  const [flight, setFlight] = useState(null);
  const [turbo, setTurbo] = useState(() => pref('td_turbo', false));
  const [session, setSession] = useState({ staked: 0, won: 0 });
  const [dev] = useState(devMode);
  const bigResolve = useRef(null);
  const introResolve = useRef(null);
  const resumed = useRef(false);
  const fast = (ms) => (turbo ? ms * 0.45 : ms);
  const balance = user?.balance ?? 0;
  const mode = view?.mode || 'base';
  const busy = spinning || running || !!intro || !!summary || !!big;

  const guard = (fn) => rawGuard(fn);
  const track = (out) => { if (out && !out.practice) setSession((s) => ({ staked: s.staked + (out.staked || 0), won: s.won + (out.win || 0) })); };
  // Coins fly from these board / reel spots into the Win box, and the box counts up.
  const flyCoins = async (keys, amount) => {
    const box = document.getElementById('td-winbox')?.getBoundingClientRect();
    const pts = keys.map((k) => document.querySelector(`[data-td="${k}"]`)?.getBoundingClientRect()).filter(Boolean)
      .flatMap((r, i) => Array.from({ length: keys.length > 8 ? 1 : 2 }, (_, j) => ({ x: r.left + r.width / 2 + (j ? 8 : -6), y: r.top + r.height / 2 + (j ? -6 : 4), i })));
    if (box && pts.length) {
      setFlight({ id: Date.now(), coins: pts.slice(0, 26), tx: box.left + box.width / 2, ty: box.top + box.height / 2 });
      pts.slice(0, 12).forEach((_, i) => setTimeout(() => fx.coinIn(i), 420 + i * 45));
    }
    const from = liveWinRef.current, steps = 12;
    await sleep(380);
    for (let i = 1; i <= steps; i++) { const v = Math.round(from + (amount * i) / steps); liveWinRef.current = v; setLiveWin(v); await sleep(28); }
    liveWinRef.current = from + amount; setLiveWin(from + amount);
    setTimeout(() => setFlight(null), 900);
  };
  const liveWinRef = useRef(0);
  const resetLive = () => { liveWinRef.current = 0; setLiveWin(null); };
  const celebrate = (amount, bet, title) => new Promise((r) => {
    if (amount && title === 'JACKPOT!') { playVoice(VOICE.jackpot, { gain: 0.75 }); playSting('tigerdragon', 'jackpot'); }
    else if (amount >= bet * 50) { playVoice(VOICE.megawin, { gain: 0.7 }); playSting('tigerdragon', 'win'); }
    else if (amount >= bet * 10) { playVoice(VOICE.bigwin, { gain: 0.7 }); playSting('tigerdragon', 'win'); }
    if (!amount || amount < bet * 10) return r();
    bigResolve.current = r;
    setBig({ amount, title });
  });
  const waitIntro = (data) => new Promise((r) => { introResolve.current = r; setIntro(data); });

  // ── Bonus: show the board, run every respin, settle ─────────
  const runBonus = useCallback(async (type, bet, startCells, { resume = false, practice = false, fromLuck = false } = {}) => {
    setRunning(true);
    const rows = type === 'tiger' ? ROWS : BONUS_ROWS;
    let b = { type, bet, rows, open: type === 'combined' ? START_ROWS : rows, cells: {}, spinsLeft: type === 'dragon' ? 1 : RESPINS, count: 0, practice };
    for (const k of startCells || []) b.cells[k] = { fresh: true };
    b.count = Object.keys(b.cells).length;
    if (resume && view?.bonus) b = { ...b, open: view.bonus.open, spinsLeft: view.bonus.spinsLeft, count: view.bonus.count, cells: Object.fromEntries(view.bonus.locked.map((k) => [k, {}])) };
    setBoard(b);
    if (!resume) resetLive();
    if (!resume) {
      // one opening cue per bonus with the announcer placed inside it (after Luck Has Arrived the cue alone, no second voice)
      const vo = fromLuck ? null : VOICE[type];
      if (type === 'dragon') playCue(SFX.cue_dragon, vo, VOICE_AT.dragon, { gain: 0.6 }); else playCue(SFX.cue_holdspin, vo, VOICE_AT.holdspin, { gain: 0.6 });
    }
    await waitIntro({ type, resume, practice });
    setIntroDone(true);
    // the starting gongs settle in with a light chime each
    if (startCells?.length) { await sleep(fast(400)); for (let i = 0; i < startCells.length; i++) { fx.gongLock(); await sleep(fast(170)); } await sleep(fast(400)); }
    // respins until the server says the round is over. Each one: every empty spot spins a strip of
    // gongs, the columns stop left to right, and landing gongs slam in and lock.
    const unfresh = (cells) => Object.fromEntries(Object.entries(cells).map(([k, v]) => [k, { ...v, fresh: false }]));
    for (let guardN = 0; guardN < 80; guardN++) {
      await sleep(fast(type === 'dragon' ? 900 : 1000));
      const lastChance = type !== 'dragon' && b.spinsLeft === 1;
      b = { ...b, cells: unfresh(b.cells), spin: true, stopped: 0, spinN: guardN, slowCol: null, spinsLeft: Math.max(0, b.spinsLeft - 1), reset: false };
      setBoard(b);
      const filled = b.count / (type === 'tiger' ? REELS * ROWS : JACKPOT_GONGS);
      fx.spinUse(lastChance);
      if (type !== 'dragon' && filled >= 0.8 && !b.nearPlayed) { fx.near(); b = { ...b, nearPlayed: true }; }   // once, when close to a full grid / the jackpot
      const [out] = await Promise.all([play('respin', {}, { quiet: false }), sleep(fast(type === 'dragon' ? 1300 : 1000))]);
      if (!out) { setBoard({ ...b, spin: false }); setRunning(false); return; }
      let landed = 0;
      for (let c = 0; c < REELS; c++) {
        // on the last spin left, hold the final column a little longer
        if (lastChance && c === REELS - 1 && !turbo) { b = { ...b, slowCol: c }; setBoard(b); fx.tension(); await sleep(1100); }
        await sleep(fast(type === 'dragon' ? 380 : 320));
        const colLands = out.lands.filter((k) => k.startsWith(`${c}-`));
        const fresh = Object.fromEntries(colLands.map((k) => [k, { fresh: true }]));
        b = { ...b, stopped: c + 1, slowCol: null, cells: { ...b.cells, ...fresh } };
        setBoard(b);
        if (colLands.length) {
          // layered impacts: one gong per landing, slightly staggered, stronger as the board fills
          fx.gongLand(colLands.length, Math.min(1, (b.count + landed) / (type === 'tiger' ? REELS * ROWS : JACKPOT_GONGS)), landed);
          landed += colLands.length; if (colLands.length >= 3) doShake(false);
        }
        else fx.reelStop(c);
      }
      b = { ...b, spin: false, count: out.count, spinsLeft: out.spinsLeft, reset: landed > 0 && type !== 'dragon' };
      setBoard(b);
      if (landed) { await sleep(fast(450)); fx.gongLock(); if (type !== 'dragon') { await sleep(fast(150)); fx.reset(); } }
      if (out.unlocked?.length) {
        const opening = out.unlocked.map((n) => BONUS_ROWS - n);
        b = { ...b, open: out.open, opening };
        setBoard(b);
        fx.unlock(out.open);
        doShake(false);
        await sleep(fast(1200));
        b = { ...b, opening: [] };
      }
      setBoard({ ...b });
      if (out.result) {
        // the feature is over: completion fanfare (the Dragon roars once more), then the values are revealed
        fx.complete();
        await sleep(fast(1300));
        await settle(out, b); return;
      }
    }
    setRunning(false);
  }, [view, fx, play, turbo]); // eslint-disable-line react-hooks/exhaustive-deps

  const settle = async (out, b) => {
    const r = out.result;
    // reveal every gong's value, left to right, top to bottom
    const keys = Object.keys(r.cells).sort((a, z) => { const [ac, ar] = a.split('-').map(Number), [zc, zr] = z.split('-').map(Number); return ar - zr || ac - zc; });
    if (r.jackpot) {
      fx.bigGong(0.9, 0.55); doShake(true);
      setBoard({ ...b, cells: Object.fromEntries(keys.map((k) => [k, { g: r.cells[k], shown: true, lit: true }])), jackpot: true });
      await sleep(900);
      await flyCoins(keys, b.practice || out.practice ? 0 : out.win);
      await sleep(600);
    } else {
      let shown = { ...b.cells };
      for (let i = 0; i < keys.length; i++) {
        shown = { ...shown, [keys[i]]: { g: r.cells[keys[i]], shown: true } };
        setBoard({ ...b, cells: shown });
        fx.revealValue(r.cells[keys[i]], i);
        await sleep(fast(keys.length > 20 ? 110 : 190));
      }
      await sleep(fast(400));
      const inCluster = new Set(r.clusters.flatMap((k) => k.cells.map(([c, rr]) => key(c, rr))));
      setBoard({ ...b, cells: Object.fromEntries(keys.map((k) => [k, { g: r.cells[k], shown: true, lit: inCluster.has(k), dim: !inCluster.has(k) }])) });
      const list = [];
      for (let i = 0; i < r.clusters.length; i++) {
        list.push(r.clusters[i]); setClusters([...list]); fx.cluster(i);
        if ((r.clusters[i].win || 0) >= b.bet * 5) fx.bigCluster();
        await flyCoins(r.clusters[i].cells.map(([c, rr]) => key(c, rr)), b.practice || out.practice ? 0 : r.clusters[i].win || 0);
        await sleep(fast(450));
      }
    }
    setRes({ win: out.win, staked: 0, bonus: r });
    track(out);
    await celebrate(out.win, b.bet, r.jackpot ? 'JACKPOT!' : null);
    if (out.win) fx.coins(Math.min(24, 6 + Math.round(out.win / b.bet)));
    commit();
    setSummary({ ...r, practice: b.practice || out.practice, win: out.win });
  };

  const endSummary = () => { setSummary(null); setBoard(null); setClusters([]); setRunning(false); resetLive(); setIntroDone(false); fx.gongLock(); };
  // music follows the action; voice lines load after the first interaction
  // the bonus music comes in once the intro is dismissed, so it never stacks on the opening cue
  useEffect(() => { setMusicScene('tigerdragon', !board || !introDone ? 'base' : board.type === 'dragon' ? 'dragon' : 'bonus'); }, [board?.type, introDone]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const h = () => preloadUrls([...Object.values(VOICE), ...Object.values(SFX)]);
    window.addEventListener('pointerdown', h, { once: true });
    return () => window.removeEventListener('pointerdown', h);
  }, []);

  // Resume a bonus that was in progress (page reload, app switch)
  useEffect(() => {
    if (resumed.current || !view || view.mode === 'base' || board) return;
    resumed.current = true;
    runBonus(view.mode, view.bonus.bet, [], { resume: true, practice: view.practice });
  }, [view]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Base spin ───────────────────────────────────────────────
  const spin = () => guard(async () => {
    if (busy || mode !== 'base') return;
    setLit(null); setGongs(null); setRes(null); setClusters([]); resetLive();
    setSpinning(true); setSpinId((n) => n + 1); reels.start(); fx.spin?.();
    const out = await play('spin', { stake });
    if (!out) { reels.stopNow(); setSpinning(false); return; }
    await showSpin(out);
  });

  // ── LUCK HAS ARRIVED: shown only when Mystery Gongs are actually awarded by the server ──
  // Gong, build-up, the announcer at 2.2s, a second resonant gong at 3.75s, then the finish.
  // The screen waits until the sound has started so picture and voice stay together.
  const luckHasArrived = async (type) => {
    const len = await playCue(SFX.cue_luck, VOICE.luck, VOICE_AT.luck, { gain: 0.7 });
    const total = turbo ? 2600 : Math.max(5400, Math.min(6400, len * 1000 - 900));
    setLuck({ id: Date.now(), total, turbo, type });
    await sleep(total);
    setLuck(null);
    await sleep(250);
  };

  const showSpin = async (out) => {
    setCells(out.grid);
    // tease the later reels when 2+ Tiger/Dragon are already showing
    const scat = out.grid.map((col) => col.filter((c) => c.s === 'TIGER' || c.s === 'DRAGON').length);
    const teaseReels = [];
    let seen = 0;
    scat.forEach((n, i) => { if (seen >= 2 && i > 0) teaseReels.push(i); seen += n; });
    setTease(turbo ? [] : teaseReels);
    let shownScat = 0;
    await reels.stopAll({ turbo, tease: turbo ? [] : teaseReels, onStop: (i) => { fx.stop(i); if (scat[i]) { shownScat += scat[i]; fx.scatterLand(shownScat); } } });
    setTease([]);
    setSpinning(false);
    const winCells = new Set(out.wins.flatMap((w) => w.cells.map(([c, r]) => key(c, r))));
    if (out.trigger) out.grid.forEach((col, c) => col.forEach((x, r) => { if ((out.trigger === 'tiger' && x.s === 'TIGER') || (out.trigger === 'dragon' && x.s === 'DRAGON') || (out.trigger === 'combined' && (x.s === 'TIGER' || x.s === 'DRAGON'))) winCells.add(key(c, r)); }));
    if (winCells.size) setLit(winCells);
    if (out.wins.length) fx.win?.(Math.min(3, out.wins.length));
    // Mystery Gongs: drop onto the reels, reveal values, pay clusters
    if (out.mystery) {
      setBanner('mystery'); fx.softGong(0.3); await sleep(fast(1200)); setBanner(null);
      const keys = Object.keys(out.mystery.cells);
      let g = {};
      for (let i = 0; i < keys.length; i++) { g = { ...g, [keys[i]]: { g: out.mystery.cells[keys[i]], shown: false } }; setGongs(g); fx.gongLand(1, i / 5); await sleep(fast(300)); }
      await sleep(fast(400));
      for (let i = 0; i < keys.length; i++) {
        g = { ...g, [keys[i]]: { g: out.mystery.cells[keys[i]], shown: true } }; setGongs(g); fx.revealValue(out.mystery.cells[keys[i]], i); await sleep(fast(220));
      }
      await sleep(fast(500));
      const inC = new Set(out.mystery.clusters.flatMap((k) => k.cells.map(([c, r]) => key(c, r))));
      setGongs(Object.fromEntries(keys.map((k) => [k, { g: out.mystery.cells[k], shown: true, lit: inC.has(k) }])));
      setClusters(out.mystery.clusters);
      if (out.mystery.clusters.length) {
        doShake(false);
        for (let i = 0; i < out.mystery.clusters.length; i++) { fx.cluster(i); if (out.mystery.clusters[i].win >= out.bet * 5) fx.bigCluster(); await flyCoins(out.mystery.clusters[i].cells.map(([c, r]) => key(c, r)), out.practice ? 0 : out.mystery.clusters[i].win || 0); }
      }
    }
    setRes({ win: out.win, staked: out.staked, wins: out.wins, mystery: out.mystery, practice: out.practice });
    track(out);
    await celebrate(out.win, out.bet, null);
    commit();
    if (out.luck) {
      // LUCK HAS ARRIVED: the screen covers over, its own sound plays, then the awarded bonus starts
      await sleep(fast(500));
      setLit(null); setGongs(null); setClusters([]);
      await luckHasArrived(out.started);
      await runBonus(out.started, out.bet, out.startCells || [], { practice: out.practice, fromLuck: true });
      return;
    }
    if (out.started) {
      await sleep(fast(700));
      setLit(null); setGongs(null); setClusters([]);
      await runBonus(out.started, out.bet, out.startCells || [], { practice: out.practice });
    }
  };

  const buy = ({ option, nonce, stake: bet = stake }) => guard(async () => {
    if (busy || mode !== 'base') return;
    setLit(null); setGongs(null); setRes(null); setClusters([]);
    const out = await play('buy', { stake: bet, option, nonce });
    if (!out) return;
    track(out);
    commit();
    await runBonus(out.started, out.bet, out.startCells || []);
  });

  const devRun = (event) => guard(async () => {
    if (busy || mode !== 'base') return;
    setLit(null); setGongs(null); setRes(null); setClusters([]);
    if (event === 'mystery' || event === 'luck') {
      setSpinning(true); reels.start();
      const out = await play('dev', { event, stake });
      if (!out) { reels.stopNow(); setSpinning(false); return; }
      await showSpin(out);
      return;
    }
    const out = await play('dev', { event, stake });
    if (!out) return;
    await runBonus(out.started, stake, out.startCells || [], { practice: true });
  });

  // space bar spins on desktop
  useEffect(() => {
    const h = (e) => { if (e.code === 'Space' && !['INPUT', 'TEXTAREA', 'BUTTON'].includes(document.activeElement?.tagName)) { e.preventDefault(); spin(); } };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  });

  const i = Math.max(0, STAKES.indexOf(stake));
  const chipsRef = useRef(null);
  useEffect(() => { const el = chipsRef.current?.querySelector('[data-on]'); if (el && chipsRef.current) chipsRef.current.scrollTo({ left: el.offsetLeft - chipsRef.current.clientWidth / 2 + el.clientWidth / 2, behavior: 'smooth' }); }, [stake]);
  const low = stake > balance;
  const detail = res?.bonus ? (res.bonus.jackpot ? `JACKPOT · ${res.bonus.gongs} gongs` : `${NAME[res.bonus.type]} · ${res.bonus.clusters.length} cluster${res.bonus.clusters.length === 1 ? '' : 's'}`)
    : res?.mystery ? (res.mystery.clusters.length ? `Mystery Gongs · ${res.mystery.clusters.length} cluster${res.mystery.clusters.length === 1 ? '' : 's'}` : 'Mystery Gongs did not connect')
      : res?.wins?.length ? res.wins.slice(0, 2).map((w) => `${w.count} ${TD_NAMES[w.symbol]} × ${w.ways} way${w.ways > 1 ? 's' : ''}`).join(' · ') : null;

  const header = (
    <div className="td-header relative -mx-2 -mt-2 mb-2 overflow-hidden rounded-t-2xl sm:-mx-4 sm:-mt-4">
      <img src={HEADER_M} alt="" className="h-[clamp(72px,22vw,120px)] w-full object-cover md:hidden" />
      <img src={HEADER} alt="" className="hidden h-[clamp(90px,14vw,150px)] w-full object-cover md:block" />
      <div className="absolute inset-y-0 left-1/2 flex w-[42%] max-w-[300px] -translate-x-1/2 items-center justify-center md:w-[34%]"><TDLogo textOnly className="h-[80%] w-full drop-shadow-[0_4px_10px_rgba(0,0,0,.7)]" /></div>
      <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-transparent via-amber-300 to-transparent" />
    </div>
  );
  const buyPanel = (
    <div className="td-panel hidden flex-col gap-2 p-2 lg:flex">
      <div className="td-plaque">Bonus buy</div>
      {[['random', 'Random bonus', 'Tiger, Dragon or both'], ['combined', 'Tiger & Dragon bonus', 'Both together']].map(([opt, l, sub]) => (
        <div key={opt} className="rounded-xl bg-gradient-to-b from-[#1e2a5c] to-[#0b1030] p-2 text-center ring-1 ring-amber-300/60">
          <div className="text-[11px] font-extrabold uppercase leading-tight text-amber-100">{l}</div>
          <div className="text-[10px] font-bold text-amber-100/70">{sub}</div>
        </div>
      ))}
      <BonusBuy game="tigerdragon" stake={stake} balance={balance} disabled={busy || mode !== 'base'} onBuy={buy} className="w-full" />
    </div>
  );
  const featurePanel = (
    <div className="td-panel hidden flex-col gap-2 p-2 lg:flex">
      {['tiger', 'dragon', 'combined'].map((t) => <img key={t} src={TD_PANEL[t]} alt={NAME[t]} className={`w-full rounded-lg ${board && board.type !== t ? 'opacity-40' : ''} ${board?.type === t ? 'td-cluster' : ''}`} />)}
    </div>
  );
  const stage = board ? (
    <div className="relative">
      <BonusHud b={board} />
      <Board b={board} />
      {board.jackpot && <div className="td-pop pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center"><img src={TD_PANEL.jackpot} alt="Jackpot" className="w-[78%] max-w-[300px] drop-shadow-[0_0_30px_rgba(252,211,77,.8)]" /><div className="mt-1 rounded-full bg-black/70 px-4 py-1 text-sm font-bold text-amber-200">{JACKPOT_GONGS} gongs collected</div><Burst game="tigerdragon" n={30} spread={150} /></div>}
    </div>
  ) : (
    <div className="relative">
      <div className="td-reelset grid" style={{ gridTemplateColumns: `repeat(${REELS}, minmax(0, 1fr))` }}>
        {cells.map((col, c) => <Reel key={c} index={c} cells={col} spinning={spinning && !reels.stopped[c]} landKey={`${spinId}-${c}`} lit={lit} turbo={turbo} tease={tease.includes(c) && spinning && !reels.stopped[c]} gongs={gongs} />)}
      </div>
    </div>
  );

  const info = (
    <>
      <section>
        <h3 className="mb-1 font-bold text-white">How it plays</h3>
        <p>5 reels, 3 rows, 243 ways: a symbol pays when it lands on reel 1 and on each neighbouring reel after it (3, 4 or 5 reels). Every combination of positions is a way, and pays are per way.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Paytable (multiples of the stake, per way)</h3>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(PAYTABLE).map(([s, p]) => (
            <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
              <div className="h-10 w-10 shrink-0"><TDSym s={s} /></div>
              <div className="text-[11px] leading-tight">{p.map((x, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{(x / 100).toFixed(2)}x</b> <span className="text-slate-500">({money(Math.floor((stake * x) / 100))})</span></div>)}</div>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Gongs and clusters</h3>
        <p>Each gong shows a number from 1 to 99 or an Arrow. A cluster is 2 or more gongs side by side in the same row; gongs above, below or diagonal do not connect. A cluster's numbers are read left to right as one number (5, 3, 8 reads 538). Each Arrow in a cluster adds its value (1 to 90) to the leftmost number first (an Arrow +5 turns 1, 2 into 62). The number is credits: {CREDITS_PER_SPIN} credits = your stake, so at {money(stake)} a 538 cluster pays {money(Math.round((538 * stake) / CREDITS_PER_SPIN))}. Every cluster pays; a lone gong pays nothing.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Luck Has Arrived</h3>
        <p>On any spin that doesn't trigger a bonus itself, luck can arrive at random (about 1 spin in {Math.round(1 / LUCK_CHANCE)}): the screen covers over and a bonus is guaranteed: the Tiger Bonus (45%), the Dragon Bonus (45%) or the Tiger &amp; Dragon Bonus (10%), starting like a bought bonus.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Mystery Gongs</h3>
        <p>After a spin with no regular win, 2 to 5 gongs can drop onto random spots on the reels (they favour sharing a row). If they form clusters, the clusters pay at your stake.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Tiger Bonus · {TIGER_TRIGGER} Tigers</h3>
        <p>Hold &amp; Respin on 5 × 3. The Tigers that triggered it become the first gongs. You get {RESPINS} spins; only gongs land. Every gong locks in place for the rest of the round and resets the spins to {RESPINS}. It ends when the spins run out or all 15 spots are filled; then every cluster reveals and pays.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Dragon Bonus · {DRAGON_TRIGGER} Dragons</h3>
        <p>Exactly one spin on a 5 × 8 grid of gongs. Every cluster then reveals and pays.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Tiger &amp; Dragon Bonus · {COMBINED_TRIGGER}+ Tigers and Dragons together</h3>
        <p>5 × 8 grid with the bottom {START_ROWS} rows open; the Tigers and Dragons that triggered it become the first gongs. {RESPINS} spins, reset by every new gong. Rows open as you collect gongs: {UNLOCKS.map(([at, n]) => `${at} gongs open row ${n}`).join(', ')}. A newly opened row is in play from the next spin. Collect {JACKPOT_GONGS} gongs to win the jackpot ({JACKPOT_X.toLocaleString()}x your stake), which replaces the cluster pays. Otherwise every cluster reveals and pays when the spins run out or the grid fills.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Bonus buy</h3>
        <p>Random bonus: {BUY_RANDOM_X}x the stake for the Tiger, Dragon or Tiger &amp; Dragon Bonus (chances {BUY_RANDOM_WEIGHTS.map(([t, w]) => `${NAME[t]} ${w}%`).join(', ')}). Tiger &amp; Dragon Bonus: {BUY_COMBINED_X}x the stake.</p>
      </section>
      <section className="text-xs text-slate-400">
        <p>Return to player is about {view?.rtp || 96}% over the long run (this server's setting), measured across the base game and every bonus. At the 96% setting bonus buys return about 96%. Maximum win {MAX_WIN_X.toLocaleString()}x the stake per spin or bonus. Gong values: about {Math.round(ARROW_CHANCE * 100)}% are Arrows.</p>
        <p className="mt-1">This game reproduces the published rules of a well-known gong slot. Its probabilities (symbol weights, how often gongs land, gong values, the jackpot size and the Mystery Gong rate) are not public, so they were set by simulation to reach the chosen return (96%, 94% or 92%). They are not the original game's numbers.</p>
      </section>
    </>
  );

  const win = res?.win || 0;
  const bar = (
    <div className="td-bar sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2 md:static">
      <div ref={chipsRef} className="td-chips relative -mx-0.5 flex gap-1.5 overflow-x-auto px-0.5 pb-0.5" role="radiogroup" aria-label="Bet per spin">
        {STAKES.map((x) => (
          <button key={x} type="button" role="radio" aria-checked={x === stake} data-on={x === stake ? '1' : undefined} disabled={busy} onClick={() => { setStake(x); synth.stop(STAKES.indexOf(x)); }}
            className={`td-chip ${x === stake ? 'on' : ''} ${[10, 20, 30, 40, 50, 100].includes(x) ? 'main' : ''}`}>{stakeLabel(x)}</button>
        ))}
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] gap-1.5">
        <div className="td-box"><span>Balance</span><b>{money(balance)}</b></div>
        <div className="td-box items-center gap-1 px-1" style={{ flexDirection: 'row' }}>
          <button className="td-round h-8 w-8 text-lg" disabled={busy || i <= 0} onClick={() => setStake(STAKES[i - 1])} aria-label="Lower stake">−</button>
          <div className="flex min-w-[3.8rem] flex-col items-center"><span>Bet</span><b>{stakeLabel(stake)}</b></div>
          <button className="td-round h-8 w-8 text-lg" disabled={busy || i >= STAKES.length - 1} onClick={() => setStake(STAKES[i + 1])} aria-label="Raise stake">+</button>
        </div>
        <div className="td-box" id="td-winbox"><span>Win</span><b className={(liveWin ?? win) ? 'text-amber-300' : ''}>{money(liveWin ?? win)}</b></div>
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
        <div className="lg:invisible"><BonusBuy game="tigerdragon" stake={stake} balance={balance} disabled={busy || mode !== 'base'} onBuy={buy} /></div>
        <button onClick={spin} disabled={busy || low || mode !== 'base'} aria-label={spinning ? 'Spinning' : running ? 'Bonus in play' : low ? 'Not enough balance' : 'Spin'} title={low ? 'Not enough balance' : 'Spin'}
          className="td-spin relative flex h-[72px] w-[72px] items-center justify-center rounded-full disabled:opacity-60">
          <svg viewBox="0 0 48 48" className={`h-10 w-10 ${spinning || running ? 'animate-spin' : ''}`} fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M38 18a16 16 0 0 0-28-3" /><path d="M10 6v9h9" /><path d="M10 30a16 16 0 0 0 28 3" /><path d="M38 42v-9h-9" />
          </svg>
        </button>
        <div className="flex justify-end gap-1.5">
          <button onClick={() => setTurbo((t) => { save('td_turbo', !t); return !t; })} className={`td-btn-blue h-11 px-3 text-xs ${turbo ? 'ring-2 ring-amber-300' : ''}`} aria-pressed={turbo}>{turbo ? 'Turbo on' : 'Turbo'}</button>
        </div>
      </div>
      {low && !busy && <p className="text-center text-[11px] font-semibold text-amber-300">Not enough balance for this bet</p>}
      {dev && (
        <div className="flex flex-wrap gap-1 border-t border-white/10 pt-2 text-[11px]" aria-label="Practice triggers">
          <span className="w-full text-amber-200/70">Practice (no cost, no pay):</span>
          {[['tiger', 'Tiger'], ['dragon', 'Dragon'], ['combined', 'Tiger & Dragon'], ['jackpot', '32-gong jackpot'], ['mystery', 'Mystery Gongs'], ['luck', 'Luck Has Arrived']].map(([e, l]) => (
            <button key={e} onClick={() => devRun(e)} disabled={busy || mode !== 'base'} className="h-8 rounded-md bg-navy-700 px-2 font-semibold text-slate-200 disabled:opacity-40">{l}</button>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <PremiumShell game="tigerdragon" rtp={`${view?.rtp || 96}%`} title="Gong Fortune" tagline="5 × 3 · 243 ways · Tiger, Dragon and Tiger & Dragon bonuses · Mystery Gongs" shake={shake}
      stageClass="border-2 border-amber-400/50 shadow-[0_0_50px_rgba(220,38,38,0.35)]" bg={<Backdrop type={board?.type} />} info={info}
      below={bar} fitKey={board ? `bonus-${board.rows}` : 'base'}
      side={<>
        <SidePanel title="This session">
          <div className="flex justify-between text-xs"><span className="text-slate-400">Staked</span><b className="tabular-nums text-white">{money(session.staked)}</b></div>
          <div className="flex justify-between text-xs"><span className="text-slate-400">Won</span><b className="tabular-nums text-white">{money(session.won)}</b></div>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      {header}
      <div className="td-msg mb-2 flex h-[60px] flex-col items-center justify-center overflow-hidden rounded-xl bg-black/50 px-2 py-1 text-center leading-tight ring-1 ring-amber-300/20">
        {clusters.length ? <Tally clusters={clusters} live={liveWin} practice={!!(board?.practice || res?.practice)} />
          : board ? (
          <div className="text-sm font-bold text-amber-100">{NAME[board.type]}{board.practice ? ' · practice' : ''}<span className="block text-[11px] font-medium text-white/70">{board.type === 'dragon' ? 'One spin: clusters of 2+ gongs pay' : 'New gongs lock and reset the spins'}</span></div>
        ) : res?.win ? <><WinAmount win={res.win} staked={res.staked} />{detail && <div className="w-full truncate text-[11px] text-white/75">{detail}</div>}</>
          : <div className="text-sm text-white/65">{spinning ? 'Spinning…' : res ? (detail || 'No win this time') : `${TIGER_TRIGGER} Tigers, ${DRAGON_TRIGGER} Dragons or ${COMBINED_TRIGGER}+ together start a bonus`}</div>}
      </div>
      <div className="lg:grid lg:grid-cols-[132px_minmax(0,1fr)_132px] lg:items-start lg:gap-2">{buyPanel}<div className="min-w-0">{stage}</div>{featurePanel}</div>

      {intro && (
        <FeatureIntro title={intro.resume ? 'WELCOME BACK' : ''}
          className={intro.type === 'dragon' ? 'bg-[radial-gradient(ellipse_at_top,rgba(6,95,70,.95),rgba(2,10,8,.97))]' : 'bg-[radial-gradient(ellipse_at_top,rgba(185,28,28,.95),rgba(20,4,4,.97))]'}
          art={<img src={TD_PANEL[intro.type]} alt="" className="td-pop relative mb-2 w-[72%] max-w-[300px] drop-shadow-[0_0_24px_rgba(0,0,0,.6)]" />}
          subtitle={intro.resume ? 'Your bonus is still in progress. Carry on where you left off.'
            : intro.type === 'tiger' ? `Hold & Respin: ${RESPINS} spins, only gongs land. Every gong locks and resets the spins to ${RESPINS}. Clusters of 2+ gongs side by side pay at the end.`
              : intro.type === 'dragon' ? 'One spin on the 5 × 8 gong grid. Clusters of 2+ gongs side by side pay.'
                : `${START_ROWS} of 8 rows open. ${UNLOCKS.map(([at]) => at).join(' / ')} gongs open the next rows. ${RESPINS} spins, reset by every gong. ${JACKPOT_GONGS} gongs wins the jackpot.`}
          cta={intro.practice ? 'Start practice' : 'Strike the gong'}
          onStart={() => { setIntro(null); introResolve.current?.(); introResolve.current = null; }} />
      )}
      {summary && (
        <FeatureIntro title={summary.jackpot ? 'JACKPOT!' : 'BONUS COMPLETE'} cta="Back to the reels" onStart={endSummary}
          className="bg-[radial-gradient(ellipse_at_top,rgba(180,83,9,.95),rgba(20,4,4,.97))]"
          subtitle={`${NAME[summary.type]}: ${summary.gongs} gongs${summary.jackpot ? ` · jackpot ${JACKPOT_X.toLocaleString()}x` : `, ${summary.clusters.length} paying cluster${summary.clusters.length === 1 ? '' : 's'}`}. ${summary.practice ? 'Practice round: nothing was paid.' : summary.win ? `You win ${money(summary.win)}${summary.capped ? ` (capped at ${MAX_WIN_X.toLocaleString()}x)` : ''}.` : 'No clusters this time.'}`} />
      )}
      <CoinFlight flight={flight} />
      <LuckScreen luck={luck} />
      {banner && <div className="td-pop pointer-events-none fixed inset-0 z-[60] flex items-center justify-center"><img src={TD_PANEL[banner]} alt="Mystery Gongs" className="w-[62%] max-w-[260px] drop-shadow-[0_0_24px_rgba(253,224,71,.5)]" /></div>}
      {big && <BigWin game="tigerdragon" amount={big.amount} bet={board?.bet || stake} title={big.title} onDone={() => { setBig(null); bigResolve.current?.(); bigResolve.current = null; }} />}

    </PremiumShell>
  );
}
