// Gong Fortune – game screen. Every result comes from the server before
// anything moves; this file only reveals it: 5 x 3 reels with 243 ways,
// Mystery Gongs after non-winning spins, the Tiger Bonus (Hold & Respin on
// 5 x 3), the Dragon Bonus (one spin on 5 x 8) and the Tiger & Dragon Bonus
// (5 x 8 with rows that unlock and a 32-gong jackpot), plus bonus buys.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, Burst, FeatureIntro, PremiumShell, RecentList, SidePanel, sleep, usePremium, useReelStops } from '../../../components/Premium.jsx';
import { WinAmount } from '../../../components/GameShell.jsx';
import { Modal } from '../../../components/ui.jsx';
import { Gong, TD_NAMES, TDLogo, TDSym } from '../../../components/SlotArtTigerDragon.jsx';
import { tigerDragonSfx } from '../../../lib/sound.js';
import { TD_DECOR, TD_PANEL } from '../../../assets/tigerdragon/index.js';
import HEADER from '../../../assets/tigerdragon/header.webp';
import HEADER_M from '../../../assets/tigerdragon/header_m.webp';
import { money } from '../../../lib/format.js';
import {
  ARROW_CHANCE, BONUS_ROWS, BUY_COMBINED_X, BUY_RANDOM_WEIGHTS, BUY_RANDOM_X, COMBINED_TRIGGER, CREDITS_PER_SPIN, DRAGON_TRIGGER, JACKPOT_GONGS, JACKPOT_X,
  MAX_WIN_X, PAYTABLE, RESPINS, ROWS, STAKES, START_ROWS, TIGER_TRIGGER, UNLOCKS,
} from '../../../../../server/games/tigerdragon/config.js';

const REELS = 5;
const C = (s) => ({ s });
const START = [['LANTERN', 'TIGER', 'FAN'], ['ENVELOPE', 'LOTUS', 'BANGLE'], ['DRAGON', 'LANTERN', 'ORNAMENT'], ['FAN', 'ENVELOPE', 'LOTUS'], ['BANGLE', 'ORNAMENT', 'LANTERN']].map((c) => c.map(C));
const BLUR = ['ENVELOPE', 'FAN', 'LOTUS', 'TIGER', 'BANGLE', 'LANTERN', 'ORNAMENT', 'DRAGON'];
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v ? '1' : '0'); } catch { /* private mode */ } };
const devMode = () => { try { return location.hash.includes('dev') || localStorage.getItem('vb_dev') === '1'; } catch { return false; } };
const key = (c, r) => `${c}-${r}`;
const NAME = { tiger: 'Tiger Bonus', dragon: 'Dragon Bonus', combined: 'Tiger & Dragon Bonus' };

/** Painted backdrop: red lacquer, pagoda, swinging lanterns, drifting gold clouds. */
function Backdrop({ type }) {
  return (
    <div className={`td-bg absolute inset-0 overflow-hidden ${type === 'dragon' ? 'td-bg-dragon' : type === 'combined' ? 'td-bg-both' : ''}`}>
      <img src={TD_DECOR.pagoda} alt="" className="absolute bottom-[6%] left-1/2 w-[38%] -translate-x-1/2 opacity-25" />
      <img src={TD_DECOR.lantern} alt="" className="td-swing absolute -top-2 left-[3%] w-[9%] max-w-[54px] opacity-90" />
      <img src={TD_DECOR.lantern} alt="" className="td-swing absolute -top-2 right-[3%] w-[9%] max-w-[54px] opacity-90" style={{ animationDelay: '-1.3s' }} />
      <img src={TD_DECOR.cloud} alt="" className="td-drift absolute -bottom-2 left-[-6%] w-[46%] opacity-70" />
      <img src={TD_DECOR.cloud2} alt="" className="td-drift absolute -bottom-1 right-[-8%] w-[50%] opacity-60" style={{ animationDelay: '-6s', animationDirection: 'reverse' }} />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(0,0,0,.55)_100%)]" />
    </div>
  );
}
const nextUnlock = (count) => UNLOCKS.find(([at]) => count < at);

// ── Base reels ────────────────────────────────────────────────
function Reel({ index, cells, spinning, landKey, lit, turbo, tease, gongs }) {
  return (
    <div className={`relative overflow-hidden ${index ? 'td-divider' : ''} ${tease ? 'td-tease' : ''}`} style={{ aspectRatio: `1 / ${ROWS}` }}>
      {spinning ? (
        <div className={`p3-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 60}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-1 opacity-80 blur-[1.5px]"><TDSym s={BLUR[(k * 3 + index * 2) % BLUR.length]} bare /></div>)}
        </div>
      ) : (
        <div key={landKey} className="p3-land-bounce">
          {cells.map((cell, row) => {
            const k = key(index, row), on = lit?.has(k), g = gongs?.[k];
            const scatter = cell.s === 'TIGER' || cell.s === 'DRAGON';
            return (
              <div key={row} className={`relative aspect-square ${scatter ? 'p-0.5' : 'p-1'} ${lit?.size && !on && !g ? 'p3-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'p3-win' : ''} ${scatter && on ? 'td-roar' : ''}`} style={{ '--glow': cell.s === 'DRAGON' ? '#34d399' : '#fbbf24' }}><TDSym s={cell.s} bare /></div>
                {g && <div className={`absolute inset-0 p-0.5 td-drop ${g.lit ? 'td-cluster' : ''}`}><Gong g={g.shown ? g.g : undefined} reveal={g.shown} tile /></div>}
                {on && <Burst key={landKey} game="tigerdragon" n={8} spread={40} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Bonus board ───────────────────────────────────────────────
function Board({ b }) {
  const rows = b.rows;
  return (
    <div className={`td-board relative mx-auto rounded-2xl p-1.5 ${b.type === 'dragon' ? 'td-board-dragon' : b.type === 'tiger' ? 'td-board-tiger' : 'td-board-both'}`}
      style={{ maxWidth: rows > 3 ? 'min(100%, calc((100dvh - 330px) * 0.625))' : undefined }}>
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${REELS}, minmax(0, 1fr))` }}>
        {Array.from({ length: rows }, (_, r) => {
          const closed = b.type === 'combined' && r < BONUS_ROWS - b.open;
          const opening = b.opening?.includes(r);
          const need = closed ? UNLOCKS.find(([, n]) => n === BONUS_ROWS - r)?.[0] : null;
          return Array.from({ length: REELS }, (_, c) => {
            const k = key(c, r), cell = b.cells[k];
            if (closed) {
              return (
                <div key={k} className="td-shut relative aspect-square rounded-lg">
                  {c === 2 && <span className="absolute inset-0 flex flex-col items-center justify-center text-center text-[9px] font-extrabold leading-tight text-amber-200/90 sm:text-[11px]"><span aria-hidden="true">🔒</span>{need} gongs</span>}
                </div>
              );
            }
            return (
              <div key={k} className={`relative aspect-square rounded-lg ${opening ? 'td-open' : ''} ${cell ? '' : 'bg-black/45 ring-1 ring-amber-300/15'}`}>
                {cell && (
                  <div className={`absolute inset-0 ${cell.fresh ? 'td-drop' : ''} ${cell.lit ? 'td-cluster' : ''} ${cell.dim ? 'opacity-45' : ''}`}>
                    <Gong g={cell.shown ? cell.g : undefined} locked={!cell.shown} reveal={cell.shown} />
                    {cell.fresh && <Burst game="tigerdragon" n={8} spread={36} />}
                  </div>
                )}
              </div>
            );
          });
        })}
      </div>
    </div>
  );
}

function BonusHud({ b }) {
  const next = b.type === 'combined' ? nextUnlock(b.count) : null;
  return (
    <div className="mb-1.5 grid grid-cols-3 items-center gap-1.5 text-center">
      <div className="rounded-lg bg-black/55 px-1.5 py-1 ring-1 ring-amber-300/30">
        <div className="text-[9px] font-bold uppercase tracking-wider text-amber-200/80">{b.type === 'dragon' ? 'Spin' : 'Spins left'}</div>
        <div className="flex justify-center gap-1 py-0.5" aria-label={`${b.spinsLeft} spins left`}>
          {Array.from({ length: b.type === 'dragon' ? 1 : RESPINS }, (_, i) => <span key={i} className={`h-3 w-3 rounded-full ${i < b.spinsLeft ? 'bg-amber-300 shadow-[0_0_8px_#fcd34d]' : 'bg-white/15'} ${b.reset && i < b.spinsLeft ? 'td-pop' : ''}`} />)}
        </div>
      </div>
      <div className="rounded-lg bg-black/55 px-1.5 py-1 ring-1 ring-amber-300/30">
        <div className="text-[9px] font-bold uppercase tracking-wider text-amber-200/80">Gongs</div>
        <div className="font-cond text-xl font-extrabold leading-none text-white tabular-nums">{b.count}{b.type === 'combined' && <span className="text-xs text-amber-200/70"> / {JACKPOT_GONGS}</span>}</div>
      </div>
      <div className="rounded-lg bg-black/55 px-1.5 py-1 ring-1 ring-amber-300/30">
        <div className="text-[9px] font-bold uppercase tracking-wider text-amber-200/80">{b.type === 'combined' ? 'Rows open' : 'Grid'}</div>
        <div className="text-[11px] font-bold leading-tight text-white">{b.type === 'combined' ? <>{b.open} / 8{next && <span className="block text-[9px] font-semibold text-amber-200/70">next at {next[0]}</span>}</> : `5 × ${b.rows}`}</div>
      </div>
    </div>
  );
}

/** Cluster read-out: "5 · 3 · ↑5 → 853" and its win. */
function ClusterLine({ k, bet }) {
  return (
    <div className="td-pop flex items-center justify-between gap-2 rounded-lg bg-black/55 px-2 py-1 text-xs ring-1 ring-amber-300/40">
      <span className="flex flex-wrap items-center gap-1 font-bold text-amber-100">
        {k.gongs.map((g, i) => <span key={i} className={`rounded px-1 ${g.a != null ? 'bg-green-700 text-white' : 'bg-amber-200 text-red-900'}`}>{g.a != null ? `↑${g.a}` : g.n}</span>)}
        <span className="text-white/70">→</span><span className="font-cond text-sm text-white">{k.text}</span>
      </span>
      <span className="shrink-0 font-bold text-amber-300 tabular-nums">{money(k.win)}</span>
    </div>
  );
}

export default function TigerDragon() {
  const { user, view, history, play, commit, guard: rawGuard, shake, doShake } = usePremium('tigerdragon');
  const fx = useMemo(() => tigerDragonSfx(), []);
  const reels = useReelStops(REELS);
  const [cells, setCells] = useState(START);
  const [lit, setLit] = useState(null);
  const [gongs, setGongs] = useState(null);         // Mystery Gongs on the reels
  const [spinning, setSpinning] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [tease, setTease] = useState([]);
  const [stake, setStake] = useState(150);
  const [res, setRes] = useState(null);
  const [board, setBoard] = useState(null);         // bonus in progress on screen
  const [clusters, setClusters] = useState([]);
  const [intro, setIntro] = useState(null);
  const [summary, setSummary] = useState(null);
  const [big, setBig] = useState(null);
  const [buyOpen, setBuyOpen] = useState(false);
  const [banner, setBanner] = useState(null);
  const [running, setRunning] = useState(false);
  const [turbo, setTurbo] = useState(() => pref('td_turbo', false));
  const [session, setSession] = useState({ staked: 0, won: 0 });
  const [dev] = useState(devMode);
  const bigResolve = useRef(null);
  const introResolve = useRef(null);
  const resumed = useRef(false);
  const fast = (ms) => (turbo ? ms * 0.45 : ms);
  const balance = user?.balance ?? 0;
  const mode = view?.mode || 'base';
  const busy = spinning || running || !!intro || !!summary || !!big;

  const guard = (fn) => rawGuard(fn);
  const track = (out) => { if (out && !out.practice) setSession((s) => ({ staked: s.staked + (out.staked || 0), won: s.won + (out.win || 0) })); };
  const celebrate = (amount, bet, title) => new Promise((r) => {
    if (!amount || amount < bet * 10) return r();
    bigResolve.current = r;
    setBig({ amount, title });
  });
  const waitIntro = (data) => new Promise((r) => { introResolve.current = r; setIntro(data); });

  // ── Bonus: show the board, run every respin, settle ─────────
  const runBonus = useCallback(async (type, bet, startCells, { resume = false, practice = false } = {}) => {
    setRunning(true);
    const rows = type === 'tiger' ? ROWS : BONUS_ROWS;
    let b = { type, bet, rows, open: type === 'combined' ? START_ROWS : rows, cells: {}, spinsLeft: type === 'dragon' ? 1 : RESPINS, count: 0, practice };
    for (const k of startCells || []) b.cells[k] = { fresh: true };
    b.count = Object.keys(b.cells).length;
    if (resume && view?.bonus) b = { ...b, open: view.bonus.open, spinsLeft: view.bonus.spinsLeft, count: view.bonus.count, cells: Object.fromEntries(view.bonus.locked.map((k) => [k, {}])) };
    setBoard(b);
    if (type === 'tiger') fx.roarTiger(); else if (type === 'dragon') fx.roarDragon(); else { fx.roarTiger(); setTimeout(() => fx.roarDragon(), 500); }
    await waitIntro({ type, resume, practice });
    fx.bonusStart();
    if (startCells?.length) { startCells.forEach((_, i) => setTimeout(() => fx.gongLock(), i * 120)); await sleep(fast(700)); }
    // respins until the server says the round is over
    for (let guardN = 0; guardN < 80; guardN++) {
      await sleep(fast(type === 'dragon' ? 500 : 650));
      const out = await play('respin', {}, { quiet: false });
      if (!out) { setRunning(false); return; }
      // land
      const fresh = {};
      out.lands.forEach((k) => { fresh[k] = { fresh: true }; });
      b = { ...b, cells: { ...Object.fromEntries(Object.entries(b.cells).map(([k, v]) => [k, { ...v, fresh: false }])), ...fresh }, count: out.count, spinsLeft: out.spinsLeft, reset: out.lands.length > 0 && type !== 'dragon' };
      setBoard(b);
      out.lands.forEach((_, i) => setTimeout(() => fx.gongLand(i), i * fast(90)));
      if (out.lands.length) { await sleep(fast(300 + Math.min(8, out.lands.length) * 60)); fx.gongLock(); }
      if (out.unlocked?.length) {
        const opening = out.unlocked.map((n) => BONUS_ROWS - n);
        b = { ...b, open: out.open, opening };
        setBoard(b);
        fx.unlock(out.open);
        doShake(false);
        await sleep(fast(900));
        b = { ...b, opening: [] };
      }
      setBoard({ ...b });
      if (out.result) { await settle(out, b); return; }
    }
    setRunning(false);
  }, [view, fx, play, turbo]); // eslint-disable-line react-hooks/exhaustive-deps

  const settle = async (out, b) => {
    const r = out.result;
    // reveal every gong's value, left to right, top to bottom
    const keys = Object.keys(r.cells).sort((a, z) => { const [ac, ar] = a.split('-').map(Number), [zc, zr] = z.split('-').map(Number); return ar - zr || ac - zc; });
    if (r.jackpot) {
      fx.jackpot(); doShake(true);
      setBoard({ ...b, cells: Object.fromEntries(keys.map((k) => [k, { g: r.cells[k], shown: true, lit: true }])), jackpot: true });
      await sleep(1800);
    } else {
      let shown = { ...b.cells };
      for (let i = 0; i < keys.length; i++) {
        shown = { ...shown, [keys[i]]: { g: r.cells[keys[i]], shown: true } };
        setBoard({ ...b, cells: shown });
        if (r.cells[keys[i]].a != null) fx.arrow(); else fx.reveal(i);
        await sleep(fast(keys.length > 20 ? 70 : 130));
      }
      await sleep(fast(400));
      const inCluster = new Set(r.clusters.flatMap((k) => k.cells.map(([c, rr]) => key(c, rr))));
      setBoard({ ...b, cells: Object.fromEntries(keys.map((k) => [k, { g: r.cells[k], shown: true, lit: inCluster.has(k), dim: !inCluster.has(k) }])) });
      const list = [];
      for (let i = 0; i < r.clusters.length; i++) {
        list.push(r.clusters[i]); setClusters([...list]); fx.cluster(i);
        await sleep(fast(650));
      }
    }
    setRes({ win: out.win, staked: 0, bonus: r });
    track(out);
    await celebrate(out.win, b.bet, r.jackpot ? 'JACKPOT!' : null);
    if (out.win) fx.coins(Math.min(24, 6 + Math.round(out.win / b.bet)));
    commit();
    setSummary({ ...r, practice: b.practice || out.practice, win: out.win });
  };

  const endSummary = () => { setSummary(null); setBoard(null); setClusters([]); setRunning(false); };

  // Resume a bonus that was in progress (page reload, app switch)
  useEffect(() => {
    if (resumed.current || !view || view.mode === 'base' || board) return;
    resumed.current = true;
    runBonus(view.mode, view.bonus.bet, [], { resume: true, practice: view.practice });
  }, [view]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Base spin ───────────────────────────────────────────────
  const spin = () => guard(async () => {
    if (busy || mode !== 'base') return;
    setLit(null); setGongs(null); setRes(null); setClusters([]);
    setSpinning(true); setSpinId((n) => n + 1); reels.start(); fx.spin?.();
    const out = await play('spin', { stake });
    if (!out) { reels.stopNow(); setSpinning(false); return; }
    await showSpin(out);
  });

  const showSpin = async (out) => {
    setCells(out.grid);
    // tease the later reels when 2+ Tiger/Dragon are already showing
    const scat = out.grid.map((col) => col.filter((c) => c.s === 'TIGER' || c.s === 'DRAGON').length);
    const teaseReels = [];
    let seen = 0;
    scat.forEach((n, i) => { if (seen >= 2 && i > 0) teaseReels.push(i); seen += n; });
    setTease(turbo ? [] : teaseReels);
    let shownScat = 0;
    await reels.stopAll({ turbo, tease: turbo ? [] : teaseReels, onStop: (i) => { fx.stop(i); if (scat[i]) { shownScat += scat[i]; fx.scatter(shownScat); } } });
    setTease([]);
    setSpinning(false);
    const winCells = new Set(out.wins.flatMap((w) => w.cells.map(([c, r]) => key(c, r))));
    if (out.trigger) out.grid.forEach((col, c) => col.forEach((x, r) => { if ((out.trigger === 'tiger' && x.s === 'TIGER') || (out.trigger === 'dragon' && x.s === 'DRAGON') || (out.trigger === 'combined' && (x.s === 'TIGER' || x.s === 'DRAGON'))) winCells.add(key(c, r)); }));
    if (winCells.size) setLit(winCells);
    if (out.wins.length) fx.win?.(Math.min(3, out.wins.length));
    // Mystery Gongs: drop onto the reels, reveal values, pay clusters
    if (out.mystery) {
      setBanner('mystery'); fx.bonusStart(); await sleep(fast(1100)); setBanner(null);
      const keys = Object.keys(out.mystery.cells);
      let g = {};
      for (let i = 0; i < keys.length; i++) { g = { ...g, [keys[i]]: { g: out.mystery.cells[keys[i]], shown: false } }; setGongs(g); fx.gongLand(i); await sleep(fast(220)); }
      await sleep(fast(300));
      g = Object.fromEntries(keys.map((k) => [k, { g: out.mystery.cells[k], shown: true }]));
      setGongs(g); keys.forEach((_, i) => setTimeout(() => fx.reveal(i), i * 60));
      await sleep(fast(600));
      const inC = new Set(out.mystery.clusters.flatMap((k) => k.cells.map(([c, r]) => key(c, r))));
      setGongs(Object.fromEntries(keys.map((k) => [k, { g: out.mystery.cells[k], shown: true, lit: inC.has(k) }])));
      setClusters(out.mystery.clusters);
      if (out.mystery.clusters.length) { out.mystery.clusters.forEach((_, i) => setTimeout(() => fx.cluster(i), i * 200)); doShake(false); }
    }
    setRes({ win: out.win, staked: out.staked, wins: out.wins, mystery: out.mystery, practice: out.practice });
    track(out);
    await celebrate(out.win, out.bet, null);
    commit();
    if (out.started) {
      await sleep(fast(700));
      setLit(null); setGongs(null); setClusters([]);
      await runBonus(out.started, out.bet, out.startCells || [], { practice: out.practice });
    }
  };

  const buy = (option) => guard(async () => {
    setBuyOpen(false);
    if (busy || mode !== 'base') return;
    setLit(null); setGongs(null); setRes(null); setClusters([]);
    const out = await play('buy', { stake, option });
    if (!out) return;
    track(out);
    commit();
    await runBonus(out.started, out.bet, out.startCells || []);
  });

  const devRun = (event) => guard(async () => {
    if (busy || mode !== 'base') return;
    setLit(null); setGongs(null); setRes(null); setClusters([]);
    if (event === 'mystery') {
      setSpinning(true); reels.start();
      const out = await play('dev', { event, stake });
      if (!out) { reels.stopNow(); setSpinning(false); return; }
      await showSpin(out);
      return;
    }
    const out = await play('dev', { event, stake });
    if (!out) return;
    await runBonus(out.started, stake, out.startCells || [], { practice: true });
  });

  // space bar spins on desktop
  useEffect(() => {
    const h = (e) => { if (e.code === 'Space' && !['INPUT', 'TEXTAREA', 'BUTTON'].includes(document.activeElement?.tagName)) { e.preventDefault(); spin(); } };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  });

  const i = Math.max(0, STAKES.indexOf(stake));
  const low = stake > balance;
  const randomCost = stake * BUY_RANDOM_X, comboCost = stake * BUY_COMBINED_X;
  const detail = res?.bonus ? (res.bonus.jackpot ? `JACKPOT · ${res.bonus.gongs} gongs` : `${NAME[res.bonus.type]} · ${res.bonus.clusters.length} cluster${res.bonus.clusters.length === 1 ? '' : 's'}`)
    : res?.mystery ? (res.mystery.clusters.length ? `Mystery Gongs · ${res.mystery.clusters.length} cluster${res.mystery.clusters.length === 1 ? '' : 's'}` : 'Mystery Gongs did not connect')
      : res?.wins?.length ? res.wins.slice(0, 2).map((w) => `${w.count} ${TD_NAMES[w.symbol]} × ${w.ways} way${w.ways > 1 ? 's' : ''}`).join(' · ') : null;

  const header = (
    <div className="relative -mx-2 -mt-2 mb-2 overflow-hidden rounded-t-2xl sm:-mx-4 sm:-mt-4">
      <img src={HEADER_M} alt="" className="h-[clamp(72px,22vw,120px)] w-full object-cover md:hidden" />
      <img src={HEADER} alt="" className="hidden h-[clamp(90px,14vw,150px)] w-full object-cover md:block" />
      <div className="absolute inset-y-0 left-1/2 flex w-[42%] max-w-[300px] -translate-x-1/2 items-center justify-center md:w-[34%]"><TDLogo textOnly className="h-[80%] w-full drop-shadow-[0_4px_10px_rgba(0,0,0,.7)]" /></div>
      <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-transparent via-amber-300 to-transparent" />
    </div>
  );
  const buyPanel = (
    <div className="td-panel hidden flex-col gap-2 p-2 lg:flex">
      <div className="td-plaque">Bonus buy</div>
      {[['random', 'Random bonus', BUY_RANDOM_X, randomCost], ['combined', 'Tiger & Dragon bonus', BUY_COMBINED_X, comboCost]].map(([opt, l, x, cost]) => (
        <div key={opt} className="rounded-xl bg-gradient-to-b from-[#1e2a5c] to-[#0b1030] p-2 text-center ring-1 ring-amber-300/60">
          <div className="text-[11px] font-extrabold uppercase leading-tight text-amber-100">{l}</div>
          <div className="font-display text-3xl leading-none text-amber-300">{x}x</div>
          <div className="text-[10px] font-bold uppercase text-amber-100/80">bet · {money(cost)}</div>
          <button onClick={() => buy(opt)} disabled={busy || mode !== 'base' || cost > balance} className="td-btn-red mt-1.5 h-9 w-full text-sm">Buy</button>
        </div>
      ))}
    </div>
  );
  const featurePanel = (
    <div className="td-panel hidden flex-col gap-2 p-2 lg:flex">
      {['tiger', 'dragon', 'combined'].map((t) => <img key={t} src={TD_PANEL[t]} alt={NAME[t]} className={`w-full rounded-lg ${board && board.type !== t ? 'opacity-40' : ''} ${board?.type === t ? 'td-cluster' : ''}`} />)}
    </div>
  );
  const stage = board ? (
    <div className="relative">
      <BonusHud b={board} />
      <Board b={board} />
      {board.jackpot && <div className="td-pop pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center"><img src={TD_PANEL.jackpot} alt="Jackpot" className="w-[78%] max-w-[300px] drop-shadow-[0_0_30px_rgba(252,211,77,.8)]" /><div className="mt-1 rounded-full bg-black/70 px-4 py-1 text-sm font-bold text-amber-200">{JACKPOT_GONGS} gongs collected</div><Burst game="tigerdragon" n={30} spread={150} /></div>}
    </div>
  ) : (
    <div className="relative">
      {banner && <div className="td-pop pointer-events-none absolute inset-0 z-20 flex items-center justify-center"><img src={TD_PANEL[banner]} alt="Mystery Gong" className="w-[70%] max-w-[280px] drop-shadow-[0_0_24px_rgba(232,121,249,.7)]" /></div>}
      <div className="td-reelset grid" style={{ gridTemplateColumns: `repeat(${REELS}, minmax(0, 1fr))` }}>
        {cells.map((col, c) => <Reel key={c} index={c} cells={col} spinning={spinning && !reels.stopped[c]} landKey={`${spinId}-${c}`} lit={lit} turbo={turbo} tease={tease.includes(c) && spinning && !reels.stopped[c]} gongs={gongs} />)}
      </div>
    </div>
  );

  const info = (
    <>
      <section>
        <h3 className="mb-1 font-bold text-white">How it plays</h3>
        <p>5 reels, 3 rows, 243 ways: a symbol pays when it lands on reel 1 and on each neighbouring reel after it (3, 4 or 5 reels). Every combination of positions is a way, and pays are per way.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Paytable (multiples of the stake, per way)</h3>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(PAYTABLE).map(([s, p]) => (
            <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
              <div className="h-10 w-10 shrink-0"><TDSym s={s} /></div>
              <div className="text-[11px] leading-tight">{p.map((x, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{(x / 100).toFixed(2)}x</b> <span className="text-slate-500">({money(Math.floor((stake * x) / 100))})</span></div>)}</div>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Gongs and clusters</h3>
        <p>Each gong shows a number from 1 to 99 or an Arrow. A cluster is 2 or more gongs side by side in the same row; gongs above, below or diagonal do not connect. A cluster's numbers are read left to right as one number (5, 3, 8 reads 538). Each Arrow in a cluster adds its value (1 to 90) to the leftmost number first (an Arrow +5 turns 1, 2 into 62). The number is credits: {CREDITS_PER_SPIN} credits = your stake, so at {money(stake)} a 538 cluster pays {money(Math.floor((538 * stake) / CREDITS_PER_SPIN))}. Every cluster pays; a lone gong pays nothing.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Mystery Gongs</h3>
        <p>After a spin with no regular win, gongs can drop onto random spots on the reels. If they form clusters, the clusters pay.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Tiger Bonus · {TIGER_TRIGGER} Tigers</h3>
        <p>Hold &amp; Respin on 5 × 3. The Tigers that triggered it become the first gongs. You get {RESPINS} spins; only gongs land. Every gong locks in place for the rest of the round and resets the spins to {RESPINS}. It ends when the spins run out or all 15 spots are filled; then every cluster reveals and pays.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Dragon Bonus · {DRAGON_TRIGGER} Dragons</h3>
        <p>Exactly one spin on a 5 × 8 grid of gongs. Every cluster then reveals and pays.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Tiger &amp; Dragon Bonus · {COMBINED_TRIGGER}+ Tigers and Dragons together</h3>
        <p>5 × 8 grid with the bottom {START_ROWS} rows open; the Tigers and Dragons that triggered it become the first gongs. {RESPINS} spins, reset by every new gong. Rows open as you collect gongs: {UNLOCKS.map(([at, n]) => `${at} gongs open row ${n}`).join(', ')}. A newly opened row is in play from the next spin. Collect {JACKPOT_GONGS} gongs to win the jackpot ({JACKPOT_X.toLocaleString()}x your stake), which replaces the cluster pays. Otherwise every cluster reveals and pays when the spins run out or the grid fills.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Bonus buy</h3>
        <p>Random bonus: {BUY_RANDOM_X}x the stake for the Tiger, Dragon or Tiger &amp; Dragon Bonus (chances {BUY_RANDOM_WEIGHTS.map(([t, w]) => `${NAME[t]} ${w}%`).join(', ')}). Tiger &amp; Dragon Bonus: {BUY_COMBINED_X}x the stake.</p>
      </section>
      <section className="text-xs text-slate-400">
        <p>Return to player is about 96% over the long run, including bonus buys (about 96% each). Maximum win {MAX_WIN_X.toLocaleString()}x the stake per spin or bonus. Gong values: about {Math.round(ARROW_CHANCE * 100)}% are Arrows.</p>
        <p className="mt-1">This game reproduces the published rules of a well-known gong slot. Its probabilities (symbol weights, how often gongs land, gong values, the jackpot size and the Mystery Gong rate) are not public, so they were set by simulation to reach a 96% return. They are not the original game's numbers.</p>
      </section>
    </>
  );

  const win = res?.win || 0;
  const bar = (
    <div className="td-bar sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2 md:static">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-1.5">
        <div className="td-box"><span>Balance</span><b>{money(balance)}</b></div>
        <div className="td-box items-center gap-1 px-1" style={{ flexDirection: 'row' }}>
          <button className="td-round h-8 w-8 text-lg" disabled={busy || i <= 0} onClick={() => setStake(STAKES[i - 1])} aria-label="Lower stake">−</button>
          <div className="flex min-w-[3.8rem] flex-col items-center"><span>Bet</span><b>{money(stake)}</b></div>
          <button className="td-round h-8 w-8 text-lg" disabled={busy || i >= STAKES.length - 1} onClick={() => setStake(STAKES[i + 1])} aria-label="Raise stake">+</button>
        </div>
        <div className="td-box"><span>Win</span><b className={win ? 'text-amber-300' : ''}>{money(win)}</b></div>
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
        <button onClick={() => setBuyOpen(true)} disabled={busy || mode !== 'base'} className="td-btn-red h-11 text-xs lg:invisible">Buy bonus</button>
        <button onClick={spin} disabled={busy || low || mode !== 'base'} aria-label={spinning ? 'Spinning' : running ? 'Bonus in play' : low ? 'Not enough balance' : 'Spin'} title={low ? 'Not enough balance' : 'Spin'}
          className="td-spin relative flex h-[72px] w-[72px] items-center justify-center rounded-full disabled:opacity-60">
          <svg viewBox="0 0 48 48" className={`h-10 w-10 ${spinning || running ? 'animate-spin' : ''}`} fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M38 18a16 16 0 0 0-28-3" /><path d="M10 6v9h9" /><path d="M10 30a16 16 0 0 0 28 3" /><path d="M38 42v-9h-9" />
          </svg>
        </button>
        <div className="flex justify-end gap-1.5">
          <button onClick={() => setTurbo((t) => { save('td_turbo', !t); return !t; })} className={`td-btn-blue h-11 px-3 text-xs ${turbo ? 'ring-2 ring-amber-300' : ''}`} aria-pressed={turbo}>{turbo ? 'Turbo on' : 'Turbo'}</button>
        </div>
      </div>
      {low && !busy && <p className="text-center text-[11px] font-semibold text-amber-300">Not enough balance for this bet</p>}
      {dev && (
        <div className="flex flex-wrap gap-1 border-t border-white/10 pt-2 text-[11px]" aria-label="Practice triggers">
          <span className="w-full text-amber-200/70">Practice (no cost, no pay):</span>
          {[['tiger', 'Tiger'], ['dragon', 'Dragon'], ['combined', 'Tiger & Dragon'], ['jackpot', '32-gong jackpot'], ['mystery', 'Mystery Gongs']].map(([e, l]) => (
            <button key={e} onClick={() => devRun(e)} disabled={busy || mode !== 'base'} className="h-8 rounded-md bg-navy-700 px-2 font-semibold text-slate-200 disabled:opacity-40">{l}</button>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <PremiumShell game="tigerdragon" rtp="96%" title="Gong Fortune" tagline="5 × 3 · 243 ways · Tiger, Dragon and Tiger & Dragon bonuses · Mystery Gongs" shake={shake}
      stageClass="border-2 border-amber-400/50 shadow-[0_0_50px_rgba(220,38,38,0.35)]" bg={<Backdrop type={board?.type} />} info={info}
      below={<>{bar}
        <div className="space-y-1">{clusters.map((k, n) => <ClusterLine key={n} k={k} bet={stake} />)}</div>
      </>}
      side={<>
        <SidePanel title="This session">
          <div className="flex justify-between text-xs"><span className="text-slate-400">Staked</span><b className="tabular-nums text-white">{money(session.staked)}</b></div>
          <div className="flex justify-between text-xs"><span className="text-slate-400">Won</span><b className="tabular-nums text-white">{money(session.won)}</b></div>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      {header}
      <div className="mb-2 flex min-h-11 flex-col items-center justify-center rounded-xl bg-black/50 px-2 py-1 text-center leading-tight ring-1 ring-amber-300/20">
        {board ? (
          <div className="text-sm font-bold text-amber-100">{NAME[board.type]}{board.practice ? ' · practice' : ''}<span className="block text-[11px] font-medium text-white/70">{board.type === 'dragon' ? 'One spin: clusters of 2+ gongs pay' : 'New gongs lock and reset the spins'}</span></div>
        ) : res?.win ? <><WinAmount win={res.win} staked={res.staked} /><div className="mt-0.5 text-[11px] text-white/75">{detail}</div></>
          : <div className="text-sm text-white/65">{spinning ? 'Spinning…' : res ? (detail || 'No win this time') : `${TIGER_TRIGGER} Tigers, ${DRAGON_TRIGGER} Dragons or ${COMBINED_TRIGGER}+ together start a bonus`}</div>}
      </div>
      <div className="lg:grid lg:grid-cols-[132px_minmax(0,1fr)_132px] lg:items-start lg:gap-2">{buyPanel}<div className="min-w-0">{stage}</div>{featurePanel}</div>

      {intro && (
        <FeatureIntro title={intro.resume ? 'WELCOME BACK' : ''}
          className={intro.type === 'dragon' ? 'bg-[radial-gradient(ellipse_at_top,rgba(6,95,70,.95),rgba(2,10,8,.97))]' : 'bg-[radial-gradient(ellipse_at_top,rgba(185,28,28,.95),rgba(20,4,4,.97))]'}
          art={<img src={TD_PANEL[intro.type]} alt="" className="td-pop relative mb-2 w-[72%] max-w-[300px] drop-shadow-[0_0_24px_rgba(0,0,0,.6)]" />}
          subtitle={intro.resume ? 'Your bonus is still in progress. Carry on where you left off.'
            : intro.type === 'tiger' ? `Hold & Respin: ${RESPINS} spins, only gongs land. Every gong locks and resets the spins to ${RESPINS}. Clusters of 2+ gongs side by side pay at the end.`
              : intro.type === 'dragon' ? 'One spin on the 5 × 8 gong grid. Clusters of 2+ gongs side by side pay.'
                : `${START_ROWS} of 8 rows open. ${UNLOCKS.map(([at]) => at).join(' / ')} gongs open the next rows. ${RESPINS} spins, reset by every gong. ${JACKPOT_GONGS} gongs wins the jackpot.`}
          cta={intro.practice ? 'Start practice' : 'Strike the gong'}
          onStart={() => { setIntro(null); introResolve.current?.(); introResolve.current = null; }} />
      )}
      {summary && (
        <FeatureIntro title={summary.jackpot ? 'JACKPOT!' : 'BONUS COMPLETE'} cta="Back to the reels" onStart={endSummary}
          className="bg-[radial-gradient(ellipse_at_top,rgba(180,83,9,.95),rgba(20,4,4,.97))]"
          subtitle={`${NAME[summary.type]}: ${summary.gongs} gongs${summary.jackpot ? ` · jackpot ${JACKPOT_X.toLocaleString()}x` : `, ${summary.clusters.length} paying cluster${summary.clusters.length === 1 ? '' : 's'}`}. ${summary.practice ? 'Practice round: nothing was paid.' : summary.win ? `You win ${money(summary.win)}${summary.capped ? ` (capped at ${MAX_WIN_X.toLocaleString()}x)` : ''}.` : 'No clusters this time.'}`} />
      )}
      {big && <BigWin game="tigerdragon" amount={big.amount} bet={board?.bet || stake} title={big.title} onDone={() => { setBig(null); bigResolve.current?.(); bigResolve.current = null; }} />}

      <Modal open={buyOpen} onClose={() => setBuyOpen(false)} title="Buy a bonus">
        <div className="space-y-3">
          <img src={TD_PANEL.buy} alt="" className="mx-auto w-32" />
          <p className="text-sm text-slate-300">Starts the bonus straight away at your current stake of <b className="text-white">{money(stake)}</b>. Virtual money only.</p>
          {[['random', 'Random bonus', `Tiger, Dragon or Tiger & Dragon Bonus`, randomCost, BUY_RANDOM_X], ['combined', 'Tiger & Dragon Bonus', `5 × 8 with unlocking rows and the ${JACKPOT_GONGS}-gong jackpot`, comboCost, BUY_COMBINED_X]].map(([opt, title, sub, cost, x]) => (
            <button key={opt} onClick={() => buy(opt)} disabled={cost > balance} className="flex w-full items-center justify-between gap-3 rounded-2xl border border-amber-400/30 bg-gradient-to-br from-red-900/60 to-[#1a0606] p-3 text-left disabled:opacity-40">
              <div className="min-w-0"><div className="font-bold text-white">{title}</div><div className="text-xs text-slate-300">{sub}</div><div className="mt-0.5 text-[11px] text-amber-200/80">{x}x stake</div></div>
              <div className="shrink-0 rounded-xl bg-amber-400 px-3 py-2 text-sm font-extrabold text-red-950">{money(cost)}</div>
            </button>
          ))}
          {randomCost > balance && <p className="text-xs text-amber-300">Lower your stake or add virtual funds to buy a bonus.</p>}
        </div>
      </Modal>
    </PremiumShell>
  );
}
