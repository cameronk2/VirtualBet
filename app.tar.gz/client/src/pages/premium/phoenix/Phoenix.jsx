// Phoenix Ember Link – game screen. Every result comes from the server before anything moves;
// this file only reveals it: 5 x 3 reels on 20 lines, five eggs that light up (and may hatch at random) when coloured Fireballs land,
// the Area Link hold-and-win bonus (one or two arrays) with its five upgrades, Phoenix Firestorm,
// four jackpots and tiered win celebrations.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { BigWin, Burst, FeatureIntro, PremiumShell, RecentList, SidePanel, sleep, usePremium, useReelStops, reduceMotion } from '../../../components/Premium.jsx';
import { WinAmount } from '../../../components/GameShell.jsx';
import { PH } from '../../../assets/phoenix/index.js';
import { playCue, playSample, playSting, playVoice, preloadUrls, registerTracks, registerVoiceGame, setMusicScene } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import {
  BASE_COLOURS, EGG_CHANCE, FIRESTORM_CHANCE, JACKPOTS, LINES, MULTIPLIERS, PAYTABLE, RESPINS, ROWS, STAKES, TRIGGER, UPGRADES, BLUE_HITS, MAGENTA_START, DEFAULT_STAKE,
} from '../../../../../server/games/phoenix/config.js';

const REELS = 5;
const key = (c, r) => `${c}-${r}`;
const ALL = Array.from({ length: 15 }, (_, i) => key(i % 5, Math.floor(i / 5)));
const C = (s) => ({ s });
const START = [['FEATHER', 'A', 'RED'], ['K', 'WILD', 'Q'], ['ORANGE', 'WILD', 'J'], ['T', 'WILD', 'PURPLE'], ['N', 'GREEN', 'A']].map((c) => c.map(C));
const BLUR = ['A', 'ORANGE', 'K', 'FEATHER', 'Q', 'RED', 'J', 'PURPLE', 'T', 'GREEN', 'N', 'WILD'];
export const COL = { yellow: '#facc15', orange: '#fb923c', magenta: '#e879f9', red: '#f43f5e', blue: '#60a5fa', green: '#4ade80', phoenix: '#fde68a' };
const UPNAME = { orange: 'Multiplier', magenta: 'Second Array', red: 'Instant Collect', blue: 'Prize Boost', green: 'Prize Increase' };
const UPDESC = {
  orange: 'Every respin draws a 2x, 3x or 5x multiplier for the Yellow prizes that lock on it.',
  magenta: 'A second Area Link array plays alongside the first, with its own respins.',
  red: 'Red Fireballs collect every prize on their array, then turn Yellow.',
  blue: 'Blue Fireballs add their prize to random Yellow prizes, then turn Yellow.',
  green: 'Green Fireballs grow by a random amount on every respin.',
};
const SYMNAME = { WILD: 'Phoenix Wild', FEATHER: 'Phoenix Feather', ORANGE: 'Orange Crystal', RED: 'Red Crystal', PURPLE: 'Purple Crystal', GREEN: 'Green Crystal', A: 'A', K: 'K', Q: 'Q', J: 'J', T: '10', N: '9' };
const RTP_LABEL = { 96: '96.4%', 94: '94.2%', 92: '92.3%' };
const JPNAME = { mini: 'MINI', minor: 'MINOR', major: 'MAJOR', grand: 'GRAND' };
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v === '1'; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } };
const devMode = () => { try { return location.hash.includes('dev') || localStorage.getItem('vb_dev') === '1'; } catch { return false; } };
const stakeLabel = (x) => (x < 100 ? `${x}p` : `£${x / 100}`);
/** Short prize text for a Fireball: 40p, £2, £2.50, MINI … */
export const prizeText = (x) => (x.jp ? JPNAME[x.jp] : x.v < 100 ? `${x.v}p` : x.v % 100 ? money(x.v) : `£${(x.v / 100).toLocaleString()}`);

// Recorded audio (client/audio/phoenix/{music,sfx,voice}/*.mp3), made with free tools (see tools/music/phoenix.py).
const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
const aud = (f) => (AUD.files.includes(`phoenix/${f}.mp3`) ? `${AUD.base}phoenix/${f}.mp3` : null);
const TRACKS = Object.fromEntries(['base', 'bonus', 'win', 'jackpot'].map((k) => [k, aud(`music/${k}`)]).filter(([, u]) => u));
if (TRACKS.base) registerTracks('phoenix', TRACKS);
const VOICE = Object.fromEntries(['arealink', 'firestorm', 'bigwin', 'megawin', 'epicwin', 'mini', 'minor', 'major', 'grand'].map((k) => [k, aud(`voice/${k}`)]));
if (VOICE.arealink) registerVoiceGame('phoenix');
const SFX_NAMES = ['spin', 'stop', 'stop_fb', 'wild', 'fb_land', 'egg_fill', 'egg_ready', 'egg_crack', 'firestorm', 'arealink', 'respin', 'lock', 'reset', 'tick',
  'mult', 'red', 'blue', 'green', 'magenta', 'near', 'complete', 'win_s', 'win_m', 'win_b', 'jp_mini', 'jp_minor', 'jp_major', 'jp_grand', 'coin', 'count'];
const SFX = Object.fromEntries(SFX_NAMES.map((k) => [k, aud(`sfx/${k}`)]));

// ── Backdrop: volcanic night, lava glow, drifting smoke, rising embers, the Phoenix above ──
const EMBERS = Array.from({ length: 28 }, (_, i) => ({ l: (i * 37) % 100, d: 5 + ((i * 13) % 50) / 10, delay: -((i * 29) % 70) / 10, s: 2 + ((i * 7) % 4), drift: ((i * 17) % 40) - 20 }));
function Backdrop({ bonus, storm }) {
  return (
    <div className="ph-bg absolute inset-0 overflow-hidden">
      <img src={bonus ? PH.bgBonus : PH.bg} alt="" className="ph-bg-img absolute inset-0 h-full w-full object-cover" />
      <div className="ph-lava absolute inset-x-0 bottom-0 h-[45%]" />
      <img src={PH.hero} alt="" className={`ph-hero absolute left-1/2 top-[-4%] w-[115%] max-w-[900px] ${storm ? 'storm' : ''}`} />
      <div className="ph-smoke absolute inset-0" />
      <div className="ph-smoke b absolute inset-0" />
      {EMBERS.map((e, i) => <span key={i} className="ph-ember absolute bottom-[-10px] rounded-full" style={{ left: `${e.l}%`, width: e.s, height: e.s, animationDuration: `${e.d}s`, animationDelay: `${e.delay}s`, '--drift': `${e.drift}px` }} />)}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,.6)_100%)]" />
    </div>
  );
}

// ── Symbols ──────────────────────────────────────────────────
export function Sym({ s, className = '' }) {
  return <img src={PH.sym[s]} alt={SYMNAME[s] || s} draggable="false" className={`ph-sym block h-full w-full select-none object-contain ${className}`} />;
}
/** A Fireball: the orb in its colour with its prize written across it. */
export function Fireball({ c = 'yellow', v, jp, label, fresh, size = 'md', dim, glow }) {
  const t = label ?? (v != null || jp ? prizeText({ v, jp }) : '');
  return (
    <div className={`ph-fb relative h-full w-full ${fresh ? 'ph-slam' : ''} ${dim ? 'opacity-45' : ''} ${glow ? 'ph-fb-glow' : ''}`} style={{ '--c': COL[c] || COL.yellow }}>
      <img src={PH.fb[c] || PH.fb.yellow} alt="" draggable="false" className="ph-fb-orb absolute inset-[4%] h-[92%] w-[92%] select-none" />
      {t && <span className={`ph-fb-val ${jp ? `jp ${jp}` : ''} ${size}`}>{t}</span>}
    </div>
  );
}

// ── Jackpot bar ──────────────────────────────────────────────
function Jackpots({ bet, hit }) {
  return (
    <div className="ph-jps grid grid-cols-4 gap-1">
      {['mini', 'minor', 'major', 'grand'].map((t) => (
        <div key={t} className={`ph-jp ${t} ${hit === t ? 'hit' : ''}`}>
          <span>{JPNAME[t]}</span><b>{money(JACKPOTS[t] * bet)}</b>
        </div>
      ))}
    </div>
  );
}

// ── Eggs ─────────────────────────────────────────────────────
function Eggs({ lit, pulse, opening }) {
  return (
    <div className="ph-eggs grid grid-cols-5 gap-1" aria-label="Phoenix eggs">
      {UPGRADES.map((u) => {
        const on = lit?.includes(u);
        return (
          <div key={u} data-egg={u} className={`ph-egg relative flex flex-col items-center ${on ? 'ready' : ''} ${pulse?.[u] ? 'pulse' : ''} ${opening?.includes(u) ? 'opening' : ''}`} style={{ '--c': COL[u], '--f': on ? 1 : 0.15 }}
            title={`${UPNAME[u]}${on ? ': lit' : ''}`}>
            <div className="ph-egg-img relative">
              <img src={PH.egg[u]} alt="" draggable="false" className="relative z-[1] h-full w-full object-contain" />
              <span className="ph-egg-fill" aria-hidden="true" />
            </div>
            <div className="ph-egg-label">{UPNAME[u].split(' ').pop()}</div>
          </div>
        );
      })}
    </div>
  );
}

/** Phoenix Firestorm: the Phoenix bursts out of the volcano and sweeps across the screen in a trail of fire. */
function PhoenixFlight({ on }) {
  if (!on) return null;
  return createPortal(
    <div className="ph-flight-scene pointer-events-none fixed inset-0 z-[88] overflow-hidden" aria-hidden="true">
      <div className="ph-flight-tint absolute inset-0" />
      <div className="ph-flight-trail absolute" />
      <img src={PH.flyer} alt="" className="ph-flyer absolute" />
      {EMBERS.slice(0, 18).map((e, i) => <span key={i} className="ph-flyspark absolute rounded-full" style={{ '--d': `${i * 70}ms`, '--y': `${(e.drift * 3)}px`, left: `${5 + i * 5}%`, top: `${70 - i * 3.4}%` }} />)}
    </div>, document.body);
}

// ── Base reels ───────────────────────────────────────────────
function Reel({ index, cells, spinning, landKey, lit, turbo, tease }) {
  return (
    // height fixed by padding (3 rows of square cells) so nothing inside can ever resize the reel
    <div className={`ph-reel relative h-0 overflow-hidden ${tease ? 'ph-tease' : ''}`} style={{ paddingBottom: `${ROWS * 100}%` }}>
      <div className="absolute inset-0 overflow-hidden">
      {spinning ? (
        <div className={`ph-strip ${turbo ? 'fast' : ''}`} style={{ animationDelay: `${-index * 70}ms` }}>
          {Array.from({ length: ROWS * 4 }, (_, k) => <div key={k} className="aspect-square p-[3%]"><Sym s={BLUR[(k * 5 + index * 3) % BLUR.length]} className="opacity-70" /></div>)}
        </div>
      ) : (
        <div key={landKey} className="ph-land flex h-full flex-col">
          {cells.map((cell, row) => {
            const k = key(index, row), on = lit?.has(k);
            return (
              <div key={row} data-ph={k} className={`relative min-h-0 flex-1 p-[3%] ${lit?.size && !on ? 'ph-dim' : ''}`}>
                <div className={`h-full w-full ${on ? 'ph-win' : ''} ${cell.s === 'WILD' ? 'ph-wild' : ''}`}>
                  {cell.s === 'FB' ? <Fireball {...cell.fb} glow={on} /> : <Sym s={cell.s} />}
                </div>
                {on && <Burst key={landKey} game="phoenix" n={6} spread={36} />}
              </div>
            );
          })}
        </div>
      )}
      </div>
    </div>
  );
}

/** Winning paylines drawn over the reels. */
function Paylines({ wins, show }) {
  if (!show || !wins?.length) return null;
  const pts = (line) => line.map((row, c) => `${(c + 0.5) * 20},${(row + 0.5) * (100 / 3)}`).join(' ');
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 z-10 h-full w-full" aria-hidden="true">
      {wins.slice(0, 8).map((w, i) => (
        <g key={i}>
          <polyline points={pts(LINES[w.line])} fill="none" stroke="rgba(249,115,22,.45)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" className="ph-line" style={{ animationDelay: `${i * 0.18}s` }} />
          <polyline points={pts(LINES[w.line])} fill="none" stroke={i ? '#fde68a' : '#fff7ed'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" className="ph-line" style={{ animationDelay: `${i * 0.18}s` }} />
        </g>
      ))}
    </svg>
  );
}

// ── Area Link board ──────────────────────────────────────────
function SpinStrip({ seed, slow }) {
  const items = [1, 0, 0, 1, 0, 0, 1, 0];
  return (
    <div className={`ph-coinstrip ${slow ? 'slow' : ''}`} style={{ animationDelay: `-${(seed * 97) % 400}ms` }} aria-hidden="true">
      {[...items, ...items].map((g, i) => <div key={i} className="aspect-square p-[10%]">{g ? <img src={PH.fb.yellow} alt="" className="h-full w-full opacity-70" draggable="false" /> : null}</div>)}
    </div>
  );
}
const cellColour = (x) => (x.t === 'green' ? 'green' : x.t === 'red' ? 'red' : x.t === 'blue' ? 'blue' : 'yellow');
function Board({ a, ai, b, two }) {
  return (
    <div className={`ph-board relative rounded-2xl p-1.5 ${a.done && b.spin ? 'opacity-70' : ''} ${a.full ? 'ph-full' : ''}`} data-board={ai}>
      <div className="mb-1 flex items-center justify-between px-1 text-[10px] font-extrabold uppercase tracking-wider text-amber-100/90">
        <span>{two ? `Array ${ai + 1}` : 'Area Link'}</span>
        <span className="flex items-center gap-1" aria-label={`${a.spinsLeft} respins left`}>
          {a.done ? <span className="text-amber-300">{a.full ? 'FULL!' : 'Complete'}</span>
            : Array.from({ length: RESPINS }, (_, i) => <span key={i} className={`ph-dot ${i < a.spinsLeft ? 'on' : ''} ${a.reset && i < a.spinsLeft ? 'pop' : ''}`} />)}
        </span>
        <span className="tabular-nums">{Object.keys(a.cells).length}/15</span>
      </div>
      <div className="grid grid-cols-5 gap-1">
        {ALL.map((k) => {
          const x = a.cells[k], c = Number(k[0]);
          const spinningHere = !x && b.spin && !a.done && c >= (b.stopped || 0);
          const fl = a.floats?.[k];
          return (
            <div key={k} data-ph={`${ai}:${k}`} className={`ph-socket relative aspect-square rounded-lg ${x ? 'filled' : ''} ${spinningHere && b.slowCol === c ? 'ph-tease' : ''}`}>
              {spinningHere && <SpinStrip seed={c * 8 + Number(k[2]) + ai * 3} slow={b.slowCol === c} />}
              {x && (
                <div className={`absolute inset-0 ${x.flash ? `ph-flash-${x.flash}` : ''}`}>
                  <Fireball c={x.show || cellColour(x)} v={x.v} jp={x.jp} fresh={x.fresh} glow={x.lit} size="sm" />
                  {x.mult > 1 && x.fresh && <span className="ph-xmult">×{x.mult}</span>}
                  {x.fresh && <Burst game="phoenix" n={10} spread={40} />}
                </div>
              )}
              {fl && <span key={fl.id} className={`ph-float ${fl.kind}`}>{fl.text}</span>}
            </div>
          );
        })}
      </div>
      {a.full && <div className="ph-pop pointer-events-none absolute inset-0 z-20 flex items-center justify-center"><div className="ph-grand-badge">GRAND</div></div>}
    </div>
  );
}

function UpgradeChips({ ups, mult, multSpin }) {
  return (
    <div className="mb-1.5 flex flex-wrap items-center justify-center gap-1">
      {ups.length ? ups.map((u) => (
        <span key={u} className="ph-chip" style={{ '--c': COL[u] }}>
          <img src={PH.egg[u]} alt="" className="h-4 w-4 object-contain" />{UPNAME[u]}
          {u === 'orange' && mult ? <b className={`ph-mult ${multSpin ? 'spin' : 'pop'}`}>×{mult}</b> : null}
        </span>
      )) : <span className="text-[11px] font-semibold text-amber-100/70">No upgrades this time: coloured Fireballs light the eggs that power Area Link</span>}
    </div>
  );
}

// ── Full-screen moments ──────────────────────────────────────
/** Phoenix Firestorm / Egg reveal: the Phoenix bursts into flame, then the eggs crack open one by one. */
function EggReveal({ data }) {
  if (!data) return null;
  return createPortal(
    <div className={`ph-reveal fixed inset-0 z-[90] flex items-center justify-center overflow-hidden ${data.storm ? 'storm' : ''}`} role="alert" aria-label={data.storm ? 'Phoenix Firestorm' : 'Upgrades'}>
      <div className="ph-reveal-bg absolute inset-0" />
      {data.storm && <img src={PH.firestorm} alt="" className="ph-storm-img absolute left-1/2 top-[42%] w-[min(120vw,760px)]" />}
      {data.storm && <><img src={PH.flames} alt="" className="ph-flames absolute bottom-[-6%] left-[-10%] w-[70%] max-w-[520px]" /><img src={PH.flames} alt="" className="ph-flames r absolute bottom-[-6%] right-[-10%] w-[70%] max-w-[520px]" /></>}
      {EMBERS.map((e, i) => <span key={i} className="ph-ember big absolute bottom-[-10px] rounded-full" style={{ left: `${e.l}%`, width: e.s * 2, height: e.s * 2, animationDuration: `${e.d * 0.6}s`, animationDelay: `${e.delay * 0.4}s`, '--drift': `${e.drift * 2}px` }} />)}
      <div className="relative flex w-full max-w-[640px] flex-col items-center px-3 text-center">
        <h2 className={`ph-title ${data.storm ? 'storm' : ''}`}>{data.storm ? <><span>PHOENIX</span><span>FIRESTORM</span></> : <span>THE EGGS HATCH</span>}</h2>
        <div className={`mt-[3vh] grid w-full grid-cols-5 gap-2 transition-opacity duration-500 ${data.phase >= 1 ? 'opacity-100' : 'opacity-0'}`}>
          {UPGRADES.map((u) => {
            const on = data.ups.includes(u), open = data.open.includes(u);
            return (
              <div key={u} className={`ph-rv-egg ${on ? 'on' : 'off'} ${open ? 'open' : ''}`} style={{ '--c': COL[u] }}>
                <div className="relative mx-auto aspect-[3/4] w-full max-w-[110px]">
                  <img src={PH.egg[u]} alt="" className="ph-rv-shell absolute inset-0 h-full w-full object-contain" />
                  {open && <span className="ph-rv-burst absolute inset-0" />}
                </div>
                <div className="ph-rv-name">{open ? UPNAME[u] : on ? '' : '—'}</div>
              </div>
            );
          })}
        </div>
        <p className={`ph-rv-sub mt-[2vh] ${data.phase >= 2 ? 'show' : ''}`}>{data.ups.length ? `${data.ups.length} upgrade${data.ups.length > 1 ? 's' : ''} for this Area Link` : 'Area Link'}</p>
      </div>
    </div>, document.body);
}

/** A jackpot moment: tier plate, amount, its own sound. */
function JackpotFlash({ jp }) {
  if (!jp) return null;
  return createPortal(
    <div className={`ph-jpflash fixed inset-0 z-[85] flex items-center justify-center ${jp.tier}`} role="alert" aria-label={`${JPNAME[jp.tier]} jackpot`}>
      <div className="ph-jpflash-rays absolute left-1/2 top-1/2" />
      <div className="relative flex flex-col items-center">
        <div className="relative w-[min(42vw,200px)]"><Fireball c="yellow" jp={jp.tier} glow /></div>
        <div className="ph-jpflash-title">{JPNAME[jp.tier]} JACKPOT</div>
        <div className="ph-jpflash-amt">{money(jp.amount)}</div>
        {jp.practice && <div className="mt-1 text-xs font-semibold text-white/70">Practice round: not paid</div>}
      </div>
    </div>, document.body);
}

/** Sparks that fly from Fireballs to their eggs, or prizes that fly into a collector / the Win box. */
function Flights({ list }) {
  if (!list?.length) return null;
  return createPortal(
    <div className="pointer-events-none fixed inset-0 z-[80]" aria-hidden="true">
      {list.map((f) => (
        <span key={f.id} className={`ph-flight ${f.kind}`} style={{ left: f.x - 9, top: f.y - 9, '--dx': `${f.tx - f.x}px`, '--dy': `${f.ty - f.y}px`, '--c': f.c, animationDelay: `${f.delay || 0}ms`, animationDuration: `${f.dur || 650}ms` }} />
      ))}
    </div>, document.body);
}

export default function Phoenix() {
  const { user, view, history, play, commit, guard, shake, doShake } = usePremium('phoenix');
  const reels = useReelStops(REELS);
  const [cells, setCells] = useState(START);
  const [lit, setLit] = useState(null);
  const [wins, setWins] = useState(null);
  const [spinning, setSpinning] = useState(false);
  const [spinId, setSpinId] = useState(0);
  const [tease, setTease] = useState([]);
  const [stake, setStakeRaw] = useState(() => { try { const v = Number(localStorage.getItem('ph_stake')); return STAKES.includes(v) ? v : DEFAULT_STAKE; } catch { return DEFAULT_STAKE; } });
  const setStake = (v) => { setStakeRaw(v); save('ph_stake', String(v)); };
  const [eggLit, setEggLit] = useState([]);          // eggs lit by coloured Fireballs on this spin
  const [eggPulse, setEggPulse] = useState(null);
  const [flight, setFlight] = useState(false);
  const [eggOpen, setEggOpen] = useState(null);
  const [reveal, setReveal] = useState(null);
  const [board, setBoard] = useState(null);
  const [intro, setIntro] = useState(null);
  const [summary, setSummary] = useState(null);
  const [big, setBig] = useState(null);
  const [jp, setJp] = useState(null);
  const [res, setRes] = useState(null);
  const [running, setRunning] = useState(false);
  const [introDone, setIntroDone] = useState(false);
  const [liveWin, setLiveWin] = useState(null);
  const [flights, setFlights] = useState([]);
  const [msg, setMsg] = useState(null);
  const [turbo, setTurbo] = useState(() => pref('ph_turbo', false));
  const [session, setSession] = useState({ staked: 0, won: 0 });
  const [dev] = useState(devMode);
  const bigResolve = useRef(null);
  const introResolve = useRef(null);
  const resumed = useRef(false);
  const liveRef = useRef(0);
  const fast = (ms) => (turbo ? ms * 0.45 : ms);
  const balance = user?.balance ?? 0;
  const mode = view?.mode || 'base';
  const busy = spinning || running || !!intro || !!summary || !!big || !!reveal || flight;

  // Recorded effects, with gentle pitch variation so repeats never sound identical
  const fx = useMemo(() => {
    const s = (name, gain = 0.5, rate = 1) => playSample(SFX[name], { gain, rate });
    let n = 0;
    return {
      spin: () => s('spin', 0.32, 0.97 + Math.random() * 0.06),
      stop: (i, fb) => s(fb ? 'stop_fb' : 'stop', fb ? 0.45 : 0.32, 0.96 + i * 0.02),
      wild: () => s('wild', 0.36),
      fbLand: (k = 0) => s('fb_land', 0.38, 0.95 + (k % 4) * 0.04),
      eggFill: (lvl = 0) => s('egg_fill', 0.4, 0.9 + Math.min(0.5, lvl * 0.5)),
      eggReady: () => s('egg_ready', 0.5),
      eggCrack: (i = 0) => s('egg_crack', 0.6, 0.94 + i * 0.04),
      respin: () => s('respin', 0.3, 0.98 + Math.random() * 0.04),
      lock: (k = 0) => s('lock', 0.42, 0.94 + ((n++ + k) % 5) * 0.03),
      reset: () => s('reset', 0.3),
      tick: (i = 0) => s('tick', 0.22, 1 + (i % 4) * 0.05),
      mult: () => s('mult', 0.5),
      red: () => s('red', 0.55),
      blue: () => s('blue', 0.5),
      green: () => s('green', 0.42),
      magenta: () => s('magenta', 0.55),
      near: () => s('near', 0.4),
      complete: () => s('complete', 0.5),
      win: (tier) => s(tier >= 3 ? 'win_b' : tier === 2 ? 'win_m' : 'win_s', 0.45),
      coin: (i = 0) => s('coin', 0.22, 0.95 + (i % 6) * 0.03),
      count: () => s('count', 0.3),
      jackpot: (t) => s(`jp_${t}`, 0.7),
    };
  }, []);

  const track = (out) => { if (out && !out.practice) setSession((x) => ({ staked: x.staked + (out.staked || 0), won: x.won + (out.win || 0) })); };
  const rect = (sel) => document.querySelector(sel)?.getBoundingClientRect();
  const centre = (r) => (r ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : null);
  const fly = (items) => {
    const list = items.filter((f) => f.from && f.to).map((f, i) => ({ id: `${Date.now()}-${i}-${Math.random()}`, x: f.from.x, y: f.from.y, tx: f.to.x, ty: f.to.y, c: f.c, kind: f.kind || 'spark', delay: f.delay, dur: f.dur }));
    if (!list.length) return;
    setFlights((l) => [...l, ...list]);
    setTimeout(() => setFlights((l) => l.filter((x) => !list.includes(x))), 1400 + Math.max(...list.map((x) => x.delay || 0)));
  };
  const countTo = async (to, ms = 500) => {
    const from = liveRef.current; const steps = Math.max(6, Math.round(ms / 40));
    for (let i = 1; i <= steps; i++) { const v = Math.round(from + ((to - from) * i) / steps); liveRef.current = v; setLiveWin(v); if (i % 3 === 0) fx.coin(i); await sleep(ms / steps); }
    liveRef.current = to; setLiveWin(to);
  };
  const resetLive = () => { liveRef.current = 0; setLiveWin(null); };
  const tierLabel = (x) => (x >= 100 ? 'EPIC WIN' : x >= 40 ? 'MEGA WIN' : 'BIG WIN');
  const celebrate = (amount, bet) => new Promise((r) => {
    const x = amount / bet;
    if (!amount || x < 10) return r();
    if (x >= 100) playVoice(VOICE.epicwin, { gain: 0.8 }); else if (x >= 40) playVoice(VOICE.megawin, { gain: 0.8 }); else playVoice(VOICE.bigwin, { gain: 0.8 });
    playSting('phoenix', x >= 40 ? 'jackpot' : 'win');
    bigResolve.current = r;
    setBig({ amount, bet, title: tierLabel(x), epic: x >= 100 });
  });
  const waitIntro = (data) => new Promise((r) => { introResolve.current = r; setIntro(data); });

  // ── The eggs hatch / Phoenix Firestorm ───────────────────────
  const phoenixFlies = async () => {
    playCue(SFX.firestorm, VOICE.firestorm, 1.2, { gain: 0.75 });
    setFlight(true); doShake(true);
    // the eggs flare one after another as the Phoenix sweeps past
    for (let k = 0; k < UPGRADES.length; k++) { await sleep(turbo ? 120 : 260); setEggPulse({ [UPGRADES[k]]: Date.now() }); }
    await sleep(turbo ? 500 : 1300);
    setFlight(false); setEggPulse(null);
  };
  const hatch = async (ups, storm) => {
    if (storm) {
      setReveal({ storm, ups, open: [], phase: 0 }); doShake(true);
      await sleep(turbo ? 1000 : 2200);
    } else {
      setReveal({ storm, ups, open: [], phase: 0 });
      await sleep(turbo ? 400 : 900);
    }
    setReveal({ storm, ups, open: [], phase: 1 });
    await sleep(turbo ? 300 : 700);
    const open = [];
    for (const u of UPGRADES) {
      if (!ups.includes(u)) continue;
      open.push(u); setReveal({ storm, ups, open: [...open], phase: 1 }); fx.eggCrack(open.length);
      await sleep(turbo ? 350 : 800);
    }
    setReveal({ storm, ups, open, phase: 2 });
    await sleep(turbo ? 600 : 1500);
    setReveal(null);
  };

  // ── Area Link ────────────────────────────────────────────────
  const runBonus = useCallback(async (vb, { resume = false, practice = false, ups = [] } = {}) => {
    setRunning(true);
    const two = vb.arrays.length > 1;
    const fresh = (cs, on) => Object.fromEntries(Object.entries(cs).map(([k, x]) => [k, { ...x, fresh: on }]));
    let b = { bet: vb.bet, upgrades: vb.upgrades, mult: vb.mult, practice, arrays: vb.arrays.map((a) => ({ cells: fresh(a.cells, !resume), spinsLeft: a.spinsLeft, done: a.done, full: a.full })) };
    setBoard(b);
    if (!resume) {
      resetLive();
      playCue(SFX.arealink, VOICE.arealink, 0.6, { gain: 0.6 });
      if (two) setTimeout(() => fx.magenta(), 900);
    }
    await waitIntro({ resume, practice, ups: vb.upgrades, two });
    setIntroDone(true);
    b = { ...b, arrays: b.arrays.map((a) => ({ ...a, cells: fresh(a.cells, false) })) };
    setBoard(b);
    if (!resume) { const n = Object.keys(b.arrays[0].cells).length; for (let i = 0; i < Math.min(8, n); i++) { fx.lock(i); await sleep(fast(110)); } }
    for (let guardN = 0; guardN < 200; guardN++) {
      await sleep(fast(800));
      const last = b.arrays.some((a) => !a.done && a.spinsLeft === 1);
      b = { ...b, spin: true, stopped: 0, slowCol: null, multSpin: b.upgrades.includes('orange'), arrays: b.arrays.map((a) => ({ ...a, reset: false, floats: null, cells: Object.fromEntries(Object.entries(a.cells).map(([k, x]) => [k, { ...x, fresh: false, flash: null, lit: false }])) })) };
      setBoard(b); fx.respin();
      const filled = Math.max(...b.arrays.map((a) => Object.keys(a.cells).length));
      if (filled >= 12 && !b.nearPlayed) { fx.near(); b = { ...b, nearPlayed: true }; }
      const [out] = await Promise.all([play('respin', {}, { quiet: false }), sleep(fast(900))]);
      if (!out) { setBoard({ ...b, spin: false }); setRunning(false); return; }
      // Orange: the multiplier for this respin
      if (out.mult) { b = { ...b, mult: out.mult, multSpin: false }; setBoard(b); fx.mult(); await sleep(fast(500)); }
      // Green: every Green grows first
      const greenEvs = out.events.flatMap((e) => e.greens.map((g) => ({ ...g, ai: e.array })));
      if (greenEvs.length) {
        fx.green();
        b = { ...b, arrays: b.arrays.map((a, ai) => {
          const gs = greenEvs.filter((g) => g.ai === ai); if (!gs.length) return a;
          const cs = { ...a.cells }; const floats = {};
          for (const g of gs) { cs[g.k] = { ...cs[g.k], v: g.v, flash: 'green' }; floats[g.k] = { id: `${g.k}-${guardN}`, text: `+${prizeText({ v: g.add })}`, kind: 'green' }; }
          return { ...a, cells: cs, floats };
        }) };
        setBoard(b); await sleep(fast(700));
      }
      // Landings, column by column across every live array
      let landed = 0;
      for (let c = 0; c < REELS; c++) {
        if (last && c === REELS - 1 && !turbo) { b = { ...b, slowCol: c }; setBoard(b); fx.near(); await sleep(900); }
        await sleep(fast(260));
        let colN = 0;
        b = { ...b, stopped: c + 1, slowCol: null, arrays: b.arrays.map((a, ai) => {
          const ev = out.events[ai]; const ls = ev.lands.filter((l) => l.k.startsWith(`${c}-`));
          if (!ls.length) return a;
          colN += ls.length;
          const cs = { ...a.cells };
          for (const l of ls) cs[l.k] = { t: l.type === 'yellow' ? (l.jp ? 'jp' : 'cash') : l.type, v: l.v, jp: l.jp, fresh: true, mult: l.mult, show: l.type === 'yellow' ? 'yellow' : l.type };
          return { ...a, cells: cs };
        }) };
        setBoard(b);
        if (colN) { fx.fbLand(landed); fx.lock(landed); landed += colN; if (colN >= 2) doShake(false); } else fx.tick(c);
      }
      b = { ...b, spin: false };
      setBoard(b);
      if (landed) await sleep(fast(500));
      // Blue: prize transfers
      for (const e of out.events) for (const bl of e.blues) {
        fx.blue();
        const from = centre(rect(`[data-ph="${e.array}:${bl.k}"]`));
        fly(bl.transfers.map((t, i) => ({ from, to: centre(rect(`[data-ph="${e.array}:${t.k}"]`)), c: COL.blue, kind: 'orb', delay: i * 160 })));
        for (let i = 0; i < bl.transfers.length; i++) {
          await sleep(fast(i ? 160 : 520));
          const t = bl.transfers[i];
          b = { ...b, arrays: b.arrays.map((a, ai) => (ai !== e.array ? a : { ...a, cells: { ...a.cells, [t.k]: { ...a.cells[t.k], v: t.v, flash: 'blue' } }, floats: { ...(a.floats || {}), [t.k]: { id: `${t.k}-${guardN}-${i}`, text: `+${prizeText({ v: t.add })}`, kind: 'blue' } } })) };
          setBoard(b); fx.tick(i);
        }
        await sleep(fast(400));
        b = { ...b, arrays: b.arrays.map((a, ai) => (ai !== e.array ? a : { ...a, cells: { ...a.cells, [bl.k]: { ...a.cells[bl.k], t: 'cash', show: 'yellow', flash: 'turn' } } })) };
        setBoard(b); await sleep(fast(400));
      }
      // Red: collect everything on the array
      for (const e of out.events) for (const rd of e.reds) {
        fx.red(); doShake(false);
        const to = centre(rect(`[data-ph="${e.array}:${rd.k}"]`));
        fly(rd.from.map((f, i) => ({ from: centre(rect(`[data-ph="${e.array}:${f.k}"]`)), to, c: COL.red, kind: 'orb', delay: i * 60 })));
        b = { ...b, arrays: b.arrays.map((a, ai) => (ai !== e.array ? a : { ...a, cells: Object.fromEntries(Object.entries(a.cells).map(([k, x]) => [k, rd.from.some((f) => f.k === k) ? { ...x, lit: true } : x])) })) };
        setBoard(b);
        await sleep(fast(700 + rd.from.length * 40));
        b = { ...b, arrays: b.arrays.map((a, ai) => (ai !== e.array ? a : { ...a, cells: { ...a.cells, [rd.k]: { ...a.cells[rd.k], v: rd.v, flash: 'red' } }, floats: { ...(a.floats || {}), [rd.k]: { id: `${rd.k}-r${guardN}`, text: `+${prizeText({ v: rd.collected })}`, kind: 'red' } } })) };
        setBoard(b); await sleep(fast(600));
        b = { ...b, arrays: b.arrays.map((a, ai) => (ai !== e.array ? a : { ...a, cells: { ...a.cells, [rd.k]: { ...a.cells[rd.k], t: 'cash', show: 'yellow', flash: 'turn' } } })) };
        setBoard(b); await sleep(fast(350));
      }
      // Counters
      b = { ...b, arrays: b.arrays.map((a, ai) => { const e = out.events[ai]; return e.skipped ? a : { ...a, spinsLeft: e.spinsLeft, done: e.done, full: e.full, reset: e.lands.length > 0 }; }) };
      setBoard(b);
      if (landed) { fx.reset(); }
      if (out.events.some((e) => e.full && !e.skipped)) { fx.jackpot('grand'); doShake(true); await sleep(fast(1200)); }
      if (out.result) { fx.complete(); await sleep(fast(1100)); await settle(out, b); return; }
    }
    setRunning(false);
  }, [view, fx, play, turbo]); // eslint-disable-line react-hooks/exhaustive-deps

  const settle = async (out, b) => {
    const r = out.result; const practice = b.practice || out.practice;
    // every prize counts into the Win box, array by array, left to right
    for (const arr of r.arrays) {
      const keys = Object.keys(arr.cells).sort((x, y) => Number(x[2]) - Number(y[2]) || Number(x[0]) - Number(y[0]));
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i], x = arr.cells[k];
        b = { ...b, arrays: b.arrays.map((a, ai) => (ai !== arr.array ? a : { ...a, cells: { ...a.cells, [k]: { ...a.cells[k], lit: true } } })) };
        setBoard(b);
        if (x.t === 'jp') {
          fx.jackpot(x.jp); playVoice(VOICE[x.jp], { gain: 0.8 });
          setJp({ tier: x.jp, amount: x.v, practice }); await sleep(turbo ? 900 : 2000); setJp(null);
        }
        fly([{ from: centre(rect(`[data-ph="${arr.array}:${k}"]`)), to: centre(rect('#ph-winbox')), c: COL.yellow, kind: 'coin', dur: 520 }]);
        await sleep(fast(140));
        await countTo(liveRef.current + x.v, fast(keys.length > 10 ? 120 : 200));
      }
      if (arr.grand) {
        fx.jackpot('grand'); playVoice(VOICE.grand, { gain: 0.85 }); playSting('phoenix', 'jackpot'); doShake(true);
        setJp({ tier: 'grand', amount: arr.grand, practice }); await sleep(turbo ? 1500 : 3600); setJp(null);
        await countTo(liveRef.current + arr.grand, 900);
      }
    }
    setRes({ win: out.win, staked: 0, bonus: r, practice });
    track(out);
    await celebrate(practice ? 0 : out.win, b.bet);
    commit();
    setSummary({ ...r, practice, win: out.win });
  };
  const endSummary = () => { setSummary(null); setBoard(null); setRunning(false); setIntroDone(false); setEggLit([]); };

  useEffect(() => { setMusicScene('phoenix', board && introDone ? 'bonus' : 'base'); }, [!!board, introDone]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const h = () => preloadUrls([...Object.values(VOICE), ...Object.values(SFX)]);
    window.addEventListener('pointerdown', h, { once: true });
    return () => window.removeEventListener('pointerdown', h);
  }, []);
  // Resume a bonus in progress (reload, app switch)
  useEffect(() => {
    if (resumed.current || !view || view.mode !== 'bonus' || board || !view.bonus) return;
    resumed.current = true;
    runBonus(view.bonus, { resume: true, practice: view.practice });
  }, [view]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Base spin ────────────────────────────────────────────────
  const spin = () => guard(async () => {
    if (busy || mode !== 'base') return;
    setLit(null); setWins(null); setRes(null); setMsg(null); resetLive();
    setSpinning(true); setSpinId((x) => x + 1); reels.start(); fx.spin();
    resumed.current = true;   // a bonus this spin starts is shown by this spin, not by the resume path
    const out = await play('spin', { stake });
    if (!out) { reels.stopNow(); setSpinning(false); return; }
    await showSpin(out);
  });

  const showSpin = async (out) => {
    setCells(out.grid);
    setEggLit([]);
    const fbCols = out.grid.map((col) => col.filter((x) => x.s === 'FB').length);
    // tease the last reels when 4+ Fireballs are already showing
    const teaseReels = []; let seen = 0;
    fbCols.forEach((n, i) => { if (seen >= 4 && i >= 3) teaseReels.push(i); seen += n; });
    setTease(turbo ? [] : teaseReels);
    let shown = 0, wildDone = false;
    await reels.stopAll({ turbo, tease: turbo ? [] : teaseReels, onStop: (i) => {
      fx.stop(i, fbCols[i] > 0);
      if (fbCols[i]) { fx.fbLand(shown); shown += fbCols[i]; }
      if (!wildDone && out.grid[i].some((x) => x.s === 'WILD')) { wildDone = true; fx.wild(); }   // once per spin, on the first reel with a Wild
    } });
    setTease([]); setSpinning(false);
    // coloured Fireballs light their eggs: a spark flies to each egg
    if (out.lights?.length) {
      const on = [];
      for (let i = 0; i < out.lights.length; i++) {
        const f = out.lights[i];
        fly([{ from: centre(rect(`[data-ph="${f.k}"]`)), to: centre(rect(`[data-egg="${f.c}"]`)), c: COL[f.c], kind: 'spark', dur: fast(600) }]);
        await sleep(fast(520));
        if (!on.includes(f.c)) on.push(f.c);
        setEggLit([...on]); setEggPulse({ [f.c]: Date.now() }); fx.eggFill(0.3 + on.length * 0.12);
        await sleep(fast(120));
      }
      setEggPulse(null);
    }
    // line wins
    const winCells = new Set(out.wins.flatMap((w) => w.cells.map(([c, r]) => key(c, r))));
    if (winCells.size) { setLit(winCells); setWins(out.wins); }
    const x = out.win / out.bet;
    if (out.wins.length) fx.win(x >= 5 ? 3 : x >= 1.5 ? 2 : 1);
    setRes({ win: out.win, staked: out.staked, wins: out.wins, practice: out.practice });
    if (out.win) await countTo(out.win, x >= 5 ? 900 : 450);
    track(out);
    await celebrate(out.win, out.bet);
    commit();
    if (out.started) {
      const fbKeys = out.grid.flatMap((col, c) => col.map((y, r) => (y.s === 'FB' ? key(c, r) : null))).filter(Boolean);
      if (out.firestorm) { setLit(null); setWins(null); await phoenixFlies(); }
      else if (out.source === 'egg') {
        // the lucky egg cracks open on the spot
        setLit(null); setWins(null); setEggOpen(out.hatched); fx.eggReady(); doShake(false);
        await sleep(fast(1300));
      } else { setLit(new Set(fbKeys)); setMsg('arealink'); await sleep(fast(1100)); }
      setLit(null); setWins(null);
      if (out.firestorm || out.upgrades.length) {
        setEggOpen(out.lit || []);
        await sleep(fast(400));
        await hatch(out.upgrades, out.firestorm);
        setEggOpen(null);
      }
      setEggLit([]);
      setMsg(null);
      await runBonus(out.view.bonus, { practice: out.practice, ups: out.upgrades });
    }
  };

  const devRun = (event) => guard(async () => {
    if (busy || mode !== 'base') return;
    setLit(null); setWins(null); setRes(null); resetLive();
    resumed.current = true;
    const out = await play('dev', { event, stake });
    if (!out) return;
    if (out.firestorm) await phoenixFlies();
    if (out.source === 'egg') { setEggLit(out.lit); await sleep(500); setEggOpen(out.hatched); fx.eggReady(); doShake(false); await sleep(1300); setEggOpen(null); }
    if (out.upgrades.length || out.firestorm) await hatch(out.upgrades, out.firestorm);
    setEggLit([]);
    await runBonus(out.view.bonus, { practice: true });
  });

  useEffect(() => {
    const h = (e) => { if (e.code === 'Space' && !['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(document.activeElement?.tagName)) { e.preventDefault(); spin(); } };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  });

  const i = Math.max(0, STAKES.indexOf(stake));
  const low = stake > balance;
  const win = res?.win || 0;
  const bet = board?.bet || stake;
  const detail = res?.bonus ? `Area Link · ${res.bonus.arrays.reduce((a, x) => a + x.count, 0)} Fireballs${res.bonus.arrays.some((a) => a.grand) ? ' · GRAND' : ''}`
    : res?.wins?.length ? res.wins.slice(0, 2).map((w) => `${w.count} × ${SYMNAME[w.symbol]} on line ${w.line + 1}`).join(' · ') + (res.wins.length > 2 ? ` +${res.wins.length - 2} more` : '') : null;

  const header = (
    <div className="ph-header relative -mx-2 -mt-2 mb-1.5 overflow-hidden sm:-mx-4 sm:-mt-4">
      <img src={PH.logo} alt="Phoenix Ember Link" className="ph-logo relative z-[1] mx-auto block h-[clamp(64px,19vw,118px)] w-auto max-w-[92%] object-contain" />
      <div className="relative z-[1] px-2 pb-1"><Jackpots bet={bet} hit={jp?.tier} /></div>
    </div>
  );

  const stage = board ? (
    <div className="relative">
      <UpgradeChips ups={board.upgrades} mult={board.mult} multSpin={board.multSpin && board.spin} />
      <div className={`grid gap-1.5 ${board.arrays.length > 1 ? 'sm:grid-cols-2' : ''}`}>
        {board.arrays.map((a, ai) => <Board key={ai} a={a} ai={ai} b={board} two={board.arrays.length > 1} />)}
      </div>
    </div>
  ) : (
    <div className="relative">
      <Eggs lit={eggLit} pulse={eggPulse} opening={eggOpen} />
      <div className="ph-frame relative mt-1">
        <div className="ph-reelset relative">
          <div className="grid gap-[2px]" style={{ gridTemplateColumns: `repeat(${REELS}, minmax(0, 1fr))` }}>
            {cells.map((col, c) => <Reel key={c} index={c} cells={col} spinning={spinning && !reels.stopped[c]} landKey={`${spinId}-${c}`} lit={lit} turbo={turbo} tease={tease.includes(c) && spinning && !reels.stopped[c]} />)}
          </div>
          <Paylines wins={wins} show={!spinning && !!wins?.length} />
        </div>
        {msg === 'arealink' && <div className="ph-pop pointer-events-none absolute inset-0 z-20 flex items-center justify-center"><div className="ph-banner">AREA LINK</div></div>}
      </div>
    </div>
  );

  const info = (
    <>
      <section>
        <h3 className="mb-1 font-bold text-white">How it plays</h3>
        <p>5 reels, 3 rows and 20 fixed lines. Wins pay left to right from the first reel, 3, 4 or 5 in a row on a line; only the best win on each line pays, and wins on different lines add up. Every pay is a multiple of your total stake, so everything scales with the bet: 20p, 50p, £1, £2, £5 or £10.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Paytable at {money(stake)}</h3>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(PAYTABLE).map(([s, p]) => (
            <div key={s} className="flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
              <div className="h-11 w-11 shrink-0"><Sym s={s} /></div>
              <div className="text-[11px] leading-tight">{p.map((x, k) => <div key={k}><span className="text-slate-500">{k + 3}×</span> <b className="text-white">{money(Math.round((stake * x) / 100))}</b></div>)}</div>
            </div>
          ))}
          <div className="col-span-2 flex items-center gap-2 rounded-lg bg-navy-800 p-1.5">
            <div className="h-11 w-11 shrink-0"><Sym s="WILD" /></div>
            <p className="text-[11px] leading-snug">The Phoenix Wild lands on reels 2 to 5, often in full stacks, and stands in for every paying symbol. It never stands in for a Fireball.</p>
          </div>
        </div>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Fireballs and the eggs</h3>
        <p>Fireballs carry a cash prize or a jackpot. A coloured Fireball also lights the egg of its colour above the reels for that spin, and every coloured Fireball has a {(EGG_CHANCE * 100).toFixed(1)}% chance to hatch its egg and start Area Link there and then, even with fewer than {TRIGGER} Fireballs. Nothing builds up between spins: every chance is fresh. Whenever Area Link starts, every egg lit on the reels adds its upgrade. About {Math.round((BASE_COLOURS.find(([c]) => c === 'yellow')[1] / BASE_COLOURS.reduce((a, [, w]) => a + w, 0)) * 100)}% of Fireballs are plain Yellow.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Area Link · {TRIGGER}+ Fireballs</h3>
        <p>The Fireballs that triggered it lock in place and you get {RESPINS} respins on a 5 × 3 array where only Fireballs land. Every Fireball locks for the rest of the feature and resets the respins to {RESPINS}. The feature ends when the respins run out, then every prize on the array is paid. Fill all 15 spots to win the GRAND on top.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">The five upgrades</h3>
        <ul className="space-y-1">
          {UPGRADES.map((u) => <li key={u} className="flex gap-2"><img src={PH.egg[u]} alt="" className="h-6 w-6 shrink-0 object-contain" /><span><b className="text-white">{UPNAME[u]}:</b> {UPDESC[u]}{u === 'orange' ? ` (2x ${MULTIPLIERS[0][1]}%, 3x ${MULTIPLIERS[1][1]}%, 5x ${MULTIPLIERS[2][1]}%; jackpots are not multiplied)` : u === 'magenta' ? ` It starts with ${MAGENTA_START} Fireballs of its own; each array can win its own GRAND.` : u === 'blue' ? ` (1 to ${BLUE_HITS.length} transfers; the same prize can be boosted more than once)` : u === 'red' ? ' The collected prizes stay and are paid once; the Red total is one new prize.' : ''}</span></li>)}
        </ul>
        <p className="mt-1">Upgrades work together in any combination; each respin applies them in the same order: multiplier, Green growth, new Fireballs, Blue boosts, Red collections.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Phoenix Firestorm</h3>
        <p>On any spin that lands a Fireball, the Phoenix can burst out of the volcano at random ({(FIRESTORM_CHANCE * 100).toFixed(2)}% a spin, about 1 spin in 600). It sweeps across the reels and starts Area Link straight away with 1 to 5 random upgrades, so all five at once is possible, plus any eggs lit on the reels.</p>
      </section>
      <section>
        <h3 className="mb-1 font-bold text-white">Jackpots</h3>
        <p>MINI {JACKPOTS.mini}x, MINOR {JACKPOTS.minor}x and MAJOR {JACKPOTS.major}x your stake appear on Fireballs. GRAND {JACKPOTS.grand.toLocaleString()}x is won by filling an Area Link array. At {money(stake)}: {['mini', 'minor', 'major', 'grand'].map((t) => `${JPNAME[t]} ${money(JACKPOTS[t] * stake)}`).join(', ')}.</p>
      </section>
      <section className="text-xs text-slate-400">
        <p>Return to player {RTP_LABEL[view?.rtp] || '96.4%'} at this server's setting. The 96.4% setting was measured by simulating 100 million spins with the real game code (base game 48.9%, Area Link about 47.5%; Area Link about 1 spin in 137, Firestorm about 1 in 620). Outcomes are drawn on the server with a cryptographic random number generator and never depend on your balance or past results. Virtual money only.</p>
        <p className="mt-1">An original game: its name, art, sounds and numbers are our own.</p>
      </section>
    </>
  );

  const bar = (
    <div className="ph-bar sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2 md:static">
      <div className="ph-chips flex justify-between gap-1" role="radiogroup" aria-label="Bet per spin">
        {STAKES.map((x) => (
          <button key={x} type="button" role="radio" aria-checked={x === stake} disabled={busy || mode !== 'base'} onClick={() => setStake(x)} className={`ph-chipbtn ${x === stake ? 'on' : ''}`}>{stakeLabel(x)}</button>
        ))}
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] gap-1.5">
        <div className="ph-box"><span>Balance</span><b>{money(balance)}</b></div>
        <div className="ph-box items-center gap-1 px-1" style={{ flexDirection: 'row' }}>
          <button className="ph-round h-8 w-8 text-lg" disabled={busy || mode !== 'base' || i <= 0} onClick={() => setStake(STAKES[i - 1])} aria-label="Lower bet">−</button>
          <div className="flex min-w-[3.6rem] flex-col items-center"><span>Bet</span><b>{money(stake)}</b></div>
          <button className="ph-round h-8 w-8 text-lg" disabled={busy || mode !== 'base' || i >= STAKES.length - 1} onClick={() => setStake(STAKES[i + 1])} aria-label="Raise bet">+</button>
        </div>
        <div className="ph-box" id="ph-winbox"><span>Win</span><b className={(liveWin ?? win) ? 'text-amber-300' : ''}>{money(liveWin ?? win)}</b></div>
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
        <div className="text-[10px] leading-tight text-amber-100/70">20 lines<br />{TRIGGER}+ Fireballs = Area Link</div>
        <button onClick={spin} disabled={busy || low || mode !== 'base'} aria-label={spinning ? 'Spinning' : running ? 'Area Link in play' : low ? 'Not enough balance' : 'Spin'} title={low ? 'Not enough balance' : 'Spin'}
          className="ph-spin relative flex h-[76px] w-[76px] items-center justify-center rounded-full">
          <svg viewBox="0 0 48 48" className={`relative z-[1] h-10 w-10 ${spinning || running ? 'animate-spin' : ''}`} fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M38 18a16 16 0 0 0-28-3" /><path d="M10 6v9h9" /><path d="M10 30a16 16 0 0 0 28 3" /><path d="M38 42v-9h-9" />
          </svg>
        </button>
        <div className="flex justify-end">
          <button onClick={() => setTurbo((t) => { save('ph_turbo', !t ? '1' : '0'); return !t; })} className={`ph-btn h-11 px-3 text-xs ${turbo ? 'on' : ''}`} aria-pressed={turbo}>{turbo ? 'Turbo on' : 'Turbo'}</button>
        </div>
      </div>
      {low && !busy && <p className="text-center text-[11px] font-semibold text-amber-300">Not enough balance for this bet</p>}
      {dev && (
        <div className="flex flex-wrap gap-1 border-t border-white/10 pt-2 text-[11px]" aria-label="Practice triggers">
          <span className="w-full text-amber-200/70">Practice (no cost, no pay):</span>
          {[['bonus', 'Area Link'], ['egg', 'Egg hatch'], ['firestorm', 'Firestorm'], ...UPGRADES.map((u) => [u, UPNAME[u]]), ['all', 'All 5'], ['grand', 'Grand']].map(([e, l]) => (
            <button key={e} onClick={() => devRun(e)} disabled={busy || mode !== 'base'} className="h-8 rounded-md bg-navy-700 px-2 font-semibold text-slate-200 disabled:opacity-40">{l}</button>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <PremiumShell game="phoenix" rtp={RTP_LABEL[view?.rtp] || '96.4%'} title="Phoenix Ember Link" tagline="5 × 3 · 20 lines · Area Link · 5 egg upgrades · Phoenix Firestorm" shake={shake}
      stageClass="ph-stage" bg={<Backdrop bonus={!!board} storm={!!reveal?.storm} />} info={info} below={bar}
      fitKey={board ? `bonus-${board.arrays.length}` : 'base'}
      side={<>
        <SidePanel title="This session">
          <div className="flex justify-between text-xs"><span className="text-slate-400">Staked</span><b className="tabular-nums text-white">{money(session.staked)}</b></div>
          <div className="flex justify-between text-xs"><span className="text-slate-400">Won</span><b className="tabular-nums text-white">{money(session.won)}</b></div>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      {header}
      <div className="ph-msg mb-1.5 flex h-[46px] flex-col items-center justify-center overflow-hidden rounded-xl px-2 text-center leading-tight">
        {board ? (
          <div className="text-sm font-bold text-amber-100">{board.arrays.length > 1 ? 'Area Link · two arrays' : 'Area Link'}{board.practice ? ' · practice' : ''}
            <span className="block text-[11px] font-medium text-white/70">{liveWin != null ? <>Total <b className="text-amber-300">{money(liveWin)}</b></> : 'Every Fireball locks and resets the respins'}</span></div>
        ) : res?.win ? <><WinAmount win={liveWin ?? res.win} staked={res.staked} />{detail && <div className="w-full truncate text-[11px] text-white/75">{detail}</div>}</>
          : <div className="text-[13px] text-white/70">{spinning ? 'Spinning…' : res ? (detail || 'No win this time') : `Land ${TRIGGER} Fireballs for Area Link · coloured Fireballs light the eggs`}</div>}
      </div>
      {stage}

      {intro && (
        <FeatureIntro title={intro.resume ? 'WELCOME BACK' : 'AREA LINK'}
          className="ph-intro"
          art={<div className="relative mb-2 flex justify-center gap-1">{(intro.ups.length ? intro.ups : ['yellow']).map((u) => <img key={u} src={u === 'yellow' ? PH.fb.yellow : PH.egg[u]} alt="" className="ph-pop h-14 w-14 object-contain sm:h-16 sm:w-16" />)}</div>}
          subtitle={intro.resume ? 'Your Area Link is still in progress. Carry on where you left off.'
            : `${RESPINS} respins${intro.two ? ' on each of two arrays' : ''}. Every Fireball locks and resets the respins. Fill an array for the GRAND.${intro.ups.length ? ` Upgrades: ${intro.ups.map((u) => UPNAME[u]).join(', ')}.` : ''}`}
          cta={intro.practice ? 'Start practice' : 'Ignite'}
          onStart={() => { setIntro(null); introResolve.current?.(); introResolve.current = null; }} />
      )}
      {summary && (
        <FeatureIntro title={summary.arrays.some((a) => a.grand) ? 'GRAND JACKPOT!' : 'AREA LINK COMPLETE'} cta="Back to the reels" onStart={endSummary} className="ph-intro"
          subtitle={`${summary.arrays.map((a, k) => `${summary.arrays.length > 1 ? `Array ${k + 1}: ` : ''}${a.count} Fireballs, ${money(a.total)}`).join(' · ')}. ${summary.practice ? 'Practice round: nothing was paid.' : `You win ${money(summary.win)}.`}`} />
      )}
      <Flights list={flights} />
      <PhoenixFlight on={flight} />
      <EggReveal data={reveal} />
      <JackpotFlash jp={jp} />
      {big && <BigWin game="phoenix" amount={big.amount} bet={big.bet} title={big.title} labels={['BIG WIN', 'MEGA WIN', 'EPIC WIN']}
        cinematic={big.epic ? <img src={PH.hero} alt="" className="ph-epic-phoenix pointer-events-none absolute left-1/2 top-[8%] w-[120%] max-w-[700px]" /> : null}
        onDone={() => { setBig(null); bigResolve.current?.(); bigResolve.current = null; }} />}
    </PremiumShell>
  );
}

export { reduceMotion };
