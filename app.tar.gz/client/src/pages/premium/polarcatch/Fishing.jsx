// Polar Catch – the fishing bonus. The server has already decided every cast (fishing.casts);
// this scene plays each one out slowly: cast → lure sinks → a fish swims in and bites → a reel-in
// fight driven by a small physics model (line length, tension, rod bend) → the fish breaches the
// ice hole and flops onto the ice → its value flies to the tally. Then the catch total, the
// pre-spin multiplier and the payout.
import { useEffect, useMemo, useRef, useState } from 'react';
import { SPOTS } from '../../../../../server/games/polarcatch/config.js';
import { Fish } from '../../../components/SlotArtPolar.jsx';
import { money } from '../../../lib/format.js';
import { sfx, sting, voice } from './audio.js';

// scene geometry (viewBox 0 0 400 640)
const ICE_Y = 250, ICE_B = 272, HOLE_X = 210, HOLE_HALF = 28;
const HOOK = { x: HOLE_X, y: ICE_B + 4 };
const BUTT = { x: 322, y: 226 }, ROD = 150, ROD_REST = -140;
const PILE = { x: 46, y: ICE_Y - 6 };

const TIERS = { minnow: [2, 5, 15], salmon: [3, 8, 20], king: [4, 12, 40] };
export const sizeOf = (bonus, v) => { const t = TIERS[bonus]; return v > t[2] ? 3 : v > t[1] ? 2 : v > t[0] ? 1 : 0; };
const SCALE = [0.56, 0.72, 0.9, 1.12];
const SIZE_LABEL = ['Nice catch', 'Good one!', 'What a catch!', 'MONSTER!'];
const rnd = (a, b) => a + Math.random() * (b - a);
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const deg = (r) => (r * 180) / Math.PI, rad = (d) => (d * Math.PI) / 180;
const ease = (k) => (k < 0.5 ? 2 * k * k : 1 - (-2 * k + 2) ** 2 / 2);

function newSim() {
  return { t: 0, mode: 'idle', mt: 0, rodA: ROD_REST, bend: 0, tension: 0, lure: null, fish: null, L: 0, L0: 0, ft: 0, fightDur: 4, reeling: false,
    drops: [], ripples: [], bubbles: [], pile: [], reelSpin: 0, hooks: {} };
}
const tipOf = (S) => { const a = rad(S.rodA - S.bend * 38); return { x: BUTT.x + ROD * Math.cos(a), y: BUTT.y + ROD * Math.sin(a) }; };
function splashAt(S, x, y, n, power) {
  for (let i = 0; i < n; i++) S.drops.push({ x: x + rnd(-HOLE_HALF * 0.7, HOLE_HALF * 0.7), y, vx: rnd(-1, 1) * 110 * power, vy: -rnd(140, 360) * power, r: rnd(1.2, 3.2), life: 0 });
  S.ripples.push({ x, y: y + 2, life: 0, w: 1 + power * 0.5 });
}

/** Advance the scene by dt seconds. */
function step(S, dt) {
  S.t += dt; S.mt += dt;
  const tip = tipOf(S);
  const f = S.fish;
  if (S.mode === 'cast') {
    const k = S.mt;
    // wind back, whip forward, settle
    S.rodA = k < 0.35 ? ROD_REST + (ROD_REST + 85 - ROD_REST) * ease(k / 0.35) : k < 0.55 ? -55 - 100 * ease((k - 0.35) / 0.2) : -155 + 15 * ease(Math.min(1, (k - 0.55) / 0.6));
    if (k >= 0.5) {
      const u = Math.min(1, (k - 0.5) / 0.7);
      const from = S.castFrom || (S.castFrom = { ...tip });
      S.lure = { x: from.x + (HOLE_X - from.x) * u, y: from.y + (ICE_B - from.y) * u - Math.sin(Math.PI * u) * 70 };
      if (u >= 1 && !S.plopped) { S.plopped = true; splashAt(S, HOLE_X, ICE_B, 8, 0.55); S.hooks.plop?.(); }
    } else S.lure = { x: tip.x, y: tip.y + 14 };
  } else if (S.mode === 'sink' || S.mode === 'nibble') {
    S.rodA += (ROD_REST - S.rodA) * Math.min(1, dt * 4);
    const l = S.lure; l.y += (S.depth - l.y) * Math.min(1, dt * 1.6); l.x = HOLE_X + Math.sin(S.t * 1.3) * 6;
    // the fish swims in and noses at the lure
    const target = S.mode === 'sink' ? { x: l.x + (f.side > 0 ? 70 : -70), y: l.y + 10 } : { x: l.x + Math.cos(S.t * 3.1) * 10, y: l.y + Math.sin(S.t * 2.3) * 6 };
    const dx = target.x - f.x, dy = target.y - f.y, d = Math.hypot(dx, dy) || 1;
    const sp = S.mode === 'sink' ? 95 : 60;
    f.vx += ((dx / d) * sp * Math.min(1, d / 40) - f.vx) * Math.min(1, dt * 3);
    f.vy += ((dy / d) * sp * Math.min(1, d / 40) - f.vy) * Math.min(1, dt * 3);
    f.x += f.vx * dt; f.y += f.vy * dt;
    if (S.mode === 'nibble') S.bend = Math.max(0, Math.sin(S.t * 23)) * 0.12 * (Math.sin(S.t * 3) > 0.3 ? 1 : 0);
    else S.bend *= 0.9;
    if (Math.random() < dt * 2) S.bubbles.push({ x: l.x, y: l.y, life: 0, r: rnd(1, 2) });
  } else if (S.mode === 'fight') {
    S.ft += dt;
    const p = Math.min(1, S.ft / S.fightDur);
    f.runT -= dt;
    if (f.runT <= 0) {
      const rest = Math.random() < 0.25 && p > 0.2;
      const a = rad(rnd(15, 165) + (f.x < HOLE_X ? 10 : -10));
      f.F = rest ? 30 : (110 + 85 * f.size) * rnd(0.6, 1.25) * (1 - p * 0.55);
      f.dir = { x: Math.cos(a) * (Math.random() < 0.5 ? -1 : 1), y: Math.abs(Math.sin(a)) * (p > 0.85 ? -0.4 : 1) };
      f.runT = rnd(0.28, 0.8);
    }
    const wig = Math.sin(S.t * 18) * 40;
    f.vx += (f.dir.x * f.F * 3 + wig * -f.dir.y) * dt; f.vy += (f.dir.y * f.F * 3 + wig * f.dir.x) * dt;
    const drag = Math.exp(-2.4 * dt); f.vx *= drag; f.vy *= drag;
    f.x += f.vx * dt; f.y += f.vy * dt;
    f.x = clamp(f.x, 22, 378); f.y = clamp(f.y, ICE_B + 18, 615);
    // reel: line comes in unless the fish is running hard (the drag pays line out)
    const ux = f.x - HOOK.x, uy = f.y - HOOK.y, d = Math.hypot(ux, uy) || 1;
    const pull = Math.max(0, (f.dir.x * ux + f.dir.y * uy) / d) * f.F / (110 + 85 * 3);
    S.reeling = pull < 0.42;
    S.L += (S.reeling ? -(26 + 22 * p) : 18 * pull) * dt;
    S.L = clamp(Math.min(S.L, S.L0 * (1 - p) ** 0.85 + 14), 12, S.L0 + 40);
    let stretch = 0;
    if (d > S.L) {
      stretch = d - S.L;
      f.x -= (ux / d) * stretch * 0.7; f.y -= (uy / d) * stretch * 0.7;
      const vr = (f.vx * ux + f.vy * uy) / d; if (vr > 0) { f.vx -= (ux / d) * vr * 0.9; f.vy -= (uy / d) * vr * 0.9; }
    }
    const raw = clamp(stretch / 12 + pull * 0.75, 0, 1);
    S.tension += (raw - S.tension) * Math.min(1, dt * 6);
    S.bend += (0.25 + S.tension * 0.75 - S.bend) * Math.min(1, dt * 8);
    S.rodA = ROD_REST + 6 * Math.sin(S.t * 2.2) - S.tension * 6;
    if (S.reeling) S.reelSpin += dt * 900;
    if (Math.random() < dt * (4 + f.size * 2)) S.bubbles.push({ x: f.x, y: f.y, life: 0, r: rnd(1, 2.6) });
    if (S.ft >= S.fightDur) {
      // breach!
      S.mode = 'breach'; S.mt = 0; f.anchor = 60;
      f.x = HOLE_X; f.y = ICE_B + 30; f.vx = -rnd(100, 125); f.vy = -(380 + f.size * 45); f.spin = rnd(420, 620);
      splashAt(S, HOLE_X, ICE_B, 18 + f.size * 10, 0.8 + f.size * 0.25); S.tension = 0.2; S.hooks.breach?.(f.size);
    }
  } else if (S.mode === 'breach') {
    f.vy += 760 * dt; f.x += f.vx * dt; f.y += f.vy * dt; f.h += f.spin * dt;
    S.bend += (0.35 - S.bend) * dt * 5;
    const rest = ICE_Y - 12 * f.s;
    if (f.vy > 0 && f.y >= rest && f.x < HOLE_X - HOLE_HALF - 20) {
      f.y = rest; f.vy = -150; f.vx *= 0.3; f.hops = 2; S.mode = 'ice'; S.mt = 0; S.hooks.flop?.(1);
      S.lure = null;
    }
  } else if (S.mode === 'ice') {
    S.bend *= 0.9; S.rodA += (ROD_REST - S.rodA) * dt * 4;
    const rest = ICE_Y - 12 * f.s;
    f.vy += 900 * dt; f.y += f.vy * dt; f.x += f.vx * dt; f.vx *= 0.96;
    f.h += (Math.round(f.h / 180) * 180 - f.h) * Math.min(1, dt * 10);
    if (f.y >= rest) { f.y = rest; if (f.hops > 0 && f.vy > 0) { f.vy = -110 * (f.hops / 2); f.hops--; S.hooks.flop?.(0.5); } else f.vy = 0; }
  } else if (S.mode === 'stow') {
    const k = Math.min(1, S.mt / 0.6);
    f.x += (f.toX - f.x) * Math.min(1, dt * 7); f.y += (f.toY - f.y) * Math.min(1, dt * 7) - Math.sin(Math.PI * k) * 3;
    f.s += (0.3 - f.s) * Math.min(1, dt * 7);
    if (k >= 1) { S.pile.push({ x: f.toX, y: f.toY, h: f.h, size: f.size }); S.fish = null; S.mode = 'idle'; }
  } else {
    S.bend *= 0.9; S.rodA += (ROD_REST - S.rodA) * Math.min(1, dt * 4);
  }
  if (f && (S.mode === 'sink' || S.mode === 'nibble' || S.mode === 'fight')) {
    const sp = Math.hypot(f.vx, f.vy);
    if (sp > 12) { const want = deg(Math.atan2(f.vy, f.vx)); let d = ((want - f.h + 540) % 360) - 180; f.h += d * Math.min(1, dt * 6); }
  }
  // particles
  for (const p of S.drops) { p.life += dt; p.vy += 900 * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
  S.drops = S.drops.filter((p) => p.y < ICE_B + 6 && p.life < 2);
  for (const r of S.ripples) r.life += dt;
  S.ripples = S.ripples.filter((r) => r.life < 1.2);
  for (const b of S.bubbles) { b.life += dt; b.y -= 45 * dt; b.x += Math.sin(b.life * 6) * 0.3; }
  S.bubbles = S.bubbles.filter((b) => b.y > ICE_B + 4 && b.life < 6);
}

function FishSprite({ f, t }) {
  const flip = Math.cos(rad(f.h)) < 0 ? -1 : 1;
  const wigA = f.anchor === 118 ? (f.fighting ? 7 : 4) : 0;
  const wig = Math.sin(t * (f.fighting ? 17 : 7)) * wigA;
  return (
    <g transform={`translate(${f.x} ${f.y}) rotate(${f.h + wig}) scale(${f.s} ${f.s * flip}) translate(${-f.anchor} -30)`}>
      {f.size === 3 && <ellipse cx="60" cy="30" rx="76" ry="40" fill="url(#pcfGlow)" />}
      <Fish species={f.species} />
    </g>
  );
}

function Angler({ S }) {
  const tip = tipOf(S);
  const a = rad(S.rodA - S.bend * 8);
  const c = { x: BUTT.x + ROD * 0.55 * Math.cos(a), y: BUTT.y + ROD * 0.55 * Math.sin(a) };
  const rod = `M${BUTT.x} ${BUTT.y}Q${c.x} ${c.y} ${tip.x} ${tip.y}`;
  return (
    <g>
      {/* stool and figure in a parka */}
      <rect x="326" y="236" width="26" height="5" rx="2" fill="#78350f" /><path d="M330 241L326 250M348 241L352 250" stroke="#451a03" strokeWidth="2.5" />
      <path d="M322 238Q318 200 338 190Q358 196 356 238Z" fill="url(#pcfParka)" stroke="#7c2d12" strokeWidth="1" />
      <path d="M326 236L320 248H334ZM344 236L346 248H358Z" fill="#1e293b" />
      <circle cx="340" cy="182" r="13" fill="#fef3c7" stroke="#e5e7eb" strokeWidth="5" />
      <circle cx="340" cy="183" r="7.5" fill="#fcd9b6" /><circle cx="337" cy="182" r="1" fill="#1e293b" /><circle cx="342.5" cy="182" r="1" fill="#1e293b" />
      <path d="M337.5 186Q340 188 342.5 186" stroke="#9a3412" strokeWidth=".9" fill="none" />
      <path d="M334 210Q324 214 322 226" stroke="#ea580c" strokeWidth="7" strokeLinecap="round" fill="none" />
      {/* rod, guides, reel */}
      <path d={rod} stroke="#1e293b" strokeWidth="3.4" fill="none" strokeLinecap="round" />
      <path d={rod} stroke="#f59e0b" strokeWidth="1.3" fill="none" strokeLinecap="round" opacity=".8" />
      <g transform={`translate(${BUTT.x - 10} ${BUTT.y - 6})`}>
        <circle r="6" fill="#cbd5e1" stroke="#475569" strokeWidth="1.2" />
        <path d="M0 0L5 0" stroke="#334155" strokeWidth="2" strokeLinecap="round" transform={`rotate(${S.reelSpin})`} />
      </g>
      <circle cx="324" cy="226" r="3.5" fill="#fcd9b6" />
    </g>
  );
}

function SceneSvg({ S, svgRef }) {
  const tip = tipOf(S), f = S.fish;
  // the fishing line
  let line = null;
  const end = f && (S.mode === 'fight') ? { x: f.x, y: f.y } : f && (S.mode === 'breach') ? { x: f.x, y: f.y } : S.lure;
  if (end) {
    const sag = 34 * (1 - Math.min(1, S.tension * 1.4));
    if (end.y > ICE_B - 2 && S.mode !== 'breach') {
      const e = { x: HOLE_X, y: ICE_B - 6 };
      const c1 = { x: (tip.x + e.x) / 2, y: (tip.y + e.y) / 2 + sag };
      const m = { x: (e.x + end.x) / 2, y: (e.y + end.y) / 2 }, dx = end.x - e.x, dy = end.y - e.y, dl = Math.hypot(dx, dy) || 1;
      const bow = (1 - Math.min(1, S.tension * 1.3)) * 14;
      line = `M${tip.x} ${tip.y}Q${c1.x} ${c1.y} ${e.x} ${e.y}Q${m.x - (dy / dl) * bow} ${m.y + (dx / dl) * bow} ${end.x} ${end.y}`;
    } else {
      line = `M${tip.x} ${tip.y}Q${(tip.x + end.x) / 2} ${(tip.y + end.y) / 2 + sag * 0.6} ${end.x} ${end.y}`;
    }
  } else line = `M${tip.x} ${tip.y}L${tip.x} ${tip.y + 16}`;
  const lure = S.lure && S.mode !== 'fight' ? S.lure : !end ? { x: tip.x, y: tip.y + 16 } : null;
  return (
    <svg ref={svgRef} viewBox="0 0 400 640" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full" aria-hidden="true">
      <defs>
        <linearGradient id="pcfSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#020617" /><stop offset=".55" stopColor="#0b1d3a" /><stop offset="1" stopColor="#1e3a5f" /></linearGradient>
        <linearGradient id="pcfWater" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0e7490" /><stop offset=".35" stopColor="#0b4f6c" /><stop offset="1" stopColor="#051e2e" /></linearGradient>
        <linearGradient id="pcfIce" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffffff" /><stop offset=".3" stopColor="#e0f2fe" /><stop offset="1" stopColor="#7dd3fc" /></linearGradient>
        <linearGradient id="pcfRay" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#a5f3fc" stopOpacity=".45" /><stop offset="1" stopColor="#a5f3fc" stopOpacity="0" /></linearGradient>
        <linearGradient id="pcfAur1" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#34d399" stopOpacity="0" /><stop offset=".4" stopColor="#34d399" /><stop offset="1" stopColor="#22d3ee" stopOpacity="0" /></linearGradient>
        <linearGradient id="pcfAur2" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#a78bfa" stopOpacity="0" /><stop offset=".6" stopColor="#c084fc" /><stop offset="1" stopColor="#34d399" stopOpacity="0" /></linearGradient>
        <linearGradient id="pcfParka" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fb923c" /><stop offset="1" stopColor="#c2410c" /></linearGradient>
        <radialGradient id="pcfGlow"><stop offset="0" stopColor="#fde68a" stopOpacity=".75" /><stop offset="1" stopColor="#fde68a" stopOpacity="0" /></radialGradient>
        <radialGradient id="pcfMoon"><stop offset=".6" stopColor="#f8fafc" /><stop offset="1" stopColor="#f8fafc" stopOpacity="0" /></radialGradient>
        <clipPath id="pcfUnder"><rect x="0" y={ICE_B - 2} width="400" height={640 - ICE_B} /></clipPath>
      </defs>
      {/* sky */}
      <rect width="400" height={ICE_Y + 4} fill="url(#pcfSky)" />
      {[[30, 30], [80, 70], [140, 24], [200, 54], [260, 18], [300, 66], [360, 40], [110, 110], [230, 100], [380, 96], [52, 140], [172, 150]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={i % 3 ? 0.9 : 1.4} fill="#fff" className={i % 2 ? 'pc-twinkle' : ''} style={{ animationDelay: `${i * 0.37}s` }} />)}
      <circle cx="318" cy="62" r="20" fill="url(#pcfMoon)" opacity=".9" />
      <g className="pc-aur-a"><path d="M-20 90Q80 30 180 80T420 50" stroke="url(#pcfAur1)" strokeWidth="34" fill="none" opacity=".38" strokeLinecap="round" /></g>
      <g className="pc-aur-b"><path d="M-20 130Q100 70 220 120T420 90" stroke="url(#pcfAur2)" strokeWidth="22" fill="none" opacity=".3" strokeLinecap="round" /></g>
      <path d="M0 250L0 200L40 168L70 190L120 150L170 196L210 176L250 200L300 160L350 196L400 170V250Z" fill="#1e3a5f" opacity=".85" />
      <path d="M120 150L132 162L122 166L110 160ZM300 160L312 172L298 172Z" fill="#e0f2fe" opacity=".8" />
      <path d="M0 250L0 222L60 206L130 226L190 212L260 228L330 210L400 224V250Z" fill="#cbd5e1" opacity=".55" />
      {/* igloo far left */}
      <g transform="translate(10 214)"><path d="M0 36Q0 0 30 0Q60 0 60 36Z" fill="#f8fafc" stroke="#94a3b8" /><path d="M6 24H54M3 30H57M12 14H48M30 0V14M18 14V24M42 14V24M24 24V30M38 24V30" stroke="#cbd5e1" strokeWidth=".8" /><path d="M22 36V28Q30 20 38 28V36Z" fill="#334155" /></g>
      {/* water */}
      <rect y={ICE_B - 2} width="400" height={640 - ICE_B + 2} fill="url(#pcfWater)" />
      <g clipPath="url(#pcfUnder)">
        {[-40, -14, 12, 38].map((o, i) => <polygon key={i} points={`${HOLE_X - 14 + o * 0.3},${ICE_B} ${HOLE_X + 14 + o * 0.3},${ICE_B} ${HOLE_X + o * 3.2 + 40},640 ${HOLE_X + o * 3.2 - 30},640`} fill="url(#pcfRay)" className="pc-ray" style={{ animationDelay: `${i * 1.3}s` }} />)}
        {/* background fish shoals */}
        <g className="pc-shoal" opacity=".28">{[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${i * 16} ${i % 2 * 9}c6-5 14-5 18 0c-4 5-12 5-18 0l-5-4v8z`} fill="#082f49" />)}</g>
        <g className="pc-shoal2" opacity=".22">{[0, 1, 2].map((i) => <path key={i} d={`M${i * 26} ${i % 2 * 12}c10-8 24-8 30 0c-6 8-20 8-30 0l-8-6v12z`} fill="#082f49" />)}</g>
        {/* sea bed */}
        <path d="M0 600Q60 584 120 598T240 594T400 590V640H0Z" fill="#0c2a3a" />
        {[[30, 600], [90, 604], [300, 596], [350, 600], [372, 598]].map(([x, y], i) => <path key={i} d={`M${x} ${y}q-6-30 2-60q8 30-2 60`} fill="#065f46" opacity=".7" className="pc-weed" style={{ animationDelay: `${i * 0.6}s` }} />)}
        <ellipse cx="160" cy="608" rx="22" ry="9" fill="#164e63" /><ellipse cx="250" cy="612" rx="14" ry="6" fill="#155e75" />
        {S.bubbles.map((b, i) => <circle key={i} cx={b.x} cy={b.y} r={b.r} fill="none" stroke="#e0f2fe" strokeWidth=".7" opacity={0.75 - b.life * 0.1} />)}
        {f && S.mode !== 'breach' && S.mode !== 'ice' && S.mode !== 'stow' && <FishSprite f={f} t={S.t} />}
      </g>
      {/* the ice sheet with its hole */}
      <path d={`M0 ${ICE_Y}Q40 ${ICE_Y - 5} 90 ${ICE_Y - 2}T${HOLE_X - HOLE_HALF} ${ICE_Y}V${ICE_B}H0Z`} fill="url(#pcfIce)" />
      <path d={`M${HOLE_X + HOLE_HALF} ${ICE_Y}Q270 ${ICE_Y - 4} 330 ${ICE_Y - 2}T400 ${ICE_Y}V${ICE_B}H${HOLE_X + HOLE_HALF}Z`} fill="url(#pcfIce)" />
      <path d={`M0 ${ICE_B}H${HOLE_X - HOLE_HALF}M${HOLE_X + HOLE_HALF} ${ICE_B}H400`} stroke="#38bdf8" strokeWidth="1.5" opacity=".7" />
      <path d="M40 256l14 6 10-3M120 258l-8 8M280 255l12 7 14-2M360 258l-6 9" stroke="#93c5fd" strokeWidth=".8" fill="none" />
      <path d={`M${HOLE_X - HOLE_HALF} ${ICE_Y}V${ICE_B}M${HOLE_X + HOLE_HALF} ${ICE_Y}V${ICE_B}`} stroke="#0369a1" strokeWidth="1.5" />
      <path d={`M${HOLE_X - HOLE_HALF + 1} ${ICE_B - 3}Q${HOLE_X} ${ICE_B - 3 + Math.sin(S.t * 3) * 1.5} ${HOLE_X + HOLE_HALF - 1} ${ICE_B - 3}`} stroke="#a5f3fc" strokeWidth="1.2" fill="none" opacity=".8" />
      {S.ripples.map((r, i) => <ellipse key={i} cx={r.x} cy={r.y} rx={(6 + r.life * 34) * r.w} ry={2 + r.life * 4} fill="none" stroke="#e0f2fe" strokeWidth="1.4" opacity={Math.max(0, 1 - r.life / 1.2)} />)}
      {/* the catch so far, piled on the ice */}
      {S.pile.map((p, i) => <FishSprite key={i} f={{ x: p.x + (i % 4) * 12, y: p.y - Math.floor(i / 4) * 7 - (i % 2) * 3, h: (i % 2 ? 180 : 0) + (i % 3 - 1) * 8, s: 0.3, anchor: 60, species: S.species, size: 0 }} t={0} />)}
      <Angler S={S} />
      {/* line, lure, the fish in the air */}
      <path d={line} stroke="#f8fafc" strokeWidth=".9" fill="none" opacity=".9" />
      {lure && <g transform={`translate(${lure.x} ${lure.y})`}><ellipse rx="2.6" ry="4.2" fill="#ef4444" stroke="#fff" strokeWidth=".8" /><path d="M0 4v3" stroke="#cbd5e1" /></g>}
      {f && (S.mode === 'breach' || S.mode === 'ice' || S.mode === 'stow') && (
        <>
          {S.mode === 'ice' && <ellipse cx={f.x} cy={ICE_Y + 1} rx={50 * f.s} ry="3" fill="#0c4a6e" opacity=".25" />}
          <FishSprite f={f} t={S.t} />
        </>
      )}
      {S.drops.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={p.r} fill="#e0f2fe" opacity=".9" />)}
    </svg>
  );
}

export default function Fishing({ fishing, bet, turbo, fx, onDone }) {
  const N = fishing.casts.length;
  const S = useRef(null); if (!S.current) { S.current = newSim(); S.current.species = fishing.bonus; }
  const [, setFrame] = useState(0);
  const [cast, setCast] = useState(-1);
  const [caption, setCaption] = useState(null);
  const [tally, setTally] = useState([]);
  const [badge, setBadge] = useState(null);
  const [summary, setSummary] = useState(null);
  const [fast, setFast] = useState(!!turbo);
  const speed = useRef(turbo ? 2 : 1);
  const root = useRef(null), svgRef = useRef(null), slots = useRef([]);
  const name = SPOTS[fishing.bonus].name;
  const sum = tally.reduce((a, v) => a + v, 0);

  useEffect(() => { if (window.innerWidth < 768) root.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, []);

  // the animation loop
  useEffect(() => {
    let raf = 0, last = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000) * speed.current; last = now;
      step(S.current, dt); setFrame((n) => (n + 1) % 1e6);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  // the story of the round
  useEffect(() => {
    let live = true;
    const W = (ms) => new Promise((r) => setTimeout(r, ms / speed.current));
    const until = (pred) => new Promise((r) => { const id = setInterval(() => { if (!live || pred()) { clearInterval(id); r(); } }, 40); });
    const sim = S.current;
    const sizeSfx = ['s', 's', 'm', 'l'];
    sim.hooks = {
      plop: () => sfx('plop', { gain: 0.7 }),
      breach: (size) => sfx(`splash_${sizeSfx[size]}`, { gain: 0.8 }) || fx.reel?.(),
      flop: (g) => sfx('flop', { gain: 0.7 * g, rate: rnd(0.9, 1.1) }),
    };
    const toPx = (x, y) => {
      const svg = svgRef.current, box = root.current?.getBoundingClientRect();
      if (!svg || !box) return { x: 0, y: 0 };
      const pt = svg.createSVGPoint(); pt.x = x; pt.y = y; const p = pt.matrixTransform(svg.getScreenCTM());
      return { x: p.x - box.left, y: p.y - box.top };
    };
    (async () => {
      await W(400); if (!live) return;
      voice(fishing.bonus) ;
      setCaption({ k: 'intro', text: `${name} bonus`, sub: `${N} casts${fishing.mult > 1 ? ` · every catch ×${fishing.mult}` : ''}` });
      await W(2200); if (!live) return;
      for (let i = 0; i < N; i++) {
        const v = fishing.casts[i], size = sizeOf(fishing.bonus, v);
        const lastCast = i === N - 1 && N > 1;
        setCast(i);
        setCaption({ k: `c${i}`, text: lastCast ? 'Last cast!' : `Cast ${i + 1} of ${N}` });
        if (lastCast) voice('last');
        // cast
        const side = Math.random() < 0.5 ? -1 : 1;
        sim.fish = { species: fishing.bonus, size, s: SCALE[size], x: side > 0 ? 460 : -60, y: rnd(420, 560), vx: 0, vy: 0, h: side > 0 ? 180 : 0, anchor: 118, side, F: 0, dir: { x: 0, y: 1 }, runT: 0 };
        sim.mode = 'cast'; sim.mt = 0; sim.castFrom = null; sim.plopped = false; sim.depth = rnd(400, 470);
        if (!sfx('cast', { gain: 0.7 })) fx.cast?.();
        await W(1300); if (!live) return;
        sim.mode = 'sink'; sim.mt = 0;
        await W(1500); if (!live) return;
        sim.mode = 'nibble'; sim.mt = 0;
        await W(rnd(900, 1700)); if (!live) return;
        // bite and fight
        if (!sfx('bite', { gain: 0.8 })) fx.bite?.();
        Object.assign(sim.fish, { fighting: true });
        sim.L0 = sim.L = Math.hypot(sim.fish.x - HOOK.x, sim.fish.y - HOOK.y) + 6; sim.ft = 0; sim.fightDur = 2.6 + size * 1.3 + rnd(0, 0.6); sim.tension = 0.6;
        sim.mode = 'fight'; sim.mt = 0;
        setCaption({ k: `f${i}`, text: size >= 2 ? 'Big fish!' : 'Fish on!', hot: true });
        if (size >= 2) voice('big'); else if (i === 0) voice('fishon');
        let strainAt = 0;
        while (live && sim.mode === 'fight') {
          if (sim.reeling) sfx('reel', { gain: 0.32, rate: rnd(0.92, 1.08) });
          else if (sim.t - strainAt > 1) { strainAt = sim.t; sfx('strain', { gain: 0.6 }); }
          await W(480);
        }
        await until(() => sim.mode === 'ice'); if (!live) return;
        await W(550); if (!live) return;
        // the value pops from the fish, then flies to the tally
        const at = toPx(sim.fish.x, sim.fish.y - 26);
        setBadge({ v, size, x: at.x, y: at.y, fly: false });
        setCaption({ k: `v${i}`, text: SIZE_LABEL[size], hot: size >= 2 });
        if (!sfx(`catch_${sizeSfx[size]}`, { gain: 0.8 })) fx.catchValue?.(size);
        if (size === 3) voice('monster'); else if (size === 2) voice('catch');
        await W(size >= 2 ? 1500 : 1100); if (!live) return;
        const slot = slots.current[i]?.getBoundingClientRect(), box = root.current?.getBoundingClientRect();
        if (slot && box) setBadge((b) => b && { ...b, fly: true, x: slot.left - box.left + slot.width / 2, y: slot.top - box.top + slot.height / 2 });
        await W(650); if (!live) return;
        setBadge(null); setTally((t) => [...t, v]); sfx('tally', { gain: 0.5 });
        sim.fish.toX = PILE.x + (i % 4) * 12; sim.fish.toY = PILE.y - Math.floor(i / 4) * 7 - (i % 2) * 3; sim.mode = 'stow'; sim.mt = 0;
        await W(800); if (!live) return;
      }
      // the payout
      setCaption(null); setCast(N);
      setSummary('sum'); sfx('tally', { gain: 0.6 });
      await W(1600); if (!live) return;
      if (fishing.mult > 1) { setSummary('mult'); if (!sfx('mult', { gain: 0.8 })) fx.mult?.(); await W(1800); if (!live) return; }
      setSummary('pays'); sting(fishing.pays >= 100 ? 'jackpot' : 'win');
      await W(3000); if (live) onDone();
    })();
    return () => { live = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const sim = S.current;
  const stars = useMemo(() => Array.from({ length: 6 }, (_, i) => i), []);
  return (
    <div ref={root} className="animate-fade-in absolute inset-0 z-30 overflow-hidden rounded-2xl scroll-mt-28 bg-[linear-gradient(180deg,#020617_0%,#0b1d3a_25%,#1e3a5f_38.5%,#e0f2fe_39.2%,#7dd3fc_42.4%,#0e7490_42.6%,#051e2e_100%)]" role="status" aria-label={`${name} bonus`}>
      <div className="relative mx-auto h-full max-w-full" style={{ aspectRatio: '5 / 8' }}>
        <SceneSvg S={sim} svgRef={svgRef} />
      </div>
      {/* title and the tally of casts */}
      <div className="absolute inset-x-2 top-2 rounded-xl border border-sky-200/30 bg-slate-950/65 px-2 py-1.5 shadow-lg">
        <div className="flex items-center justify-between gap-2 leading-tight">
          <div className="min-w-0">
            <div className="truncate font-display text-base tracking-wide text-sky-50 sm:text-xl">{name.toUpperCase()}</div>
            <div className="text-[9px] font-bold uppercase tracking-[.2em] text-sky-300">Fishing bonus{fishing.mult > 1 ? '' : ` · ${N} casts`}</div>
          </div>
          {fishing.mult > 1 && <div className="shrink-0 rounded-md bg-[linear-gradient(180deg,#fff7c2,#facc15,#b45309)] px-2 font-display text-sm text-amber-950 shadow-[0_0_12px_#facc15]">×{fishing.mult} power-up</div>}
          <div className="shrink-0 text-right"><div className="text-[9px] font-bold uppercase tracking-[.2em] text-sky-300">Total</div><div key={sum} className="p3-stamp font-display text-xl leading-none text-amber-300">{sum}x</div></div>
        </div>
        <div className="mt-1.5 flex gap-1">
          {fishing.casts.map((_, i) => (
            <div key={i} ref={(el) => { slots.current[i] = el; }} className={`flex h-7 flex-1 items-center justify-center gap-0.5 rounded-md text-xs font-bold tabular-nums ${i === cast && tally[i] == null ? 'bg-sky-400/30 ring-1 ring-sky-300' : 'bg-white/5'}`}>
              <svg viewBox="0 0 120 60" className="h-3 w-6 shrink-0"><Fish species={fishing.bonus} /></svg>
              {tally[i] != null ? <span key="v" className="p3-stamp text-white">{tally[i]}x</span> : <span className="text-slate-500">{i + 1}</span>}
            </div>
          ))}
        </div>
      </div>
      {/* tension meter while the fish fights */}
      {sim.mode === 'fight' && (
        <div className="absolute bottom-[14%] right-3 flex flex-col items-center gap-1">
          <div className="text-[9px] font-extrabold uppercase tracking-widest text-sky-100 [text-shadow:0_1px_3px_#000]">Line</div>
          <div className="relative h-28 w-3.5 overflow-hidden rounded-full border border-white/50 bg-slate-950/60">
            <div className="absolute inset-x-0 bottom-0 rounded-full" style={{ height: `${Math.round(sim.tension * 100)}%`, background: sim.tension > 0.75 ? '#ef4444' : sim.tension > 0.45 ? '#f59e0b' : '#22c55e' }} />
          </div>
        </div>
      )}
      {/* caption */}
      {caption && (
        <div key={caption.k} className="p3-stamp pointer-events-none absolute inset-x-0 top-[15%] text-center">
          <div className={`inline-block rounded-2xl px-4 py-1 font-display tracking-wide [text-shadow:0_2px_8px_#000] ${caption.hot ? 'text-3xl text-amber-300 sm:text-4xl' : 'text-2xl text-white sm:text-3xl'}`}>{caption.text}</div>
          {caption.sub && <div className="text-sm font-bold text-sky-200 [text-shadow:0_1px_4px_#000]">{caption.sub}</div>}
        </div>
      )}
      {/* the value of the fish just landed */}
      {badge && (
        <div className="pointer-events-none absolute z-10" style={{ left: badge.x, top: badge.y, transform: `translate(-50%,-50%) scale(${badge.fly ? 0.45 : 1})`, transition: badge.fly ? 'left .6s cubic-bezier(.5,0,.6,1), top .6s cubic-bezier(.5,0,.6,1), transform .6s' : 'none' }}>
          <div className={`p3-stamp rounded-xl px-3 py-1 font-display text-3xl ring-2 ${badge.size >= 2 ? 'bg-[linear-gradient(180deg,#fff7c2,#facc15,#b45309)] text-amber-950 ring-amber-100 shadow-[0_0_24px_#facc15]' : 'bg-sky-950/90 text-white ring-sky-200'}`}>{badge.v}x</div>
        </div>
      )}
      {/* the payout */}
      {summary && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="p3-stamp w-full max-w-xs rounded-2xl border-2 border-sky-200/60 bg-[linear-gradient(180deg,#0c4a6e,#082f49)] p-4 text-center shadow-[0_0_40px_rgba(125,211,252,.4)]">
            <div className="text-xs font-extrabold uppercase tracking-[.25em] text-sky-300">{name} · {N} casts</div>
            <div className="mt-1 font-display text-4xl text-white">{sum}x</div>
            {fishing.mult > 1 && (summary === 'mult' || summary === 'pays') && <div className="p3-stamp mx-auto mt-1 w-fit rounded-lg bg-[linear-gradient(180deg,#fff7c2,#facc15,#b45309)] px-3 font-display text-3xl text-amber-950 shadow-[0_0_20px_#facc15]">×{fishing.mult}</div>}
            {summary === 'pays' && (
              <div className="p3-stamp mt-2 rounded-xl bg-emerald-500 px-3 py-1.5 text-emerald-950">
                <div className="font-display text-2xl">Pays {fishing.pays}:1{fishing.capped ? ' (max)' : ''}</div>
                {bet > 0 && <div className="text-sm font-bold">{money(bet * (1 + fishing.pays))}</div>}
              </div>
            )}
            <div className="mt-2 flex justify-center gap-1">{stars.map((i) => <span key={i} className="h-1 w-1 rounded-full bg-sky-200/60" />)}</div>
          </div>
        </div>
      )}
      {!summary && (
        <button type="button" onClick={() => { const v = !fast; setFast(v); speed.current = v ? 2.5 : 1; }} aria-pressed={fast}
          className={`absolute bottom-2 left-2 rounded-full px-3 py-1.5 text-xs font-extrabold shadow ${fast ? 'bg-sky-300 text-sky-950' : 'bg-slate-950/70 text-sky-100 ring-1 ring-sky-200/50'}`}>{fast ? 'Fast ▸▸' : 'Normal ▸'}</button>
      )}
    </div>
  );
}
