// Polar Catch recorded audio (client/audio/polarcatch, made by tools/music/polar.py with free tools):
// Arctic base music, a sea-shanty bonus track, stings, effects and a British host (Kokoro TTS).
import { playSample, playSting, playVoice, preloadUrls, registerTracks, registerVoiceGame } from '../../../lib/sound.js';

const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
const au = (f) => (AUD.files.includes(`polarcatch/${f}.mp3`) ? `${AUD.base}polarcatch/${f}.mp3` : null);
const TRACKS = { base: au('music/base'), bonus: au('music/bonus'), win: au('music/win'), jackpot: au('music/jackpot') };
if (TRACKS.base) registerTracks('polarcatch', TRACKS);
if (au('voice/fishon')) registerVoiceGame('polarcatch');

export const HAS_AUDIO = !!TRACKS.base;
/** Play an effect; returns false if it isn't available (so the caller can fall back to the synth). */
export const sfx = (name, opts) => playSample(au(`sfx/${name}`), opts);
export const voice = (name, opts) => playVoice(au(`voice/${name}`), opts);
export const sting = (name) => playSting('polarcatch', name);
export function preloadPolar() {
  preloadUrls(['peg', 'spin', 'lit', 'bmult', 'bonus', 'cast', 'plop', 'bite', 'reel', 'strain', 'splash_s', 'splash_m', 'splash_l', 'flop', 'catch_s', 'catch_m', 'catch_l', 'tally', 'mult'].map((n) => au(`sfx/${n}`)));
  preloadUrls(['minnow', 'salmon', 'king', 'bonus', 'fishon', 'catch', 'monster', 'last', 'big'].map((n) => au(`voice/${n}`)));
}
