// Polar Catch – an original Arctic fishing wheel game.
// The server settles the whole round first; the screen then reveals it:
// pre-spin multipliers → wheel spin → flake win or fishing bonus → payout.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, PremiumShell, RecentList, SidePanel, sleep, usePremium } from '../../../components/Premium.jsx';
import { WinAmount } from '../../../components/GameShell.jsx';
import { Fish, Flake, POLAR_LOBBY } from '../../../components/SlotArtPolar.jsx';
import { themeSfx } from '../../../lib/sound.js';
import { money } from '../../../lib/format.js';
import { BONUS_IDS, BONUS_MULT, FLAKE_MULTS, MAX_WIN_X, SPOTS, SPOT_MAX, SPOT_MIN, WHEEL } from '../../../../../server/games/polarcatch/config.js';
import { bonusRtp, flakeRtp } from '../../../../../server/games/polarcatch/maths.js';
import { Wheel, targetAngle } from './Wheel.jsx';
import Fishing from './Fishing.jsx';

const CHIPS = [10, 50, 100, 500, 1000, 2500];
const CHIP_STYLE = { 10: 'from-slate-200 to-slate-400 text-slate-900', 50: 'from-sky-300 to-sky-600 text-white', 100: 'from-emerald-300 to-emerald-600 text-white', 500: 'from-fuchsia-300 to-fuchsia-600 text-white', 1000: 'from-amber-200 to-amber-500 text-amber-950', 2500: 'from-rose-300 to-rose-600 text-white' };
const SPOT_STYLE = {
  blue: 'from-sky-400 to-sky-700 ring-sky-200/60', white: 'from-slate-50 to-slate-300 ring-white text-slate-900',
  minnow: 'from-cyan-400 to-cyan-800 ring-cyan-200/60', salmon: 'from-orange-400 to-orange-700 ring-orange-200/60', king: 'from-rose-500 to-rose-900 ring-rose-200/60',
};
const chipLabel = (v) => (v >= 100 ? `£${v / 100}` : `${v}p`);
const pct = (x) => `${(x * 100).toFixed(2)}%`;

function Snow() {
  const flakes = useMemo(() => Array.from({ length: 30 }, (_, i) => ({ x: (i * 37) % 100, d: `${-(i * 0.6)}s`, t: `${6 + (i % 5)}s`, s: 2 + (i % 3) })), []);
  return <>{flakes.map((f, i) => <span key={i} className="pc-snow absolute top-0 rounded-full bg-white/80" style={{ left: `${f.x}%`, width: f.s, height: f.s, animationDelay: f.d, animationDuration: f.t }} />)}</>;
}

function Scene() {
  return (
    <>
      <div className="absolute inset-0 bg-[linear-gradient(180deg,#020617,#0b1d3a_40%,#0e4a6e_70%,#cfeafd)]" />
      <div className="pc-aurora absolute inset-x-0 top-0 h-1/2 opacity-70" />
      <svg viewBox="0 0 400 80" preserveAspectRatio="none" className="absolute bottom-[10%] left-0 h-[18%] w-full opacity-80" aria-hidden="true"><polygon points="0,80 0,50 40,30 80,46 130,18 170,40 220,22 270,44 320,20 360,38 400,30 400,80" fill="#e0f2fe" /><polygon points="130,18 142,28 118,30" fill="#fff" /></svg>
      <div className="absolute inset-x-0 bottom-0 h-[12%] bg-[linear-gradient(180deg,#e0f2fe,#bae6fd)]" />
      <svg viewBox="0 0 60 30" className="absolute bottom-[8%] left-[4%] w-[12%] opacity-90" aria-hidden="true"><path d="M2 30Q2 2 30 2Q58 2 58 30Z" fill="#f8fafc" stroke="#94a3b8" /><path d="M8 18H52M5 24H55M14 10H46" stroke="#cbd5e1" /><path d="M24 30V22Q30 16 36 22V30Z" fill="#334155" /></svg>
      <Snow />
    </>
  );
}

function Spot({ id, amount, onClick, mult, result, disabled, winning }) {
  const s = SPOTS[id];
  const isFlake = s.kind === 'flake';
  return (
    <button type="button" onClick={onClick} disabled={disabled}
      className={`relative flex min-h-[74px] flex-col items-center justify-center rounded-xl bg-gradient-to-b p-1.5 text-center ring-2 transition-transform active:scale-95 disabled:cursor-not-allowed ${SPOT_STYLE[id]} ${id === 'white' ? '' : 'text-white'} ${winning ? 'pc-win scale-105' : ''}`}
      aria-label={`${s.name}: ${amount ? `bet ${money(amount)}` : 'no bet'}. Tap to add a chip.`}>
      {mult > 1 && <span className="p3-stamp absolute -right-1.5 -top-2 rounded-md bg-[linear-gradient(180deg,#fff7c2,#facc15)] px-1.5 font-display text-sm text-amber-950 shadow-[0_0_10px_#facc15]">x{mult}</span>}
      <div className="h-7 w-12">
        {isFlake ? <svg viewBox="0 0 24 24" className="mx-auto h-7 w-7"><Flake fill={id === 'white' ? '#0ea5e9' : '#fff'} stroke="none" /></svg>
          : <svg viewBox="0 0 120 60" className="h-full w-full"><Fish species={id} /></svg>}
      </div>
      <div className="text-[11px] font-extrabold uppercase leading-tight tracking-wide">{s.name}</div>
      <div className={`text-[10px] font-semibold ${id === 'white' ? 'text-slate-600' : 'text-white/80'}`}>{isFlake ? 'Pays 1:1' : `Bonus · up to ${s.maxPay}:1`}</div>
      {amount > 0 && <div className="mt-0.5 rounded-full bg-black/55 px-2 text-xs font-bold tabular-nums text-white">{money(amount)}</div>}
      {result > 0 && <div className="absolute inset-x-1 bottom-1 rounded bg-emerald-500/90 text-[11px] font-bold text-white">+{money(result)}</div>}
    </button>
  );
}

export default function PolarCatch() {
  const { user, view, history, play, commit, guard, shake, doShake } = usePremium('polarcatch');
  const base = useMemo(() => themeSfx('polarcatch'), []);
  const fx = useMemo(() => ({
    ...base,
    cast: () => base.special(), bite: () => base.coin(), reel: () => base.tease(), catchValue: (s) => base.win(s >= 2 ? 2 : 1), mult: () => base.bonus(),
  }), [base]);
  const [chip, setChip] = useState(100);
  const [bets, setBets] = useState({});
  const [last, setLast] = useState(null);
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [dur, setDur] = useState(5000);
  const [lit, setLit] = useState({});
  const [bonusMult, setBonusMult] = useState({});
  const [landed, setLanded] = useState(null);
  const [fishing, setFishing] = useState(null);
  const [res, setRes] = useState(null);
  const [big, setBig] = useState(null);
  const [busy, setBusy] = useState(false);
  const [turbo, setTurbo] = useState(() => { try { return localStorage.getItem('pc_turbo') === '1'; } catch { return false; } });
  const fishDone = useRef(null);
  const wheelBox = useRef(null);
  const t = useCallback((ms) => sleep(turbo ? ms * 0.5 : ms), [turbo]);

  const total = Object.values(bets).reduce((a, b) => a + b, 0);
  const balance = user?.balance ?? 0;
  const add = (id, amt = chip) => {
    if (busy) return;
    setBets((b) => {
      const v = Math.min(SPOT_MAX, (b[id] || 0) + amt);
      const next = { ...b, [id]: v };
      if (Object.values(next).reduce((a, x) => a + x, 0) > balance) return b;
      return next;
    });
    base.click();
  };
  const allBonuses = () => { if (busy) return; setBets((b) => { const n = { ...b }; for (const id of BONUS_IDS) n[id] = Math.min(SPOT_MAX, (n[id] || 0) + chip); return Object.values(n).reduce((a, x) => a + x, 0) > balance ? b : n; }); base.click(); };
  const double = () => setBets((b) => { const n = Object.fromEntries(Object.entries(b).map(([k, v]) => [k, Math.min(SPOT_MAX, v * 2)])); return Object.values(n).reduce((a, x) => a + x, 0) > balance ? b : n; });

  const spin = () => guard(async () => {
    if (!total || total > balance) return;
    setBusy(true); setRes(null); setLanded(null); setFishing(null); setLit({}); setBonusMult({});
    const out = await play('spin', { bets });
    if (!out) { setBusy(false); return; }
    setLast(bets);
    // 1. pre-spin multipliers drop onto the wheel and the bonus spots
    const litEntries = Object.entries(out.lit);
    for (const [i, m] of litEntries) { setLit((l) => ({ ...l, [i]: m })); base.land(); await t(260); }
    for (const [id, m] of Object.entries(out.bonusMult)) { setBonusMult((b) => ({ ...b, [id]: m })); base.coin(); await t(320); }
    if (litEntries.length || Object.keys(out.bonusMult).length) await t(300);
    // 2. the wheel spins to the chosen segment
    const d = turbo ? 2600 : 5200;
    setDur(d);
    const target = targetAngle(angle, out.segment, turbo ? 3 : 6, (out.segment * 7919 % 100) / 50 - 1);
    if (window.innerWidth < 768) wheelBox.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setSpinning(true); setAngle(target); base.spin();
    const ticks = turbo ? 24 : 40;
    for (let k = 0; k < ticks; k++) setTimeout(() => base.stop(k), d * (1 - (1 - k / ticks) ** 0.5));
    await sleep(d + 150);
    setSpinning(false); setLanded(out.segment);
    // 3. outcome
    if (out.fishing) {
      base.bonus(); doShake(false);
      await t(600);
      await new Promise((resolve) => { fishDone.current = resolve; setFishing(out.fishing); });
      setFishing(null);
    } else if (out.lit[out.segment]) { base.win(2); doShake(false); }
    setRes(out); commit(); setBusy(false);
    if (out.payout >= out.staked * 10) setBig({ amount: out.payout, bet: out.staked });
    else if (out.payout > 0) base.win(1);
  });

  // space bar spins
  const spinRef = useRef(spin); spinRef.current = spin;
  useEffect(() => {
    const h = (e) => { if (e.code === 'Space' && !e.repeat && !['INPUT', 'TEXTAREA', 'BUTTON'].includes(e.target.tagName)) { e.preventDefault(); if (big) setBig(null); else spinRef.current(); } };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [big]);

  const hist = view?.history || [];
  const colour = { blue: 'bg-sky-500', white: 'bg-slate-100 text-slate-900', minnow: 'bg-cyan-600', salmon: 'bg-orange-500', king: 'bg-rose-600' };
  const shortName = { blue: 'B', white: 'W', minnow: 'FM', salmon: 'AS', king: 'RK' };
  const flakeR = flakeRtp();

  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to play</h3>
        <p>Place chips on any of the five spots, then spin. The wheel has <b>53 segments</b>: 23 Blue Flake, 23 White Flake, 4 Frost Minnows, 2 Amber Salmon and 1 Ruby Kings. The spot the pointer lands on wins.</p>
        <p><b>Pre-spin multipliers</b>: before each spin, up to {Math.max(...FLAKE_MULTS.count.map(([c]) => c))} flake segments can light up with x3 to x10. A flake win on a lit segment pays that many to 1 instead of 1:1. Each fishing bonus can also be powered up as a whole, by x2 to x10 ({Math.round(BONUS_MULT.chance * 100)}% chance each, every spin).</p>
        <p><b>Fishing bonuses</b>: land a fish segment and its bonus round starts. One catch is reeled in through the ice, worth a multiple of your bet on that spot, then multiplied by that bonus's pre-spin multiplier. Your bet is returned as well.</p>
        <p><b>All Bonuses</b> places your chip on all three fish spots at once.</p>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">Payouts and return to player</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-400"><tr><th className="py-1 pr-2">Bet spot</th><th className="pr-2">Segments</th><th className="pr-2">Base payout</th><th className="pr-2">Max payout</th><th>RTP</th></tr></thead>
            <tbody className="text-slate-200">
              <tr className="border-t border-white/10"><td className="py-1 pr-2">Blue / White Flake</td><td>23 each</td><td>1:1</td><td>10:1 (lit x10)</td><td>{pct(flakeR)}</td></tr>
              <tr className="border-t border-white/10"><td className="py-1 pr-2">Frost Minnows</td><td>4</td><td>3–100:1</td><td>999:1</td><td>{pct(bonusRtp('minnow'))}</td></tr>
              <tr className="border-t border-white/10"><td className="py-1 pr-2">Amber Salmon</td><td>2</td><td>4–200:1</td><td>1,999:1</td><td>{pct(bonusRtp('salmon'))}</td></tr>
              <tr className="border-t border-white/10"><td className="py-1 pr-2">Ruby Kings</td><td>1</td><td>10–500:1</td><td>4,999:1</td><td>{pct(bonusRtp('king'))}</td></tr>
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-slate-400">The return for each spot is calculated exactly from the game's tables. A round pays at most {MAX_WIN_X.toLocaleString()}x your total stake. Bets {money(SPOT_MIN)}–{money(SPOT_MAX)} per spot.</p>
      </section>
      <section className="rounded-lg border border-sky-400/30 bg-sky-400/5 p-3 text-xs text-slate-300">
        <b className="text-sky-200">About this game</b>: Polar Catch is an original game in the style of fishing-wheel game shows. It is not affiliated with any live casino studio. There is no live presenter; the wheel is driven by the server's random number generator, and every result is decided before the wheel moves.
      </section>
    </>
  );

  return (
    <PremiumShell game="polarcatch" rtp={`up to ${pct(flakeR)}`} tagline="53-segment wheel · pre-spin multipliers · 3 fishing bonuses" shake={shake}
      stageClass="border-2 border-sky-200/50 shadow-[0_0_60px_rgba(125,211,252,0.25)]" bg={<Scene />} info={info}
      below={(
        <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
          {/* Chips on one row, bet tools on their own row so nothing is pushed off a narrow screen */}
          <div className="flex items-center justify-between gap-1 px-0.5 pt-0.5" role="radiogroup" aria-label="Chip value">
            {CHIPS.map((c) => (
              <button key={c} type="button" role="radio" aria-checked={chip === c} onClick={() => setChip(c)} disabled={c > balance}
                className={`h-10 w-10 shrink-0 rounded-full bg-gradient-to-b text-[11px] font-extrabold shadow ring-2 ring-white/30 disabled:opacity-30 ${CHIP_STYLE[c]} ${chip === c ? 'scale-110 ring-4 ring-sky-200' : ''}`}>{chipLabel(c)}</button>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            <button className="h-9 rounded-lg bg-navy-700 text-xs font-semibold text-slate-200 disabled:opacity-40" disabled={busy || !total} onClick={() => setBets({})}>Clear</button>
            <button className="h-9 rounded-lg bg-navy-700 text-xs font-semibold text-slate-200 disabled:opacity-40" disabled={busy || !total} onClick={double}>Double</button>
            <button className="h-9 rounded-lg bg-navy-700 text-xs font-semibold text-slate-200 disabled:opacity-40" disabled={busy || !last || total > 0} onClick={() => setBets(last)}>Rebet</button>
          </div>
          <div className="flex items-center gap-2">
            <div className="min-w-[5.5rem] leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Total bet</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(total)}</div></div>
            <button onClick={spin} disabled={busy || !total || total > balance} className="btn h-14 flex-1 rounded-full bg-gradient-to-b from-sky-200 to-sky-500 text-lg font-extrabold text-sky-950 shadow-lg active:scale-95 disabled:opacity-50">
              {busy ? 'Spinning…' : !total ? 'Place a bet' : total > balance ? 'Not enough balance' : 'Spin'}
            </button>
            <button onClick={() => { const v = !turbo; setTurbo(v); try { localStorage.setItem('pc_turbo', v ? '1' : '0'); } catch { /* */ } }} className={`h-11 rounded-lg px-3 text-xs font-semibold ${turbo ? 'bg-sky-300 text-sky-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={turbo}>Quick</button>
          </div>
        </div>
      )}
      side={<>
        <SidePanel title="Last results">
          <div className="flex flex-wrap gap-1">{hist.length ? hist.map((h, i) => <span key={i} className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${colour[h.landed]}`}>{shortName[h.landed]}{h.mult > 1 ? ` x${h.mult}` : ''}{h.fish ? ` ${h.fish}x` : ''}</span>) : <span className="text-xs text-slate-500">No spins yet</span>}</div>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      <div className="relative">
        <div className="grid items-center gap-3 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <div ref={wheelBox} className="relative mx-auto w-full scroll-mt-28" style={{ maxWidth: 'min(100%, max(240px, calc(100dvh - 520px)), 460px)' }}>
            <Wheel angle={angle} spinning={spinning} duration={dur} lit={lit} landed={landed} flashLit />
          </div>
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              {['blue', 'white'].map((id) => <Spot key={id} id={id} amount={bets[id]} onClick={() => add(id)} disabled={busy} result={res?.results?.[id]?.ret} winning={res?.landed === id} />)}
            </div>
            <div className="grid grid-cols-3 gap-2">
              {BONUS_IDS.map((id) => <Spot key={id} id={id} amount={bets[id]} onClick={() => add(id)} disabled={busy} mult={bonusMult[id]} result={res?.results?.[id]?.ret} winning={res?.landed === id} />)}
            </div>
            <button type="button" onClick={allBonuses} disabled={busy} className="w-full rounded-lg bg-[linear-gradient(90deg,#0891b2,#ea580c,#e11d48)] py-2 text-sm font-extrabold uppercase tracking-wide text-white shadow ring-1 ring-white/30 disabled:opacity-50">All Bonuses +{chipLabel(chip)}</button>
            <div className="flex min-h-12 flex-col items-center justify-center rounded-xl bg-black/45 px-2 py-1.5 text-center leading-tight">
              {res?.payout ? <WinAmount win={res.payout} staked={res.staked} /> : <div className="text-sm text-white/70">{busy ? 'Good luck…' : res ? `Landed on ${SPOTS[res.landed].name}` : 'Tap the spots to place chips'}</div>}
            </div>
          </div>
        </div>
        {fishing && <Fishing fishing={fishing} bet={res?.results?.[fishing.bonus]?.bet ?? bets[fishing.bonus] ?? 0} wait={t} fx={fx} onDone={() => fishDone.current?.()} />}
        {big && <BigWin game="polarcatch" amount={big.amount} bet={big.bet} onDone={() => setBig(null)}
          cinematic={<svg viewBox="0 0 100 100" className="pointer-events-none absolute inset-0 h-full w-full opacity-25" preserveAspectRatio="xMidYMid slice" aria-hidden="true">{POLAR_LOBBY}</svg>} />}
      </div>
    </PremiumShell>
  );
}
