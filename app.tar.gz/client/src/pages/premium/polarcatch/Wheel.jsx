// Polar Catch – the 53-segment wheel (SVG). Spins to whatever segment the server already chose;
// lit multipliers sit on their segments. A chrome rim with chasing bulbs, pegs between segments and
// a flapper pointer that the caller kicks on every peg (see PolarCatch.jsx).
import { forwardRef } from 'react';
import { WHEEL } from '../../../../../server/games/polarcatch/config.js';
import { Fish, Flake } from '../../../components/SlotArtPolar.jsx';

const N = WHEEL.length, A = 360 / N;
export const SEG_ANGLE = A;
const FILL = { blue: 'url(#pcBlue)', white: 'url(#pcWhite)', minnow: 'url(#pcMinnow)', salmon: 'url(#pcSalmon)', king: 'url(#pcKing)' };
const rad = (d) => ((d - 90) * Math.PI) / 180;
const pt = (r, d) => [r * Math.cos(rad(d)), r * Math.sin(rad(d))];
function wedge(i, r0, r1) {
  const a0 = i * A - A / 2, a1 = i * A + A / 2;
  const [x0, y0] = pt(r1, a0), [x1, y1] = pt(r1, a1), [x2, y2] = pt(r0, a1), [x3, y3] = pt(r0, a0);
  return `M${x0} ${y0}A${r1} ${r1} 0 0 1 ${x1} ${y1}L${x2} ${y2}A${r0} ${r0} 0 0 0 ${x3} ${y3}Z`;
}
const BULBS = 36;

/** Angle that puts `segment` under the top pointer after at least `turns` full turns. */
export function targetAngle(current, segment, turns, jitter = 0) {
  const base = current + 360 * turns;
  const want = -segment * A + jitter * A * 0.35;
  return base + ((((want - base) % 360) + 360) % 360);
}

export const Wheel = forwardRef(function Wheel({ angle, spinning, duration, lit = {}, landed, flashLit, rotRef, flapRef }, ref) {
  const settled = landed != null && !spinning;
  return (
    <div className="relative mx-auto aspect-square w-full" ref={ref}>
      <div className="pointer-events-none absolute inset-[-4%] rounded-full bg-[radial-gradient(circle,rgba(125,211,252,.35),transparent_68%)]" />
      <svg viewBox="-118 -118 236 236" className={`absolute inset-0 h-full w-full ${spinning ? 'pc-bulbs-fast' : ''}`} aria-hidden="true">
        <defs>
          <linearGradient id="pcChrome" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#f8fafc" /><stop offset=".3" stopColor="#94a3b8" /><stop offset=".5" stopColor="#e2e8f0" /><stop offset=".75" stopColor="#64748b" /><stop offset="1" stopColor="#cbd5e1" /></linearGradient>
          <radialGradient id="pcGloss" cx=".35" cy=".25" r=".8"><stop offset="0" stopColor="#fff" stopOpacity=".28" /><stop offset=".5" stopColor="#fff" stopOpacity="0" /></radialGradient>
          <radialGradient id="pcBulb"><stop offset="0" stopColor="#fff" /><stop offset=".4" stopColor="#fef9c3" /><stop offset="1" stopColor="#facc15" stopOpacity="0" /></radialGradient>
        </defs>
        <circle r="117" fill="#020617" opacity=".55" transform="translate(0 4)" />
        <circle r="116" fill="url(#pcChrome)" />
        <circle r="110" fill="#0c4a6e" stroke="#082f49" strokeWidth="1.5" />
        {Array.from({ length: BULBS }, (_, i) => { const [x, y] = pt(113, (i * 360) / BULBS); return <circle key={i} cx={x} cy={y} r="2.6" fill="url(#pcBulb)" className={i % 2 ? 'pc-bulb-a' : 'pc-bulb-b'} />; })}
        <g ref={rotRef} style={{ transform: `rotate(${angle}deg)`, transition: spinning ? `transform ${duration}ms cubic-bezier(.12,.62,.08,1)` : 'none' }}>
          {WHEEL.map((s, i) => (
            <g key={i}>
              <path d={wedge(i, 46, 107)} fill={FILL[s]} stroke="#082f49" strokeWidth=".8" opacity={settled && landed !== i ? 0.5 : 1} />
              {s !== 'blue' && s !== 'white' && <path d={wedge(i, 100, 107)} fill="url(#pcGold)" opacity=".9" />}
              <g transform={`rotate(${i * A}) translate(0 -88)`}>
                {s === 'blue' || s === 'white'
                  ? <g transform="translate(-6 -6) scale(.5)"><Flake fill={s === 'blue' ? '#e0f2fe' : '#0ea5e9'} stroke="none" /></g>
                  : <g transform="rotate(-90) translate(-10 -5) scale(.17)"><Fish species={s} /></g>}
              </g>
              {lit[i] && (
                <g transform={`rotate(${i * A}) translate(0 -66)`} className={flashLit ? 'pc-lit' : ''}>
                  <rect x="-7.5" y="-6" width="15" height="12" rx="3" fill="url(#pcGold)" stroke="#78350f" strokeWidth=".8" />
                  <text y="3.4" textAnchor="middle" fontFamily="'Lilita One'" fontSize="8.5" fill="#451a03">x{lit[i]}</text>
                </g>
              )}
            </g>
          ))}
          {/* pegs between segments */}
          {Array.from({ length: N }, (_, i) => { const [x, y] = pt(104, i * A + A / 2); return <g key={i}><circle cx={x} cy={y} r="2.2" fill="url(#pcChrome)" stroke="#334155" strokeWidth=".5" /></g>; })}
          {settled && <path d={wedge(landed, 46, 107)} fill="none" stroke="#fef08a" strokeWidth="2.4" />}
        </g>
        <circle r="107" fill="url(#pcGloss)" pointerEvents="none" />
        {/* hub */}
        <circle r="46" fill="url(#pcChrome)" />
        <circle r="42" fill="url(#pcSky)" stroke="#7dd3fc" strokeWidth="1" />
        <path d="M-34 -6Q-10 -24 14 -14T38 -18" stroke="#34d399" strokeWidth="5" opacity=".35" fill="none" />
        <g transform="translate(-16 -26) scale(1.35)"><Flake fill="#bae6fd" stroke="none" /></g>
        <text y="16" textAnchor="middle" fontFamily="'Lilita One'" fontSize="11" fill="#e0f2fe" letterSpacing="1">POLAR</text>
        <text y="27" textAnchor="middle" fontFamily="'Lilita One'" fontSize="11" fill="#7dd3fc" letterSpacing="1">CATCH</text>
        <circle r="42" fill="url(#pcGloss)" />
      </svg>
      {/* flapper pointer: pivots at its top and is kicked by the pegs */}
      <div className="absolute left-1/2 top-[-4.5%] z-10 h-[13%] w-[9%] -translate-x-1/2">
        <svg ref={flapRef} viewBox="0 0 30 40" className="pc-flapper h-full w-full drop-shadow-[0_3px_4px_rgba(0,0,0,0.6)]" aria-hidden="true">
          <path d="M15 40L3 12Q3 2 15 2Q27 2 27 12Z" fill="url(#pcGold)" stroke="#78350f" strokeWidth="1.6" />
          <path d="M15 34L8 13Q9 7 15 7" stroke="#fff" strokeOpacity=".55" strokeWidth="1.6" fill="none" />
          <circle cx="15" cy="10" r="4" fill="url(#pcChrome)" stroke="#475569" strokeWidth="1" />
        </svg>
      </div>
    </div>
  );
});
