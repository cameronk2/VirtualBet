// Developer-only: draws every symbol of a slot alone at 512px on a transparent background so the
// art pipeline (tools/art/paint.py) can capture and repaint it. Reached at /__art?game=<id>.
import { useEffect } from 'react';

globalThis.__vbRawArt = true;   // draw the raw vector art, not the painted versions
import { SYMS3, SlotDefs3, Sym3 } from '../components/SlotArt3.jsx';
import { BRICK_NAMES, BrickDefs, BrickSym } from '../components/SlotArtBrick.jsx';
import { MOON_NAMES, MoonDefs, MoonSym } from '../components/SlotArtMoon.jsx';
import { Sym, SYMBOLS } from '../components/SlotArt2.jsx';
import { ALL_SYMBOLS, SlotSymbol } from '../components/SlotSymbols.jsx';

const LISTS = {
  ...Object.fromEntries(Object.entries(SYMS3).map(([g, l]) => [g, l.filter((s) => !['MULT', 'GRAVITY'].includes(s))])),
  brick: Object.keys(BRICK_NAMES), moonridge: Object.keys(MOON_NAMES).filter((s) => !['W2', 'W3', 'WG'].includes(s)),
  vault: SYMBOLS.vault.filter((s) => s !== 'COIN'), starlight: SYMBOLS.starlight, nebula: [...SYMBOLS.nebula, 'SCAT'], fruit: SYMBOLS.fruit,
  lakeside: ALL_SYMBOLS.filter((s) => s !== 'FISH'),
};
function One({ game, s }) {
  if (SYMS3[game]) return <Sym3 game={game} s={s} />;
  if (game === 'brick') return <BrickSym s={s} />;
  if (game === 'moonridge') return <MoonSym s={s} />;
  if (game === 'lakeside') return <SlotSymbol cell={{ s }} />;
  return <Sym s={s} game={game} />;
}
export default function ArtCapture() {
  const game = new URLSearchParams(location.search).get('game');
  useEffect(() => { document.documentElement.classList.add('art-capture'); }, []);
  return (
    <div>
      <SlotDefs3 /><BrickDefs /><MoonDefs />
      <style>{`html.art-capture, html.art-capture body { background: transparent !important; } .art-capture header, .art-capture nav, .art-capture footer { display: none !important; }
        .art-cell, .art-cell * { background: transparent !important; box-shadow: none !important; border-color: transparent !important; } .art-cell svg { padding: 0 !important; }`}</style>
      <div className="flex flex-wrap gap-2">
        {(LISTS[game] || []).map((s) => <div key={s} data-sym={s} className="art-cell" style={{ width: 512, height: 512 }}><One game={game} s={s} /></div>)}
      </div>
    </div>
  );
}
