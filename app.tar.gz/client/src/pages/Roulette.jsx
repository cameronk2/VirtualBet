import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { usePopout } from '../components/Popout.jsx';
import GameShell, { useGame } from '../components/GameShell.jsx';
import { money } from '../lib/format.js';
import { sfx, playSample, queueVoice, clearVoiceQueue, registerTracks, registerVoiceGame, preloadUrls } from '../lib/sound.js';
import WinCelebration from '../components/WinCelebration.jsx';
import { colourOf, RED, WHEEL_ORDER } from '../../../server/games/roulette.js';

const CHIPS = [10, 100, 500, 2500, 10000, 50000, 100000];
const chipLabel = (v) => (v < 100 ? `${v}p` : v >= 100000 ? `£${v / 100000}k` : `£${v / 100}`);
const CHIP_CLS = { 10: 'bg-slate-200 text-navy-950', 50: 'bg-sky-500 text-white', 100: 'bg-red-600 text-white', 500: 'bg-emerald-600 text-white', 2500: 'bg-zinc-900 text-gold-400 ring-gold-500', 10000: 'bg-violet-700 text-white', 50000: 'bg-amber-500 text-navy-950', 100000: 'bg-gradient-to-br from-gold-400 to-amber-700 text-navy-950' };
const key = (nums) => [...nums].sort((a, b) => a - b).join('-');
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
const PAYS = { 1: '35:1', 2: '17:1', 3: '11:1', 4: '8:1', 6: '5:1', 12: '2:1', 18: '1:1' };
const betName = (nums) => {
  const n = nums.length;
  if (n === 1) return `Straight ${nums[0]}`;
  const s = [...nums].sort((a, b) => a - b).join('/');
  if (n === 2) return `Split ${s}`;
  if (n === 3) return nums.includes(0) ? `Trio ${s}` : `Street ${s}`;
  if (n === 4) return nums.includes(0) ? 'First four 0/1/2/3' : `Corner ${s}`;
  if (n === 6) return `Six line ${Math.min(...nums)}-${Math.max(...nums)}`;
  const k = key(nums);
  const named = [...OUTSIDE, ...DOZENS].find((o) => key(o.nums) === k);
  if (named) return named.label === '1st 12' || named.label === '2nd 12' || named.label === '3rd 12' ? `${named.label} dozen` : named.label;
  const ci = COLUMNS.findIndex((c) => key(c.nums) === k);
  return ci >= 0 ? `Column ${ci + 1}` : s;
};
const SEG = 360 / 37;
// Recorded table audio (client/audio/roulette): a British female croupier (Kokoro TTS) calls every number
// and colour; the ball, chips and wins are synthesised (tools/music/roulette.py). Lounge music is shared with blackjack.
const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
const au = (f) => (AUD.files.includes(`${f}.mp3`) ? `${AUD.base}${f}.mp3` : null);
if (au('blackjack/music/base')) registerTracks('roulette', { base: au('blackjack/music/base') });
if (au('roulette/voice/n0')) registerVoiceGame('roulette');
const VO = (k) => au(`roulette/voice/${k}`);
const RFX = (k) => au(`roulette/sfx/${k}`);
const CHIP_COL = { 10: ['#e2e8f0', '#0f172a'], 100: ['#dc2626', '#fff'], 500: ['#059669', '#fff'], 2500: ['#18181b', '#fbbf24'], 10000: ['#6d28d9', '#fff'], 50000: ['#f59e0b', '#1c1917'], 100000: ['#d4a017', '#1c1917'] };
/** A casino chip: coloured body, white edge inserts, value in the middle. */
function Chip({ value, label, size = 26, className = '' }) {
  const [bg, fg] = CHIP_COL[CHIPS.filter((c) => c <= value).pop() || 10];
  return (
    <span className={`rl-chip ${className}`} style={{ '--cb': bg, '--cf': fg, width: size, height: size, fontSize: Math.max(8, size * 0.34) }}>
      <span>{label ?? money(value).replace('£', '').replace('.00', '')}</span>
    </span>
  );
}
const reduceMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

const OUTSIDE = [
  { label: '1-18', nums: range(1, 18) }, { label: 'EVEN', nums: range(1, 36).filter((n) => n % 2 === 0) },
  { label: 'RED', nums: [...RED], cls: 'bg-red-700' }, { label: 'BLACK', nums: range(1, 36).filter((n) => !RED.has(n)), cls: 'bg-zinc-900' },
  { label: 'ODD', nums: range(1, 36).filter((n) => n % 2 === 1) }, { label: '19-36', nums: range(19, 36) },
];
const DOZENS = [{ label: '1st 12', nums: range(1, 12) }, { label: '2nd 12', nums: range(13, 24) }, { label: '3rd 12', nums: range(25, 36) }];
const COLUMNS = [1, 2, 3].map((c) => ({ label: '2:1', nums: range(1, 36).filter((n) => (n - 1) % 3 === c - 1) }));

// Racetrack "call bets": each is a list of standard bets, in chip units
const CALL_BETS = {
  Voisins: [[[0, 2, 3], 2], [[4, 7], 1], [[12, 15], 1], [[18, 21], 1], [[19, 22], 1], [[32, 35], 1], [[25, 26, 28, 29], 2]],
  Tiers: [[[5, 8], 1], [[10, 11], 1], [[13, 16], 1], [[23, 24], 1], [[27, 30], 1], [[33, 36], 1]],
  Orphelins: [[[1], 1], [[6, 9], 1], [[14, 17], 1], [[17, 20], 1], [[31, 34], 1]],
  'Jeu 0': [[[0, 3], 1], [[12, 15], 1], [[32, 35], 1], [[26], 1]],
};
const neighbours = (n) => { const i = WHEEL_ORDER.indexOf(n); return [-2, -1, 0, 1, 2].map((d) => WHEEL_ORDER[(i + d + 37) % 37]); };

/** A premium wheel: polished wood bowl, gold frets, deep pockets and a turned turret. Ball handled by WheelStage. */
function Wheel({ rotation, spinning, win }) {
  const cx = 200, cy = 200;
  const pt = (r, deg) => { const a = ((deg - 90) * Math.PI) / 180; return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; };
  return (
    <svg viewBox="0 0 400 400" className="h-full w-full">
      <defs>
        <radialGradient id="rl-wood" cx="50%" cy="45%" r="55%"><stop offset="70%" stopColor="#5b2a0c" /><stop offset="88%" stopColor="#8a4316" /><stop offset="96%" stopColor="#3a1704" /><stop offset="100%" stopColor="#1e0b02" /></radialGradient>
        <linearGradient id="rl-gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fff3c4" /><stop offset=".35" stopColor="#e2b04a" /><stop offset=".6" stopColor="#8a5a12" /><stop offset="1" stopColor="#f5d27a" /></linearGradient>
        <radialGradient id="rl-track" cx="50%" cy="50%" r="50%"><stop offset="80%" stopColor="#2a1408" /><stop offset="93%" stopColor="#6b3814" /><stop offset="100%" stopColor="#2a1408" /></radialGradient>
        <linearGradient id="rl-red" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#e11d2a" /><stop offset="1" stopColor="#7a0710" /></linearGradient>
        <linearGradient id="rl-black" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#3a3a3a" /><stop offset="1" stopColor="#050505" /></linearGradient>
        <linearGradient id="rl-green" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#22a052" /><stop offset="1" stopColor="#0b4a24" /></linearGradient>
        <radialGradient id="rl-cone" cx="45%" cy="40%" r="60%"><stop offset="0" stopColor="#b8692a" /><stop offset=".6" stopColor="#7a3b10" /><stop offset="1" stopColor="#3d1a05" /></radialGradient>
        <radialGradient id="rl-shine" cx="35%" cy="25%" r="70%"><stop offset="0" stopColor="rgba(255,255,255,.35)" /><stop offset=".5" stopColor="rgba(255,255,255,0)" /></radialGradient>
      </defs>
      {/* static bowl: rim and ball track */}
      <circle cx={cx} cy={cy} r="199" fill="url(#rl-wood)" />
      <circle cx={cx} cy={cy} r="186" fill="none" stroke="url(#rl-gold)" strokeWidth="5" />
      <circle cx={cx} cy={cy} r="183" fill="url(#rl-track)" />
      {Array.from({ length: 8 }, (_, i) => { const [x1, y1] = pt(160, i * 45 + 22.5); const [x2, y2] = pt(172, i * 45 + 22.5); return <path key={i} d={`M${x1} ${y1}L${x2} ${y2}`} stroke="url(#rl-gold)" strokeWidth="5" strokeLinecap="round" />; })}
      {/* the turning wheel */}
      <g style={{ transform: `rotate(${rotation}deg)`, transformOrigin: '200px 200px', transition: spinning ? `transform ${reduceMotion ? 0 : 5.2}s cubic-bezier(0.12, 0.7, 0.12, 1)` : 'none' }}>
        <circle cx={cx} cy={cy} r="152" fill="#1a0c03" stroke="url(#rl-gold)" strokeWidth="3" />
        {WHEEL_ORDER.map((n, i) => {
          const d0 = i * SEG - SEG / 2, d1 = i * SEG + SEG / 2;
          const [ax, ay] = pt(150, d0), [bx, by] = pt(150, d1), [cx2, cy2] = pt(104, d1), [dx, dy] = pt(104, d0);
          const [tx, ty] = pt(134, i * SEG);
          const [px0, py0] = pt(122, d0), [px1, py1] = pt(122, d1), [qx1, qy1] = pt(104, d1), [qx0, qy0] = pt(104, d0);
          const [fx0, fy0] = pt(150, d0), [fx1, fy1] = pt(104, d0);
          const hot = win === n && !spinning;
          return (
            <g key={n}>
              <path d={`M${ax} ${ay}A150 150 0 0 1 ${bx} ${by}L${cx2} ${cy2}A104 104 0 0 0 ${dx} ${dy}z`} fill={n === 0 ? 'url(#rl-green)' : RED.has(n) ? 'url(#rl-red)' : 'url(#rl-black)'} />
              <path d={`M${px0} ${py0}A122 122 0 0 1 ${px1} ${py1}L${qx1} ${qy1}A104 104 0 0 0 ${qx0} ${qy0}z`} fill="rgba(0,0,0,.35)" />
              {hot && <path d={`M${ax} ${ay}A150 150 0 0 1 ${bx} ${by}L${cx2} ${cy2}A104 104 0 0 0 ${dx} ${dy}z`} fill="rgba(255,236,170,.55)" className="rl-hot" />}
              <path d={`M${fx0} ${fy0}L${fx1} ${fy1}`} stroke="url(#rl-gold)" strokeWidth="1.6" />
              <text x={tx} y={ty} transform={`rotate(${i * SEG} ${tx} ${ty})`} textAnchor="middle" dominantBaseline="middle" fontSize="15" fontWeight="800" fill="#fff" fontFamily="'Barlow Condensed', system-ui" style={{ paintOrder: 'stroke', stroke: 'rgba(0,0,0,.5)', strokeWidth: 1.5 }}>{n}</text>
            </g>
          );
        })}
        <circle cx={cx} cy={cy} r="104" fill="none" stroke="url(#rl-gold)" strokeWidth="2.5" />
        <circle cx={cx} cy={cy} r="100" fill="url(#rl-cone)" />
        {Array.from({ length: 8 }, (_, i) => <path key={i} d={`M${pt(96, i * 45)[0]} ${pt(96, i * 45)[1]}L${pt(52, i * 45)[0]} ${pt(52, i * 45)[1]}`} stroke="rgba(0,0,0,.25)" strokeWidth="1" />)}
        <circle cx={cx} cy={cy} r="54" fill="none" stroke="url(#rl-gold)" strokeWidth="2" />
        {[0, 90, 180, 270].map((a) => { const [x, y] = pt(46, a); return <g key={a}><path d={`M${cx} ${cy}L${x} ${y}`} stroke="url(#rl-gold)" strokeWidth="7" strokeLinecap="round" /><circle cx={x} cy={y} r="7" fill="url(#rl-gold)" /></g>; })}
        <circle cx={cx} cy={cy} r="17" fill="url(#rl-gold)" stroke="#5b3a0a" strokeWidth="1" />
        <circle cx={cx} cy={cy - 4} r="7" fill="#fff6d6" opacity=".7" />
      </g>
      <circle cx={cx} cy={cy} r="199" fill="url(#rl-shine)" pointerEvents="none" />
    </svg>
  );
}

const SAYCOL = { red: 'RED', black: 'BLACK', green: 'GREEN' };
/** Full-screen spin: the big wheel, the ball racing round and dropping into its pocket, then the call. */
function WheelStage({ open, rotation, spinning, result, ballRun, onClose }) {
  const ballRef = useRef(null); const boxRef = useRef(null);
  useEffect(() => {
    if (!ballRun || !ballRef.current || !boxRef.current) return;
    const w = boxRef.current.offsetWidth; const R = (rr) => -(rr / 400) * w;
    const arm = ballRef.current, ball = arm.firstChild;
    const T = reduceMotion ? 50 : 5200;
    arm.animate([{ transform: `rotate(${1440 + 137}deg)` }, { transform: 'rotate(0deg)' }], { duration: T, easing: 'cubic-bezier(0.15, 0.6, 0.2, 1)', fill: 'forwards' });
    ball.animate([
      { transform: `translateY(${R(170)}px)`, offset: 0 }, { transform: `translateY(${R(170)}px)`, offset: 0.62 },
      { transform: `translateY(${R(140)}px)`, offset: 0.76 }, { transform: `translateY(${R(156)}px)`, offset: 0.82 },
      { transform: `translateY(${R(126)}px)`, offset: 0.9 }, { transform: `translateY(${R(131)}px)`, offset: 0.95 }, { transform: `translateY(${R(127)}px)`, offset: 1 },
    ], { duration: T, easing: 'ease-in-out', fill: 'forwards' });
  }, [ballRun]);
  if (!open) return null;
  return createPortal(
    <div className="rl-stage fixed inset-0 z-[70] flex flex-col items-center justify-center overflow-hidden" onClick={!spinning ? onClose : undefined} role="dialog" aria-label="Roulette wheel">
      <div className="rl-stage-bg absolute inset-0" />
      <div className="relative mb-[2vh] font-cond text-sm font-extrabold uppercase tracking-[.35em] text-amber-200/80">{spinning ? 'No more bets' : result ? '' : ''}</div>
      <div ref={boxRef} className="rl-bigwheel relative aspect-square w-[min(94vw,68vh,640px)]">
        <div className="absolute left-1/2 top-[-2.5%] z-10 -translate-x-1/2"><svg width="30" height="26" viewBox="0 0 18 16"><path d="M9 16L0 0h18z" fill="#fbbf24" stroke="#78350f" strokeWidth="1" /></svg></div>
        <Wheel rotation={rotation} spinning={spinning} win={result?.number} />
        <div ref={ballRef} className="pointer-events-none absolute left-1/2 top-1/2 h-0 w-0" style={{ transform: 'rotate(0deg)' }}>
          <div className="rl-ball" />
        </div>
      </div>
      <div className="relative mt-[2.5vh] flex min-h-[120px] flex-col items-center px-4 text-center">
        {result && !spinning && (
          <>
            <div className="rl-call flex items-center gap-3">
              <span className={`rl-callnum ${result.colour}`}>{result.number}</span>
              <span className={`font-cond text-4xl font-extrabold tracking-wider ${result.colour === 'red' ? 'text-red-400' : result.colour === 'green' ? 'text-emerald-400' : 'text-slate-100'}`}>{SAYCOL[result.colour]}</span>
            </div>
            <div className={`rl-callwin mt-2 font-cond text-2xl font-extrabold ${result.payout > result.staked ? 'text-gold-400' : 'text-slate-300'}`}>
              {result.payout > 0 ? (result.payout > result.staked ? `You win ${money(result.payout - result.staked)}` : `${money(result.payout)} back`) : 'No win this time'}
            </div>
            <div className="mt-2 text-xs text-white/50">Tap to return to the table</div>
          </>
        )}
      </div>
    </div>, document.body);
}

export default function Roulette() {
  const { view, history, busy, play, commit } = useGame('roulette');
  const [chip, setChip] = useState(100);
  const [lastAdd, setLastAdd] = useState(null);
  const [lastStraight, setLastStraight] = useState(null);
  const [boardEl, setBoardEl] = useState(null);
  const cellRefs = useRef({});
  const [geo, setGeo] = useState(null);
  const [bets, setBets] = useState([]); // [{nums, amount}] in placement order
  const [last, setLast] = useState(null);
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState(null);
  const rot = useRef(0);
  const [full] = usePopout();
  const [showWheel, setShowWheel] = useState(false);
  const [mode, setMode] = useState('straight');   // 'straight': tap a number = straight up · 'combo': splits, corners, streets
  const [track, setTrack] = useState(false);
  const [ballRun, setBallRun] = useState(0);
  const [hideNewest, setHideNewest] = useState(false); // don't reveal the number in the history before the ball lands
  const wheelTimer = useRef(0);
  useEffect(() => () => clearTimeout(wheelTimer.current), []);

  const merged = useMemo(() => {
    const m = new Map();
    for (const b of bets) { const k = key(b.nums); m.set(k, { nums: b.nums, amount: (m.get(k)?.amount || 0) + b.amount }); }
    return [...m.values()];
  }, [bets]);
  const total = merged.reduce((a, b) => a + b.amount, 0);
  const onKey = useMemo(() => Object.fromEntries(merged.map((b) => [key(b.nums), b.amount])), [merged]);
  const add = (nums, units = 1, quiet = false) => {
    if (spinning) return;
    setResult(null); if (!playSample(RFX('chip'), { gain: 0.5, rate: 0.95 + Math.random() * 0.1 })) sfx.chip();
    setBets((b) => [...b, { nums, amount: chip * units }]);
    if (!quiet) setLastAdd({ name: betName(nums), pays: PAYS[nums.length], amount: chip * units });
  };
  const addMany = (list, name) => { if (spinning) return; list.forEach(([nums, u]) => add(nums, u, true)); setLastAdd({ name, pays: 'several bets', amount: chip * list.reduce((a, x) => a + x[1], 0) }); };
  const removeBet = (k) => { if (spinning) return; setBets((b) => b.filter((x) => key(x.nums) !== k)); setLastAdd(null); };
  const tapNumber = (n) => { setLastStraight(n); add([n]); };

  // Measure the number cells so the split / corner / street spots sit exactly on the lines between them
  useLayoutEffect(() => {
    const el = boardEl;
    if (!el) return undefined;
    // offset* ignores CSS transforms, so this stays right inside the scaled full-screen frame
    const measure = () => {
      const g = {};
      for (let n = 0; n <= 36; n++) {
        const c = cellRefs.current[n];
        if (!c) return;
        g[n] = { l: c.offsetLeft, r: c.offsetLeft + c.offsetWidth, t: c.offsetTop, b: c.offsetTop + c.offsetHeight };
      }
      setGeo((old) => (JSON.stringify(old) === JSON.stringify(g) ? old : g));
    };
    measure();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
    ro?.observe(el);
    window.addEventListener('resize', measure);
    return () => { ro?.disconnect(); window.removeEventListener('resize', measure); };
  }, [boardEl, full]);
  const spots = useMemo(() => {
    if (!geo) return [];
    const out = [];
    const mx = (n) => (geo[n].l + geo[n].r) / 2, my = (n) => (geo[n].t + geo[n].b) / 2;
    for (let n = 1; n <= 36; n++) {
      const col = (n - 1) % 3;
      const below = (geo[n].b + (geo[n + 3]?.t ?? geo[n].b)) / 2;
      if (col < 2) out.push({ nums: [n, n + 1], x: (geo[n].r + geo[n + 1].l) / 2, y: my(n) });
      if (n <= 33) out.push({ nums: [n, n + 3], x: mx(n), y: below });
      if (col < 2 && n <= 32) out.push({ nums: [n, n + 1, n + 3, n + 4], x: (geo[n].r + geo[n + 1].l) / 2, y: below });
      if (col === 0) {
        out.push({ nums: [n, n + 1, n + 2], x: geo[n].l, y: my(n), edge: true });
        if (n <= 31) out.push({ nums: range(n, n + 5), x: geo[n].l, y: below, edge: true });
      }
    }
    const zy = (geo[0].b + geo[1].t) / 2;
    [1, 2, 3].forEach((c) => out.push({ nums: [0, c], x: mx(c), y: zy }));
    out.push({ nums: [0, 1, 2], x: (geo[1].r + geo[2].l) / 2, y: zy });
    out.push({ nums: [0, 2, 3], x: (geo[2].r + geo[3].l) / 2, y: zy });
    out.push({ nums: [0, 1, 2, 3], x: geo[1].l, y: zy, edge: true });
    return out;
  }, [geo]);

  const spin = async () => {
    if (!merged.length || spinning) return;
    setResult(null);
    setSpinning(true); setShowWheel(true); setLastAdd(null); clearTimeout(wheelTimer.current);
    clearVoiceQueue(); queueVoice(VO('nomore'));
    const out = await play('spin', { bets: merged });
    if (!out) { setSpinning(false); setShowWheel(false); return; }
    setHideNewest(true);
    const idx = WHEEL_ORDER.indexOf(out.number);
    const base = rot.current - (rot.current % 360);
    const next = base + 360 * 5 - idx * SEG;
    rot.current = next;
    setRotation(next); setBallRun((x) => x + 1);
    if (!playSample(RFX('spin'), { gain: 0.6 })) sfx.spin();
    setTimeout(() => {
      setSpinning(false); setHideNewest(false);
      setResult(out);
      queueVoice(VO(`n${out.number}`), { maxWait: 3 });
      if (out.payout > out.staked) queueVoice(VO(out.payout >= out.staked * 10 ? 'bigwin' : 'win'), { maxWait: 4 });
      wheelTimer.current = setTimeout(() => setShowWheel(false), 4200);
      setLast(merged);
      commit();
      if (out.payout >= out.staked * 10 && out.staked > 0) setTimeout(() => { setShowWheel(false); setBig({ amount: out.payout, bet: out.staked }); }, 2600);
      else if (out.payout > 0) { if (!playSample(RFX('win'), { gain: 0.5 })) sfx.win(); } else sfx.lose();
    }, reduceMotion ? 100 : 5300);
  };

  const histAll = view?.history || [];
  const hist = hideNewest ? histAll.slice(1) : histAll;
  const [big, setBig] = useState(null);
  const stats = useMemo(() => {
    const h = hist.slice(0, 100);
    const counts = new Map(range(0, 36).map((n) => [n, 0]));
    h.forEach((n) => counts.set(n, counts.get(n) + 1));
    const sorted = [...counts].sort((a, b) => b[1] - a[1] || a[0] - b[0]);
    const pct = (f) => (h.length ? Math.round((h.filter(f).length / h.length) * 100) : 0);
    return { n: h.length, hot: sorted.slice(0, 5), cold: sorted.slice(-5).reverse(), red: pct((n) => colourOf(n) === 'red'), black: pct((n) => colourOf(n) === 'black'), zero: pct((n) => n === 0) };
  }, [hist]);
  const win = result?.number;
  const outcomeText = (r) => (r.payout <= 0 ? 'No win' : r.payout > r.staked ? `Won ${money(r.payout - r.staked)}` : r.payout === r.staked ? 'Stake back' : `${money(r.payout)} back`);
  const statusText = spinning ? 'No more bets…'
    : result ? `${result.number} · ${result.payout > 0 ? `Paid ${money(result.payout)} · ${result.payout >= result.staked ? '+' : '−'}${money(Math.abs(result.payout - result.staked))}` : 'No win'}`
      : lastAdd ? `${lastAdd.name} · ${money(lastAdd.amount)} · pays ${lastAdd.pays}` : 'Place your bets';
  const numCls = (n) => `rl-cell ${n === 0 ? 'z' : RED.has(n) ? 'r' : 'b'} ${win === n && !spinning ? 'won' : ''}`;
  // a bet's chip sits in the middle of its cell
  const Stack = ({ amt }) => (amt ? <span className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center"><Chip value={amt} size={28} /></span> : null);
  useEffect(() => {
    const h = () => preloadUrls([VO('nomore'), RFX('spin'), RFX('chip'), RFX('chip2'), RFX('win'), ...range(0, 36).map((n) => VO(`n${n}`))]);
    window.addEventListener('pointerdown', h, { once: true });
    return () => window.removeEventListener('pointerdown', h);
  }, []);

  const board = (
    <div ref={setBoardEl} className="rl-felt relative grid select-none grid-cols-[.78fr_.78fr_1.3fr_1.3fr_1.3fr] gap-[3px] p-1.5 text-white">
      <div className="col-span-2 flex items-center justify-center">
        <div className="rl-mode" role="radiogroup" aria-label="Bet type">
          <button role="radio" aria-checked={mode === 'straight'} className={mode === 'straight' ? 'on' : ''} onClick={() => setMode('straight')}>Straight</button>
          <button role="radio" aria-checked={mode === 'combo'} className={mode === 'combo' ? 'on' : ''} onClick={() => setMode('combo')}>Splits · corners</button>
        </div>
      </div>
      <button ref={(e) => { cellRefs.current[0] = e; }} onClick={() => tapNumber(0)} disabled={spinning} className={`rl-num col-span-3 ${numCls(0)}`}>0<Stack amt={onKey['0']} /></button>
      {OUTSIDE.map((o, i) => (
        <button key={o.label} onClick={() => add(o.nums)} disabled={spinning} style={{ gridRow: `${2 + i * 2} / span 2`, gridColumn: 1 }} className={`rl-out relative ${o.label === 'RED' ? 'red' : o.label === 'BLACK' ? 'black' : ''}`}>
          <span className="[writing-mode:vertical-rl] rotate-180">{o.label === 'RED' || o.label === 'BLACK' ? <span className={`inline-block h-5 w-5 rotate-45 rounded-sm ${o.label === 'RED' ? 'bg-red-600' : 'bg-zinc-950 ring-1 ring-white/40'}`} /> : o.label}</span><Stack amt={onKey[key(o.nums)]} />
        </button>
      ))}
      {DOZENS.map((d, i) => (
        <button key={d.label} onClick={() => add(d.nums)} disabled={spinning} style={{ gridRow: `${2 + i * 4} / span 4`, gridColumn: 2 }} className="rl-out relative">
          <span className="[writing-mode:vertical-rl] rotate-180">{d.label}</span><Stack amt={onKey[key(d.nums)]} />
        </button>
      ))}
      {range(1, 36).map((n) => (
        <button key={n} ref={(e) => { cellRefs.current[n] = e; }} onClick={() => tapNumber(n)} disabled={spinning} aria-label={`Straight up on ${n}, pays 35 to 1`} style={{ gridRow: 2 + Math.floor((n - 1) / 3), gridColumn: 3 + ((n - 1) % 3) }} className={`rl-num ${numCls(n)}`}>
          <span className="relative z-[1]">{n}</span><Stack amt={onKey[String(n)]} />
          {win === n && !spinning && <span className="rl-dolly" aria-hidden="true" />}
        </button>
      ))}
      <div className="col-span-2" style={{ gridRow: 14 }} />
      {COLUMNS.map((c, i) => (
        <button key={i} onClick={() => add(c.nums)} disabled={spinning} style={{ gridRow: 14, gridColumn: 3 + i }} className="rl-num rl-out relative">2:1<Stack amt={onKey[key(c.nums)]} /></button>
      ))}
      {mode === 'combo' && spots.map((sp) => {
        const k = key(sp.nums), amt = onKey[k];
        return (
          <button key={k} type="button" aria-label={`${betName(sp.nums)}, pays ${PAYS[sp.nums.length]}`} title={`${betName(sp.nums)} · pays ${PAYS[sp.nums.length]}`}
            onClick={() => add(sp.nums)} disabled={spinning} style={{ left: sp.x, top: sp.y }}
            className="group absolute z-[15] flex h-[34px] w-[34px] -translate-x-1/2 -translate-y-1/2 items-center justify-center">
            {amt ? <Chip value={amt} size={24} /> : <span className={`pointer-events-none h-3.5 w-3.5 rounded-full ${sp.edge ? 'bg-sky-300' : 'bg-gold-400'} shadow-[0_0_0_2px_rgba(0,0,0,.6),0_0_8px_rgba(250,204,21,.6)] transition-transform group-active:scale-150`} />}
          </button>
        );
      })}
      {mode === 'straight' && spots.filter((sp) => onKey[key(sp.nums)]).map((sp) => (
        <span key={key(sp.nums)} style={{ left: sp.x, top: sp.y }} className="pointer-events-none absolute z-[15] -translate-x-1/2 -translate-y-1/2"><Chip value={onKey[key(sp.nums)]} size={22} /></span>
      ))}
    </div>
  );

  return (
    <GameShell title="Roulette" subtitle="European single zero · straight up pays 35:1" rtp="97.3%" history={history}
      rules={<>
        <p>One green zero and 36 numbers. A winning bet returns your stake plus the odds, so £1 on a corner (8:1) returns £9. Bets pay: straight (1 number) 35:1, split (2) 17:1, street (3) 11:1, corner (4) 8:1, six line (6) 5:1, dozen or column 2:1, red/black, odd/even, 1-18/19-36 1:1.</p>
        <p><b>Numbers</b> mode (the default): tap any number to bet on it straight up. Switch to <b>Splits</b> to show the dots on the lines: a dot between two numbers is a split, where four meet is a corner, and the blue dots on the left edge are streets (three numbers) and six lines. Every bet is listed under the board; tap one there to remove it. The <b>Racetrack</b> button opens the call bets: <b>Voisins</b> (the 17 numbers near zero, 9 chips), <b>Tiers</b> (the 12 opposite, 6 chips), <b>Orphelins</b> (the other 8, 5 chips), <b>Jeu 0</b> (4 chips) and <b>Neighbours</b> (a number and two either side on the wheel, 5 chips).</p>
        <p className="text-slate-500">The house edge is 2.7% on every bet. Hot and cold numbers only describe past spins; every spin is independent, so they don't predict anything.</p>
      </>}>
      <WheelStage open={showWheel} rotation={rotation} spinning={spinning} result={result} ballRun={ballRun} onClose={() => { clearTimeout(wheelTimer.current); setShowWheel(false); }} />
      {big && <WinCelebration game="roulette" amount={big.amount} bet={big.bet} onDone={() => setBig(null)} className="fixed inset-0 z-[75]" />}
      <div className={full ? 'mx-auto grid max-w-[560px] grid-cols-[minmax(0,1fr)] gap-1.5' : 'grid gap-3 lg:grid-cols-[minmax(0,.8fr)_minmax(0,1.2fr)]'}>
        {!full && (
          <section className="space-y-3">
            <div className="rl-mini relative overflow-hidden rounded-2xl p-4">
              <div className="mx-auto aspect-square w-full max-w-[320px]"><Wheel rotation={rotation} spinning={false} win={win} /></div>
              <div className="mt-2 text-center text-sm text-amber-100/80">{statusText}</div>
            </div>
            <div className="card p-3">
              <div className="mb-2 flex items-center justify-between"><span className="text-xs font-bold uppercase tracking-wider text-slate-400">Last results</span><span className="text-[11px] text-slate-500">{stats.n} spins</span></div>
              <div className="scrollbar-none flex gap-1 overflow-x-auto">
                {hist.slice(0, 18).map((n, i) => <span key={i} className={`flex h-7 min-w-7 items-center justify-center rounded text-xs font-bold text-white ${n === 0 ? 'bg-green-700' : RED.has(n) ? 'bg-red-700' : 'bg-zinc-900 ring-1 ring-white/15'}`}>{n}</span>)}
                {!hist.length && <span className="text-xs text-slate-500">No spins yet</span>}
              </div>
              {stats.n >= 10 && (
                <div className="mt-3 grid grid-cols-2 gap-3 text-xs">
                  <div><div className="mb-1 font-semibold text-red-300">Hot</div><div className="flex gap-1">{stats.hot.map(([n, c]) => <span key={n} className="rounded bg-navy-800 px-1.5 py-0.5 tabular-nums text-slate-200">{n}<sub className="text-slate-500">{c}</sub></span>)}</div></div>
                  <div><div className="mb-1 font-semibold text-sky-300">Cold</div><div className="flex gap-1">{stats.cold.map(([n, c]) => <span key={n} className="rounded bg-navy-800 px-1.5 py-0.5 tabular-nums text-slate-200">{n}<sub className="text-slate-500">{c}</sub></span>)}</div></div>
                  <div className="col-span-2 flex h-2 overflow-hidden rounded-full"><span className="bg-red-600" style={{ width: `${stats.red}%` }} /><span className="bg-green-600" style={{ width: `${stats.zero}%` }} /><span className="bg-zinc-700" style={{ width: `${stats.black}%` }} /></div>
                  <p className="col-span-2 text-[11px] text-slate-500">Red {stats.red}% · Zero {stats.zero}% · Black {stats.black}%. Past spins don't change the odds of the next one.</p>
                </div>
              )}
            </div>
          </section>
        )}

        <section className={full ? 'min-w-0 space-y-1.5' : 'space-y-3'}>
          <div className="flex h-8 items-center gap-1.5 px-0.5">
            <div className="flex gap-1">{hist.slice(0, full ? 5 : 8).map((n, i) => <span key={i} className={`flex h-6 min-w-6 items-center justify-center rounded-full text-[11px] font-bold text-white ${i === 0 ? 'ring-2 ring-gold-400' : ''} ${n === 0 ? 'bg-green-700' : RED.has(n) ? 'bg-red-700' : 'bg-zinc-900 ring-1 ring-white/15'}`}>{n}</span>)}</div>
            <div className={`ml-auto truncate text-sm font-bold ${result?.payout > result?.staked ? 'text-gold-400' : 'text-slate-200'}`}>{statusText}</div>
            <button onClick={() => setTrack((t) => !t)} className={`rl-trackbtn ${track ? 'on' : ''}`} aria-expanded={track}>Racetrack</button>
          </div>
          {track && (
            <div className="scrollbar-none flex w-0 min-w-full gap-1 overflow-x-auto">
              {Object.entries(CALL_BETS).map(([name, list]) => <button key={name} className="chip shrink-0 border-amber-400/40" onClick={() => addMany(list, name)}>{name} · {list.reduce((a, x) => a + x[1], 0)}</button>)}
              <button className="chip shrink-0 border-amber-400/40" disabled={(lastStraight ?? win) == null} onClick={() => { const n = lastStraight ?? win; addMany(neighbours(n).map((x) => [[x], 1]), `Neighbours of ${n}`); }}>Neighbours {lastStraight ?? win ?? ''}</button>
            </div>
          )}
          <div className="rl-table relative rounded-2xl p-1">
            {board}
          </div>
          {merged.length > 0 && !spinning && (
            <div className="scrollbar-none flex w-0 min-w-full gap-1 overflow-x-auto text-[11px]">
              {merged.map((b) => (
                <button key={key(b.nums)} onClick={() => removeBet(key(b.nums))} title="Remove this bet" className="flex shrink-0 items-center gap-1 rounded-full bg-navy-800 px-2 py-0.5 text-slate-300 hover:bg-navy-700">
                  <span className="whitespace-nowrap">{betName(b.nums)} · {money(b.amount)} · {PAYS[b.nums.length]}</span><span className="text-slate-500">✕</span>
                </button>
              ))}
            </div>
          )}

          <div className={`rl-controls ${full ? 'space-y-1.5 p-1.5' : 'space-y-3 p-3'}`}>
            <div className="flex items-center justify-between gap-1 px-0.5">
              {CHIPS.map((c) => (
                <button key={c} onClick={() => { setChip(c); playSample(RFX('chip2'), { gain: 0.4 }) || sfx.chip(); }} aria-pressed={chip === c} aria-label={`Chip ${chipLabel(c)}`}
                  className={`rl-chipbtn ${chip === c ? 'on' : ''}`}><Chip value={c} label={chipLabel(c)} size={44} /></button>
              ))}
            </div>
            <div className="grid grid-cols-[repeat(4,minmax(0,1fr))_2fr] gap-1.5">
              <button className="btn-ghost h-12 px-1" disabled={spinning || !bets.length} onClick={() => setBets((b) => b.slice(0, -1))}>Undo</button>
              <button className="btn-ghost h-12 px-1" disabled={spinning || !bets.length} onClick={() => { setBets([]); setLastAdd(null); }}>Clear</button>
              <button className="btn-ghost h-12 px-1" disabled={spinning || !last} onClick={() => setBets(last.map((b) => ({ ...b })))}>Rebet</button>
              <button className="btn-ghost h-12 px-1" disabled={spinning || !bets.length} onClick={() => setBets((b) => [...b, ...b.map((x) => ({ ...x }))])}>×2</button>
              <button className="rl-spin h-12 px-2 text-base" disabled={busy || spinning || !merged.length} onClick={spin}>{spinning ? 'Spinning…' : merged.length ? `Spin ${money(total)}` : 'Bet to spin'}</button>
            </div>
          </div>
        </section>
      </div>
    </GameShell>
  );
}
