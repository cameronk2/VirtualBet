// Shared bits for the racing pages: odds formatting (fractional / decimal, the player's choice),
// silks, countdowns, status badges, and the racing look (deep green, navy, gold).
import { useEffect, useState } from 'react';
import { Link } from '../../lib/router.jsx';

const KEY = 'rc_odds';
export function useOddsFormat() {
  const [fmt, setFmt] = useState(() => { try { return localStorage.getItem(KEY) || 'frac'; } catch { return 'frac'; } });
  const set = (v) => { setFmt(v); try { localStorage.setItem(KEY, v); } catch { /* private mode */ } window.dispatchEvent(new CustomEvent('rc-odds', { detail: v })); };
  useEffect(() => { const h = (e) => setFmt(e.detail); window.addEventListener('rc-odds', h); return () => window.removeEventListener('rc-odds', h); }, []);
  return [fmt, set];
}
/** Odds as the player prefers them. `o` is { num, den, dec } or a plain decimal. */
export function oddsText(o, fmt) {
  if (o == null) return '–';
  if (typeof o === 'number') { if (fmt === 'dec') return o.toFixed(2); const x = o - 1; return x >= 10 ? `${Math.round(x)}/1` : `${o.toFixed(2)}`; }
  if (fmt === 'dec') return o.dec.toFixed(2);
  return o.num === o.den ? 'Evs' : `${o.num}/${o.den}`;
}
export function OddsToggle({ className = '' }) {
  const [fmt, set] = useOddsFormat();
  return (
    <div className={`inline-flex rounded-full bg-black/30 p-0.5 text-[11px] font-bold ring-1 ring-rc-gold/30 ${className}`} role="radiogroup" aria-label="Odds format">
      {[['frac', '5/2'], ['dec', '3.50']].map(([k, l]) => <button key={k} type="button" role="radio" aria-checked={fmt === k} onClick={() => set(k)} className={`rounded-full px-2.5 py-1 ${fmt === k ? 'bg-rc-gold text-rc-ink' : 'text-rc-cream/70'}`}>{l}</button>)}
    </div>
  );
}

export const offTime = (ms) => (ms ? new Date(ms).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : 'On demand');
export const pounds = (p) => `£${Math.round(p).toLocaleString('en-GB')}`;

/** Live countdown to a time (server-corrected with `skew`, ms). */
export function useCountdown(to, skew = 0) {
  const [now, setNow] = useState(() => Date.now() + skew);
  useEffect(() => { const id = setInterval(() => setNow(Date.now() + skew), 250); return () => clearInterval(id); }, [skew]);
  if (!to) return null;
  return Math.max(0, to - now);
}
export function Countdown({ to, skew = 0, className = '' }) {
  const ms = useCountdown(to, skew);
  if (ms == null) return null;
  const s = Math.ceil(ms / 1000);
  return <span className={`tabular-nums ${className}`}>{s >= 3600 ? `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m` : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`}</span>;
}

export function PhaseBadge({ phase, kind }) {
  const m = {
    open: ['Betting open', 'bg-emerald-500/15 text-emerald-300 ring-emerald-400/40'],
    closing: ['Going down', 'bg-amber-500/15 text-amber-300 ring-amber-400/40'],
    ready: ['Ready to run', 'bg-sky-500/15 text-sky-200 ring-sky-400/40'],
    live: ['Live', 'bg-red-600 text-white ring-red-400/60'],
    result: ['Result', 'bg-white/10 text-rc-cream/80 ring-white/20'],
  }[phase] || ['', ''];
  return (
    <span className="inline-flex items-center gap-1">
      <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider ring-1 ${m[1]}`}>
        {phase === 'live' && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />}{m[0]}
      </span>
      <span className="rounded bg-rc-gold/15 px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-rc-gold ring-1 ring-rc-gold/30">{kind === 'quick' ? 'Your virtual race' : 'Virtual'}</span>
    </span>
  );
}

/** Racing silks: a jersey with its pattern and the cap. */
export function Silks({ silks, size = 32, className = '' }) {
  if (!silks) return null;
  const { c1, c2, cap, pattern } = silks;
  const id = `s${c1}${c2}${pattern}`.replace(/[^a-z0-9]/gi, '');
  const pat = {
    hoops: <><rect y="22" width="64" height="7" fill={c2} /><rect y="35" width="64" height="7" fill={c2} /><rect y="48" width="64" height="7" fill={c2} /></>,
    stripes: <>{[14, 26, 38, 50].map((x) => <rect key={x} x={x} y="14" width="5" height="50" fill={c2} />)}</>,
    sash: <path d="M14 18L22 14L52 60L44 64Z" fill={c2} />,
    chevrons: <path d="M10 30L32 44L54 30L54 38L32 52L10 38Z" fill={c2} />,
    quartered: <><rect x="10" y="14" width="22" height="22" fill={c2} /><rect x="32" y="36" width="22" height="28" fill={c2} /></>,
    halved: <rect x="10" y="14" width="22" height="50" fill={c2} />,
    star: <path d="M32 26l3 8h8l-6.5 5 2.5 8-7-5-7 5 2.5-8-6.5-5h8z" fill={c2} />,
    braces: <><rect x="20" y="14" width="5" height="50" fill={c2} /><rect x="39" y="14" width="5" height="50" fill={c2} /></>,
    diamond: <path d="M32 24L42 39L32 54L22 39Z" fill={c2} />,
    spots: <>{[[22, 28], [42, 28], [32, 40], [22, 52], [42, 52]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="4" fill={c2} />)}</>,
    cross: <><rect x="29" y="14" width="6" height="50" fill={c2} /><rect x="10" y="34" width="44" height="6" fill={c2} /></>,
    plain: null,
  }[pattern];
  return (
    <svg viewBox="0 0 64 64" width={size} height={size} className={className} aria-hidden="true">
      <defs><clipPath id={id}><path d="M10 18L22 12Q32 16 42 12L54 18L62 30L54 34L54 64L10 64L10 34L2 30Z" /></clipPath></defs>
      <path d="M10 18L22 12Q32 16 42 12L54 18L62 30L54 34L54 64L10 64L10 34L2 30Z" fill={c1} stroke="rgba(0,0,0,.35)" strokeWidth="1.5" />
      <g clipPath={`url(#${id})`}>{pat}</g>
      <path d="M22 12Q32 2 42 12Q32 9 22 12Z" fill={cap} stroke="rgba(0,0,0,.35)" strokeWidth="1" />
    </svg>
  );
}

export function FormFigures({ form }) {
  if (!form) return <span className="text-rc-cream/40">–</span>;
  return <span className="font-mono tracking-wider">{form.split('').reverse().join('').slice(-6).split('').map((c, i) => <span key={i} className={c === '1' ? 'font-bold text-rc-gold' : c === '0' ? 'text-rc-cream/40' : ''}>{c}</span>)}</span>;
}

export function Stat({ label, value, sub, tone }) {
  return (
    <div className="rounded-xl border border-white/10 bg-rc-panel p-3">
      <div className="text-[10px] font-bold uppercase tracking-[.16em] text-rc-cream/50">{label}</div>
      <div className={`mt-0.5 font-cond text-xl font-bold tabular-nums ${tone === 'pos' ? 'text-emerald-400' : tone === 'neg' ? 'text-red-400' : 'text-white'}`}>{value}</div>
      {sub && <div className="text-[11px] text-rc-cream/50">{sub}</div>}
    </div>
  );
}

export function RaceRow({ r, skew, to = `/racing/race/${r.id}` }) {
  return (
    <Link to={to} className="group flex min-w-0 items-center gap-3 rounded-xl border border-white/[0.07] bg-rc-panel px-3 py-2.5 transition-colors hover:border-rc-gold/40 active:bg-white/5">
      <div className="w-14 shrink-0 text-center leading-tight">
        <div className="font-cond text-lg font-bold tabular-nums text-white">{offTime(r.off)}</div>
        <div className="text-[10px] font-semibold uppercase tracking-wider text-rc-cream/50">{r.courseName.split(' ')[0]}</div>
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5"><PhaseBadge phase={r.phase} kind={r.kind} /></div>
        <div className="mt-0.5 truncate font-semibold text-rc-cream">{r.name}</div>
        <div className="text-[11px] text-rc-cream/55">{r.distanceLabel} · {r.goingName} · {r.field} runners · {r.type}</div>
        {r.winner && r.phase === 'result' && <div className="mt-0.5 text-[11px] font-semibold text-rc-gold">Won by {r.winner}</div>}
        {r.top && r.phase !== 'result' && <div className="mt-1 flex flex-wrap gap-x-2 text-[11px] text-rc-cream/60">{r.top.map((t) => <span key={t.no} className="inline-flex items-center gap-0.5"><Silks silks={t.silks} size={14} />{t.name} <b className="text-rc-cream">{t.odds}</b></span>)}</div>}
      </div>
      <div className="shrink-0 text-right">
        {r.phase === 'open' && <Countdown to={r.off} skew={skew} className="font-cond text-base font-bold text-emerald-300" />}
        <svg viewBox="0 0 20 20" className="ml-auto mt-1 h-4 w-4 text-rc-gold/60 group-hover:text-rc-gold" fill="currentColor"><path d="M7.3 4.3a1 1 0 011.4 0l5 5a1 1 0 010 1.4l-5 5a1 1 0 01-1.4-1.4L11.6 10 7.3 5.7a1 1 0 010-1.4z" /></svg>
      </div>
    </Link>
  );
}
