// Racing sound settings: master, mute and separate volumes for commentary, horses, crowd and
// interface sounds, plus the crowd ambience switch. Saved on this device.
import { useEffect, useState } from 'react';
import { getSettings, onSettings, setSettings, unlock } from './audio.js';

export default function SoundPanel({ onClose }) {
  const [s, setS] = useState(getSettings());
  useEffect(() => onSettings(setS), []);
  const row = (k, label) => (
    <label className="flex items-center gap-2 text-xs text-rc-cream/80">
      <span className="w-24 shrink-0">{label}</span>
      <input type="range" min="0" max="1" step="0.05" value={s[k]} onChange={(e) => { unlock(); setSettings({ [k]: Number(e.target.value) }); }} className="rc-range flex-1" aria-label={`${label} volume`} />
    </label>
  );
  return (
    <div className="rounded-xl border border-rc-gold/30 bg-rc-ink/95 p-3 shadow-2xl backdrop-blur" role="dialog" aria-label="Sound settings">
      <div className="mb-2 flex items-center justify-between">
        <div className="text-[11px] font-extrabold uppercase tracking-[.2em] text-rc-gold">Sound</div>
        {onClose && <button type="button" onClick={onClose} className="text-rc-cream/60" aria-label="Close"><svg viewBox="0 0 20 20" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l10 10M15 5L5 15" /></svg></button>}
      </div>
      <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-white"><input type="checkbox" className="h-4 w-4 accent-amber-400" checked={s.muted} onChange={(e) => setSettings({ muted: e.target.checked })} />Mute all</label>
      <div className="space-y-1.5">
        {row('master', 'Master')}{row('commentary', 'Commentary')}{row('horses', 'Horses')}{row('crowd', 'Crowd')}{row('ui', 'Interface')}
      </div>
      <label className="mt-2 flex items-center gap-2 text-xs text-rc-cream/80"><input type="checkbox" className="h-4 w-4 accent-amber-400" checked={s.ambience} onChange={(e) => setSettings({ ambience: e.target.checked })} />Background crowd ambience</label>
    </div>
  );
}
