// The 3D race viewer (Three.js, vendored r170). It plays the server's recorded run of a race (the
// "trace": every horse's distance every 0.5 s), so the pictures always show the real result.
//
// Horses: Quaternius "Horse" (CC0) with its Gallop / Walk / Idle animations, recoloured per coat.
// Everything else (jockeys and silks, rails, stalls, stands, crowds, the courses) is built here.
import * as THREE from '../../../vendor/three/three.module.js';
import { GLTFLoader } from '../../../vendor/three/GLTFLoader.js';
import { clone as cloneSkinned } from '../../../vendor/three/SkeletonUtils.js';
import { COURSES } from '../../../../server/racing/data.js';

const MODELS = typeof __MODELS__ !== 'undefined' ? __MODELS__ : '/models/';
const COURSE = Object.fromEntries(COURSES.map((c) => [c.id, c]));
const W = 24;              // track width (m)
const GALLOP_STRIDE = 7.2; // metres covered per gallop cycle
const COATS = {
  bay: ['#5a2e14', '#3a1d0c', '#7a4220', '#141110', '#2b1a10'], dbay: ['#3a1e10', '#24120a', '#4f2a16', '#0e0b0a', '#1d120b'],
  chestnut: ['#8a4019', '#5f2b10', '#a8541f', '#7a3412', '#4a2410'], grey: ['#b8b6ae', '#8d8b84', '#d6d4cc', '#e8e6e0', '#6b6862'],
  black: ['#1c1a19', '#121110', '#2a2725', '#0a0909', '#151312'], roan: ['#7a5a4a', '#5a4034', '#9a7a6a', '#2a2220', '#3a2a22'],
};

let horseAsset = null;
function loadHorse() {
  if (!horseAsset) horseAsset = new GLTFLoader().loadAsync(`${MODELS}horse.glb`);
  return horseAsset;
}

// ── track geometry: an oval (two straights and two bends); s = distance along the inner rail ──
export function makeTrack(course) {
  const size = COURSE[course]?.scene?.size || 1;
  const r = 150 * size, C = 2000 * size;
  const S = (C - 2 * Math.PI * r) / 2;
  const hand = COURSE[course]?.hand === 'right' ? -1 : 1;
  const finish = S * 0.86;
  const point = (s) => {
    s = ((s % C) + C) % C;
    let x, z, hx, hz;
    if (s < S) { x = -S / 2 + s; z = r; hx = 1; hz = 0; }
    else if (s < S + Math.PI * r) { const a = (s - S) / r; x = S / 2 + r * Math.sin(a); z = r * Math.cos(a); hx = Math.cos(a); hz = -Math.sin(a); }
    else if (s < 2 * S + Math.PI * r) { x = S / 2 - (s - S - Math.PI * r); z = -r; hx = -1; hz = 0; }
    else { const a = (s - 2 * S - Math.PI * r) / r; x = -S / 2 - r * Math.sin(a); z = -r * Math.cos(a); hx = -Math.cos(a); hz = Math.sin(a); }
    // outward normal (away from the infield)
    const nx = s < S ? 0 : s < S + Math.PI * r ? Math.sin((s - S) / r) : s < 2 * S + Math.PI * r ? 0 : -Math.sin((s - 2 * S - Math.PI * r) / r);
    const nz = s < S ? 1 : s < S + Math.PI * r ? Math.cos((s - S) / r) : s < 2 * S + Math.PI * r ? -1 : -Math.cos((s - 2 * S - Math.PI * r) / r);
    return { x, z: z * hand, hx, hz: hz * hand, nx, nz: nz * hand };
  };
  const at = (s, d) => { const p = point(s); return new THREE.Vector3(p.x + p.nx * (d + 1.5), 0, p.z + p.nz * (d + 1.5)); };
  return { C, S, r, size, hand, finish, point, at };
}

// ── textures drawn in code ──
function canvasTex(w, h, draw, repeat) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  t.anisotropy = 4;
  return t;
}
function grassTex(c1, c2, stripes = true) {
  return canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = c1; g.fillRect(0, 0, w, h);
    if (stripes) { g.fillStyle = c2; g.fillRect(0, 0, w / 2, h); }
    for (let i = 0; i < 3500; i++) { g.fillStyle = `rgba(${Math.random() < 0.5 ? '255,255,220' : '0,30,0'},${Math.random() * 0.07})`; g.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 3); }
  });
}
function silkTex(silks, number) {
  const { c1, c2, pattern } = silks;
  return canvasTex(128, 128, (g, w, h) => {
    g.fillStyle = c1; g.fillRect(0, 0, w, h); g.fillStyle = c2;
    if (pattern === 'hoops') for (let y = 8; y < h; y += 32) g.fillRect(0, y, w, 14);
    else if (pattern === 'stripes') for (let x = 6; x < w; x += 28) g.fillRect(x, 0, 12, h);
    else if (pattern === 'sash') { g.beginPath(); g.moveTo(0, 20); g.lineTo(20, 0); g.lineTo(w, h - 20); g.lineTo(w - 20, h); g.closePath(); g.fill(); }
    else if (pattern === 'chevrons') for (let y = -20; y < h; y += 36) { g.beginPath(); g.moveTo(0, y); g.lineTo(w / 2, y + 26); g.lineTo(w, y); g.lineTo(w, y + 14); g.lineTo(w / 2, y + 40); g.lineTo(0, y + 14); g.fill(); }
    else if (pattern === 'quartered' || pattern === 'halved') { g.fillRect(0, 0, w / 2, h / 2); if (pattern === 'quartered') g.fillRect(w / 2, h / 2, w / 2, h / 2); else g.fillRect(0, h / 2, w / 2, h / 2); }
    else if (pattern === 'star') { g.beginPath(); for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2 - Math.PI / 2, rr = i % 2 ? 14 : 34; g.lineTo(w / 2 + Math.cos(a) * rr, h / 2 + Math.sin(a) * rr); } g.fill(); }
    else if (pattern === 'braces') { g.fillRect(28, 0, 12, h); g.fillRect(w - 40, 0, 12, h); }
    else if (pattern === 'diamond') { g.beginPath(); g.moveTo(w / 2, 14); g.lineTo(w - 24, h / 2); g.lineTo(w / 2, h - 14); g.lineTo(24, h / 2); g.fill(); }
    else if (pattern === 'spots') for (let i = 0; i < 9; i++) { g.beginPath(); g.arc(20 + (i % 3) * 44, 20 + Math.floor(i / 3) * 44, 9, 0, Math.PI * 2); g.fill(); }
    else if (pattern === 'cross') { g.fillRect(w / 2 - 9, 0, 18, h); g.fillRect(0, h / 2 - 9, w, 18); }
    if (number != null) { g.fillStyle = '#fff'; g.beginPath(); g.arc(w / 2, h / 2, 24, 0, 7); g.fill(); g.fillStyle = '#111'; g.font = 'bold 30px Barlow, Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(number), w / 2, h / 2 + 1); }
  });
}
function clothTex(no, colour) {
  return canvasTex(128, 64, (g, w, h) => {
    g.fillStyle = colour; g.fillRect(0, 0, w, h); g.fillStyle = 'rgba(255,255,255,.85)'; g.fillRect(4, 4, w - 8, h - 8);
    g.fillStyle = '#111'; g.font = 'bold 44px Barlow, Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(no), w / 2, h / 2 + 2);
  });
}
const CLOTH = ['#c8102e', '#ffffff', '#0b3d91', '#ffd100', '#00843d', '#111111', '#f28c28', '#e4007c', '#00a3e0', '#7d3c98', '#8b5a2b', '#5c7f2f', '#b5121b', '#1e2a78', '#f5e1a4', '#00635a'];

// ── a jockey: a crouched rider in silks, built from simple solids ──
function makeJockey(silks, no) {
  const g = new THREE.Group();
  const silk = new THREE.MeshStandardMaterial({ map: silkTex(silks, null), roughness: 0.55 });
  const capM = new THREE.MeshStandardMaterial({ color: silks.cap, roughness: 0.4 });
  const white = new THREE.MeshStandardMaterial({ color: '#f1efe8', roughness: 0.8 });
  const boot = new THREE.MeshStandardMaterial({ color: '#141210', roughness: 0.5 });
  const skin = new THREE.MeshStandardMaterial({ color: '#d9a483', roughness: 0.7 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 0.42, 4, 10), silk);
  torso.rotation.z = Math.PI / 2 - 0.25; torso.position.set(0.02, 0.38, 0); g.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 14, 10), skin); head.position.set(0.42, 0.55, 0); g.add(head);
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.165, 14, 10, 0, Math.PI * 2, 0, Math.PI / 1.9), capM); cap.position.copy(head.position).add(new THREE.Vector3(-0.01, 0.03, 0)); g.add(cap);
  const peak = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.02, 0.16), capM); peak.position.set(0.58, 0.58, 0); g.add(peak);
  for (const side of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.34, 3, 8), silk); arm.rotation.z = 1.2; arm.position.set(0.42, 0.3, side * 0.2); g.add(arm);
    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.3, 3, 8), white); thigh.rotation.z = -0.6; thigh.position.set(-0.08, 0.14, side * 0.24); g.add(thigh);
    const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.28, 3, 8), boot); shin.rotation.z = 0.7; shin.position.set(-0.02, -0.12, side * 0.27); g.add(shin);
  }
  g.userData.arm = g.children.find((m) => m.geometry.type === 'CapsuleGeometry' && m.position.y === 0.3);
  g.traverse((m) => { if (m.isMesh) m.castShadow = true; });
  return g;
}

// ── the whole venue ──
function buildVenue(scene, track, course, quality) {
  const cs = COURSE[course]?.scene || COURSES[0].scene;
  const night = cs.time === 'night';
  // sky dome
  const sky = new THREE.Mesh(new THREE.SphereGeometry(4000, 32, 16), new THREE.MeshBasicMaterial({ side: THREE.BackSide, depthWrite: false, map: canvasTex(8, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, cs.sky[0]); gr.addColorStop(0.42, cs.sky[0]); gr.addColorStop(0.5, cs.sky[1]); gr.addColorStop(1, cs.sky[1]); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  }) }));
  scene.add(sky);
  if (night) { const st = new THREE.BufferGeometry(); const pts = []; for (let i = 0; i < 700; i++) { const a = Math.random() * Math.PI * 2, e = 0.15 + Math.random() * 1.2; pts.push(Math.cos(a) * Math.cos(e) * 3500, Math.sin(e) * 3500, Math.sin(a) * Math.cos(e) * 3500); } st.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3)); scene.add(new THREE.Points(st, new THREE.PointsMaterial({ color: '#fff', size: 6, sizeAttenuation: true }))); }
  scene.fog = new THREE.Fog(cs.sky[1], 600, 2600);
  // light
  scene.add(new THREE.HemisphereLight(night ? '#8fa0c8' : '#dfefff', night ? '#20301f' : '#3d5a2e', night ? 1.2 : 0.85));
  const sun = new THREE.DirectionalLight(night ? '#e8f0ff' : '#fff6e2', night ? 1.6 : cs.time === 'overcast' ? 1.4 : 2.6);
  sun.position.set(-200, 320, 260);
  if (quality.shadows) { sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048); const sc = sun.shadow.camera; sc.left = -60; sc.right = 60; sc.top = 60; sc.bottom = -60; sc.near = 10; sc.far = 900; sun.shadow.bias = -0.0005; }
  scene.add(sun, sun.target);
  // ground: infield and surroundings
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(6000, 6000), new THREE.MeshLambertMaterial({ map: grassTex(cs.grass2, cs.grass, false), color: '#ffffff' }));
  ground.material.map.repeat.set(400, 400); ground.material.map.wrapS = ground.material.map.wrapT = THREE.RepeatWrapping;
  ground.rotation.x = -Math.PI / 2; ground.position.y = -0.05; ground.receiveShadow = true; scene.add(ground);
  // the racing strip, as a ribbon along the oval with mowing stripes across it
  const N = 400, pos = [], uv = [], idx = [];
  for (let i = 0; i <= N; i++) {
    const s = (i / N) * track.C;
    const a = track.at(s, -1.5), b = track.at(s, W + 0.5);
    pos.push(a.x, 0, a.z, b.x, 0, b.z); uv.push(s / 12, 0, s / 12, 1);
    if (i < N) { const k = i * 2; idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
  }
  const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); tg.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); tg.setIndex(idx); tg.computeVertexNormals();
  const turf = new THREE.Mesh(tg, new THREE.MeshLambertMaterial({ map: grassTex(cs.grass, cs.grass2, true), side: THREE.DoubleSide }));
  turf.material.map.wrapS = THREE.RepeatWrapping; turf.receiveShadow = true; turf.position.y = 0.01; scene.add(turf);
  // rails: white posts and a running rail on both sides
  const railMat = new THREE.MeshLambertMaterial({ color: '#f7f7f2' });
  for (const d of [-1.2, W + 0.3]) {
    const pts = []; for (let i = 0; i <= 200; i++) pts.push(track.at((i / 200) * track.C, d).setY(1.05));
    scene.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, true), 600, 0.06, 6, true), railMat));
    const n = Math.floor(track.C / (quality.high ? 3 : 6));
    const posts = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.05, 0.05, 1.05, 6), railMat, n);
    const m = new THREE.Matrix4();
    for (let i = 0; i < n; i++) { const p = track.at((i / n) * track.C, d); m.makeTranslation(p.x, 0.52, p.z); posts.setMatrixAt(i, m); }
    scene.add(posts);
  }
  // furlong poles on the inner rail, counted back from the finish
  const poleMat = new THREE.MeshLambertMaterial({ color: '#d42a2a' });
  for (let f = 1; f <= 20; f++) {
    const p = track.at(track.finish - f * 201.168, -1.6);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 2.6, 8), f % 2 ? poleMat : railMat); pole.position.set(p.x, 1.3, p.z); scene.add(pole);
  }
  // the winning post and line
  const fin = track.point(track.finish);
  const fp = track.at(track.finish, -2.2);
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 4, 10), railMat); post.position.set(fp.x, 2, fp.z); scene.add(post);
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.08, 24), new THREE.MeshLambertMaterial({ map: canvasTex(64, 64, (g) => { g.fillStyle = '#fff'; g.fillRect(0, 0, 64, 64); g.fillStyle = '#d0102a'; g.beginPath(); g.arc(32, 32, 22, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(32, 32, 10, 0, 7); g.fill(); }) }));
  disc.rotation.x = Math.PI / 2; disc.rotation.z = Math.atan2(fin.hz, fin.hx); disc.position.set(fp.x, 4.2, fp.z); scene.add(disc);
  const lineA = track.at(track.finish, -1), lineB = track.at(track.finish, W);
  const line = new THREE.Mesh(new THREE.PlaneGeometry(lineA.distanceTo(lineB), 0.25), new THREE.MeshBasicMaterial({ color: '#ffffff' }));
  line.rotation.x = -Math.PI / 2; line.rotation.z = -Math.atan2(lineB.z - lineA.z, lineB.x - lineA.x); line.position.set((lineA.x + lineB.x) / 2, 0.03, (lineA.z + lineB.z) / 2); scene.add(line);
  // grandstand along the home straight, outside the rail, with a crowd
  const standLen = 260, standX0 = fin.x - 170, outZ = track.hand * (track.r + W + 14);
  const standMat = new THREE.MeshLambertMaterial({ color: cs.stand });
  const roofMat = new THREE.MeshLambertMaterial({ color: cs.roof });
  const glass = new THREE.MeshLambertMaterial({ color: night ? '#ffe9a8' : '#9cc3d8', emissive: night ? '#6b5520' : '#000000' });
  const tiers = 7, dir = track.hand;
  for (let t = 0; t < tiers; t++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(standLen, 1.2, 2.4), standMat);
    step.position.set(standX0 + standLen / 2, 0.6 + t * 1.2, outZ + dir * (4 + t * 2.4)); step.receiveShadow = true; scene.add(step);
  }
  const back = new THREE.Mesh(new THREE.BoxGeometry(standLen, 22, 6), standMat); back.position.set(standX0 + standLen / 2, 11, outZ + dir * 24); scene.add(back);
  const win = new THREE.Mesh(new THREE.BoxGeometry(standLen - 10, 4, 0.2), glass); win.position.set(standX0 + standLen / 2, 15, outZ + dir * 20.9); scene.add(win);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(standLen + 8, 0.8, 22), roofMat); roof.position.set(standX0 + standLen / 2, 22.5, outZ + dir * 14); roof.rotation.x = dir * 0.08; roof.castShadow = true; scene.add(roof);
  for (let i = 0; i <= 8; i++) { const col = new THREE.Mesh(new THREE.BoxGeometry(0.6, 22, 0.6), roofMat); col.position.set(standX0 + (i / 8) * standLen, 11, outZ + dir * 3.2); scene.add(col); }
  // the crowd: instanced figures on the steps and along the rail
  const crowdN = quality.high ? 2600 : 1100;
  const body = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.22, 0.6, 2, 6), new THREE.MeshLambertMaterial({ color: '#ffffff' }), crowdN);
  const headM = new THREE.InstancedMesh(new THREE.SphereGeometry(0.15, 6, 5), new THREE.MeshLambertMaterial({ color: '#ffffff' }), crowdN);
  const palette = ['#1f3a5f', '#8c1c13', '#2e5e3a', '#e8e1d0', '#2a2a2a', '#5d4b8a', '#c79b3b', '#7a8b99', '#b5524a', '#f2f2f2', '#3b6ea5', '#6b4226'];
  const skins = ['#f1c7a5', '#d9a483', '#a8714f', '#7a4b31', '#e8b896'];
  const mm = new THREE.Matrix4(), col = new THREE.Color();
  const crowdBase = [];
  for (let i = 0; i < crowdN; i++) {
    const onStand = i < crowdN * 0.7;
    const t = Math.floor(Math.random() * tiers);
    const x = onStand ? standX0 + 4 + Math.random() * (standLen - 8) : standX0 - 120 + Math.random() * (standLen + 200);
    const y = onStand ? 1.2 + t * 1.2 + 0.55 : 0.55;
    const z = onStand ? outZ + dir * (4 + t * 2.4 + (Math.random() - 0.5) * 1.4) : outZ + dir * (-4 - Math.random() * 3.5);
    crowdBase.push([x, y, z]);
    mm.makeTranslation(x, y, z); body.setMatrixAt(i, mm); body.setColorAt(i, col.set(palette[i % palette.length]));
    mm.makeTranslation(x, y + 0.6, z); headM.setMatrixAt(i, mm); headM.setColorAt(i, col.set(skins[i % skins.length]));
  }
  scene.add(body, headM);
  // trees and hills beyond the course
  const treeN = quality.high ? 420 : 200;
  const trees = new THREE.InstancedMesh(new THREE.ConeGeometry(4, 12, 7), new THREE.MeshLambertMaterial({ color: night ? '#16241a' : '#2f5a2c' }), treeN);
  for (let i = 0; i < treeN; i++) {
    const a = Math.random() * Math.PI * 2, rr = track.S / 2 + track.r + 120 + Math.random() * 500;
    const sc = 0.7 + Math.random() * 1.2;
    mm.compose(new THREE.Vector3(Math.cos(a) * rr * 1.25, 6 * sc, Math.sin(a) * rr), new THREE.Quaternion(), new THREE.Vector3(sc, sc, sc)); trees.setMatrixAt(i, mm);
  }
  scene.add(trees);
  const hillMat = new THREE.MeshLambertMaterial({ color: cs.hills, flatShading: true });
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2 + Math.random() * 0.2, rr = 1500 + Math.random() * 500;
    const h = new THREE.Mesh(new THREE.SphereGeometry(300 + Math.random() * 250, 10, 6), hillMat);
    h.scale.y = 0.25 + Math.random() * 0.25; h.position.set(Math.cos(a) * rr, -40, Math.sin(a) * rr); scene.add(h);
  }
  const farMat = new THREE.MeshLambertMaterial({ color: cs.far, flatShading: true, fog: true });
  for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2, rr = 2600; const h = new THREE.Mesh(new THREE.SphereGeometry(600, 8, 5), farMat); h.scale.y = 0.35; h.position.set(Math.cos(a) * rr, -60, Math.sin(a) * rr); scene.add(h); }
  // course features
  if (cs.water) { const w = new THREE.Mesh(new THREE.PlaneGeometry(1600, 90), new THREE.MeshLambertMaterial({ color: '#4f7f98' })); w.rotation.x = -Math.PI / 2; w.position.set(0, 0.02, -track.hand * (track.r + 260)); scene.add(w); }
  if (cs.sea) { const w = new THREE.Mesh(new THREE.PlaneGeometry(6000, 2000), new THREE.MeshLambertMaterial({ color: '#3f86b0' })); w.rotation.x = -Math.PI / 2; w.position.set(0, 0.03, -track.hand * 1700); scene.add(w); }
  if (cs.castle) {
    const stone = new THREE.MeshLambertMaterial({ color: '#8d877b', flatShading: true });
    const base = new THREE.Vector3(-300, 0, -track.hand * 650);
    [[0, 0, 40, 26, 40], [-38, 0, 16, 40, 16], [38, 0, 16, 34, 16], [0, 0, 70, 14, 8]].forEach(([dx, , w, h, d]) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), stone); m.position.set(base.x + dx, h / 2, base.z); scene.add(m); });
  }
  if (night) {
    for (let i = 0; i < 10; i++) {
      const p = track.at((i / 10) * track.C, i % 2 ? -18 : W + 20);
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.7, 40, 8), new THREE.MeshLambertMaterial({ color: '#555' })); mast.position.set(p.x, 20, p.z); scene.add(mast);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(6, 3, 1), new THREE.MeshBasicMaterial({ color: '#fffbe8' })); lamp.position.set(p.x, 40, p.z); scene.add(lamp);
    }
  }
  return { sun, crowd: { body, headM, base: crowdBase } };
}

// ── starting stalls ──
function buildStalls(scene, track, s0, field) {
  const g = new THREE.Group();
  const frame = new THREE.MeshLambertMaterial({ color: '#e9eef2' });
  const green = new THREE.MeshLambertMaterial({ color: '#1f6b3a' });
  const doors = [];
  const p = track.point(s0);
  const yaw = Math.atan2(-p.hz, p.hx);
  for (let i = 0; i <= field; i++) {
    const d = 0.8 + i * 1.32;
    const at = track.at(s0, d - 0.66);
    const wall = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.5, 0.08), green); wall.position.set(at.x, 1.15, at.z); wall.rotation.y = yaw; g.add(wall);
    if (i < field) {
      const cpos = track.at(s0 + 1.9, d);
      const door = new THREE.Group(); door.position.set(cpos.x, 0, cpos.z); door.rotation.y = yaw;
      const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.0, 1.25), frame); leaf.position.set(0, 1.1, 0); door.add(leaf);
      g.add(door); doors.push(door);
    }
  }
  const a = track.at(s0, 0), b = track.at(s0, 0.8 + field * 1.32);
  const top = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, a.distanceTo(b) + 1), frame);
  top.position.set((a.x + b.x) / 2, 3.1, (a.z + b.z) / 2); top.rotation.y = yaw; g.add(top);
  scene.add(g);
  return { group: g, doors, yaw };
}

/**
 * Creates a viewer on `canvas`. Call load(race) with a race that has a trace (or none, for a preview of
 * the horses in the stalls), then setTime(seconds since the off) every frame or use play().
 */
export async function createViewer(canvas, { quality: q = 'auto', onEvent } = {}) {
  const cores = navigator.hardwareConcurrency || 4;
  const weak = q === 'low' || (q === 'auto' && (cores <= 4 || /Android/.test(navigator.userAgent)));
  const quality = { high: !weak, shadows: !weak };
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: !weak, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, weak ? 1.25 : 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = quality.shadows; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const camera = new THREE.PerspectiveCamera(42, 1, 0.3, 5000);
  const gltf = await loadHorse();
  let scene = null, state = null, disposed = false;

  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
  }

  function makeHorse(r, k) {
    const model = cloneSkinned(gltf.scene);
    const cols = COATS[r.coat] || COATS.bay;
    model.traverse((o) => {
      if (!o.isMesh) return;
      o.castShadow = true; o.frustumCulled = false;
      const ms = Array.isArray(o.material) ? o.material : [o.material];
      const out = ms.map((m) => {
        const c = m.clone();
        const map = { Main: cols[0], Main_Dark: cols[1], Main_Light: cols[2], Hair: cols[3], Muzzle: cols[4] };
        if (map[m.name]) c.color.set(map[m.name]);
        c.roughness = 0.55; c.metalness = 0.05;
        return c;
      });
      o.material = Array.isArray(o.material) ? out : out[0];
    });
    const holder = new THREE.Group(); holder.add(model);
    // scale the model to a real thoroughbred: about 2.6 m from nose to tail root
    model.updateMatrixWorld(true);
    let headB = null, tailB = null; model.traverse((o) => { if (o.name === 'Head') headB = o; if (o.name === 'Tail1') tailB = o; });
    const hpos = new THREE.Vector3(), tpos = new THREE.Vector3(); headB.getWorldPosition(hpos); tailB.getWorldPosition(tpos);
    model.scale.multiplyScalar(2.3 / Math.max(1e-6, hpos.distanceTo(tpos)));
    const mixer = new THREE.AnimationMixer(model);
    const clip = (n) => gltf.animations.find((a) => a.name.endsWith(`|${n}`));
    const gallop = mixer.clipAction(clip('Gallop')); const walk = mixer.clipAction(clip('Walk')); const idle = mixer.clipAction(clip('Idle'));
    [gallop, walk, idle].forEach((a) => { a.play(); a.setEffectiveWeight(0); });
    idle.setEffectiveWeight(1); idle.time = Math.random() * 3;
    gallop.time = Math.random() * 0.5;
    // which way the model faces: find the head relative to the body
    let head = null, back = null; model.traverse((o) => { if (o.name === 'Head') head = o; if (o.name === 'Torso2') back = o; });
    const jockey = makeJockey(r.silks, r.no); holder.add(jockey);
    const cloth = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.32), new THREE.MeshLambertMaterial({ map: clothTex(r.no, CLOTH[(r.no - 1) % CLOTH.length]), side: THREE.DoubleSide }));
    holder.add(cloth);
    scene.add(holder);
    return { r, k, holder, model, mixer, gallop, walk, idle, head, back, jockey, cloth, lane: 0, yawFix: null, lastX: 0, speed: 0 };
  }

  function load(race) {
    if (scene) dispose(true);
    scene = new THREE.Scene();
    const track = makeTrack(race.course);
    const venue = buildVenue(scene, track, race.course, quality);
    const s0 = track.finish - race.distance;
    const stalls = buildStalls(scene, track, s0, race.field);
    const horses = race.runners.map((r, k) => makeHorse(r, k));
    horses.forEach((h) => { h.lane = 0.8 + (h.r.draw - 1) * 1.32 + 0.66; });
    // work out the model's facing once (towards its head)
    const t0 = horses[0];
    t0.holder.updateMatrixWorld(true);
    const hp = new THREE.Vector3(), bp = new THREE.Vector3();
    t0.head?.getWorldPosition(hp); t0.back?.getWorldPosition(bp);
    const facing = Math.atan2(-(hp.z - bp.z), hp.x - bp.x); // model yaw so that head points +x
    const backH = bp.y;
    horses.forEach((h) => { h.facing = facing; h.backH = backH; });
    state = { race, track, venue, stalls, horses, s0, trace: race.trace, t: -6, cam: 'auto', follow: null, events: new Set(), lastLeader: null, finishedAt: null };
    resize();
    setTime(-6);
  }

  // distance covered by runner k at time t (s since the off), from the recorded run
  function distAt(k, t) {
    const tr = state.trace;
    if (!tr || t <= 0) return 0;
    const f = t / tr.every, i = Math.floor(f);
    const fr = tr.frames;
    if (i >= fr.length - 1) return fr[fr.length - 1][k];
    const a = fr[i][k], b = fr[i + 1][k];
    return a + (b - a) * (f - i);
  }

  function setTime(t) {
    if (!state) return;
    const dt = Math.max(0, Math.min(0.1, Math.abs(t - state.t)));
    state.t = t;
    const { track, horses, s0, race } = state;
    const xs = horses.map((h) => distAt(h.k, t));
    const order = horses.map((h) => h.k).sort((a, b) => xs[b] - xs[a]);
    const leadX = xs[order[0]];
    // lanes: horses drift towards the rail and fan out in the straight
    const toGo = race.distance - leadX;
    order.forEach((k, rank) => {
      const h = horses[k];
      let target;
      if (t <= 0) target = 0.8 + (h.r.draw - 1) * 1.32 + 0.66;
      else {
        let crowd = 0;
        for (const j of order) { if (j === k) break; if (xs[j] - xs[k] < 3.2) crowd++; }
        target = 1.0 + crowd * 1.45 + (toGo < 420 ? rank * 0.55 : 0);
        target = Math.min(W - 2, target);
      }
      h.lane += (target - h.lane) * Math.min(1, dt * 0.9 * (t > 0 ? 1 : 10));
    });
    for (const h of horses) {
      const x = xs[h.k];
      const s = s0 + x;
      const pos = track.at(s, h.lane);
      const p = track.point(s);
      const yaw = Math.atan2(-p.hz, p.hx);
      const v = dt > 0 ? Math.abs(x - h.lastX) / dt : h.speed;
      h.speed += (v - h.speed) * 0.2; h.lastX = x;
      h.holder.position.copy(pos);
      h.holder.rotation.y = yaw;
      h.model.rotation.y = -h.facing;
      // animation blend: idle in the stalls, gallop at speed, walk when pulling up
      const sp = h.speed;
      const gw = Math.min(1, Math.max(0, (sp - 3) / 5)), ww = sp > 0.3 ? Math.max(0, 1 - gw) : 0;
      h.gallop.setEffectiveWeight(gw); h.walk.setEffectiveWeight(ww * 0.9); h.idle.setEffectiveWeight(Math.max(0, 1 - gw - ww));
      h.gallop.timeScale = Math.max(0.5, sp / (GALLOP_STRIDE / 0.583) * 1);
      h.walk.timeScale = Math.max(0.6, sp / 1.6);
      h.mixer.update(dt);
      // the rider sits on the horse's back and moves with it
      h.holder.updateMatrixWorld(true);
      const bp = new THREE.Vector3(); h.back?.getWorldPosition(bp);
      h.holder.worldToLocal(bp);
      h.jockey.position.set(bp.x - 0.1, bp.y + 0.28, bp.z);
      h.jockey.rotation.set(0, 0, gw * 0.08 * Math.sin(h.gallop.time * Math.PI * 2 / 0.583));
      h.cloth.position.set(bp.x - 0.15, bp.y - 0.2, bp.z + 0.36);
      h.cloth.rotation.set(0, 0, 0);
    }
    // stalls doors swing open at the off
    state.stalls.doors.forEach((d) => { d.children[0].rotation.y = Math.min(Math.PI / 2, Math.max(0, t * 6)); });
    // the crowd stirs in the final furlongs
    const excite = t > 0 ? Math.max(0, 1 - toGo / 600) : 0;
    if (excite > 0.05 && Math.floor(t * 20) % 2 === 0) {
      const { body, headM, base } = state.venue.crowd; const mm = new THREE.Matrix4();
      for (let i = 0; i < base.length; i += 1) {
        const j = Math.max(0, Math.sin(t * 9 + i * 1.7)) * 0.35 * excite;
        mm.makeTranslation(base[i][0], base[i][1] + j, base[i][2]); body.setMatrixAt(i, mm);
        mm.makeTranslation(base[i][0], base[i][1] + 0.6 + j, base[i][2]); headM.setMatrixAt(i, mm);
      }
      body.instanceMatrix.needsUpdate = true; headM.instanceMatrix.needsUpdate = true;
    }
    // events for commentary and the HUD
    const ev = (key, data) => { if (!state.events.has(key)) { state.events.add(key); onEvent?.(key, data); } };
    if (t > -4) ev('orders', {});
    if (t > 0) ev('off', {});
    if (t > 0) {
      const leader = horses[order[0]].r;
      if (state.lastLeader !== leader.no && t > 4 && toGo > 30) { onEvent?.('leader', { no: leader.no, name: leader.name, toGo }); }
      state.lastLeader = leader.no;
      if (leadX > race.distance / 2) ev('halfway', { leader });
      if (toGo < 402) ev('2f', { leader });
      if (toGo < 201) ev('1f', { leader });
      if (toGo <= 0) ev('finish', { winner: state.race.result?.positions?.[0] });
    }
    // camera
    updateCamera(t, xs, order);
    // the shadow area follows the leaders
    const lead = horses[order[0]].holder.position;
    if (quality.shadows) { const sun = state.venue.sun; sun.position.set(lead.x - 120, 260, lead.z + 160); sun.target.position.copy(lead); }
    renderer.render(scene, camera);
    return { order: order.map((k) => horses[k].r.no), xs, toGo, leadX };
  }

  const camPos = new THREE.Vector3(), camLook = new THREE.Vector3();
  let camInit = false;
  function updateCamera(t, xs, order) {
    const { track, horses, s0, race } = state;
    const lead = xs[order[0]], tail = xs[order[order.length - 1]];
    const mid = (lead + Math.max(tail, lead - 30)) / 2;
    let mode = state.cam;
    const toGo = race.distance - lead;
    if (mode === 'auto') mode = t < 1.5 ? 'stalls' : toGo < 90 && toGo > -40 ? 'finish' : toGo < 500 ? 'side' : 'broadcast';
    if (state.follow != null && mode === 'jockey') {/* follows the chosen horse */}
    let pos, look, fov = 42, snap = false;
    if (mode === 'stalls') {
      const n = race.field * 1.32;
      pos = track.at(s0 + 16, n + 9).setY(3.4); look = track.at(s0, n * 0.45).setY(1.2); fov = 40;
    } else if (mode === 'broadcast') {
      // the classic elevated camera from the stands side, slightly behind the leaders
      pos = track.at(s0 + mid - 14, W + 26).setY(9); look = track.at(s0 + mid + 4, W / 4).setY(1.2); fov = 30;
    } else if (mode === 'side') {
      // the tracking car running alongside the field
      pos = track.at(s0 + mid + 2, W + 5).setY(2.4); look = track.at(s0 + mid, W / 5).setY(1.3); fov = 38;
    } else if (mode === 'overhead') {
      const c = track.at(s0 + mid, W / 4); pos = track.at(s0 + mid - 8, W / 4).setY(38); look = c; fov = 42;
    } else if (mode === 'finish') {
      // fixed on the infield, looking across the line towards the stands
      pos = track.at(track.finish, -16).setY(2.2); look = track.at(track.finish, W * 0.6).setY(1.4); fov = 26; snap = true;
    } else if (mode === 'jockey') {
      const k = state.follow != null ? horses.findIndex((h) => h.r.no === state.follow) : order[0];
      const h = horses[k >= 0 ? k : order[0]];
      const x = xs[h.k];
      pos = track.at(s0 + x + 1.6, h.lane).setY(2.9); look = track.at(s0 + x + 40, h.lane * 0.7).setY(1.5); fov = 62; snap = true;
    }
    if (!camInit || snap) { camPos.copy(pos); camLook.copy(look); camInit = true; }
    else { camPos.lerp(pos, 0.08); camLook.lerp(look, 0.12); }
    camera.fov += (fov - camera.fov) * (snap ? 1 : 0.1); camera.updateProjectionMatrix();
    camera.position.copy(camPos); camera.lookAt(camLook);
    state.camMode = mode;
  }

  function setCamera(mode, follow = null) { if (state) { state.cam = mode; state.follow = follow; camInit = false; } }

  /** A still image of the finish (for the photo-finish panel), taken from the finish camera. */
  function photoFinish(t) {
    if (!state) return null;
    const prev = state.cam; state.cam = 'finish'; camInit = false;
    setTime(t);
    const url = canvas.toDataURL('image/jpeg', 0.85);
    state.cam = prev; camInit = false;
    return url;
  }

  function dispose(keepRenderer = false) {
    if (scene) scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); const m = o.material; if (m) (Array.isArray(m) ? m : [m]).forEach((x) => { x.map?.dispose(); x.dispose(); }); });
    scene = null; state = null;
    if (!keepRenderer) { disposed = true; renderer.dispose(); }
  }

  return { load, setTime, setCamera, resize, dispose, photoFinish, get state() { return state; }, get disposed() { return disposed; }, quality };
}

/** A portrait of a horse in its coat with its jockey's silks (for profiles), as a data URL. */
export async function horsePortrait({ coat, silks, no = 1 }, w = 480, h = 320) {
  const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
  const v = await createViewer(canvas, { quality: 'high' });
  const race = { course: 'ashcombe', distance: 1200, field: 1, runners: [{ no, draw: 1, coat, silks, name: '' }], trace: null };
  v.load(race);
  const st = v.state;
  const hz = st.horses[0];
  for (let i = 0; i < 6; i++) v.setTime(-6 + i * 0.05);
  const p = hz.holder.position;
  const cam = new THREE.PerspectiveCamera(30, w / h, 0.1, 5000);
  const yaw = hz.holder.rotation.y;
  cam.position.set(p.x + Math.cos(yaw) * 2.5 + Math.sin(yaw) * 6.5, 1.8, p.z - Math.sin(yaw) * 2.5 + Math.cos(yaw) * 6.5);
  cam.lookAt(p.x, 1.2, p.z);
  const r = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
  r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.ACESFilmicToneMapping; r.setSize(w, h, false);
  // hide the stalls for the portrait
  st.stalls.group.visible = false;
  r.render(st.horses[0].holder.parent, cam);
  const url = canvas.toDataURL('image/jpeg', 0.88);
  r.dispose(); v.dispose();
  return url;
}
