// One race: the racecard, the broadcast / replay, the bet slip and the result.
import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../../lib/api.js';
import { useApp } from '../../state/AppContext.jsx';
import { Link } from '../../lib/router.jsx';
import { money } from '../../lib/format.js';
import { Loading, ErrorBox, Modal } from '../../components/ui.jsx';
import { Countdown, FormFigures, OddsToggle, PhaseBadge, Silks, offTime, oddsText, pounds, useOddsFormat } from './common.jsx';
import Viewer from './Viewer.jsx';
import * as rcAudio from './audio.js';

const TYPES = [
  ['win', 'Win / Each Way', 1], ['place', 'Place', 1], ['forecast', 'Forecast', 2], ['reverse_forecast', 'Reverse Forecast', 2], ['tricast', 'Tricast', 3], ['trio', 'Trio', 3],
];
const TYPE_NAME = { win: 'Win', each_way: 'Each Way', place: 'Place', forecast: 'Forecast', reverse_forecast: 'Reverse Forecast', tricast: 'Tricast', trio: 'Trio' };
const HELP = {
  win: 'Tap a price to back a horse to win. Switch on Each Way in the slip to add a place bet too (half on the win, half on the place).',
  place: 'Your horse must finish in the places shown in the terms.',
  forecast: 'Pick the 1st and 2nd in the correct order.',
  reverse_forecast: 'Pick two horses to finish 1st and 2nd in either order (2 bets).',
  tricast: 'Pick the first three in the correct order.',
  trio: 'Pick three horses to finish in the first three in any order.',
};
const QUICK = [100, 500, 1000, 2500];
const nonce = () => { try { return Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => b.toString(16).padStart(2, '0')).join(''); } catch { return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`; } };
const RATING = [['speed', 'Speed'], ['stamina', 'Stamina'], ['accel', 'Acceleration'], ['finish', 'Finishing'], ['temperament', 'Temperament']];

function RunnerDetail({ r }) {
  const [h, setH] = useState(null);
  useEffect(() => { api.get(`/api/racing/horses/${r.horseId}`).then(setH).catch(() => {}); }, [r.horseId]);
  if (!h) return <div className="px-3 pb-3 text-xs text-rc-cream/50">Loading profile…</div>;
  return (
    <div className="grid gap-3 px-3 pb-3 text-xs text-rc-cream/80 sm:grid-cols-2">
      <div className="space-y-1">
        {RATING.map(([k, l]) => (
          <div key={k} className="flex items-center gap-2"><span className="w-24 text-rc-cream/55">{l}</span><div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-rc-gold to-rc-gold2" style={{ width: `${h.ratings[k]}%` }} /></div><span className="w-6 text-right tabular-nums text-white">{h.ratings[k]}</span></div>
        ))}
      </div>
      <div className="space-y-0.5">
        <div>Style: <b className="text-white">{h.style}</b> · Likes: <b className="text-white">{({ firm: 'Firm', gf: 'Good to Firm', good: 'Good', gs: 'Good to Soft', soft: 'Soft', heavy: 'Heavy' })[h.goingPref]}</b></div>
        <div>Record: <b className="text-white">{h.runs} runs, {h.wins} wins, {h.places} places</b></div>
        <div>Trainer {h.trainer} · Owner {h.owner}</div>
        <div>By {h.sire} out of {h.dam}</div>
        <Link to={`/racing/horse/${h.id}`} className="mt-1 inline-block font-bold text-rc-gold">Full profile →</Link>
      </div>
    </div>
  );
}

export default function RacePage({ id }) {
  const { user, setUser, toast } = useApp();
  const [race, setRace] = useState(null);
  const [error, setError] = useState(null);
  const [skew, setSkew] = useState(0);
  const [type, setType] = useState('win');
  const [picks, setPicks] = useState([]);           // for multi-horse bets
  const [slip, setSlip] = useState([]);             // [{ key, type, picks, stake, ew }]
  const [quotes, setQuotes] = useState([]);
  const [confirm, setConfirm] = useState(false);
  const [sending, setSending] = useState(false);
  const [placed, setPlaced] = useState(null);
  const [open, setOpen] = useState(null);           // expanded runner
  const [starting, setStarting] = useState(false);
  const [slipOpen, setSlipOpen] = useState(false);
  const [watching, setWatching] = useState(false);  // a quick race you just started: hold the result until it has been shown
  const [fmt] = useOddsFormat();
  const pendingUser = useRef(null);
  const ref = useRef(nonce());

  const load = () => api.get(`/api/racing/races/${id}`).then((r) => { setRace(r); setError(null); }).catch(setError);
  useEffect(() => { load(); api.get('/api/racing').then((d) => setSkew(d.now - Date.now())).catch(() => {}); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  // follow the race through its phases
  useEffect(() => {
    if (!race) return undefined;
    let wait = null;
    const t = Date.now() + skew;
    if (race.phase === 'open' || race.phase === 'closing') wait = Math.max(500, race.off - t + 300);
    else if (race.phase === 'live') wait = Math.max(1000, race.off + race.duration * 1000 + 2000 - t);
    if (wait == null) return undefined;
    const h = setTimeout(load, Math.min(wait, 20000));
    return () => clearTimeout(h);
  }, [race, skew]); // eslint-disable-line react-hooks/exhaustive-deps

  // price the slip on the server whenever it changes
  const slipBets = useMemo(() => slip.map((s) => ({ type: s.type === 'win' && s.ew ? 'each_way' : s.type, picks: s.picks, stake: s.stake })), [slip]);
  useEffect(() => {
    if (!slip.length || !race) { setQuotes([]); return undefined; }
    const h = setTimeout(() => api.post('/api/racing/quote', { raceId: race.id, bets: slipBets }).then((d) => setQuotes(d.bets)).catch(() => {}), 150);
    return () => clearTimeout(h);
  }, [slipBets, race?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (error) return <ErrorBox error={error} onRetry={load} />;
  if (!race) return <Loading label="Loading racecard…" />;
  const canBet = user && (race.phase === 'open' || race.phase === 'ready');
  const byNo = new Map(race.runners.map((r) => [r.no, r]));
  const need = TYPES.find((x) => x[0] === type)[2];
  const ordered = type === 'forecast' || type === 'tricast';
  const total = quotes.reduce((a, q) => a + (q.total || 0), 0);
  const bad = quotes.some((q) => q.error);

  const addSingle = (r) => {
    if (!canBet) return;
    rcAudio.unlock(); rcAudio.ui('select', { gain: 0.5 });
    const t = type === 'place' ? 'place' : 'win';
    const key = `${t}:${r.no}`;
    setSlip((s) => (s.some((x) => x.key === key) ? s.filter((x) => x.key !== key) : [...s, { key, type: t, picks: [r.no], stake: 100, ew: false }]));
    setSlipOpen(true);
  };
  const togglePick = (no, pos = null) => {
    rcAudio.unlock();
    setPicks((p) => {
      if (ordered) { const n = [...p]; const at = n.indexOf(no); if (at >= 0) n[at] = undefined; n[pos] = no; return n.slice(0, need); }
      return p.includes(no) ? p.filter((x) => x !== no) : p.length < need ? [...p, no] : p;
    });
  };
  const chosen = ordered ? picks.filter((x) => x != null) : picks;
  const addMulti = () => {
    if (chosen.length !== need || (ordered && picks.slice(0, need).some((x) => x == null))) return;
    const key = `${type}:${chosen.join('-')}`;
    if (!slip.some((x) => x.key === key)) setSlip((s) => [...s, { key, type, picks: chosen, stake: 100 }]);
    setPicks([]); setSlipOpen(true); rcAudio.ui('select', { gain: 0.5 });
  };
  const place = async () => {
    if (sending) return;
    setSending(true);
    try {
      const d = await api.post('/api/racing/bets', { raceId: race.id, bets: slipBets, nonce: ref.current });
      ref.current = nonce();
      setPlaced(d.placed); setSlip([]); setConfirm(false); setSlipOpen(false); setUser(d.user); rcAudio.sfx('confirm'); rcAudio.ui('confirm');
      load();
    } catch (e) { toast(e.message, 'error'); if (e.status === 409) { ref.current = nonce(); setConfirm(false); load(); } }
    finally { setSending(false); }
  };
  const start = async () => {
    setStarting(true); rcAudio.unlock();
    try { const d = await api.post(`/api/racing/races/${race.id}/start`, {}); pendingUser.current = d.user; setWatching(true); setRace(d.race); setTimeout(() => document.getElementById('rc-viewer')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50); }
    catch (e) { toast(e.message, 'error'); }
    finally { setStarting(false); }
  };

  const slipPanel = (
    <div className="space-y-2">
      {!slip.length && <p className="py-3 text-center text-sm text-rc-cream/50">{canBet ? 'Tap a price on the racecard to add a bet.' : race.phase === 'result' ? 'This race has finished.' : 'Betting has closed for this race.'}</p>}
      {slip.map((s, i) => {
        const q = quotes[i];
        const ew = s.type === 'win' && s.ew;
        const names = s.picks.map((no) => `${no}. ${byNo.get(no)?.name}`);
        return (
          <div key={s.key} className="rounded-xl border border-white/10 bg-black/25 p-2.5">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[10px] font-extrabold uppercase tracking-wider text-rc-gold">{TYPE_NAME[ew ? 'each_way' : s.type]}{s.type === 'reverse_forecast' ? ' · 2 bets' : ''}{ew ? ' · 2 bets' : ''}</div>
                <div className="text-sm font-semibold text-white">{names.join(s.type === 'forecast' || s.type === 'tricast' ? ' → ' : ' · ')}</div>
                <div className="text-[11px] text-rc-cream/60">
                  {q?.price?.win && <>Win {oddsText(q.price.win, fmt)} </>}
                  {q?.price?.place && <>Place {oddsText(q.price.place.dec, 'dec')}{q.price.place.fraction ? ` (${q.price.place.fraction[0]}/${q.price.place.fraction[1]} odds, ${q.price.place.places} places)` : ` (${q.price.places || q.price.place.places} places)`} </>}
                  {q?.price?.lines && q.price.lines.map((l, k) => <span key={k}>{k ? ' / ' : ''}{oddsText(l.dec, fmt)}</span>)}
                </div>
              </div>
              <button type="button" onClick={() => setSlip((x) => x.filter((y) => y.key !== s.key))} className="shrink-0 rounded-full p-1 text-rc-cream/50 hover:text-white" aria-label={`Remove ${names.join(', ')}`}>
                <svg viewBox="0 0 20 20" className="h-4 w-4" fill="currentColor"><path d="M5.3 5.3a1 1 0 011.4 0L10 8.6l3.3-3.3a1 1 0 111.4 1.4L11.4 10l3.3 3.3a1 1 0 01-1.4 1.4L10 11.4l-3.3 3.3a1 1 0 01-1.4-1.4L8.6 10 5.3 6.7a1 1 0 010-1.4z" /></svg>
              </button>
            </div>
            <div className="mt-2 flex items-center gap-1.5">
              <button type="button" className="rc-step" onClick={() => setSlip((x) => x.map((y) => (y.key === s.key ? { ...y, stake: Math.max(10, y.stake - (y.stake > 1000 ? 500 : 100)) } : y)))} aria-label="Lower stake">−</button>
              <label className="relative flex-1"><span className="absolute left-2 top-1/2 -translate-y-1/2 text-sm text-rc-cream/50">£</span>
                <input inputMode="decimal" className="h-10 w-full rounded-lg border border-white/15 bg-black/30 pl-6 pr-2 text-right font-cond text-lg font-bold text-white tabular-nums" aria-label="Stake per bet"
                  value={(s.stake / 100).toFixed(2)} onChange={(e) => { const v = Math.round(parseFloat(e.target.value.replace(/[^0-9.]/g, '')) * 100); setSlip((x) => x.map((y) => (y.key === s.key ? { ...y, stake: Number.isFinite(v) ? Math.max(0, Math.min(100000, v)) : 0 } : y))); }} />
              </label>
              <button type="button" className="rc-step" onClick={() => setSlip((x) => x.map((y) => (y.key === s.key ? { ...y, stake: Math.min(100000, y.stake + (y.stake >= 1000 ? 500 : 100)) } : y)))} aria-label="Raise stake">+</button>
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-1">
              {QUICK.map((v) => <button key={v} type="button" onClick={() => setSlip((x) => x.map((y) => (y.key === s.key ? { ...y, stake: v } : y)))} className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${s.stake === v ? 'bg-rc-gold text-rc-ink' : 'bg-white/10 text-rc-cream/80'}`}>{money(v)}</button>)}
              {s.type === 'win' && race.terms && <label className="ml-auto flex items-center gap-1 text-[11px] font-bold text-rc-cream/80"><input type="checkbox" className="h-4 w-4 accent-amber-400" checked={!!s.ew} onChange={(e) => setSlip((x) => x.map((y) => (y.key === s.key ? { ...y, ew: e.target.checked } : y)))} />Each way</label>}
            </div>
            <div className="mt-1.5 flex justify-between text-[11px]">
              <span className="text-rc-cream/60">Stake {money(q?.total ?? s.stake)}{q?.lines > 1 ? ` (${q.lines} × ${money(s.stake)})` : ''}</span>
              {q?.error ? <span className="text-red-300">{q.error}</span> : <span className="text-rc-cream/60">Returns up to <b className="text-emerald-300">{money(q?.potential || 0)}</b></span>}
            </div>
          </div>
        );
      })}
      {slip.length > 0 && (
        <div className="space-y-2 border-t border-white/10 pt-2">
          <div className="flex justify-between text-sm"><span className="text-rc-cream/70">Total stake</span><b className="font-cond text-lg text-white">{money(total)}</b></div>
          <div className="flex justify-between text-xs text-rc-cream/60"><span>Balance</span><span>{money(user?.balance ?? 0)}</span></div>
          <div className="flex gap-2">
            <button type="button" onClick={() => setSlip([])} className="h-11 rounded-xl bg-white/10 px-3 text-sm font-bold text-rc-cream">Clear</button>
            <button type="button" disabled={!canBet || !total || bad || total > (user?.balance ?? 0)} onClick={() => setConfirm(true)} className="rc-gold-btn h-11 flex-1 rounded-xl text-sm font-extrabold disabled:opacity-40">{total > (user?.balance ?? 0) ? 'Not enough balance' : `Place bets · ${money(total)}`}</button>
          </div>
        </div>
      )}
    </div>
  );

  const result = !watching && (race.phase === 'result' || (race.kind === 'quick' && race.phase === 'live')) && race.result;
  return (
    <div className="rc-page space-y-3 pb-24 lg:pb-4">
      <Link to="/racing" className="inline-flex items-center gap-1 text-sm font-semibold text-rc-gold"><svg viewBox="0 0 20 20" className="h-4 w-4 rotate-180" fill="currentColor"><path d="M7.3 4.3a1 1 0 011.4 0l5 5a1 1 0 010 1.4l-5 5a1 1 0 01-1.4-1.4L11.6 10 7.3 5.7a1 1 0 010-1.4z" /></svg>Racing</Link>
      <header className="rc-hero-card rounded-2xl border border-rc-gold/25 p-3 sm:p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <PhaseBadge phase={race.phase} kind={race.kind} />
          <div className="flex items-center gap-2 text-sm">
            {race.phase === 'open' && <span className="font-semibold text-rc-cream/70">Off in <Countdown to={race.off} skew={skew} className="font-cond text-lg font-bold text-emerald-300" /></span>}
            <OddsToggle />
          </div>
        </div>
        <div className="mt-1.5 text-[11px] font-bold uppercase tracking-[.2em] text-rc-gold"><Link to={`/racing/course/${race.course}`}>{race.courseName}</Link> · {offTime(race.off)}</div>
        <h1 className="font-serif text-2xl font-bold leading-tight text-white sm:text-3xl">{race.name}</h1>
        <div className="mt-2 flex flex-wrap gap-1.5 text-[11px] font-semibold text-rc-cream/80">
          {[race.distanceLabel, `Going: ${race.goingName}`, `${race.field} runners`, race.type, race.formatName, `Prize fund ${pounds(race.prize)} (fictional)`, race.terms ? `Each way ${race.terms.fraction[0]}/${race.terms.fraction[1]} odds · ${race.terms.places} places` : 'Win only'].map((x) => <span key={x} className="rounded-full bg-white/[0.07] px-2 py-0.5 ring-1 ring-white/10">{x}</span>)}
        </div>
      </header>

      <div id="rc-viewer" className="scroll-mt-20" />
      <Viewer key={`${race.id}-${race.trace ? 'run' : 'card'}`} race={race} skew={skew} live={race.phase === 'live' && race.kind === 'sched'} onDone={() => { if (pendingUser.current) { setUser(pendingUser.current); pendingUser.current = null; } setWatching(false); load(); }} />

      {race.phase === 'ready' && (
        <div className="flex flex-col items-center gap-2 rounded-2xl border border-rc-gold/30 bg-rc-panel p-3 sm:flex-row">
          <p className="flex-1 text-sm text-rc-cream/80">Your own virtual race: place your bets, then start it whenever you're ready. The result is decided by the server when you press Start.</p>
          <button type="button" onClick={start} disabled={starting} className="rc-gold-btn h-12 w-full rounded-xl px-6 text-base font-extrabold sm:w-auto">{starting ? 'Loading the stalls…' : 'Start the race'}</button>
        </div>
      )}

      {result && (
        <section className="overflow-hidden rounded-2xl border border-rc-gold/25 bg-rc-panel">
          <div className="flex items-center justify-between border-b border-white/10 px-3 py-2"><h2 className="font-serif text-lg font-bold text-white">Result</h2><span className="text-xs text-rc-cream/60">Winning time {Math.floor(result.winTime / 60)}m {(result.winTime % 60).toFixed(2)}s{result.photo ? ' · Photo finish' : ''}</span></div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-sm">
              <thead className="text-left text-[10px] uppercase tracking-wider text-rc-cream/50"><tr><th className="px-3 py-1.5">Pos</th><th>No</th><th>Horse</th><th>Jockey</th><th className="text-right">SP</th><th className="text-right">Dist</th><th className="px-3 text-right">Time</th></tr></thead>
              <tbody className="divide-y divide-white/5">
                {result.positions.map((p) => { const r = byNo.get(p.no); return (
                  <tr key={p.no} className={p.pos === 1 ? 'bg-rc-gold/10' : ''}>
                    <td className="px-3 py-1.5 font-cond text-base font-bold text-white">{p.pos === 1 ? <span className="text-rc-gold">1st</span> : `${p.pos}${['', 'st', 'nd', 'rd'][p.pos] || 'th'}`}</td>
                    <td><span className="inline-flex items-center gap-1"><Silks silks={r.silks} size={18} />{p.no}</span></td>
                    <td className="font-semibold text-white"><Link to={`/racing/horse/${r.horseId}`}>{r.name}</Link></td>
                    <td className="text-rc-cream/70">{r.jockey}</td>
                    <td className="text-right tabular-nums">{oddsText(r.odds, fmt)}{race.favourite === r.no ? <span className="ml-0.5 text-[10px] text-rc-gold">F</span> : ''}</td>
                    <td className="text-right text-rc-cream/70">{p.margin || '–'}</td>
                    <td className="px-3 text-right tabular-nums text-rc-cream/70">{p.time.toFixed(2)}s</td>
                  </tr>); })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_340px] lg:items-start lg:gap-3">
        <section className="overflow-hidden rounded-2xl border border-white/10 bg-rc-panel">
          <div className="scrollbar-none flex gap-1 overflow-x-auto border-b border-white/10 p-1.5" role="tablist" aria-label="Bet type">
            {TYPES.map(([k, l]) => <button key={k} type="button" role="tab" aria-selected={type === k} onClick={() => { setType(k); setPicks([]); }} className={`shrink-0 rounded-lg px-3 py-1.5 text-xs font-bold ${type === k ? 'bg-rc-gold text-rc-ink' : 'text-rc-cream/70 hover:text-white'}`}>{l}</button>)}
          </div>
          <p className="px-3 pt-2 text-[11px] text-rc-cream/60">{HELP[type]}</p>
          <ul className="divide-y divide-white/[0.06]">
            {race.runners.map((r) => {
              const inSlip = slip.some((s) => s.picks.length === 1 && s.picks[0] === r.no && (type === 'place' ? s.type === 'place' : s.type === 'win'));
              const fin = result ? result.positions.find((p) => p.no === r.no) : null;
              return (
                <li key={r.no}>
                  <div className="flex items-center gap-2 px-3 py-2">
                    <div className="flex w-8 shrink-0 flex-col items-center leading-none"><span className="font-cond text-lg font-bold text-white">{r.no}</span><span className="text-[10px] text-rc-cream/50">({r.draw})</span></div>
                    <Silks silks={r.silks} size={34} className="shrink-0" />
                    <button type="button" onClick={() => setOpen(open === r.no ? null : r.no)} className="min-w-0 flex-1 text-left" aria-expanded={open === r.no}>
                      <div className="truncate font-semibold text-white">{r.name}{fin && <span className="ml-1.5 rounded bg-white/10 px-1 text-[10px] font-bold text-rc-gold">{fin.pos}{['', 'st', 'nd', 'rd'][fin.pos] || 'th'}</span>}</div>
                      <div className="truncate text-[11px] text-rc-cream/60">J: {r.jockey} · T: {r.trainer}</div>
                      <div className="text-[11px] text-rc-cream/60">{r.age}yo · {Math.floor(r.weight / 14)}st {r.weight % 14}lb · Rtg {r.rating} · Form <FormFigures form={r.form} /></div>
                    </button>
                    {(type === 'win' || type === 'place') ? (
                      <button type="button" disabled={!canBet} onClick={() => addSingle(r)} className={`rc-odds ${inSlip ? 'rc-odds-on' : ''}`} aria-pressed={inSlip} aria-label={`${r.name} ${oddsText(r.odds, fmt)}`}>
                        {type === 'place' ? <span className="text-[10px] font-semibold opacity-80">Place</span> : null}{oddsText(r.odds, fmt)}
                      </button>
                    ) : ordered ? (
                      <div className="flex gap-1">{Array.from({ length: need }, (_, pos) => <button key={pos} type="button" disabled={!canBet} onClick={() => togglePick(r.no, pos)} className={`rc-pos ${picks[pos] === r.no ? 'rc-odds-on' : ''}`} aria-pressed={picks[pos] === r.no}>{['1st', '2nd', '3rd'][pos]}</button>)}</div>
                    ) : (
                      <button type="button" disabled={!canBet} onClick={() => togglePick(r.no)} className={`rc-pos w-12 ${picks.includes(r.no) ? 'rc-odds-on' : ''}`} aria-pressed={picks.includes(r.no)}>{picks.includes(r.no) ? 'Picked' : 'Pick'}</button>
                    )}
                  </div>
                  {open === r.no && <RunnerDetail r={r} />}
                </li>
              );
            })}
          </ul>
          {type !== 'win' && type !== 'place' && canBet && (
            <div className="sticky bottom-0 flex items-center gap-2 border-t border-white/10 bg-rc-panel/95 p-2 backdrop-blur">
              <span className="flex-1 text-xs text-rc-cream/70">{chosen.length}/{need} selected{chosen.length ? `: ${chosen.map((n) => byNo.get(n)?.name).join(ordered ? ' → ' : ', ')}` : ''}</span>
              <button type="button" disabled={chosen.length !== need} onClick={addMulti} className="rc-gold-btn h-10 rounded-lg px-4 text-sm font-extrabold disabled:opacity-40">Add to slip</button>
            </div>
          )}
        </section>
        <aside className="hidden rounded-2xl border border-rc-gold/25 bg-rc-panel p-3 lg:sticky lg:top-[130px] lg:block">
          <div className="mb-2 flex items-center justify-between"><h2 className="font-serif text-lg font-bold text-white">Bet slip</h2><span className="text-xs text-rc-cream/60">{race.name.split(' ').slice(0, 3).join(' ')}</span></div>
          {slipPanel}
        </aside>
      </div>

      {race.myBets?.length > 0 && !watching && (
        <section className="rounded-2xl border border-white/10 bg-rc-panel p-3">
          <h2 className="mb-2 font-serif text-lg font-bold text-white">Your bets on this race</h2>
          <ul className="space-y-1.5 text-sm">
            {race.myBets.map((b) => (
              <li key={b.id} className="flex items-center justify-between gap-2 rounded-lg bg-black/20 px-2.5 py-1.5">
                <span className="min-w-0"><b className="text-white">{b.typeName}</b> <span className="text-rc-cream/70">{b.picks.map((n) => byNo.get(n)?.name).join(', ')}</span><span className="block text-[11px] text-rc-cream/50">{b.ref} · stake {money(b.total)}</span></span>
                <span className={`shrink-0 text-right text-xs font-bold ${b.status === 'won' || b.status === 'placed' ? 'text-emerald-300' : b.status === 'lost' ? 'text-red-300' : 'text-rc-gold'}`}>{b.status === 'open' ? `To return ${money(b.potential)}` : b.status === 'running' ? 'Running…' : b.status === 'lost' ? 'Lost' : `Returned ${money(b.returns)}`}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* the slip on phones: a bar that opens a sheet */}
      {(slip.length > 0 || canBet) && (
        <div className="fixed inset-x-0 bottom-[calc(58px+env(safe-area-inset-bottom))] z-30 px-3 pb-2 lg:hidden">
          <button type="button" onClick={() => setSlipOpen(true)} className="flex h-12 w-full items-center justify-between rounded-2xl border border-rc-gold/40 bg-rc-ink/95 px-4 text-sm font-bold text-white shadow-2xl backdrop-blur">
            <span className="flex items-center gap-2"><span className="rounded-full bg-rc-gold px-2 text-rc-ink">{slip.length}</span>Bet slip</span>
            <span className="font-cond text-lg">{money(total)}</span>
          </button>
        </div>
      )}
      <Modal open={slipOpen && typeof window !== 'undefined' && window.innerWidth < 1024} onClose={() => setSlipOpen(false)} title={`Bet slip · ${race.courseName} ${offTime(race.off)}`}>{slipPanel}</Modal>
      <Modal open={confirm} onClose={() => !sending && setConfirm(false)} title="Confirm your bets">
        <div className="space-y-2 text-sm">
          <div className="text-xs text-rc-cream/60">{race.name} · {race.courseName} · {offTime(race.off)}</div>
          {slip.map((s, i) => <div key={s.key} className="flex justify-between gap-2"><span className="text-white">{TYPE_NAME[s.type === 'win' && s.ew ? 'each_way' : s.type]}: {s.picks.map((n) => byNo.get(n)?.name).join(', ')}</span><span className="shrink-0 tabular-nums">{money(quotes[i]?.total || 0)}</span></div>)}
          <div className="flex justify-between border-t border-white/10 pt-2 font-bold"><span>Total stake</span><span>{money(total)}</span></div>
          <div className="flex justify-between text-xs text-rc-cream/60"><span>Balance after</span><span>{money((user?.balance ?? 0) - total)}</span></div>
          <p className="text-[11px] text-rc-cream/50">Prices are fixed when your bets are placed. Virtual credits only.</p>
          <button type="button" disabled={sending} onClick={place} className="rc-gold-btn h-12 w-full rounded-xl text-base font-extrabold disabled:opacity-50">{sending ? 'Placing…' : 'Confirm bets'}</button>
        </div>
      </Modal>
      <Modal open={!!placed} onClose={() => setPlaced(null)} title="Bets placed">
        <div className="space-y-2 text-sm">
          <div className="text-center"><svg viewBox="0 0 48 48" className="mx-auto h-12 w-12 text-emerald-400"><circle cx="24" cy="24" r="22" fill="currentColor" opacity=".15" /><path d="M14 25l7 7 13-15" stroke="currentColor" strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg></div>
          {placed?.map((b) => <div key={b.id} className="flex justify-between gap-2 rounded-lg bg-black/20 px-2 py-1.5"><span><b>{b.typeName}</b> {b.picks.map((n) => byNo.get(n)?.name).join(', ')}<span className="block text-[11px] text-rc-cream/50">{b.ref}</span></span><span className="text-right text-xs">Stake {money(b.total)}<br />Up to {money(b.potential)}</span></div>)}
          <button type="button" onClick={() => setPlaced(null)} className="rc-gold-btn h-11 w-full rounded-xl font-extrabold">Done</button>
        </div>
      </Modal>
    </div>
  );
}
