// The race viewer: the 3D broadcast (or a 2D track view on weak devices / without WebGL) with a
// running-order bar, race clock, commentary captions, camera switching, replay and photo finish.
// Live races play in sync with the server clock; finished races can be replayed from any point.
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';

const ordinal = (n) => `${n}${n % 100 >= 11 && n % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10] || 'th'}`;
import { createPortal } from 'react-dom';
import { Silks } from './common.jsx';
import * as rcAudio from './audio.js';
import SoundPanel from './SoundPanel.jsx';

const Ico = {
  play: <svg viewBox="0 0 20 20" className="h-3.5 w-3.5" fill="currentColor"><path d="M6 4l10 6-10 6z" /></svg>,
  pause: <svg viewBox="0 0 20 20" className="h-3.5 w-3.5" fill="currentColor"><path d="M5 4h3.5v12H5zM11.5 4H15v12h-3.5z" /></svg>,
  sound: <svg viewBox="0 0 20 20" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 8h3l4-3v10l-4-3H3z" fill="currentColor" /><path d="M13 7.5a3.5 3.5 0 010 5M15.5 5a7 7 0 010 10" /></svg>,
  full: <svg viewBox="0 0 20 20" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 7V3h4M13 3h4v4M17 13v4h-4M7 17H3v-4" /></svg>,
  close: <svg viewBox="0 0 20 20" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l10 10M15 5L5 15" /></svg>,
};
const CAMS = [['auto', 'Director'], ['mine', 'My horse'], ['broadcast', 'Broadcast'], ['side', 'Side-on'], ['jockey', 'Jockey'], ['overhead', 'Overhead'], ['finish', 'Finish line']];
const QKEY = 'rc_quality';
const loadQ = () => { try { return localStorage.getItem(QKEY) || 'auto'; } catch { return 'auto'; } };

/** Top-down 2D track for weak devices or when WebGL is unavailable. */
function draw2D(cv, race, t, mine = []) {
  const g = cv.getContext('2d'); if (!g) return null; const w = cv.width = cv.clientWidth * (window.devicePixelRatio || 1); const h = cv.height = cv.clientHeight * (window.devicePixelRatio || 1);
  g.fillStyle = '#1e5a2e'; g.fillRect(0, 0, w, h);
  const D = race.distance, tr = race.trace;
  const xs = race.runners.map((_, k) => { if (!tr || t <= 0) return 0; const f = t / tr.every, i = Math.floor(f); const fr = tr.frames; if (i >= fr.length - 1) return fr[fr.length - 1][k]; return fr[i][k] + (fr[i + 1][k] - fr[i][k]) * (f - i); });
  const lead = Math.max(...xs);
  const view = 140; // metres shown
  const x0 = Math.max(-10, Math.min(D - view * 0.7, lead - view * 0.7));
  const px = (m) => ((m - x0) / view) * w;
  g.fillStyle = '#2f7a3d'; g.fillRect(0, h * 0.12, w, h * 0.76);
  for (let m = Math.ceil(x0 / 20) * 20; m < x0 + view; m += 20) { g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(px(m), h * 0.12, 1, h * 0.76); }
  g.fillStyle = '#fff'; g.fillRect(0, h * 0.12 - 3, w, 3); g.fillRect(0, h * 0.88, w, 3);
  if (D >= x0 && D <= x0 + view) { g.fillStyle = '#fff'; g.fillRect(px(D) - 2, h * 0.12, 4, h * 0.76); g.fillStyle = '#d0102a'; g.beginPath(); g.arc(px(D), h * 0.08, 8 * (w / 600), 0, 7); g.fill(); }
  const n = race.runners.length;
  race.runners.forEach((r, k) => {
    const y = h * 0.16 + ((r.draw - 1) / Math.max(1, n - 1)) * h * 0.68;
    const x = px(xs[k]);
    const rad = Math.max(7, Math.min(16, h / (n * 2.6)));
    if (mine.includes(r.no)) { g.strokeStyle = '#f5c542'; g.lineWidth = 4; g.beginPath(); g.arc(x, y, rad + 6, 0, 7); g.stroke(); g.fillStyle = '#f5c542'; g.beginPath(); g.moveTo(x, y - rad - 8); g.lineTo(x - 7, y - rad - 20); g.lineTo(x + 7, y - rad - 20); g.fill(); }
    g.fillStyle = r.silks.c1; g.beginPath(); g.arc(x, y, rad, 0, 7); g.fill();
    g.strokeStyle = r.silks.c2; g.lineWidth = 3; g.stroke();
    g.fillStyle = '#fff'; g.font = `bold ${rad}px Barlow, Arial`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(r.no), x, y + 1);
  });
  const order = race.runners.map((r, k) => k).sort((a, b) => xs[b] - xs[a]);
  return { order: order.map((k) => race.runners[k].no), xs, toGo: D - lead, leadX: lead };
}

export default function Viewer({ race, skew = 0, live = false, onDone, height = 'min(56vw, 62vh)', follow = null, mine = [] }) {
  const canvas = useRef(null), viewer = useRef(null), raf = useRef(0), clock = useRef({ t: -6, playing: false, rate: 1, last: 0 });
  const [hud, setHud] = useState({ order: [], toGo: race.distance, t: -6 });
  const [cam, setCam] = useState('auto');
  const [mode3d, setMode3d] = useState(loadQ() !== '2d');
  const [quality, setQuality] = useState(loadQ());
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [caption, setCaption] = useState(null);
  const [ended, setEnded] = useState(false);
  const [photo, setPhoto] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [full, setFull] = useState(false);
  const [sound, setSound] = useState(false);
  const runners = useRef(new Map(race.runners.map((r) => [r.no, r])));
  const mineKey = mine.slice().sort((a, b) => a - b).join(',');
  const mineRef = useRef(mine); mineRef.current = mine;
  const [mineIdx, setMineIdx] = useState(0);
  const followNo = follow ?? (mine.length ? mine[mineIdx % mine.length] : null);
  // the persistent element the whole viewer lives in: moving it between the page and full screen
  // keeps the 3D canvas (and its WebGL context) alive instead of re-creating it
  const host = useRef(null);
  if (!host.current && typeof document !== 'undefined') { host.current = document.createElement('div'); host.current.className = 'h-full w-full'; }
  const slot = useRef(null);
  const [portrait, setPortrait] = useState(() => typeof window !== 'undefined' && window.innerHeight > window.innerWidth);
  useEffect(() => { const f = () => setPortrait(window.innerHeight > window.innerWidth); window.addEventListener('resize', f); return () => window.removeEventListener('resize', f); }, []);
  const tallFull = full && portrait;
  const finishT = race.result ? race.result.winTime : null;
  const duration = race.trace ? race.trace.frames.length * race.trace.every : 0;
  const lastLeader = useRef({ no: null, at: 0 });

  const cap = (text, ms = 2600) => { setCaption({ text, k: Date.now() }); clearTimeout(cap.t); cap.t = setTimeout(() => setCaption(null), ms); };
  const onEvent = useCallback((key, d) => {
    const nm = (no) => runners.current.get(no)?.name;
    if (key === 'orders') { cap("They're under starters' orders…"); rcAudio.say('orders'); }
    if (key === 'off') { cap("And they're off!"); rcAudio.sfx('gates'); rcAudio.sfx('bell', { gain: 0.6 }); rcAudio.say('off', { urgent: true }); }
    if (key === 'leader') {
      const now = performance.now();
      if (lastLeader.current.no !== d.no && now - lastLeader.current.at > 5000) { lastLeader.current = { no: d.no, at: now }; cap(`${d.name} takes it up`); rcAudio.say([rcAudio.nameLine(runners.current.get(d.no)?.horseId), 'leads'], { maxWait: 1.5 }); }
    }
    if (key === 'halfway') { cap(`Halfway: ${d.leader.name} leads`); rcAudio.say(['halfway', rcAudio.nameLine(d.leader.horseId)], { maxWait: 2 }); }
    if (key === '2f') { cap('Two furlongs to run!'); rcAudio.say('2f', { maxWait: 2 }); rcAudio.sfx('cheer1', { gain: 0.7 }); }
    if (key === '1f') { cap('Inside the final furlong!'); rcAudio.say('1f', { urgent: true }); }
    if (key === 'finish') {
      const w = race.result?.positions?.[0];
      if (race.result?.photo) { cap('Photo finish!', 3500); rcAudio.say('photo', { urgent: true }); rcAudio.sfx('photo'); rcAudio.sfx('gasp', { gain: 0.8 }); }
      else if (w) { cap(`${nm(w.no)} wins it!`, 3500); rcAudio.say([rcAudio.nameLine(runners.current.get(w.no)?.horseId), 'wins'], { urgent: true }); rcAudio.sfx('cheer2'); }
    }
  }, [race]);

  useEffect(() => { const go = () => rcAudio.preloadRace(race); window.addEventListener('pointerdown', go, { once: true }); return () => window.removeEventListener('pointerdown', go); }, [race.id]); // eslint-disable-line react-hooks/exhaustive-deps
  // build the viewer
  useEffect(() => {
    if (!mode3d) { setReady(true); return undefined; }
    let alive = true;
    (async () => {
      try {
        const { createViewer } = await import('./engine3d.js');
        if (!alive) return;
        const v = await createViewer(canvas.current, { quality: quality === 'auto' ? 'auto' : quality, onEvent });
        if (!alive) { v.dispose(); return; }
        viewer.current = v; v.load(race); v.setMine?.(mineRef.current); v.setCamera(cam, followNo); setReady(true); window.__rcViewer = v; window.__rcClock = clock.current;
      } catch (e) { console.warn('3D unavailable', e); if (alive) { setFailed(String(e?.message || e).slice(0, 120)); setMode3d(false); setReady(true); } }
    })();
    return () => { alive = false; viewer.current?.dispose(); viewer.current = null; };
  }, [race.id, race.trace ? 1 : 0, mode3d, quality]); // eslint-disable-line react-hooks/exhaustive-deps

  // the clock: live races follow the server; replays run on their own
  useEffect(() => {
    if (!ready) return undefined;
    const c = clock.current;
    if (race.trace) {
      if (live) { c.t = (Date.now() + skew - race.off) / 1000; c.playing = true; }
      else { c.t = race.kind === 'quick' ? -6 : duration; c.playing = race.kind === 'quick'; }
    } else { c.t = -60; c.playing = true; }
    setPlaying(c.playing); setEnded(false);
    if (race.trace && c.playing) rcAudio.startRace();
    c.last = performance.now();
    const tick = (now) => {
      const dt = Math.min(0.1, (now - c.last) / 1000); c.last = now;
      if (c.playing) c.t += dt * c.rate;
      if (!race.trace && c.t > -6.2) c.t = -60; // preview: horses in the stalls
      if (race.trace && c.t >= duration) { c.t = duration; if (c.playing) { c.playing = false; setPlaying(false); setEnded(true); rcAudio.stopRace(); onDone?.(); if (race.result?.photo && viewer.current) setPhoto(viewer.current.photoFinish(finishT)); } }
      let st;
      if (viewer.current) st = viewer.current.setTime(c.t);
      else if (!mode3d && canvas.current) st = draw2D(canvas.current, race, c.t, mineRef.current);
      if (st && Math.floor(now / 120) !== Math.floor((now - dt * 1000) / 120)) {
        setHud({ order: st.order, toGo: Math.max(0, st.toGo), t: c.t });
        if (race.trace && c.playing) rcAudio.updateRace({ excite: c.t > 0 ? Math.max(0, 1 - st.toGo / 700) : 0, pace: c.t > 0 && st.toGo > -60 ? 1 : c.t > 0 ? 0.3 : 0, near: 0.8 });
      }
      if (!mode3d && st && race.trace && c.t > 0) {
        // the 2D view still announces the race
        const evs = [['off', c.t > 0], ['2f', st.toGo < 402], ['1f', st.toGo < 201], ['finish', st.toGo <= 0]];
        for (const [k, cond] of evs) if (cond && !draw2D[k + race.id]) { draw2D[k + race.id] = true; onEvent(k, { leader: runners.current.get(st.order[0]) }); }
      }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf.current); rcAudio.stopRace(); };
  }, [ready, race.id, live, mode3d]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { const r = () => viewer.current?.resize(); window.addEventListener('resize', r); return () => window.removeEventListener('resize', r); }, []);
  useEffect(() => { viewer.current?.setMine?.(mine); }, [mineKey, ready]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { viewer.current?.setCamera(cam, followNo); }, [followNo]); // eslint-disable-line react-hooks/exhaustive-deps
  // full screen: move the persistent element (never remount it) and ask the browser for real full screen
  useLayoutEffect(() => {
    const el = host.current; if (!el) return undefined;
    if (full) {
      document.body.appendChild(el);
      el.className = 'fixed inset-0 z-[70] flex flex-col justify-center bg-black';
      const lock = document.documentElement.style.overflow; document.documentElement.style.overflow = 'hidden';
      try { const req = el.requestFullscreen || el.webkitRequestFullscreen; const pr = req?.call(el); pr?.then?.(() => screen.orientation?.lock?.('landscape').catch(() => {})).catch?.(() => {}); } catch { /* not supported (iPhone): the fixed overlay is used */ }
      const onFs = () => { if (!(document.fullscreenElement || document.webkitFullscreenElement)) setFull(false); };
      document.addEventListener('fullscreenchange', onFs); document.addEventListener('webkitfullscreenchange', onFs);
      return () => {
        document.removeEventListener('fullscreenchange', onFs); document.removeEventListener('webkitfullscreenchange', onFs);
        document.documentElement.style.overflow = lock;
        try { if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen)?.call(document)?.catch?.(() => {}); } catch { /* */ }
      };
    }
    el.className = 'h-full w-full';
    slot.current?.appendChild(el);
    return undefined;
  }, [full]);
  useEffect(() => { const t = setTimeout(() => viewer.current?.resize(), 60); viewer.current?.resize(); return () => clearTimeout(t); }, [full]);
  useEffect(() => () => { host.current?.remove(); }, []);

  const setCamera = (m) => { setCam(m); viewer.current?.setCamera(m, followNo); rcAudio.unlock(); };
  const replay = (from = -6) => { const c = clock.current; c.t = from; c.playing = true; c.rate = c.rate || 1; setPlaying(true); setEnded(false); setPhoto(null); viewer.current?.state?.events.clear(); rcAudio.unlock(); rcAudio.startRace(); };
  const toggle = () => { const c = clock.current; if (c.t >= duration) return replay(); c.playing = !c.playing; setPlaying(c.playing); rcAudio.unlock(); if (c.playing) rcAudio.startRace(); else rcAudio.stopRace(); };
  const setQ = (q) => { try { localStorage.setItem(QKEY, q); } catch { /* */ } setQuality(q); setMode3d(q !== '2d'); setReady(false); };
  const lengthsToGo = hud.toGo;
  const leaderRows = hud.order.slice(0, 6).map((no) => runners.current.get(no)).filter(Boolean);

  const body = (
    <div className={`relative w-full shrink-0 overflow-hidden bg-black ${full ? '' : 'rounded-2xl border border-rc-gold/25'} ${tallFull ? '' : 'h-full'}`} style={tallFull ? { height: 'min(66vw, 60vh)' } : undefined}>
      <canvas key={mode3d ? 'gl' : '2d'} ref={canvas} className="absolute inset-0 h-full w-full" />
      {!ready && <div className="absolute inset-0 flex items-center justify-center text-sm text-rc-cream/70"><span className="rc-spinner mr-2" />Loading the course…</div>}
      {/* running order */}
      {race.trace && hud.t > 0 && (
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center gap-1 bg-gradient-to-b from-black/75 to-transparent px-2 pb-5 pt-1.5">
          <span className="rounded bg-red-600 px-1.5 text-[10px] font-extrabold uppercase text-white">{live ? 'Live' : 'Replay'}</span>
          <div className="scrollbar-none flex min-w-0 flex-1 gap-1 overflow-hidden">
            {leaderRows.map((r, i) => (
              <span key={r.no} className={`flex shrink-0 items-center gap-0.5 rounded px-1 py-0.5 text-[11px] font-bold text-white ${mine.includes(r.no) ? 'bg-rc-gold/30 ring-2 ring-rc-gold' : 'bg-black/55'}`}>
                <span className="text-rc-gold">{i + 1}</span><Silks silks={r.silks} size={14} />{r.no}<span className="hidden max-w-[7rem] truncate font-semibold text-white/80 sm:inline">&nbsp;{r.name}</span>
              </span>
            ))}
          </div>
          <span className="shrink-0 rounded bg-black/60 px-1.5 font-cond text-xs font-bold tabular-nums text-white">{lengthsToGo > 0 ? `${Math.round(lengthsToGo)}m` : 'Finished'} · {Math.max(0, hud.t).toFixed(1)}s</span>
        </div>
      )}
      {/* my horses: where they are right now */}
      {mine.length > 0 && hud.order.length > 0 && race.trace && hud.t > 0 && (
        <div className="pointer-events-auto absolute left-2 top-9 flex flex-col gap-1">
          {mine.map((no) => { const r = runners.current.get(no); const pos = hud.order.indexOf(no) + 1; if (!r || !pos) return null; return (
            <button type="button" key={no} onClick={() => { setMineIdx(mine.indexOf(no)); setCamera('mine'); }} className={`flex items-center gap-1.5 rounded-lg border px-1.5 py-0.5 text-left text-[11px] font-bold text-white shadow ${followNo === no && cam === 'mine' ? 'border-rc-gold bg-rc-gold/35' : 'border-rc-gold/60 bg-black/65'}`} aria-label={`Watch ${r.name}`}>
              <span className="text-rc-gold">★</span><Silks silks={r.silks} size={14} /><span className="max-w-[7.5rem] truncate">{r.no}. {r.name}</span><span className="rounded bg-rc-gold px-1 font-cond text-rc-ink">{ordinal(pos)}</span>
            </button>
          ); })}
        </div>
      )}
      {!race.trace && ready && <div className="pointer-events-none absolute inset-x-0 top-2 text-center"><span className="rounded-full bg-black/60 px-3 py-1 text-xs font-bold text-rc-cream">In the stalls · {race.courseName}</span></div>}
      {/* commentary */}
      {caption && <div key={caption.k} className="rc-caption pointer-events-none absolute inset-x-0 bottom-14 text-center"><span className="rounded-lg bg-black/70 px-3 py-1.5 font-serif text-base font-bold italic text-white sm:text-xl">{caption.text}</span></div>}
      {/* photo finish */}
      {photo && ended && (
        <div className="absolute right-2 top-10 w-[46%] max-w-[300px] overflow-hidden rounded-lg border-2 border-white bg-black shadow-xl">
          <div className="bg-white px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-widest text-black">Photo finish</div>
          <div className="relative"><img src={photo} alt="Photo finish" className="w-full grayscale contrast-125" /><div className="absolute inset-y-0 left-1/2 w-px bg-red-500" /></div>
        </div>
      )}
      {ended && race.result && (
        <div className="rc-pop absolute inset-x-2 bottom-14 mx-auto max-w-md rounded-xl border border-rc-gold/50 bg-rc-ink/90 p-3 text-center">
          <div className="text-[10px] font-extrabold uppercase tracking-[.3em] text-rc-gold">Winner</div>
          {(() => { const w = runners.current.get(race.result.positions[0].no); return <div className="flex items-center justify-center gap-2 font-serif text-xl font-bold text-white"><Silks silks={w.silks} size={28} />{w.no}. {w.name}</div>; })()}
          <div className="mt-0.5 text-xs text-rc-cream/70">{race.result.positions.slice(1, 4).map((p) => `${p.pos}. ${runners.current.get(p.no)?.name} (${p.margin})`).join(' · ')}</div>
        </div>
      )}
      {/* controls */}
      <div className="absolute inset-x-0 bottom-0 flex items-center gap-1 bg-gradient-to-t from-black/85 to-transparent px-2 pb-2 pt-6">
        {race.trace && !live && <button type="button" onClick={toggle} className="rc-ctl" aria-label={playing ? 'Pause' : 'Play'}>{playing ? Ico.pause : Ico.play}</button>}
        {race.trace && !live && <button type="button" onClick={() => replay(-6)} className="rc-ctl">Replay</button>}
        {race.trace && !live && <button type="button" onClick={() => replay(Math.max(0, finishT - 14))} className="rc-ctl hidden sm:inline-flex">Final furlong</button>}
        {race.trace && !live && <button type="button" onClick={() => { clock.current.rate = clock.current.rate === 1 ? 2 : clock.current.rate === 2 ? 0.5 : 1; setHud((h) => ({ ...h })); }} className="rc-ctl">{clock.current.rate}x</button>}
        <select value={cam} onChange={(e) => setCamera(e.target.value)} className="rc-ctl min-w-0 max-w-[8.5rem] appearance-none pr-2" aria-label="Camera" disabled={!mode3d}>
          {CAMS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
        </select>
        <div className="ml-auto flex items-center gap-1">
          <select value={quality} onChange={(e) => setQ(e.target.value)} className="rc-ctl appearance-none" aria-label="Graphics quality">
            <option value="auto">Auto</option><option value="high">HD</option><option value="low">Lite</option><option value="2d">2D</option>
          </select>
          <button type="button" onClick={() => { setSound((v) => !v); rcAudio.unlock(); }} className="rc-ctl" aria-label="Sound settings">{Ico.sound}</button>
          <button type="button" onClick={() => setFull((v) => !v)} className="rc-ctl" aria-label={full ? 'Exit full screen' : 'Full screen'}>{full ? Ico.close : Ico.full}</button>
        </div>
      </div>
      {sound && <div className="absolute bottom-12 right-2 z-10 w-64"><SoundPanel onClose={() => setSound(false)} /></div>}
      {failed && <div className="absolute left-2 top-10 rounded bg-black/70 px-2 py-1 text-[11px] text-rc-cream/80">3D couldn't start here, so the race is shown in 2D{typeof failed === 'string' ? ` (${failed})` : ''}.</div>}
    </div>
  );
  return (
    <>
      <div ref={slot} className="relative" style={{ height }} />
      {host.current ? createPortal(<>{tallFull && <div className="pointer-events-none px-3 pb-3 text-center text-[11px] font-semibold text-rc-cream/60">Turn your phone sideways for a bigger picture</div>}{body}{tallFull && race.trace && (
        <div className="mt-2 max-h-[34vh] overflow-y-auto px-3 text-sm" aria-label="Running order">
          <div className="mb-1 text-[10px] font-extrabold uppercase tracking-[.25em] text-rc-gold">Running order</div>
          {(hud.order.length ? hud.order : race.runners.map((r) => r.no)).map((no, i) => { const r = runners.current.get(no); if (!r) return null; const me = mine.includes(no); return (
            <div key={no} className={`mb-1 flex items-center gap-2 rounded-lg px-2 py-1 ${me ? 'bg-rc-gold/20 ring-1 ring-rc-gold' : 'bg-white/5'}`}>
              <span className="w-7 font-cond font-bold text-rc-gold">{hud.t > 0 ? ordinal(i + 1) : ''}</span><Silks silks={r.silks} size={18} /><span className="min-w-0 flex-1 truncate font-semibold text-white">{r.no}. {r.name}</span>{me && <span className="text-[10px] font-extrabold uppercase text-rc-gold">★ Your bet</span>}
            </div>
          ); })}
        </div>
      )}</>, host.current) : null}
    </>
  );
}
