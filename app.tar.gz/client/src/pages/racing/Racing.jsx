// The Horse Racing lounge: hero, dashboard tabs (Live now, Upcoming, Today, Virtual racing, Results,
// Racecourses, My Bets, Leaderboard), horse profiles, racecourse pages and the live video player.
// Every race here is a fictional virtual race, clearly labelled; nothing pretends to be real racing.
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../../lib/api.js';
import { useApp } from '../../state/AppContext.jsx';
import { Link, navigate, useLocation } from '../../lib/router.jsx';
import { usePolling } from '../../lib/hooks.js';
import { money, signed } from '../../lib/format.js';
import { Empty, ErrorBox, Loading } from '../../components/ui.jsx';
import { Countdown, FormFigures, OddsToggle, PhaseBadge, RaceRow, Silks, Stat, offTime, oddsText, pounds, useOddsFormat } from './common.jsx';
import LiveVideo from './LiveVideo.jsx';
import heroImg from '../../assets/racing/hero.webp';

const RacePage = lazy(() => import('./RacePage.jsx'));
const Viewer = lazy(() => import('./Viewer.jsx'));

const Star = ({ on }) => <svg viewBox="0 0 20 20" className="h-3.5 w-3.5" fill={on ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M10 2.5l2.3 4.8 5.2.7-3.8 3.6.9 5.2L10 14.3 5.4 16.8l.9-5.2L2.5 8l5.2-.7z" /></svg>;
const TABS = [['live', 'Live now'], ['upcoming', 'Upcoming'], ['today', "Today's races"], ['virtual', 'Virtual racing'], ['results', 'Results'], ['courses', 'Racecourses'], ['bets', 'My bets'], ['leaders', 'Leaderboard']];

/** Toasts when a race you have bets on, or a favourite horse, is about to go off. */
function useRaceAlerts(ov) {
  const { toast, user } = useApp();
  const seen = useRef(new Set());
  const [favs, setFavs] = useState(null);
  const [open, setOpen] = useState([]);
  useEffect(() => { if (user) { api.get('/api/racing/favourites').then(setFavs).catch(() => {}); api.get('/api/racing/bets?status=open').then((d) => setOpen(d.bets)).catch(() => {}); } }, [user?.id, ov?.next?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!ov) return undefined;
    const id = setInterval(() => {
      const t = Date.now() + (ov.now - ov.fetchedAt);
      for (const r of ov.upcoming || []) {
        const left = r.off - t;
        if (left > 0 && left < 60000 && !seen.current.has(r.id)) {
          const mine = open.some((b) => b.race?.id === r.id);
          const fav = favs?.courses?.includes(r.course);
          if (mine || fav) { seen.current.add(r.id); toast(`${mine ? 'Your race' : 'Favourite course'}: ${r.courseName} ${offTime(r.off)} goes off in under a minute`, 'info'); }
        }
      }
    }, 5000);
    return () => clearInterval(id);
  }, [ov, open, favs, toast]);
}

function Hero({ ov, skew }) {
  const next = ov?.next, live = ov?.live?.[0];
  const featured = ov?.upcoming?.find((r) => r.type === 'Championship') || next;
  return (
    <section className="rc-hero relative overflow-hidden rounded-3xl border border-rc-gold/25">
      <img src={heroImg} alt="" className="absolute inset-0 h-full w-full object-cover object-[70%_40%]" />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(3,17,11,.94)_0%,rgba(3,17,11,.75)_45%,rgba(3,17,11,.15)_100%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(3,17,11,.9),transparent_55%)]" />
      <div className="relative flex min-h-[340px] flex-col justify-end gap-3 p-4 sm:min-h-[400px] sm:p-7">
        <div className="flex flex-wrap items-center gap-2">
          {live ? <Link to={`/racing/race/${live.id}`} className="inline-flex items-center gap-1.5 rounded-full bg-red-600 px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wider text-white"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />Live now · {live.courseName}</Link>
            : <span className="rounded-full bg-black/50 px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wider text-rc-cream/80 ring-1 ring-white/15">Next off in {next ? <Countdown to={next.off} skew={skew} /> : '…'}</span>}
          <span className="rounded-full bg-rc-gold/15 px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wider text-rc-gold ring-1 ring-rc-gold/40">Virtual racing · fictional horses</span>
        </div>
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[.35em] text-rc-gold">VirtualBet</div>
          <h1 className="font-serif text-5xl font-extrabold leading-[0.95] tracking-tight text-white sm:text-7xl">Horse Racing</h1>
          <p className="mt-2 max-w-lg text-sm text-rc-cream/80 sm:text-base">A race every three minutes across eight virtual racecourses, or run your own whenever you like. Real-time 3D racing, fixed odds and every bet type, with virtual credits only.</p>
        </div>
        {featured && (
          <Link to={`/racing/race/${featured.id}`} className="flex max-w-xl items-center gap-3 rounded-2xl border border-rc-gold/30 bg-black/45 p-3 backdrop-blur transition-colors hover:border-rc-gold/70">
            <div className="text-center leading-tight"><div className="font-cond text-2xl font-bold text-white">{offTime(featured.off)}</div><div className="text-[10px] uppercase tracking-wider text-rc-cream/60">{featured.courseName}</div></div>
            <div className="min-w-0 flex-1"><div className="text-[10px] font-extrabold uppercase tracking-[.2em] text-rc-gold">{featured.type === 'Championship' ? 'Feature race' : 'Next race'}</div><div className="truncate font-serif text-lg font-bold text-white">{featured.name}</div><div className="text-[11px] text-rc-cream/70">{featured.distanceLabel} · {featured.goingName} · {featured.field} runners · fav {featured.top?.[0]?.name} {featured.top?.[0]?.odds}</div></div>
            <Countdown to={featured.off} skew={skew} className="font-cond text-xl font-bold text-emerald-300" />
          </Link>
        )}
        <div className="flex flex-wrap gap-2">
          <Link to="/racing?tab=live" className="rc-gold-btn inline-flex h-11 items-center rounded-full px-5 text-sm font-extrabold">Watch live</Link>
          <Link to="/racing?tab=virtual" className="inline-flex h-11 items-center rounded-full bg-white/10 px-5 text-sm font-extrabold text-white ring-1 ring-white/25 backdrop-blur hover:bg-white/15">Run a race now</Link>
        </div>
      </div>
    </section>
  );
}

function Filters({ courses, course, setCourse, search, setSearch }) {
  return (
    <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
      <div className="scrollbar-none -mx-1 flex flex-1 gap-1 overflow-x-auto px-1">
        <button type="button" onClick={() => setCourse(null)} className={`rc-chip ${!course ? 'rc-chip-on' : ''}`}>All courses</button>
        {courses.map((c) => <button key={c.id} type="button" onClick={() => setCourse(c.id === course ? null : c.id)} className={`rc-chip ${course === c.id ? 'rc-chip-on' : ''}`}>{c.name}</button>)}
      </div>
      <label className="relative sm:w-56"><span className="sr-only">Search horses</span>
        <svg viewBox="0 0 20 20" className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-rc-cream/50" fill="currentColor"><path d="M8.5 3a5.5 5.5 0 014.38 8.82l3.65 3.65a1 1 0 01-1.42 1.42l-3.65-3.65A5.5 5.5 0 118.5 3zm0 2a3.5 3.5 0 100 7 3.5 3.5 0 000-7z" /></svg>
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search horses" className="h-10 w-full rounded-full border border-white/15 bg-black/30 pl-8 pr-3 text-sm text-white placeholder:text-rc-cream/40" />
      </label>
    </div>
  );
}

function HorseSearch({ q }) {
  const [res, setRes] = useState(null);
  useEffect(() => { const h = setTimeout(() => api.get(`/api/racing/horses?q=${encodeURIComponent(q)}`).then((d) => setRes(d.horses)).catch(() => {}), 200); return () => clearTimeout(h); }, [q]);
  if (!res) return <Loading />;
  if (!res.length) return <div className="rounded-xl bg-rc-panel p-4 text-sm text-rc-cream/60">No horses match "{q}".</div>;
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {res.map((h) => (
        <Link key={h.id} to={`/racing/horse/${h.id}`} className="flex items-center gap-3 rounded-xl border border-white/[0.07] bg-rc-panel p-2.5 hover:border-rc-gold/40">
          <Silks silks={h.silks} size={34} />
          <div className="min-w-0 flex-1"><div className="truncate font-semibold text-white">{h.name}</div><div className="text-[11px] text-rc-cream/60">{h.age}yo · {h.trainer} · Rtg {h.rating}</div></div>
          <div className="text-right text-[11px] text-rc-cream/70">{h.wins}/{h.runs} wins<br /><FormFigures form={h.form} /></div>
        </Link>
      ))}
    </div>
  );
}

function QuickRaces({ ov }) {
  const { user, toast } = useApp();
  const [format, setFormat] = useState('sprint');
  const [field, setField] = useState(8);
  const [course, setCourse] = useState('');
  const [busy, setBusy] = useState(false);
  const f = ov.formats.find((x) => x.id === format);
  useEffect(() => { if (f && !f.fields.includes(field)) setField(f.fields[0]); }, [format]); // eslint-disable-line react-hooks/exhaustive-deps
  const make = async () => {
    if (!user) return navigate('/login');
    setBusy(true);
    try { const r = await api.post('/api/racing/quick', { format, field, course: course || undefined }); navigate(`/racing/race/${r.id}`); }
    catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-rc-gold/25 bg-[linear-gradient(135deg,rgba(214,178,94,.12),rgba(11,35,26,.8))] p-4">
        <h2 className="font-serif text-2xl font-bold text-white">Run a virtual race now</h2>
        <p className="mt-1 text-sm text-rc-cream/75">Choose a race type and field size. You get a full racecard with prices, place your bets, then start it whenever you like. The race is simulated on the server from each horse's speed, stamina, acceleration, finishing kick and temperament.</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <label className="text-xs font-bold uppercase tracking-wider text-rc-cream/60">Race type
            <select value={format} onChange={(e) => setFormat(e.target.value)} className="rc-select mt-1">{ov.formats.map((x) => <option key={x.id} value={x.id}>{x.name} ({x.furlongs.map((d) => `${d}f`).join('/')})</option>)}</select>
          </label>
          <label className="text-xs font-bold uppercase tracking-wider text-rc-cream/60">Runners
            <div className="mt-1 flex gap-1">{f?.fields.map((n) => <button key={n} type="button" onClick={() => setField(n)} className={`rc-chip flex-1 justify-center ${field === n ? 'rc-chip-on' : ''}`}>{n}</button>)}</div>
          </label>
          <label className="text-xs font-bold uppercase tracking-wider text-rc-cream/60">Racecourse
            <select value={course} onChange={(e) => setCourse(e.target.value)} className="rc-select mt-1"><option value="">Any course</option>{ov.courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          </label>
        </div>
        <button type="button" onClick={make} disabled={busy} className="rc-gold-btn mt-3 h-12 w-full rounded-xl text-base font-extrabold sm:w-auto sm:px-8">{busy ? 'Drawing the field…' : 'Create racecard'}</button>
      </div>
      {ov.quick?.length > 0 && <div className="space-y-2"><h3 className="text-xs font-bold uppercase tracking-[.2em] text-rc-cream/60">Your recent virtual races</h3>{ov.quick.map((r) => <RaceRow key={r.id} r={r} />)}</div>}
    </div>
  );
}

function MyBets() {
  const { user } = useApp();
  const [filter, setFilter] = useState('open');
  const [fmt] = useOddsFormat();
  const { data, error, reload } = usePolling(user ? `/api/racing/bets?status=${filter}` : null, 8000, [filter]);
  const stats = usePolling(user ? '/api/racing/stats' : null, 15000);
  if (!user) return <div className="rounded-2xl bg-rc-panel p-6 text-center text-sm text-rc-cream/70"><Link to="/login" className="font-bold text-rc-gold">Log in</Link> to see your racing bets.</div>;
  const s = stats.data;
  return (
    <div className="space-y-3">
      {s && (
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <Stat label="Settled bets" value={s.bets} sub={`${s.open} open (${money(s.openStake)})`} />
          <Stat label="Staked" value={money(s.staked)} />
          <Stat label="Returned" value={money(s.returned)} />
          <Stat label="Profit / loss" value={signed(s.profit)} tone={s.profit > 0 ? 'pos' : s.profit < 0 ? 'neg' : null} sub={`Win rate ${(s.winRate * 100).toFixed(0)}% · best ${money(s.best)}`} />
        </div>
      )}
      {s?.favouriteHorses?.length > 0 && <div className="flex flex-wrap items-center gap-1.5 text-xs text-rc-cream/70"><span className="font-bold uppercase tracking-wider text-rc-cream/50">Your favourite horses:</span>{s.favouriteHorses.map((h) => <Link key={h.id} to={`/racing/horse/${h.id}`} className="rc-chip">{h.name} · {h.n}</Link>)}</div>}
      <div className="flex gap-1">{[['open', 'Open'], ['settled', 'Settled'], ['all', 'All']].map(([k, l]) => <button key={k} type="button" onClick={() => setFilter(k)} className={`rc-chip ${filter === k ? 'rc-chip-on' : ''}`}>{l}</button>)}</div>
      {error && <ErrorBox error={error} onRetry={reload} />}
      {!data ? <Loading /> : !data.bets.length ? <div className="rounded-2xl bg-rc-panel p-6"><Empty title={filter === 'open' ? 'No open bets' : 'No settled bets yet'}>Pick a race from Upcoming or run a virtual race.</Empty></div> : (
        <ul className="space-y-2">
          {data.bets.map((b) => (
            <li key={b.id}>
              <Link to={`/racing/race/${b.race?.id}`} className="block rounded-xl border border-white/[0.07] bg-rc-panel p-3 hover:border-rc-gold/40">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-[10px] font-extrabold uppercase tracking-wider text-rc-gold">{b.typeName} · {b.ref}</div>
                    <div className="truncate font-semibold text-white">{b.names.join(b.type === 'forecast' || b.type === 'tricast' ? ' → ' : ', ')}</div>
                    <div className="truncate text-[11px] text-rc-cream/60">{b.race?.courseName} {offTime(b.race?.off)} · {b.race?.name}</div>
                    <div className="text-[11px] text-rc-cream/60">Stake {money(b.total)} · {b.price.win ? `Win ${oddsText(b.price.win, fmt)}` : ''}{b.price.place ? ` Place ${b.price.place.dec.toFixed(2)}` : ''}{b.price.lines ? b.price.lines.map((l) => oddsText(l.dec, fmt)).join(' / ') : ''}</div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className={`rounded px-1.5 py-0.5 text-[10px] font-extrabold uppercase ${b.status === 'won' || b.status === 'placed' ? 'bg-emerald-500/20 text-emerald-300' : b.status === 'lost' ? 'bg-red-500/15 text-red-300' : 'bg-rc-gold/15 text-rc-gold'}`}>{b.status}</div>
                    <div className="mt-1 font-cond text-base font-bold text-white">{b.status === 'open' || b.status === 'running' ? money(b.potential) : money(b.returns)}</div>
                    <div className="text-[10px] text-rc-cream/50">{b.status === 'open' || b.status === 'running' ? 'potential' : 'returned'}</div>
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Leaderboard() {
  const [period, setPeriod] = useState('week');
  const { data } = usePolling(`/api/racing/leaderboard?period=${period}`, 30000, [period]);
  const boards = [['profit', 'Highest virtual profit', (r) => signed(r.profit)], ['winners', 'Most successful (winning bets)', (r) => `${r.winners} winners`], ['best', 'Biggest single win', (r) => money(r.best)], ['winRate', 'Best win percentage (10+ bets)', (r) => `${(r.winRate * 100).toFixed(1)}%`], ['active', 'Most active', (r) => `${r.bets} bets`]];
  return (
    <div className="space-y-3">
      <div className="flex gap-1">{[['week', 'This week'], ['month', 'This month'], ['all', 'All time']].map(([k, l]) => <button key={k} type="button" onClick={() => setPeriod(k)} className={`rc-chip ${period === k ? 'rc-chip-on' : ''}`}>{l}</button>)}</div>
      {!data ? <Loading /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {boards.map(([k, title, val]) => (
            <section key={k} className="rounded-2xl border border-white/10 bg-rc-panel p-3">
              <h3 className="mb-2 font-serif text-base font-bold text-white">{title}</h3>
              {!data[k].length ? <p className="text-xs text-rc-cream/50">No settled bets in this period yet.</p> : (
                <ol className="space-y-1 text-sm">{data[k].slice(0, 10).map((r, i) => <li key={r.name} className="flex items-center justify-between gap-2"><span className="flex min-w-0 items-center gap-2"><span className={`w-5 text-center font-cond font-bold ${i < 3 ? 'text-rc-gold' : 'text-rc-cream/50'}`}>{i + 1}</span><span className="truncate text-white">{r.name}</span></span><span className="font-cond font-bold tabular-nums text-rc-cream">{val(r)}</span></li>)}</ol>
              )}
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

function Courses({ ov }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {ov.courses.map((c) => (
        <Link key={c.id} to={`/racing/course/${c.id}`} className="group overflow-hidden rounded-2xl border border-white/10 bg-rc-panel hover:border-rc-gold/50">
          <CourseArt id={c.id} />
          <div className="p-3">
            <div className="font-serif text-lg font-bold text-white">{c.name}</div>
            <div className="text-[11px] uppercase tracking-wider text-rc-cream/50">{c.region} · {c.hand}-handed</div>
            <p className="mt-1 line-clamp-2 text-xs text-rc-cream/70">{c.desc}</p>
            <div className="mt-2 text-[11px] font-bold text-rc-gold">{c.next ? `Next race ${offTime(c.next)}` : 'Racing later today'}</div>
          </div>
        </Link>
      ))}
    </div>
  );
}

/** A drawn vista of each course (sky, hills, stand, rail) in its own colours. */
const COURSE_COL = { ashcombe: ['#7fb2e5', '#3f7d34', '#2e4d3a'], kingsbury: ['#8cb8de', '#4b7f2f', '#3a3a52'], rivermead: ['#9cc3e8', '#3d7a3a', '#1f3b5a'], harrowgate: ['#a6b6c8', '#4f7a3a', '#4a2f2a'], marlow: ['#86b9e8', '#3c8139', '#6b1f2a'], castleton: ['#9bb4cf', '#457a33', '#2a3340'], saltmarsh: ['#7ec2ec', '#5a8a3e', '#1c5d7a'], northbridge: ['#0f1a33', '#2f6a32', '#16161e'] };
export function CourseArt({ id, className = 'h-28 w-full' }) {
  const [sky, grass, roof] = COURSE_COL[id] || COURSE_COL.ashcombe;
  const night = id === 'northbridge';
  return (
    <svg viewBox="0 0 320 120" preserveAspectRatio="xMidYMid slice" className={className} aria-hidden="true">
      <defs><linearGradient id={`sk${id}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={sky} /><stop offset="1" stopColor={night ? '#3a4b72' : '#eef4f8'} /></linearGradient></defs>
      <rect width="320" height="120" fill={`url(#sk${id})`} />
      {night && [20, 70, 140, 210, 260, 300].map((x, i) => <circle key={x} cx={x} cy={12 + (i % 3) * 9} r="1" fill="#fff" />)}
      <path d="M0 70Q60 45 120 64T240 58T320 66V120H0Z" fill={night ? '#1d2c22' : '#7a9a5c'} opacity=".8" />
      {id === 'castleton' && <path d="M230 62V44h6v6h6v-6h6v6h6v-6h6v18Z" fill="#8d877b" />}
      {id === 'saltmarsh' && <rect y="66" width="320" height="8" fill="#3f86b0" />}
      <rect y="76" width="320" height="44" fill={grass} />
      <path d="M0 92H320" stroke="#fff" strokeWidth="2" opacity=".85" /><path d="M0 104H320" stroke="#fff" strokeWidth="1.5" opacity=".6" />
      <rect x="170" y="56" width="120" height="22" fill="#efe9dc" /><path d="M164 56L296 56L290 50L170 50Z" fill={roof} />
      {[...Array(14)].map((_, i) => <rect key={i} x={174 + i * 8} y={62 + (i % 3)} width="4" height="5" fill={['#1f3a5f', '#8c1c13', '#2e5e3a', '#c79b3b'][i % 4]} />)}
      {night && [40, 120, 250].map((x) => <g key={x}><rect x={x} y="30" width="2" height="48" fill="#555" /><rect x={x - 5} y="28" width="12" height="4" fill="#fffbe8" /></g>)}
    </svg>
  );
}

function Dashboard() {
  const { query } = useLocation();
  const tab = query.get('tab') || 'upcoming';
  const { data: ovRaw, error, reload } = usePolling('/api/racing', 8000);
  const ov = useMemo(() => (ovRaw ? { ...ovRaw, fetchedAt: Date.now() } : null), [ovRaw]);
  const skew = ov ? ov.now - ov.fetchedAt : 0;
  const [course, setCourse] = useState(null);
  const [search, setSearch] = useState('');
  useRaceAlerts(ov);
  const filt = (list) => (list || []).filter((r) => !course || r.course === course);
  const go = (t) => navigate(`/racing?tab=${t}`, { replace: true });

  return (
    <div className="space-y-4">
      {tab === 'upcoming' ? <Hero ov={ov} skew={skew} /> : (
        <div className="flex items-end justify-between gap-2 border-b border-rc-gold/20 pb-2">
          <div><div className="text-[10px] font-bold uppercase tracking-[.3em] text-rc-gold">Virtual racing</div><h1 className="font-serif text-3xl font-extrabold text-white">Horse Racing</h1></div>
          {ov?.next && <Link to={`/racing/race/${ov.next.id}`} className="text-right text-xs text-rc-cream/70">Next: <b className="text-white">{offTime(ov.next.off)} {ov.next.courseName}</b><br /><Countdown to={ov.next.off} skew={skew} className="font-cond text-base font-bold text-emerald-300" /></Link>}
        </div>
      )}
      <nav className="scrollbar-none -mx-3 flex gap-1 overflow-x-auto px-3 sm:mx-0 sm:px-0" role="tablist" aria-label="Racing">
        {TABS.map(([k, l]) => <button key={k} type="button" role="tab" aria-selected={tab === k} onClick={() => go(k)} className={`rc-tab ${tab === k ? 'rc-tab-on' : ''}`}>{k === 'live' && ov?.live?.length ? <span className="mr-1 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" /> : null}{l}</button>)}
        <div className="ml-auto hidden shrink-0 items-center sm:flex"><OddsToggle /></div>
      </nav>
      {error && !ov && <ErrorBox error={error} onRetry={reload} />}
      {!ov ? <Loading label="Loading the racing…" /> : (
        <>
          {['upcoming', 'today', 'results'].includes(tab) && <Filters courses={ov.courses} course={course} setCourse={setCourse} search={search} setSearch={setSearch} />}
          {search.trim() && ['upcoming', 'today', 'results'].includes(tab) ? <HorseSearch q={search.trim()} /> : null}
          {!search.trim() && tab === 'upcoming' && (filt(ov.upcoming).length ? <div className="grid grid-cols-1 gap-2 lg:grid-cols-2">{filt(ov.upcoming).map((r) => <RaceRow key={r.id} r={r} skew={skew} />)}</div> : <div className="rounded-2xl bg-rc-panel p-6"><Empty title="No upcoming races here">Try another course.</Empty></div>)}
          {!search.trim() && tab === 'today' && <div className="grid grid-cols-1 gap-2 lg:grid-cols-2">{filt(ov.today).map((r) => <RaceRow key={r.id} r={r} skew={skew} />)}</div>}
          {!search.trim() && tab === 'results' && (filt(ov.results).length ? <div className="grid grid-cols-1 gap-2 lg:grid-cols-2">{filt(ov.results).map((r) => <RaceRow key={r.id} r={r} skew={skew} />)}</div> : <div className="rounded-2xl bg-rc-panel p-6"><Empty title="No results yet">Results appear here as soon as each race has finished.</Empty></div>)}
          {tab === 'live' && <LiveTab ov={ov} skew={skew} />}
          {tab === 'virtual' && <QuickRaces ov={ov} />}
          {tab === 'courses' && <Courses ov={ov} />}
          {tab === 'bets' && <MyBets />}
          {tab === 'leaders' && <Leaderboard />}
        </>
      )}
      <p className="text-center text-[11px] text-rc-cream/40">All racing here is virtual: fictional horses, jockeys, trainers and racecourses, simulated on our server. Prize money is fictional. Virtual credits only, no real money.</p>
    </div>
  );
}

function LiveTab({ ov, skew }) {
  const live = ov.live?.[0];
  const [race, setRace] = useState(null);
  useEffect(() => { if (live) api.get(`/api/racing/races/${live.id}`).then(setRace).catch(() => {}); else setRace(null); }, [live?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="space-y-3">
      <LiveVideo next={ov.next} skew={skew} />
      <section className="space-y-2">
        <div className="flex items-center justify-between"><h2 className="font-serif text-xl font-bold text-white">Virtual racing: live now</h2>{live && <Link to={`/racing/race/${live.id}`} className="text-sm font-bold text-rc-gold">Racecard →</Link>}</div>
        {race?.trace ? (
          <Suspense fallback={<Loading />}><Viewer key={race.id} race={race} skew={skew} live /></Suspense>
        ) : (
          <div className="rounded-2xl border border-white/10 bg-rc-panel p-5 text-center">
            <div className="font-serif text-lg font-bold text-white">Between races</div>
            {ov.next && <p className="mt-1 text-sm text-rc-cream/70">Next: <Link to={`/racing/race/${ov.next.id}`} className="font-bold text-rc-gold">{offTime(ov.next.off)} {ov.next.courseName}</Link> · off in <Countdown to={ov.next.off} skew={skew} className="font-cond font-bold text-emerald-300" /></p>}
          </div>
        )}
      </section>
      <section className="space-y-2"><h3 className="text-xs font-bold uppercase tracking-[.2em] text-rc-cream/60">Coming up</h3>{ov.upcoming.slice(0, 4).map((r) => <RaceRow key={r.id} r={r} skew={skew} />)}</section>
    </div>
  );
}

function HorseProfile({ id }) {
  const { user, toast } = useApp();
  const [h, setH] = useState(null);
  const [img, setImg] = useState(null);
  const [error, setError] = useState(null);
  const load = () => api.get(`/api/racing/horses/${id}`).then(setH).catch(setError);
  useEffect(() => { load(); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!h) return; import('./engine3d.js').then((m) => m.horsePortrait({ coat: h.coat, silks: h.silks })).then(setImg).catch(() => setImg(null)); }, [h?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (error) return <ErrorBox error={error} />;
  if (!h) return <Loading />;
  const fav = async () => { if (!user) return navigate('/login'); try { await api.post('/api/racing/favourites', { kind: 'horse', ref: h.id, on: !h.favourite }); load(); } catch (e) { toast(e.message, 'error'); } };
  const coat = { bay: 'Bay', dbay: 'Dark bay', chestnut: 'Chestnut', grey: 'Grey', black: 'Black', roan: 'Roan' }[h.coat];
  return (
    <div className="space-y-3">
      <Link to="/racing" className="text-sm font-semibold text-rc-gold">← Racing</Link>
      <section className="overflow-hidden rounded-3xl border border-rc-gold/25 bg-rc-panel md:grid md:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <div className="relative aspect-[3/2] bg-[radial-gradient(ellipse_at_center,#1d4a33,#05150f)]">
          {img ? <img src={img} alt={`${h.name}, a ${coat.toLowerCase()} ${h.sex === 'f' || h.sex === 'm' ? 'mare' : 'horse'}`} className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-sm text-rc-cream/50"><span className="rc-spinner mr-2" />Painting the portrait…</div>}
          <div className="absolute left-3 top-3"><Silks silks={h.silks} size={44} /></div>
        </div>
        <div className="space-y-2 p-4">
          <div className="text-[11px] font-bold uppercase tracking-[.25em] text-rc-gold">Virtual racehorse</div>
          <div className="flex items-start justify-between gap-2"><h1 className="font-serif text-3xl font-bold text-white">{h.name}</h1><button type="button" onClick={fav} className={`rc-chip shrink-0 ${h.favourite ? 'rc-chip-on' : ''}`} aria-pressed={h.favourite}><Star on={h.favourite} />Favourite</button></div>
          <div className="text-sm text-rc-cream/75">{h.age}-year-old {coat.toLowerCase()} {({ g: 'gelding', c: 'colt', f: 'filly', m: 'mare', h: 'horse' })[h.sex]} · by {h.sire} out of {h.dam}</div>
          <div className="text-sm text-rc-cream/75">Trainer <b className="text-white">{h.trainer}</b> · Owner {h.owner}</div>
          <div className="grid grid-cols-3 gap-2 pt-1">
            <Stat label="Runs" value={h.runs} /><Stat label="Wins" value={h.wins} sub={h.runs ? `${Math.round((h.wins / h.runs) * 100)}%` : null} /><Stat label="Places" value={h.places} />
          </div>
          <div className="grid grid-cols-2 gap-2"><Stat label="Earnings (fictional)" value={pounds(h.earnings)} /><Stat label="Rating" value={h.rating} sub={`Form ${h.form ? h.form.slice(0, 6).split('').reverse().join('') : '–'}`} /></div>
          {h.next && <Link to={`/racing/race/${h.next.id}`} className="block rounded-xl bg-rc-gold/15 p-2 text-sm text-rc-cream ring-1 ring-rc-gold/40">Next: <b>{offTime(h.next.off)} {h.next.courseName}</b> · {h.next.name}</Link>}
        </div>
      </section>
      <section className="grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-rc-panel p-3">
          <h2 className="mb-2 font-serif text-lg font-bold text-white">Ratings</h2>
          {[['speed', 'Speed'], ['stamina', 'Stamina'], ['accel', 'Acceleration'], ['finish', 'Finishing'], ['temperament', 'Temperament']].map(([k, l]) => (
            <div key={k} className="mb-1.5 flex items-center gap-2 text-sm"><span className="w-28 text-rc-cream/70">{l}</span><div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-rc-gold to-rc-gold2" style={{ width: `${h.ratings[k]}%` }} /></div><b className="w-7 text-right tabular-nums text-white">{h.ratings[k]}</b></div>
          ))}
          <p className="mt-1 text-xs text-rc-cream/60">Running style: <b className="text-white">{h.style}</b>. Prefers {({ firm: 'firm', gf: 'good to firm', good: 'good', gs: 'good to soft', soft: 'soft', heavy: 'heavy' })[h.goingPref]} ground.</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-rc-panel p-3">
          <h2 className="mb-2 font-serif text-lg font-bold text-white">Jockeys</h2>
          {h.jockeys.length ? <ul className="space-y-1 text-sm">{h.jockeys.map((j) => <li key={j.name} className="flex justify-between"><span className="text-white">{j.name}</span><span className="text-rc-cream/60">{j.n} ride{j.n > 1 ? 's' : ''}</span></li>)}</ul> : <p className="text-sm text-rc-cream/50">No runs yet.</p>}
        </div>
      </section>
      <section className="overflow-hidden rounded-2xl border border-white/10 bg-rc-panel">
        <h2 className="border-b border-white/10 px-3 py-2 font-serif text-lg font-bold text-white">Race history</h2>
        {!h.runsList.length ? <p className="p-3 text-sm text-rc-cream/50">This horse hasn't run in a timetable race yet.</p> : (
          <div className="overflow-x-auto"><table className="w-full min-w-[560px] text-sm">
            <thead className="text-left text-[10px] uppercase tracking-wider text-rc-cream/50"><tr><th className="px-3 py-1.5">Date</th><th>Course</th><th>Race</th><th>Dist</th><th>Going</th><th>Pos</th><th>SP</th><th className="px-3">Jockey</th></tr></thead>
            <tbody className="divide-y divide-white/5">{h.runsList.map((r) => <tr key={r.raceId}><td className="px-3 py-1.5 text-rc-cream/60">{new Date(r.off).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td><td>{r.course}</td><td className="max-w-[12rem] truncate"><Link to={`/racing/race/${r.raceId}`} className="text-white">{r.race}</Link></td><td>{r.distance}</td><td className="text-rc-cream/70">{r.going}</td><td className={r.pos === 1 ? 'font-bold text-rc-gold' : 'text-white'}>{r.pos}/{r.field}{r.margin ? <span className="text-[10px] text-rc-cream/50"> {r.margin}</span> : ''}</td><td>{r.odds}</td><td className="px-3 text-rc-cream/70">{r.jockey}</td></tr>)}</tbody>
          </table></div>
        )}
      </section>
    </div>
  );
}

function CoursePage({ id }) {
  const { user, toast } = useApp();
  const { data: c, error } = usePolling(`/api/racing/courses/${id}`, 15000, [id]);
  const [fav, setFav] = useState(false);
  useEffect(() => { if (user) api.get('/api/racing/favourites').then((f) => setFav(f.courses.includes(id))).catch(() => {}); }, [user?.id, id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (error) return <ErrorBox error={error} />;
  if (!c) return <Loading />;
  const toggle = async () => { if (!user) return navigate('/login'); try { const f = await api.post('/api/racing/favourites', { kind: 'course', ref: id, on: !fav }); setFav(f.courses.includes(id)); } catch (e) { toast(e.message, 'error'); } };
  return (
    <div className="space-y-3">
      <Link to="/racing?tab=courses" className="text-sm font-semibold text-rc-gold">← Racecourses</Link>
      <section className="overflow-hidden rounded-3xl border border-rc-gold/25 bg-rc-panel">
        <CourseArt id={id} className="h-44 w-full sm:h-56" />
        <div className="p-4">
          <div className="flex items-start justify-between gap-2"><div><div className="text-[11px] font-bold uppercase tracking-[.25em] text-rc-gold">Virtual racecourse · {c.region}</div><h1 className="font-serif text-3xl font-bold text-white">{c.name}</h1></div><button type="button" onClick={toggle} className={`rc-chip ${fav ? 'rc-chip-on' : ''}`} aria-pressed={fav}><Star on={fav} />Favourite</button></div>
          <p className="mt-1 text-sm text-rc-cream/80">{c.desc}</p>
          <div className="mt-2 flex flex-wrap gap-1.5">{[`${c.hand}-handed`, ...c.features].map((f) => <span key={f} className="rc-chip">{f}</span>)}<span className="rc-chip">{c.races} races run</span></div>
        </div>
      </section>
      <div className="grid gap-3 lg:grid-cols-2">
        <section className="space-y-2"><h2 className="font-serif text-lg font-bold text-white">Upcoming here</h2>{c.upcoming.length ? c.upcoming.map((r) => <RaceRow key={r.id} r={r} />) : <p className="text-sm text-rc-cream/50">No races scheduled in the next hour; the meeting moves between courses.</p>}</section>
        <section className="space-y-2"><h2 className="font-serif text-lg font-bold text-white">Recent results</h2>{c.results.length ? c.results.map((r) => <RaceRow key={r.id} r={r} />) : <p className="text-sm text-rc-cream/50">No results yet.</p>}</section>
      </div>
    </div>
  );
}

export default function Racing() {
  const { pathname } = useLocation();
  let m;
  let page;
  if ((m = /^\/racing\/race\/(\d+)/.exec(pathname))) page = <Suspense fallback={<Loading />}><RacePage key={m[1]} id={Number(m[1])} /></Suspense>;
  else if ((m = /^\/racing\/horse\/(\d+)/.exec(pathname))) page = <HorseProfile key={m[1]} id={Number(m[1])} />;
  else if ((m = /^\/racing\/course\/([a-z]+)/.exec(pathname))) page = <CoursePage key={m[1]} id={m[1]} />;
  else page = <Dashboard />;
  return <div className="rc-root">{page}</div>;
}
