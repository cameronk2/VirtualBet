// Live racing video. Only streams the site is licensed to show are played: they are listed by the
// server (RACING_STREAMS). None are configured by default, because no free, legally embeddable live
// UK racing feed is available, so this shows an honest "no live broadcast" state and points to the
// virtual racing instead. Supports HLS (native on Safari/iOS/Android, hls.js elsewhere), MP4 and
// authorised iframe players, with loading, error and unavailable states.
import { useEffect, useRef, useState } from 'react';
import { api } from '../../lib/api.js';
import { Link } from '../../lib/router.jsx';
import { Countdown, offTime } from './common.jsx';

const HLS_JS = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js';
function loadHls() {
  if (window.Hls) return Promise.resolve(window.Hls);
  return new Promise((res, rej) => { const s = document.createElement('script'); s.src = HLS_JS; s.onload = () => res(window.Hls); s.onerror = rej; document.head.appendChild(s); });
}

function Player({ stream }) {
  const video = useRef(null), box = useRef(null), hls = useRef(null);
  const [state, setState] = useState('loading');
  const [levels, setLevels] = useState([]);
  const [level, setLevel] = useState(-1);
  const [muted, setMuted] = useState(true);
  const [paused, setPaused] = useState(false);
  useEffect(() => {
    if (stream.type === 'iframe') return undefined;
    const v = video.current; let alive = true;
    const onErr = () => alive && setState('error');
    v.addEventListener('playing', () => alive && setState('playing'));
    v.addEventListener('waiting', () => alive && setState('loading'));
    v.addEventListener('error', onErr);
    if (stream.type === 'mp4' || v.canPlayType('application/vnd.apple.mpegurl')) { v.src = stream.url; v.play().catch(() => setPaused(true)); }
    else loadHls().then((Hls) => {
      if (!alive) return;
      if (!Hls?.isSupported()) { setState('error'); return; }
      const h = new Hls({ lowLatencyMode: true }); hls.current = h;
      h.on(Hls.Events.MANIFEST_PARSED, (_, d) => { setLevels(d.levels.map((l, i) => ({ i, label: l.height ? `${l.height}p` : `${Math.round(l.bitrate / 1000)}k` }))); v.play().catch(() => setPaused(true)); });
      h.on(Hls.Events.ERROR, (_, d) => { if (d.fatal) onErr(); });
      h.loadSource(stream.url); h.attachMedia(v);
    }).catch(onErr);
    return () => { alive = false; hls.current?.destroy(); hls.current = null; };
  }, [stream.url, stream.type]);
  const fs = () => { const el = box.current; if (document.fullscreenElement) document.exitFullscreen(); else (el.requestFullscreen || el.webkitRequestFullscreen)?.call(el); if (!el.requestFullscreen && video.current?.webkitEnterFullscreen) video.current.webkitEnterFullscreen(); };
  return (
    <div ref={box} className="relative aspect-video overflow-hidden rounded-2xl border border-rc-gold/30 bg-black">
      {stream.type === 'iframe'
        ? <iframe src={stream.url} title={stream.name} allow="autoplay; fullscreen; picture-in-picture" allowFullScreen className="absolute inset-0 h-full w-full" onLoad={() => setState('playing')} />
        : <video ref={video} className="absolute inset-0 h-full w-full" playsInline muted={muted} autoPlay />}
      <div className="pointer-events-none absolute left-2 top-2 flex items-center gap-1.5"><span className="inline-flex items-center gap-1 rounded bg-red-600 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-white"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />Live</span><span className="rounded bg-black/60 px-1.5 py-0.5 text-[11px] font-bold text-white">{stream.course || stream.name}</span></div>
      {state === 'loading' && <div className="absolute inset-0 flex items-center justify-center"><span className="rc-spinner" /></div>}
      {state === 'error' && <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 bg-black/80 text-center text-sm text-rc-cream/80"><b className="text-white">Stream unavailable</b>The broadcaster's feed isn't available right now.</div>}
      {stream.type !== 'iframe' && (
        <div className="absolute inset-x-0 bottom-0 flex items-center gap-1 bg-gradient-to-t from-black/80 to-transparent p-2">
          <button type="button" className="rc-ctl" onClick={() => { const v = video.current; if (v.paused) { v.play(); setPaused(false); } else { v.pause(); setPaused(true); } }}>{paused ? 'Play' : 'Pause'}</button>
          <button type="button" className="rc-ctl" onClick={() => setMuted((m) => !m)}>{muted ? 'Unmute' : 'Mute'}</button>
          {levels.length > 1 && <select className="rc-ctl appearance-none" value={level} onChange={(e) => { const l = Number(e.target.value); setLevel(l); if (hls.current) hls.current.currentLevel = l; }} aria-label="Quality"><option value={-1}>Auto</option>{levels.map((l) => <option key={l.i} value={l.i}>{l.label}</option>)}</select>}
          <button type="button" className="rc-ctl ml-auto" onClick={fs}>Full screen</button>
        </div>
      )}
    </div>
  );
}

export default function LiveVideo({ next, skew }) {
  const [streams, setStreams] = useState(null);
  const [pick, setPick] = useState(0);
  useEffect(() => { api.get('/api/racing/streams').then((d) => setStreams(d.streams)).catch(() => setStreams([])); }, []);
  if (streams == null) return null;
  if (streams.length) {
    return (
      <section className="space-y-2">
        <div className="flex items-center justify-between"><h2 className="font-serif text-xl font-bold text-white">Live broadcast</h2>{streams.length > 1 && <select className="rc-select w-auto" value={pick} onChange={(e) => setPick(Number(e.target.value))}>{streams.map((s, i) => <option key={s.id} value={i}>{s.name}</option>)}</select>}</div>
        <Player key={streams[pick].url} stream={streams[pick]} />
      </section>
    );
  }
  return (
    <section className="relative overflow-hidden rounded-2xl border border-white/10 bg-[radial-gradient(ellipse_at_top_right,rgba(214,178,94,.18),transparent_60%),linear-gradient(160deg,#0a1626,#05150f)] p-4">
      <div className="flex items-start gap-3">
        <svg viewBox="0 0 48 48" className="h-11 w-11 shrink-0 text-rc-gold" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true"><rect x="4" y="10" width="30" height="24" rx="4" /><path d="M34 18l10-6v20l-10-6" strokeLinejoin="round" /><path d="M6 40L42 6" strokeLinecap="round" /></svg>
        <div className="min-w-0">
          <h2 className="font-serif text-xl font-bold text-white">No live broadcast right now</h2>
          <p className="mt-1 text-sm text-rc-cream/75">Live coverage of real racing can only be shown here with the broadcaster's permission. Free UK coverage (such as ITV Racing on ITVX) can't be embedded in other websites, so there's no real racing video on VirtualBet. We'll never show a recording as live.</p>
          <p className="mt-2 text-sm text-rc-cream/75">Watch the virtual racing below instead{next ? <> — next off at <Link to={`/racing/race/${next.id}`} className="font-bold text-rc-gold">{offTime(next.off)} {next.courseName}</Link> in <Countdown to={next.off} skew={skew} className="font-cond font-bold text-emerald-300" /></> : null}.</p>
        </div>
      </div>
    </section>
  );
}
