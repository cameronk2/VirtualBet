// Racing sound: its own mixer with separate volumes for commentary, horses, crowd and interface
// sounds (plus master and mute), saved per player. Files come from client/audio/racing, made with
// free tools (tools/music/racing.py). With sound off or a file missing, nothing breaks: the
// commentary still appears as captions.
const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
const has = (f) => AUD.files.includes(`racing/${f}.mp3`);
const url = (f) => (has(f) ? `${AUD.base}racing/${f}.mp3` : null);

const KEY = 'rc_audio';
const DEFAULTS = { muted: false, master: 0.9, commentary: 1, horses: 0.75, crowd: 0.7, ui: 0.6, ambience: true };
export function loadSettings() { try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { return { ...DEFAULTS }; } }
let settings = loadSettings();
const listeners = new Set();
export function onSettings(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function getSettings() { return settings; }
export function setSettings(patch) {
  settings = { ...settings, ...patch };
  try { localStorage.setItem(KEY, JSON.stringify(settings)); } catch { /* private mode */ }
  apply(); listeners.forEach((f) => f(settings));
}

let ctx = null, bus = null;
const buffers = new Map();
function ac() {
  if (ctx) return ctx;
  const C = window.AudioContext || window.webkitAudioContext;
  if (!C) return null;
  ctx = new C();
  const master = ctx.createGain(); master.connect(ctx.destination);
  const mk = () => { const g = ctx.createGain(); g.connect(master); return g; };
  bus = { master, commentary: mk(), horses: mk(), crowd: mk(), ui: mk() };
  // the commentary ducks the crowd and hooves so it is always clear
  bus.duck = ctx.createGain(); bus.duck.connect(master);
  bus.crowd.disconnect(); bus.crowd.connect(bus.duck); bus.horses.disconnect(); bus.horses.connect(bus.duck);
  apply();
  return ctx;
}
function apply() {
  if (!bus) return;
  const t = ctx.currentTime;
  bus.master.gain.setTargetAtTime(settings.muted ? 0 : settings.master, t, 0.05);
  for (const k of ['commentary', 'horses', 'crowd', 'ui']) bus[k].gain.setTargetAtTime(settings[k], t, 0.05);
}
/** Call from a tap/click: browsers only start audio after a gesture. */
export function unlock() { const a = ac(); if (a?.state === 'suspended') a.resume().catch(() => {}); }

function load(u) {
  if (!u) return Promise.reject(new Error('missing'));
  const a = ac(); if (!a) return Promise.reject(new Error('no audio'));
  if (!buffers.has(u)) buffers.set(u, fetch(u).then((r) => r.arrayBuffer()).then((b) => new Promise((res, rej) => a.decodeAudioData(b, res, rej))).catch((e) => { buffers.delete(u); throw e; }));
  return buffers.get(u);
}
/** Load what one race needs: the calls, the crowd and hooves, and the runners' names. */
export function preloadRace(race) {
  if (!ac()) return;
  const files = ['voice/orders', 'voice/off', 'voice/leads', 'voice/halfway', 'voice/2f', 'voice/1f', 'voice/photo', 'voice/wins', 'sfx/crowd', 'sfx/roar', 'sfx/gallop', 'sfx/gates', 'sfx/bell', 'sfx/cheer1', 'sfx/cheer2', 'sfx/gasp', 'sfx/photo',
    ...(race.runners || []).map((r) => `voice/horse/h${r.horseId}`)];
  for (const f of files) { const u = url(f); if (u) load(u).catch(() => {}); }
}

function play(file, channel, { gain = 1, rate = 1, at = 0, loop = false } = {}) {
  const u = url(file); if (!u || settings.muted) return null;
  const a = ac(); if (!a) return null;
  const h = { src: null, g: a.createGain(), stopped: false };
  h.g.gain.value = gain; h.g.connect(bus[channel]);
  load(u).then((buf) => {
    if (h.stopped) return;
    const s = a.createBufferSource(); s.buffer = buf; s.loop = loop; s.playbackRate.value = rate; s.connect(h.g);
    s.start(Math.max(a.currentTime, at || a.currentTime)); h.src = s; h.dur = buf.duration;
  }).catch(() => {});
  h.stop = (fade = 0.3) => { h.stopped = true; try { h.g.gain.setTargetAtTime(0, a.currentTime, fade / 3); h.src?.stop(a.currentTime + fade + 0.05); } catch { /* done */ } };
  return h;
}
export const ui = (name, opts) => play(`ui/${name}`, 'ui', opts);

// ── commentary: one line after another, never over each other ──
let queueEnd = 0;
const said = [];
export function say(lines, { urgent = false, maxWait = 3 } = {}) {
  const a = ac(); if (!a || settings.muted) return;
  const files = (Array.isArray(lines) ? lines : [lines]).map((l) => `voice/${l}`).filter((f) => has(f));
  if (!files.length) return;
  const asked = a.currentTime;
  if (urgent) { said.forEach((h) => h.stop(0.08)); said.length = 0; queueEnd = 0; }
  Promise.all(files.map((f) => load(url(f)).catch(() => null))).then((bufs) => {
    let t = Math.max(a.currentTime + 0.02, queueEnd + 0.05);
    if (t - asked > maxWait) return;
    for (const b of bufs) {
      if (!b) continue;
      const s = a.createBufferSource(), g = a.createGain(); s.buffer = b; s.connect(g).connect(bus.commentary); s.start(t);
      const h = { stop: (f) => { try { g.gain.setTargetAtTime(0, a.currentTime, f); s.stop(a.currentTime + f * 3); } catch { /* done */ } } };
      said.push(h); s.onended = () => { const i = said.indexOf(h); if (i >= 0) said.splice(i, 1); };
      t += b.duration - 0.04;
    }
    // duck the crowd and hooves under the voice
    bus.duck.gain.cancelScheduledValues(a.currentTime);
    bus.duck.gain.setTargetAtTime(0.38, Math.max(a.currentTime, queueEnd), 0.06);
    bus.duck.gain.setTargetAtTime(1, t, 0.25);
    queueEnd = t;
  });
}
export const nameLine = (horseId) => `horse/h${horseId}`;

// ── the race soundscape: crowd bed, hooves, cheers ──
let scene = null;
export function startRace() {
  stopRace();
  const a = ac(); if (!a) return;
  scene = {
    crowd: settings.ambience ? play('sfx/crowd', 'crowd', { loop: true, gain: 0.5 }) : null,
    hooves: play('sfx/gallop', 'horses', { loop: true, gain: 0 }),
    roar: play('sfx/roar', 'crowd', { loop: true, gain: 0 }),
  };
}
/** Called every frame: excitement 0..1 (closeness to the line), pace 0..1, near 0..1 (camera close to the field). */
export function updateRace({ excite = 0, pace = 0, near = 0.5 }) {
  if (!scene || !ctx) return;
  const t = ctx.currentTime;
  scene.hooves?.g.gain.setTargetAtTime(pace * (0.35 + near * 0.65), t, 0.15);
  if (scene.hooves?.src) scene.hooves.src.playbackRate.setTargetAtTime(0.85 + pace * 0.3, t, 0.3);
  scene.roar?.g.gain.setTargetAtTime(excite ** 1.4 * 0.9, t, 0.3);
  scene.crowd?.g.gain.setTargetAtTime(0.45 + excite * 0.25, t, 0.4);
}
export function stopRace() {
  if (!scene) return;
  Object.values(scene).forEach((h) => h?.stop(0.8));
  scene = null;
}
const SFX_CHANNEL = { gates: 'horses', gallop: 'horses', snort: 'horses', bell: 'ui', photo: 'ui', fanfare: 'ui', confirm: 'ui' };
export const sfx = (name, opts) => play(`sfx/${name}`, SFX_CHANNEL[name] || 'crowd', opts);
export const hasCommentary = () => has('voice/off');
