// Canvas money wheels for Fortune Live: the 54-segment main wheel and the 64-segment
// Fortune Frenzy wheel. The face is painted once into an offscreen texture; each frame
// rotates it and adds the live parts (bulbs, flappers, glow) on top.

export const TAU = Math.PI * 2;
const dpr = () => Math.min(2.5, (typeof window !== 'undefined' && window.devicePixelRatio) || 1);

/** Colours and labels for main-wheel segments. */
export const SEG_STYLE = {
  n1: { a: '#fde047', b: '#ca8a04', text: '#3b2300', label: '1' },
  n2: { a: '#7dd3fc', b: '#0369a1', text: '#04223a', label: '2' },
  n5: { a: '#f9a8d4', b: '#be185d', text: '#3d0322', label: '5' },
  n10: { a: '#c4b5fd', b: '#6d28d9', text: '#1e0a45', label: '10' },
  toss: { a: '#60a5fa', b: '#1d4ed8', text: '#fff', label: 'COIN TOSS', split: '#ef4444' },
  wall: { a: '#4ade80', b: '#15803d', text: '#fff', label: 'PRIZE WALL' },
  drop: { a: '#d8b4fe', b: '#7e22ce', text: '#fff', label: 'DROP ZONE' },
  frenzy: { a: '#fb7185', b: '#b91c1c', text: '#fff', label: 'FRENZY', rainbow: true },
};

function seg(ctx, r0, r1, a0, a1) {
  ctx.beginPath();
  ctx.arc(0, 0, r1, a0, a1);
  ctx.arc(0, 0, r0, a1, a0, true);
  ctx.closePath();
}

/**
 * Paints a wheel face. `items` is one entry per segment: { a, b, text, label, small?, split?, rainbow? }.
 * Segment i is centred straight up when the wheel's rotation is -i * step.
 */
export function paintFace(size, items, { rim = '#e5c55a', hub = 'Fortune', hubSub = 'LIVE', fontScale = 1, radial = false } = {}) {
  const c = document.createElement('canvas');
  const k = dpr();
  c.width = c.height = Math.round(size * k);
  const ctx = c.getContext('2d');
  ctx.scale(k, k);
  ctx.translate(size / 2, size / 2);
  const R = size / 2;
  const n = items.length, step = TAU / n;
  const r1 = R * 0.9, r0 = R * 0.2;
  // rim: brushed gold ring
  const rg = ctx.createLinearGradient(-R, -R, R, R);
  rg.addColorStop(0, '#fff6c9'); rg.addColorStop(0.25, rim); rg.addColorStop(0.5, '#7a5a12'); rg.addColorStop(0.75, rim); rg.addColorStop(1, '#fff3b0');
  ctx.beginPath(); ctx.arc(0, 0, R * 0.995, 0, TAU); ctx.fillStyle = rg; ctx.fill();
  ctx.beginPath(); ctx.arc(0, 0, R * 0.93, 0, TAU); ctx.fillStyle = '#1a1020'; ctx.fill();
  for (let i = 0; i < n; i++) {
    const it = items[i];
    const a0 = -Math.PI / 2 + (i - 0.5) * step, a1 = a0 + step;
    const g = ctx.createRadialGradient(0, 0, r0, 0, 0, r1);
    g.addColorStop(0, it.b); g.addColorStop(0.55, it.a); g.addColorStop(1, it.b);
    seg(ctx, r0, r1, a0, a1); ctx.fillStyle = g; ctx.fill();
    if (it.split) { // Coin Toss: half red, half blue
      const g2 = ctx.createRadialGradient(0, 0, r0, 0, 0, r1); g2.addColorStop(0, '#7f1d1d'); g2.addColorStop(0.55, it.split); g2.addColorStop(1, '#7f1d1d');
      seg(ctx, r0, r1, a0 + step / 2, a1); ctx.fillStyle = g2; ctx.fill();
    }
    if (it.rainbow) {
      const cols = ['#ef4444', '#f97316', '#facc15', '#22c55e', '#3b82f6', '#a855f7'];
      cols.forEach((col, j) => { seg(ctx, r1 - (j + 1) * (r1 - r0) * 0.055, r1 - j * (r1 - r0) * 0.055, a0, a1); ctx.fillStyle = col; ctx.fill(); });
    }
    // separators
    ctx.strokeStyle = 'rgba(255,240,190,.9)'; ctx.lineWidth = Math.max(1, size / 360);
    ctx.beginPath(); ctx.moveTo(Math.cos(a0) * r0, Math.sin(a0) * r0); ctx.lineTo(Math.cos(a0) * r1, Math.sin(a0) * r1); ctx.stroke();
    // label: written along the radius, reading outward
    ctx.save();
    ctx.rotate(a0 + step / 2);
    ctx.fillStyle = it.text;
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    const long = radial || it.label.length > 3;
    const arc = (TAU * r1) / n;
    const fs = radial ? Math.min(arc * 0.78, R * 0.075) * (it.small || 1)
      : (long ? R * 0.052 : it.label.length > 2 ? R * 0.085 : R * 0.1) * fontScale * (it.small || 1);
    ctx.font = `900 ${fs}px "Lilita One", "Barlow Condensed", system-ui, sans-serif`;
    if (long) {
      ctx.save(); ctx.translate(r1 - R * 0.035, 0);
      ctx.lineWidth = fs * 0.22; ctx.strokeStyle = it.text === '#fff' ? 'rgba(0,0,0,.55)' : 'rgba(255,255,255,.6)'; ctx.strokeText(it.label, 0, 0); ctx.fillText(it.label, 0, 0);
      ctx.restore();
    } else {
      // numbers stand upright at the rim
      ctx.save(); ctx.translate(r1 - fs * 0.75, 0); ctx.rotate(Math.PI / 2);
      ctx.textAlign = 'center';
      ctx.lineWidth = fs * 0.12; ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.strokeText(it.label, 0, 0);
      ctx.fillText(it.label, 0, 0);
      ctx.restore();
    }
    ctx.restore();
  }
  // inner and outer bands
  ctx.lineWidth = R * 0.018; ctx.strokeStyle = '#f5d76e';
  ctx.beginPath(); ctx.arc(0, 0, r1, 0, TAU); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, r0, 0, TAU); ctx.stroke();
  // pegs on the separators
  for (let i = 0; i < n; i++) {
    const a = -Math.PI / 2 + (i - 0.5) * step;
    const x = Math.cos(a) * R * 0.915, y = Math.sin(a) * R * 0.915;
    const pg = ctx.createRadialGradient(x - 1, y - 1, 0, x, y, R * 0.016);
    pg.addColorStop(0, '#fff'); pg.addColorStop(0.5, '#d6d3d1'); pg.addColorStop(1, '#57534e');
    ctx.beginPath(); ctx.arc(x, y, R * 0.013, 0, TAU); ctx.fillStyle = pg; ctx.fill();
  }
  // hub
  const hg = ctx.createRadialGradient(-r0 * 0.3, -r0 * 0.4, 0, 0, 0, r0);
  hg.addColorStop(0, '#fff7cc'); hg.addColorStop(0.4, '#eab308'); hg.addColorStop(1, '#713f12');
  ctx.beginPath(); ctx.arc(0, 0, r0 * 0.96, 0, TAU); ctx.fillStyle = hg; ctx.fill();
  ctx.beginPath(); ctx.arc(0, 0, r0 * 0.78, 0, TAU); ctx.fillStyle = '#2a0f3d'; ctx.fill();
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = '#fde68a';
  ctx.font = `900 ${r0 * 0.36}px "Lilita One", system-ui, sans-serif`;
  ctx.fillText(hub, 0, -r0 * 0.12);
  ctx.fillStyle = '#f472b6';
  ctx.font = `800 ${r0 * 0.26}px "Barlow Condensed", system-ui, sans-serif`;
  ctx.fillText(hubSub, 0, r0 * 0.3);
  // gloss
  const gl = ctx.createRadialGradient(-R * 0.35, -R * 0.45, 0, -R * 0.2, -R * 0.2, R * 1.1);
  gl.addColorStop(0, 'rgba(255,255,255,.22)'); gl.addColorStop(0.45, 'rgba(255,255,255,0)');
  ctx.beginPath(); ctx.arc(0, 0, R * 0.93, 0, TAU); ctx.fillStyle = gl; ctx.fill();
  return c;
}

/** Angle (radians, clockwise) that puts segment `i` under the top pointer after `turns` full turns. */
export function targetRotation(current, i, n, turns, jitter = 0) {
  const step = TAU / n;
  const base = current + TAU * turns;
  const want = -i * step + jitter * step * 0.36;
  return base + ((((want - base) % TAU) + TAU) % TAU);
}

/**
 * Draws one frame: the rotated face, chasing rim bulbs and one or more flappers.
 * flappers: [{ at: angle (rad, 0 = top), colour, kick }]; boostSeg lights a segment.
 */
export function drawFrame(ctx, size, face, rot, { t = 0, fast = false, flappers = [{ at: 0, colour: '#f8fafc', kick: 0 }], glowSeg = null, n = 54, glowColour = '#fff' } = {}) {
  const R = size / 2;
  ctx.clearRect(0, 0, size, size);
  ctx.save();
  ctx.translate(R, R);
  // drop shadow
  ctx.beginPath(); ctx.arc(0, R * 0.02, R * 0.99, 0, TAU); ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fill();
  ctx.save(); ctx.rotate(rot); ctx.drawImage(face, -R, -R, size, size);
  if (glowSeg != null) {
    const step = TAU / n, a0 = -Math.PI / 2 + (glowSeg - 0.5) * step;
    ctx.globalCompositeOperation = 'lighter';
    ctx.beginPath(); ctx.arc(0, 0, R * 0.9, a0, a0 + step); ctx.arc(0, 0, R * 0.2, a0 + step, a0, true); ctx.closePath();
    ctx.fillStyle = glowColour; ctx.globalAlpha = 0.35 + 0.25 * Math.sin(t / 120); ctx.fill();
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();
  // bulbs on the rim (fixed, chasing)
  const B = 40;
  for (let i = 0; i < B; i++) {
    const a = (i / B) * TAU;
    const on = ((i + Math.floor(t / (fast ? 60 : 180))) % 4) < 2;
    const x = Math.cos(a) * R * 0.962, y = Math.sin(a) * R * 0.962;
    const r = R * 0.017;
    if (on) { const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3); g.addColorStop(0, 'rgba(255,248,200,1)'); g.addColorStop(0.35, 'rgba(253,224,71,.8)'); g.addColorStop(1, 'rgba(253,224,71,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 3, 0, TAU); ctx.fill(); }
    ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fillStyle = on ? '#fffbe6' : '#8a6d1f'; ctx.fill();
  }
  // flappers
  for (const f of flappers) {
    ctx.save();
    ctx.rotate(f.at);
    ctx.translate(0, -R * 0.985);
    ctx.rotate((f.kick || 0) * 0.5);
    ctx.beginPath();
    ctx.moveTo(-R * 0.045, -R * 0.02); ctx.lineTo(R * 0.045, -R * 0.02); ctx.lineTo(0, R * 0.12); ctx.closePath();
    const fg = ctx.createLinearGradient(-R * 0.05, 0, R * 0.05, 0);
    fg.addColorStop(0, '#000'); fg.addColorStop(0.08, f.colour); fg.addColorStop(0.5, '#fff'); fg.addColorStop(0.9, f.colour); fg.addColorStop(1, '#000');
    ctx.fillStyle = fg; ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 2; ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.beginPath(); ctx.arc(0, 0, R * 0.026, 0, TAU); ctx.fillStyle = '#1c1917'; ctx.fill();
    ctx.strokeStyle = '#fef3c7'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}

/** Sizes a canvas to its CSS box at device resolution; returns the CSS size. */
export function fitCanvas(cv) {
  const s = Math.max(120, Math.round(cv.clientWidth || 320));
  const k = dpr();
  if (cv.width !== Math.round(s * k)) { cv.width = Math.round(s * k); cv.height = Math.round(s * k); }
  const ctx = cv.getContext('2d');
  ctx.setTransform(k, 0, 0, k, 0, 0);
  return { s, ctx };
}

export const easeOut = (x) => 1 - (1 - x) ** 4;
