// Fortune Frenzy: a 64-segment prize wheel with three flappers. The player picks a flapper;
// the wheel spins and that flapper's segment pays. DOUBLE and TRIPLE multiply every prize and
// the wheel spins again. The prizes are on show before the choice; the spins come from the server.
import { useEffect, useRef, useState } from 'react';
import { FLAPPERS, FLAPPER_OFFSET, FRENZY_SEGS } from '../../../../../server/games/fortune/config.js';
import { TAU, drawFrame, easeOut, fitCanvas, paintFace, targetRotation } from '../canvasWheel.js';
import { BonusFrame, wait } from './common.jsx';

const STEP = TAU / FRENZY_SEGS;
const FL_COL = { green: '#22c55e', blue: '#3b82f6', yellow: '#facc15' };
const PALS = [['#fde047', '#a16207', '#3b2300'], ['#f472b6', '#9d174d', '#fff'], ['#38bdf8', '#075985', '#fff'], ['#4ade80', '#166534', '#05230f'], ['#c084fc', '#6b21a8', '#fff'], ['#fb923c', '#9a3412', '#fff']];
const PICK_SECS = 12;

function items(wheel, factor) {
  return wheel.map((v, i) => {
    if (v === 'DBL') return { a: '#fef08a', b: '#ca8a04', text: '#422006', label: 'DOUBLE', small: 0.8 };
    if (v === 'TRP') return { a: '#fecaca', b: '#b91c1c', text: '#fff', label: 'TRIPLE', small: 0.8 };
    const [a, b, text] = PALS[i % PALS.length];
    const n = v * factor;
    return { a, b, text, label: `${n}x`, small: n >= 10000 ? 0.8 : 1 };
  });
}

export default function Frenzy({ wheel, boost, bet, watched, known, fast, fx, run, onDone }) {
  const cv = useRef(null);
  const st = useRef({ rot: 0, anim: null, face: null, size: 0, factor: 1, kick: 0, glow: null, chosen: null });
  const [phase, setPhase] = useState('intro');
  const [chosen, setChosen] = useState(null);
  const [left, setLeft] = useState(PICK_SECS);
  const [factor, setFactor] = useState(1);
  const [result, setResult] = useState(null);
  const [msg, setMsg] = useState('');
  const locked = useRef(false);

  useEffect(() => {
    let raf = 0, alive = true;
    const loop = (t) => {
      if (!alive) return;
      const c = cv.current, s = st.current;
      if (c) {
        const { s: size, ctx } = fitCanvas(c);
        if (!s.face || s.size !== size) { s.face = paintFace(size, items(wheel, s.factor), { hub: 'Frenzy', hubSub: s.factor > 1 ? `×${s.factor}` : 'FORTUNE', radial: true }); s.size = size; }
        if (s.anim) {
          const a = s.anim, x = Math.min(1, (t - a.t0) / a.ms), prev = s.rot;
          s.rot = a.from + (a.to - a.from) * easeOut(x);
          if (Math.floor((prev + STEP / 2) / STEP) !== Math.floor((s.rot + STEP / 2) / STEP)) { s.kick = 0.8; if ((s.rot - prev) / STEP < 0.6) fx.sfx?.('peg', { gain: 0.3, rate: 1.1 }); }
          if (x >= 1) { s.anim = null; a.done(); }
        }
        s.kick *= 0.8;
        const fl = FLAPPERS.map((f) => ({ at: FLAPPER_OFFSET[f] * STEP, colour: FL_COL[f], kick: -s.kick * (s.chosen && s.chosen !== f ? 0.5 : 1) }));
        drawFrame(ctx, size, s.face, s.rot, { t, fast: !!s.anim, flappers: fl, n: FRENZY_SEGS, glowSeg: s.glow, glowColour: '#fff' });
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    document.fonts?.ready?.then(() => { st.current.face = null; });
    return () => { alive = false; cancelAnimationFrame(raf); };
  }, [wheel]); // eslint-disable-line react-hooks/exhaustive-deps

  const spinTo = (stop, ms) => new Promise((done) => {
    const s = st.current;
    s.anim = { from: s.rot, to: targetRotation(s.rot, stop, FRENZY_SEGS, fast ? 2 : 3, 0), t0: performance.now(), ms, done };
  });

  useEffect(() => {
    let live = true;
    (async () => {
      fx.voice?.('frenzy_intro');
      // a slow showcase turn so the prizes can be read
      spinTo(Math.floor(Math.random() * FRENZY_SEGS), fast ? 1200 : 3000);
      await wait(fast ? 1300 : 3100, false);
      if (!live) return;
      if (watched) { setPhase('choose'); await wait(900, fast); choose(known.flapper); await wait(700, fast); if (live) lock(known.flapper, known); return; }
      setPhase('choose'); fx.voice?.('frenzy_pick');
    })();
    return () => { live = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (phase !== 'choose' || watched) return;
    if (left <= 0) { lock(chosen || FLAPPERS[Math.floor(Math.random() * 3)]); return; }
    if (left <= 3) fx.sfx?.('tick');
    const t = setTimeout(() => setLeft((v) => v - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, left]); // eslint-disable-line react-hooks/exhaustive-deps

  function choose(f) { setChosen(f); st.current.chosen = f; fx.sfx?.('aim'); }

  async function lock(f, pre) {
    if (locked.current) return;
    locked.current = true;
    choose(f); setPhase('spin'); fx.sfx?.('lock');
    const r = pre || await run(f);
    if (!r) { onDone(); return; }
    for (const sp of r.spins) {
      setMsg(sp.factor > 1 ? `Every prize ×${sp.factor} · spinning again…` : 'Spinning…');
      fx.sfx?.('spin');
      st.current.glow = null;
      await spinTo(sp.stop, fast ? 2600 : 5200);
      st.current.glow = sp.seg;
      fx.sfx?.('land');
      if (sp.value === 'DBL' || sp.value === 'TRP') {
        const nf = sp.factor * (sp.value === 'DBL' ? 2 : 3);
        setMsg(sp.value === 'DBL' ? 'DOUBLE! Every prize doubles.' : 'TRIPLE! Every prize triples.');
        fx.sfx?.('double'); fx.voice?.(sp.value === 'DBL' ? 'double' : 'triple');
        await wait(1500, fast);
        st.current.factor = nf; st.current.face = null; setFactor(nf);
        await wait(800, fast);
      }
    }
    setResult(r.x); setMsg(''); setPhase('done');
    if (!watched) { fx.sfx?.('win'); fx.voice?.(r.x >= 200 ? 'big' : 'nice'); }
    await wait(2800, fast);
    onDone();
  }

  return (
    <BonusFrame id="frenzy" bet={bet} boost={boost} watched={watched} result={phase === 'done' && !watched ? result : null}
      footer={phase === 'choose' && !watched ? (
        <div className="flex w-full items-center justify-between gap-2">
          <div className="flex gap-1.5">
            {FLAPPERS.map((f) => (
              <button key={f} type="button" onClick={() => choose(f)} className={`h-9 rounded-full px-3 text-xs font-extrabold uppercase tracking-wide text-black ring-2 transition-transform ${chosen === f ? 'scale-110 ring-white' : 'ring-black/20 opacity-80'}`} style={{ background: FL_COL[f] }}>{f}</button>
            ))}
          </div>
          <span className={`font-cond text-lg font-bold tabular-nums ${left <= 3 ? 'text-rose-300' : 'text-white'}`}>{left}s</span>
          <button type="button" disabled={!chosen} onClick={() => lock(chosen)} className="rounded-full bg-amber-300 px-3 py-1.5 text-sm font-extrabold text-amber-950 disabled:opacity-40">Spin</button>
        </div>
      ) : phase === 'done' && watched ? <span className="text-white/80">The {chosen} flapper won <b className="text-amber-200">{result}x</b></span> : null}>
      <div className="relative aspect-square" style={{ width: 'min(100%, 58vh, 520px)' }}>
        <canvas ref={cv} className="block aspect-square w-full" />
      </div>
      <div className="mt-1 flex h-6 items-center gap-2 font-cond text-sm font-bold uppercase tracking-wider text-fuchsia-100">
        {chosen && <span className="rounded-full px-2 text-[11px] text-black" style={{ background: FL_COL[chosen] }}>{chosen} flapper</span>}
        {factor > 1 && <span className="text-amber-200">×{factor}</span>}
        {msg}{result != null && <span className="fl-pop text-amber-200">{result}x!</span>}
        {phase === 'choose' && !watched && !chosen && <span>Choose a flapper</span>}
      </div>
    </BonusFrame>
  );
}
