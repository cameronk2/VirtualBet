// Shared pieces for the Fortune Live bonus scenes.
import { money } from '../../../lib/format.js';
import { SpotIcon } from '../icons.jsx';
import { SPOTS } from '../../../../../server/games/fortune/config.js';

export const wait = (ms, fast) => new Promise((r) => setTimeout(r, fast ? ms * 0.45 : ms));

export function BonusFrame({ id, children, bet, boost, result, watched, onSkip, footer }) {
  return (
    <div className="fl-bonus-in absolute inset-0 z-30 flex flex-col overflow-hidden rounded-2xl bg-[radial-gradient(ellipse_at_50%_0%,#4c1d95,#1e0b3a_45%,#07030f)]">
      <div className="fl-rays pointer-events-none absolute inset-0 opacity-40" />
      <div className="relative flex items-center justify-between gap-2 px-3 pt-2.5">
        <div className="flex items-center gap-2">
          <SpotIcon id={id} className="h-9 w-9 drop-shadow" />
          <div className="leading-tight">
            <div className="font-display text-xl text-amber-200 [text-shadow:0_2px_0_#7c2d12] sm:text-2xl">{SPOTS[id].name}</div>
            <div className="text-[10px] font-semibold uppercase tracking-widest text-fuchsia-200/80">{watched ? 'You are watching this bonus' : 'Bonus game'}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {boost > 1 && <span className="fl-pop rounded-lg bg-amber-300 px-2 py-0.5 font-display text-sm text-amber-950 shadow-[0_0_14px_#f59e0b]">Booster {boost}x</span>}
          {onSkip && <button type="button" onClick={onSkip} className="rounded-md bg-white/10 px-2.5 py-1 text-xs font-semibold text-white/80 ring-1 ring-white/20 hover:bg-white/20">Skip</button>}
        </div>
      </div>
      <div className="relative flex min-h-0 flex-1 flex-col items-center justify-center px-2 py-2">{children}</div>
      <div className="relative flex min-h-[44px] items-center justify-center gap-3 border-t border-white/10 bg-black/40 px-3 py-2 text-center text-sm">
        {footer || (watched ? <span className="text-white/70">No bet on {SPOTS[id].name} this round</span>
          : result != null ? <span className="fl-pop font-cond text-xl font-extrabold text-amber-200">{result}x · you win {money(Math.floor(bet * (1 + result)))}</span>
            : <span className="text-white/80">Your bet: <b className="text-white">{money(bet)}</b></span>)}
      </div>
    </div>
  );
}

export function Mult({ x, className = '' }) {
  return <span className={`font-display tabular-nums ${className}`}>{x}x</span>;
}
