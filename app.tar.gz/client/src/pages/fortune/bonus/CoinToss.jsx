// Coin Toss: the red and blue sides get their multipliers, then the coin is flipped.
import { useEffect, useRef, useState } from 'react';
import { BonusFrame, wait } from './common.jsx';

export default function CoinToss({ data, final, boost, bet, watched, fast, fx, onDone }) {
  const [red, setRed] = useState(null), [blue, setBlue] = useState(null);
  const [landed, setLanded] = useState(null);
  const [result, setResult] = useState(null);
  const coin = useRef(null), skip = useRef(false), [fastNow, setFast] = useState(fast);
  useEffect(() => {
    let live = true;
    (async () => {
      const f = () => fastNow || skip.current;
      fx.voice?.('toss_intro');
      await wait(1300, f());
      if (!live) return; setRed(data.red); fx.sfx?.('reveal'); await wait(800, f());
      if (!live) return; setBlue(data.blue); fx.sfx?.('reveal', { rate: 1.12 }); await wait(1100, f());
      if (!live) return;
      fx.voice?.('toss_flip');
      fx.sfx?.('flip');
      const turns = (f() ? 6 : 10) * 360 + (data.side === 'blue' ? 180 : 0);
      const ms = f() ? 1400 : 2600;
      coin.current?.animate?.([
        { transform: 'translateY(0) rotateX(0deg) scale(1)' },
        { transform: `translateY(-46%) rotateX(${turns * 0.55}deg) scale(1.25)`, offset: 0.45 },
        { transform: `translateY(0) rotateX(${turns}deg) scale(1)` },
      ], { duration: ms, easing: 'cubic-bezier(.3,.1,.3,1)', fill: 'forwards' });
      await wait(ms, false);
      if (!live) return;
      fx.sfx?.('land'); setLanded(data.side);
      const x = final ?? data.x * boost;
      await wait(400, f());
      setResult(x); fx.voice?.(x >= 50 ? 'big' : data.side === 'red' ? 'toss_red' : 'toss_blue'); if (!watched) fx.sfx?.('win');
      await wait(2200, f());
      if (live) onDone();
    })();
    return () => { live = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const face = (side, v) => (
    <div className={`absolute inset-0 flex flex-col items-center justify-center rounded-full border-[6px] border-amber-200 [backface-visibility:hidden] ${side === 'red' ? 'bg-[radial-gradient(circle_at_35%_30%,#fca5a5,#dc2626_45%,#7f1d1d)]' : 'bg-[radial-gradient(circle_at_35%_30%,#93c5fd,#2563eb_45%,#1e3a8a)] [transform:rotateX(180deg)]'} shadow-[inset_0_0_0_6px_rgba(0,0,0,.25),0_10px_30px_rgba(0,0,0,.5)]`}>
      <span className="font-display text-[11vw] leading-none text-white [text-shadow:0_3px_0_rgba(0,0,0,.35)] sm:text-6xl">{v != null ? `${v}x` : '?'}</span>
      <span className="mt-1 font-cond text-xs font-extrabold uppercase tracking-[0.3em] text-white/80">{side}</span>
    </div>
  );
  return (
    <BonusFrame id="toss" bet={bet} boost={boost} watched={watched} result={watched ? null : result} onSkip={() => { skip.current = true; setFast(true); }}>
      <div className="flex w-full items-center justify-around gap-2">
        {[['red', red, 'from-red-500 to-red-800'], ['blue', blue, 'from-blue-500 to-blue-800']].map(([side, v, g]) => (
          <div key={side} className={`flex flex-col items-center rounded-xl bg-gradient-to-b px-3 py-1.5 ring-2 transition-all ${g} ${landed === side ? 'fl-winner scale-110 ring-amber-200' : landed ? 'opacity-40 ring-white/20' : 'ring-white/30'}`}>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-white/80">{side}</span>
            <span className={`font-display text-2xl text-white ${v != null ? 'fl-pop' : 'opacity-40'}`}>{v != null ? `${v}x` : '—'}</span>
          </div>
        ))}
      </div>
      <div className="relative mt-4 aspect-square w-[46%] max-w-[220px] [perspective:800px]">
        <div ref={coin} className="relative h-full w-full [transform-style:preserve-3d]">
          {face('red', red)}{face('blue', blue)}
        </div>
      </div>
      {result != null && <div className="fl-pop mt-3 font-display text-4xl text-amber-200 [text-shadow:0_0_20px_#f59e0b]">{result}x</div>}
    </BonusFrame>
  );
}
