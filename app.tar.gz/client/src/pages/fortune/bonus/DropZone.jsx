// Drop Zone: a puck falls through a wall of pegs into one of 16 prize slots. A DOUBLE slot
// doubles every prize on the board and the puck is dropped again. The path comes from the server.
import { useEffect, useRef, useState } from 'react';
import { DROP_ROWS, DROP_SLOTS } from '../../../../../server/games/fortune/config.js';
import { BonusFrame, wait } from './common.jsx';

const W = 340, H = 400;
const COL = (c) => 20 + (c * (W - 40)) / (DROP_SLOTS - 1);
const ROW = (r) => 52 + r * ((H - 120) / DROP_ROWS);

export default function DropZone({ data, final, boost, bet, watched, fast, fx, onDone }) {
  const cv = useRef(null);
  const [factor, setFactor] = useState(1);
  const [landed, setLanded] = useState(null);
  const [result, setResult] = useState(null);
  const [msg, setMsg] = useState('');
  const st = useRef({ puck: null, factor: 1, hit: null, glow: 0 });
  const skip = useRef(false);

  // render loop
  useEffect(() => {
    let raf = 0, alive = true;
    const draw = (t) => {
      if (!alive) return;
      const c = cv.current;
      if (c) {
        const k = Math.min(2.5, window.devicePixelRatio || 1);
        if (c.width !== W * k) { c.width = W * k; c.height = H * k; }
        const ctx = c.getContext('2d');
        ctx.setTransform(k, 0, 0, k, 0, 0);
        ctx.clearRect(0, 0, W, H);
        const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#2e1065'); bg.addColorStop(1, '#0b0420');
        ctx.fillStyle = bg; roundRect(ctx, 0, 0, W, H, 16); ctx.fill();
        // drop gates
        for (let c2 = 0; c2 < DROP_SLOTS; c2++) { ctx.fillStyle = 'rgba(253,224,71,.25)'; ctx.fillRect(COL(c2) - 6, 14, 12, 18); }
        // pegs
        for (let r = 0; r < DROP_ROWS; r++) {
          for (let c2 = 0; c2 < DROP_SLOTS; c2++) {
            const x = COL(c2) + (r % 2 === 0 ? (W - 40) / (DROP_SLOTS - 1) / 2 : 0);
            if (x > W - 14) continue;
            const y = ROW(r) + 8;
            const g = ctx.createRadialGradient(x - 1, y - 1, 0, x, y, 4); g.addColorStop(0, '#fff'); g.addColorStop(1, '#a78bfa');
            ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 3.2, 0, Math.PI * 2); ctx.fill();
          }
        }
        // slots
        const s = st.current;
        const sw = (W - 40) / (DROP_SLOTS - 1);
        data.board.forEach((v, i) => {
          const x = COL(i) - sw / 2 + 1, y = H - 56;
          const isD = v === 'D';
          const hit = s.hit === i;
          ctx.fillStyle = isD ? (hit ? '#fde047' : '#ca8a04') : hit ? '#f472b6' : ['#7e22ce', '#9333ea', '#a855f7'][i % 3];
          roundRect(ctx, x, y, sw - 2, 50, 5); ctx.fill();
          if (hit) { ctx.save(); ctx.shadowColor = '#fff'; ctx.shadowBlur = 16 + 8 * Math.sin(t / 90); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; roundRect(ctx, x, y, sw - 2, 50, 5); ctx.stroke(); ctx.restore(); }
          ctx.save(); ctx.translate(x + (sw - 2) / 2, y + 25); ctx.rotate(-Math.PI / 2);
          ctx.fillStyle = isD ? '#422006' : '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.font = `900 ${isD ? 11 : 13}px "Barlow Condensed", system-ui`;
          ctx.fillText(isD ? 'DOUBLE' : `${v * s.factor}x`, 0, 0);
          ctx.restore();
        });
        // puck
        if (s.puck) {
          const { x, y } = s.puck;
          ctx.save(); ctx.shadowColor = '#fde047'; ctx.shadowBlur = 14;
          const g = ctx.createRadialGradient(x - 3, y - 3, 1, x, y, 9); g.addColorStop(0, '#fffbeb'); g.addColorStop(0.5, '#facc15'); g.addColorStop(1, '#a16207');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 8, 0, Math.PI * 2); ctx.fill(); ctx.restore();
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => { alive = false; cancelAnimationFrame(raf); };
  }, [data]);

  useEffect(() => {
    let live = true;
    const f = () => fast || skip.current;
    (async () => {
      fx.voice?.('drop_intro');
      await wait(1500, f());
      for (const d of data.drops) {
        if (!live) return;
        st.current.factor = d.factor; setFactor(d.factor); st.current.hit = null;
        setMsg(d.factor > 1 ? `Every prize is now ×${d.factor}. Dropping again…` : 'Dropping the puck…');
        // the puck: to the gate, then row by row with a little bounce
        const pts = [{ x: COL(d.start), y: 18 }];
        let c = d.start;
        d.steps.forEach((step, r) => { c += step; pts.push({ x: COL(c), y: ROW(r) + 22 }); });
        pts.push({ x: COL(d.slot), y: H - 36 });
        fx.sfx?.('drop');
        const seg = f() ? 90 : 170;
        for (let i = 1; i < pts.length; i++) {
          const a = pts[i - 1], b = pts[i];
          const t0 = performance.now();
          await new Promise((res) => {
            const step = (now) => {
              const u = Math.min(1, (now - t0) / seg);
              const hop = Math.sin(u * Math.PI) * 7;
              st.current.puck = { x: a.x + (b.x - a.x) * u, y: a.y + (b.y - a.y) * (u * u) - hop * (i < pts.length - 1 ? 1 : 0) };
              if (u < 1 && live) requestAnimationFrame(step); else res();
            };
            requestAnimationFrame(step);
          });
          if (i < pts.length - 1) fx.sfx?.('peg', { gain: 0.25, rate: 0.9 + Math.random() * 0.3 });
        }
        if (!live) return;
        st.current.hit = d.slot; setLanded(d.slot); fx.sfx?.('land');
        if (data.board[d.slot] === 'D') { fx.sfx?.('double'); fx.voice?.('double'); setMsg('DOUBLE! Every prize doubles.'); await wait(1500, f()); st.current.puck = null; }
      }
      const x = final ?? data.x * boost;
      setResult(x); setMsg('');
      if (!watched) { fx.sfx?.('win'); fx.voice?.(x >= 100 ? 'big' : 'nice'); }
      await wait(2400, f());
      if (live) onDone();
    })();
    return () => { live = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <BonusFrame id="drop" bet={bet} boost={boost} watched={watched} result={watched ? null : result} onSkip={() => { skip.current = true; }}>
      <div className="relative" style={{ width: `min(100%, calc(min(58vh, 520px) * ${W / H}))`, aspectRatio: `${W}/${H}` }}>
        <canvas ref={cv} className="block h-full w-full" />
        {factor > 1 && <span className="fl-pop absolute right-2 top-2 rounded-md bg-amber-300 px-2 font-display text-lg text-amber-950">×{factor}</span>}
      </div>
      <div className="mt-1 h-5 font-cond text-sm font-bold uppercase tracking-wider text-fuchsia-100">{msg}{result != null ? <span className="fl-pop text-amber-200">{watched ? `Landed on ${result}x` : `${result}x!`}</span> : null}{landed == null ? '' : ''}</div>
    </BonusFrame>
  );
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
