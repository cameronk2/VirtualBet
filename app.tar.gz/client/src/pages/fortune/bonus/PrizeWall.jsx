// Prize Wall: 108 covered prizes. The player aims at one before the timer ends; then every
// prize is uncovered. The prizes were drawn by the server before the wall appeared.
import { useEffect, useMemo, useRef, useState } from 'react';
import { BonusFrame, wait } from './common.jsx';

const SYMBOLS = ['★', '♛', '♦', '♣', '♥', '♠', '✦', '☘'];
const SYM_COL = ['#fde047', '#fbbf24', '#38bdf8', '#4ade80', '#fb7185', '#c4b5fd', '#f0abfc', '#86efac'];
const PICK_SECS = 15;

/** run(pickIndex) resolves to { pick, values, base, x }. `known` is set when the player is only watching. */
export default function PrizeWall({ boost, bet, watched, known, fast, fx, run, onDone }) {
  const [phase, setPhase] = useState('shuffle');
  const [aim, setAim] = useState(null);
  const [left, setLeft] = useState(PICK_SECS);
  const [res, setRes] = useState(null);
  const [shown, setShown] = useState(0);
  const locked = useRef(false);
  const order = useMemo(() => Array.from({ length: 108 }, (_, i) => (i * 37 + 11) % 108), []);
  const sym = (i) => (i * 5 + (i >> 3)) % SYMBOLS.length;

  useEffect(() => {
    let live = true;
    (async () => {
      fx.voice?.('wall_intro');
      fx.sfx?.('shuffle');
      await wait(2200, fast);
      if (!live) return;
      if (watched) {
        setPhase('aim');
        await wait(900, fast);
        setAim(known.pick); fx.sfx?.('aim');
        await wait(900, fast);
        if (live) lock(known.pick, known);
        return;
      }
      setPhase('aim'); fx.voice?.('wall_pick');
    })();
    return () => { live = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // countdown while aiming (the player's own pick only)
  useEffect(() => {
    if (phase !== 'aim' || watched) return;
    if (left <= 0) { lock(aim ?? Math.floor(Math.random() * 108)); return; }
    if (left <= 3) fx.sfx?.('tick');
    const t = setTimeout(() => setLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, left]); // eslint-disable-line react-hooks/exhaustive-deps

  async function lock(i, pre) {
    if (locked.current) return;
    locked.current = true;
    setAim(i); setPhase('locked'); fx.sfx?.('lock');
    const r = pre || await run(i);
    if (!r) { onDone(); return; }
    setRes(r);
    await wait(700, fast);
    setPhase('reveal');
    // uncover in a sweep, the chosen prize last
    const steps = 12;
    for (let k = 1; k <= steps; k++) { setShown(k / steps); fx.sfx?.('flipTile', { rate: 0.9 + k / 30, gain: 0.35 }); await wait(fast ? 60 : 110, false); }
    await wait(600, fast);
    setPhase('done'); fx.sfx?.('reveal');
    if (!watched) { fx.sfx?.('win'); fx.voice?.(r.x >= 100 ? 'big' : 'nice'); }
    await wait(2600, fast);
    onDone();
  }

  const top = res ? Math.max(...res.values) : 0;
  return (
    <BonusFrame id="wall" bet={bet} boost={boost} watched={watched} result={phase === 'done' && !watched ? res?.x : null}
      footer={phase === 'aim' && !watched ? (
        <div className="flex w-full items-center justify-between gap-2">
          <span className="text-left text-xs text-white/80">{aim == null ? 'Tap a prize to aim at it' : 'Aiming. Tap another to change.'}</span>
          <span className={`font-cond text-lg font-bold tabular-nums ${left <= 3 ? 'text-rose-300' : 'text-white'}`}>{left}s</span>
          <button type="button" disabled={aim == null} onClick={() => lock(aim)} className="rounded-full bg-amber-300 px-4 py-1.5 text-sm font-extrabold text-amber-950 disabled:opacity-40">Lock in</button>
        </div>
      ) : phase === 'done' && res ? (
        watched ? <span className="text-white/80">The prize picked was <b className="text-amber-200">{res.x}x</b> · highest on the wall {top * (boost || 1)}x</span>
          : <span className="fl-pop font-cond text-xl font-extrabold text-amber-200">{res.x}x · highest on the wall was {top * (boost || 1)}x</span>
      ) : null}>
      <div className={`grid w-full max-w-[560px] grid-cols-12 gap-[3px] ${phase === 'shuffle' ? 'fl-shuffle' : ''}`}>
        {order.map((_, i) => {
          const open = phase === 'reveal' || phase === 'done' ? (i === aim ? phase === 'done' : ((i * 29) % 108) / 108 < shown) : false;
          const v = res?.values?.[i];
          const mine = i === aim;
          return (
            <button key={i} type="button" disabled={phase !== 'aim' || watched} onClick={() => { setAim(i); fx.sfx?.('aim'); }}
              className={`relative aspect-square rounded-[5px] text-center transition-transform duration-200 ${mine ? 'z-10 scale-125 ring-2 ring-amber-300 shadow-[0_0_14px_#fbbf24]' : ''} ${open ? 'bg-[linear-gradient(180deg,#14532d,#052e16)]' : 'bg-[linear-gradient(180deg,#22c55e,#166534)] active:scale-90'}`}
              aria-label={open ? `${v * (boost || 1)}x` : `Prize ${i + 1}`}>
              {open ? <span className={`absolute inset-0 flex items-center justify-center font-cond text-[9px] font-extrabold leading-none sm:text-xs ${mine ? 'text-amber-200' : v >= 100 ? 'text-amber-300' : 'text-white/85'}`}>{v * (boost || 1)}</span>
                : <span className="absolute inset-0 flex items-center justify-center text-[10px] leading-none sm:text-sm" style={{ color: SYM_COL[sym(i)] }}>{SYMBOLS[sym(i)]}</span>}
              {mine && phase !== 'done' && <span className="pointer-events-none absolute -inset-1 rounded-md border-2 border-amber-200 fl-aim" />}
            </button>
          );
        })}
      </div>
      {phase === 'shuffle' && <div className="mt-2 font-cond text-sm font-bold uppercase tracking-widest text-emerald-200">Shuffling the prizes…</div>}
      {phase === 'locked' && <div className="mt-2 font-cond text-sm font-bold uppercase tracking-widest text-amber-200">Locked in!</div>}
    </BonusFrame>
  );
}
