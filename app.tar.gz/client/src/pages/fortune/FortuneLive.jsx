// Fortune Live – an original money-wheel game show in an animated virtual studio.
// Each round: bets close → Fortune Booster → the wheel → a number win or one of four bonus games.
// The server settles every round before anything moves; Prize Wall and Fortune Frenzy wait for
// the player's choice. Nothing here is a live stream: the studio, host and wheel are animated.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BigWin, PremiumShell, RecentList, SidePanel, sleep, usePremium } from '../../components/Premium.jsx';
import { money } from '../../lib/format.js';
import { setMusicScene } from '../../lib/sound.js';
import { BONUS_IDS, BONUS_MAX_X, BOOST_CHANCE, NUMBER_IDS, SPOTS, SPOT_IDS, SPOT_MAX, SPOT_MIN, WHEEL } from '../../../../server/games/fortune/config.js';
import { boosterChance, segmentsOf, spotRtp } from '../../../../server/games/fortune/maths.js';
import MainWheel from './MainWheel.jsx';
import Booster from './Booster.jsx';
import { SpotIcon } from './icons.jsx';
import { SEG_STYLE } from './canvasWheel.js';
import { preloadFortune, sfx, sting, voice } from './audio.js';
import LINES from './lines.json';
import CoinToss from './bonus/CoinToss.jsx';
import PrizeWall from './bonus/PrizeWall.jsx';
import DropZone from './bonus/DropZone.jsx';
import Frenzy from './bonus/Frenzy.jsx';

const CHIPS = [10, 50, 100, 500, 1000, 2500];
const CHIP_STYLE = { 10: 'from-slate-200 to-slate-400 text-slate-900', 50: 'from-sky-300 to-sky-600 text-white', 100: 'from-emerald-300 to-emerald-600 text-white', 500: 'from-fuchsia-300 to-fuchsia-600 text-white', 1000: 'from-amber-200 to-amber-500 text-amber-950', 2500: 'from-rose-300 to-rose-600 text-white' };
const chipLabel = (v) => (v >= 100 ? `£${v / 100}` : `${v}p`);
const TIMERS = [0, 10, 15, 25];
const pref = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } };
const pct = (x) => `${(x * 100).toFixed(2)}%`;

// ── studio scenery ──
function Studio() {
  const lights = useMemo(() => Array.from({ length: 14 }, (_, i) => ({ x: 4 + i * 7, d: `${(i % 5) * 0.4}s`, c: ['#f472b6', '#facc15', '#38bdf8', '#a78bfa'][i % 4] })), []);
  return (
    <>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_30%,#3b0764_0%,#1e0b3a_40%,#08030f_80%)]" />
      <div className="fl-led absolute inset-x-0 top-0 h-[38%] opacity-60" />
      {lights.map((l, i) => <span key={i} className="fl-beam absolute top-0 h-[70%] w-[9%] origin-top" style={{ left: `${l.x}%`, animationDelay: l.d, '--c': l.c }} />)}
      <svg viewBox="0 0 400 60" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-[16%] w-full" aria-hidden="true">
        {Array.from({ length: 34 }, (_, i) => <ellipse key={i} cx={6 + i * 12} cy={60 - (i % 3) * 2} rx="7" ry="11" fill="#05010a" opacity=".9" />)}
        {Array.from({ length: 34 }, (_, i) => <circle key={`h${i}`} cx={6 + i * 12} cy={44 - (i % 3) * 2} r="5" fill="#05010a" />)}
      </svg>
      <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/70 to-transparent" />
    </>
  );
}

// ── the host: an animated presenter graphic, captions for every line ──
function Host({ talking, caption }) {
  return (
    <div className="pointer-events-none absolute bottom-1 left-1 z-10 flex items-end gap-1 sm:bottom-2 sm:left-2">
      <svg viewBox="0 0 60 70" className="h-14 w-12 drop-shadow-[0_4px_8px_rgba(0,0,0,.6)] sm:h-20 sm:w-16" aria-hidden="true">
        <path d="M8 70c0-16 10-24 22-24s22 8 22 24z" fill="#be185d" /><path d="M24 48l6 10 6-10z" fill="#fde68a" />
        <path d="M14 26c0-14 8-20 16-20s16 6 16 20c0 6-2 10-2 14H16c0-4-2-8-2-14z" fill="#3b1d0f" />
        <ellipse cx="30" cy="28" rx="11" ry="13" fill="#f2c9a5" />
        <path d="M19 22c4-8 18-10 22 2-6-4-14-6-22-2z" fill="#3b1d0f" />
        <circle cx="26" cy="27" r="1.4" fill="#1f1308" /><circle cx="34" cy="27" r="1.4" fill="#1f1308" />
        <ellipse cx="30" cy="35" rx="3.2" ry={talking ? 2.4 : 0.8} fill="#9f1239" className={talking ? 'fl-talk' : ''} />
        <circle cx="19" cy="31" r="1.6" fill="#fde047" /><circle cx="41" cy="31" r="1.6" fill="#fde047" />
      </svg>
      {caption && <div className="fl-pop mb-6 max-w-[58vw] rounded-xl rounded-bl-none bg-white/95 px-2.5 py-1 text-[11px] font-semibold leading-snug text-slate-900 shadow-lg sm:max-w-xs sm:text-xs">{caption}</div>}
    </div>
  );
}

function Spot({ id, amount, onClick, disabled, boost, win, lost, winning }) {
  const s = SPOTS[id], st = SEG_STYLE[id];
  const num = s.kind === 'number';
  return (
    <button type="button" onClick={onClick} disabled={disabled}
      className={`relative flex min-h-[64px] flex-col items-center justify-center overflow-visible rounded-xl p-1 text-center ring-2 transition-all active:scale-95 disabled:cursor-not-allowed ${winning ? 'fl-winner z-10 scale-105 ring-amber-200' : lost ? 'opacity-55 ring-white/10' : 'ring-white/25'}`}
      style={{ background: `linear-gradient(180deg, ${st.a}, ${st.b})` }}
      aria-label={`${s.name}: ${amount ? `bet ${money(amount)}` : 'no bet'}. Tap to add a chip.`}>
      <span className="pointer-events-none absolute inset-x-1 top-0.5 h-1/3 rounded-t-lg bg-gradient-to-b from-white/35 to-transparent" />
      {boost > 1 && <span className="fl-pop absolute -right-1.5 -top-2.5 z-10 rounded-md bg-[linear-gradient(180deg,#fff7c2,#facc15)] px-1.5 font-display text-sm text-amber-950 shadow-[0_0_12px_#facc15]">{boost}x</span>}
      <SpotIcon id={id} className={num ? 'h-8 w-8' : 'h-7 w-7'} />
      <div className={`mt-0.5 font-cond text-[11px] font-extrabold uppercase leading-none tracking-wide ${num ? 'text-black/70' : 'text-white'}`}>{num ? `Pays ${s.pay}:1` : s.name}</div>
      {amount > 0 && <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-black/80 px-2 text-[11px] font-bold tabular-nums text-white ring-1 ring-amber-300/60">{money(amount)}</div>}
      {win > 0 && <div className="fl-pop absolute inset-x-0.5 top-0.5 rounded bg-emerald-500/95 text-[10px] font-bold text-white">+{money(win)}</div>}
    </button>
  );
}

function TimerRing({ left, total, label }) {
  const r = 17, c = 2 * Math.PI * r, frac = total ? Math.max(0, left) / total : 0;
  const hot = total && left <= 3;
  return (
    <div className="flex items-center gap-2">
      <svg viewBox="0 0 40 40" className="h-10 w-10 -rotate-90" aria-hidden="true">
        <circle cx="20" cy="20" r={r} fill="rgba(0,0,0,.5)" stroke="rgba(255,255,255,.15)" strokeWidth="4" />
        <circle cx="20" cy="20" r={r} fill="none" stroke={hot ? '#fb7185' : '#4ade80'} strokeWidth="4" strokeDasharray={c} strokeDashoffset={c * (1 - frac)} strokeLinecap="round" style={{ transition: 'stroke-dashoffset 1s linear' }} />
        <text x="20" y="25" textAnchor="middle" transform="rotate(90 20 20)" fontSize="13" fontWeight="800" fill="#fff" fontFamily="Barlow Condensed">{total ? Math.max(0, left) : '∞'}</text>
      </svg>
      <div className="font-cond text-sm font-extrabold uppercase leading-tight tracking-wider text-white [text-shadow:0_1px_3px_#000]">{label}</div>
    </div>
  );
}

export default function FortuneLive() {
  const { user, view, history, play, commit, guard, shake, doShake } = usePremium('fortune');
  const [chip, setChip] = useState(() => pref('fl_chip', 100));
  const [bets, setBets] = useState({});
  const [undo, setUndo] = useState([]);
  const [last, setLast] = useState(() => pref('fl_last', null));
  const [phase, setPhase] = useState('bets');
  const [timerLen, setTimerLen] = useState(() => pref('fl_timer', 15));
  const [left, setLeft] = useState(timerLen);
  const [fast, setFast] = useState(() => pref('fl_fast', false));
  const [roll, setRoll] = useState(null);
  const [boostShown, setBoostShown] = useState(null);
  const [glow, setGlow] = useState(null);
  const [res, setRes] = useState(null);
  const [bonus, setBonus] = useState(null);
  const [banner, setBanner] = useState(null);
  const [big, setBig] = useState(null);
  const [caption, setCaption] = useState('');
  const [talking, setTalking] = useState(false);
  const [round, setRound] = useState(() => pref('fl_round', 1));
  const wheel = useRef(null), boosterDone = useRef(null), bonusDone = useRef(null), stageRef = useRef(null);
  const capTimer = useRef(0);
  const balance = user?.balance ?? 0;
  const total = Object.values(bets).reduce((a, b) => a + b, 0);
  const busy = phase !== 'bets';

  useEffect(() => { preloadFortune(); }, []);
  useEffect(() => { setMusicScene('fortune', bonus ? 'bonus' : 'base'); }, [!!bonus]); // eslint-disable-line react-hooks/exhaustive-deps

  /** Host speaks (recorded voice when available) and the caption shows the words. */
  const say = useCallback((key, opts) => {
    const takes = Object.keys(LINES).filter((k) => k === key || new RegExp(`^${key}_\\d+$`).test(k));
    if (!takes.length) return;
    const k = takes[Math.floor(Math.random() * takes.length)];
    setCaption(LINES[k]); setTalking(true);
    voice(k, opts);
    clearTimeout(capTimer.current);
    capTimer.current = setTimeout(() => { setTalking(false); setTimeout(() => setCaption(''), 900); }, Math.min(3800, 900 + LINES[k].length * 55));
  }, []);
  const fx = useMemo(() => ({ sfx, voice: (k) => say(k) }), [say]);

  // greet once
  useEffect(() => { const t = setTimeout(() => say('welcome'), 900); return () => clearTimeout(t); }, [say]);

  // a bonus left waiting (page reloaded mid-pick): reopen it
  const resumed = useRef(false);
  useEffect(() => {
    const p = view?.pending;
    if (!p || resumed.current || phase !== 'bets') return;
    resumed.current = true;
    wheel.current?.show(p.segment);
    setBets(p.bets || {}); setBoostShown(p.boost > 1 ? { spot: p.bonus, mult: p.boost } : null);
    guard(async () => { setPhase('bonus'); await runBonus({ landed: p.bonus, boost: p.boost, pending: p, results: Object.fromEntries(Object.entries(p.bets || {}).map(([k, v]) => [k, { bet: v, ret: 0 }])), done: false }); });
  }, [view?.pending]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── betting ──
  const add = (id, amt = chip) => {
    if (busy) return;
    setBets((b) => {
      const v = Math.min(SPOT_MAX, (b[id] || 0) + amt);
      const next = { ...b, [id]: v };
      if (Object.values(next).reduce((a, x) => a + x, 0) > balance) return b;
      setUndo((u) => [...u.slice(-30), b]);
      return next;
    });
    sfx('chip', { gain: 0.6, rate: 0.9 + Math.random() * 0.2 });
  };
  const addMany = (ids) => { if (busy) return; setBets((b) => { const n = { ...b }; for (const id of ids) n[id] = Math.min(SPOT_MAX, (n[id] || 0) + chip); if (Object.values(n).reduce((a, x) => a + x, 0) > balance) return b; setUndo((u) => [...u.slice(-30), b]); return n; }); sfx('chip'); };
  const double = () => setBets((b) => { const n = Object.fromEntries(Object.entries(b).map(([k, v]) => [k, Math.min(SPOT_MAX, v * 2)])); if (Object.values(n).reduce((a, x) => a + x, 0) > balance) return b; setUndo((u) => [...u, b]); return n; });
  const rebet = () => { if (!last) return; if (Object.values(last).reduce((a, x) => a + x, 0) > balance) return; setUndo((u) => [...u, bets]); setBets(last); sfx('chip'); };
  const doUndo = () => setUndo((u) => { if (!u.length) return u; setBets(u[u.length - 1]); return u.slice(0, -1); });

  // ── the betting timer ──
  useEffect(() => { if (phase === 'bets') setLeft(timerLen); }, [phase, timerLen]);
  const goRef = useRef(null);
  useEffect(() => {
    if (phase !== 'bets' || !timerLen) return;
    if (left <= 0) {
      if (total > 0 && total <= balance) goRef.current?.();
      else setLeft(timerLen);   // nobody's in: the betting window simply opens again
      return;
    }
    if (left === 4 && total > 0) say('last');
    if (left <= 3 && total > 0) sfx('tick', { gain: 0.5 });
    const t = setTimeout(() => setLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, left, timerLen]); // eslint-disable-line react-hooks/exhaustive-deps

  const wt = (ms) => sleep(fast ? ms * 0.5 : ms);

  // ── one round ──
  const go = () => guard(async () => {
    if (!total || total > balance || phase !== 'bets') return;
    const placed = bets;
    setPhase('closing'); setRes(null); setGlow(null); setBoostShown(null); setBanner(null);
    say('nomore'); sfx('nomore');
    await wt(900);
    const out = await play('spin', { bets: placed });
    if (!out) { setPhase('bets'); return; }
    setLast(placed); save('fl_last', placed); setUndo([]);
    setRound((r) => { save('fl_round', r + 1); return r + 1; });
    // 1. the booster
    setPhase('boost'); say('booster');
    await new Promise((r) => { boosterDone.current = r; setRoll({ ...out.booster, id: Date.now() }); sfx('reel', { gain: 0.6 }); });
    if (out.booster.hit) { setBoostShown({ spot: out.booster.spot, mult: out.booster.mult }); sfx('boost'); say('boosthit'); await wt(1100); }
    await wt(300);
    // 2. the wheel
    setPhase('spin'); say('spin');
    if (window.innerWidth < 768) stageRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    sfx('spin', { gain: 0.7 });
    await wheel.current.spin(out.segment, fast ? 3600 : 7000, fast ? 3 : 5);
    setGlow({ seg: out.segment, colour: SEG_STYLE[out.landed].a });
    sfx('land');
    say(out.landed);
    await wt(700);
    // 3. a number, or a bonus game
    if (SPOTS[out.landed].kind === 'bonus') {
      setPhase('bonus');
      await runBonus(out);
    } else {
      finish(out);
    }
  });
  goRef.current = go;

  async function runBonus(out) {
    const id = out.landed;
    pickRef.current = null;
    const watched = !(out.results?.[id]?.bet > 0) && !out.pending;
    setBanner({ id, watched });
    sfx('bonus'); doShake(false);
    await wt(1800);
    setBanner(null);
    if (watched) say('watch');
    // the bonus scene runs; it resolves with the final round result
    const final = await new Promise((resolve) => {
      bonusDone.current = resolve;
      setBonus({ id, out, watched });
    });
    setBonus(null);
    finish(final || out);
  }

  // Prize Wall / Frenzy: the player's choice is sent here; the reply settles the round
  const pickRef = useRef(null);
  const sendPick = useCallback(async (pick) => {
    const out = await play('pick', { pick });
    if (!out) return null;
    pickRef.current = out;
    return out[out.landed];
  }, [play]);

  function finish(o) {
    // a Prize Wall / Frenzy pick takes no new stake, so the round's stake comes from its bets
    const staked = Object.values(o.results || {}).reduce((a, r) => a + r.bet, 0);
    const out = { ...o, staked };
    setRes(out); setPhase('result');
    commit();
    const win = out.payout ?? out.win ?? 0;
    if (win > 0) {
      if (win >= staked * 20) { setBig({ amount: win, bet: staked }); sting(); }
      else { sfx('win'); sfx('cheer', { gain: 0.5 }); }
      if (SPOTS[out.landed].kind === 'number') say(win >= staked * 10 ? 'big' : 'win');
    } else if (staked > 0) { say('lose'); }
    setTimeout(() => { setPhase('bets'); setGlow(null); say('bets'); }, fast ? 1600 : 3000);
  }

  // space bar: spin now
  useEffect(() => {
    const h = (e) => { if (e.code === 'Space' && !e.repeat && !['INPUT', 'TEXTAREA', 'BUTTON'].includes(e.target.tagName)) { e.preventDefault(); if (big) setBig(null); else goRef.current?.(); } };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [big]);

  const hist = view?.history || [];
  const stats = view?.stats || {};
  const boostFor = (id) => (boostShown?.spot === id ? boostShown.mult : 0);
  const statusLabel = phase === 'bets' ? (total ? 'Bets open' : timerLen ? 'Place your bets' : 'Place bets, then spin')
    : phase === 'closing' ? 'No more bets' : phase === 'boost' ? 'Fortune Booster' : phase === 'spin' ? 'Spinning…' : phase === 'bonus' ? 'Bonus game' : phase === 'result' ? 'Next round soon' : '';

  const info = (
    <>
      <section className="space-y-2">
        <h3 className="font-bold text-white">How to play</h3>
        <p>Fortune Live is a money-wheel game show. Put chips on any of the eight spots before the betting timer runs out (or tap <b>Spin now</b>). The 54-segment wheel then spins and the segment under the pointer wins.</p>
        <p><b>Numbers</b> pay their number to 1: <b>1</b> pays 1:1, <b>2</b> pays 2:1, <b>5</b> pays 5:1 and <b>10</b> pays 10:1. Your bet is returned as well.</p>
        <p><b>Fortune Booster</b>: before every spin, two reels pick a spot and a multiplier (2x to 50x). When they line up, that spot is boosted for the round: a boosted number pays its number times the booster, and a boosted bonus game multiplies its whole result. On about {Math.round(boosterChance() * 100)}% of rounds the booster lines up on something.</p>
        <p><b>Bonus games</b> pay a multiplier of your bet on that bonus (plus the bet back). Only bets on the bonus that lands take part; everyone else watches.</p>
        <ul className="list-disc space-y-1 pl-5">
          <li><b>Coin Toss</b>: the red and blue sides each get a multiplier, then the coin is flipped.</li>
          <li><b>Prize Wall</b>: 108 hidden prizes. You aim at one before the timer ends (15 seconds); every prize is then uncovered and you win the one you picked. If you don't choose, one is picked for you.</li>
          <li><b>Drop Zone</b>: a puck falls through the pegs into one of 16 prize slots. Two slots say DOUBLE: every prize on the board doubles and the puck drops again.</li>
          <li><b>Fortune Frenzy</b>: a 64-segment wheel of prizes with three flappers. Choose green, blue or yellow; the wheel spins and your flapper's segment pays. DOUBLE and TRIPLE multiply every prize and spin again.</li>
        </ul>
        <p>Each bonus pays at most {BONUS_MAX_X.toLocaleString()}x your bet on it. Bets {money(SPOT_MIN)} to {money(SPOT_MAX)} per spot. If you leave during a Prize Wall or Fortune Frenzy pick, it waits for you.</p>
      </section>
      <section>
        <h3 className="mb-2 font-bold text-white">Wheel, odds and return to player</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-400"><tr><th className="py-1 pr-2">Spot</th><th className="pr-2">Segments</th><th className="pr-2">Chance</th><th className="pr-2">Pays</th><th className="pr-2">Booster</th><th>RTP</th></tr></thead>
            <tbody className="text-slate-200">
              {SPOT_IDS.map((id) => (
                <tr key={id} className="border-t border-white/10">
                  <td className="py-1 pr-2">{SPOTS[id].kind === 'number' ? `Number ${SPOTS[id].name}` : SPOTS[id].name}</td>
                  <td>{segmentsOf(id)}</td><td>1 in {(54 / segmentsOf(id)).toFixed(1)}</td>
                  <td>{SPOTS[id].kind === 'number' ? `${SPOTS[id].pay}:1` : 'bonus'}</td>
                  <td>{(BOOST_CHANCE[id] * 100).toFixed(1)}%</td><td>{pct(spotRtp(id))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-slate-400">Every spot returns {pct(spotRtp('n1'))} over the long run, worked out exactly from the game's tables (the bonus cap moves this by less than 0.05%). "Booster" is the chance that the booster lines up on that spot in a round.</p>
      </section>
      <section className="rounded-lg border border-fuchsia-400/30 bg-fuchsia-400/5 p-3 text-xs text-slate-300">
        <b className="text-fuchsia-200">About this game</b>: Fortune Live is an original game in the style of TV money-wheel shows. It is <b>not a live stream</b>: the studio, host and wheel are animated in your browser, and every result comes from the server's random number generator before the wheel moves. It isn't affiliated with any live-casino studio. Virtual money only.
      </section>
    </>
  );

  const B = bonus;
  const out = B?.out;
  const betOn = out ? (out.results?.[B.id]?.bet || 0) : 0;
  const shownStats = SPOT_IDS.map((id) => ({ id, n: stats[id] || 0 }));
  const rounds = stats.rounds || 0;

  return (
    <PremiumShell game="fortune" rtp="96%" tagline="Game-show wheel · Fortune Booster · 4 bonus games · animated studio" shake={shake}
      stageClass="border-2 border-fuchsia-300/40 shadow-[0_0_60px_rgba(217,70,239,0.25)]" bg={<Studio />} info={info} popout={false}
      below={bonus ? null : (
        <div className="card sticky bottom-[calc(80px+env(safe-area-inset-bottom))] z-30 space-y-2 p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] md:static md:shadow-none">
          <div className="flex items-center justify-between gap-1 px-0.5 pt-0.5" role="radiogroup" aria-label="Chip value">
            {CHIPS.map((c) => (
              <button key={c} type="button" role="radio" aria-checked={chip === c} onClick={() => { setChip(c); save('fl_chip', c); }} disabled={c > balance}
                className={`h-10 w-10 shrink-0 rounded-full bg-gradient-to-b text-[11px] font-extrabold shadow ring-2 ring-white/30 disabled:opacity-30 ${CHIP_STYLE[c]} ${chip === c ? 'scale-110 ring-4 ring-fuchsia-200' : ''}`}>{chipLabel(c)}</button>
            ))}
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            <button className="h-9 rounded-lg bg-navy-700 text-xs font-semibold text-slate-200 disabled:opacity-40" disabled={busy || !undo.length} onClick={doUndo}>Undo</button>
            <button className="h-9 rounded-lg bg-navy-700 text-xs font-semibold text-slate-200 disabled:opacity-40" disabled={busy || !total} onClick={() => { setUndo((u) => [...u, bets]); setBets({}); }}>Clear</button>
            <button className="h-9 rounded-lg bg-navy-700 text-xs font-semibold text-slate-200 disabled:opacity-40" disabled={busy || !total} onClick={double}>Double</button>
            <button className="h-9 rounded-lg bg-navy-700 text-xs font-semibold text-slate-200 disabled:opacity-40" disabled={busy || !last || total > 0} onClick={rebet}>Rebet</button>
          </div>
          <div className="flex items-center gap-2">
            <div className="min-w-[5.5rem] leading-tight"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Total bet</div><div className="font-cond text-lg font-bold tabular-nums text-white">{money(total)}</div></div>
            <button onClick={go} disabled={busy || !total || total > balance} className="btn h-14 flex-1 rounded-full bg-[linear-gradient(180deg,#f9a8d4,#db2777)] text-lg font-extrabold text-white shadow-lg [text-shadow:0_1px_2px_rgba(0,0,0,.4)] active:scale-95 disabled:opacity-50">
              {busy ? statusLabel : !total ? 'Place a bet' : total > balance ? 'Not enough balance' : timerLen ? `Spin now · ${left}s` : 'Spin'}
            </button>
            <button onClick={() => { const v = !fast; setFast(v); save('fl_fast', v); }} className={`h-11 rounded-lg px-3 text-xs font-semibold ${fast ? 'bg-fuchsia-300 text-fuchsia-950' : 'bg-navy-700 text-slate-200'}`} aria-pressed={fast}>Quick</button>
          </div>
          <div className="flex items-center justify-between gap-2 text-[11px] text-slate-400">
            <span>Betting timer</span>
            <div className="flex gap-1" role="radiogroup" aria-label="Betting timer">
              {TIMERS.map((s) => <button key={s} role="radio" aria-checked={timerLen === s} onClick={() => { setTimerLen(s); save('fl_timer', s); }} className={`rounded-md px-2 py-0.5 font-semibold ${timerLen === s ? 'bg-fuchsia-500 text-white' : 'bg-navy-700 text-slate-300'}`}>{s ? `${s}s` : 'Off'}</button>)}
            </div>
          </div>
        </div>
      )}
      side={<>
        <SidePanel title="Last results">
          <ResultsStrip hist={hist} />
        </SidePanel>
        <SidePanel title={`Your wheel stats · ${rounds} spins`}>
          <div className="space-y-1">
            {shownStats.map(({ id, n }) => (
              <div key={id} className="flex items-center gap-2 text-xs">
                <SpotIcon id={id} className="h-5 w-5" />
                <div className="h-2 flex-1 overflow-hidden rounded bg-white/10"><div className="h-full rounded" style={{ width: `${rounds ? (n / rounds) * 100 : 0}%`, background: SEG_STYLE[id].a }} /></div>
                <span className="w-16 text-right tabular-nums text-slate-300">{rounds ? `${((n / rounds) * 100).toFixed(0)}%` : '–'} <span className="text-slate-500">/{((segmentsOf(id) / 54) * 100).toFixed(0)}%</span></span>
              </div>
            ))}
            <p className="pt-1 text-[10px] text-slate-500">Your share of spins vs the wheel's chance. Every spin is independent.</p>
          </div>
        </SidePanel>
        <SidePanel title="Win history"><RecentList history={history} /></SidePanel>
      </>}>
      <div ref={stageRef} className="relative scroll-mt-24">
        {/* top bar: honest label, round, status */}
        <div className="flex items-center justify-between gap-2 px-1 pb-1">
          <TimerRing left={phase === 'bets' ? left : 0} total={phase === 'bets' ? timerLen : 0} label={statusLabel} />
          <div className="flex flex-col items-end gap-0.5">
            <span className="rounded-full bg-fuchsia-600/90 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-widest text-white ring-1 ring-white/30">Virtual studio</span>
            <span className="text-[10px] font-semibold text-white/60">Round {round.toLocaleString()} · animated, not a stream</span>
          </div>
        </div>
        <div className="relative z-10 mb-1 flex justify-center">
          <Booster roll={roll} fast={fast} onStop={() => sfx('reelStop')} onDone={() => boosterDone.current?.()} />
        </div>
        <div className="relative mx-auto w-full" style={{ maxWidth: 'min(100%, max(260px, calc(100dvh - 430px)), 520px)' }}>
          <Host talking={talking} caption={caption} />
          <MainWheel ref={wheel} glow={glow} onPeg={(v) => { if (!sfx('peg', { gain: Math.min(0.55, 0.2 + 0.25 / Math.max(v, 0.25)), rate: 0.95 + Math.random() * 0.1 })) { /* synth handled */ } }} />
          {banner && (
            <div className="fl-banner absolute inset-x-0 top-1/2 z-20 -translate-y-1/2 text-center">
              <div className="mx-auto inline-flex flex-col items-center rounded-2xl border-2 border-amber-200 bg-[linear-gradient(180deg,#7c2d12,#3b0a2a)] px-5 py-3 shadow-[0_0_40px_rgba(251,191,36,.6)]">
                <SpotIcon id={banner.id} className="h-12 w-12" />
                <span className="font-display text-3xl text-amber-200 [text-shadow:0_3px_0_#3b0a2a]">{SPOTS[banner.id].name}!</span>
                <span className="text-xs font-semibold text-white/80">{banner.watched ? 'No bet on this bonus · watching' : 'You are in this bonus!'}</span>
              </div>
            </div>
          )}
          {res && phase !== 'bonus' && !banner && (
            <div className="pointer-events-none absolute inset-x-0 top-1/2 z-10 flex -translate-y-1/2 justify-center">
              <div className="fl-pop rounded-xl bg-black/75 px-4 py-1.5 text-center ring-1 ring-amber-200/50">
                {res.payout > 0 ? <><div className="font-display text-2xl text-amber-200">{money(res.payout)}</div><div className={`text-[11px] font-semibold ${res.payout > res.staked ? 'text-emerald-300' : 'text-slate-300'}`}>{res.payout > res.staked ? `+${money(res.payout - res.staked)} on ${money(res.staked)}` : res.payout === res.staked ? 'Stake back' : `Returned of ${money(res.staked)} staked`}</div></>
                  : <div className="text-sm font-semibold text-white/80">{SPOTS[res.landed].kind === 'number' ? `It's ${SPOTS[res.landed].name}` : SPOTS[res.landed].name} · no win this time</div>}
              </div>
            </div>
          )}
        </div>
        <ResultsStrip hist={hist} compact />
        <div className="mt-2 grid grid-cols-4 gap-2 pb-2">
          {NUMBER_IDS.map((id) => <Spot key={id} id={id} amount={bets[id]} onClick={() => add(id)} disabled={busy} boost={boostFor(id)} win={res?.results?.[id]?.ret} winning={res?.landed === id} lost={res && res.landed !== id && bets[id] > 0} />)}
          {BONUS_IDS.map((id) => <Spot key={id} id={id} amount={bets[id]} onClick={() => add(id)} disabled={busy} boost={boostFor(id)} win={res?.results?.[id]?.ret} winning={res?.landed === id} lost={res && res.landed !== id && bets[id] > 0} />)}
        </div>
        <div className="grid grid-cols-2 gap-2 pb-1">
          <button type="button" onClick={() => addMany(NUMBER_IDS)} disabled={busy} className="rounded-lg bg-[linear-gradient(90deg,#ca8a04,#0369a1,#be185d,#6d28d9)] py-1.5 text-xs font-extrabold uppercase tracking-wide text-white ring-1 ring-white/30 disabled:opacity-50">All numbers +{chipLabel(chip)}</button>
          <button type="button" onClick={() => addMany(BONUS_IDS)} disabled={busy} className="rounded-lg bg-[linear-gradient(90deg,#1d4ed8,#15803d,#7e22ce,#b91c1c)] py-1.5 text-xs font-extrabold uppercase tracking-wide text-white ring-1 ring-white/30 disabled:opacity-50">All bonuses +{chipLabel(chip)}</button>
        </div>

        {B && B.id === 'toss' && <CoinToss data={out.toss} final={out.x} boost={out.boost} bet={betOn} watched={B.watched} fast={fast} fx={fx} onDone={() => bonusDone.current?.(out)} />}
        {B && B.id === 'drop' && <DropZone data={out.drop} final={out.x} boost={out.boost} bet={betOn} watched={B.watched} fast={fast} fx={fx} onDone={() => bonusDone.current?.(out)} />}
        {B && B.id === 'wall' && <PrizeWall boost={out.boost} bet={betOn} watched={B.watched} known={out.wall} fast={fast} fx={fx} run={sendPick} onDone={() => bonusDone.current?.(B.watched ? out : pickRef.current)} />}
        {B && B.id === 'frenzy' && <Frenzy wheel={out.frenzy?.wheel || out.pending?.wheel} boost={out.boost} bet={betOn} watched={B.watched} known={out.frenzy} fast={fast} fx={fx} run={sendPick} onDone={() => bonusDone.current?.(B.watched ? out : pickRef.current)} />}
        {big && <BigWin game="fortune" amount={big.amount} bet={big.bet} onDone={() => setBig(null)} />}
      </div>
    </PremiumShell>
  );
}

function ResultsStrip({ hist, compact }) {
  if (compact) {
    return (
      <div className="scrollbar-none -mx-1 mt-3 flex gap-1 overflow-x-auto px-1" aria-label="Last results">
        {hist.slice(0, 14).map((h, i) => <Chip key={i} h={h} />)}
        {!hist.length && <span className="text-[11px] text-white/50">Results will appear here</span>}
      </div>
    );
  }
  return <div className="flex flex-wrap gap-1">{hist.length ? hist.slice(0, 30).map((h, i) => <Chip key={i} h={h} />) : <span className="text-xs text-slate-500">No spins yet</span>}</div>;
}
function Chip({ h }) {
  const st = SEG_STYLE[h.landed];
  const num = h.landed.startsWith('n');
  return (
    <span className="flex shrink-0 items-center gap-0.5 rounded-md px-1 py-0.5 text-[10px] font-extrabold" style={{ background: st.b, color: '#fff' }}>
      {num ? <span className="px-0.5 font-display text-xs">{st.label}</span> : <SpotIcon id={h.landed} className="h-4 w-4" />}
      {!num && h.total != null && <span>{h.total}x</span>}
      {h.boost > 1 && <span className="rounded bg-amber-300 px-0.5 text-amber-950">{h.boost}x</span>}
    </span>
  );
}
