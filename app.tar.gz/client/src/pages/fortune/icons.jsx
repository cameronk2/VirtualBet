// Fortune Live emblems: one per bet spot, the logo, and the lobby thumbnail. All original vector art.
import { SEG_STYLE } from './canvasWheel.js';

export function SpotIcon({ id, className = 'h-8 w-8' }) {
  const s = SEG_STYLE[id];
  if (id.startsWith('n')) {
    return (
      <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
        <defs><radialGradient id={`fl-${id}`} cx=".35" cy=".3" r=".8"><stop offset="0" stopColor="#fff" stopOpacity=".9" /><stop offset=".25" stopColor={s.a} /><stop offset="1" stopColor={s.b} /></radialGradient></defs>
        <circle cx="20" cy="20" r="18" fill={`url(#fl-${id})`} stroke="#fff6c9" strokeWidth="2" />
        <text x="20" y="27" textAnchor="middle" fontFamily="'Lilita One',system-ui" fontSize={s.label.length > 1 ? 17 : 21} fill={s.text}>{s.label}</text>
      </svg>
    );
  }
  if (id === 'toss') {
    return (
      <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
        <circle cx="20" cy="20" r="17" fill="#1d4ed8" stroke="#fde68a" strokeWidth="2.5" />
        <path d="M20 3a17 17 0 0 1 0 34z" fill="#dc2626" />
        <circle cx="20" cy="20" r="11" fill="none" stroke="#fde68a" strokeWidth="1.5" strokeDasharray="2 2" />
        <text x="20" y="25" textAnchor="middle" fontFamily="'Lilita One',system-ui" fontSize="14" fill="#fde68a">£</text>
      </svg>
    );
  }
  if (id === 'wall') {
    return (
      <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
        <rect x="3" y="5" width="34" height="30" rx="4" fill="#14532d" stroke="#86efac" strokeWidth="2" />
        {[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={7 + c * 9.5} y={9 + r * 8.5} width="7.5" height="6.5" rx="1.5" fill={r === 1 && c === 1 ? '#fde047' : '#22c55e'} />))}
        <circle cx="20" cy="20" r="6" fill="none" stroke="#fff" strokeWidth="1.6" /><path d="M20 12v4M20 24v4M12 20h4M24 20h4" stroke="#fff" strokeWidth="1.6" />
      </svg>
    );
  }
  if (id === 'drop') {
    return (
      <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
        <rect x="3" y="3" width="34" height="34" rx="5" fill="#3b0764" stroke="#d8b4fe" strokeWidth="2" />
        {[0, 1, 2, 3].map((r) => Array.from({ length: 4 - (r % 2) }, (_, c) => <circle key={`${r}${c}`} cx={9 + c * 7.4 + (r % 2) * 3.7} cy={10 + r * 6} r="1.4" fill="#f5d0fe" />))}
        <circle cx="16.5" cy="7" r="3" fill="#fde047" stroke="#fff" strokeWidth=".8" />
        {['#a855f7', '#f472b6', '#fde047', '#f472b6', '#a855f7'].map((c, i) => <rect key={i} x={5 + i * 6.2} y="31" width="5" height="4" rx="1" fill={c} />)}
      </svg>
    );
  }
  // frenzy
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      {['#ef4444', '#f97316', '#facc15', '#22c55e', '#3b82f6', '#a855f7', '#ef4444', '#f97316', '#facc15', '#22c55e', '#3b82f6', '#a855f7'].map((c, i) => <path key={i} d="M20 20L20 3A17 17 0 0 1 28.5 5.3z" fill={c} transform={`rotate(${i * 30} 20 20)`} />)}
      <circle cx="20" cy="20" r="17" fill="none" stroke="#fde68a" strokeWidth="2" />
      <circle cx="20" cy="20" r="6.5" fill="#1e1b4b" stroke="#fde68a" strokeWidth="1.5" />
      <path d="M20 15.5l1.3 2.8 3 .3-2.3 2 .7 3-2.7-1.6-2.7 1.6.7-3-2.3-2 3-.3z" fill="#fde047" />
    </svg>
  );
}

export function FortuneLogo({ className }) {
  return (
    <svg viewBox="0 0 300 90" className={className} aria-label="Fortune Live">
      <defs>
        <linearGradient id="flLogoG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff7d6" /><stop offset=".45" stopColor="#fbbf24" /><stop offset="1" stopColor="#b45309" /></linearGradient>
        <linearGradient id="flLiveG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#f43f5e" /><stop offset=".5" stopColor="#d946ef" /><stop offset="1" stopColor="#8b5cf6" /></linearGradient>
      </defs>
      <g transform="translate(40 45)">
        {Array.from({ length: 12 }, (_, i) => <path key={i} d="M0 0L0 -30A30 30 0 0 1 15 -26z" fill={['#facc15', '#38bdf8', '#f472b6', '#a78bfa', '#4ade80', '#ef4444'][i % 6]} transform={`rotate(${i * 30})`} />)}
        <circle r="30" fill="none" stroke="#fde68a" strokeWidth="3" /><circle r="9" fill="#2a0f3d" stroke="#fde68a" strokeWidth="2" />
        <path d="M0 -24l-6 -14h12z" fill="#fff" stroke="#78350f" strokeWidth="1.5" />
      </g>
      <text x="186" y="50" textAnchor="middle" fontFamily="'Lilita One'" fontSize="46" textLength="200" lengthAdjust="spacingAndGlyphs" fill="url(#flLogoG)" stroke="#3b0a2a" strokeWidth="3.5" paintOrder="stroke">FORTUNE</text>
      <rect x="128" y="57" width="116" height="26" rx="13" fill="url(#flLiveG)" stroke="#fff" strokeWidth="1.5" />
      <circle cx="145" cy="70" r="5" fill="#fff"><animate attributeName="opacity" values="1;.25;1" dur="1.4s" repeatCount="indefinite" /></circle>
      <text x="194" y="77" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="20" letterSpacing="6" fill="#fff">LIVE</text>
    </svg>
  );
}

export const FORTUNE_LOBBY = (
  <g>
    <circle cx="50" cy="54" r="40" fill="#fde68a" />
    {Array.from({ length: 18 }, (_, i) => <path key={i} d="M50 54L50 17A37 37 0 0 1 62.7 19.2z" fill={['#facc15', '#38bdf8', '#facc15', '#f472b6', '#4ade80', '#38bdf8', '#facc15', '#a78bfa', '#ef4444'][i % 9]} transform={`rotate(${i * 20} 50 54)`} />)}
    <circle cx="50" cy="54" r="12" fill="#2a0f3d" stroke="#fde68a" strokeWidth="2.5" />
    <text x="50" y="58" textAnchor="middle" fontFamily="'Lilita One',system-ui" fontSize="7.5" fill="#fde047">LIVE</text>
    <path d="M50 22l-6-12h12z" fill="#fff" stroke="#78350f" strokeWidth="1.5" />
    {[[14, 14], [86, 18], [12, 88], [88, 86]].map(([x, y], i) => <path key={i} d={`M${x} ${y - 6}l1.8 4.2 4.2 1.8-4.2 1.8-1.8 4.2-1.8-4.2-4.2-1.8 4.2-1.8z`} fill="#fff" opacity=".9" />)}
  </g>
);
