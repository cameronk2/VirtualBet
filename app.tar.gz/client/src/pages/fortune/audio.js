// Fortune Live audio (client/audio/fortune, made by tools/music/fortune.py with free tools):
// a studio band loop, a bonus loop, a win sting, one effects sprite and one host-voice sprite
// (Kokoro TTS). Sprites keep the file count small. Falls back to the synthesised effects.
import { playSprite, playSting, playVoiceSprite, preloadUrls, registerTracks, registerVoiceGame, themeSfx } from '../../lib/sound.js';
import { SFX, VOICE } from './sprites.js';

const AUD = typeof __AUDIO__ !== 'undefined' ? __AUDIO__ : { base: '/audio/', files: [] };
const au = (f) => (AUD.files.includes(`fortune/${f}.mp3`) ? `${AUD.base}fortune/${f}.mp3` : null);
const TRACKS = { base: au('music/base'), bonus: au('music/bonus'), win: au('music/win'), jackpot: au('music/win') };
if (TRACKS.base) registerTracks('fortune', TRACKS);
const SFX_URL = au('sfx'), VOICE_URL = au('voice');
if (VOICE_URL) registerVoiceGame('fortune');
export const HAS_AUDIO = !!SFX_URL;

const synth = themeSfx('fortune');
const FALLBACK = {
  peg: () => synth.stop(0), spin: () => synth.spin(), reel: () => synth.click(), reelStop: () => synth.land(), boost: () => synth.bonus(),
  win: () => synth.win(1), bonus: () => synth.bonus(), reveal: () => synth.coin(), flip: () => synth.special(), land: () => synth.land(),
  double: () => synth.bonus(), lock: () => synth.coin(), aim: () => synth.click(), tick: () => synth.click(), chip: () => synth.click(),
  nomore: () => synth.tease(), drop: () => synth.special(), shuffle: () => synth.tease(), flipTile: () => synth.click(), cheer: () => synth.win(2), lose: () => {},
};
export function sfx(name, opts) {
  const clip = SFX[name];
  if (SFX_URL && clip) return playSprite(SFX_URL, clip, opts);
  FALLBACK[name]?.(); return false;
}
/** A host line. `name` may have numbered takes (name_1, name_2…); one is chosen at random. */
export function voice(name, opts) {
  if (!VOICE_URL) return false;
  const takes = Object.keys(VOICE).filter((k) => k === name || new RegExp(`^${name}_\\d+$`).test(k));
  if (!takes.length) return false;
  return playVoiceSprite(VOICE_URL, VOICE[takes[Math.floor(Math.random() * takes.length)]], opts);
}
export const sting = () => playSting('fortune', 'win');
export function preloadFortune() { preloadUrls([SFX_URL, VOICE_URL]); }
