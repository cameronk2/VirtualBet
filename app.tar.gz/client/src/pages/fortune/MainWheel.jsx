// The 54-segment Fortune Live wheel on a canvas. `spin(segment, ms)` turns it to the segment the
// server already chose; every peg that passes the pointer kicks the flapper and calls onPeg.
import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { WHEEL } from '../../../../server/games/fortune/config.js';
import { SEG_STYLE, TAU, drawFrame, easeOut, fitCanvas, paintFace, targetRotation } from './canvasWheel.js';

const N = WHEEL.length, STEP = TAU / N;

const MainWheel = forwardRef(function MainWheel({ onPeg, glow }, ref) {
  const cv = useRef(null);
  const st = useRef({ rot: 0, kick: 0, fast: false, face: null, faceSize: 0, glowSeg: null, glowColour: '#fff', anim: null });
  const pegRef = useRef(onPeg); pegRef.current = onPeg;

  useEffect(() => {
    const s = st.current;
    let raf = 0, alive = true;
    const loop = (t) => {
      if (!alive) return;
      const c = cv.current;
      if (c) {
        const { s: size, ctx } = fitCanvas(c);
        if (!s.face || s.faceSize !== size) { s.face = paintFace(size, WHEEL.map((id) => SEG_STYLE[id])); s.faceSize = size; }
        if (s.anim) {
          const a = s.anim;
          const x = Math.min(1, (t - a.t0) / a.ms);
          const prev = s.rot;
          s.rot = a.from + (a.to - a.from) * easeOut(x);
          // pegs pass the pointer every STEP; a peg sits half a segment from each centre
          const pegsBefore = Math.floor((prev + STEP / 2) / STEP), pegsNow = Math.floor((s.rot + STEP / 2) / STEP);
          if (pegsNow !== pegsBefore) { const v = (s.rot - prev) / STEP; s.kick = Math.min(1, 0.35 + v * 0.4); pegRef.current?.(v); }
          s.fast = x < 0.7;
          if (x >= 1) { s.anim = null; s.fast = false; a.done(); }
        }
        s.kick *= 0.82;
        drawFrame(ctx, size, s.face, s.rot, { t, fast: s.fast, flappers: [{ at: 0, colour: '#f8fafc', kick: -s.kick }], glowSeg: s.glowSeg, glowColour: s.glowColour, n: N });
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    // repaint the face once the display fonts are ready
    document.fonts?.ready?.then(() => { s.face = null; });
    return () => { alive = false; cancelAnimationFrame(raf); };
  }, []);

  useEffect(() => { st.current.glowSeg = glow?.seg ?? null; st.current.glowColour = glow?.colour || '#fff'; }, [glow?.seg, glow?.colour]);

  useImperativeHandle(ref, () => ({
    spin(segment, ms = 6000, turns = 4) {
      const s = st.current;
      return new Promise((done) => {
        const to = targetRotation(s.rot, segment, N, turns, ((segment * 7919) % 100) / 50 - 1);
        s.anim = { from: s.rot, to, t0: performance.now(), ms, done };
      });
    },
    /** Jump straight to a segment (used when returning to a bonus that is waiting). */
    show(segment) { st.current.rot = -segment * STEP; },
  }), []);

  return <canvas ref={cv} className="block aspect-square w-full" role="img" aria-label="Fortune Live wheel" />;
});
export default MainWheel;
