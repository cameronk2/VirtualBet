// The Fortune Booster: two reels above the wheel. The left reel picks a bet spot, the right a
// multiplier. When they line up (a hit) that spot is boosted for this round only.
import { useEffect, useRef, useState } from 'react';
import { BOOST_MULTS, SPOT_IDS } from '../../../../server/games/fortune/config.js';
import { SpotIcon } from './icons.jsx';

const H = 44; // item height (px)
const MULTS = BOOST_MULTS.map(([v]) => v);

function strip(final, pool, n) {
  const out = [];
  for (let i = 0; i < n - 1; i++) out.push(pool[(i * 7 + 3) % pool.length]);
  out.push(final);
  return out;
}

function Reel({ items, render, roll, ms, onStop }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current; if (!el || !roll) return;
    el.style.transition = 'none';
    el.style.transform = 'translateY(0)';
    void el.offsetHeight;
    el.style.transition = `transform ${ms}ms cubic-bezier(.12,.75,.2,1.02)`;
    el.style.transform = `translateY(${-(items.length - 1) * H}px)`;
    const t = setTimeout(() => onStop?.(), ms);
    return () => clearTimeout(t);
  }, [roll]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="relative h-[44px] w-[64px] overflow-hidden rounded-lg bg-gradient-to-b from-black via-[#1b0b2b] to-black ring-2 ring-amber-300/70 sm:w-[76px]">
      <div ref={ref} className="will-change-transform">
        {items.map((v, i) => <div key={i} className="flex h-[44px] items-center justify-center">{render(v)}</div>)}
      </div>
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(0,0,0,.65),transparent_30%,transparent_70%,rgba(0,0,0,.65))]" />
    </div>
  );
}

/** roll: { spot, mult, hit, id } – a new id starts the reels. onDone fires when both have stopped. */
export default function Booster({ roll, fast, onStop, onDone }) {
  const [state, setState] = useState('idle');
  const [left, setLeft] = useState([SPOT_IDS[0]]);
  const [right, setRight] = useState([MULTS[0]]);
  const stops = useRef(0);
  useEffect(() => {
    if (!roll) { setState('idle'); return; }
    stops.current = 0;
    setLeft(strip(roll.spot, SPOT_IDS, 22));
    setRight(strip(roll.hit ? roll.mult : 'miss', [...MULTS, 'miss'], 26));
    setState('spin');
  }, [roll?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const stopped = () => {
    onStop?.(stops.current);
    if (++stops.current === 2) { setState(roll?.hit ? 'hit' : 'miss'); onDone?.(); }
  };
  const ms = fast ? [700, 1100] : [1300, 2100];
  return (
    <div className={`relative mx-auto flex w-fit items-center gap-2 rounded-2xl border-2 px-2.5 py-1.5 shadow-[0_6px_24px_rgba(0,0,0,.5)] transition-colors ${state === 'hit' ? 'fl-boost-hit border-amber-300 bg-[linear-gradient(180deg,#7c2d12,#3b0a2a)]' : 'border-amber-300/50 bg-[linear-gradient(180deg,#3b0a2a,#140518)]'} ${state === 'idle' || state === 'miss' ? '[&_.will-change-transform]:opacity-50' : ''}`}>
      <div className="flex flex-col items-center leading-none">
        <span className="font-cond text-[10px] font-extrabold uppercase tracking-[0.2em] text-amber-200">Fortune</span>
        <span className="font-cond text-[10px] font-extrabold uppercase tracking-[0.2em] text-fuchsia-300">Booster</span>
      </div>
      <Reel items={left} roll={state === 'spin' ? roll?.id : null} ms={ms[0]} onStop={stopped} render={(id) => <SpotIcon id={id} className="h-9 w-9" />} />
      <span className={`text-lg font-black ${state === 'hit' ? 'text-amber-200' : 'text-white/40'}`}>×</span>
      <Reel items={right} roll={state === 'spin' ? roll?.id : null} ms={ms[1]} onStop={stopped}
        render={(m) => (m === 'miss' ? <span className="font-cond text-sm font-extrabold uppercase tracking-wider text-white/45">Miss</span> : <span className="font-display text-2xl text-amber-200 [text-shadow:0_0_10px_#f59e0b]">{m}x</span>)} />
      {state === 'hit' && <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-amber-300 px-2 text-[10px] font-extrabold uppercase tracking-wider text-amber-950 shadow">Boosted!</span>}
    </div>
  );
}
