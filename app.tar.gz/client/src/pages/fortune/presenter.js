// Fortune Live's 3D presenter. The body is Quaternius' CC0 "Universal Base Characters" female
// (mesh and skeleton only); the dress, shoes, hair, make-up and eyes are shaded in code, and every
// movement is posed in code: breathing and weight shifts, talking gestures, and reaching for the
// wheel's rim and pushing it round at the start of each spin.
//
// The presenter draws on a transparent canvas laid over the wheel. Screen points (the wheel's rim)
// are turned into world points on a plane in front of her so her hand lands where the rim is drawn.
import * as THREE from '../../../vendor/three/three.module.js';
import { GLTFLoader } from '../../../vendor/three/GLTFLoader.js';
import { clone as cloneSkinned } from '../../../vendor/three/SkeletonUtils.js';

const MODELS = typeof __MODELS__ !== 'undefined' ? __MODELS__ : '/models/'; // eslint-disable-line no-undef
// the single-file build defines __PRESENTER_URL__ (the model inline); referenced once so it is embedded once
const INLINE = (() => { try { return __PRESENTER_URL__; } catch { return null; } })(); // eslint-disable-line no-undef
let asset = null;
function loadModel() {
  if (!asset) {
    if (INLINE) {
      const bin = atob(INLINE.slice(INLINE.indexOf(',') + 1)); const buf = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
      asset = new GLTFLoader().parseAsync(buf.buffer, '');
    } else asset = new GLTFLoader().loadAsync(`${MODELS}presenter.glb`);
    asset.catch(() => { asset = null; });
  }
  return asset;
}

const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
const clamp01 = (x) => Math.max(0, Math.min(1, x));

// ── materials ──────────────────────────────────────────────────────────────
// One body material: the bind-pose position of each vertex decides skin, dress, shoes or lips.
function bodyMaterial(uTime) {
  const m = new THREE.MeshPhysicalMaterial({ color: '#ffffff', roughness: 0.55, metalness: 0, sheen: 0.35, sheenColor: new THREE.Color('#ffd9c4'), sheenRoughness: 0.6 });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = uTime;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vBind;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvBind = position;');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', `#include <common>
varying vec3 vBind; uniform float uTime;
float hash3(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }
float dressMask() {
  float ax = abs(vBind.x), y = vBind.y;
  float neck = (vBind.z < -0.03) ? 1.36 : 1.325 + 0.03 * smoothstep(0.015, 0.11, ax);
  float hem = 0.63 + 0.012 * sin(vBind.x * 60.0);
  return step(hem, y) * step(y, neck) * step(ax, 0.26);
}`)
      .replace('#include <color_fragment>', `#include <color_fragment>
float dM = dressMask();
float shoe = step(vBind.y, 0.105);
vec3 lp = (vBind - vec3(0.0, 1.574, 0.097)) / vec3(0.026, 0.0085, 0.03);
float lip = (1.0 - smoothstep(0.7, 1.0, length(lp))) * (1.0 - dM);
vec3 skin = vec3(0.70, 0.46, 0.35);
vec3 dress = mix(vec3(0.62, 0.05, 0.42), vec3(0.28, 0.03, 0.45), smoothstep(0.65, 1.3, vBind.y));
diffuseColor.rgb = skin;
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.72, 0.22, 0.32), lip);
diffuseColor.rgb = mix(diffuseColor.rgb, dress, dM);
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.03, 0.02, 0.03), shoe);`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
roughnessFactor = mix(roughnessFactor, 0.32, dM); roughnessFactor = mix(roughnessFactor, 0.18, shoe); roughnessFactor = mix(roughnessFactor, 0.3, lip);`)
      .replace('#include <metalnessmap_fragment>', `#include <metalnessmap_fragment>
metalnessFactor = mix(metalnessFactor, 0.55, dM);`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
float h = hash3(floor(vBind * 380.0));
float tw = step(0.955, h) * (0.55 + 0.45 * sin(uTime * 5.0 + h * 80.0));
totalEmissiveRadiance += dM * tw * vec3(1.0, 0.86, 0.96) * 1.4;`);
  };
  return m;
}

function eyeMaterial() {
  const m = new THREE.MeshPhysicalMaterial({ color: '#ffffff', roughness: 0.08, clearcoat: 1, clearcoatRoughness: 0.05 });
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vBindN;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvBindN = normal;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vBindN;').replace('#include <color_fragment>', `#include <color_fragment>
float f = normalize(vBindN).z;
vec3 iris = mix(vec3(0.16, 0.09, 0.04), vec3(0.42, 0.27, 0.12), smoothstep(0.9, 0.975, f));
diffuseColor.rgb = vec3(0.95, 0.93, 0.92);
diffuseColor.rgb = mix(diffuseColor.rgb, iris, smoothstep(0.86, 0.885, f));
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.02), smoothstep(0.965, 0.972, f));`);
  };
  return m;
}

function hairTexture() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#4a2c1a'; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 900; i++) {
    const x = Math.random() * 256, light = Math.random() < 0.5;
    g.strokeStyle = light ? `rgba(196,140,92,${0.15 + Math.random() * 0.25})` : `rgba(20,10,5,${0.2 + Math.random() * 0.3})`;
    g.lineWidth = 0.6 + Math.random() * 1.2;
    g.beginPath(); g.moveTo(x, 0); g.bezierCurveTo(x + (Math.random() - 0.5) * 20, 90, x + (Math.random() - 0.5) * 20, 170, x + (Math.random() - 0.5) * 14, 256); g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8;
  return t;
}

/** Hair built in code: a shaped cap over the skull and long layered hair down the back. */
function makeHair(headCentre) {
  const tex = hairTexture();
  const mat = new THREE.MeshPhysicalMaterial({ map: tex, color: '#ffffff', roughness: 0.42, sheen: 1, sheenColor: new THREE.Color('#c08a5a'), sheenRoughness: 0.35, side: THREE.DoubleSide });
  const group = new THREE.Group();
  // cap: a sphere around the skull, trimmed to a hairline (side parting, face open)
  const cap = new THREE.SphereGeometry(0.113, 64, 40);
  const keep = (p) => {
    const front = Math.max(0, p.z) / 0.12;                      // 0 at the ears … 1 at the forehead
    const line = -0.09 + 0.13 * Math.min(1, front * 1.15) - 0.02 * Math.max(0, -p.x) / 0.1; // lower on the swept side
    return p.y > line;
  };
  {
    // outside the hairline the cap sinks smoothly under the scalp, so the edge is soft rather than cut
    const pos = cap.attributes.position; const v = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) {
      v.fromBufferAttribute(pos, i).multiply(new THREE.Vector3(0.97, 1.02, 1.1));
      const front = Math.max(0, v.z) / 0.12;
      const line = -0.09 + 0.135 * Math.min(1, front * 1.15) - 0.025 * Math.max(0, -v.x) / 0.1;
      const k = THREE.MathUtils.smoothstep(v.y - line, -0.02, 0.012);   // 0 below the line … 1 above
      v.multiplyScalar(0.5 + 0.5 * k);
      pos.setXYZ(i, v.x, v.y, v.z);
    }
    cap.computeVertexNormals();
  }
  const capMesh = new THREE.Mesh(cap, mat); capMesh.position.copy(headCentre); group.add(capMesh);
  // long hair: an open, tapered shell from the crown down past the shoulder blades, with soft waves
  const H = 0.44, segY = 40, segA = 48, a0 = Math.PI * 0.36, a1 = Math.PI * 1.64;
  const pos = [], uv = [], ind = [];
  for (let j = 0; j <= segY; j++) {
    const t = j / segY, y = headCentre.y + 0.02 - t * H;
    for (let i = 0; i <= segA; i++) {
      const u = i / segA, a = a0 + (a1 - a0) * u;
      const r = 0.114 + 0.03 * t + 0.01 * Math.sin(t * 9 + u * 20) * t;
      const rx = r * (1.02 + 0.55 * t), rz = r * (1.0 + 0.2 * t);
      // round over the skull at the top, then fall behind the shoulders
      const back = -0.015 - 0.11 * t * t;
      pos.push(Math.sin(a) * rx, y, Math.cos(a) * rz + back + headCentre.z - 0.0);
      uv.push(u * 3, t);
    }
  }
  for (let j = 0; j < segY; j++) for (let i = 0; i < segA; i++) { const k = j * (segA + 1) + i; ind.push(k, k + segA + 1, k + 1, k + 1, k + segA + 1, k + segA + 2); }
  const lg = new THREE.BufferGeometry(); lg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); lg.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); lg.setIndex(ind); lg.computeVertexNormals();
  // the front of the shell (over the face) is open: a0..a1 skip the front quarter; trim it above the chin too
  const longMesh = new THREE.Mesh(lg, mat); group.add(longMesh);
  return group;
}

function envMap(renderer) {
  const pm = new THREE.PMREMGenerator(renderer);
  const s = new THREE.Scene();
  const box = new THREE.Mesh(new THREE.BoxGeometry(20, 20, 20), new THREE.MeshBasicMaterial({ color: '#1a0b26', side: THREE.BackSide })); s.add(box);
  const panel = (c, x, y, z, w, h, k = 1) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(k), side: THREE.DoubleSide })); m.position.set(x, y, z); m.lookAt(0, 0, 0); s.add(m); };
  panel('#fff3e0', -4, 5, 6, 6, 4, 3); panel('#f0abfc', 7, 2, -3, 3, 8, 2); panel('#7dd3fc', -7, 1, -4, 3, 8, 1.6); panel('#fde68a', 0, 9, 0, 10, 2, 1.5);
  const t = pm.fromScene(s, 0.03).texture; pm.dispose();
  return t;
}

/**
 * createPresenter(canvas) → { resize, setLayout, talk, reach, push, dispose }.
 * setLayout({ w, h, wheel: { cx, cy, r } }) tells it where the wheel is drawn (CSS px, same box as the canvas).
 */
export async function createPresenter(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.08;
  renderer.setClearColor(0x000000, 0);
  const scene = new THREE.Scene();
  scene.environment = envMap(renderer);
  const camera = new THREE.PerspectiveCamera(18, 1, 0.1, 60);
  const key = new THREE.DirectionalLight('#fff1e0', 2.0); key.position.set(-2, 4, 5); scene.add(key);
  const fill = new THREE.DirectionalLight('#c7d2fe', 0.7); fill.position.set(4, 1, 4); scene.add(fill);
  const rimA = new THREE.DirectionalLight('#f0abfc', 2.2); rimA.position.set(3, 3, -4); scene.add(rimA);
  const rimB = new THREE.DirectionalLight('#7dd3fc', 1.4); rimB.position.set(-4, 2, -3); scene.add(rimB);
  scene.add(new THREE.HemisphereLight('#ffe4f2', '#2a1040', 0.5));

  const gltf = await loadModel();
  const model = cloneSkinned(gltf.scene);
  const uTime = { value: 0 };
  const body = bodyMaterial(uTime), eye = eyeMaterial(), brow = new THREE.MeshStandardMaterial({ color: '#3a2414', roughness: 0.8 });
  model.traverse((o) => {
    if (!o.isMesh) return;
    o.frustumCulled = false;
    o.material = o.name === 'Eyes' ? eye : o.name === 'Eyebrows' ? brow : body;
  });
  const B = {}; model.traverse((o) => { if (o.isBone) B[o.name] = o; });
  const rig = new THREE.Group(); rig.add(model); scene.add(rig);
  model.updateMatrixWorld(true);
  // hair follows the head
  const headWorld = new THREE.Vector3(0, 1.668, -0.012);
  const hair = makeHair(headWorld);
  const head = B.Head; const hq = new THREE.Quaternion(); head.getWorldQuaternion(hq);
  const hp = new THREE.Vector3(); head.getWorldPosition(hp);
  hair.position.copy(hp).negate().applyQuaternion(hq.clone().invert()); // so hair's world-space coordinates are kept
  hair.quaternion.copy(hq.clone().invert());
  const hairPivot = new THREE.Group(); hairPivot.add(hair); head.add(hairPivot);
  // the rest pose and arm lengths
  const bind = {}; for (const [n, b] of Object.entries(B)) bind[n] = b.quaternion.clone();
  const wp = (b) => b.getWorldPosition(new THREE.Vector3());
  const len = (a, b) => wp(B[a]).distanceTo(wp(B[b]));
  const armLen = { L: [len('upperarm_l', 'lowerarm_l'), len('lowerarm_l', 'hand_l')], R: [len('upperarm_r', 'lowerarm_r'), len('lowerarm_r', 'hand_r')] };

  // ── posing helpers ──
  const _q = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3();
  function aim(bone, child, target) {
    bone.updateMatrixWorld(true);
    const bp = wp(bone), cp = wp(child);
    _v1.subVectors(cp, bp).normalize(); _v2.subVectors(target, bp).normalize();
    if (_v1.lengthSq() < 1e-8 || _v2.lengthSq() < 1e-8) return;
    _q.setFromUnitVectors(_v1, _v2);
    bone.getWorldQuaternion(_q2); _q.multiply(_q2);
    bone.parent.getWorldQuaternion(_q2); bone.quaternion.copy(_q2.invert().multiply(_q));
    bone.updateMatrixWorld(true);
  }
  function rotWorld(bone, axis, ang) {
    bone.updateMatrixWorld(true);
    bone.getWorldQuaternion(_q2); _q.setFromAxisAngle(axis, ang).multiply(_q2);
    bone.parent.getWorldQuaternion(_q2); bone.quaternion.copy(_q2.invert().multiply(_q));
    bone.updateMatrixWorld(true);
  }
  /** Two-bone arm: shoulder → elbow → hand at `target`, elbow bent towards `pole`. */
  function arm(side, target, pole) {
    const s = side === 'L' ? '_l' : '_r';
    const up = B[`upperarm${s}`], lo = B[`lowerarm${s}`], ha = B[`hand${s}`];
    const [a, b] = armLen[side];
    const S = wp(up); const toT = _v1.subVectors(target, S); let d = toT.length();
    d = Math.min(d, (a + b) * 0.995); const dir = toT.normalize().clone();
    const T = S.clone().addScaledVector(dir, d);
    const x = (a * a - b * b + d * d) / (2 * d), h = Math.sqrt(Math.max(0, a * a - x * x));
    const pl = pole.clone().sub(dir.clone().multiplyScalar(pole.dot(dir))).normalize();
    const E = S.clone().addScaledVector(dir, x).addScaledVector(pl, h);
    aim(up, lo, E); aim(lo, ha, T);
    return T;
  }
  function curlFingers(side, amt) {
    const s = side === 'L' ? '_l' : '_r';
    const hand = B[`hand${s}`]; hand.updateMatrixWorld(true);
    const axis = wp(B[`index_01${s}`]).sub(wp(B[`pinky_01${s}`])).normalize();
    for (const f of ['index', 'middle', 'ring', 'pinky']) for (const k of ['01', '02', '03']) { const bn = B[`${f}_${k}${s}`]; if (bn) rotWorld(bn, axis, (side === 'L' ? -1 : 1) * amt * (k === '01' ? 0.5 : 0.8)); }
    const th = B[`thumb_02${s}`]; if (th) rotWorld(th, axis, (side === 'L' ? -1 : 1) * amt * 0.3);
  }

  // ── layout: where things are on screen ──
  let W = 300, H = 300, wheel = { cx: 150, cy: 150, r: 140 };
  const viewH = 1.3;           // metres visible top to bottom
  const ndc = new THREE.Vector3(), ray = new THREE.Raycaster(), plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), -0.2);
  function screenToWorld(x, y, zPlane = 0.2) {
    ndc.set((x / W) * 2 - 1, -(y / H) * 2 + 1, 0.5);
    ray.setFromCamera(ndc, camera); plane.constant = -zPlane;
    const out = new THREE.Vector3(); ray.ray.intersectPlane(plane, out); return out;
  }
  function worldToScreen(v) { const p = v.clone().project(camera); return { x: (p.x + 1) / 2 * W, y: (1 - p.y) / 2 * H }; }
  function setLayout(l) {
    W = Math.max(50, l.w); H = Math.max(50, l.h); wheel = l.wheel;
    renderer.setSize(W, H, false);
    camera.aspect = W / H;
    const D = viewH / 2 / Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    camera.position.set(0, 0.98 + viewH / 2, D); camera.lookAt(0, 0.98 + viewH / 2, 0); camera.updateProjectionMatrix();
    // stand at the wheel's lower left, a little in front of it
    const pxPerM = H / viewH;
    const wantX = Math.max(0.45 * 0.5 * pxPerM, Math.min(W * 0.32, wheel.cx - wheel.r + 0.3 * pxPerM));
    const wl = screenToWorld(wantX, H * 0.5, 0); rig.position.x = wl.x;
  }

  // ── behaviour ──
  const st = { talk: 0, talking: false, reach: null, look: 0 };
  function talk(on) { st.talking = on; }
  /** The rim point her left hand goes to (screen px), at angle a (radians, clockwise from top). */
  const rimPoint = (a, k = 0.955) => ({ x: wheel.cx + Math.sin(a) * wheel.r * k, y: wheel.cy - Math.cos(a) * wheel.r * k });
  function grabAngle() {
    // the rim point nearest her right shoulder, kept to the wheel's left side
    const sh = worldToScreen(wp(B.upperarm_r));
    let a = Math.atan2(sh.x - wheel.cx, -(sh.y - wheel.cy));
    if (a < 0) a += Math.PI * 2;
    return Math.min(Math.PI * 1.52, Math.max(Math.PI * 1.25, a));
  }
  let anim = null; // { kind, t0, dur, a0, a1, resolve }
  function reach() { return new Promise((resolve) => { const a = grabAngle(); anim = { kind: 'reach', t0: performance.now(), dur: 650, a0: a, a1: a, resolve }; }); }
  function push() { return new Promise((resolve) => { const a = anim?.a0 ?? grabAngle(); anim = { kind: 'push', t0: performance.now(), dur: 420, a0: a, a1: a + 0.55, resolve }; }); }

  const leftHandIdle = new THREE.Vector3(), poleDown = new THREE.Vector3(0, -1, -0.35), poleOut = new THREE.Vector3(-0.6, -0.7, -0.3);
  let lastHand = null, t0 = performance.now(), raf = 0, alive = true;
  function frame(now) {
    if (!alive) return;
    const t = (now - t0) / 1000; uTime.value = t;
    for (const [n, q] of Object.entries(bind)) B[n].quaternion.copy(q);
    rig.rotation.y = 0.12 - st.look * 0.22;
    model.updateMatrixWorld(true);
    // breathing and a slow weight shift
    rotWorld(B.pelvis, new THREE.Vector3(0, 0, 1), Math.sin(t * 0.5) * 0.02);
    rotWorld(B.spine_02, new THREE.Vector3(0, 0, 1), -Math.sin(t * 0.5) * 0.02);
    rotWorld(B.spine_03, new THREE.Vector3(1, 0, 0), Math.sin(t * 1.6) * 0.015 - 0.03);
    // the left arm rests by her side; while talking it gestures
    st.talk += ((st.talking ? 1 : 0) - st.talk) * 0.08;
    const g = st.talk * (0.5 + 0.5 * Math.sin(t * 3.1));
    const ls = wp(B.upperarm_l);
    arm('L', ls.clone().add(new THREE.Vector3(0.08 - g * 0.05, -0.47 + g * 0.24, 0.06 + g * 0.2)), new THREE.Vector3(0.3, -1, -0.5));
    curlFingers('L', 0.25 + g * 0.15);
    // the right arm: by her side, or reaching for and pushing the wheel
    const rs = wp(B.upperarm_r);
    leftHandIdle.copy(rs).add(new THREE.Vector3(-0.07, -0.47, 0.07));
    let target = leftHandIdle, k = 0, grip = 0.2;
    if (anim) {
      const p = clamp01((now - anim.t0) / anim.dur);
      if (anim.kind === 'reach') {
        const r = rimPoint(anim.a0); const tw = screenToWorld(r.x, r.y, 0.22);
        k = ease(p); target = leftHandIdle.clone().lerp(tw, k); grip = 0.2 + 0.7 * k; st.look = k;
        if (p >= 1) { const res = anim.resolve; anim = { kind: 'hold', a0: anim.a0 }; res(); }
      } else if (anim.kind === 'hold') {
        const r = rimPoint(anim.a0); target = screenToWorld(r.x, r.y, 0.22); grip = 0.9; st.look = 1;
      } else if (anim.kind === 'push') {
        const a = anim.a0 + (anim.a1 - anim.a0) * ease(p);
        const r = rimPoint(a); target = screenToWorld(r.x, r.y, 0.22); grip = 0.9 - 0.6 * p; st.look = 1;
        if (p >= 1) { const res = anim.resolve; lastHand = target.clone(); anim = { kind: 'return', t0: now, dur: 900 }; res(); }
      } else if (anim.kind === 'return') {
        k = ease(p); target = (lastHand || leftHandIdle).clone().lerp(leftHandIdle, k); grip = 0.2; st.look = 1 - 0.6 * k;
        if (p >= 1) { anim = null; }
      }
    } else st.look += (0 - st.look) * 0.05;
    arm('R', target, anim ? poleOut : poleDown);
    curlFingers('R', grip);
    // head: towards the viewer, turning to the wheel while she spins it; nods while talking
    rotWorld(B.Head, new THREE.Vector3(0, 1, 0), -0.08 - st.look * 0.45 + Math.sin(t * 0.7) * 0.04);
    rotWorld(B.Head, new THREE.Vector3(1, 0, 0), st.talk * Math.sin(t * 5.3) * 0.05 + st.look * -0.1);
    rotWorld(B.neck_01, new THREE.Vector3(0, 0, 1), Math.sin(t * 0.6) * 0.03);
    renderer.render(scene, camera);
    raf = requestAnimationFrame(frame);
  }
  raf = requestAnimationFrame(frame);

  return {
    setLayout, talk, reach, push,
    dispose() { alive = false; cancelAnimationFrame(raf); scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); renderer.dispose(); },
  };
}
