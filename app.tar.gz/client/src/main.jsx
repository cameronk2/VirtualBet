import { lazy, Suspense, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { AppProvider } from './state/AppContext.jsx';
import { matchPath, navigate, useLocation } from './lib/router.jsx';
import Layout from './components/Layout.jsx';
import Home from './pages/Home.jsx';
import { LivePage, ResultsPage, UpcomingPage } from './pages/Matches.jsx';
import MatchPage from './pages/Match.jsx';
import MyBets from './pages/MyBets.jsx';
import History from './pages/History.jsx';
import Leaderboard from './pages/Leaderboard.jsx';
import Account from './pages/Account.jsx';
import Auth from './pages/Auth.jsx';
const ArtCapture = lazy(() => import('./pages/ArtCapture.jsx'));
const Casino = lazy(() => import('./pages/Casino.jsx'));
const Roulette = lazy(() => import('./pages/Roulette.jsx'));
import { Achievements } from './pages/Progress.jsx';
const PolarCatch = lazy(() => import('./pages/premium/polarcatch/PolarCatch.jsx'));
const ClydeBlackjack = lazy(() => import('./pages/clyde/ClydeBlackjack.jsx'));
const TigerDragon = lazy(() => import('./pages/premium/tigerdragon/TigerDragon.jsx'));
const Phoenix = lazy(() => import('./pages/premium/phoenix/Phoenix.jsx'));
const Racing = lazy(() => import('./pages/racing/Racing.jsx'));
const BonusBuyHistory = lazy(() => import('./pages/BonusBuys.jsx').then((m) => ({ default: m.BonusBuyHistory })));
const BonusBuyAdmin = lazy(() => import('./pages/BonusBuys.jsx').then((m) => ({ default: m.BonusBuyAdmin })));
import { Empty, Loading } from './components/ui.jsx';

// A light casino beside racing and football: Clyde Blackjack, Roulette and three feature games.
const CASINO = { roulette: Roulette, polarcatch: PolarCatch, tigerdragon: TigerDragon, phoenix: Phoenix };

/** Old links to games that have left the site land somewhere sensible instead of a dead page. */
function Redirect({ to }) {
  useEffect(() => { navigate(to, { replace: true }); }, [to]);
  return null;
}

function Routes() {
  const { pathname } = useLocation();
  let params;
  if (pathname === '/') return <Home />;
  if (pathname === '/live') return <LivePage />;
  if (pathname === '/upcoming') return <UpcomingPage />;
  if (pathname === '/results') return <ResultsPage />;
  if ((params = matchPath('/match/:id', pathname))) return <MatchPage id={params.id} />;
  if (pathname === '/my-bets') return <MyBets />;
  if (pathname === '/history') return <History />;
  if (pathname === '/leaderboard') return <Leaderboard />;
  if (pathname === '/clyde') return <ClydeBlackjack />;
  if (pathname === '/blackjack' || pathname === '/spin21') return <Redirect to="/clyde" />;
  if (pathname === '/slots') return <Redirect to="/casino" />;
  if (pathname === '/__art') return <ArtCapture />;
  if (pathname === '/casino') return <Casino />;
  if ((params = matchPath('/casino/:game', pathname))) { const G = CASINO[params.game]; return G ? <G key={params.game} /> : <Redirect to="/casino" />; }
  if (pathname === '/achievements') return <Achievements />;
  if (pathname === '/racing' || pathname.startsWith('/racing/')) return <Racing />;
  if (pathname === '/bonus-buys') return <BonusBuyHistory />;
  if (pathname === '/admin/bonus-buy') return <BonusBuyAdmin />;
  if (pathname === '/account') return <Account />;
  if (pathname === '/login') return <Auth mode="login" />;
  if (pathname === '/register') return <Auth mode="register" />;
  return <div className="card"><Empty title="Page not found" /></div>;
}

// Register the service worker in the hosted build only (not the single-file version)
if (typeof __PWA__ !== 'undefined' && __PWA__ && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}

createRoot(document.getElementById('root')).render(
  <AppProvider>
    <Layout>
      <Suspense fallback={<Loading label="Loading…" />}>
        <Routes />
      </Suspense>
    </Layout>
  </AppProvider>,
);
