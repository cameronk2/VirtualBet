// Universal Bonus Buy: the button, the purchase menu, the confirmation and the "bonus bought"
// moment, for every slot that registers options (server/games/bonusbuy/adapters.js).
//
// A slot page adds one line next to its spin button:
//   <BonusBuy game="neon" stake={stake} balance={balance} disabled={busy || !!free} onBuy={(b) => { armBuy(b); spin(); }} />
// `armBuy` (from useGame / usePremium) turns the page's next spin request into the purchase, so the
// bought round plays through that slot's own spin, intro and bonus screens.
import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { api } from '../lib/api.js';
import { money } from '../lib/format.js';
import { CATALOGUE } from '../../../server/games/catalogue.js';
import { Modal } from './ui.jsx';
import { sfx } from '../lib/sound.js';

const nonce = () => {
  try { return Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => b.toString(16).padStart(2, '0')).join(''); }
  catch { return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`; }
};

/** Small emblem per kind of feature (no emoji). */
function Emblem({ id }) {
  const k = /hold|cash/.test(id) ? 'coin' : /treasure|pick|chest/.test(id) ? 'chest' : /saw|wheel/.test(id) ? 'wheel' : /firestorm|combined/.test(id) ? 'burst' : /arealink/.test(id) ? 'link' : 'spins';
  return (
    <svg viewBox="0 0 40 40" className="h-11 w-11 shrink-0" aria-hidden="true">
      <defs><linearGradient id={`bbg-${k}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff7c2" /><stop offset=".5" stopColor="#facc15" /><stop offset="1" stopColor="#b45309" /></linearGradient></defs>
      <circle cx="20" cy="20" r="19" fill="#1c1406" stroke={`url(#bbg-${k})`} strokeWidth="2" />
      {k === 'coin' && <><circle cx="20" cy="20" r="10" fill={`url(#bbg-${k})`} /><text x="20" y="24.5" textAnchor="middle" fontSize="12" fontWeight="900" fill="#78350f">£</text></>}
      {k === 'chest' && <><rect x="10" y="16" width="20" height="13" rx="2" fill={`url(#bbg-${k})`} /><path d="M10 18Q20 8 30 18" fill="#b45309" /><rect x="18" y="19" width="4" height="5" fill="#451a03" /></>}
      {k === 'wheel' && <><circle cx="20" cy="20" r="11" fill="none" stroke={`url(#bbg-${k})`} strokeWidth="3" />{[0, 45, 90, 135].map((a) => <path key={a} d="M20 9V31" stroke="#facc15" strokeWidth="1.5" transform={`rotate(${a} 20 20)`} />)}<circle cx="20" cy="20" r="3" fill="#fff7c2" /></>}
      {k === 'burst' && <path d="M20 7L23 16L32 13L26 20L33 26L23 24L20 33L17 24L7 26L14 20L8 13L17 16Z" fill={`url(#bbg-${k})`} />}
      {k === 'link' && <><circle cx="15" cy="20" r="6" fill="none" stroke="#facc15" strokeWidth="3" /><circle cx="25" cy="20" r="6" fill="none" stroke="#fde68a" strokeWidth="3" /></>}
      {k === 'spins' && <><path d="M20 9A11 11 0 1 1 9 20" fill="none" stroke={`url(#bbg-${k})`} strokeWidth="3.5" strokeLinecap="round" /><path d="M9 13V20H16" fill="none" stroke="#facc15" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></>}
    </svg>
  );
}

export function BonusBuyButton({ onClick, disabled, className = '', compact = false }) {
  return (
    <button type="button" onClick={onClick} disabled={disabled} aria-label="Bonus Buy"
      className={`bb-btn relative isolate shrink-0 overflow-hidden rounded-xl px-3 font-extrabold uppercase tracking-wide text-amber-950 shadow-[0_2px_10px_rgba(0,0,0,.45)] ring-1 ring-amber-100/70 transition active:scale-95 disabled:opacity-40 ${compact ? 'h-10 text-[10px] leading-[1.05]' : 'h-11 text-[11px] leading-tight'} ${className}`}>
      <span className="relative z-10 block">Bonus<br />Buy</span>
    </button>
  );
}

/** The confirmation burst shown over the game when a purchase goes through. */
function Bought({ name, cost, onDone }) {
  const done = useRef(onDone); done.current = onDone;
  useEffect(() => { const t = setTimeout(() => done.current(), 1900); return () => clearTimeout(t); }, []);
  return createPortal(
    <div className="pointer-events-none fixed inset-0 z-[60] flex items-center justify-center">
      <div className="bb-flash absolute inset-0" />
      <div className="p3-stamp relative rounded-2xl border-2 border-amber-200 bg-[linear-gradient(180deg,#3b2606,#120c02)] px-6 py-4 text-center shadow-[0_0_60px_rgba(250,204,21,.55)]">
        <div className="text-[11px] font-extrabold uppercase tracking-[.3em] text-amber-300">Bonus bought</div>
        <div className="mt-1 font-display text-3xl text-amber-100">{name}</div>
        <div className="mt-1 text-sm font-semibold text-amber-200/80">{money(cost)} · good luck!</div>
      </div>
    </div>,
    document.body,
  );
}

export default function BonusBuy({ game, stake, balance = 0, disabled, onBuy, compact = false, className = '', hidden = false }) {
  const [info, setInfo] = useState(null);
  const [open, setOpen] = useState(false);
  const [pick, setPick] = useState(null);       // option on the confirmation screen
  const [ref, setRef] = useState(null);         // purchase reference for that confirmation
  const [sending, setSending] = useState(false);
  const [bought, setBought] = useState(null);
  const [showHist, setShowHist] = useState(false);
  const load = useCallback(() => api.get(`/api/bonusbuy/${game}`).then(setInfo).catch(() => setInfo(null)), [game]);
  useEffect(() => { load(); }, [load]);
  if (!info?.buy) return bought ? <Bought name={bought.name} cost={bought.cost} onDone={() => setBought(null)} /> : null;
  if (hidden) return bought ? <Bought name={bought.name} cost={bought.cost} onDone={() => setBought(null)} /> : null;
  const { options, minStake, maxStake } = info.buy;
  const cat = CATALOGUE.find((c) => c.id === game);
  const inRange = stake >= minStake && stake <= maxStake;
  const close = () => { setOpen(false); setPick(null); setSending(false); };
  const choose = (o) => { setPick(o); setRef(nonce()); sfx.click?.(); };
  const confirm = () => {
    if (sending || !pick) return;
    setSending(true);                              // one tap only: the button is disabled from here
    const cost = Math.round(stake * pick.cost);
    const b = { option: pick.id, name: pick.name, stake, cost, nonce: ref };
    close();
    setBought(b);
    onBuy(b);
    setTimeout(load, 4000);
  };

  return (
    <>
      <BonusBuyButton onClick={() => { load(); setOpen(true); }} disabled={disabled} compact={compact} className={className} />
      <Modal open={open} onClose={close} title={pick ? 'Confirm purchase' : 'Bonus Buy'}>
        {!pick && (
          <div className="space-y-3">
            <div className={`relative overflow-hidden rounded-xl bg-gradient-to-br ${cat?.hue || 'from-amber-500 to-stone-900'} p-3`}>
              <div className="absolute inset-0 bg-black/45" />
              <div className="relative flex items-center justify-between gap-2">
                <div><div className="text-[10px] font-extrabold uppercase tracking-[.25em] text-amber-200">Bonus Buy</div><div className="font-display text-xl text-white">{cat?.name || game}</div></div>
                <div className="text-right"><div className="text-[10px] font-semibold uppercase tracking-wider text-white/70">Your bet</div><div className="font-cond text-xl font-bold tabular-nums text-white">{money(stake)}</div></div>
              </div>
            </div>
            {!inRange && <p className="rounded-lg bg-amber-500/10 p-2 text-xs text-amber-200">Bonus Buy is available for bets from {money(minStake)} to {money(maxStake)}. Change your bet to buy.</p>}
            {options.map((o, i) => {
              const cost = Math.round(stake * o.cost);
              const short = cost > balance;
              return (
                <div key={o.id} className="bb-card rounded-2xl border border-amber-300/30 bg-[linear-gradient(160deg,#2a1d07,#0f0b04)] p-3" style={{ animationDelay: `${i * 70}ms` }}>
                  <div className="flex gap-3">
                    <Emblem id={o.id} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2"><div className="font-bold text-amber-100">{o.name}</div><div className="shrink-0 rounded-md bg-amber-400/15 px-1.5 text-[11px] font-bold text-amber-300">{o.cost}x bet</div></div>
                      <p className="mt-0.5 text-xs leading-snug text-slate-300">{o.desc}</p>
                      <p className="mt-1 text-[11px] text-slate-400">Starts from: {o.feature}{o.rtp ? ` · return about ${o.rtp}%` : ''}</p>
                    </div>
                  </div>
                  <button type="button" onClick={() => choose(o)} disabled={!inRange || short}
                    className="bb-buy mt-2.5 flex h-11 w-full items-center justify-between rounded-xl px-4 font-extrabold text-amber-950 disabled:opacity-40">
                    <span>Buy</span><span className="font-cond text-lg tabular-nums">{money(cost)}</span>
                  </button>
                  {short && inRange && <p className="mt-1 text-[11px] text-amber-300">Not enough balance for this one at {money(stake)}.</p>}
                </div>
              );
            })}
            <p className="text-[11px] leading-snug text-slate-500">The price is your bet × the multiplier shown, taken from your virtual balance. The bought round is a real triggering spin of this game, and the bonus plays by the game's normal rules. Virtual money only.</p>
            {info.purchases?.length > 0 && (
              <div>
                <button type="button" onClick={() => setShowHist((v) => !v)} className="text-xs font-semibold text-sky-300">{showHist ? 'Hide' : 'Show'} your recent purchases</button>
                {showHist && (
                  <table className="mt-1 w-full text-left text-[11px]">
                    <thead className="text-slate-500"><tr><th className="py-0.5">Bonus</th><th>Cost</th><th>Paid</th><th>Net</th></tr></thead>
                    <tbody className="text-slate-300">
                      {info.purchases.slice(0, 8).map((p) => (
                        <tr key={p.id} className="border-t border-white/5"><td className="py-0.5">{p.name}{p.status === 'open' ? ' (in play)' : ''}</td><td>{money(p.cost)}</td><td>{money(p.payout)}</td><td className={p.net >= 0 ? 'text-emerald-400' : 'text-rose-300'}>{p.net >= 0 ? '+' : '−'}{money(Math.abs(p.net))}</td></tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </div>
        )}
        {pick && (() => {
          const cost = Math.round(stake * pick.cost);
          return (
            <div className="space-y-3 text-center">
              <div className="mx-auto w-fit"><Emblem id={pick.id} /></div>
              <div className="text-[11px] font-extrabold uppercase tracking-[.3em] text-amber-300">Bonus Buy</div>
              <div className="font-display text-2xl text-white">{pick.name}</div>
              <div className="text-xs text-slate-400">{cat?.name} · bet {money(stake)} × {pick.cost}</div>
              <dl className="mx-auto max-w-xs space-y-1.5 rounded-xl bg-black/30 p-3 text-sm">
                <div className="flex justify-between"><dt className="text-slate-400">Purchase cost</dt><dd className="font-bold tabular-nums text-amber-200">{money(cost)}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-400">Current balance</dt><dd className="tabular-nums text-white">{money(balance)}</dd></div>
                <div className="flex justify-between border-t border-white/10 pt-1.5"><dt className="text-slate-400">Balance after purchase</dt><dd className="font-bold tabular-nums text-white">{money(balance - cost)}</dd></div>
              </dl>
              <button type="button" onClick={confirm} disabled={sending || cost > balance} className="bb-buy h-12 w-full rounded-xl text-base font-extrabold text-amber-950 disabled:opacity-50">{sending ? 'Buying…' : 'Confirm purchase'}</button>
              <button type="button" onClick={() => setPick(null)} className="h-10 w-full rounded-xl bg-navy-700 text-sm font-semibold text-slate-200">Cancel</button>
            </div>
          );
        })()}
      </Modal>
      {bought && <Bought name={bought.name} cost={bought.cost} onDone={() => setBought(null)} />}
    </>
  );
}
