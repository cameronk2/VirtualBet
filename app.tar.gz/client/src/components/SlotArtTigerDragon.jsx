import { TD_IMG } from '../assets/tigerdragon/index.js';
// Gong Fortune – original vector artwork (no third-party assets).
// Six regular symbols, the Tiger and Dragon scatters, gold gongs (blank,
// numbered, arrow), the logo and the lobby tile. All drawn on a 100x100 box.

export function TigerDragonDefs() {
  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="tdGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff7c2" /><stop offset=".35" stopColor="#fcd34d" /><stop offset=".7" stopColor="#d97706" /><stop offset="1" stopColor="#7c2d12" /></linearGradient>
        <linearGradient id="tdGoldH" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#92400e" /><stop offset=".5" stopColor="#fde68a" /><stop offset="1" stopColor="#92400e" /></linearGradient>
        <radialGradient id="tdGong" cx="42%" cy="38%" r="62%"><stop offset="0" stopColor="#fffbe6" /><stop offset=".28" stopColor="#fde047" /><stop offset=".62" stopColor="#d97706" /><stop offset=".86" stopColor="#92400e" /><stop offset="1" stopColor="#451a03" /></radialGradient>
        <radialGradient id="tdRed" cx="50%" cy="40%" r="65%"><stop offset="0" stopColor="#f87171" /><stop offset=".55" stopColor="#b91c1c" /><stop offset="1" stopColor="#450a0a" /></radialGradient>
        <radialGradient id="tdJade" cx="45%" cy="38%" r="65%"><stop offset="0" stopColor="#a7f3d0" /><stop offset=".5" stopColor="#10b981" /><stop offset="1" stopColor="#064e3b" /></radialGradient>
        <radialGradient id="tdTile" cx="50%" cy="35%" r="75%"><stop offset="0" stopColor="#5b0f0f" /><stop offset="1" stopColor="#1a0505" /></radialGradient>
        <linearGradient id="tdFur" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fdba74" /><stop offset=".55" stopColor="#ea580c" /><stop offset="1" stopColor="#7c2d12" /></linearGradient>
        <linearGradient id="tdScale" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#6ee7b7" /><stop offset=".5" stopColor="#059669" /><stop offset="1" stopColor="#022c22" /></linearGradient>
        <filter id="tdGlow" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.4" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        <filter id="tdShadow" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="2.2" stdDeviation="1.6" floodColor="#000" floodOpacity=".55" /></filter>
      </defs>
    </svg>
  );
}

const Frame = ({ children, hi }) => (
  <g>
    <rect x="3" y="3" width="94" height="94" rx="14" fill="url(#tdTile)" stroke={hi ? 'url(#tdGold)' : '#7f1d1d'} strokeWidth={hi ? 3 : 2} />
    <g filter="url(#tdShadow)">{children}</g>
  </g>
);

// ── Regular symbols ─────────────────────────────────────────
const ENVELOPE = (
  <Frame hi>
    <rect x="18" y="26" width="64" height="50" rx="5" fill="url(#tdRed)" stroke="#fde68a" strokeWidth="2.5" />
    <path d="M18 31l32 22 32-22" fill="none" stroke="#fde68a" strokeWidth="2.5" />
    <circle cx="50" cy="55" r="11" fill="url(#tdGold)" stroke="#7c2d12" strokeWidth="1.5" />
    <text x="50" y="60" textAnchor="middle" fontSize="13" fontWeight="900" fill="#7f1d1d" fontFamily="system-ui">福</text>
  </Frame>
);
const LOTUS = (
  <Frame hi>
    {[-48, -24, 0, 24, 48].map((a, i) => <ellipse key={a} cx="50" cy="44" rx="9" ry="24" fill={i === 2 ? '#fbcfe8' : '#f472b6'} stroke="#9d174d" strokeWidth="1.5" transform={`rotate(${a} 50 66)`} />)}
    <ellipse cx="50" cy="70" rx="26" ry="7" fill="url(#tdJade)" />
    <circle cx="50" cy="58" r="5" fill="url(#tdGold)" />
  </Frame>
);
const LANTERN = (
  <Frame hi>
    <path d="M50 12v8" stroke="#fde68a" strokeWidth="2.5" />
    <rect x="34" y="20" width="32" height="6" rx="2" fill="url(#tdGold)" />
    <ellipse cx="50" cy="50" rx="28" ry="24" fill="url(#tdRed)" stroke="#fde68a" strokeWidth="2" />
    {[-14, 0, 14].map((x) => <path key={x} d={`M${50 + x} 27q${x * 0.9} 23 0 46`} fill="none" stroke="#7f1d1d" strokeWidth="1.6" />)}
    <rect x="34" y="72" width="32" height="6" rx="2" fill="url(#tdGold)" />
    {[40, 46, 52, 58].map((x) => <path key={x} d={`M${x} 78v10`} stroke="#fcd34d" strokeWidth="2" />)}
  </Frame>
);
const FAN = (
  <Frame>
    {Array.from({ length: 9 }, (_, i) => <path key={i} d="M50 76L50 22" stroke="#7c2d12" strokeWidth="2" transform={`rotate(${-64 + i * 16} 50 76)`} />)}
    <path d="M50 76L19 41A44 44 0 0 1 81 41z" fill="#0f766e" stroke="#fde68a" strokeWidth="2" />
    <path d="M27 45A34 34 0 0 1 73 45" fill="none" stroke="#fde68a" strokeWidth="1.5" />
    <circle cx="50" cy="76" r="4" fill="url(#tdGold)" />
  </Frame>
);
const BANGLE = (
  <Frame>
    <ellipse cx="50" cy="52" rx="30" ry="26" fill="none" stroke="url(#tdJade)" strokeWidth="11" />
    <ellipse cx="50" cy="52" rx="30" ry="26" fill="none" stroke="#d1fae5" strokeOpacity=".5" strokeWidth="1.5" />
    <ellipse cx="40" cy="34" rx="6" ry="2.5" fill="#ecfdf5" opacity=".7" transform="rotate(-20 40 34)" />
  </Frame>
);
const ORNAMENT = (
  <Frame>
    <path d="M50 14v10" stroke="#fde68a" strokeWidth="2.5" />
    <path d="M50 24l22 22-22 22-22-22z" fill="url(#tdRed)" stroke="#fde68a" strokeWidth="2" />
    <path d="M50 34l12 12-12 12-12-12z" fill="url(#tdGold)" />
    {[44, 50, 56].map((x) => <path key={x} d={`M${x} 68l${(x - 50) * 0.4} 18`} stroke="#ef4444" strokeWidth="2.6" />)}
  </Frame>
);

// ── Tiger and Dragon scatters ───────────────────────────────
export const TigerHead = ({ scale = 1 }) => (
  <g transform={`translate(50 52) scale(${scale}) translate(-50 -52)`}>
    <path d="M18 30l8-16 14 10M82 30l-8-16-14 10" fill="url(#tdFur)" stroke="#431407" strokeWidth="2" />
    <path d="M22 26l6-8 6 6M78 26l-6-8-6 6" fill="#fde68a" />
    <path d="M50 20c20 0 34 14 34 34 0 16-12 30-34 34-22-4-34-18-34-34 0-20 14-34 34-34z" fill="url(#tdFur)" stroke="#431407" strokeWidth="2.2" />
    {/* stripes */}
    <path d="M50 22v12M42 23l4 10M58 23l-4 10M20 46l10 3M80 46l-10 3M19 56l11 1M81 56l-11 1M24 66l9-3M76 66l-9-3" stroke="#1c0a02" strokeWidth="3.2" strokeLinecap="round" />
    <path d="M35 66c5 10 25 10 30 0-4 12-26 12-30 0z" fill="#fff7ed" />
    <path d="M30 60c6 16 34 16 40 0" fill="#fff7ed" opacity=".95" />
    {/* eyes */}
    <path d="M30 46q8-6 15 0-7 5-15 0zM70 46q-8-6-15 0 7 5 15 0z" fill="#fde047" stroke="#1c0a02" strokeWidth="1.6" />
    <ellipse cx="38" cy="46" rx="1.8" ry="3.6" fill="#1c0a02" /><ellipse cx="62" cy="46" rx="1.8" ry="3.6" fill="#1c0a02" />
    <path d="M44 58h12l-6 7z" fill="#7f1d1d" />
    <path d="M50 65v5M50 70q-6 5-11 1M50 70q6 5 11 1" stroke="#1c0a02" strokeWidth="1.8" fill="none" />
    <path d="M44 72l2 6 2-6M52 72l2 6 2-6" fill="#fff" />
    {[[36, 64], [33, 68], [64, 64], [67, 68]].map(([x, y], i) => <path key={i} d={`M${x} ${y}l${x < 50 ? -12 : 12} ${i % 2 ? 4 : -2}`} stroke="#fff" strokeOpacity=".8" strokeWidth=".9" />)}
    <text x="50" y="40" textAnchor="middle" fontSize="11" fontWeight="900" fill="#1c0a02" fontFamily="system-ui">王</text>
  </g>
);
export const DragonHead = ({ scale = 1 }) => (
  <g transform={`translate(50 52) scale(${scale}) translate(-50 -52)`}>
    {/* horns and mane */}
    <path d="M34 26C28 14 18 10 10 12c8 4 12 10 14 18M66 26c6-12 16-16 24-14-8 4-12 10-14 18" fill="none" stroke="url(#tdGold)" strokeWidth="5" strokeLinecap="round" />
    {[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${24 + i * 13} 30q${i < 2 ? -12 : i > 2 ? 12 : 0} -12 ${i < 2 ? -4 : i > 2 ? 4 : 0} -20`} fill="none" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" />)}
    {/* head */}
    <path d="M22 44c0-14 12-20 28-20s28 6 28 20c0 8-3 14-8 18l2 14c-8 6-18 8-22 8s-14-2-22-8l2-14c-5-4-8-10-8-18z" fill="url(#tdScale)" stroke="#022c22" strokeWidth="2.2" />
    <path d="M30 36q20-10 40 0" fill="none" stroke="#a7f3d0" strokeWidth="1.6" opacity=".7" />
    {/* eyes */}
    <path d="M30 44q8-8 16-1-8 6-16 1zM70 44q-8-8-16-1 8 6 16 1z" fill="#facc15" stroke="#1c1917" strokeWidth="1.5" />
    <circle cx="39" cy="43" r="2.3" fill="#7f1d1d" /><circle cx="61" cy="43" r="2.3" fill="#7f1d1d" />
    {/* snout, nostrils, whiskers */}
    <path d="M36 58c4-6 24-6 28 0v8c-6 4-22 4-28 0z" fill="#34d399" stroke="#022c22" strokeWidth="1.8" />
    <circle cx="44" cy="60" r="2" fill="#022c22" /><circle cx="56" cy="60" r="2" fill="#022c22" />
    <path d="M36 62C24 64 14 74 8 86M64 62c12 2 22 12 28 24" fill="none" stroke="url(#tdGold)" strokeWidth="2.6" strokeLinecap="round" />
    <path d="M40 68l3 8 3-6 4 7 4-7 3 6 3-8" fill="#fff" stroke="#022c22" strokeWidth="1" />
    <circle cx="50" cy="30" r="5" fill="url(#tdRed)" stroke="#fde68a" strokeWidth="1.5" />
  </g>
);
const TIGER = (
  <g>
    <rect x="3" y="3" width="94" height="94" rx="14" fill="#431407" stroke="url(#tdGold)" strokeWidth="3.5" />
    <circle cx="50" cy="50" r="40" fill="#ea580c" opacity=".35" />
    <g filter="url(#tdShadow)"><TigerHead scale={0.92} /></g>
    <rect x="16" y="78" width="68" height="14" rx="7" fill="#1c0a02" stroke="url(#tdGold)" strokeWidth="1.5" />
    <text x="50" y="89" textAnchor="middle" fontSize="10" fontWeight="900" letterSpacing="2" fill="#fdba74" fontFamily="system-ui">TIGER</text>
  </g>
);
const DRAGON = (
  <g>
    <rect x="3" y="3" width="94" height="94" rx="14" fill="#022c22" stroke="url(#tdGold)" strokeWidth="3.5" />
    <circle cx="50" cy="50" r="40" fill="#10b981" opacity=".3" />
    <g filter="url(#tdShadow)"><DragonHead scale={0.92} /></g>
    <rect x="14" y="78" width="72" height="14" rx="7" fill="#022c22" stroke="url(#tdGold)" strokeWidth="1.5" />
    <text x="50" y="89" textAnchor="middle" fontSize="10" fontWeight="900" letterSpacing="2" fill="#6ee7b7" fontFamily="system-ui">DRAGON</text>
  </g>
);

export const TD_ART = { ENVELOPE, LOTUS, LANTERN, FAN, BANGLE, ORNAMENT, TIGER, DRAGON };
export const TD_NAMES = { ENVELOPE: 'Envelope', LOTUS: 'Lotus', LANTERN: 'Lantern', FAN: 'Fan', BANGLE: 'Bangle', ORNAMENT: 'Ornament', TIGER: 'Tiger', DRAGON: 'Dragon' };

/** Painted symbol: Tiger and Dragon are full tiles; the others sit on the red lacquer tile. */
export function TDSym({ s, className = 'h-full w-full', bare = false }) {
  const img = TD_IMG[s];
  if (!img) return <svg viewBox="0 0 100 100" className={className} role="img" aria-label={TD_NAMES[s] || s}>{TD_ART[s]}</svg>;
  const tile = s === 'TIGER' || s === 'DRAGON';
  return (
    <svg viewBox="0 0 100 100" className={className} role="img" aria-label={TD_NAMES[s] || s}>
      {!tile && !bare && <rect x="3" y="3" width="94" height="94" rx="14" fill="url(#tdTile)" stroke={['ENVELOPE', 'LOTUS', 'LANTERN'].includes(s) ? 'url(#tdGold)' : '#7f1d1d'} strokeWidth={['ENVELOPE', 'LOTUS', 'LANTERN'].includes(s) ? 3 : 2} />}
      <image href={img} x={tile || bare ? 1 : 9} y={tile || bare ? 1 : 9} width={tile || bare ? 98 : 82} height={tile || bare ? 98 : 82} preserveAspectRatio="xMidYMid meet" />
    </svg>
  );
}

/**
 * A gold gong. g: undefined (blank / value hidden), { n } a number or { a } an Arrow with its boost.
 * locked adds the red lock ring that shows it is held for the rest of the round.
 */
export function Gong({ g, locked = false, className = 'h-full w-full', reveal = false, tile = false }) {
  const label = g?.n != null ? `Gong ${g.n}` : g?.a != null ? `Arrow plus ${g.a}` : 'Gong';
  return (
    <svg viewBox="0 0 100 100" className={className} role="img" aria-label={label}>
      {locked && <circle cx="50" cy="50" r="47" fill="none" stroke="#ef4444" strokeWidth="3" strokeDasharray="6 4" opacity=".9" />}
      {tile && TD_IMG.GONGTILE ? (
        <image href={TD_IMG.GONGTILE} x="4" y="1" width="92" height="98" preserveAspectRatio="xMidYMid meet" />
      ) : TD_IMG.GONG ? (
        <>
          <circle cx="50" cy="54" r="40" fill="#000" opacity=".35" />
          <image href={TD_IMG.GONG} x="8" y="10" width="84" height="84" />
          {g && <circle cx="50" cy="52" r="24" fill="#7c2d12" opacity=".28" />}
        </>
      ) : (
        <>
          <path d="M22 10q28-8 56 0" fill="none" stroke="#7c2d12" strokeWidth="4" strokeLinecap="round" />
          <path d="M30 9v8M70 9v8" stroke="#7c2d12" strokeWidth="3" />
          <circle cx="50" cy="54" r="38" fill="url(#tdGong)" stroke="#78350f" strokeWidth="2.5" filter="url(#tdShadow)" />
          <circle cx="50" cy="54" r="30" fill="none" stroke="#fef3c7" strokeOpacity=".55" strokeWidth="1.4" />
          <circle cx="50" cy="54" r="12" fill="#b45309" opacity=".35" />
          <ellipse cx="38" cy="40" rx="10" ry="5" fill="#fff" opacity=".45" transform="rotate(-30 38 40)" />
        </>
      )}
      {g?.n != null && (
        <text x="50" y={g.n >= 10 ? 65 : 67} textAnchor="middle" fontSize={g.n >= 10 ? 32 : 38} fontWeight="900" fontFamily="'Lilita One', system-ui" fill="#7f1d1d" stroke="#fffbeb" strokeWidth="2.5" paintOrder="stroke" className={reveal ? 'td-reveal' : undefined}>{g.n}</text>
      )}
      {g?.a != null && (
        <g className={reveal ? 'td-reveal' : undefined}>
          <path d="M50 30l15 16h-9v14H44V46h-9z" fill="#16a34a" stroke="#fffbeb" strokeWidth="2.5" paintOrder="stroke" />
          <text x="50" y="80" textAnchor="middle" fontSize="15" fontWeight="900" fontFamily="system-ui" fill="#14532d" stroke="#fffbeb" strokeWidth="2" paintOrder="stroke">+{g.a}</text>
        </g>
      )}
      {!g && !TD_IMG.GONG && <text x="50" y="62" textAnchor="middle" fontSize="20" fontWeight="900" fontFamily="system-ui" fill="#7c2d12" opacity=".55">鑼</text>}
    </svg>
  );
}

export function TDLogo({ className = '', textOnly = false }) {
  if (textOnly) return (
    <svg viewBox="60 0 200 96" className={className} aria-label="Gong Fortune">
      <text x="160" y="52" textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize="50" letterSpacing="3" fill="url(#tdGold)" stroke="#450a0a" strokeWidth="4" paintOrder="stroke">GONG</text>
      <text x="160" y="88" textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize="30" letterSpacing="5" fill="#fecaca" stroke="#450a0a" strokeWidth="3" paintOrder="stroke">FORTUNE</text>
    </svg>
  );
  return (
    <svg viewBox="0 0 320 96" className={className} aria-label="Gong Fortune">
      <defs><clipPath id="tdLogoL"><circle cx="40" cy="48" r="36" /></clipPath><clipPath id="tdLogoR"><circle cx="280" cy="48" r="36" /></clipPath></defs>
      <circle cx="40" cy="48" r="38" fill="url(#tdGold)" /><image href={TD_IMG.TIGER} x="2" y="6" width="80" height="88" clipPath="url(#tdLogoL)" preserveAspectRatio="xMidYMin slice" />
      <circle cx="280" cy="48" r="38" fill="url(#tdGold)" /><image href={TD_IMG.DRAGON} x="242" y="6" width="80" height="88" clipPath="url(#tdLogoR)" preserveAspectRatio="xMidYMin slice" />
      <text x="160" y="52" textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize="44" letterSpacing="3" fill="url(#tdGold)" stroke="#450a0a" strokeWidth="3" paintOrder="stroke">GONG</text>
      <text x="160" y="86" textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize="30" letterSpacing="5" fill="#fca5a5" stroke="#450a0a" strokeWidth="2.5" paintOrder="stroke">FORTUNE</text>
    </svg>
  );
}

export const TD_LOBBY = (
  <g>
    <rect width="100" height="100" fill="url(#tdTile)" />
    <circle cx="50" cy="50" r="44" fill="#dc2626" opacity=".25" />
    <image href={TD_IMG.TIGER} x="-2" y="14" width="56" height="62" />
    <image href={TD_IMG.DRAGON} x="48" y="14" width="56" height="62" />
    <image href={TD_IMG.GONG} x="30" y="52" width="40" height="40" />
    <text x="50" y="78" textAnchor="middle" fontSize="16" fontWeight="900" fontFamily="system-ui" fill="#7f1d1d" stroke="#fffbeb" strokeWidth="1.5" paintOrder="stroke">88</text>
  </g>
);
