// Original symbol art for the five premium slots (inline SVG, no images).
// Gradients live once per page in <SlotDefs3 />; symbols reference them.
import PaintedSym from './PaintedSym.jsx';
import { SLOT_IMG } from '../assets/slots/index.js';
import { money } from '../lib/format.js';
import { MOON_LOBBY, MoonDefs, MoonLogo } from './SlotArtMoon.jsx';
import { MUMMY_LOBBY, MummyDefs, MummyLogo } from './SlotArtMummy.jsx';
import { POLAR_LOBBY, PolarDefs, PolarLogo } from './SlotArtPolar.jsx';
import { BRICK_LOBBY, BrickDefs, BrickLogo } from './SlotArtBrick.jsx';
import { STAMPEDE_LOBBY, StampedeDefs, StampedeLogo } from './SlotArtStampede.jsx';
import { CHICKEN_LOBBY, ChickenDefs, ChickenLogo } from './SlotArtChicken.jsx';
import { MINES_LOBBY, MinesDefs, MinesLogo } from './SlotArtMines.jsx';
import { KENO_LOBBY, KenoDefs, KenoLogo } from './SlotArtKeno.jsx';
import { GENIE_LOBBY, GenieDefs, GenieLogo } from './SlotArtGenie.jsx';
import { TD_LOBBY, TDLogo, TigerDragonDefs } from './SlotArtTigerDragon.jsx';
import { FROST_ART, FROST_LOBBY, FROST_NAMES, FROST_TILE, FrostDefs, FrostLogo } from './SlotArtFrost.jsx';

export function SlotDefs3() {
  const lg = (id, stops, x2 = 0, y2 = 1) => (
    <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</linearGradient>
  );
  const rg = (id, stops) => <radialGradient id={id} cx="50%" cy="40%" r="60%">{stops.map(([o, c], i) => <stop key={i} offset={o} stopColor={c} />)}</radialGradient>;
  return (
    <>
    <FrostDefs />
    <MoonDefs />
    <MummyDefs />
    <PolarDefs />
    <BrickDefs />
    <StampedeDefs />
    <ChickenDefs />
    <MinesDefs />
    <KenoDefs />
    <GenieDefs />
    <TigerDragonDefs />
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <defs>
        {lg('s3gold', [[0, '#fff7c2'], [0.35, '#facc15'], [0.7, '#d97706'], [1, '#7c2d12']])}
        {lg('s3goldH', [[0, '#fde68a'], [0.5, '#f59e0b'], [1, '#92400e']], 1, 0)}
        {lg('s3teal', [[0, '#a5f3fc'], [0.5, '#22d3ee'], [1, '#0e7490']])}
        {lg('s3sea', [[0, '#0c4a6e'], [1, '#082f49']])}
        {lg('s3red', [[0, '#fca5a5'], [0.4, '#dc2626'], [1, '#7f1d1d']])}
        {lg('s3jade', [[0, '#bbf7d0'], [0.5, '#22c55e'], [1, '#14532d']])}
        {lg('s3lacq', [[0, '#991b1b'], [1, '#450a0a']])}
        {lg('s3sand', [[0, '#fde68a'], [0.6, '#d6a85b'], [1, '#92643a']])}
        {lg('s3stone', [[0, '#e7c99a'], [1, '#a47a4a']])}
        {lg('s3lapis', [[0, '#60a5fa'], [1, '#1e3a8a']])}
        {lg('s3pink', [[0, '#f9a8d4'], [1, '#db2777']])}
        {lg('s3cyan', [[0, '#a5f3fc'], [1, '#0891b2']])}
        {lg('s3violet', [[0, '#ddd6fe'], [1, '#6d28d9']])}
        {lg('s3fire', [[0, '#fef08a'], [0.4, '#f97316'], [1, '#b91c1c']])}
        {rg('s3pearl', [[0, '#ffffff'], [0.6, '#e0f2fe'], [1, '#93c5fd']])}
        {rg('s3orb', [[0, '#fef9c3'], [0.5, '#a855f7'], [1, '#312e81']])}
        {rg('s3sun', [[0, '#fffbeb'], [0.45, '#fde047'], [1, '#ea580c']])}
        {rg('s3hole', [[0, '#000'], [0.55, '#000'], [0.7, '#7c3aed'], [0.85, '#f472b6'], [1, 'rgba(0,0,0,0)']])}
        {rg('s3planet', [[0, '#fed7aa'], [0.6, '#f97316'], [1, '#7c2d12']])}
        <filter id="s3glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2.2" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
    </svg>
    </>
  );
}

const txt = (t, y, size, fill = '#fff', stroke = '#000') => (
  <text x="50" y={y} textAnchor="middle" fontFamily="'Lilita One', system-ui" fontSize={size} fill={fill} stroke={stroke} strokeWidth={size / 9} paintOrder="stroke">{t}</text>
);

// ─────────────── ATLANTIS ───────────────
const AT = {
  SHELL: <g><path d="M50 82L18 46c4-18 20-28 32-28s28 10 32 28z" fill="#fdba74" stroke="#9a3412" strokeWidth="3" />{[-28, -14, 0, 14, 28].map((a) => <path key={a} d="M50 80L50 24" stroke="#c2410c" strokeWidth="2.5" transform={`rotate(${a} 50 80)`} />)}<path d="M40 82h20l-4 8H44z" fill="#fb923c" /></g>,
  STAR: <g><path d="M50 14l9 24 26 2-20 16 7 26-22-15-22 15 7-26-20-16 26-2z" fill="#fb7185" stroke="#9f1239" strokeWidth="3" strokeLinejoin="round" />{[[50, 30], [62, 46], [56, 62], [44, 62], [38, 46]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="2.6" fill="#fff1f2" />)}</g>,
  CORAL: <g stroke="#e11d48" strokeWidth="7" strokeLinecap="round" fill="none"><path d="M50 88V50M50 62L32 44M32 44V26M32 44L20 36M50 54L68 36M68 36V20M68 36l12-6" /><path d="M50 88V50" stroke="#fb7185" strokeWidth="3" /></g>,
  SEAHORSE: <g><path d="M56 16c12 2 16 14 8 20l-6 4c8 6 10 18 2 26-6 6-4 14 2 16-10 4-20-4-16-14 3-8-2-14-8-18-6-4-6-14 2-18-6-2-8-8-4-12 6 0 14-6 20-4z" fill="#facc15" stroke="#854d0e" strokeWidth="3" /><circle cx="58" cy="24" r="2.5" fill="#1c1917" /><path d="M40 30l-10-2" stroke="#854d0e" strokeWidth="3" /></g>,
  TURTLE: <g><ellipse cx="50" cy="52" rx="24" ry="28" fill="#16a34a" stroke="#14532d" strokeWidth="3" /><path d="M50 30l10 8v14l-10 8-10-8V38zM40 52l-12 6M60 52l12 6M50 60v18" stroke="#86efac" strokeWidth="2.5" fill="none" /><circle cx="50" cy="20" r="8" fill="#4ade80" stroke="#14532d" strokeWidth="3" /><path d="M28 38l-12-8M72 38l12-8M30 74l-10 8M70 74l10 8" stroke="#4ade80" strokeWidth="7" strokeLinecap="round" /></g>,
  KRAKEN: <g><path d="M24 50c0-20 12-34 26-34s26 14 26 34z" fill="#9333ea" stroke="#3b0764" strokeWidth="3" />{[26, 38, 50, 62, 74].map((x, i) => <path key={i} d={`M${x} 48c${i % 2 ? 6 : -6} 14 ${i % 2 ? -8 : 8} 22 ${i % 2 ? 2 : -2} 36`} stroke="#a855f7" strokeWidth="7" fill="none" strokeLinecap="round" />)}<circle cx="41" cy="38" r="5" fill="#fef08a" /><circle cx="59" cy="38" r="5" fill="#fef08a" /><circle cx="41" cy="38" r="2" fill="#000" /><circle cx="59" cy="38" r="2" fill="#000" /></g>,
  MASK: <g><path d="M50 12l8 10 14-4-2 14c8 6 10 18 4 30-6 14-16 24-24 26-8-2-18-12-24-26-6-12-4-24 4-30l-2-14 14 4z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" /><path d="M34 46h12M54 46h12" stroke="#0e7490" strokeWidth="5" strokeLinecap="round" /><path d="M50 50v12M42 70h16" stroke="#92400e" strokeWidth="3" /><circle cx="50" cy="26" r="4" fill="#22d3ee" /></g>,
  TRIDENT: <g filter="url(#s3glow)"><path d="M50 92V30M30 16v18c0 8 8 12 20 12s20-4 20-12V16M50 12v18" stroke="url(#s3gold)" strokeWidth="7" fill="none" strokeLinecap="round" /><path d="M24 20l6-10 6 10M44 16l6-10 6 10M64 20l6-10 6 10" fill="#22d3ee" /></g>,
  WILD: <g><path d="M14 40L50 16l36 24z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" />{[22, 36, 50, 64, 78].map((x) => <rect key={x} x={x - 4} y="42" width="8" height="30" fill="#fef3c7" stroke="#b45309" strokeWidth="2" />)}<rect x="12" y="72" width="76" height="8" fill="url(#s3gold)" stroke="#78350f" strokeWidth="2" />{txt('WILD', 96, 22, '#a5f3fc', '#083344')}</g>,
  CHEST: <g><rect x="16" y="44" width="68" height="40" rx="5" fill="#92400e" stroke="#451a03" strokeWidth="3" /><path d="M16 46c0-18 14-26 34-26s34 8 34 26z" fill="#b45309" stroke="#451a03" strokeWidth="3" /><path d="M16 50h68M30 22v62M70 22v62" stroke="url(#s3gold)" strokeWidth="5" /><rect x="44" y="46" width="12" height="14" rx="2" fill="url(#s3gold)" stroke="#451a03" strokeWidth="2" /><circle cx="50" cy="38" r="5" fill="url(#s3pearl)" />{txt('BONUS', 98, 18, '#fde68a', '#451a03')}</g>,
};
// Pick-bonus prizes
export const ChestItem = ({ item, bet }) => (
  <svg viewBox="0 0 100 100" className="h-full w-full">
    {item.k === 'coin' && <g><circle cx="50" cy="42" r="26" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" /><circle cx="50" cy="42" r="18" fill="none" stroke="#92400e" strokeWidth="2" />{txt(money(item.amount).replace('.00', ''), 92, 20, '#fde68a', '#1c1917')}</g>}
    {item.k === 'trident' && <g transform="translate(0 -6)">{AT.TRIDENT}{txt('TRIDENT', 98, 15, '#a5f3fc', '#083344')}</g>}
    {item.k === 'free' && <g><circle cx="50" cy="42" r="28" fill="#0e7490" stroke="#a5f3fc" strokeWidth="3" />{txt(String(item.spins), 54, 34, '#fff', '#083344')}{txt('FREE SPINS', 94, 15, '#a5f3fc', '#083344')}</g>}
    {item.k === 'collect' && <g><circle cx="50" cy="44" r="28" fill="#7f1d1d" stroke="#fca5a5" strokeWidth="3" /><path d="M38 44l8 8 16-16" stroke="#fff" strokeWidth="6" fill="none" strokeLinecap="round" />{txt('COLLECT', 94, 16, '#fecaca', '#450a0a')}</g>}
  </svg>
);
export const Poseidon = ({ className = '' }) => (
  <svg viewBox="0 0 200 220" className={className} aria-hidden="true">
    <path d="M100 20l12 18 22-10-4 24 22 2-14 18c10 18 8 44-6 62-10 14-22 22-32 22s-22-8-32-22c-14-18-16-44-6-62l-14-18 22-2-4-24 22 10z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="4" />
    <path d="M62 92c10-8 26-8 30 0M108 92c4-8 20-8 30 0" stroke="#083344" strokeWidth="6" strokeLinecap="round" fill="none" />
    <circle cx="78" cy="98" r="5" fill="#22d3ee" /><circle cx="122" cy="98" r="5" fill="#22d3ee" />
    <path d="M60 120c10 30 30 70 40 90 10-20 30-60 40-90-10 12-24 18-40 18s-30-6-40-18z" fill="#e0f2fe" stroke="#7dd3fc" strokeWidth="3" />
    {[72, 86, 100, 114, 128].map((x) => <path key={x} d={`M${x} 130c-4 20 0 40 ${x < 100 ? 6 : -6} 60`} stroke="#bae6fd" strokeWidth="3" fill="none" />)}
    <path d="M100 116v10M88 124h24" stroke="#92400e" strokeWidth="4" />
    <path d="M178 210V40M162 30v16c0 6 6 10 16 10s16-4 16-10V30M178 26v18" stroke="url(#s3gold)" strokeWidth="8" fill="none" strokeLinecap="round" filter="url(#s3glow)" />
  </svg>
);

// ─────────────── NEON OVERDRIVE ───────────────
const neonStroke = (c) => ({ stroke: c, strokeWidth: 4, fill: 'none', filter: 'url(#s3glow)', strokeLinecap: 'round', strokeLinejoin: 'round' });
const NE = {
  NODE: <g {...neonStroke('#22d3ee')}><circle cx="50" cy="50" r="30" /><path d="M50 28l20 34H30z" /><circle cx="50" cy="50" r="5" fill="#22d3ee" /></g>,
  CHIP: <g {...neonStroke('#4ade80')}><rect x="28" y="28" width="44" height="44" rx="6" /><rect x="40" y="40" width="20" height="20" />{[34, 50, 66].map((p) => <path key={p} d={`M${p} 28v-10M${p} 72v10M28 ${p}h-10M72 ${p}h10`} />)}</g>,
  DISC: <g {...neonStroke('#f472b6')}><circle cx="50" cy="50" r="32" /><circle cx="50" cy="50" r="10" /><path d="M50 22a28 28 0 0 1 26 18" /><path d="M24 60a28 28 0 0 0 14 16" /></g>,
  CORE: <g {...neonStroke('#facc15')}><path d="M50 16l29 17v34L50 84 21 67V33z" /><path d="M50 32l15 9v18l-15 9-15-9V41z" fill="#facc15" fillOpacity=".25" /></g>,
  VISOR: <g><path d="M22 58c0-22 12-36 28-36s28 14 28 36v14H22z" fill="#1e1b4b" stroke="#a78bfa" strokeWidth="4" filter="url(#s3glow)" /><path d="M26 50h48v12H26z" fill="url(#s3cyan)" opacity=".9" /><path d="M30 56h40" stroke="#fff" strokeWidth="2" opacity=".8" /></g>,
  DRONE: <g><rect x="38" y="44" width="24" height="14" rx="4" fill="#1f2937" stroke="#fb923c" strokeWidth="3" filter="url(#s3glow)" />{[[24, 36], [76, 36], [24, 70], [76, 70]].map(([x, y], i) => <g key={i}><path d={`M${x} ${y}L50 51`} stroke="#fb923c" strokeWidth="3" /><ellipse cx={x} cy={y} rx="12" ry="3" fill="none" stroke="#fdba74" strokeWidth="2.5" /></g>)}<circle cx="50" cy="51" r="3" fill="#f43f5e" /></g>,
  BIKE: <g filter="url(#s3glow)"><circle cx="26" cy="66" r="14" fill="none" stroke="#22d3ee" strokeWidth="5" /><circle cx="76" cy="66" r="14" fill="none" stroke="#f472b6" strokeWidth="5" /><path d="M26 66l18-26h22l10 26M44 40l-8-8h-8M58 40l6-10h10" stroke="#e879f9" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>,
  ANDROID: <g><path d="M28 34c0-12 10-20 22-20s22 8 22 20v24c0 14-10 24-22 24S28 72 28 58z" fill="#0f172a" stroke="url(#s3pink)" strokeWidth="4" filter="url(#s3glow)" /><rect x="34" y="40" width="12" height="6" rx="3" fill="#22d3ee" /><rect x="54" y="40" width="12" height="6" rx="3" fill="#22d3ee" /><path d="M40 64h20M50 14V6M34 54l-6 4M66 54l6 4" stroke="#f472b6" strokeWidth="3" /></g>,
  WILD: <g><rect x="10" y="22" width="80" height="56" rx="8" fill="#0f172a" stroke="url(#s3cyan)" strokeWidth="4" filter="url(#s3glow)" /><path d="M10 40h8l4-6h10M90 60h-8l-4 6H68" stroke="#f472b6" strokeWidth="2.5" fill="none" />{txt('WILD', 61, 28, '#e0f2fe', '#db2777')}<text x="52" y="61" textAnchor="middle" fontFamily="'Lilita One'" fontSize="28" fill="#22d3ee" opacity=".55">WILD</text></g>,
  OVER: <g><path d="M16 66a34 34 0 0 1 68 0" fill="none" stroke="#f43f5e" strokeWidth="8" strokeLinecap="round" filter="url(#s3glow)" /><path d="M16 66a34 34 0 0 1 40-33" fill="none" stroke="#facc15" strokeWidth="8" strokeLinecap="round" /><path d="M50 66L72 40" stroke="#fff" strokeWidth="4" strokeLinecap="round" /><circle cx="50" cy="66" r="5" fill="#fff" />{txt('OVERDRIVE', 92, 15, '#fda4af', '#4c0519')}</g>,
};
const NeMult = ({ v }) => (
  <g><path d="M50 8l36 21v42L50 92 14 71V29z" fill="#1e1b4b" stroke="url(#s3violet)" strokeWidth="4" filter="url(#s3glow)" /><path d="M56 16L40 50h12l-8 30 20-38H52z" fill="#facc15" opacity=".35" />{txt(`x${v}`, 62, v >= 10 ? 30 : 34, '#fef08a', '#581c87')}</g>
);

// ─────────────── DRAGON'S FORTUNE ───────────────
const DR = {
  JADE: <g><circle cx="50" cy="50" r="32" fill="url(#s3jade)" stroke="#14532d" strokeWidth="3" /><circle cx="50" cy="50" r="11" fill="#450a0a" stroke="#14532d" strokeWidth="3" /><path d="M30 40a24 24 0 0 1 14-16" stroke="#dcfce7" strokeWidth="3" fill="none" opacity=".8" /></g>,
  COIN: <g><circle cx="50" cy="50" r="32" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" /><rect x="42" y="42" width="16" height="16" fill="#450a0a" stroke="#78350f" strokeWidth="2" />{[[50, 28], [72, 50], [50, 72], [28, 50]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="3" fill="#92400e" />)}</g>,
  FAN: <g>{Array.from({ length: 9 }, (_, i) => <path key={i} d="M50 80L50 20" stroke={i % 2 ? '#fef3c7' : '#dc2626'} strokeWidth="9" transform={`rotate(${-60 + i * 15} 50 80)`} />)}<path d="M14 58a40 40 0 0 1 72 0" stroke="url(#s3gold)" strokeWidth="4" fill="none" /><circle cx="50" cy="80" r="5" fill="url(#s3gold)" /></g>,
  KNOT: <g><path d="M50 14l16 16-16 16-16-16z" fill="#dc2626" stroke="#7f1d1d" strokeWidth="3" /><path d="M50 30l12 12-12 12-12-12z" fill="#ef4444" stroke="#7f1d1d" strokeWidth="2" /><circle cx="50" cy="46" r="5" fill="url(#s3gold)" /><path d="M44 56l-4 30M50 56v32M56 56l4 30" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" /></g>,
  KOI: <g><path d="M18 50c12-20 40-24 56-8l10-10v36l-10-10c-16 16-44 12-56-8z" fill="#fff7ed" stroke="#9a3412" strokeWidth="3" /><path d="M34 40c6 4 8 10 4 18M52 36c6 6 6 14 0 22" fill="#f97316" stroke="#f97316" strokeWidth="6" strokeLinecap="round" /><circle cx="26" cy="48" r="2.6" fill="#000" /></g>,
  INGOT: <g><path d="M12 56c6 18 70 18 76 0l-8-10H20z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" /><ellipse cx="50" cy="44" rx="20" ry="12" fill="url(#s3goldH)" stroke="#78350f" strokeWidth="3" /><path d="M24 52c8 8 44 8 52 0" stroke="#fff7c2" strokeWidth="2" fill="none" /></g>,
  LION: <g><circle cx="50" cy="50" r="34" fill="#a16207" stroke="#451a03" strokeWidth="3" />{Array.from({ length: 12 }, (_, i) => <circle key={i} cx={50 + 30 * Math.cos((i / 12) * Math.PI * 2)} cy={50 + 30 * Math.sin((i / 12) * Math.PI * 2)} r="6" fill="#ca8a04" />)}<circle cx="50" cy="52" r="20" fill="url(#s3gold)" stroke="#451a03" strokeWidth="2" /><circle cx="43" cy="46" r="3" fill="#000" /><circle cx="57" cy="46" r="3" fill="#000" /><path d="M42 60c4 4 12 4 16 0" stroke="#7f1d1d" strokeWidth="3" fill="none" /></g>,
  PHOENIX: <g><path d="M50 30c-14-14-36-6-36 10 10-6 20-2 26 6-12-2-22 6-20 18 8-8 18-8 24-2" fill="url(#s3fire)" stroke="#7c2d12" strokeWidth="2.5" /><path d="M50 30c14-14 36-6 36 10-10-6-20-2-26 6 12-2 22 6 20 18-8-8-18-8-24-2" fill="url(#s3fire)" stroke="#7c2d12" strokeWidth="2.5" /><path d="M50 28v40c0 10-6 18-10 22M50 68c0 10 6 18 10 22" stroke="#fb923c" strokeWidth="4" fill="none" /><circle cx="50" cy="24" r="6" fill="#fde047" stroke="#7c2d12" strokeWidth="2" /></g>,
  DRAGON: <g><path d="M20 56c0-24 16-40 34-40 14 0 26 10 28 24l-12 2 6 10-14-2c-2 10-8 16-16 18l4 12-12-6-6 10c-8-6-12-16-12-28z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" /><circle cx="58" cy="36" r="4" fill="#dc2626" /><path d="M34 20c-6-6-14-6-18 0M48 16c0-8-4-12-10-14" stroke="#fde68a" strokeWidth="3" fill="none" /><path d="M82 46c6 2 10 8 10 14-6-4-10-4-16-2" fill="url(#s3fire)" />{txt('WILD', 96, 20, '#fde68a', '#7f1d1d')}</g>,
  PEARL: <g><path d="M50 8c8 12 22 14 22 34 0 6-2 10-4 12 6-2 10-8 10-14 4 10 2 26-8 34-6 6-12 8-20 8s-14-2-20-8c-10-8-12-24-8-34 0 6 4 12 10 14-2-2-4-6-4-12 0-20 14-22 22-34z" fill="url(#s3fire)" opacity=".9" /><circle cx="50" cy="60" r="20" fill="url(#s3pearl)" stroke="#bfdbfe" strokeWidth="2" /><circle cx="44" cy="54" r="5" fill="#fff" />{txt('FREE', 96, 18, '#fde68a', '#7f1d1d')}</g>,
  LANTERN: <g><path d="M44 10h12v8H44z" fill="url(#s3gold)" /><ellipse cx="50" cy="48" rx="28" ry="30" fill="url(#s3red)" stroke="#7f1d1d" strokeWidth="3" /><path d="M50 18v60M34 22c-6 16-6 36 0 52M66 22c6 16 6 36 0 52" stroke="#fbbf24" strokeWidth="2" fill="none" opacity=".7" /><rect x="40" y="76" width="20" height="6" fill="url(#s3gold)" /><path d="M46 82l-2 12M50 82v14M54 82l2 12" stroke="#fbbf24" strokeWidth="2.5" /></g>,
};
export const DragonTall = ({ className = '' }) => (
  <svg viewBox="0 0 60 180" preserveAspectRatio="none" className={className} aria-hidden="true">
    <path d="M30 6c14 6 20 20 12 32-8 10-22 14-20 28s20 18 20 34-18 22-18 38 12 24 8 36" stroke="url(#s3gold)" strokeWidth="14" fill="none" strokeLinecap="round" />
    <path d="M30 6c14 6 20 20 12 32-8 10-22 14-20 28s20 18 20 34-18 22-18 38 12 24 8 36" stroke="#b45309" strokeWidth="3" strokeDasharray="2 6" fill="none" />
    <path d="M18 18c0-10 8-16 16-14 10 2 14 10 12 18l-8 2 4 6-10 2c-8 0-14-6-14-14z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="2" />
    <circle cx="36" cy="14" r="2.5" fill="#dc2626" />
    {txt('WILD', 176, 15, '#fde68a', '#7f1d1d')}
  </svg>
);

// ─────────────── COSMIC COLLAPSE ───────────────
const CO = {
  ASTEROID: <g><path d="M26 40l14-16 24 2 14 18-4 22-18 14-22-6-10-18z" fill="#78716c" stroke="#292524" strokeWidth="3" /><circle cx="44" cy="44" r="6" fill="#57534e" /><circle cx="62" cy="58" r="4" fill="#57534e" /><circle cx="40" cy="64" r="3" fill="#a8a29e" /></g>,
  COMET: <g><path d="M78 22L36 54" stroke="#a5f3fc" strokeWidth="18" strokeLinecap="round" opacity=".35" /><path d="M78 22L40 52" stroke="#e0f2fe" strokeWidth="8" strokeLinecap="round" opacity=".6" /><circle cx="34" cy="60" r="16" fill="url(#s3pearl)" filter="url(#s3glow)" /></g>,
  MOON: <g><path d="M60 16a34 34 0 1 0 22 54A28 28 0 1 1 60 16z" fill="#e5e7eb" stroke="#6b7280" strokeWidth="3" /><circle cx="36" cy="44" r="5" fill="#d1d5db" /><circle cx="46" cy="66" r="4" fill="#d1d5db" /></g>,
  CRYSTAL: <g filter="url(#s3glow)"><path d="M50 10l16 22-6 50H40l-6-50z" fill="url(#s3violet)" stroke="#ede9fe" strokeWidth="2.5" /><path d="M50 10v72M34 32h32" stroke="#f5f3ff" strokeWidth="1.5" opacity=".7" /><path d="M28 46l8 6-4 26-8-4zM72 46l-8 6 4 26 8-4z" fill="#a78bfa" stroke="#ede9fe" strokeWidth="2" /></g>,
  SATELLITE: <g><rect x="40" y="38" width="20" height="24" rx="3" fill="#cbd5e1" stroke="#334155" strokeWidth="3" /><rect x="8" y="42" width="28" height="16" fill="#1d4ed8" stroke="#93c5fd" strokeWidth="2" /><rect x="64" y="42" width="28" height="16" fill="#1d4ed8" stroke="#93c5fd" strokeWidth="2" /><path d="M16 42v16M24 42v16M72 42v16M80 42v16M50 38V24" stroke="#93c5fd" strokeWidth="1.5" /><circle cx="50" cy="20" r="5" fill="#f87171" /></g>,
  PLANET: <g><circle cx="50" cy="50" r="24" fill="url(#s3planet)" /><ellipse cx="50" cy="52" rx="42" ry="11" fill="none" stroke="#fde68a" strokeWidth="4" transform="rotate(-18 50 52)" /><path d="M30 44c10-4 30-4 40 0" stroke="#fdba74" strokeWidth="3" opacity=".7" /></g>,
  SUN: <g filter="url(#s3glow)">{Array.from({ length: 12 }, (_, i) => <path key={i} d="M50 6l5 14h-10z" fill="#fde047" transform={`rotate(${i * 30} 50 50)`} />)}<circle cx="50" cy="50" r="27" fill="url(#s3sun)" /></g>,
  GALAXY: <g filter="url(#s3glow)"><ellipse cx="50" cy="50" rx="40" ry="16" fill="#c026d3" opacity=".25" transform="rotate(-25 50 50)" />{[0, 120, 240].map((r) => <path key={r} d="M50 50c10-4 22 0 28 12" stroke="#f0abfc" strokeWidth="5" fill="none" strokeLinecap="round" transform={`rotate(${r} 50 50)`} />)}<circle cx="50" cy="50" r="9" fill="#fdf4ff" /></g>,
  WILD: <g filter="url(#s3glow)"><path d="M50 4l10 32 34 2-28 18 12 34-28-22-28 22 12-34L6 38l34-2z" fill="url(#s3sun)" stroke="#fff" strokeWidth="2" />{txt('WILD', 62, 22, '#fff', '#7c3aed')}</g>,
  HOLE: <g><circle cx="50" cy="50" r="44" fill="url(#s3hole)" /><ellipse cx="50" cy="50" rx="40" ry="10" fill="none" stroke="#f9a8d4" strokeWidth="3" transform="rotate(-20 50 50)" opacity=".85" /><circle cx="50" cy="50" r="16" fill="#000" />{txt('BONUS', 96, 16, '#f5d0fe', '#3b0764')}</g>,
};
const Orb = ({ v }) => (
  <g><circle cx="50" cy="50" r="36" fill="url(#s3orb)" filter="url(#s3glow)" /><ellipse cx="50" cy="50" rx="44" ry="10" fill="none" stroke="#e9d5ff" strokeWidth="2.5" transform="rotate(-15 50 50)" />{txt(`x${v}`, 60, v >= 10 ? 26 : 30, '#fff', '#4c1d95')}</g>
);

// ─────────────── PHARAOH'S GOLD ───────────────
const PH = {
  ANKH: <g><ellipse cx="50" cy="28" rx="13" ry="16" fill="none" stroke="url(#s3gold)" strokeWidth="9" /><path d="M50 42v46M26 48h48" stroke="url(#s3gold)" strokeWidth="10" strokeLinecap="round" /></g>,
  LOTUS: <g><path d="M50 18c10 12 12 30 0 52-12-22-10-40 0-52z" fill="#5eead4" stroke="#115e59" strokeWidth="3" /><path d="M50 70c-14-6-26-20-28-40 12 4 22 16 28 40zM50 70c14-6 26-20 28-40-12 4-22 16-28 40z" fill="#2dd4bf" stroke="#115e59" strokeWidth="3" /><path d="M24 80h52" stroke="url(#s3gold)" strokeWidth="5" strokeLinecap="round" /></g>,
  EYE: <g><path d="M10 48c20-22 60-22 80 0-20 18-60 18-80 0z" fill="#fef3c7" stroke="#1e3a8a" strokeWidth="5" /><circle cx="50" cy="48" r="12" fill="url(#s3lapis)" /><circle cx="50" cy="48" r="5" fill="#0f172a" /><path d="M40 60l-6 22c-2 6 6 8 8 2M58 60l14 14" stroke="#1e3a8a" strokeWidth="5" fill="none" strokeLinecap="round" /><path d="M14 36c14-10 36-14 60-6" stroke="url(#s3gold)" strokeWidth="4" fill="none" /></g>,
  CAT: <g><path d="M34 88c-6-20-2-40 6-50l-4-20 12 12c2-2 6-2 8 0l12-12-4 20c8 10 12 30 6 50z" fill="#1c1917" stroke="url(#s3gold)" strokeWidth="3" /><circle cx="44" cy="40" r="3" fill="#fde047" /><circle cx="56" cy="40" r="3" fill="#fde047" /><circle cx="62" cy="52" r="3" fill="url(#s3gold)" /><path d="M40 62h20" stroke="url(#s3gold)" strokeWidth="4" /></g>,
  SPHINX: <g><path d="M8 78h84v8H8zM14 78c0-12 8-18 20-18h30c6 0 10-4 10-10V30c0-10 6-16 10-16-2 8 4 12 4 22v42z" fill="url(#s3sand)" stroke="#78350f" strokeWidth="3" /><path d="M70 22h18v24c-4 4-14 4-18 0z" fill="#d6a85b" stroke="#78350f" strokeWidth="2" /><path d="M72 28h14M72 34h14M72 40h14" stroke="#1e3a8a" strokeWidth="2.5" /></g>,
  MASK: <g><path d="M22 34c0-16 12-26 28-26s28 10 28 26l6 40c-10 12-22 18-34 18s-24-6-34-18z" fill="url(#s3lapis)" stroke="#78350f" strokeWidth="3" />{[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${18 + i} ${44 + i * 8}h${64 - i * 2}`} stroke="url(#s3gold)" strokeWidth="4" />)}<path d="M34 30c0-10 8-16 16-16s16 6 16 16v24c0 10-8 18-16 18s-16-8-16-18z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="2" /><path d="M40 38h6M54 38h6" stroke="#0f172a" strokeWidth="3" strokeLinecap="round" /><path d="M46 74h8v12h-8z" fill="url(#s3lapis)" /></g>,
  PHARAOH: <g><path d="M24 30c0-14 12-22 26-22s26 8 26 22l4 34c-8 8-18 12-30 12s-22-4-30-12z" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" />{[38, 46, 54].map((y) => <path key={y} d={`M22 ${y}h56`} stroke="#1e40af" strokeWidth="3" />)}<path d="M38 28h24v22c0 8-6 12-12 12s-12-4-12-12z" fill="#c08457" stroke="#78350f" strokeWidth="2" /><circle cx="44" cy="38" r="2" fill="#000" /><circle cx="56" cy="38" r="2" fill="#000" /><path d="M84 30c6 0 8 6 4 10L78 76" stroke="url(#s3lapis)" strokeWidth="5" fill="none" />{txt('WILD', 96, 20, '#fde68a', '#1e3a8a')}</g>,
  SCARAB: <g><path d="M50 30c-24-16-44-2-42 20 12-8 24-8 32 0M50 30c24-16 44-2 42 20-12-8-24-8-32 0" fill="#14b8a6" stroke="#134e4a" strokeWidth="2.5" opacity=".9" /><ellipse cx="50" cy="56" rx="16" ry="22" fill="url(#s3gold)" stroke="#78350f" strokeWidth="3" /><circle cx="50" cy="32" r="8" fill="url(#s3gold)" stroke="#78350f" strokeWidth="2" /><path d="M50 40v38" stroke="#78350f" strokeWidth="2" /><circle cx="50" cy="20" r="7" fill="#dc2626" opacity=".85" />{txt('FREE', 98, 18, '#fde68a', '#78350f')}</g>,
  MYSTERY: <g><rect x="10" y="10" width="80" height="80" rx="4" fill="url(#s3stone)" stroke="#78350f" strokeWidth="3" /><path d="M10 36h80M10 64h80M36 10v26M64 36v28M36 64v26" stroke="#92643a" strokeWidth="2" opacity=".6" />{txt('?', 66, 44, '#fde68a', '#78350f')}</g>,
};
export const MULT_STONE = (v) => <g><rect x="10" y="10" width="80" height="80" rx="10" fill="url(#s3stone)" stroke="#78350f" strokeWidth="3" />{txt(`x${v}`, 64, 36, v >= 5 ? '#fde68a' : '#fff7ed', '#78350f')}</g>;

export const ART3 = { atlantis: AT, neon: NE, dragon: DR, cosmic: CO, pharaoh: PH, frost: FROST_ART };
export const SYMS3 = {
  atlantis: Object.keys(AT), neon: [...Object.keys(NE), 'MULT'], dragon: Object.keys(DR), cosmic: [...Object.keys(CO), 'GRAVITY'], pharaoh: Object.keys(PH).filter((k) => k !== 'MYSTERY'), frost: Object.keys(FROST_ART),
};
export const NAMES3 = {
  SHELL: 'Shell', STAR: 'Starfish', CORAL: 'Coral', SEAHORSE: 'Seahorse', TURTLE: 'Turtle', KRAKEN: 'Kraken', MASK: 'Mask', TRIDENT: 'Trident', WILD: 'Wild', CHEST: 'Chest',
  NODE: 'Node', CHIP: 'Chip', DISC: 'Disc', CORE: 'Core', VISOR: 'Visor', DRONE: 'Drone', BIKE: 'Bike', ANDROID: 'Android', MULT: 'Multiplier', OVER: 'Overdrive',
  JADE: 'Jade', COIN: 'Coin', FAN: 'Fan', KNOT: 'Knot', KOI: 'Koi', INGOT: 'Ingot', LION: 'Lion', PHOENIX: 'Phoenix', DRAGON: 'Dragon Wild', PEARL: 'Pearl', LANTERN: 'Lantern',
  ASTEROID: 'Asteroid', COMET: 'Comet', MOON: 'Moon', CRYSTAL: 'Crystal', SATELLITE: 'Satellite', PLANET: 'Planet', SUN: 'Sun', GALAXY: 'Galaxy', GRAVITY: 'Gravity orb', HOLE: 'Black Hole',
  ...FROST_NAMES,
  ANKH: 'Ankh', LOTUS: 'Lotus', EYE: 'Eye', CAT: 'Cat', SPHINX: 'Sphinx', PHARAOH: 'Pharaoh Wild', SCARAB: 'Golden Scarab', MYSTERY: 'Mystery',
};

const TILE = {
  atlantis: (s) => `rounded-lg ${['WILD', 'MASK', 'TRIDENT', 'CHEST'].includes(s) ? 'bg-[radial-gradient(circle_at_50%_40%,rgba(34,211,238,0.35),rgba(8,47,73,0.85))] ring-1 ring-amber-300/70' : 'bg-[radial-gradient(circle_at_50%_35%,rgba(14,116,144,0.55),rgba(8,47,73,0.9))] ring-1 ring-cyan-300/20'}`,
  neon: (s) => `rounded-md bg-[linear-gradient(160deg,rgba(30,27,75,0.9),rgba(2,6,23,0.95))] ring-1 ${['WILD', 'OVER', 'MULT'].includes(s) ? 'ring-fuchsia-400/80 shadow-[0_0_10px_rgba(232,121,249,0.5)]' : 'ring-cyan-400/25'}`,
  dragon: (s) => `rounded-md border-2 ${['DRAGON', 'PEARL', 'LANTERN', 'PHOENIX'].includes(s) ? 'border-amber-300 bg-[radial-gradient(circle_at_50%_35%,#b91c1c,#450a0a)]' : 'border-amber-600/60 bg-[radial-gradient(circle_at_50%_35%,#7f1d1d,#1c0505)]'}`,
  cosmic: () => 'rounded-full',
  frost: FROST_TILE,
  pharaoh: (s) => `rounded-sm ${['PHARAOH', 'SCARAB', 'MASK'].includes(s) ? 'bg-[linear-gradient(180deg,#d6a85b,#7c5124)] ring-2 ring-amber-300/80' : 'bg-[linear-gradient(180deg,#c9a06a,#8a6239)] ring-1 ring-amber-900/60'} shadow-[inset_0_2px_0_rgba(255,255,255,0.25),inset_0_-3px_0_rgba(0,0,0,0.25)]`,
};

/** One symbol cell for a premium slot. */
export function Sym3({ game, s, v, className = '' }) {
  if (!s) return null;
  if (SLOT_IMG[game]?.[s]) {
    const sp = { WILD: '#22d3ee', CHEST: '#facc15' }[s];
    const tier = sp ? 'special' : ['SHELL', 'STAR', 'CORAL'].includes(s) ? 'low' : ['SEAHORSE', 'TURTLE'].includes(s) ? 'mid' : 'premium';
    return <PaintedSym src={SLOT_IMG[game][s]} alt={NAMES3[s] || s} tier={tier} glow={sp} className={className} />;
  }
  let art = ART3[game]?.[s];
  if (game === 'neon' && s === 'MULT') art = <NeMult v={v} />;
  if (game === 'cosmic' && s === 'GRAVITY') art = <Orb v={v} />;
  return (
    <div className={`relative h-full w-full ${TILE[game]?.(s) || ''} ${className}`}>
      <svg viewBox="0 0 100 100" className="h-full w-full p-[6%]" role="img" aria-label={NAMES3[s] || s}>{art}</svg>
    </div>
  );
}

/** Game logos (used in headers and lobby tiles). */
export function Logo3({ game, className = '' }) {
  const L = {
    atlantis: (
      <svg viewBox="0 0 300 90" className={className} aria-label="Atlantis – Kingdom of the Deep">
        <path d="M20 70h260" stroke="url(#s3gold)" strokeWidth="3" /><path d="M150 4l14 12h-28z" fill="url(#s3gold)" />
        <text x="150" y="58" textAnchor="middle" fontFamily="'Lilita One'" fontSize="50" textLength="250" lengthAdjust="spacingAndGlyphs" letterSpacing="4" fill="url(#s3gold)" stroke="#451a03" strokeWidth="2.5" paintOrder="stroke">ATLANTIS</text>
        <text x="150" y="86" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="15" letterSpacing="5" fill="#a5f3fc">KINGDOM OF THE DEEP</text>
      </svg>
    ),
    neon: (
      <svg viewBox="0 0 300 90" className={className} aria-label="Neon Overdrive">
        <text x="150" y="44" textAnchor="middle" fontFamily="'Lilita One'" fontSize="40" letterSpacing="6" fill="none" stroke="#f472b6" strokeWidth="2.5" filter="url(#s3glow)">NEON</text>
        <text x="152" y="82" textAnchor="middle" fontFamily="'Lilita One'" fontSize="34" textLength="250" lengthAdjust="spacingAndGlyphs" letterSpacing="3" fill="#22d3ee" opacity=".5">OVERDRIVE</text>
        <text x="150" y="80" textAnchor="middle" fontFamily="'Lilita One'" fontSize="34" textLength="250" lengthAdjust="spacingAndGlyphs" letterSpacing="3" fill="#e0f2fe" stroke="#0891b2" strokeWidth="1.5" filter="url(#s3glow)">OVERDRIVE</text>
      </svg>
    ),
    dragon: (
      <svg viewBox="0 0 300 90" className={className} aria-label="Dragon's Fortune – The Golden Empire">
        <rect x="6" y="6" width="288" height="78" rx="6" fill="#7f1d1d" stroke="url(#s3gold)" strokeWidth="4" />
        <rect x="14" y="14" width="272" height="62" rx="4" fill="none" stroke="#fbbf24" strokeWidth="1.5" strokeDasharray="6 4" />
        <text x="150" y="52" textAnchor="middle" fontFamily="'Lilita One'" fontSize="36" textLength="262" lengthAdjust="spacingAndGlyphs" letterSpacing="2" fill="url(#s3gold)" stroke="#450a0a" strokeWidth="2" paintOrder="stroke">DRAGON&apos;S FORTUNE</text>
        <text x="150" y="70" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="12" letterSpacing="5" fill="#fde68a">THE GOLDEN EMPIRE</text>
      </svg>
    ),
    cosmic: (
      <svg viewBox="0 0 300 90" className={className} aria-label="Cosmic Collapse">
        <ellipse cx="150" cy="46" rx="140" ry="18" fill="none" stroke="#c4b5fd" strokeWidth="2" opacity=".5" />
        <text x="150" y="44" textAnchor="middle" fontFamily="'Lilita One'" fontSize="38" textLength="240" lengthAdjust="spacingAndGlyphs" letterSpacing="8" fill="url(#s3violet)" stroke="#1e1b4b" strokeWidth="2" paintOrder="stroke">COSMIC</text>
        <text x="150" y="80" textAnchor="middle" fontFamily="'Lilita One'" fontSize="30" textLength="240" lengthAdjust="spacingAndGlyphs" letterSpacing="10" fill="#f0abfc" stroke="#3b0764" strokeWidth="2" paintOrder="stroke">COLLAPSE</text>
      </svg>
    ),
    pharaoh: (
      <svg viewBox="0 0 300 90" className={className} aria-label="Pharaoh's Gold – Secrets of Egypt">
        <path d="M150 2L190 34H110z" fill="url(#s3gold)" opacity=".9" />
        <text x="150" y="62" textAnchor="middle" fontFamily="'Lilita One'" fontSize="40" textLength="280" lengthAdjust="spacingAndGlyphs" letterSpacing="3" fill="url(#s3gold)" stroke="#1e3a8a" strokeWidth="2.5" paintOrder="stroke">PHARAOH&apos;S GOLD</text>
        <text x="150" y="84" textAnchor="middle" fontFamily="'Barlow Condensed'" fontWeight="800" fontSize="14" letterSpacing="6" fill="#5eead4">SECRETS OF EGYPT</text>
      </svg>
    ),
  };
  if (game === 'frost') return <FrostLogo className={className} />;
  if (game === 'moonridge') return <MoonLogo className={className} />;
  if (game === 'mummy') return <MummyLogo className={className} />;
  if (game === 'polarcatch') return <PolarLogo className={className} />;
  if (game === 'brick') return <BrickLogo className={className} />;
  if (game === 'stampede') return <StampedeLogo className={className} />;
  if (game === 'chicken') return <ChickenLogo className={className} />;
  if (game === 'mines') return <MinesLogo className={className} />;
  if (game === 'keno') return <KenoLogo className={className} />;
  if (game === 'genie') return <GenieLogo className={className} />;
  if (game === 'tigerdragon') return <TDLogo className={className} />;
  return L[game] || null;
}

/** Lobby thumbnail emblems (viewBox 0 0 100 100). Uses the page-level defs. */
export const LOBBY_ART3 = {
  moonridge: MOON_LOBBY,
  mummy: MUMMY_LOBBY,
  polarcatch: POLAR_LOBBY,
  brick: BRICK_LOBBY,
  stampede: STAMPEDE_LOBBY,
  chicken: CHICKEN_LOBBY,
  mines: MINES_LOBBY,
  keno: KENO_LOBBY,
  genie: GENIE_LOBBY,
  tigerdragon: TD_LOBBY,
  frost: FROST_LOBBY,
  atlantis: <g><path d="M10 70l40-26 40 26z" fill="url(#s3gold)" />{[20, 35, 50, 65, 80].map((x) => <rect key={x} x={x - 3} y="70" width="6" height="18" fill="#fde68a" />)}<g transform="translate(30 4) scale(.4)">{AT.TRIDENT}</g>{[[18, 30], [82, 22], [74, 46]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="3" fill="none" stroke="#a5f3fc" strokeWidth="1.5" />)}</g>,
  neon: <g><path d="M4 92V54h10v38M18 92V40h12v52M34 92V58h8v34M60 92V36h12v56M76 92V50h10v42" fill="#1e1b4b" stroke="#a78bfa" strokeWidth="1" /><g transform="translate(25 16) scale(.5)">{NE.ANDROID}</g><path d="M6 24h20" stroke="#22d3ee" strokeWidth="2" filter="url(#s3glow)" /><path d="M70 20h22" stroke="#f472b6" strokeWidth="2" filter="url(#s3glow)" /></g>,
  dragon: <g><g transform="translate(18 10) scale(.64)">{DR.DRAGON}</g><g transform="translate(-2 48) scale(.36)">{DR.LANTERN}</g><g transform="translate(66 48) scale(.36)">{DR.LANTERN}</g></g>,
  cosmic: <g><circle cx="50" cy="50" r="40" fill="url(#s3hole)" /><ellipse cx="50" cy="50" rx="44" ry="12" fill="none" stroke="#f9a8d4" strokeWidth="2.5" transform="rotate(-20 50 50)" /><circle cx="50" cy="50" r="14" fill="#000" /><g transform="translate(64 6) scale(.3)">{CO.PLANET}</g><g transform="translate(6 62) scale(.28)">{CO.SUN}</g></g>,
  pharaoh: <g><path d="M8 88L50 22l42 66z" fill="url(#s3sand)" stroke="#78350f" strokeWidth="2" /><path d="M50 22l12 66" stroke="#92643a" strokeWidth="1.5" opacity=".6" /><g transform="translate(26 30) scale(.48)">{PH.MASK}</g></g>,
};
