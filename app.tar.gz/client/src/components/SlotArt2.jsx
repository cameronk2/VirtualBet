// Original symbol artwork for Nebula Clusters, Coin Vault, Fruit Shack and Starlight Observatory
// (inline SVG; no third-party assets). Shapes use layered gradients, bevels and glints so the
// symbols read as polished objects rather than flat icons.
import { useId } from 'react';
import { SLOT_CUT, useCut } from '../assets/cut/index.js';
import { JACKPOTS } from '../../../server/games/slots2.js';

// Every symbol gets private gradient ids: a shared id whose first copy sits in a hidden element
// (e.g. a paytable that is display:none on phones) would leave every other copy unpainted.
const useU = () => useId().replace(/[^a-zA-Z0-9]/g, '');

const Svg = ({ children, label }) => <svg viewBox="0 0 64 64" className="h-full w-full overflow-visible" role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : 'true'}>{children}</svg>;
const Glint = ({ x, y, s = 1 }) => <path d={`M${x} ${y - 5 * s}l${1.2 * s} ${3.8 * s} ${3.8 * s} ${1.2 * s}-${3.8 * s} ${1.2 * s}-${1.2 * s} ${3.8 * s}-${1.2 * s}-${3.8 * s}-${3.8 * s}-${1.2 * s} ${3.8 * s}-${1.2 * s}z`} fill="#fff" opacity=".9" />;

// ── Card royals: bevelled metallic letters, coloured per rank ──
const LETTERS = { 10: ['#e0f2fe', '#38bdf8', '#075985'], J: ['#dcfce7', '#22c55e', '#14532d'], Q: ['#fce7f3', '#ec4899', '#831843'], K: ['#fef3c7', '#f59e0b', '#78350f'], A: ['#ede9fe', '#8b5cf6', '#3b0764'] };
function Letter({ ch }) {
  const [hi, mid, lo] = LETTERS[ch];
  const u = useU(); const id = `${u}l2${ch}`;
  const size = ch === '10' ? 31 : 40;
  const common = { x: 32, y: 46, textAnchor: 'middle', fontSize: size, fontFamily: "'Lilita One', system-ui", letterSpacing: ch === '10' ? -1 : 0 };
  return (
    <Svg label={ch}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={hi} /><stop offset=".45" stopColor={mid} /><stop offset="1" stopColor={lo} /></linearGradient>
        <linearGradient id={`${id}h`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".9" /><stop offset=".45" stopColor="#fff" stopOpacity="0" /></linearGradient>
      </defs>
      <text {...common} y={48} fill="#000" opacity=".45">{ch}</text>
      <text {...common} fill={`url(#${id})`} stroke="#0b1020" strokeWidth="5" paintOrder="stroke" strokeLinejoin="round">{ch}</text>
      <text {...common} fill={`url(#${id}h)`}>{ch}</text>
      <text {...common} fill="none" stroke={hi} strokeOpacity=".7" strokeWidth=".8">{ch}</text>
      <Glint x={ch === '10' ? 46 : 42} y={22} s={0.8} />
    </Svg>
  );
}

// ── Nebula gems: faceted stones ──
const GEM = {
  RED: ['#fecdd3', '#f43f5e', '#881337', [[32, 5], [55, 19], [55, 45], [32, 59], [9, 45], [9, 19]]],
  ORG: ['#ffedd5', '#fb923c', '#7c2d12', [[32, 4], [58, 32], [32, 60], [6, 32]]],
  YEL: ['#fef9c3', '#facc15', '#713f12', [[32, 4], [40, 22], [60, 24], [45, 37], [50, 57], [32, 46], [14, 57], [19, 37], [4, 24], [24, 22]]],
  GRN: ['#dcfce7', '#22c55e', '#14532d', [[17, 9], [47, 9], [58, 32], [47, 55], [17, 55], [6, 32]]],
  BLU: ['#e0f2fe', '#3b82f6', '#1e3a8a', Array.from({ length: 12 }, (_, i) => [32 + 26 * Math.cos((i / 12) * Math.PI * 2 - Math.PI / 2), 32 + 26 * Math.sin((i / 12) * Math.PI * 2 - Math.PI / 2)])],
  PUR: ['#f3e8ff', '#a855f7', '#3b0764', [[32, 4], [44, 16], [60, 20], [52, 36], [56, 54], [32, 48], [8, 54], [12, 36], [4, 20], [20, 16]]],
};
function Gem({ s }) {
  const u = useU(); const [hi, mid, lo, pts] = GEM[s];
  const inner = pts.map(([x, y]) => [32 + (x - 32) * 0.52, 30 + (y - 32) * 0.52]);
  const P = (a) => a.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  return (
    <Svg label={s}>
      <defs>
        <radialGradient id={`${u}g2${s}`} cx=".38" cy=".3" r=".85"><stop offset="0" stopColor={hi} /><stop offset=".45" stopColor={mid} /><stop offset="1" stopColor={lo} /></radialGradient>
        <linearGradient id={`${u}g2${s}t`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".85" /><stop offset=".6" stopColor={hi} stopOpacity=".25" /><stop offset="1" stopColor={mid} stopOpacity=".1" /></linearGradient>
      </defs>
      <polygon points={P(pts.map(([x, y]) => [x + 1, y + 2]))} fill="#000" opacity=".35" />
      <polygon points={P(pts)} fill={`url(#${u}g2${s})`} stroke={lo} strokeWidth="1.5" strokeLinejoin="round" />
      {pts.map(([x, y], i) => {
        const [ix, iy] = inner[i], [nx, ny] = pts[(i + 1) % pts.length], [jx, jy] = inner[(i + 1) % pts.length];
        const shade = Math.sin((i / pts.length) * Math.PI * 2 + 1.2);
        return <polygon key={i} points={P([[x, y], [nx, ny], [jx, jy], [ix, iy]])} fill={shade > 0 ? '#fff' : '#000'} opacity={Math.abs(shade) * 0.22} />;
      })}
      <polygon points={P(inner)} fill={`url(#${u}g2${s}t)`} stroke="#fff" strokeOpacity=".5" strokeWidth=".8" />
      <Glint x={24} y={18} s={0.9} />
    </Svg>
  );
}
const Comet = () => { const u = useU(); return (
  <Svg label="Comet">
    <defs><linearGradient id={`${u}cm2t`} x1="0" y1="1" x2="1" y2="0"><stop offset="0" stopColor="#22d3ee" stopOpacity="0" /><stop offset="1" stopColor="#e0f2fe" /></linearGradient>
      <radialGradient id={`${u}cm2h`} cx=".4" cy=".35" r=".7"><stop offset="0" stopColor="#fff" /><stop offset=".5" stopColor="#a5f3fc" /><stop offset="1" stopColor="#0891b2" /></radialGradient></defs>
    <path d="M4 58C16 42 30 28 42 20l6 6C38 36 24 48 4 58z" fill={`url(#${u}cm2t)`} />
    <path d="M10 56C22 42 32 32 44 24" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" opacity=".7" />
    <circle cx="46" cy="18" r="12" fill={`url(#${u}cm2h)`} stroke="#e0f2fe" strokeWidth="1.5" />
    <Glint x={42} y={14} s={0.9} />
    <rect x="8" y="49" width="48" height="13" rx="4" fill="#0b1520" stroke="#22d3ee" strokeWidth="1.5" />
    <text x="32" y="59" textAnchor="middle" fontSize="9" fontFamily="'Lilita One', system-ui" letterSpacing="1" fill="#a5f3fc">COMET</text>
  </Svg>
); };

// ── Coin Vault: polished bell, bar, sevens, the vault-door wild and value coins ──
const GOLD = (id) => <linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fef9c3" /><stop offset=".35" stopColor="#facc15" /><stop offset=".7" stopColor="#ca8a04" /><stop offset="1" stopColor="#713f12" /></linearGradient>;
const Bell = () => { const u = useU(); return (
  <Svg label="Bell">
    <defs>{GOLD(`${u}bl2`)}</defs>
    <path d="M32 7c-12 0-17 10-17 21v10l-7 9h48l-7-9V28c0-11-5-21-17-21z" fill={`url(#${u}bl2)`} stroke="#713f12" strokeWidth="2.5" strokeLinejoin="round" />
    <path d="M10 47h44v4H10z" fill="#a16207" stroke="#713f12" strokeWidth="1.5" />
    <circle cx="32" cy="55" r="5.5" fill={`url(#${u}bl2)`} stroke="#713f12" strokeWidth="2" />
    <path d="M22 18c2-5 6-7 10-7" stroke="#fff" strokeWidth="3" strokeLinecap="round" opacity=".85" />
    <path d="M20 30v10" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity=".45" />
    <Glint x={42} y={16} s={0.8} />
  </Svg>
); };
const Bar = () => { const u = useU(); return (
  <Svg label="Bar">
    <defs>{GOLD(`${u}br2`)}<linearGradient id={`${u}br2b`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#374151" /><stop offset="1" stopColor="#030712" /></linearGradient></defs>
    <rect x="4" y="18" width="56" height="28" rx="6" fill={`url(#${u}br2)`} stroke="#713f12" strokeWidth="2" />
    <rect x="8" y="22" width="48" height="20" rx="4" fill={`url(#${u}br2b)`} />
    <text x="32" y="39" textAnchor="middle" fontSize="18" fontFamily="'Lilita One', system-ui" letterSpacing="2" fill={`url(#${u}br2)`}>BAR</text>
    <path d="M10 24h44" stroke="#fff" strokeOpacity=".25" strokeWidth="2" />
  </Svg>
); };
const Seven = () => { const u = useU(); return (
  <Svg label="Seven">
    <defs><linearGradient id={`${u}sv2`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fecaca" /><stop offset=".35" stopColor="#ef4444" /><stop offset="1" stopColor="#7f1d1d" /></linearGradient></defs>
    <path d="M14 10h38v9L31 58H16l19-36H14z" fill="#000" opacity=".35" transform="translate(1.5 2)" />
    <path d="M12 9h38v9L29 57H14l19-36H12z" fill={`url(#${u}sv2)`} stroke="#450a0a" strokeWidth="3" strokeLinejoin="round" />
    <path d="M15 12h31" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" opacity=".75" />
    <path d="M37 22L22 52" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" opacity=".35" />
    <Glint x={46} y={13} s={0.8} />
  </Svg>
); };
const VaultWild = () => { const u = useU(); return (
  <Svg label="Wild">
    <defs>{GOLD(`${u}vw2`)}<radialGradient id={`${u}vw2s`} cx=".4" cy=".35" r=".8"><stop offset="0" stopColor="#94a3b8" /><stop offset=".6" stopColor="#334155" /><stop offset="1" stopColor="#0f172a" /></radialGradient></defs>
    <circle cx="32" cy="29" r="25" fill={`url(#${u}vw2s)`} stroke={`url(#${u}vw2)`} strokeWidth="4" />
    {Array.from({ length: 12 }, (_, i) => <circle key={i} cx={32 + 21 * Math.cos((i / 12) * Math.PI * 2)} cy={29 + 21 * Math.sin((i / 12) * Math.PI * 2)} r="1.6" fill="#facc15" />)}
    <circle cx="32" cy="29" r="12" fill="none" stroke={`url(#${u}vw2)`} strokeWidth="3" />
    {[0, 60, 120, 180, 240, 300].map((a) => <rect key={a} x="30.5" y="12" width="3" height="11" rx="1.5" fill={`url(#${u}vw2)`} transform={`rotate(${a} 32 29)`} />)}
    <circle cx="32" cy="29" r="4" fill={`url(#${u}vw2)`} />
    <rect x="8" y="47" width="48" height="14" rx="4" fill="#0b1520" stroke="#facc15" strokeWidth="1.8" />
    <text x="32" y="58.5" textAnchor="middle" fontSize="11" fontFamily="'Lilita One', system-ui" letterSpacing="2" fill={`url(#${u}vw2)`}>WILD</text>
  </Svg>
); };
export function Coin({ v, bet }) {
  const jack = typeof v === 'string';
  const label = jack ? v : (() => { const p = Math.floor(((bet || 100) * v) / 100); return `£${p % 100 === 0 ? p / 100 : (p / 100).toFixed(2)}`; })();
  const fill = jack ? { MINI: '#38bdf8', MINOR: '#a78bfa', MAJOR: '#f43f5e', GRAND: '#facc15' }[v] : '#fbbf24';
  const u = useU(); const id = `${u}c2${jack ? v : 'n'}`;
  return (
    <Svg label={jack ? `${v} jackpot coin` : `Coin ${label}`}>
      <defs>
        <radialGradient id={id} cx=".35" cy=".3" r=".85"><stop offset="0" stopColor="#fffbeb" /><stop offset=".35" stopColor={fill} /><stop offset="1" stopColor="#713f12" /></radialGradient>
        <linearGradient id={`${id}e`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fef3c7" /><stop offset="1" stopColor="#92400e" /></linearGradient>
      </defs>
      <circle cx="33" cy="34" r="28" fill="#000" opacity=".35" />
      <circle cx="32" cy="32" r="28" fill={`url(#${id}e)`} />
      <circle cx="32" cy="32" r="24.5" fill={`url(#${id})`} stroke="#78350f" strokeWidth="1.2" />
      {Array.from({ length: 24 }, (_, i) => <rect key={i} x="31.4" y="4.5" width="1.2" height="3" fill="#78350f" opacity=".45" transform={`rotate(${i * 15} 32 32)`} />)}
      <circle cx="32" cy="32" r="19" fill="none" stroke="#fff" strokeOpacity=".45" strokeWidth="1.2" strokeDasharray="2.5 2.5" />
      <path d="M17 22a18 18 0 0 1 16-9" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" opacity=".7" fill="none" />
      <text x="32" y={jack ? 36.5 : 37.5} textAnchor="middle" fontSize={jack ? 11.5 : label.length > 5 ? 11.5 : 14.5} fontFamily="'Lilita One', system-ui" fill="#451a03" stroke="#fef3c7" strokeWidth=".8" paintOrder="stroke">{label}</text>
      <Glint x={44} y={16} s={0.7} />
    </Svg>
  );
}
export const jackpotLabel = (v) => (typeof v === 'string' ? `${v} ${JACKPOTS[v] / 100}x` : null);

// ── Fruit Shack: glossy fruit ──
const shine = (cx, cy, rx, ry, rot = -30) => <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="#fff" opacity=".55" transform={`rotate(${rot} ${cx} ${cy})`} />;
const FRUIT = {
  CHERRY: (u) => (
    <Svg label="Cherries">
      <defs><radialGradient id={`${u}fr2c`} cx=".35" cy=".3" r=".8"><stop offset="0" stopColor="#fecaca" /><stop offset=".35" stopColor="#ef4444" /><stop offset="1" stopColor="#7f1d1d" /></radialGradient></defs>
      <path d="M24 34C26 22 32 13 42 7M41 36c0-10 1-19 1-29" stroke="#166534" strokeWidth="3" fill="none" strokeLinecap="round" />
      <path d="M42 8c7-5 14-3 17 2-7 3-12 3-17-2z" fill="#22c55e" stroke="#14532d" strokeWidth="1.2" />
      <circle cx="23" cy="45" r="13" fill={`url(#${u}fr2c)`} stroke="#450a0a" strokeWidth="1.8" /><circle cx="42" cy="47" r="13" fill={`url(#${u}fr2c)`} stroke="#450a0a" strokeWidth="1.8" />
      {shine(18, 39, 4, 2.5)}{shine(37, 41, 4, 2.5)}
    </Svg>
  ),
  LEMON: (u) => (
    <Svg label="Lemon">
      <defs><radialGradient id={`${u}fr2l`} cx=".38" cy=".32" r=".85"><stop offset="0" stopColor="#fefce8" /><stop offset=".4" stopColor="#fde047" /><stop offset="1" stopColor="#a16207" /></radialGradient></defs>
      <path d="M6 34c0-11 12-19 26-19s26 8 26 19-12 19-26 19S6 45 6 34z" fill={`url(#${u}fr2l)`} stroke="#854d0e" strokeWidth="2" />
      <path d="M6 34l-3 0M58 34h3" stroke="#854d0e" strokeWidth="3.5" strokeLinecap="round" />
      {shine(22, 26, 8, 3, -12)}
      {[[40, 40], [34, 44], [46, 34], [28, 40]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r=".9" fill="#a16207" opacity=".6" />)}
    </Svg>
  ),
  ORANGE: (u) => (
    <Svg label="Orange">
      <defs><radialGradient id={`${u}fr2o`} cx=".35" cy=".32" r=".85"><stop offset="0" stopColor="#ffedd5" /><stop offset=".38" stopColor="#fb923c" /><stop offset="1" stopColor="#7c2d12" /></radialGradient></defs>
      <circle cx="32" cy="36" r="23" fill={`url(#${u}fr2o)`} stroke="#7c2d12" strokeWidth="2" />
      <path d="M32 14c1-5 5-8 11-8-1 5-5 8-11 8z" fill="#22c55e" stroke="#14532d" strokeWidth="1.2" /><path d="M32 13v-4" stroke="#14532d" strokeWidth="2" />
      {shine(24, 27, 6, 3.5)}
      {Array.from({ length: 9 }, (_, i) => <circle key={i} cx={22 + (i % 3) * 10 + (i > 2 ? 3 : 0)} cy={34 + Math.floor(i / 3) * 7} r=".9" fill="#9a3412" opacity=".5" />)}
    </Svg>
  ),
  PLUM: (u) => (
    <Svg label="Plum">
      <defs><radialGradient id={`${u}fr2p`} cx=".35" cy=".3" r=".85"><stop offset="0" stopColor="#f3e8ff" /><stop offset=".35" stopColor="#a855f7" /><stop offset="1" stopColor="#3b0764" /></radialGradient></defs>
      <path d="M32 12c15 0 23 10 23 24S45 59 32 59 9 50 9 36s8-24 23-24z" fill={`url(#${u}fr2p)`} stroke="#2e1065" strokeWidth="2" />
      <path d="M32 15c-2 14-2 28 0 42" stroke="#3b0764" strokeWidth="1.5" opacity=".55" fill="none" />
      <path d="M32 12c2-5 6-7 11-6" stroke="#166534" strokeWidth="3" fill="none" strokeLinecap="round" />
      {shine(21, 27, 4, 8, 15)}
    </Svg>
  ),
  BELL: () => <Bell />, BAR: () => <Bar />, SEVEN: () => <Seven />,
};

// ── Starlight Observatory ──
const STAR = {
  MOON: (u) => (
    <Svg label="Moon">
      <defs><radialGradient id={`${u}st2m`} cx=".35" cy=".3" r=".85"><stop offset="0" stopColor="#ffffff" /><stop offset=".5" stopColor="#cbd5e1" /><stop offset="1" stopColor="#475569" /></radialGradient></defs>
      <circle cx="32" cy="32" r="24" fill="#a5b4fc" opacity=".25" />
      <circle cx="32" cy="32" r="21" fill={`url(#${u}st2m)`} stroke="#334155" strokeWidth="1.5" />
      {[[24, 26, 4], [38, 38, 6], [40, 22, 2.5], [26, 42, 3]].map(([x, y, r], i) => <g key={i}><circle cx={x} cy={y} r={r} fill="#94a3b8" /><circle cx={x - r * 0.25} cy={y - r * 0.25} r={r * 0.75} fill="#cbd5e1" /></g>)}
      {shine(24, 18, 6, 2.5, -25)}
    </Svg>
  ),
  SATURN: (u) => (
    <Svg label="Saturn">
      <defs><radialGradient id={`${u}st2s`} cx=".35" cy=".3" r=".85"><stop offset="0" stopColor="#fef3c7" /><stop offset=".45" stopColor="#f59e0b" /><stop offset="1" stopColor="#78350f" /></radialGradient></defs>
      <path d="M5 40C7 30 57 18 59 28" stroke="#fde68a" strokeWidth="4" fill="none" opacity=".55" />
      <circle cx="32" cy="32" r="16" fill={`url(#${u}st2s)`} stroke="#78350f" strokeWidth="1.5" />
      <path d="M17 28c8 2 22 2 30 0M16 35c9 2 23 2 32 0" stroke="#fbbf24" strokeWidth="2" opacity=".6" fill="none" />
      <path d="M5 40c3 8 52-6 54-12" stroke="#fde68a" strokeWidth="4" fill="none" />
      <path d="M5 40c3 8 52-6 54-12" stroke="#fff" strokeWidth="1" fill="none" opacity=".7" />
      {shine(25, 24, 5, 2.5)}
    </Svg>
  ),
  ROCKET: (u) => (
    <Svg label="Rocket">
      <defs><linearGradient id={`${u}st2r`} x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#94a3b8" /><stop offset=".45" stopColor="#ffffff" /><stop offset="1" stopColor="#64748b" /></linearGradient>
        <linearGradient id={`${u}st2f`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fef08a" /><stop offset=".5" stopColor="#fb923c" /><stop offset="1" stopColor="#ef4444" stopOpacity="0" /></linearGradient></defs>
      <path d="M25 41h14l-7 21z" fill={`url(#${u}st2f)`} />
      <path d="M32 3c11 8 13 21 8 37H24C19 24 21 11 32 3z" fill={`url(#${u}st2r)`} stroke="#1e293b" strokeWidth="1.8" />
      <path d="M32 3c5 4 8 8 9 13H23c1-5 4-9 9-13z" fill="#ef4444" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="32" cy="24" r="5.5" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.8" /><circle cx="30.5" cy="22.5" r="1.8" fill="#e0f2fe" />
      <path d="M24 30l-9 11 9 2zM40 30l9 11-9 2z" fill="#ef4444" stroke="#7f1d1d" strokeWidth="1.5" strokeLinejoin="round" />
    </Svg>
  ),
  ASTRO: (u) => (
    <Svg label="Astronaut">
      <defs><radialGradient id={`${u}st2a`} cx=".35" cy=".3" r=".8"><stop offset="0" stopColor="#fff" /><stop offset="1" stopColor="#94a3b8" /></radialGradient>
        <linearGradient id={`${u}st2v`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#60a5fa" /><stop offset=".5" stopColor="#1e3a8a" /><stop offset="1" stopColor="#0f172a" /></linearGradient></defs>
      <rect x="15" y="44" width="34" height="17" rx="7" fill={`url(#${u}st2a)`} stroke="#334155" strokeWidth="1.8" />
      <circle cx="32" cy="27" r="20" fill={`url(#${u}st2a)`} stroke="#334155" strokeWidth="2" />
      <rect x="17" y="17" width="30" height="20" rx="10" fill={`url(#${u}st2v)`} stroke="#334155" strokeWidth="1.8" />
      <path d="M21 23c4-3 11-3 15 0" stroke="#bfdbfe" strokeWidth="2" strokeLinecap="round" opacity=".9" />
      <circle cx="44" cy="10" r="3" fill="#f43f5e" /><path d="M44 13v4" stroke="#334155" strokeWidth="1.5" />
      <rect x="27" y="49" width="10" height="6" rx="1.5" fill="#38bdf8" />
    </Svg>
  ),
  SCOPE: (u) => (
    <Svg label="Telescope: wild and scatter">
      <defs><linearGradient id={`${u}st2t`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fef3c7" /><stop offset=".5" stopColor="#fbbf24" /><stop offset="1" stopColor="#92400e" /></linearGradient></defs>
      <circle cx="46" cy="10" r="8" fill="#fde68a" opacity=".35" />
      <g transform="rotate(-28 30 20)"><rect x="12" y="14" width="34" height="13" rx="4" fill={`url(#${u}st2t)`} stroke="#451a03" strokeWidth="1.8" /><rect x="44" y="12" width="9" height="17" rx="3" fill="#92400e" stroke="#451a03" strokeWidth="1.8" /><path d="M15 17h28" stroke="#fff" strokeWidth="1.5" opacity=".6" /></g>
      <path d="M28 31L18 49M28 31l10 18M28 31v18" stroke="#cbd5e1" strokeWidth="3" strokeLinecap="round" />
      <Glint x={50} y={8} s={0.9} />
      <rect x="6" y="48" width="52" height="14" rx="4" fill="#0b1520" stroke="#fde68a" strokeWidth="1.5" />
      <text x="32" y="58.5" textAnchor="middle" fontSize="7.4" textLength="46" lengthAdjust="spacingAndGlyphs" fontFamily="'Lilita One', system-ui" fill="#fde68a">WILD ✦ SCATTER</text>
    </Svg>
  ),
};

/** Render any symbol from the four games. `game` picks the art style. */
export function Sym({ s, v, bet, game }) {
  const u = useU();
  const cut = useCut() && SLOT_CUT[game]?.[s];
  if (cut) return <img src={cut} alt={s} draggable="false" className="h-full w-full select-none object-contain" />;
  if (LETTERS[s]) return <Letter ch={s} />;
  if (game === 'nebula') return s === 'SCAT' ? <Comet /> : <Gem s={s} />;
  if (game === 'vault') { if (s === 'COIN') return <Coin v={v} bet={bet} />; if (s === 'WILD') return <VaultWild />; return { BELL: <Bell />, BAR: <Bar />, SEVEN: <Seven /> }[s] || null; }
  if (game === 'fruit') return FRUIT[s]?.(u) || null;
  if (game === 'starlight') return STAR[s]?.(u) || null;
  return null;
}
export const SYMBOLS = {
  vault: ['10', 'J', 'Q', 'K', 'A', 'BELL', 'BAR', 'SEVEN', 'WILD', 'COIN'],
  starlight: ['10', 'J', 'Q', 'K', 'A', 'MOON', 'SATURN', 'ROCKET', 'ASTRO', 'SCOPE'],
  nebula: ['RED', 'ORG', 'YEL', 'GRN', 'BLU', 'PUR'],
  fruit: ['CHERRY', 'LEMON', 'ORANGE', 'PLUM', 'BELL', 'BAR', 'SEVEN'],
};
