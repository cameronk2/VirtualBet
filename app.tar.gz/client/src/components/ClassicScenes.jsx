// Animated backdrops for the classic slots (Coin Vault, Starlight Observatory, Nebula Clusters,
// Fruit Shack). Pure SVG + CSS, decorative only (aria-hidden), and calm under reduced motion.
import { useMemo } from 'react';

const rnd = (i, k = 1) => { const x = Math.sin(i * 127.1 + k * 311.7) * 43758.5453; return x - Math.floor(x); };

/** Coin Vault: a steel vault room, the great door's dial turning, security lasers and drifting gold dust. */
export function VaultScene({ hot = false }) {
  const dust = useMemo(() => Array.from({ length: 22 }, (_, i) => ({ l: rnd(i) * 100, t: rnd(i, 2) * 100, d: 6 + rnd(i, 3) * 6, s: 2 + rnd(i, 4) * 3 })), []);
  return (
    <>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_35%,#3f2a0d_0%,#1c1408_45%,#07070a_100%)]" />
      <div className="absolute inset-0 opacity-30 [background:repeating-linear-gradient(90deg,rgba(255,255,255,.04)_0_2px,transparent_2px_46px),repeating-linear-gradient(0deg,rgba(255,255,255,.035)_0_2px,transparent_2px_46px)]" />
      <svg viewBox="0 0 200 200" className="cs-dial absolute left-1/2 top-[38%] w-[120%] max-w-[760px] -translate-x-1/2 -translate-y-1/2 opacity-[.16]" aria-hidden="true">
        <circle cx="100" cy="100" r="96" fill="none" stroke="#fcd34d" strokeWidth="3" />
        <circle cx="100" cy="100" r="78" fill="none" stroke="#fcd34d" strokeWidth="1.5" strokeDasharray="3 5" />
        {Array.from({ length: 8 }, (_, i) => <rect key={i} x="97" y="6" width="6" height="22" rx="2" fill="#fcd34d" transform={`rotate(${i * 45} 100 100)`} />)}
        <circle cx="100" cy="100" r="30" fill="none" stroke="#fcd34d" strokeWidth="4" />
        {Array.from({ length: 6 }, (_, i) => <line key={i} x1="100" y1="100" x2="100" y2="72" stroke="#fcd34d" strokeWidth="5" strokeLinecap="round" transform={`rotate(${i * 60} 100 100)`} />)}
      </svg>
      <div className={`cs-laser absolute left-[-20%] top-[22%] h-[2px] w-[140%] ${hot ? 'opacity-90' : 'opacity-50'}`} />
      <div className={`cs-laser b absolute left-[-20%] top-[68%] h-[2px] w-[140%] ${hot ? 'opacity-90' : 'opacity-40'}`} />
      {dust.map((p, i) => <span key={i} className="cs-dust absolute rounded-full" style={{ left: `${p.l}%`, top: `${p.t}%`, width: p.s, height: p.s, animationDuration: `${p.d}s`, animationDelay: `${-p.d * rnd(i, 5)}s` }} />)}
      <div className={`absolute inset-0 transition-opacity duration-700 ${hot ? 'opacity-100' : 'opacity-0'} bg-[radial-gradient(ellipse_at_center,rgba(250,204,21,.28),transparent_60%)]`} />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(0,0,0,.65))]" />
    </>
  );
}

/** Starlight Observatory: deep sky, twinkling stars, a slowly turning star field, shooting stars and the dome. */
export function StarScene({ free = false }) {
  const stars = useMemo(() => Array.from({ length: 70 }, (_, i) => ({ l: rnd(i) * 100, t: rnd(i, 2) * 70, s: rnd(i, 3) < 0.15 ? 3 : rnd(i, 3) < 0.5 ? 2 : 1, d: 2 + rnd(i, 4) * 4 })), []);
  return (
    <>
      <div className={`absolute inset-0 transition-colors duration-1000 ${free ? 'bg-[linear-gradient(180deg,#1e1b4b,#3730a3_45%,#0f172a)]' : 'bg-[linear-gradient(180deg,#020617,#172554_50%,#0f172a)]'}`} />
      <div className="cs-milky absolute left-1/2 top-[28%] h-[60%] w-[160%] -translate-x-1/2 -translate-y-1/2 rotate-[-18deg] rounded-[50%] bg-[radial-gradient(ellipse,rgba(165,180,252,.22),rgba(99,102,241,.08)_45%,transparent_70%)] blur-xl" />
      <div className="cs-spin absolute left-1/2 top-[30%] h-[200%] w-[200%] -translate-x-1/2 -translate-y-1/2">
        {stars.map((s, i) => <span key={i} className="cs-twinkle absolute rounded-full bg-white" style={{ left: `${25 + s.l / 2}%`, top: `${15 + s.t / 2}%`, width: s.s, height: s.s, animationDuration: `${s.d}s`, animationDelay: `${-s.d * rnd(i, 6)}s`, boxShadow: s.s > 2 ? '0 0 6px 1px rgba(199,210,254,.9)' : undefined }} />)}
      </div>
      {[0, 1, 2].map((i) => <span key={i} className="cs-shoot absolute h-[2px] w-24 rounded-full" style={{ top: `${8 + i * 14}%`, left: `${20 + i * 25}%`, animationDelay: `${i * 4.3 + 1}s` }} />)}
      <svg viewBox="0 0 400 80" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-[22%] w-full" aria-hidden="true">
        <path d="M0 80V58q60-14 120-6t100-10q50-10 90 2t90 4v32z" fill="#0b1026" />
        <path d="M250 60V40a28 28 0 0 1 56 0v20z" fill="#1e293b" stroke="#475569" strokeWidth="1" />
        <path d="M278 12l26-18" stroke="#64748b" strokeWidth="6" strokeLinecap="round" />
        <rect x="270" y="30" width="16" height="4" fill="#fde68a" className="p3-flicker" />
      </svg>
    </>
  );
}

/** Nebula Clusters: drifting coloured gas clouds, star dust and a soft core glow that brightens with the multiplier. */
export function NebulaScene({ level = 0, free = false }) {
  const dust = useMemo(() => Array.from({ length: 40 }, (_, i) => ({ l: rnd(i, 7) * 100, t: rnd(i, 8) * 100, s: rnd(i, 9) < 0.2 ? 2 : 1, d: 2.5 + rnd(i, 10) * 3 })), []);
  return (
    <>
      <div className="absolute inset-0 bg-[#060716]" />
      <div className="cs-cloud absolute -left-[20%] -top-[10%] h-[70%] w-[90%] rounded-full bg-[radial-gradient(circle,rgba(217,70,239,.55),transparent_65%)] blur-2xl" />
      <div className="cs-cloud b absolute -right-[25%] top-[20%] h-[70%] w-[90%] rounded-full bg-[radial-gradient(circle,rgba(34,211,238,.38),transparent_65%)] blur-2xl" />
      <div className="cs-cloud c absolute left-[10%] bottom-[-20%] h-[60%] w-[80%] rounded-full bg-[radial-gradient(circle,rgba(99,102,241,.45),transparent_65%)] blur-2xl" />
      {dust.map((s, i) => <span key={i} className="cs-twinkle absolute rounded-full bg-white" style={{ left: `${s.l}%`, top: `${s.t}%`, width: s.s, height: s.s, animationDuration: `${s.d}s`, animationDelay: `${-s.d * rnd(i, 11)}s` }} />)}
      <div className="absolute inset-0 transition-opacity duration-500" style={{ opacity: Math.min(1, level / 5 + (free ? 0.3 : 0)), background: 'radial-gradient(ellipse at 50% 45%, rgba(250,204,21,.25), transparent 60%)' }} />
    </>
  );
}

/** Fruit Shack: a beach-shack sunset, sun rays turning, palm fronds swaying and bubbles rising. */
export function FruitScene({ win = false }) {
  const bubbles = useMemo(() => Array.from({ length: 14 }, (_, i) => ({ l: rnd(i, 12) * 100, s: 6 + rnd(i, 13) * 14, d: 7 + rnd(i, 14) * 6 })), []);
  return (
    <>
      <div className="absolute inset-0 bg-[linear-gradient(180deg,#fb923c_0%,#f43f5e_38%,#7c2d12_70%,#431407)]" />
      <div className="cs-rays absolute left-1/2 top-[18%] h-[260%] w-[260%] -translate-x-1/2 -translate-y-1/2 [background:repeating-conic-gradient(from_0deg,rgba(255,237,213,.18)_0deg_8deg,transparent_8deg_22deg)] [mask-image:radial-gradient(circle,#000,transparent_40%)]" />
      <div className="absolute left-1/2 top-[14%] h-28 w-28 -translate-x-1/2 rounded-full bg-[radial-gradient(circle,#fef3c7,#fdba74_60%,transparent_72%)]" />
      <svg viewBox="0 0 120 120" className="cs-palm absolute -left-6 -top-4 w-40 opacity-80" aria-hidden="true"><g fill="#3f1d0b">{[0, 35, 70, 110, 150].map((r) => <path key={r} d="M10 10q40 6 70 34q-34-14-70-22z" transform={`rotate(${r} 10 10)`} />)}</g></svg>
      <svg viewBox="0 0 120 120" className="cs-palm r absolute -right-6 -top-4 w-40 -scale-x-100 opacity-80" aria-hidden="true"><g fill="#3f1d0b">{[0, 35, 70, 110, 150].map((r) => <path key={r} d="M10 10q40 6 70 34q-34-14-70-22z" transform={`rotate(${r} 10 10)`} />)}</g></svg>
      {bubbles.map((b, i) => <span key={i} className="p3-deco cs-bubble absolute bottom-0 rounded-full" style={{ left: `${b.l}%`, width: b.s, height: b.s, animationDuration: `${b.d}s`, animationDelay: `${-b.d * rnd(i, 15)}s` }} />)}
      <div className="absolute inset-x-0 bottom-0 h-[18%] bg-[repeating-linear-gradient(90deg,#78350f_0_18px,#92400e_18px_36px)] opacity-80" />
      <div className={`absolute inset-0 transition-opacity duration-500 ${win ? 'opacity-100' : 'opacity-0'} bg-[radial-gradient(ellipse_at_center,rgba(253,224,71,.35),transparent_60%)]`} />
    </>
  );
}
