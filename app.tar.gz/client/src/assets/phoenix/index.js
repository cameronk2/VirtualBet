// Phoenix Ember Link art: rendered locally with Stable Diffusion 1.5 (CreativeML OpenRAIL-M) on CPU,
// then cut out, recoloured and finished by tools/art/phoenix_build.py. No paid tools or services.
import S_WILD from './sym/WILD.webp';
import S_FEATHER from './sym/FEATHER.webp';
import S_ORANGE from './sym/ORANGE.webp';
import S_RED from './sym/RED.webp';
import S_PURPLE from './sym/PURPLE.webp';
import S_GREEN from './sym/GREEN.webp';
import S_A from './sym/A.webp';
import S_K from './sym/K.webp';
import S_Q from './sym/Q.webp';
import S_J from './sym/J.webp';
import S_T from './sym/T.webp';
import S_N from './sym/N.webp';
import F_yellow from './fb/yellow.webp';
import F_orange from './fb/orange.webp';
import F_magenta from './fb/magenta.webp';
import F_red from './fb/red.webp';
import F_blue from './fb/blue.webp';
import F_green from './fb/green.webp';
import F_phoenix from './fb/phoenix.webp';
import E_orange from './egg/orange.webp';
import E_magenta from './egg/magenta.webp';
import E_red from './egg/red.webp';
import E_blue from './egg/blue.webp';
import E_green from './egg/green.webp';
import BG from './bg.webp';
import BGB from './bg_bonus.webp';
import HERO from './hero.webp';
import STORM from './firestorm.webp';
import FLAMES from './flames.webp';
import FLYER from './flyer.webp';
import LOGO from './logo.webp';

export const PH = {
  sym: { WILD: S_WILD, FEATHER: S_FEATHER, ORANGE: S_ORANGE, RED: S_RED, PURPLE: S_PURPLE, GREEN: S_GREEN, A: S_A, K: S_K, Q: S_Q, J: S_J, T: S_T, N: S_N },
  fb: { yellow: F_yellow, orange: F_orange, magenta: F_magenta, red: F_red, blue: F_blue, green: F_green, phoenix: F_phoenix },
  egg: { orange: E_orange, magenta: E_magenta, red: E_red, blue: E_blue, green: E_green },
  bg: BG, bgBonus: BGB, hero: HERO, firestorm: STORM, flames: FLAMES, flyer: FLYER, logo: LOGO,
};
