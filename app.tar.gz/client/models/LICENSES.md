# 3D models

| File | Source | Author | Licence |
| --- | --- | --- | --- |
| horse.glb | Ultimate Animated Animal Pack (https://quaternius.com/packs/ultimateanimatedanimals.html) | Quaternius | CC0 1.0 (public domain, commercial use allowed, no attribution required) |

Everything else in the racing scenes (jockeys, silks, rails, stalls, stands, crowds, courses) is built in code.

| File | Source | Author | Licence |
| --- | --- | --- | --- |
| presenter.glb | Universal Base Characters, Standard (free) (https://quaternius.itch.io/universal-base-characters), `Superhero_Female_FullBody`, mesh and 65-joint skeleton only (converted copy from github.com/glanderness/BeefTV) | Quaternius | CC0 1.0 (public domain, commercial use allowed, no attribution required) |

The Fortune Live presenter's dress, shoes, hair, make-up, eyes and every movement (idle, talking, reaching for and spinning the wheel) are made in code (`client/src/pages/fortune/presenter.js`).
