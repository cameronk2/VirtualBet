# 3D models

| File | Source | Author | Licence |
| --- | --- | --- | --- |
| horse.glb | Ultimate Animated Animal Pack (https://quaternius.com/packs/ultimateanimatedanimals.html) | Quaternius | CC0 1.0 (public domain, commercial use allowed, no attribution required) |

Everything else in the racing scenes (jockeys, silks, rails, stalls, stands, crowds, courses) is built in code.
