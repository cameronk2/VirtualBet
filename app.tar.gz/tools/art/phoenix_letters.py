# Royal symbols (A K Q J 10 9) for Phoenix Ember Link: a carved serif glyph filled with a deep colour,
# a thick molten-gold rim, then the shared 3D paint pass (bevel, studio light, gloss, shadow).
import sys, numpy as np
sys.path.insert(0, '.')
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from paint import paint
FONT = '/usr/share/fonts/truetype/crosextra/Caladea-Bold.ttf'
COL = {'A': ((255, 90, 70), (120, 8, 12)), 'K': ((120, 170, 255), (14, 34, 120)), 'Q': ((220, 140, 255), (70, 16, 120)),
       'J': ((120, 240, 150), (8, 90, 40)), 'T': ((255, 190, 90), (150, 50, 6)), 'N': ((110, 235, 230), (6, 90, 100))}
def glyph(ch, size=512):
    text = '10' if ch == 'T' else '9' if ch == 'N' else ch
    f = ImageFont.truetype(FONT, 380 if len(text) == 1 else 300)
    m = Image.new('L', (size, size), 0); d = ImageDraw.Draw(m)
    bb = d.textbbox((0, 0), text, font=f); w, h = bb[2] - bb[0], bb[3] - bb[1]
    d.text(((size - w) / 2 - bb[0], (size - h) / 2 - bb[1]), text, font=f, fill=255)
    return m
def letter(ch):
    m = glyph(ch); a = np.asarray(m).astype(np.float32) / 255
    from scipy import ndimage as nd
    inside = a > .5
    rim = nd.binary_dilation(inside, iterations=16) & ~nd.binary_erosion(inside, iterations=2)
    outer = nd.binary_dilation(inside, iterations=16)
    H, W = a.shape; y = np.linspace(0, 1, H)[:, None] * np.ones((1, W))
    top, bot = [np.array(c, np.float32) / 255 for c in COL[ch]]
    fill = top[None, None] * (1 - y[..., None]) + bot[None, None] * y[..., None]
    gold_t, gold_b = np.array([1.0, .93, .62]), np.array([.62, .32, .05])
    gy = (np.sin(y * 9) * .25 + .5)[..., None]
    gold = gold_t * (1 - gy) + gold_b * gy
    rgb = np.where(rim[..., None], gold, fill)
    al = nd.gaussian_filter(outer.astype(np.float32), .8)
    im = Image.fromarray((np.dstack([rgb, al]) * 255).astype(np.uint8), 'RGBA')
    out = paint(im, 'gem' if False else 'glossy')
    return out
if __name__ == '__main__':
    import os
    dst = sys.argv[1]; os.makedirs(dst, exist_ok=True)
    for ch in COL:
        im = letter(ch).resize((256, 256), Image.LANCZOS); im.save(f'{dst}/{ch}.png'); print(ch)
