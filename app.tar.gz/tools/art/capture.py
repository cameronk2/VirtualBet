import sys, os
from playwright.sync_api import sync_playwright
games=sys.argv[1].split(',')
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1200,'height':900},device_scale_factor=1)
    pg=ctx.new_page()
    for g in games:
        pg.goto(f'http://localhost:3100/__art?game={g}'); pg.wait_for_timeout(2500)
        cells=pg.locator('[data-sym]'); n=cells.count(); os.makedirs(f'/tmp/claude-0/art/raw/{g}',exist_ok=True)
        for i in range(n):
            el=cells.nth(i); s=el.get_attribute('data-sym')
            el.screenshot(path=f'/tmp/claude-0/art/raw/{g}/{s}.png', omit_background=True)
        print(g, n)
