# Free "painted 3D" pass for slot symbols.
# Input: transparent 512px renders of the game's own vector art (captured from /__art by capture.py).
# Output: 256px WebP symbols with bevelled depth, studio lighting, gloss, reflections, rim light,
# ambient occlusion and a soft shadow. Pure numpy/scipy/PIL, no AI, no paid tools.
# Usage: python3 paint.py <in_dir> <out_dir> [style]   style: glossy (default) | metal | neon | gem | ice
import sys, os, glob
import numpy as np
from scipy import ndimage as nd
from PIL import Image

def smooth(x, a, b):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)

def normalize(v):
    return v / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-6)

STYLES = {
    #        bevel  relief  lines  spec_sharp  spec_k  broad  refl  rim   sat   shadow
    'glossy': (20,   0.30,   0.50,  80,         1.10,   0.28,  0.30, 0.30, 1.15, 0.50),
    'metal':  (18,   0.35,   0.60,  100,        1.30,   0.40,  0.70, 0.35, 1.08, 0.55),
    'gem':    (12,   0.55,   0.35,  120,        1.30,   0.30,  0.45, 0.40, 1.20, 0.45),
    'ice':    (14,   0.40,   0.35,  110,        1.20,   0.30,  0.50, 0.55, 1.00, 0.40),
    'neon':   (8,    0.15,   0.10,  60,         0.60,   0.10,  0.10, 0.10, 1.25, 0.00),
}

def env(r):
    """Studio environment seen in a reflection direction r (y down): a bright softbox overhead,
    a warm horizon band and a dark floor."""
    up = np.clip(-r[..., 1], -1, 1)
    sky = smooth(up, -0.1, 0.7) * 1.0 + 0.08
    box = np.exp(-((r[..., 0] + 0.25) ** 2) / 0.02) * smooth(up, 0.35, 0.8) * 0.9   # vertical softbox strip
    band = np.exp(-(up - 0.05) ** 2 / 0.01) * 0.35
    e = np.stack([sky + box + band * 1.0, sky + box + band * 0.85, sky * 1.05 + box + band * 0.6], -1)
    return e

def paint(im, style='glossy'):
    S = STYLES[style]
    rgba = np.asarray(im.convert('RGBA'), dtype=np.float64) / 255.0
    H, W = rgba.shape[:2]
    a = rgba[..., 3]; c = rgba[..., :3]
    # premultiplied edges: recover colour where alpha is partial
    c = np.where(a[..., None] > 0.01, c, 0)
    inside = a > 0.5
    # ── height ──
    d = nd.distance_transform_edt(inside)
    h_bevel = smooth(d, 0, S[0])
    # dome: every separate part rises to its own centre with a circular profile, so balls read as
    # spheres and strokes as rounded tubes (the bevel above keeps edges crisp)
    lab, n = nd.label(inside)
    if n:
        dmax = nd.maximum(d, lab, index=np.arange(1, n + 1))
        dm = np.zeros_like(d); dm[lab > 0] = np.asarray(dmax)[lab[lab > 0] - 1]
        t = np.clip(d / np.maximum(dm, 1), 0, 1)
        dome = np.sqrt(np.clip(1 - (1 - t) ** 2, 0, 1)) * np.clip(dm / 60, 0.25, 1.0)
    else:
        dome = np.zeros_like(d)
    h_bevel = 0.55 * h_bevel + 0.75 * dome
    L = (0.299 * c[..., 0] + 0.587 * c[..., 1] + 0.114 * c[..., 2])
    h_relief = nd.gaussian_filter(L, 2.0) * S[1]
    dark = smooth(0.28 - L, 0, 0.18) * inside          # outline strokes sit lower
    h_lines = -nd.gaussian_filter(dark, 1.2) * S[2]
    # colour-region edges get their own small bevel so separate parts read as separate pieces
    edges = np.zeros_like(L)
    for k in range(3):
        g = nd.gaussian_gradient_magnitude(c[..., k], 1.0); edges = np.maximum(edges, g)
    h_parts = -nd.gaussian_filter(np.clip(edges * 3, 0, 1), 1.5) * 0.18
    h = h_bevel * 1.0 + h_relief + h_lines + h_parts
    h = nd.gaussian_filter(h, 1.0) * a
    # ── normals ──
    k = 16.0 * (S[0] / 14)
    gy, gx = np.gradient(h)
    N = normalize(np.stack([-gx * k, -gy * k, np.ones_like(h)], -1))
    # ── lights ──
    V = np.array([0, 0, 1.0])
    L1 = normalize(np.array([-0.55, -0.65, 0.55])); C1 = np.array([1.0, 0.96, 0.88])
    L2 = normalize(np.array([0.7, 0.4, 0.5])); C2 = np.array([0.55, 0.65, 0.9])
    ndl1 = np.clip(N @ L1, 0, 1)[..., None]; ndl2 = np.clip(N @ L2, 0, 1)[..., None]
    diffuse = 0.22 + 0.95 * ndl1 * C1 + 0.25 * ndl2 * C2
    H1 = normalize(L1 + V)
    nh = np.clip(N @ H1, 0, 1)
    spec = (nh ** S[3] * S[4] + nh ** 14 * S[5])[..., None] * C1
    ndv = np.clip(N[..., 2], 0, 1)
    R = normalize(2 * ndv[..., None] * N - V)
    fres = (0.04 + 0.96 * (1 - ndv) ** 5)[..., None]
    refl = env(R) * (S[6] * (0.35 + fres))
    rim = ((1 - ndv) ** 3)[..., None] * S[7] * np.array([0.85, 0.92, 1.0])
    # ambient occlusion: creases and the inner edge of the bevel get darker
    ao = 1 - 0.45 * np.clip(nd.gaussian_filter(h, 7) - h, 0, 1)[..., None] * 3
    ao = np.clip(ao, 0.55, 1)
    # metals tint their reflections with their own colour
    tint = c if style in ('metal', 'gem') else 1.0
    out = c * diffuse * ao + spec + refl * tint + rim * (0.6 + 0.4 * c)
    # saturation / contrast
    lum = out.mean(-1, keepdims=True)
    out = lum + (out - lum) * S[8]
    out = np.clip((out - 0.5) * 1.08 + 0.5, 0, None)     # a little contrast
    out = out / (1 + np.maximum(out - 1, 0) * 0.6)         # soft shoulder so highlights don't clip harshly
    out = np.clip(out, 0, 1)
    if style == 'neon':                                    # glowing tube: bloom outside, hot core inside
        core = np.clip(L * 1.4, 0, 1)[..., None]
        out = np.clip(c * 1.1 + core * 0.35 + spec * 0.5, 0, 1)
    res = np.dstack([out, a])
    # ── shadow / glow underneath ──
    img = Image.fromarray((res * 255).astype(np.uint8), 'RGBA')
    canvas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    if style == 'neon':
        glow_rgb = nd.gaussian_filter(c * a[..., None], (14, 14, 0)) * 2.2
        glow_a = np.clip(nd.gaussian_filter(a, 14) * 1.6, 0, 1)
        glow = np.dstack([np.clip(glow_rgb / np.maximum(glow_a[..., None], 1e-3), 0, 1), glow_a * 0.9])
        canvas.alpha_composite(Image.fromarray((glow * 255).astype(np.uint8), 'RGBA'))
    elif S[9] > 0:
        sh = nd.gaussian_filter(nd.shift(a, (12, 4), order=1), 9) * S[9]
        canvas.alpha_composite(Image.fromarray(np.dstack([np.zeros((H, W, 3)), sh * 255]).astype(np.uint8), 'RGBA'))
    canvas.alpha_composite(img)
    return canvas

if __name__ == '__main__':
    src, dst = sys.argv[1], sys.argv[2]; style = sys.argv[3] if len(sys.argv) > 3 else 'glossy'
    os.makedirs(dst, exist_ok=True)
    for f in sorted(glob.glob(f'{src}/*.png')):
        name = os.path.splitext(os.path.basename(f))[0]
        st = style
        if ':' in style:                                       # per-symbol overrides, e.g. "glossy:BAR=metal,SEVEN=metal"
            base, over = style.split(':', 1); st = dict(x.split('=') for x in over.split(',')).get(name, base)
        out = paint(Image.open(f), st)
        out = out.resize((256, 256), Image.LANCZOS)
        out.save(f'{dst}/{name}.webp', 'WEBP', quality=86, method=6)
        print(name, st, os.path.getsize(f'{dst}/{name}.webp'))
