# Slot art pipeline (free, no AI)

1. `capture.py <game,...>`: opens the developer page `/__art?game=<id>` and saves each symbol's own
   vector art as a transparent 512px PNG.
2. `paint.py <in> <out> <style[:SYM=style,...]>`: repaints each symbol with bevelled depth, studio
   lighting, gloss, environment reflections, rim light, ambient occlusion and a soft shadow
   (styles: glossy, metal, gem, ice, neon). Output: 256px WebP cut-outs.
3. Copy the results to `client/src/assets/cut/<game>/` and rebuild `assets/cut/index.js`
   (the generator lives at the bottom of this README's commit; any game/symbol present is used
   automatically in place of its vector art).
4. `backgrounds.py`: paints each slot's backdrop procedurally (fbm clouds, light shafts, bokeh,
   silhouettes) into `client/src/assets/cut/bg/`.
