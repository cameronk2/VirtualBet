# Cut-out helpers for the Phoenix Ember Link art (AI renders from local Stable Diffusion 1.5).
import numpy as np, cv2
from PIL import Image, ImageFilter
from scipy import ndimage as nd

def grabcut(im, margin=0.06, iters=6, keep_shadow=False):
    """Object on a plain studio background -> RGBA. GrabCut seeded by a centred rectangle,
    then the largest component, holes filled and a soft, slightly shrunk edge."""
    a = np.asarray(im.convert('RGB')); h, w = a.shape[:2]
    mask = np.zeros((h, w), np.uint8); bgd = np.zeros((1, 65), np.float64); fgd = np.zeros((1, 65), np.float64)
    r = (int(w * margin), int(h * margin), int(w * (1 - 2 * margin)), int(h * (1 - 2 * margin)))
    cv2.grabCut(cv2.cvtColor(a, cv2.COLOR_RGB2BGR), mask, r, bgd, fgd, iters, cv2.GC_INIT_WITH_RECT)
    fg = np.isin(mask, (1, 3))
    lab, n = nd.label(fg)
    if n: fg = lab == (1 + np.argmax(nd.sum(fg, lab, range(1, n + 1))))
    fg = nd.binary_fill_holes(fg)
    fg = nd.binary_erosion(fg, iterations=1)
    alpha = nd.gaussian_filter(fg.astype(np.float32), 1.2)
    return Image.fromarray(np.dstack([a, (np.clip(alpha, 0, 1) * 255).astype(np.uint8)]), 'RGBA')

def glow_alpha(im, gamma=1.0, floor=0.06, boost=1.25):
    """Something glowing on black -> RGBA where black becomes transparent (un-premultiplied)."""
    a = np.asarray(im.convert('RGB')).astype(np.float32) / 255
    al = np.clip((a.max(-1) - floor) / (1 - floor), 0, 1) ** gamma
    al = np.clip(al * boost, 0, 1)
    rgb = np.clip(a / np.maximum(al[..., None], 1e-3), 0, 1)
    return Image.fromarray((np.dstack([rgb, al]) * 255).astype(np.uint8), 'RGBA')

def lum_mask(im, thr=0.08, soft=0.08):
    """Bright object on dark bg: mask by luminance, largest blob, holes filled."""
    a = np.asarray(im.convert('RGB')).astype(np.float32) / 255
    L = a @ [0.3, 0.59, 0.11]
    fg = L > thr
    lab, n = nd.label(fg)
    if n: fg = lab == (1 + np.argmax(nd.sum(fg, lab, range(1, n + 1))))
    fg = nd.binary_fill_holes(fg)
    al = np.clip(nd.gaussian_filter(fg.astype(np.float32), 1.5), 0, 1) * np.clip((L - thr * .5) / soft, 0, 1)
    return Image.fromarray(np.dstack([(a * 255).astype(np.uint8), (al * 255).astype(np.uint8)]), 'RGBA')

def gradient_map(im, stops):
    """Recolour by luminance through colour stops [(pos, (r,g,b)), ...]; alpha kept."""
    rgba = np.asarray(im.convert('RGBA')).astype(np.float32) / 255
    L = rgba[..., :3] @ [0.3, 0.59, 0.11]
    xs = [p for p, _ in stops]; out = np.zeros(L.shape + (3,), np.float32)
    for c in range(3): out[..., c] = np.interp(L, xs, [col[c] / 255 for _, col in stops])
    return Image.fromarray((np.dstack([out, rgba[..., 3]]) * 255).astype(np.uint8), 'RGBA')

def hue_tint(im, rgb, amount=0.85):
    """Keep shading, swap colour: blend the hue/saturation toward a target colour (eggs)."""
    rgba = np.asarray(im.convert('RGBA')).astype(np.float32) / 255
    L = rgba[..., :3] @ [0.3, 0.59, 0.11]
    t = np.array(rgb, np.float32) / 255; tl = t @ [0.3, 0.59, 0.11]
    col = np.clip(t[None, None, :] * (L[..., None] / max(tl, 1e-3)), 0, None)
    col = col / (1 + np.maximum(col - 1, 0))      # soft shoulder, highlights go white-ish
    hi = np.clip((L - 0.75) / 0.25, 0, 1)[..., None]
    col = col * (1 - hi) + hi * np.clip(col * 0.5 + 0.6, 0, 1)
    out = rgba[..., :3] * (1 - amount) + col * amount
    return Image.fromarray((np.dstack([np.clip(out, 0, 1), rgba[..., 3]]) * 255).astype(np.uint8), 'RGBA')

def trim_square(im, pad=0.04, size=None):
    bb = im.getchannel('A').point(lambda v: 255 if v > 12 else 0).getbbox()
    if bb: im = im.crop(bb)
    s = int(max(im.size) * (1 + 2 * pad)); c = Image.new('RGBA', (s, s), (0, 0, 0, 0))
    c.paste(im, ((s - im.width) // 2, (s - im.height) // 2), im)
    return c.resize((size, size), Image.LANCZOS) if size else c

def gem_cut(im, sat_t=0.22, val_t=0.3):
    """GrabCut, then drop the grey floor shadow and the dim reflection under a gem."""
    g = grabcut(im)
    rgba = np.asarray(g).astype(np.float32) / 255
    hsv = cv2.cvtColor((rgba[..., :3] * 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32) / 255
    body = ((hsv[..., 1] > sat_t) & (hsv[..., 2] > val_t)) | (rgba[..., :3].mean(-1) > 0.82)
    body = nd.binary_closing(body, iterations=4)
    lab, n = nd.label(body)
    if n: body = lab == (1 + np.argmax(nd.sum(body, lab, range(1, n + 1))))
    body = nd.binary_fill_holes(body)
    body = nd.binary_dilation(body, iterations=1)
    al = np.minimum(rgba[..., 3], nd.gaussian_filter(body.astype(np.float32), 1.0))
    return Image.fromarray((np.dstack([rgba[..., :3], al]) * 255).astype(np.uint8), 'RGBA')

def orb_cut(im, thr=0.55, halo=1.22):
    """A glowing sphere: find the bright disc, keep it solid, let a luminous halo fade out around it."""
    a = np.asarray(im.convert('RGB')).astype(np.float32) / 255
    L = a @ [0.3, 0.59, 0.11]
    hsv = cv2.cvtColor((a * 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    warm = (hsv[..., 0] < 35) | (hsv[..., 0] > 165)
    fg = (L > thr) & warm
    fg = nd.binary_opening(fg, iterations=3)
    lab, n = nd.label(fg)
    fg = lab == (1 + np.argmax(nd.sum(fg, lab, range(1, n + 1))))
    ys, xs = np.nonzero(fg); cy, cx = ys.mean(), xs.mean()
    r = np.sqrt(fg.sum() / np.pi) * 1.04
    yy, xx = np.mgrid[:a.shape[0], :a.shape[1]]; d = np.hypot(yy - cy, xx - cx) / r
    core = np.clip((1.0 - d) / 0.04 + 1, 0, 1)
    glowa = np.clip((halo - d) / (halo - 1), 0, 1) ** 2 * np.clip(L * 1.6, 0, 1) * warm
    al = np.maximum(core, glowa)
    out = Image.fromarray((np.dstack([a, al]) * 255).astype(np.uint8), 'RGBA')
    s = int(r * halo * 2.1); box = (int(cx - s / 2), int(cy - s / 2), int(cx + s / 2), int(cy + s / 2))
    return out.crop(box)

def egg_shape(w=384, h=480):
    """Egg silhouette mask (wider at the bottom)."""
    yy, xx = np.mgrid[:h, :w].astype(np.float32)
    y = (yy - h * 0.56) / (h * 0.44); x = (xx - w / 2) / (w * 0.46)
    k = 1 + 0.18 * y                      # narrower at the top
    d = (x / np.clip(k, .5, 2)) ** 2 + y ** 2
    return np.clip((1 - d) / 0.02, 0, 1)

def make_egg(filigree, fire, colour):
    """A jewelled egg: gold filigree shell over a glowing core of the upgrade's colour."""
    W, H = 384, 480
    m = egg_shape(W, H)
    f = np.asarray(filigree.convert('RGB').resize((W, int(W * filigree.height / filigree.width))).crop((0, 0, W, H)).resize((W, H))).astype(np.float32) / 255
    L = f @ [0.3, 0.59, 0.11]
    metal = np.clip((L - 0.18) / 0.25, 0, 1)[..., None]           # filigree where bright
    c = np.array(colour, np.float32) / 255
    core = np.asarray(fire.convert('RGB').resize((W, H))).astype(np.float32) / 255
    cl = core @ [0.3, 0.59, 0.11]
    yy, xx = np.mgrid[:H, :W]; r = np.hypot((xx - W / 2) / W, (yy - H * .58) / H)
    glow = np.clip(1.25 - r * 2.6, 0, 1)[..., None]
    inner = np.clip(c * (0.35 + 1.2 * cl[..., None]) * (0.5 + glow), 0, 1)
    inner = inner + glow ** 3 * 0.5
    gold = f * np.array([1.08, 1.0, 0.85])
    rgb = np.clip(gold * metal + inner * (1 - metal), 0, 1)
    # dome shading: darker toward the rim, a highlight upper-left
    d = np.hypot((xx - W * .42) / W, (yy - H * .33) / H)
    rgb = rgb * (0.55 + 0.6 * np.clip(1 - r * 1.6, 0, 1))[..., None] + np.clip(0.35 - d * 2.2, 0, 1)[..., None] * 0.9
    rim = np.clip(m - nd.binary_erosion(m > .5, iterations=8), 0, 1)[..., None]
    rgb = rgb * (1 - rim) + rim * np.array([1, .82, .45]) * (0.6 + 0.4 * (1 - yy / H))[..., None]
    return Image.fromarray((np.dstack([np.clip(rgb, 0, 1), m]) * 255).astype(np.uint8), 'RGBA')

def lum_key(im, lo=0.35, hi=0.6, grow=6):
    """A bright subject on a darker coloured background: soft luminance key, largest blob."""
    a = np.asarray(im.convert('RGB')).astype(np.float32) / 255; L = a @ [0.3, 0.59, 0.11]
    al = np.clip((L - lo) / (hi - lo), 0, 1)
    fg = al > .5; lab, n = nd.label(fg); fg = lab == (1 + np.argmax(nd.sum(fg, lab, range(1, n + 1))))
    al = al * nd.binary_dilation(fg, iterations=grow)
    return Image.fromarray((np.dstack([a, al]) * 255).astype(np.uint8), 'RGBA')

def radial_fade(im, inner=.55, outer=.98):
    a = np.asarray(im.convert('RGBA')).astype(np.float32) / 255; h, w = a.shape[:2]
    yy, xx = np.mgrid[:h, :w]; d = np.hypot((xx - w / 2) / (w / 2), (yy - h / 2) / (h / 2))
    a[..., 3] *= np.clip((outer - d) / (outer - inner), 0, 1)
    return Image.fromarray((a * 255).astype(np.uint8), 'RGBA')
