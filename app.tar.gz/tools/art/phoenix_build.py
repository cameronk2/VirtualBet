# Builds every Phoenix Ember Link image from the local Stable Diffusion renders in SRC:
# cut-outs, recoloured eggs and Fireballs, symbol finishing, backgrounds, the logo, then
# writes WebP files and client/src/assets/phoenix/index.js.
import sys, os, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
from scipy import ndimage as nd
from phoenix_cut import lum_key, radial_fade, make_egg, orb_cut, grabcut, gem_cut, glow_alpha, lum_mask, gradient_map, hue_tint, trim_square
from phoenix_letters import letter
from paint import paint
SRC = '/home/claude/sd/out'
DST = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../client/src/assets/phoenix')
PICK = json.load(open(sys.argv[1])) if len(sys.argv) > 1 else {}
os.makedirs(f'{DST}/sym', exist_ok=True); os.makedirs(f'{DST}/fb', exist_ok=True); os.makedirs(f'{DST}/egg', exist_ok=True)
src = lambda k: Image.open(f"{SRC}/{PICK[k]}.png").convert('RGB')
def save(im, path, q=84, size=None):
    if size: im = im.resize(size if isinstance(size, tuple) else (size, size), Image.LANCZOS)
    im.save(f'{DST}/{path}.webp', 'WEBP', quality=q, method=6); print(path, os.path.getsize(f'{DST}/{path}.webp'))

def aura(obj, rgb, strength=.55, blur=18):
    """A soft coloured glow behind a cut-out, so it sits in the fiery scene."""
    a = np.asarray(obj.getchannel('A')).astype(np.float32) / 255
    g = nd.gaussian_filter(nd.binary_dilation(a > .3, iterations=6).astype(np.float32), blur) * strength
    glow = Image.fromarray(np.dstack([np.full(a.shape + (3,), rgb, np.uint8), (np.clip(g, 0, 1) * 255).astype(np.uint8)]), 'RGBA')
    c = Image.new('RGBA', obj.size, (0, 0, 0, 0)); c.alpha_composite(glow); c.alpha_composite(obj); return c
def shadow(obj, off=(0, 8), blur=8, k=.55):
    a = np.asarray(obj.getchannel('A')).astype(np.float32) / 255
    s = nd.gaussian_filter(nd.shift(a, off, order=1), blur) * k
    sh = Image.fromarray(np.dstack([np.zeros(a.shape + (3,), np.uint8), (s * 255).astype(np.uint8)]), 'RGBA')
    c = Image.new('RGBA', obj.size, (0, 0, 0, 0)); c.alpha_composite(sh); c.alpha_composite(obj); return c
def fit(obj, size=256, fill=.9):
    o = trim_square(obj, pad=(1 - fill) / 2); return o.resize((size, size), Image.LANCZOS)
def grade(im, sat=1.1, con=1.06, bri=1.0):
    rgb, a = im.convert('RGB'), im.getchannel('A')
    rgb = ImageEnhance.Contrast(ImageEnhance.Color(rgb).enhance(sat)).enhance(con); rgb = ImageEnhance.Brightness(rgb).enhance(bri)
    out = rgb.convert('RGBA'); out.putalpha(a); return out

# ── high symbols ─────────────────────────────────────────────────
GEM = {'ORANGE': (255, 150, 40), 'RED': (255, 50, 60), 'PURPLE': (190, 90, 255), 'GREEN': (60, 230, 110)}
for s, col in GEM.items():
    o = grade(gem_cut(src(s)), 1.12, 1.08); o = fit(o, 512, .84); o = shadow(aura(o, col, .5, 22), (0, 10), 10, .5)
    save(o, f'sym/{s}', size=256)
# Feather: glowing on dark – luminance cut
f = src('FEATHER'); o = lum_key(f, .35, .6)
save(shadow(aura(fit(grade(o, 1.15, 1.08), 512, .9), (255, 140, 40), .45, 20), (0, 8), 10, .4), 'sym/FEATHER', size=256)

# Wild: the phoenix emblem in a round gold medallion with a WILD plate
w = src('WILD').resize((512, 512), Image.LANCZOS)
disc = Image.new('L', (512, 512), 0); ImageDraw.Draw(disc).ellipse((26, 26, 486, 486), fill=255); disc = disc.filter(ImageFilter.GaussianBlur(1.5))
emb = w.convert('RGBA'); emb.putalpha(disc)
ring = Image.new('RGBA', (512, 512), (0, 0, 0, 0)); d = ImageDraw.Draw(ring)
for i, c in enumerate([(120, 60, 8), (255, 220, 130), (200, 130, 30), (255, 240, 180), (140, 70, 10)]): d.ellipse((14 + i * 3, 14 + i * 3, 498 - i * 3, 498 - i * 3), outline=c + (255,), width=4)
ring = paint(ring, 'metal')
wild = Image.new('RGBA', (512, 512), (0, 0, 0, 0)); wild.alpha_composite(emb); wild.alpha_composite(ring)
# WILD plate
plate = Image.new('RGBA', (512, 512), (0, 0, 0, 0)); pd = ImageDraw.Draw(plate)
pd.rounded_rectangle((96, 368, 416, 470), 30, fill=(150, 20, 10, 255), outline=(255, 214, 120, 255), width=10)
font = ImageFont.truetype('/usr/share/fonts/truetype/crosextra/Caladea-Bold.ttf', 92)
bb = pd.textbbox((0, 0), 'WILD', font=font); pd.text((256 - (bb[2] - bb[0]) / 2 - bb[0], 419 - (bb[3] - bb[1]) / 2 - bb[1]), 'WILD', font=font, fill=(255, 236, 170, 255))
plate = paint(plate, 'glossy'); wild.alpha_composite(plate)
save(shadow(aura(wild, (255, 120, 30), .6, 24), (0, 8), 10, .45), 'sym/WILD', size=256)

# ── royals ───────────────────────────────────────────────────────
for ch in 'AKQJTN':
    o = fit(letter(ch), 512, .82); save(o, f'sym/{ch}', size=256)

# ── Fireballs: one fire orb, gradient-mapped into each colour ─────
orb = orb_cut(src('FIREBALL'))
orb = fit(orb, 512, .98)
RAMPS = {
    'yellow': [(0, (40, 5, 0)), (.3, (200, 60, 0)), (.6, (255, 170, 20)), (.85, (255, 235, 120)), (1, (255, 255, 235))],
    'orange': [(0, (40, 5, 0)), (.3, (190, 40, 0)), (.6, (255, 110, 10)), (.85, (255, 190, 90)), (1, (255, 245, 220))],
    'magenta': [(0, (30, 0, 25)), (.3, (140, 0, 110)), (.6, (240, 50, 210)), (.85, (255, 160, 245)), (1, (255, 240, 255))],
    'red': [(0, (30, 0, 0)), (.3, (150, 0, 10)), (.6, (240, 30, 40)), (.85, (255, 130, 120)), (1, (255, 235, 230))],
    'blue': [(0, (0, 5, 35)), (.3, (0, 40, 160)), (.6, (40, 130, 255)), (.85, (150, 210, 255)), (1, (240, 250, 255))],
    'green': [(0, (0, 25, 5)), (.3, (0, 110, 30)), (.6, (40, 220, 80)), (.85, (170, 255, 170)), (1, (245, 255, 240))],
    'phoenix': [(0, (40, 0, 0)), (.25, (170, 10, 10)), (.5, (255, 90, 0)), (.75, (255, 210, 60)), (1, (255, 255, 245))],
}
for c, ramp in RAMPS.items():
    o = gradient_map(orb, ramp)
    if c == 'phoenix':   # the Phoenix Fireball carries the phoenix emblem inside its flames
        em = radial_fade(src('WILD').resize((300, 300), Image.LANCZOS).convert('RGBA'), .35, .8)
        layer = Image.new('RGBA', o.size, (0, 0, 0, 0)); layer.alpha_composite(em, ((o.width - 300) // 2, (o.height - 300) // 2))
        e = np.asarray(layer).astype(np.float32) / 255; b = np.asarray(o).astype(np.float32) / 255
        rgb = 1 - (1 - b[..., :3]) * (1 - e[..., :3] * e[..., 3:] * 1.1)          # screen blend
        o = Image.fromarray((np.dstack([np.clip(rgb, 0, 1), b[..., 3]]) * 255).astype(np.uint8), 'RGBA')
    save(o, f'fb/{c}', q=82, size=192)

# ── Eggs: one ornate egg, tinted for each upgrade ─────────────────
ECOL = {'orange': (255, 140, 30), 'magenta': (240, 70, 220), 'red': (245, 40, 50), 'blue': (60, 140, 255), 'green': (50, 220, 100)}
for u, col in ECOL.items():
    o = make_egg(src('EGG'), src('FIREBALL'), col)
    o = shadow(aura(o, col, .45, 14), (0, 6), 6, .45)
    save(o.resize((154, 192), Image.LANCZOS), f'egg/{u}', q=84)

# ── Backgrounds and key art ───────────────────────────────────────
def cover(im, w, h):
    s = max(w / im.width, h / im.height); im = im.resize((int(im.width * s + .5), int(im.height * s + .5)), Image.LANCZOS)
    x, y = (im.width - w) // 2, (im.height - h) // 2; return im.crop((x, y, x + w, y + h))
bg = src('BG'); save(cover(bg, 768, 1024).filter(ImageFilter.GaussianBlur(.6)), 'bg', q=72)
save(cover(src('BG_BONUS'), 768, 1024).filter(ImageFilter.GaussianBlur(.6)), 'bg_bonus', q=72)
save(src('HERO').resize((768, 768), Image.LANCZOS), 'hero', q=74)
save(src('FIRESTORM').resize((768, 768), Image.LANCZOS), 'firestorm', q=74)
save(radial_fade(glow_alpha(src('HERO'), 1.3, .1, 1.15), .45, .95).resize((512, 512), Image.LANCZOS), 'flyer', q=80)
save(glow_alpha(src('FLAMES'), 1.0, .05, 1.2).resize((512, 512), Image.LANCZOS), 'flames', q=78)

# ── Logo: molten gold lettering, fire glow, the phoenix behind ────
def logo():
    W, H = 1200, 420
    canvas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    big = ImageFont.truetype('/usr/share/fonts/truetype/crosextra/Caladea-Bold.ttf', 210)
    small = ImageFont.truetype('/usr/share/fonts/truetype/crosextra/Caladea-Bold.ttf', 92)
    m = Image.new('L', (W, H), 0); d = ImageDraw.Draw(m)
    def ctext(t, f, y):
        bb = d.textbbox((0, 0), t, font=f); d.text(((W - (bb[2] - bb[0])) / 2 - bb[0], y - bb[1]), t, font=f, fill=255)
    ctext('PHOENIX', big, 40); ctext('EMBER  LINK', small, 280)
    a = np.asarray(m).astype(np.float32) / 255
    inside = a > .5
    rim = nd.binary_dilation(inside, iterations=9) & ~inside
    H_, W_ = a.shape; y = np.linspace(0, 1, H_)[:, None] * np.ones((1, W_))
    band = (np.sin(y * 14) * .5 + .5)[..., None]
    gold = np.array([1, .95, .7]) * (1 - band) + np.array([.85, .45, .08]) * band
    fire = np.array([1, .85, .35]) * (1 - y[..., None]) + np.array([.85, .12, .02]) * y[..., None]
    rgb = np.where(inside[..., None], fire, gold)
    al = nd.gaussian_filter((inside | rim).astype(np.float32), .8)
    txt = paint(Image.fromarray((np.dstack([rgb, al]) * 255).astype(np.uint8), 'RGBA'), 'metal')
    # dark outline + fire glow
    outl = nd.binary_dilation(inside | rim, iterations=5)
    o = Image.fromarray(np.dstack([np.zeros(a.shape + (3,), np.uint8) + [40, 6, 0], (nd.gaussian_filter(outl.astype(np.float32), 1) * 255).astype(np.uint8)]).astype(np.uint8), 'RGBA')
    glow = nd.gaussian_filter(outl.astype(np.float32), 18) * 1.1
    g = Image.fromarray(np.dstack([np.zeros(a.shape + (3,), np.uint8) + [255, 110, 20], (np.clip(glow, 0, 1) * 255).astype(np.uint8)]).astype(np.uint8), 'RGBA')
    hero = radial_fade(src('LOGO_ART').resize((520, 520), Image.LANCZOS).convert('RGBA'), .35, .75)
    canvas.alpha_composite(hero, ((W - 520) // 2, -60))
    canvas.alpha_composite(g); canvas.alpha_composite(o); canvas.alpha_composite(txt)
    return canvas
lg = logo(); save(lg, 'logo', q=88, size=(840, 294))

open(f'{DST}/index.js', 'w').write('''// Phoenix Ember Link art: rendered locally with Stable Diffusion 1.5 (CreativeML OpenRAIL-M) on CPU,
// then cut out, recoloured and finished by tools/art/phoenix_build.py. No paid tools or services.
''' + '\n'.join(f"import {k} from './{p}.webp';" for k, p in [
    *[(f'S_{s}', f'sym/{s}') for s in ['WILD', 'FEATHER', 'ORANGE', 'RED', 'PURPLE', 'GREEN', 'A', 'K', 'Q', 'J', 'T', 'N']],
    *[(f'F_{c}', f'fb/{c}') for c in RAMPS], *[(f'E_{u}', f'egg/{u}') for u in ECOL],
    ('BG', 'bg'), ('BGB', 'bg_bonus'), ('HERO', 'hero'), ('STORM', 'firestorm'), ('FLAMES', 'flames'), ('FLYER', 'flyer'), ('LOGO', 'logo')]) + '''

export const PH = {
  sym: { WILD: S_WILD, FEATHER: S_FEATHER, ORANGE: S_ORANGE, RED: S_RED, PURPLE: S_PURPLE, GREEN: S_GREEN, A: S_A, K: S_K, Q: S_Q, J: S_J, T: S_T, N: S_N },
  fb: { yellow: F_yellow, orange: F_orange, magenta: F_magenta, red: F_red, blue: F_blue, green: F_green, phoenix: F_phoenix },
  egg: { orange: E_orange, magenta: E_magenta, red: E_red, blue: E_blue, green: E_green },
  bg: BG, bgBonus: BGB, hero: HERO, firestorm: STORM, flames: FLAMES, flyer: FLYER, logo: LOGO,
};
''')
print('index written')
