# Offline renderer: drives libfluidsynth through ctypes.
import ctypes as C, numpy as np
L=C.CDLL('libfluidsynth.so.3')
L.new_fluid_settings.restype=C.c_void_p; L.new_fluid_synth.restype=C.c_void_p; L.new_fluid_synth.argtypes=[C.c_void_p]
L.fluid_settings_setnum.argtypes=[C.c_void_p,C.c_char_p,C.c_double]; L.fluid_settings_setint.argtypes=[C.c_void_p,C.c_char_p,C.c_int]
L.fluid_synth_sfload.argtypes=[C.c_void_p,C.c_char_p,C.c_int]
for f in ['fluid_synth_noteon','fluid_synth_cc','fluid_synth_program_select']: pass
L.fluid_synth_noteon.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_int]; L.fluid_synth_noteoff.argtypes=[C.c_void_p,C.c_int,C.c_int]
L.fluid_synth_cc.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_int]; L.fluid_synth_program_change.argtypes=[C.c_void_p,C.c_int,C.c_int]
L.fluid_synth_pitch_bend.argtypes=[C.c_void_p,C.c_int,C.c_int]
L.fluid_synth_write_float.argtypes=[C.c_void_p,C.c_int,C.c_void_p,C.c_int,C.c_int,C.c_void_p,C.c_int,C.c_int]
L.fluid_synth_bank_select.argtypes=[C.c_void_p,C.c_int,C.c_int]
SR=44100
SF='/tmp/claude-0/ms/share/sound/FluidR3Mono_GM.sf3'
class Synth:
    def __init__(s, room=0.7, level=0.55):
        st=L.new_fluid_settings(); L.fluid_settings_setnum(st,b'synth.sample-rate',float(SR)); L.fluid_settings_setnum(st,b'synth.gain',0.5)
        L.fluid_settings_setint(st,b'synth.reverb.active',1); L.fluid_settings_setint(st,b'synth.chorus.active',1)
        L.fluid_settings_setnum(st,b'synth.reverb.room-size',room); L.fluid_settings_setnum(st,b'synth.reverb.level',level); L.fluid_settings_setnum(st,b'synth.reverb.width',1.0); L.fluid_settings_setnum(st,b'synth.reverb.damp',0.3)
        L.fluid_settings_setint(st,b'synth.polyphony',256)
        s.s=L.new_fluid_synth(st); r=L.fluid_synth_sfload(s.s,SF.encode(),1); assert r>=0,'sfload'
        s.ev=[]
    def prog(s,ch,p,pan=64,rev=60,vol=100,cho=0):
        s.ev.append((0,0,lambda:(L.fluid_synth_program_change(s.s,ch,p),L.fluid_synth_cc(s.s,ch,10,pan),L.fluid_synth_cc(s.s,ch,91,rev),L.fluid_synth_cc(s.s,ch,7,vol),L.fluid_synth_cc(s.s,ch,93,cho))))
    def note(s,t,ch,n,dur,vel):
        vel=int(max(1,min(127,vel))); n=int(n)
        s.ev.append((t,2,lambda:L.fluid_synth_noteon(s.s,ch,n,vel))); s.ev.append((t+dur,1,lambda:L.fluid_synth_noteoff(s.s,ch,n)))
    def cc(s,t,ch,c,v): s.ev.append((t,0,lambda:L.fluid_synth_cc(s.s,ch,c,int(v))))
    def bend(s,t,ch,v): s.ev.append((t,0,lambda:L.fluid_synth_pitch_bend(s.s,ch,int(v))))
    def render(s,total):
        s.ev.sort(key=lambda e:(e[0],e[1])); out=[]; pos=0
        def run(n):
            l=np.zeros(n,np.float32); r=np.zeros(n,np.float32)
            L.fluid_synth_write_float(s.s,n,l.ctypes.data,0,1,r.ctypes.data,0,1); out.append(np.stack([l,r],1))
        for t,_,f in s.ev:
            smp=int(round(t*SR))
            if smp>pos: run(smp-pos); pos=smp
            f()
        if int(total*SR)>pos: run(int(total*SR)-pos)
        return np.concatenate(out)
NN={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def m(name):
    if isinstance(name,int): return name
    acc=0; b=name[0]; rest=name[1:]
    while rest and rest[0] in '#b': acc+=1 if rest[0]=='#' else -1; rest=rest[1:]
    return 12*(int(rest)+1)+NN[b]+acc
