# Gong Fortune audio (all free, all original)

Output: `client/audio/tigerdragon/{music,voice,sfx}/`.

- `compose.py` + `fs.py`: music loops (base, bonus, dragon) and stings, rendered through FluidSynth
  (libfluidsynth via ctypes) with the FluidR3 Mono GM soundfont (MIT licence, from MuseScore's repository).
- `gongs.py`: ceremonial and opera gongs by modal synthesis (inharmonic partials, beating, tam-tam bloom,
  pitch glide, mallet strike, synthetic hall).
- `cues.py`: feature cues (Hold & Spin, Dragon, Luck Has Arrived, near-completion, completion, reveals,
  spin-used, last spin) and roars, mixing soundfont orchestra parts with the synthesised gongs.
- `tts.py`: announcer lines with Kokoro-82M (Apache 2.0) through onnxruntime from hand-written phonemes;
  ffmpeg then lowers the pitch slightly, adds presence, compression and an arena echo.
Paths inside the scripts point at the build machine's temp folders.

## Clyde Blackjack (`clyde.py`)

Output: `client/audio/clyde/{music/base.mp3, sfx.mp3, voice.mp3}` and `client/src/pages/clyde/sprites.js`.
Dealer voice: Piper `en_GB-alba-medium` (CC-BY 4.0; dataset: VCTK corpus, CSTR, University of Edinburgh,
https://datashare.ed.ac.uk/handle/10283/3270; model: https://huggingface.co/rhasspy/piper-voices) run with onnxruntime.
Attribution: "Dealer voice: Piper en_GB-alba-medium, CC-BY 4.0, trained on the VCTK corpus."
Player calls ("Hit", "Stand"): Piper `en_GB-vctk-medium` (CC-BY 4.0; VCTK corpus, CSTR, University of Edinburgh,
https://datashare.ed.ac.uk/handle/10283/3443), speaker p241, from the sherpa-onnx release `vits-piper-en_GB-vctk-medium`.
