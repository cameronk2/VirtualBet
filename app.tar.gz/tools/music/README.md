# Gong Fortune audio (all free)

- Music: `compose.py` (with `fs.py`) renders the base and bonus loops and the win/jackpot stings
  through FluidSynth (libfluidsynth) using the FluidR3 Mono GM soundfont (MIT licence, from
  MuseScore's repository). Instruments: koto, shamisen, flute, fiddle, strings, pizzicato, taiko.
- Voice: `tts.py` renders the callouts with Kokoro-82M (Apache 2.0) through onnxruntime,
  from hand-written phonemes; ffmpeg adds compression, presence EQ and an arena echo.
- Output goes in `client/audio/tigerdragon/`. Paths in the scripts point at the build machine's temp folders.
