# Themed soundtracks for every slot: a base loop, a bonus loop and two win stings each.
# Rendered offline through FluidSynth (fs.py) with the FluidR3 Mono GM soundfont (MIT).
# Usage: python3 slots.py [game ...]   -> writes WAVs to OUT, mastered to mp3 by master.sh
import sys, random, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, '/tmp/claude-0/mu')
import numpy as np, scipy.io.wavfile as wf
from fs import Synth, SR

OUT = os.environ.get('OUT', '/tmp/claude-0/slotmusic')
os.makedirs(OUT, exist_ok=True)
MODES = {
    'major': [0, 2, 4, 5, 7, 9, 11], 'minor': [0, 2, 3, 5, 7, 8, 10], 'dorian': [0, 2, 3, 5, 7, 9, 10],
    'lydian': [0, 2, 4, 6, 7, 9, 11], 'hijaz': [0, 1, 4, 5, 7, 8, 10], 'harm': [0, 2, 3, 5, 7, 8, 11],
    'penta': [0, 2, 4, 7, 9], 'mpenta': [0, 3, 5, 7, 10], 'whole': [0, 2, 4, 6, 8, 10], 'mixo': [0, 2, 4, 5, 7, 9, 10],
}
NOTE = {'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'Eb': 3, 'E': 4, 'F': 5, 'F#': 6, 'G': 7, 'Ab': 8, 'A': 9, 'Bb': 10, 'B': 11}

# Drum map (GM channel 10)
KICK, SNARE, RIM, CLAP, HAT, OHAT, RIDE, CRASH, CHINA, TAMB, SHAKER, CABASA, CONGA_H, CONGA_L, BONGO_H, BONGO_L, TRI, CLAVES, WOOD_H, LTOM, HTOM, TIMB_H = \
    36, 38, 37, 39, 42, 46, 51, 49, 52, 54, 70, 69, 62, 64, 60, 61, 81, 75, 76, 45, 50, 65

STYLES = {
  # id: dict(key, mode, bpm, meter, prog (scale degrees, 8 bars; repeated with variation), instruments...)
  'stampede': dict(key='A', oct=3, mode='mpenta', chordmode='minor', bpm=100, prog=[0, 0, 5, 6, 0, 3, 4, 4],
      lead=(22, 'harmonica', 96), lead2=(110, 'fiddle', 92), comp=(25, 'strum'), arp=(105, 'roll'), bass=(32, 'root5'), pad=(48, 50),
      drums=dict(kick='x...x...x...x...', snare='....x.......x...', hat='x.x.x.x.x.x.x.x.', ltom='x.xx' * 4),
      bonus=dict(bpm=128, drums=dict(kick='x.x.x.x.x.x.x.x.', snare='....x..x....x.x.', tamb='xxxxxxxxxxxxxxxx', ltom='xxxx' * 4), brass=61)),
  'brick': dict(key='C', oct=3, mode='major', chordmode='major', bpm=108, prog=[0, 3, 4, 0, 5, 3, 1, 4],
      lead=(56, 'trumpet', 92), lead2=(13, 'xylo', 96), comp=(7, 'stab'), arp=None, bass=(36, 'funk'), pad=None,
      drums=dict(kick='x.....x...x.....', snare='....x.......x...', hat='x.x.x.x.x.x.x.x.', clap='....x.......x...'),
      bonus=dict(bpm=132, drums=dict(kick='x...x.x...x.x...', snare='....x..x....x...', hat='xxxxxxxxxxxxxxxx', clap='....x.......x..x'), brass=61)),
  'mummy': dict(key='D', oct=3, mode='hijaz', chordmode='hijaz', bpm=92, prog=[0, 0, 1, 0, 6, 5, 1, 0],
      lead=(68, 'oboe', 92), lead2=(104, 'sitar', 90), comp=None, arp=(46, 'harp'), bass=(45, 'root5'), pad=(49, 48),
      drums=dict(bongo_l='x..x..x.x..x..x.', bongo_h='..x...x...x..xx.', tamb='....x.......x...', tri='x.......x.......'),
      bonus=dict(bpm=118, drums=dict(conga_l='x..x..x.x..x..x.', conga_h='.xx.xx.x.xx.xx.x', tamb='x.x.x.x.x.x.x.x.', kick='x.......x.......'), brass=None)),
  'pharaoh': dict(key='E', oct=3, mode='hijaz', chordmode='hijaz', bpm=80, prog=[0, 1, 0, 6, 5, 4, 1, 0],
      lead=(60, 'horn', 96), lead2=(56, 'trumpet', 90), comp=None, arp=(46, 'harp'), bass=(43, 'root'), pad=(52, 62), timp=True,
      drums=dict(kick='x.......x.....x.', tamb='....x.......x...', crash='x...............'),
      bonus=dict(bpm=104, drums=dict(kick='x...x...x...x...', snare='....x.......x.xx', tamb='x.x.x.x.x.x.x.x.'), brass=61)),
  'moonridge': dict(key='D', oct=3, mode='dorian', chordmode='dorian', bpm=84, prog=[0, 0, 3, 6, 0, 5, 3, 4],
      lead=(60, 'horn', 92), lead2=(73, 'flute', 90), comp=None, arp=(8, 'celesta'), bass=(43, 'root'), pad=(44, 52), timp=True,
      drums=dict(kick='x.........x.....', tamb='', tri='........x.......'),
      bonus=dict(bpm=108, drums=dict(kick='x...x...x...x...', snare='....x.......x...', ltom='..x...x...x.x.x.'), brass=61)),
  'frost': dict(key='E', oct=3, mode='minor', chordmode='minor', bpm=72, prog=[0, 5, 2, 6, 0, 5, 3, 4],
      lead=(42, 'cello', 96), lead2=(110, 'fiddle', 92), comp=None, arp=(9, 'glock'), bass=(43, 'root'), pad=(52, 62), taiko=True,
      drums=dict(kick='x.......x.......', tri='....x.......x...'),
      bonus=dict(bpm=96, drums=dict(kick='x..x..x.x..x..x.', snare='....x.......x...', crash='x...............'), brass=61)),
  'atlantis': dict(key='F', oct=3, mode='lydian', chordmode='lydian', bpm=76, prog=[0, 1, 0, 5, 3, 1, 4, 0],
      lead=(73, 'flute', 90), lead2=(11, 'vibes', 92), comp=None, arp=(46, 'harp'), bass=(35, 'root5'), pad=(89, 60),
      drums=dict(shaker='x.x.x.x.x.x.x.x.', tri='x...............', kick='x.......x.......'),
      bonus=dict(bpm=100, drums=dict(kick='x...x...x...x...', shaker='xxxxxxxxxxxxxxxx', snare='....x.......x...'), brass=None)),
  'neon': dict(key='A', oct=2, mode='minor', chordmode='minor', bpm=116, prog=[0, 5, 2, 6, 0, 5, 3, 4],
      lead=(81, 'saw', 88), lead2=(80, 'square', 80), comp=None, arp=(80, 'arp16'), bass=(38, 'octave8'), pad=(90, 66),
      drums=dict(kick='x...x...x...x...', snare='....x.......x...', hat='xxxxxxxxxxxxxxxx', clap='....x.......x...'),
      bonus=dict(bpm=132, drums=dict(kick='x...x...x...x...', snare='....x.......x...', ohat='..x...x...x...x.', hat='xxxxxxxxxxxxxxxx', clap='....x..x....x..x'), brass=None)),
  'dragon': dict(key='G', oct=3, mode='penta', chordmode='major', bpm=96, prog=[0, 5, 3, 4, 0, 5, 1, 4],
      lead=(77, 'shakuhachi', 92), lead2=(110, 'erhu', 94), comp=None, arp=(106, 'pipa'), bass=(45, 'root5'), pad=(48, 50), taiko=True,
      drums=dict(wood_h='..x...x...x...x.', china='x...............'),
      bonus=dict(bpm=124, drums=dict(wood_h='x.x.x.x.x.x.x.x.', china='x.......x.......', kick='x..x..x.x..x..x.'), brass=None)),
  'cosmic': dict(key='C', oct=3, mode='lydian', chordmode='lydian', bpm=64, prog=[0, 1, 5, 4, 0, 1, 3, 4],
      lead=(98, 'crystal', 84), lead2=(100, 'brightness', 80), comp=None, arp=(8, 'celesta'), bass=(39, 'root'), pad=(91, 66),
      drums=dict(kick='x...............', tri='........x.......'),
      bonus=dict(bpm=88, drums=dict(kick='x.......x.......', snare='....x.......x...', hat='x.x.x.x.x.x.x.x.'), brass=None)),
  'lakeside': dict(key='G', oct=3, mode='major', chordmode='major', bpm=104, prog=[0, 3, 0, 4, 0, 3, 4, 0],
      lead=(22, 'harmonica', 92), lead2=(78, 'whistle', 86), comp=(25, 'strum'), arp=(105, 'roll'), bass=(32, 'twofeel'), pad=None,
      drums=dict(kick='x.......x.......', snare='....x.......x...', shaker='x.x.x.x.x.x.x.x.'),
      bonus=dict(bpm=128, drums=dict(kick='x...x...x...x...', snare='....x.......x...', tamb='x.x.x.x.x.x.x.x.'), brass=None)),
  'nebula': dict(key='C#', oct=2, mode='mpenta', chordmode='minor', bpm=100, prog=[0, 5, 3, 6, 0, 5, 3, 4],
      leadoct=2, lead=(82, 'calliope', 82), lead2=(88, 'newage', 80), comp=None, arp=(80, 'arp16'), bass=(38, 'octave8'), pad=(95, 64),
      drums=dict(kick='x.......x.......', clap='....x.......x...', hat='..x...x...x...x.'),
      bonus=dict(bpm=124, drums=dict(kick='x...x...x...x...', clap='....x.......x...', hat='xxxxxxxxxxxxxxxx'), brass=None)),
  'vault': dict(key='B', oct=2, mode='harm', chordmode='minor', bpm=118, swing=0.62, prog=[0, 3, 4, 0, 5, 1, 4, 4],
      lead=(59, 'mutedtpt', 92), lead2=(11, 'vibes', 92), comp=(0, 'jazzcomp'), arp=None, bass=(32, 'walk'), pad=None,
      drums=dict(ride='x.xxx.xxx.xxx.xx', hat='....x.......x...', kick='x.......x.......', rim='......x.......x.'),
      bonus=dict(bpm=144, drums=dict(ride='x.xxx.xxx.xxx.xx', snare='...x..x....x.x..', kick='x.....x...x.....'), brass=61)),
  'starlight': dict(key='E', oct=3, mode='major', chordmode='major', bpm=90, meter=3, prog=[0, 3, 4, 0, 5, 1, 4, 0],
      lead=(8, 'celesta', 92), lead2=(73, 'flute', 90), comp=None, arp=(46, 'waltzharp'), bass=(45, 'waltz'), pad=(48, 48),
      drums=dict(tri='x.....x.....'),
      bonus=dict(bpm=112, drums=dict(tri='x...x...x...', kick='x...........', tamb='....x...x...'), brass=None)),
  'fruit': dict(key='C', oct=3, mode='major', chordmode='major', bpm=112, prog=[0, 4, 5, 3, 0, 4, 3, 4],
      lead=(114, 'steeldrum', 96), lead2=(12, 'marimba', 96), comp=(24, 'strum'), arp=None, bass=(33, 'reggae'), pad=None,
      drums=dict(conga_l='x..x....x..x....', conga_h='..x..x.x..x..x.x', shaker='xxxxxxxxxxxxxxxx', claves='x..x..x...x.x...'),
      bonus=dict(bpm=136, drums=dict(kick='x...x...x...x...', conga_h='.xx.xx.x.xx.xx.x', shaker='xxxxxxxxxxxxxxxx', claves='x..x..x...x.x...'), brass=None)),
}
DRUMNOTE = dict(kick=KICK, snare=SNARE, rim=RIM, clap=CLAP, hat=HAT, ohat=OHAT, ride=RIDE, crash=CRASH, china=CHINA, tamb=TAMB, shaker=SHAKER,
                cabasa=CABASA, conga_h=CONGA_H, conga_l=CONGA_L, bongo_h=BONGO_H, bongo_l=BONGO_L, tri=TRI, claves=CLAVES, wood_h=WOOD_H, ltom=LTOM, htom=HTOM)

class Piece:
    def __init__(s, st, bonus=False, seed=1):
        s.st = st; s.bonus = bonus; s.r = random.Random(seed)
        s.bpm = st['bonus']['bpm'] if bonus else st['bpm']; s.beat = 60 / s.bpm; s.meter = st.get('meter', 4)
        s.root = 12 * (st['oct'] + 1) + NOTE[st['key']]; s.scale = MODES[st['mode']]; s.cscale = MODES[st['chordmode']]
        s.swing = st.get('swing', 0)
    def deg(s, d, scale=None, base=None):
        sc = scale or s.scale; base = s.root if base is None else base
        o, i = divmod(d, len(sc)); return base + 12 * o + sc[i]
    def chord(s, d):  # triad stacked in thirds over the chord scale
        return [s.deg(d, s.cscale), s.deg(d + 2, s.cscale), s.deg(d + 4, s.cscale)]
    def t8(s, k):  # time of the k-th eighth, with swing
        base = (k // 2) * s.beat
        return base + (s.beat * s.swing if (k % 2 and s.swing) else (s.beat / 2 if k % 2 else 0))

def nearest_scale(p, n):
    """index in the lead scale nearest to midi note n"""
    best = None
    for d in range(-10, 30):
        v = p.deg(d, base=p.root + 12)
        if best is None or abs(v - n) < abs(best[1] - n): best = (d, v)
    return best[0]

RHYTHMS4 = [[1, .5, .5, 1, 1], [1.5, .5, 1, 1], [.5, .5, 1, .5, .5, 1], [2, 1, 1], [1, 1, 2], [.5, .5, .5, .5, 2], [1.5, .5, 2], [1, .5, .5, 2]]
RHYTHMS3 = [[1, 1, 1], [2, 1], [1.5, .5, 1], [3], [1, .5, .5, 1]]

def melody(p, ch, bars, t0, vel, octave=1, density=1.0, seed=0, leg=0.95):
    """Motif-based melody: a 2-bar idea, repeated and varied; strong beats land on chord tones."""
    r = random.Random(seed); meter = p.meter
    R = RHYTHMS3 if meter == 3 else RHYTHMS4
    motif_r = [r.choice(R), r.choice(R)]
    motif_s = [r.choice([-1, 1, 2, -2, 0, 1]) for _ in range(12)]
    prog = p.st['prog']; cur = None; out = []
    for b in range(bars):
        phrase_bar = b % 8
        ch_deg = prog[b % len(prog)]
        tones = [x + 12 * octave for x in p.chord(ch_deg)]
        rhythm = motif_r[b % 2] if phrase_bar not in (3, 7) else ([2, 2] if meter == 4 else [3])
        if density > 1.2 and phrase_bar not in (3, 7): rhythm = [x / 2 for x in rhythm for _ in (0, 1)]
        if b % 4 == 2 and phrase_bar not in (3, 7): rhythm = r.choice(R)  # variation
        t = t0 + b * meter * p.beat; pos = 0.0
        for i, d in enumerate(rhythm):
            strong = abs(pos - round(pos)) < 1e-6 and int(round(pos)) % (2 if meter == 4 else 3) == 0
            if cur is None or strong or i == len(rhythm) - 1 and phrase_bar in (3, 7):
                home = p.root + 12 * octave + 14   # the register the tune returns to
                if phrase_bar == 7 and i == len(rhythm) - 1: cands = [tones[0] + 12 * k for k in (-1, 0, 1, 2)]
                else: cands = [x + 12 * k for x in tones for k in (-1, 0, 1, 2)]
                ref = home if cur is None else cur
                # close to the previous note, gently pulled back towards home, with a little randomness
                cur = min(cands, key=lambda c: abs(c - ref) + 0.28 * abs(c - home) + r.random() * 6)
            else:
                step = motif_s[(b * 4 + i) % len(motif_s)]
                cur = p.deg(nearest_scale(p, cur) + step, base=p.root + 12)
            if r.random() < 0.06 and not strong and phrase_bar not in (3, 7): pos += d; continue  # breath
            out.append((t + pos * p.beat, cur, d * p.beat * leg, vel + (8 if strong else 0) + r.randint(-5, 5)))
            pos += d
    for (tt, n, dd, v) in out: p.s.note(tt, ch, n, dd, v)
    return out

def comp(p, ch, style, bars, t0, vel):
    for b in range(bars):
        tones = p.chord(p.st['prog'][b % 8]); t = t0 + b * p.meter * p.beat; tn = [x + 12 for x in tones]
        if style == 'strum':
            for k, (pos, v) in enumerate([(0, 1), (1, .7), (1.5, .8), (2.5, .7), (3, .9)] if p.meter == 4 else [(0, 1), (1, .7), (2, .7)]):
                for j, n in enumerate(tn + [tn[0] + 12]): p.s.note(t + pos * p.beat + j * 0.012, ch, n, p.beat * 0.9, int(vel * v))
        elif style == 'stab':
            for pos in (0.5, 1.5, 2.75, 3.5):
                for n in tn: p.s.note(t + pos * p.beat, ch, n, p.beat * 0.22, vel)
        elif style == 'jazzcomp':
            sev = tn + [p.deg(p.st['prog'][b % 8] + 6, p.cscale) + 12]
            for pos in (1.0 if b % 2 else 0.0, 2.5 if b % 2 else 2.0):
                for n in sev: p.s.note(t + pos * p.beat + (p.beat * 0.12 if p.swing and pos % 1 else 0), ch, n, p.beat * 0.6, vel - 10)

def arp(p, ch, style, bars, t0, vel):
    for b in range(bars):
        tones = p.chord(p.st['prog'][b % 8]); t = t0 + b * p.meter * p.beat
        up = [x + 12 for x in tones] + [x + 24 for x in tones]
        if style in ('harp', 'celesta', 'glock', 'pipa', 'roll'):
            seq = [0, 1, 2, 3, 4, 3, 2, 1] if style != 'roll' else [0, 2, 1, 3, 2, 4, 3, 5]
            off = 12 if style in ('celesta', 'glock') else 0
            for k, i in enumerate(seq): p.s.note(t + k * p.beat / 2, ch, up[i % len(up)] + off, p.beat * 1.4, vel - (6 if k % 2 else 0))
        elif style == 'arp16':
            seq = [0, 1, 2, 3, 2, 1, 2, 3, 4, 3, 2, 1, 2, 3, 4, 5]
            for k, i in enumerate(seq): p.s.note(t + k * p.beat / 4, ch, up[i % len(up)] + 12, p.beat * 0.2, vel - (10 if k % 2 else 0))
        elif style == 'waltzharp':
            for k, i in enumerate([0, 2, 4, 5, 4, 2]): p.s.note(t + k * p.beat / 2, ch, up[i % len(up)], p.beat * 1.2, vel - (8 if k % 2 else 0))

def bass(p, ch, style, bars, t0, vel):
    for b in range(bars):
        tones = p.chord(p.st['prog'][b % 8]); r0 = tones[0] - 12; fifth = tones[2] - 12; t = t0 + b * p.meter * p.beat
        nxt = p.chord(p.st['prog'][(b + 1) % 8])[0] - 12
        pat = {
            'root': [(0, r0, 3.8)], 'root5': [(0, r0, 1.6), (2, fifth, 1.6)], 'twofeel': [(0, r0, .9), (2, fifth, .9)],
            'octave8': [(k * .5, r0 + (12 if k % 2 else 0), .4) for k in range(8)],
            'funk': [(0, r0, .4), (.75, r0, .2), (1.5, r0 + 12, .3), (2, fifth, .4), (3, r0, .3), (3.5, r0 + 10, .3)],
            'walk': [(0, r0, .9), (1, r0 + p.cscale[2] if len(p.cscale) > 2 else r0 + 3, .9), (2, fifth, .9), (3, nxt - 1, .9)],
            'reggae': [(0, r0, .9), (1.5, r0, .4), (2, fifth, .9), (3, r0 + 12, .4), (3.5, fifth, .4)],
            'waltz': [(0, r0, .9)],
        }[style]
        for pos, n, d in pat: p.s.note(t + pos * p.beat, ch, n, d * p.beat, vel - (6 if pos % 1 else 0))
        if style == 'waltz':
            for pos in (1, 2):
                for n in tones: p.s.note(t + pos * p.beat, 4, n, p.beat * 0.5, vel - 30)  # oom-pah-pah on the pad channel

def drums(p, pats, bars, t0, vel, fill=True):
    steps = 16 if p.meter == 4 else 12
    for b in range(bars):
        t = t0 + b * p.meter * p.beat
        for name, pat in pats.items():
            if not pat: continue
            note = DRUMNOTE[name]
            for k in range(steps):
                if pat[k % len(pat)] != 'x': continue
                tt = t + k * p.beat / 4
                if p.swing and k % 4 == 2: tt += p.beat * (p.swing - 0.5) / 1  # swung 8ths
                v = vel + (10 if k % 4 == 0 else 0) - (14 if name in ('hat', 'shaker', 'tamb', 'cabasa') else 0) + p.r.randint(-6, 6)
                p.s.note(tt, 9, note, p.beat / 3, v)
        if fill and b % 4 == 3 and p.meter == 4:  # small tom fill into the next phrase
            for k, n in enumerate([HTOM, HTOM, LTOM, LTOM]): p.s.note(t + (3 + k * .25) * p.beat, 9, n, p.beat / 4, vel - 6 + k * 4)
        if b % 8 == 0: p.s.note(t, 9, CRASH, p.beat * 2, vel - 8)

def big_drums(p, ch, style, bars, t0, vel):
    for b in range(bars):
        t = t0 + b * p.meter * p.beat
        hits = [(0, 1.0), (2.5, .7), (3, .85)] if style == 'taiko' else [(0, 1.0), (2, .6)]
        for pos, v in hits: p.s.note(t + pos * p.beat, ch, 36 if style == 'taiko' else p.root - 12, p.beat, int(vel * v))
        if b % 4 == 3:
            for k in range(8): p.s.note(t + 2 * p.beat + k * p.beat / 4, ch, 38 if style == 'taiko' else p.root - 12, p.beat / 4, 50 + k * 8)

def render_piece(game, bonus):
    st = STYLES[game]; p = Piece(st, bonus, seed=hash(game) & 0xffff)
    s = p.s = Synth(room=0.7, level=0.55)
    L, L2 = st['lead'], st['lead2']
    s.prog(0, L[0], pan=70, rev=70, vol=104); s.prog(1, L2[0], pan=52, rev=75, vol=96)
    if st.get('comp'): s.prog(2, st['comp'][0], pan=40, rev=55, vol=86)
    if st.get('arp'): s.prog(3, st['arp'][0], pan=88, rev=80, vol=80)
    if st.get('pad'): s.prog(4, st['pad'][0], rev=90, vol=st['pad'][1] + (6 if bonus else 0))
    elif st['bass'][1] == 'waltz': s.prog(4, 48, rev=90, vol=60)
    s.prog(5, st['bass'][0], pan=64, rev=35, vol=108)
    if st.get('timp') or st.get('taiko'): s.prog(6, 116 if st.get('taiko') else 47, rev=60, vol=112)
    if bonus and st['bonus'].get('brass'): s.prog(7, st['bonus']['brass'], pan=60, rev=70, vol=84)
    s.prog(9, 0, rev=40, vol=96)
    BARS = 16; period = BARS * p.meter * p.beat
    for rep in range(3):
        T0 = rep * period
        # lead plays bars 1-8, second lead answers bars 9-16 (bonus: lead an octave up and busier)
        lo = st.get('leadoct', 1)
        melody(p, 0, 8, T0, 92 if not bonus else 100, octave=lo if not bonus else lo + 1, density=1.0 if not bonus else 1.5, seed=7)
        melody(p, 1, 8, T0 + 8 * p.meter * p.beat, 88 if not bonus else 96, octave=lo, density=1.0 if not bonus else 1.5, seed=11)
        if st.get('comp'): comp(p, 2, st['comp'][1], BARS, T0, 74)
        if st.get('arp'): arp(p, 3, st['arp'][1], BARS, T0, 70 if not bonus else 78)
        if st.get('pad'):
            for b in range(BARS):
                for n in p.chord(st['prog'][b % 8]): s.note(T0 + b * p.meter * p.beat, 4, n + 12, p.meter * p.beat * 0.98, 52)
        bass(p, 5, st['bass'][1] if not (bonus and st['bass'][1] in ('root', 'root5', 'twofeel')) else 'octave8', BARS, T0, 98)
        if st.get('timp'): big_drums(p, 6, 'timp', BARS, T0, 96 if not bonus else 112)
        if st.get('taiko'): big_drums(p, 6, 'taiko', BARS, T0, 100 if not bonus else 118)
        drums(p, st['bonus']['drums'] if bonus else st['drums'], BARS, T0, 84 if not bonus else 96)
        if bonus and st['bonus'].get('brass'):
            for b in range(BARS):
                if b % 2 == 0:
                    for n in p.chord(st['prog'][b % 8]): s.note(T0 + b * p.meter * p.beat, 7, n + 12, p.beat * 0.6, 92); s.note(T0 + (b * p.meter + 1.5) * p.beat, 7, n + 12, p.beat * 0.4, 80)
    a = s.render(2 * period + 6)
    return a[int(period * SR):int((2 * period + 3) * SR)]   # middle pass: real reverb tails at the seam

def render_sting(game, big):
    st = STYLES[game]; p = Piece(st, False); s = p.s = Synth(room=0.8, level=0.65)
    L = st['lead']; s.prog(0, L[0], rev=85, vol=110); s.prog(3, (st.get('arp') or (46,))[0], rev=90, vol=100); s.prog(4, 48, rev=95, vol=100)
    s.prog(7, 61, rev=85, vol=96 if big else 80); s.prog(9, 0, rev=70, vol=100)
    tones = [x + 12 for x in p.chord(0)]; run = [p.deg(i, base=p.root + 12) for i in range(0, 12 if big else 8)]
    for i, n in enumerate(run): s.note(i * 0.06, 3, n, 0.9, 80 + i * 3)
    t = len(run) * 0.06
    for n in tones + [tones[0] + 12]: s.note(t, 4, n, 2.4 if big else 1.6, 100); s.note(t, 7, n, 1.2 if big else 0.6, 96)
    for i, n in enumerate([tones[2], tones[0] + 12] + ([tones[1] + 12, tones[2] + 12, tones[0] + 24] if big else [])):
        s.note(t + i * 0.16, 0, n, 0.5 if i < (4 if big else 1) else 1.6, 108)
    s.note(t, 9, CRASH, 2.5, 110); s.note(t, 9, KICK, 0.3, 120)
    if big:
        for k in range(10): s.note(k * 0.07, 9, SNARE, 0.06, 50 + k * 6)
    return s.render(5.5 if big else 3.8)

def save(name, a):
    a = a / (np.abs(a).max() + 1e-9) * 0.89
    wf.write(f'{OUT}/{name}.wav', SR, a.astype(np.float32))

if __name__ == '__main__':
    for g in (sys.argv[1:] or list(STYLES)):
        save(f'{g}_base', render_piece(g, False)); save(f'{g}_bonus', render_piece(g, True))
        save(f'{g}_win', render_sting(g, False)); save(f'{g}_jackpot', render_sting(g, True))
        print(g, 'done', flush=True)
