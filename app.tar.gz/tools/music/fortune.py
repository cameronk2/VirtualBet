# Fortune Live sound package, free tools only:
#   * music: FluidSynth + FluidR3 Mono GM soundfont (MIT): a disco-funk studio band loop, a faster
#     bonus loop and a brass win sting
#   * effects: numpy synthesis (pegs, reels, coin, puck, applause) + FluidSynth stingers, packed into
#     ONE sprite file (sfx.mp3) so the game adds few files
#   * host: Kokoro-82M (Apache 2.0), British female "bf_emma", spellings from Kokoro's British dictionary
#     (misaki gb_gold / gb_silver), all lines packed into ONE sprite (voice.mp3)
# Output: client/audio/fortune/{music/*.mp3, sfx.mp3, voice.mp3} and client/src/pages/fortune/sprites.js
import sys, os, json, subprocess, numpy as np, scipy.io.wavfile as wf
sys.path.insert(0, os.path.dirname(__file__))
from fs import m, SR
import phoenix as P
import racing as R
HERE = os.path.dirname(__file__)
OUT = os.path.join(HERE, '../../client/audio/fortune')
SPRITES = os.path.join(HERE, '../../client/src/pages/fortune/sprites.js')
LINES = json.load(open(os.path.join(HERE, '../../client/src/pages/fortune/lines.json')))
TMP = '/tmp/claude-0/flx'; os.makedirs(TMP, exist_ok=True)
os.makedirs(f'{OUT}/music', exist_ok=True)
GM = lambda fn, sec, room=.6, level=.45: P.st(P.fsynth(fn, sec, room, level))
DRUMS = 9
EPIANO, SLAPBASS, FINGERBASS, BRASS, TRUMPET, SAX, STR, SYNSTR, GLOCK, ORGAN, GUITAR, CLAV, TIMP, VIBES = 4, 36, 33, 61, 56, 65, 48, 50, 9, 17, 27, 7, 47, 11
KICK, SNARE, CLAP, HHC, HHO, CRASH, TAMB, RIDE, TOMH, TOML, COWBELL = 36, 38, 39, 42, 46, 49, 54, 51, 50, 45, 56

def save_mp3(path, x, peak_db=-1.0, kbps=96, mono=False):
    x = P.st(x); x = x / (np.abs(x).max() + 1e-9) * 10 ** (peak_db / 20)
    w = f'{TMP}/{os.path.basename(path)}.wav'; wf.write(w, SR, x.astype(np.float32))
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', w, *(['-ac', '1'] if mono else []), '-codec:a', 'libmp3lame', '-b:a', f'{kbps}k', '-ar', '44100', f'{OUT}/{path}.mp3'], check=True)
    print(path, round(len(x) / SR, 2), 's')

# ── music ───────────────────────────────────────────────────────
def band(s, bars, bpm, prog, lead, intense=False, t0=0.0):
    beat = 60 / bpm
    s.prog(0, SLAPBASS if intense else FINGERBASS, rev=30, vol=104, pan=64)
    s.prog(1, EPIANO, rev=70, vol=78, pan=44); s.prog(2, BRASS, rev=70, vol=96, pan=78); s.prog(3, SYNSTR, rev=90, vol=66, pan=58)
    s.prog(4, GUITAR, rev=50, vol=64, pan=96); s.prog(5, TRUMPET, rev=80, vol=96, pan=70); s.prog(6, GLOCK, rev=90, vol=58, pan=34)
    s.prog(DRUMS, 0, rev=40, vol=112)
    for b in range(bars):
        root, kind = prog[b % len(prog)]; r = m(root); T = t0 + b * 4 * beat
        third = 3 if kind == 'm' else 4; sev = 10 if kind in ('m', '7') else 11
        # drums: four on the floor, open hats on the off-beat, claps on 2 and 4
        for q in range(4):
            s.note(T + q * beat, DRUMS, KICK, .1, 112 if q % 2 == 0 else 100)
            s.note(T + q * beat + beat / 2, DRUMS, HHO, .1, 70)
            s.note(T + q * beat, DRUMS, HHC, .05, 56)
            if q in (1, 3): s.note(T + q * beat, DRUMS, CLAP, .1, 96); s.note(T + q * beat, DRUMS, SNARE, .1, 70)
            if intense: s.note(T + q * beat + beat * .25, DRUMS, HHC, .05, 50); s.note(T + q * beat + beat * .75, DRUMS, TAMB, .05, 56)
        if b % 8 == 7:
            for k, n in enumerate([TOMH, TOMH, TOML, TOML]): s.note(T + 3 * beat + k * beat / 4, DRUMS, n, .1, 96)
        if b % 8 == 0: s.note(T, DRUMS, CRASH, 1, 96)
        # octave bass
        pat = [(0, 0), (.5, 12), (1, 0), (1.5, 12), (2, 0), (2.5, 12), (3, 7), (3.5, 12)]
        for t, o in pat: s.note(T + t * beat, 0, r - 12 + o, beat * .42, 100 if o == 0 else 84)
        # e-piano chord stabs on the off-beats, strings pad
        for t in (.5, 1.5, 2.5, 3.5):
            for o in (third, 7, sev): s.note(T + t * beat, 1, r + 12 + o, beat * .3, 70)
        for o in (0, third, 7): s.note(T, 3, r + 24 + o, 4 * beat * .98, 52)
        # guitar chicken-scratch
        for k in range(8):
            if k % 2: s.note(T + k * beat / 2, 4, r + 24 + [third, 7][k % 2 == 1], beat * .12, 64)
        # brass hits
        if b % 2 == 1:
            for o in (third, 7, 12): s.note(T + 2.5 * beat, 2, r + 12 + o, beat * .35, 100); s.note(T + 3 * beat, 2, r + 12 + o, beat * .7, 106)
    t = t0 + 8 * 4 * beat if not intense else t0 + 4 * 4 * beat
    for rep in range(2 if not intense else 3):
        tt = t + rep * 8 * 4 * beat
        for n, d in lead:
            if n != '-': s.note(tt, 5, m(n), d * beat * .9, 100); s.note(tt, 6, m(n) + 12, d * beat * .6, 60)
            tt += d * beat

def base_music():
    bpm = 118; bars = 32
    prog = [('F3', 'M'), ('F3', 'M'), ('D3', 'm'), ('D3', 'm'), ('Bb2', 'M'), ('C3', '7'), ('F3', 'M'), ('C3', '7')]
    lead = [('C5', 1), ('A4', .5), ('C5', .5), ('D5', 1), ('C5', 1), ('A4', 2), ('-', 2), ('F5', 1), ('E5', .5), ('D5', .5), ('C5', 1), ('A4', 1), ('C5', 4),
            ('Bb4', 1), ('A4', .5), ('G4', .5), ('F4', 1), ('A4', 1), ('G4', 2), ('C5', 2), ('A4', 1.5), ('G4', .5), ('F4', 2), ('-', 4)]
    sec = bars * 4 * 60 / bpm
    x = GM(lambda s: band(s, bars, bpm, prog, lead), sec + 2.5)
    save_mp3('music/base', P.fadeout(x[:int((sec + .4) * SR)], .4), -3, 96)

def bonus_music():
    bpm = 132; bars = 24
    prog = [('A2', 'm'), ('A2', 'm'), ('F2', 'M'), ('G2', '7'), ('A2', 'm'), ('A2', 'm'), ('D3', 'm'), ('E2', '7')]
    lead = [('E5', .5), ('E5', .5), ('-', .5), ('E5', .5), ('C5', .5), ('E5', 1), ('G5', 2), ('-', 2.5), ('A4', 1), ('C5', 1), ('D5', 1), ('E5', 1), ('D5', 2), ('B4', 2), ('-', 4),
            ('A5', 1), ('G5', 1), ('E5', 1), ('D5', 1), ('C5', 1.5), ('D5', .5), ('E5', 4)]
    sec = bars * 4 * 60 / bpm
    x = GM(lambda s: band(s, bars, bpm, prog, lead, intense=True), sec + 2.5)
    save_mp3('music/bonus', P.fadeout(x[:int((sec + .4) * SR)], .4), -3, 96)

def win_sting():
    def f(s):
        s.prog(0, BRASS, rev=90, vol=122); s.prog(1, GLOCK, rev=90, vol=100); s.prog(2, STR, rev=100, vol=100); s.prog(DRUMS, 0, rev=60, vol=120); s.prog(3, TRUMPET, rev=90, vol=118)
        for i, n in enumerate(['C4', 'E4', 'G4']): s.note(i * .12, 0, m(n), .1, 110)
        for n in ['C4', 'E4', 'G4', 'C5']: s.note(.36, 0, m(n), 1.6, 116)
        for n in ['G5', 'C6']: s.note(.36, 3, m(n), 1.5, 112)
        for k in range(10): s.note(.36 + k * .06, 1, m('C6') + [0, 4, 7, 12][k % 4], .5, 90)
        for n in ['C3', 'G3', 'E4']: s.note(.36, 2, m(n), 2, 96)
        for k in range(8): s.note(k * .04, DRUMS, SNARE, .05, 60 + k * 8)
        s.note(.36, DRUMS, CRASH, 2, 120); s.note(.36, DRUMS, KICK, .2, 127)
    x = GM(f, 3.0)
    save_mp3('music/win', P.fadeout(P.mix((0, x, 1), (.4, P.sparkle(1.6, 26, 3000, 9000, 51), .3)), .4), -2, 96)

# ── effects (sprite) ────────────────────────────────────────────
def applause(sec=2.2, n=420, seed=7, swell=True):
    r = np.random.default_rng(seed); out = np.zeros(int(sec * SR))
    for _ in range(n):
        t = r.uniform(0, sec * .85); L = int(.025 * SR); i = int(t * SR)
        c = P.bp(r.standard_normal(L), r.uniform(800, 1800), r.uniform(2500, 5500)) * np.exp(-np.arange(L) / (.004 * SR)) * r.uniform(.3, 1)
        out[i:i + L] += c[:len(out) - i]
    t = P.T(sec)
    env = np.minimum(1, t / .25) * np.exp(-np.maximum(0, t - sec * .45) / (sec * .3)) if swell else np.exp(-t / sec)
    crowd = P.bp(P.noise(sec), 300, 2500) * .25 * env
    return P.st(P.hall(P.st(out * env + crowd), 1.2, .25))

def effects():
    E = {}
    E['peg'] = P.mix((0, P.click(.008, 3800), 1), (0, P.bp(P.noise(.03), 1800, 4500) * P.env(int(.03 * SR), .001, tau=.005), .5))
    E['chip'] = P.mix((0, P.click(.01, 5200), 1), (.012, P.click(.01, 4200), .7), (0, P.chime([2600, 3900], .12, .03), .25))
    E['spin'] = P.hall(P.mix((0, P.whoosh(1.0, 200, 1800, 41, 2.5), .9), (0, P.thump(55, .4, .6), .5)), .8, .2)
    E['reel'] = P.mix(*[(k * .045, P.click(.012, 2500 + (k % 3) * 300), .6) for k in range(16)])
    E['reelStop'] = P.mix((0, P.thump(110, .18, .4), .9), (0, P.click(.02, 2000), .8))
    E['boost'] = P.hall(GM(lambda s: (s.prog(0, BRASS, rev=90, vol=118), s.prog(1, GLOCK, rev=90, vol=110), [s.note(i * .07, 0, m(n), .5, 110) for i, n in enumerate(['G4', 'C5', 'E5', 'G5'])], [s.note(.3 + i * .05, 1, m(n), .6, 100) for i, n in enumerate(['C6', 'E6', 'G6', 'C7'])]), 1.4), .9, .25)
    E['nomore'] = GM(lambda s: (s.prog(0, VIBES, rev=80, vol=110), [s.note(i * .16, 0, m(n), .5, 100) for i, n in enumerate(['G5', 'E5', 'C5'])]), 1.1)
    E['tick'] = P.mix((0, P.click(.012, 3000), 1), (0, P.chime([1800], .08, .02), .4))
    E['land'] = P.mix((0, P.thump(80, .4, .5), .8), (0, P.chime([1046, 1568], .8, .25), .5))
    E['win'] = P.hall(GM(lambda s: (s.prog(0, GLOCK, rev=90, vol=110), s.prog(1, BRASS, rev=80, vol=100), [s.note(i * .07, 0, m(n), .4, 105) for i, n in enumerate(['C6', 'E6', 'G6', 'C7'])], [s.note(.2, 1, m(n), .7, 100) for n in ['C4', 'E4', 'G4']]), 1.3), .9, .25)
    E['bonus'] = P.hall(GM(lambda s: (s.prog(0, BRASS, rev=90, vol=124), s.prog(1, TRUMPET, rev=90, vol=118), s.prog(DRUMS, 0, rev=60, vol=124),
                                      [s.note(k * .05, DRUMS, SNARE, .05, 50 + k * 4) for k in range(18)], s.note(.9, DRUMS, CRASH, 1.5, 124), s.note(.9, DRUMS, KICK, .2, 127),
                                      [s.note(.9, 0, m(n), 1.2, 118) for n in ['D4', 'F#4', 'A4', 'D5']], [s.note(.9 + i * .1, 1, m(n), .3 if i < 3 else 1, 116) for i, n in enumerate(['A4', 'D5', 'F#5', 'A5'])]), 2.6), 1.2, .25)
    E['reveal'] = P.mix((0, P.chime([1318, 1975, 2637], .9, .3), .7), (0, P.sparkle(.5, 8, 3500, 9000, 61), .4))
    E['flip'] = P.mix(*[(k * .09 * (1 + k * .04), P.chime([3200 + (k % 2) * 400], .05, .015), .5 - k * .015) for k in range(22)], (0, P.whoosh(.6, 600, 2400, 62, 3), .3))
    E['double'] = P.hall(GM(lambda s: (s.prog(0, BRASS, rev=90, vol=124), s.prog(1, GLOCK, rev=90, vol=110), [s.note(i * .12, 0, m(n), .25 if i < 2 else .9, 118) for i, n in enumerate(['C5', 'C5', 'G5'])], [s.note(.24 + k * .04, 1, m('C6') + [0, 7, 12, 19][k % 4], .5, 100) for k in range(10)]), 1.6), .9, .25)
    E['lock'] = P.mix((0, P.thump(140, .2, .4), .8), (0, P.click(.02, 1800), 1), (.03, P.chime([880, 1320], .4, .12), .5))
    E['aim'] = P.chime([2093], .18, .05) * .6
    E['drop'] = P.mix((0, P.whoosh(.5, 2400, 600, 63, 2), .6), (0, P.chime([1567], .2, .06), .4))
    E['shuffle'] = P.mix(*[(k * .05, P.bp(P.noise(.04), 2000, 6000) * P.env(int(.04 * SR), .002, tau=.01), .5) for k in range(36)])
    E['flipTile'] = P.mix((0, P.click(.012, 2800), .9), (0, P.chime([2400], .06, .02), .3))
    E['cheer'] = applause(2.4, 520, 7)
    E['lose'] = GM(lambda s: (s.prog(0, VIBES, rev=80, vol=96), [s.note(i * .18, 0, m(n), .5, 80) for i, n in enumerate(['E5', 'C5'])]), .9)
    # pack: each effect followed by silence; offsets in seconds
    gap = .25; parts = []; clips = {}; pos = 0.0
    for k, x in E.items():
        x = P.st(P.tail_trim(P.st(x)))
        x = x / (np.abs(x).max() + 1e-9) * 10 ** (-3 / 20)
        clips[k] = [round(pos, 3), round(len(x) / SR, 3)]
        parts += [x, np.zeros((int(gap * SR), 2))]; pos += len(x) / SR + gap
    save_mp3('sfx', np.concatenate(parts), -1.5, 96)
    return clips

# ── host voice (sprite) ─────────────────────────────────────────
EXTRA = {'fortune': 'fˈɔːʧuːn', 'fortunes': 'fˈɔːʧuːnz', "let's": 'lˈɛts', "where's": 'wˈɛːz', "that's": 'ðˈats', "it's": 'ɪts', 'booster': 'bˈuːstə', 'flapper': 'flˈapə', 'supercharged': 'sˈuːpəʧɑːʤd', 'seconds': 'sˈɛkᵊndz', 'congratulations': 'kənɡɹatjʊlˈAʃᵊnz'}
R.EXTRA.update(EXTRA)
def voices(voice='bf_emma'):
    gap = .3; parts = []; clips = {}; pos = 0.0
    for k, text in LINES.items():
        excited = '!' in text
        ph = R.phon(text)
        a = R.tts(ph, voice, 1.02 if excited else 0.98, blend=('bf_isabella', .25))
        raw = f'{TMP}/v_{k}.wav'; wf.write(raw, 24000, a.astype(np.float32))
        proc = f'{TMP}/v_{k}_p.wav'
        af = ('silenceremove=start_periods=1:start_threshold=-45dB:stop_periods=1:stop_threshold=-45dB:stop_duration=0.15,aresample=44100,highpass=f=90,'
              f'equalizer=f=200:t=q:w=1:g=1.5,equalizer=f=3000:t=q:w=1.2:g={4 if excited else 3},equalizer=f=7500:t=q:w=1:g=1.5,'
              'acompressor=threshold=-24dB:ratio=4:attack=3:release=90,volume=12dB,alimiter=limit=0.92')
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '1', proc], check=True)
        sr, y = wf.read(proc); y = y.astype(np.float64)
        if y.dtype.kind == 'i' or np.abs(y).max() > 2: y = y / 32768
        clips[k] = [round(pos, 3), round(len(y) / sr, 3)]
        parts += [y, np.zeros(int(gap * sr))]; pos += len(y) / sr + gap
    allv = np.concatenate(parts)
    w = f'{TMP}/voice_all.wav'; wf.write(w, 44100, allv.astype(np.float32))
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', w, '-ac', '1', '-codec:a', 'libmp3lame', '-b:a', '56k', f'{OUT}/voice.mp3'], check=True)
    print('voice lines', len(clips), round(pos, 1), 's')
    return clips

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('music', 'all'): base_music(); bonus_music(); win_sting()
    sfx_clips = effects() if what in ('sfx', 'all') else None
    voice_clips = voices() if what in ('voice', 'all') else None
    old = open(SPRITES).read() if os.path.exists(SPRITES) else ''
    def keep(name):
        import re as _re
        mm = _re.search(rf'export const {name} = (\{{.*?\}});', old, _re.S); return json.loads(mm.group(1)) if mm else {}
    sfx_clips = sfx_clips or keep('SFX'); voice_clips = voice_clips or keep('VOICE')
    with open(SPRITES, 'w') as f:
        f.write('// Generated by tools/music/fortune.py: [offset, duration] in seconds within sfx.mp3 / voice.mp3.\n')
        f.write(f'export const SFX = {json.dumps(sfx_clips)};\n')
        f.write(f'export const VOICE = {json.dumps(voice_clips)};\n')
