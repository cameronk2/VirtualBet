# Physically-inspired gong synthesis: inharmonic modal partials with beating pairs, energy bloom
# into the upper partials (tam-tam), optional pitch glide (Chinese opera gongs), a felt-mallet
# strike, and a synthetic stereo hall.
import numpy as np, scipy.signal as sg, scipy.io.wavfile as wf
SR=44100
def hall(x, secs=3.0, wet=0.3, seed=1, damp=4000):
    rng=np.random.default_rng(seed); n=int(secs*SR); t=np.arange(n)/SR
    irs=[]
    for ch in range(2):
        ir=rng.standard_normal(n)*np.exp(-t*6.9/secs)
        b,a=sg.butter(2,damp/(SR/2)); ir=sg.lfilter(b,a,ir); ir[:int(0.012*SR)]*=np.linspace(0,1,int(0.012*SR)); irs.append(ir/np.sqrt((ir**2).sum()))
    if x.ndim==1: x=np.stack([x,x],1)
    out=np.zeros((len(x)+n-1,2))
    for ch in range(2): out[:,ch]=sg.fftconvolve(x[:,ch],irs[ch])*wet
    out[:len(x)]+=x*(1-wet*0.5)
    return out
def gong(f0=110, dur=6.0, partials=70, tilt=1.1, bloom=0.0, glide=0.0, glide_tau=0.35, bright=1.0, seed=0, strike=1.0, decay=1.0):
    rng=np.random.default_rng(seed); n=int(dur*SR); t=np.arange(n)/SR; y=np.zeros(n)
    # modal ratios: low modes roughly like a plate (k^1.6-ish spacing) with jitter, upper modes dense
    ks=np.arange(1,partials+1)
    ratios=np.concatenate([[1.0,1.52,2.0,2.42,2.94,3.56,4.1],1.0+0.42*ks[7:]**1.13])[:partials]
    ratios*=1+rng.uniform(-0.03,0.03,partials); ratios[0]=1
    for i,r in enumerate(ratios):
        f=f0*r
        if f>16000: break
        amp=(1/(i+1)**tilt)*rng.uniform(0.6,1.2)*(bright if i>8 else 1)
        tau=decay*dur*0.55*(f0/f)**0.55*rng.uniform(0.7,1.2)
        env=np.exp(-t/tau)
        if bloom>0 and i>6:  # tam-tam: upper partials swell after the strike
            att=bloom*rng.uniform(0.4,1.2); env=env*(1-np.exp(-t/att))*(1.6+bloom)
        ph=rng.uniform(0,2*np.pi); df=rng.uniform(0.2,1.6)
        fi=f*(1+glide*np.exp(-t/glide_tau)) if glide else f
        phase=2*np.pi*np.cumsum(fi)/SR if glide else 2*np.pi*f*t
        y+=amp*env*(0.6*np.sin(phase+ph)+0.4*np.sin(phase*(1+df/f)+ph*1.7))
    # mallet: soft low thump + short filtered noise
    th=np.exp(-t/0.09)*np.sin(2*np.pi*f0*0.5*t)*0.8*strike
    nz=rng.standard_normal(n)*np.exp(-t/0.018); b,a=sg.butter(2,[max(200,f0*2)/(SR/2),min(9000,f0*40)/(SR/2)],'band'); nz=sg.lfilter(b,a,nz)*0.6*strike
    y=y+th+nz
    fade=int(0.25*SR); y[-fade:]*=np.linspace(1,0,fade)
    return y/np.abs(y).max()
def norm(x,peak=0.95): return x/np.abs(x).max()*peak
def save(name,x): wf.write(f'/tmp/claude-0/sfx/{name}.wav',SR,norm(x).astype(np.float32)); print(name, round(len(x)/SR,2))
if __name__=='__main__':
    # landing gongs: six pitched opera-style gongs, slight downward glide (daluo), different pitch/brightness
    for i,(f,g,b) in enumerate([(196,0.06,1.0),(220,0.05,1.1),(247,0.07,0.9),(262,0.04,1.2),(294,0.06,1.0),(330,0.05,1.15)]):
        save(f'gong_land_{i+1}', hall(gong(f,2.8,partials=45,tilt=1.0,glide=g,glide_tau=0.3,bright=b,seed=10+i,decay=0.8),2.2,0.28,seed=i))
    # big ceremonial tam-tam with bloom
    save('gong_big', hall(gong(58,8.5,partials=110,tilt=0.75,bloom=0.9,bright=1.2,seed=3,strike=1.4,decay=1.3),4.0,0.35,seed=9))
    save('gong_big_2', hall(gong(73,7.0,partials=100,tilt=0.8,bloom=0.6,bright=1.1,seed=5,strike=1.2,decay=1.2),3.5,0.33,seed=8))
    # lock: small bright gong + metallic clank
    lk=gong(523,1.3,partials=30,tilt=1.2,glide=0.02,seed=21,decay=0.6)*0.8
    save('gong_lock', hall(lk,1.5,0.2,seed=4))
    # reset: rising opera gong (xiaoluo glides UP) followed by a second higher hit
    r1=gong(392,1.6,partials=35,tilt=1.0,glide=-0.12,glide_tau=0.25,seed=31,decay=0.7)
    r2=gong(523,1.4,partials=35,tilt=1.0,glide=-0.10,glide_tau=0.22,seed=32,decay=0.7)
    x=np.zeros(int(2.1*SR)); x[:len(r1)]+=r1; o=int(0.16*SR); x[o:o+len(r2)]+=r2[:len(x)-o]*0.9
    save('gong_reset', hall(x,1.8,0.25,seed=5))
