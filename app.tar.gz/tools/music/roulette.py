# Roulette croupier voice and sounds, free tools only:
#   * voice: Kokoro-82M (Apache 2.0), British female "bf_isabella", slow and warm, via onnxruntime + ffmpeg
#   * ball, wheel and win sounds: numpy synthesis + FluidSynth (FluidR3 Mono GM, MIT)
# Output: client/audio/roulette/{voice,sfx,music}/*.mp3
import sys, os, json, subprocess, numpy as np, scipy.io.wavfile as wf
sys.path.insert(0, os.path.dirname(__file__))
from fs import m, SR
import phoenix as P
OUT = os.path.join(os.path.dirname(__file__), '../../client/audio/roulette')
TMP = '/tmp/claude-0/rlx'; os.makedirs(TMP, exist_ok=True)
for d in ('voice', 'sfx', 'music'): os.makedirs(f'{OUT}/{d}', exist_ok=True)

# spellings copied from Kokoro's own British dictionary (misaki gb_gold.json), so nothing is mispronounced
ONES = {0: 'zˈɪəɹQ', 1: 'wˈʌn', 2: 'tˈuː', 3: 'θɹˈiː', 4: 'fˈɔː', 5: 'fˈIv', 6: 'sˈɪks', 7: 'sˈɛvᵊn', 8: 'ˈAt', 9: 'nˈIn', 10: 'tˈɛn',
        11: 'ɪlˈɛvᵊn', 12: 'twˈɛlv', 13: 'θˌɜːtˈiːn', 14: 'fˌɔːtˈiːn', 15: 'fˌɪftˈiːn', 16: 'sˌɪkstˈiːn', 17: 'sˌɛvntˈiːn', 18: 'ˌAtˈiːn', 19: 'nˌIntˈiːn'}
TENS = {20: 'twˈɛnti', 30: 'θˈɜːti'}
def num(n):
    if n in ONES: return ONES[n]
    t = n // 10 * 10; return TENS[t] + ('' if n == t else ' ' + ONES[n - t])
RED = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}
COL = {'red': 'ɹˈɛd', 'black': 'blˈak', 'green': 'ɡɹˈiːn'}

def lines():
    L = {}
    for n in range(37):
        c = 'green' if n == 0 else 'red' if n in RED else 'black'
        L[f'n{n}'] = f'{num(n)}, {COL[c]}.'
    L.update({'bets': 'plˈAs jɔː bˈɛts.', 'nomore': 'nˈQ mˈɔː bˈɛts.', 'win': 'wˈɛl dˈʌn, juː wˈɪn.', 'bigwin': 'ˈQ, wˌɒt ə wˈɪn!'})
    return L

def voices(voice='bf_isabella'):
    import onnxruntime as ort
    cfg = json.load(open('/tmp/claude-0/ko/src/kokoro_onnx/config.json')); vocab = cfg['vocab']
    sess = ort.InferenceSession('/tmp/claude-0/kk/kokoro-v1.0.int8.onnx'); vs = np.load('/tmp/claude-0/kk/voices-v1.0.bin')
    tk = 'input_ids' if 'input_ids' in {i.name for i in sess.get_inputs()} else 'tokens'
    # a blend of two British voices: Isabella's warmth with a little of Emma's clarity
    style = lambda n: (vs[voice][n] * 0.75 + vs['bf_emma'][n] * 0.25).astype(np.float32)
    for k, ph in lines().items():
        toks = [vocab[c] for c in ph if c in vocab]
        a = sess.run(None, {tk: np.array([[0, *toks, 0]], dtype=np.int64), 'style': style(len(toks)), 'speed': np.array([0.95], dtype=np.float32)})[0].reshape(-1)
        a = a / (np.abs(a).max() + 1e-9)
        raw = f'{TMP}/{k}.wav'; wf.write(raw, 24000, a.astype(np.float32))
        # smooth and intimate: slightly lower, warm low-mids, soft top, gentle room
        # clean processing only: no pitch shifting and no echo (both blurred the words)
        af = ('silenceremove=start_periods=1:start_threshold=-45dB:stop_periods=1:stop_threshold=-45dB:stop_duration=0.2,'
              'aresample=44100,highpass=f=80,equalizer=f=220:t=q:w=1:g=2,equalizer=f=3000:t=q:w=1.2:g=1.5,'
              'equalizer=f=8000:t=q:w=1:g=-2,acompressor=threshold=-22dB:ratio=2.5:attack=6:release=140,volume=11dB,alimiter=limit=0.9')
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '1', '-codec:a', 'libmp3lame', '-b:a', '64k', f'{OUT}/voice/{k}.mp3'], check=True)
    print('voice lines', len(lines()))

def clack(seed, bright=1.0):
    """One clay casino chip landing on another: a short, woody click (no ringing metal partials)."""
    r = np.random.default_rng(seed); n = int(.06 * SR); t = np.arange(n) / SR
    x = r.standard_normal(n) * np.exp(-t / .006)
    body = P.bp(x, 900 * bright, 3800 * bright, 2) * 1.0 + P.bp(x, 2200 * bright, 2700 * bright, 2) * 1.4   # the clay 'tock'
    thud = np.sin(2 * np.pi * r.uniform(330, 420) * t) * np.exp(-t / .012) * .35                              # felt underneath
    return body + thud
def clay_chips(seed=1, n=3):
    """A small stack being set down: a firm clack, then one or two lighter settles."""
    r = np.random.default_rng(seed); out = []
    t = 0
    for i in range(n):
        out.append((t, clack(seed * 10 + i, r.uniform(.9, 1.15)) * (1 if i == 0 else r.uniform(.25, .45))))
        t += r.uniform(.028, .055)
    return P.lay(out, .2)

def sfx():
    # the ball: a rolling rumble that slows over 5 s, with clicks off the frets as it settles
    sec = 5.4; t = P.T(sec); k = t / sec
    speed = (1 - k) ** 1.6
    roll = P.bp(P.noise(sec), 900, 4200) * (0.25 + 0.75 * speed) * (0.6 + 0.4 * np.sin(2 * np.pi * np.cumsum(6 + 16 * speed) / SR))
    rumble = P.lp(P.noise(sec), 160) * 1.5 * (0.3 + 0.7 * speed)
    clicks = np.zeros(len(t)); r = np.random.default_rng(3); pos = 2.6
    while pos < 5.0:
        i = int(pos * SR); c = P.click(.012, r.uniform(2500, 4200)) * r.uniform(.4, 1); clicks[i:i + len(c)] += c[:len(clicks) - i]
        pos += 0.05 + (pos - 2.6) ** 2 * 0.09
    drop = np.zeros(len(t)); i = int(5.0 * SR); c = P.mix((0, P.click(.02, 3000), 1), (.06, P.click(.015, 3600), .6), (.13, P.click(.012, 3300), .35)); drop[i:i + len(c)] += c[:len(drop) - i, 0]
    x = P.mix((0, roll * 0.5, 1), (0, rumble, .5), (0, clicks, .8), (0, drop, 1.1))
    x = x * np.minimum(1, t / 0.15)[:, None]
    P.save('../roulette/sfx/spin', P.hall(x, .9, .15), -2)
    P.save('../roulette/sfx/chip', clay_chips(), -4)
    P.save('../roulette/sfx/chip2', clay_chips(seed=9, n=2), -4)
    win = P.st(P.fsynth(lambda s: (s.prog(0, 11, rev=90, vol=110), s.prog(1, 61, rev=90, vol=100),
                                     [s.note(i * .08, 0, m(n), .9, 100) for i, n in enumerate(['D5', 'F#5', 'A5', 'D6'])], [s.note(.24, 1, m(n), 1.1, 96) for n in ['D4', 'F#4', 'A4']]), 2.0, .7, .5))
    P.save('../roulette/sfx/win', P.hall(P.mix((0, win, 1), (.15, P.lay(((i * .05, P.coinclink(i)) for i in range(10)), 1.0), .25)), 1.3, .22), -2)

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('voice', 'all'): voices()
    if what in ('sfx', 'all'): sfx()
