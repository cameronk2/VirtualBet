import sys; sys.path.insert(0,'/tmp/claude-0/mu'); sys.path.insert(0,'/tmp/claude-0/sfx')
import numpy as np, scipy.io.wavfile as wf
from gongs import gong, hall, save, SR
from cues import ld, place, blank, synth_part, roll, gliss, norm, PENT, m, KOTO,FLUTE,STR,TREM,PIZZ,TAIKO,TIMP,BRASS,CHOIR,CELESTA,GLOCK
HARP=46
# soft landing gongs: small, darker, short
for i,(f,g) in enumerate([(330,0.03),(349,0.025),(392,0.035),(415,0.03),(440,0.025),(494,0.03)]):
    x=gong(f,1.6,partials=28,tilt=1.45,glide=g,glide_tau=0.25,bright=0.7,seed=40+i,strike=0.45,decay=0.45)
    save(f'gong_land_{i+1}', hall(x,1.3,0.16,seed=i,damp=3000))
save('gong_lock', hall(gong(784,0.9,partials=20,tilt=1.6,seed=51,strike=0.3,decay=0.35)*0.7,1.0,0.15,seed=2,damp=3500))
save('gong_reset', hall(gong(523,1.3,partials=24,tilt=1.4,glide=-0.06,glide_tau=0.2,seed=52,strike=0.4,decay=0.45),1.2,0.18,seed=3,damp=3200))
save('gong_soft', hall(gong(98,4.5,partials=80,tilt=0.95,bloom=0.5,bright=0.8,seed=53,strike=0.5,decay=0.9),3.0,0.3,seed=4,damp=3000))
# Hold & Spin opener: soft gong swell, strings, koto run, sparkle. Voice at 1.0s.
def hs(s):
    s.prog(0,KOTO,pan=40,rev=90); s.prog(1,STR,rev=100,vol=90); s.prog(2,CELESTA,rev=90,vol=70)
    for n in ['D3','A3','D4','F#4']: s.note(0,1,m(n),2.6,48)
    for k in range(8): s.cc(k*0.15,1,11,40+k*10)
    gliss(s,0,0.55,PENT[:10],0.05,62)
    for i,n in enumerate(['A5','D6','F#6']): s.note(1.1+i*0.12,2,m(n),0.8,55)
x=blank(3.4); place(x,synth_part(hs,3.4),0,0.7); place(x,ld('gong_soft'),0,0.45); save('cue_holdspin',x)
# Dragon opener: quiet timpani swell, low choir, distant roar, one soft gong. Voice at 1.6s.
def dg(s):
    s.prog(3,CHOIR,rev=110,vol=90); s.prog(7,TIMP,rev=80,vol=90); s.prog(1,TREM,rev=100,vol=80)
    roll(s,7,'A1',0.0,1.4,15,70,0.07)
    for n in ['A2','E3','A3']: s.note(0.2,1,m(n),2.4,45)
    for n in ['A2','E3','A3','C4']: s.note(1.4,3,m(n),2.4,70)
x=blank(4.2); place(x,synth_part(dg,4.2),0,0.75); place(x,ld('roar_dragon'),0.1,0.22); place(x,ld('gong_soft'),1.4,0.4); save('cue_dragon',x)
# LUCK HAS ARRIVED: shimmering tam-tam bloom, harp gliss, choir + celesta, rising strings; voice at 2.0s; resonant gong at 3.4s; warm resolve.
def lk(s):
    s.prog(0,HARP,pan=36,rev=100,vol=100); s.prog(1,STR,rev=110,vol=95); s.prog(2,FLUTE,pan=84,rev=100,vol=90); s.prog(3,CHOIR,rev=120,vol=85); s.prog(5,CELESTA,pan=90,rev=100,vol=80)
    for n in ['D3','A3','D4','F#4','A4']: s.note(0.2,1,m(n),1.9,40)
    for k in range(10): s.cc(0.2+k*0.17,1,11,35+k*9)
    for n in ['D4','F#4','A4']: s.note(0.4,3,m(n),1.7,55)
    gliss(s,0,0.9,PENT[:12],0.07,58)
    for i,n in enumerate(['A5','D6','E6','F#6','A6']): s.note(1.3+i*0.11,5,m(n),0.6,52)
    # resolve after the second gong
    for n in ['D3','A3','D4','F#4','A4','D5']: s.note(3.45,1,m(n),2.8,70); s.note(3.45,3,m(n),2.8,58)
    for i,n in enumerate(['F#5','A5','D6']): s.note(3.5+i*0.18,2,m(n),0.5 if i<2 else 1.8,72)
    gliss(s,0,3.45,PENT,0.04,60)
x=blank(7.0); place(x,synth_part(lk,7.0),0,0.75); place(x,ld('gong_big'),0.0,0.6); place(x,ld('gong_big_2'),3.4,0.45); place(x,ld('gong_lock'),3.42,0.25)
save('cue_luck',x)
def nr(s):
    s.prog(1,TREM,rev=100,vol=80)
    for n in ['A2','E3','A3']: s.note(0,1,m(n),2.0,40)
    for k in range(8): s.cc(k*0.24,1,11,30+k*9)
save('cue_near',norm(synth_part(nr,2.6)))
def cp(s):
    s.prog(0,KOTO,rev=90); s.prog(1,STR,rev=100,vol=95); s.prog(2,FLUTE,rev=100,vol=85)
    for n in ['D4','F#4','A4','D5']: s.note(0,1,m(n),2.2,62)
    gliss(s,0,0,PENT[:9],0.04,60)
    s.note(0.35,2,m('A5'),0.3,65); s.note(0.6,2,m('D6'),1.4,70)
x=blank(3.4); place(x,synth_part(cp,3.4),0,0.8); place(x,ld('gong_soft'),0,0.3); save('cue_complete',x)
def rv_s(s): s.prog(0,CELESTA,rev=80); s.note(0,0,m('A6'),0.4,70)
def rv_m(s): s.prog(0,KOTO,rev=80); [s.note(i*0.03,0,m(n),1.0,70) for i,n in enumerate(['D5','F#5','A5'])]
def rv_b(s): s.prog(0,HARP,rev=90); s.prog(1,STR,rev=100,vol=90); [s.note(i*0.04,0,m(n),1.2,80) for i,n in enumerate(['D5','F#5','A5','D6','F#6'])]; [s.note(0,1,m(n),1.6,60) for n in ['D4','F#4','A4']]
save('reveal_s',synth_part(rv_s,1.0)); save('reveal_m',synth_part(rv_m,1.4)); save('reveal_b',synth_part(rv_b,2.4))
def su(s): s.prog(5,115,rev=50,vol=70); s.note(0,5,m('E5'),0.15,55)
save('spin_use',synth_part(su,0.6))
def hb(s): s.prog(7,TIMP,rev=50,vol=80); s.note(0,7,m('D2'),0.4,70); s.note(0.25,7,m('D2'),0.4,50)
save('spin_last',synth_part(hb,1.0))
