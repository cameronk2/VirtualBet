# Polar Catch – sound package, free tools only:
#   * music: FluidSynth + FluidR3 Mono GM soundfont (MIT)
#       base  – "northern lights": celesta/glockenspiel ostinato, harp, warm strings, horn melody, soft timpani
#       bonus – a jolly sea shanty in 6/8: accordion, fiddle, tin whistle, oom-pah tuba, bodhrán and stamps
#   * effects: numpy synthesis (wheel pegs, line whirr, reel ratchet, splashes, ice) + FluidSynth stingers
#   * host: Kokoro-82M (Apache 2.0), British male "bm_george", pronunciations from Kokoro's own gb dictionary
# Output: client/audio/polarcatch/{music,sfx,voice}/*.mp3
import sys, os, json, subprocess, numpy as np, scipy.io.wavfile as wf
sys.path.insert(0, os.path.dirname(__file__))
from fs import m, SR
import phoenix as P
OUT = os.path.join(os.path.dirname(__file__), '../../client/audio/polarcatch')
TMP = '/tmp/claude-0/pcx'; os.makedirs(TMP, exist_ok=True)
for d in ('music', 'sfx', 'voice'): os.makedirs(f'{OUT}/{d}', exist_ok=True)
S = lambda name, x, db=-1.5, kb=None: P.save(f'../polarcatch/{name}', x, db, kb)
GM = lambda fn, sec, room=.75, level=.55: P.st(P.fsynth(fn, sec, room, level))
CELESTA, GLOCK, MUSICBOX, HARP, STR, SLOWSTR, PIZZ, HORN, TIMP, CHOIR, FLUTE = 8, 9, 10, 46, 48, 49, 45, 60, 47, 52, 73
ACCORD, FIDDLE, WHISTLE, TUBA, BANJO, DRUMS, MARIMBA, BRASS = 21, 40, 78, 58, 105, 9, 12, 61

# ── music ───────────────────────────────────────────────────────
def base_music():
    bpm = 92; beat = 60 / bpm; bars = 32; sec = bars * 4 * beat
    prog = [('D3', [0, 4, 7, 11]), ('B2', [0, 3, 7, 10]), ('G2', [0, 4, 7, 14]), ('A2', [0, 5, 7, 14])] * 2 + \
           [('G2', [0, 4, 7, 11]), ('A2', [0, 4, 7, 10]), ('F#2', [0, 3, 7, 10]), ('B2', [0, 3, 7, 10]), ('G2', [0, 4, 7, 11]), ('E2', [0, 3, 7, 10]), ('A2', [0, 5, 7, 14]), ('A2', [0, 4, 7, 10])]
    def f(s):
        s.prog(0, SLOWSTR, rev=100, vol=74); s.prog(1, HARP, rev=95, vol=80, pan=40); s.prog(2, CELESTA, rev=100, vol=70, pan=86); s.prog(3, HORN, rev=100, vol=84, pan=58)
        s.prog(4, TIMP, rev=80, vol=66); s.prog(5, PIZZ, rev=70, vol=72, pan=30); s.prog(6, GLOCK, rev=100, vol=54, pan=96); s.prog(7, FLUTE, rev=100, vol=70, pan=70); s.prog(8, CHOIR, rev=110, vol=56)
        for b in range(bars):
            root, iv = prog[b % len(prog)]; t0 = b * 4 * beat; r = m(root)
            for o in iv[:3]: s.note(t0, 0, r + 12 + o, 4 * beat * .98, 52)
            if b >= 8: s.note(t0, 8, r + 24, 4 * beat, 40); s.note(t0, 8, r + 24 + iv[2], 4 * beat, 36)
            s.note(t0, 5, r, beat * .5, 70); s.note(t0 + 2 * beat, 5, r + 7, beat * .5, 58)
            arp = [r + 24 + iv[0], r + 24 + iv[1], r + 24 + iv[2], r + 36 + iv[0], r + 24 + iv[3], r + 24 + iv[2], r + 24 + iv[1], r + 24 + iv[2]]
            for i, n in enumerate(arp): s.note(t0 + i * beat / 2, 2, n, beat * .8, 56 + (10 if i % 4 == 0 else 0))
            for i in (0, 3, 5): s.note(t0 + i * beat / 2, 1, r + 12 + iv[i % 3], beat * 1.5, 52)
            if b % 4 == 3: s.note(t0 + 3 * beat, 4, m('D2'), .6, 54); s.note(t0 + 3.5 * beat, 4, m('A1'), .6, 62)
            if b % 2 == 0: s.note(t0 + 3 * beat, 6, r + 48 + iv[1], 1.5, 40)
        mel = [('F#4', 2), ('A4', 1), ('D5', 1), ('C#5', 2), ('B4', 2), ('A4', 3), ('F#4', 1), ('G4', 4),
               ('E4', 2), ('G4', 1), ('B4', 1), ('A4', 2), ('F#4', 2), ('E4', 6), ('-', 2),
               ('F#4', 2), ('A4', 1), ('D5', 1), ('E5', 2), ('F#5', 2), ('E5', 3), ('D5', 1), ('B4', 4),
               ('G4', 2), ('B4', 1), ('D5', 1), ('C#5', 2), ('A4', 2), ('D5', 6), ('-', 2)]
        for rep, ch in ((0, 3), (1, 7)):
            t = (8 + rep * 16) * 4 * beat
            for n, d in mel:
                if n != '-': s.note(t, ch, m(n) - (12 if ch == 3 else 0), d * beat * .95, 74)
                t += d * beat
    x = GM(f, sec + 3, .85, .55)
    wind = P.st(P.lp(P.noise(sec + 3), 500)) * .012 * (1 + .5 * np.sin(2 * np.pi * .07 * P.T(sec + 3)))[:, None]
    n = min(len(x), len(wind))
    S('music/base', x[:n] + wind[:n], -3, 72)

def bonus_music():
    # 6/8 shanty: a bar = 6 eighths; ~ 116 dotted-quarter bpm feel
    q = 60 / 116 / 3 * 2   # one eighth
    bars = 32; sec = bars * 6 * q
    prog = ['D', 'D', 'G', 'D', 'D', 'D', 'A', 'A', 'D', 'D', 'G', 'D', 'G', 'A', 'D', 'D']
    tri = {'D': [m('D3'), m('F#3'), m('A3')], 'G': [m('G2'), m('B2'), m('D3')], 'A': [m('A2'), m('C#3'), m('E3')]}
    tune = [('A4', 2), ('A4', 1), ('A4', 2), ('B4', 1), ('A4', 2), ('F#4', 1), ('D4', 3), ('E4', 2), ('F#4', 1), ('G4', 2), ('E4', 1), ('F#4', 3), ('D4', 3),
            ('A4', 2), ('A4', 1), ('A4', 2), ('B4', 1), ('A4', 2), ('F#4', 1), ('D5', 3), ('C#5', 2), ('B4', 1), ('A4', 2), ('G4', 1), ('F#4', 3), ('E4', 3),
            ('B4', 2), ('B4', 1), ('B4', 2), ('C#5', 1), ('D5', 2), ('B4', 1), ('A4', 3), ('G4', 2), ('B4', 1), ('A4', 2), ('F#4', 1), ('E4', 3), ('A4', 3),
            ('A4', 2), ('A4', 1), ('A4', 2), ('B4', 1), ('A4', 2), ('F#4', 1), ('D5', 3), ('E5', 2), ('C#5', 1), ('A4', 2), ('E4', 1), ('D4', 6)]
    def f(s):
        s.prog(0, ACCORD, rev=50, vol=80, pan=48); s.prog(1, FIDDLE, rev=60, vol=92, pan=74); s.prog(2, WHISTLE, rev=60, vol=86, pan=60); s.prog(3, TUBA, rev=40, vol=104)
        s.prog(4, BANJO, rev=40, vol=70, pan=30); s.prog(5, GLOCK, rev=80, vol=50, pan=96)
        for b in range(bars):
            c = prog[b % 16]; t0 = b * 6 * q; tr = tri[c]
            s.note(t0, 3, tr[0] - 12, q * 1.6, 100); s.note(t0 + 3 * q, 3, tr[2] - 12, q * 1.6, 88)         # oom ... pah
            for k in (1, 2, 4, 5):
                for n in tr: s.note(t0 + k * q, 0, n + 12, q * .8, 58 + (6 if k in (1, 4) else 0))          # accordion off-beats
            for k in range(6): s.note(t0 + k * q, 4, tr[k % 3] + 12, q * .6, 46 + (14 if k % 3 == 0 else 0))  # banjo strum
            # bodhrán and stamps
            s.note(t0, DRUMS, 36, .1, 96); s.note(t0 + 3 * q, DRUMS, 36, .1, 84); s.note(t0 + 2 * q, DRUMS, 41, .1, 50); s.note(t0 + 5 * q, DRUMS, 41, .1, 56)
            s.note(t0 + 3 * q, DRUMS, 39, .1, 70)
            if b % 4 == 3: s.note(t0 + 5 * q, DRUMS, 54, .2, 70)
        for rep, ch in ((0, 2), (1, 1)):
            t = rep * 16 * 6 * q
            for n, d in tune:
                s.note(t, ch, m(n) + (0 if ch == 2 else -12 if rep == 0 else 0), d * q * .92, 92); t += d * q
        for b in range(0, bars, 2): s.note(b * 6 * q + 5 * q, 5, m('D6') + [0, 4, 7][b // 2 % 3], .3, 60)
    x = GM(f, sec + 2, .55, .5)
    S('music/bonus', x[:int((sec + 1.2) * SR)], -2, 72)

def stings():
    win = GM(lambda s: (s.prog(0, BRASS, rev=90, vol=118), s.prog(1, GLOCK, rev=90, vol=100), s.prog(2, STR, rev=100, vol=96),
                        [s.note(i * .1, 0, m(n), .3 if i < 3 else 1.4, 108) for i, n in enumerate(['D4', 'F#4', 'A4', 'D5'])],
                        [s.note(.3 + i * .06, 1, m(n), .9, 96) for i, n in enumerate(['A5', 'D6', 'F#6', 'A6', 'D7'])],
                        [s.note(.3, 2, m(n), 1.8, 90) for n in ['D3', 'A3', 'F#4', 'A4']]), 3.2)
    S('music/win', P.fadeout(P.hall(P.mix((0, win, 1), (.3, P.sparkle(1.4, 22, 3000, 9000, 31), .3)), 1.6, .25), .3), -2, 96)
    jp = GM(lambda s: (s.prog(0, BRASS, rev=90, vol=124), s.prog(1, STR, rev=100, vol=110), s.prog(2, CHOIR, rev=110, vol=100), s.prog(3, TIMP, rev=80, vol=118), s.prog(4, GLOCK, rev=90, vol=100),
                       [s.note(t, 0, m(n), d, 112) for n, t, d in [('D4', 0, .25), ('F#4', .25, .25), ('A4', .5, .25), ('D5', .75, 1.0), ('B4', 1.75, .25), ('C#5', 2.0, .25), ('D5', 2.25, 2.6)]],
                       [s.note(.75, 1, m(n), 1.0, 100) for n in ['D3', 'A3', 'F#4']], [s.note(2.25, 1, m(n), 2.6, 108) for n in ['D3', 'A3', 'D4', 'F#4', 'A4']],
                       [s.note(2.25, 2, m(n), 2.6, 100) for n in ['D4', 'F#4', 'A4']], [s.note(1.5 + k * .05, 3, m('D2'), .08, 50 + k * 5) for k in range(15)], s.note(2.25, 3, m('D2'), 1, 127),
                       [s.note(2.25 + k * .06, 4, m('D6') + [0, 4, 7, 12][k % 4], .6, 92) for k in range(12)]), 5.6)
    S('music/jackpot', P.fadeout(P.hall(P.mix((0, jp, 1), (2.25, P.sparkle(2.4, 36, 2500, 9000, 33), .3)), 2.0, .25), .4), -1.5, 96)

# ── effects ─────────────────────────────────────────────────────
def splash(sec=.9, size=1.0, seed=0):
    r = np.random.default_rng(seed); n = int(sec * SR); t = np.arange(n) / SR
    body = P.lp(r.standard_normal(n), 2500 * size ** -.3) * np.exp(-t / (.12 * size)) * 1.4
    hiss = P.bp(r.standard_normal(n), 2500, 9000) * np.exp(-t / (.25 * size)) * .6
    drops = P.lay(((r.uniform(.05, sec * .8), P.chime([r.uniform(900, 2200)], .12, .03) * r.uniform(.1, .3)) for _ in range(int(14 * size))), sec)
    thump = P.thump(70 + 40 / size, .4, .8) * .8
    return P.mix((0, body, 1), (0, hiss, 1), (0, drops, 1), (0, thump, 1), sec=sec)
def sfx():
    peg = P.mix((0, P.click(.008, 3200), 1), (0, P.bp(P.noise(.03), 1500, 3500) * P.env(int(.03 * SR), .001, tau=.006), .6))
    S('sfx/peg', peg, -6)
    S('sfx/spin', P.hall(P.mix((0, P.whoosh(.8, 300, 2000, 41, 2.5), .8), (0, P.thump(60, .3, .6), .4)), .8, .2), -4)
    lit = GM(lambda s: (s.prog(0, GLOCK, rev=100, vol=110), s.prog(1, CELESTA, rev=100, vol=100), s.note(0, 0, m('A6'), .6, 100), s.note(.06, 1, m('E6'), .6, 90)), 1.0)
    S('sfx/lit', P.hall(P.mix((0, lit, 1), (0, P.sparkle(.4, 6, 4000, 9000, 42), .3)), .9, .25), -4)
    bmult = GM(lambda s: (s.prog(0, BRASS, rev=90, vol=110), s.prog(1, GLOCK, rev=90), [s.note(0, 0, m(n), .5, 100) for n in ['D4', 'A4', 'D5']], [s.note(k * .05, 1, m(n), .6, 96) for k, n in enumerate(['D6', 'F#6', 'A6'])]), 1.2)
    S('sfx/bmult', P.hall(P.mix((0, P.whoosh(.4, 600, 5000, 43, 2), .4), (.3, bmult, 1)), 1.1, .25), -3)
    crack = P.lay(((t, P.click(.02, f) * a) for t, f, a in [(0, 2200, 1), (.05, 1600, .8), (.09, 2800, .6), (.16, 1300, .5), (.24, 1900, .4)]), .5)
    land = GM(lambda s: (s.prog(0, BRASS, rev=100, vol=120), s.prog(1, STR, rev=100, vol=110), s.prog(2, TIMP, rev=80, vol=120), s.prog(3, GLOCK, rev=90, vol=96),
                         [s.note(.25 + i * .12, 0, m(n), .35 if i < 2 else 1.3, 112) for i, n in enumerate(['A3', 'D4', 'F#4'])], [s.note(.49, 1, m(n), 1.5, 100) for n in ['D3', 'A3', 'D4', 'F#4']],
                         [s.note(k * .04, 2, m('D2'), .06, 50 + k * 6) for k in range(10)], s.note(.49, 2, m('D2'), .8, 127), [s.note(.49 + k * .05, 3, m(n), .7, 90) for k, n in enumerate(['D6', 'F#6', 'A6', 'D7'])]), 2.4)
    S('sfx/bonus', P.hall(P.mix((0, crack, 1), (0, P.thump(55, .6, 1), .6), (.05, land, 1)), 1.8, .25), -1.5)
    # fishing
    zip_ = P.bp(P.noise(.7), 2500, 7000) * np.linspace(1, .2, int(.7 * SR)) * (0.6 + .4 * np.sin(2 * np.pi * np.cumsum(np.linspace(90, 30, int(.7 * SR))) / SR))
    S('sfx/cast', P.hall(P.mix((0, P.whoosh(.45, 400, 3000, 44, 2), .9), (.15, zip_, .5)), .8, .2), -3)
    plop = P.mix((0, P.thump(260, .25, 1.5), .7), (0, P.lp(P.noise(.2), 1800) * P.env(int(.2 * SR), .002, tau=.04), .6), (.03, P.chime([1100], .2, .05), .25))
    S('sfx/plop', P.hall(plop, .7, .2), -4)
    bubbles = P.lay(((t, P.chime([f], .1, .03) * a) for t, f, a in [(0, 700, .5), (.07, 950, .4), (.12, 820, .45), (.2, 1150, .35), (.26, 1000, .3)]), .5)
    tug = P.mix((0, P.thump(120, .3, 1), .7), (.02, P.lp(P.noise(.3), 1200) * P.env(int(.3 * SR), .002, tau=.06), .5), (.05, bubbles, .8))
    S('sfx/bite', P.hall(tug, .6, .2), -4)
    # reel ratchet: rapid clicks with a whirring drag (played in a loop while the fish fights)
    sec = 1.0; clicks = P.lay(((i / 38, P.click(.006, 2600 + 400 * (i % 3)) * (.7 + .3 * (i % 2))) for i in range(38)), sec)
    whirr = P.st(P.bp(P.noise(sec), 400, 1400) * .25 * (0.7 + .3 * np.sin(2 * np.pi * 38 * P.T(sec))))
    S('sfx/reel', P.mix((0, clicks, .9), (0, whirr, 1), sec=sec), -6)
    strain = P.mix((0, P.bp(P.noise(.6), 180, 600) * np.sin(np.pi * np.linspace(0, 1, int(.6 * SR))) ** 2 * 2, 1), (0, P.thump(90, .5, .2) * .3, 1))
    S('sfx/strain', strain, -8)
    for k, size in (('splash_s', .7), ('splash_m', 1.0), ('splash_l', 1.5)): S(f'sfx/{k}', P.hall(splash(1.0 + size * .3, size, int(size * 10)), 1.0, .2), -2)
    flop = P.mix((0, P.thump(110, .25, .5), 1), (.02, P.lp(P.noise(.12), 900) * P.env(int(.12 * SR), .002, tau=.03), .6), (.18, P.thump(130, .15, .5), .5), (.3, P.thump(140, .1, .5), .3))
    S('sfx/flop', flop, -5)
    for k, notes in (('catch_s', ['D6', 'A6']), ('catch_m', ['D5', 'F#5', 'A5', 'D6']), ('catch_l', ['A4', 'D5', 'F#5', 'A5', 'D6', 'F#6'])):
        c = GM(lambda s, notes=notes: (s.prog(0, GLOCK, rev=100, vol=110), s.prog(1, MARIMBA, rev=90, vol=100), [s.note(i * .06, 0, m(n), .7, 104) for i, n in enumerate(notes)], [s.note(i * .06, 1, m(n) - 12, .5, 90) for i, n in enumerate(notes)]), 1.6)
        S(f'sfx/{k}', P.hall(P.mix((0, c, 1), (.05, P.sparkle(.6 + .3 * len(notes) / 6, 4 * len(notes), 3500, 9000, len(notes)), .3)), 1.2, .25), -3)
    tally = P.lay(((i * .045, P.coinclink(i + 50) * (.6 + .4 * (i % 2))) for i in range(12)), .9)
    S('sfx/tally', P.hall(tally, .6, .15), -6)
    mult = GM(lambda s: (s.prog(0, BRASS, rev=100, vol=120), s.prog(1, CHOIR, rev=110, vol=100), [s.note(0, 0, m(n), 1.0, 116) for n in ['D4', 'F#4', 'A4', 'D5']], [s.note(.1, 1, m(n), 1.2, 96) for n in ['D4', 'A4', 'D5']]), 2.0)
    S('sfx/mult', P.hall(P.mix((0, P.whoosh(.5, 300, 4000, 45, 2), .5), (.4, mult, 1), (.4, P.thump(50, .6, 1), .5)), 1.6, .3), -2)

# ── host ────────────────────────────────────────────────────────
def voices(voice='bm_george'):
    import onnxruntime as ort
    cfg = json.load(open('/tmp/claude-0/ko/src/kokoro_onnx/config.json')); vocab = cfg['vocab']
    sess = ort.InferenceSession('/tmp/claude-0/kk/kokoro-v1.0.int8.onnx'); vs = np.load('/tmp/claude-0/kk/voices-v1.0.bin')
    tk = 'input_ids' if 'input_ids' in {i.name for i in sess.get_inputs()} else 'tokens'
    # spellings from Kokoro's British dictionary (misaki gb_gold.json)
    L = {'minnow': 'fɹˈɒst mˈɪnQz!', 'salmon': 'ˈambə sˈamən!', 'king': 'ɹˈuːbi kˈɪŋz!', 'bonus': 'bˈQnəs tˈIm!', 'fishon': 'fˈɪʃ ɒn!',
         'catch': 'wˌɒt ə kˈaʧ!', 'monster': 'mˈɒnstə kˈaʧ!', 'last': 'lˈɑːst kˈɑːst!', 'big': 'bˈɪɡ fˈɪʃ!'}
    for k, ph in L.items():
        assert all(c in vocab for c in ph), k
        toks = [vocab[c] for c in ph]
        a = sess.run(None, {tk: np.array([[0, *toks, 0]], dtype=np.int64), 'style': vs[voice][len(toks)].astype(np.float32), 'speed': np.array([1.0], dtype=np.float32)})[0].reshape(-1)
        a = a / (np.abs(a).max() + 1e-9)
        raw = f'{TMP}/{k}.wav'; wf.write(raw, 24000, a.astype(np.float32))
        af = ('silenceremove=start_periods=1:start_threshold=-45dB:stop_periods=1:stop_threshold=-45dB:stop_duration=0.2,aresample=44100,highpass=f=70,'
              'equalizer=f=160:t=q:w=1:g=2,equalizer=f=3200:t=q:w=1.2:g=3,acompressor=threshold=-20dB:ratio=3:attack=4:release=120,volume=12dB,alimiter=limit=0.9')
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '1', '-codec:a', 'libmp3lame', '-b:a', '64k', f'{OUT}/voice/{k}.mp3'], check=True)
    print('voice lines', len(L))

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('music', 'all'): base_music(); bonus_music(); stings()
    if what in ('sfx', 'all'): sfx()
    if what in ('voice', 'all'): voices()
