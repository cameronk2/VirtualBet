# Horse racing sound package, free tools only:
#   * commentary: Kokoro-82M (Apache 2.0), British male "bm_george", spellings from Kokoro's own British
#     dictionary (misaki gb_gold / gb_silver), every horse name recorded once (240 names)
#   * crowd: dozens of Kokoro voices murmuring and shouting, layered and placed in a reverberant space
#   * hooves, gates, bell, shutter, fanfare, interface: numpy synthesis + FluidSynth (FluidR3 Mono, MIT)
# Output: client/audio/racing/{voice,voice/horse,sfx,ui}/*.mp3
import sys, os, re, json, subprocess, numpy as np, scipy.io.wavfile as wf
sys.path.insert(0, os.path.dirname(__file__))
from fs import m, SR
import phoenix as P
OUT = os.path.join(os.path.dirname(__file__), '../../client/audio/racing')
TMP = '/tmp/claude-0/rcx'; os.makedirs(TMP, exist_ok=True)
for d in ('voice', 'voice/horse', 'sfx', 'ui'): os.makedirs(f'{OUT}/{d}', exist_ok=True)
S = lambda name, x, db=-1.5, kb=None: P.save(f'../racing/{name}', x, db, kb)
GM = lambda fn, sec, room=.75, level=.55: P.st(P.fsynth(fn, sec, room, level))

# ── pronunciation ───────────────────────────────────────────────
GOLD = json.load(open('/tmp/claude-0/misaki/misaki/data/gb_gold.json'))
SILVER = json.load(open('/tmp/claude-0/misaki/misaki/data/gb_silver.json'))
EXTRA = {  # names not in the dictionary, spelt in its style
    'bramblewick': 'bɹˈambᵊlwɪk', 'copperfield': 'kˈɒpəfiːld', 'corrigan': 'kˈɒɹɪɡən', 'dashwood': 'dˈaʃwʊd', 'dunmore': 'dʌnmˈɔː',
    'ellwand': 'ˈɛlwɒnd', 'fennimore': 'fˈɛnɪmɔː', "fiddler's": 'fˈɪdləz', 'glenfinnan': 'ɡlɛnfˈɪnən', 'inchcape': 'ˈɪnʧkAp',
    'oakhurst': 'ˈQkhɜːst', 'pennywhistle': 'pˈɛniwɪsᵊl', 'riverrun': 'ɹˈɪvəɹʌn', 'umberleigh': 'ˈʌmbəli', 'wychwood': 'wˈɪʧwʊd', 'zephyrine': 'zˈɛfəɹiːn',
    "they're": 'ðˈɛː', "starters'": 'stˈɑːtəz', "it's": 'ɪts',
}
def word(w):
    k = w.lower()
    if k in EXTRA: return EXTRA[k]
    for d in (GOLD, SILVER):
        for kk in (w, k, w.capitalize()):
            if kk in d:
                v = d[kk]; return v if isinstance(v, str) else (v.get('DEFAULT') or next(iter(v.values())))
    raise KeyError(w)
def phon(text):
    out = []
    for tok in re.findall(r"[A-Za-z']+|[,.!?]", text):
        if tok in ',.!?': out.append(tok)
        else: out.append((' ' if out and out[-1] not in ('',) else '') + word(tok))
    return ''.join(out).strip()

# ── Kokoro ──────────────────────────────────────────────────────
_k = {}
def kokoro():
    if not _k:
        import onnxruntime as ort
        _k['vocab'] = json.load(open('/tmp/claude-0/ko/src/kokoro_onnx/config.json'))['vocab']
        _k['sess'] = ort.InferenceSession('/tmp/claude-0/kk/kokoro-v1.0.int8.onnx'); _k['vs'] = np.load('/tmp/claude-0/kk/voices-v1.0.bin')
        _k['tk'] = 'input_ids' if 'input_ids' in {i.name for i in _k['sess'].get_inputs()} else 'tokens'
    return _k
def tts(ph, voice='bm_george', speed=1.0, blend=None):
    k = kokoro(); v = k['vocab']
    toks = [v[c] for c in ph if c in v]
    style = k['vs'][voice][len(toks)]
    if blend: style = style * (1 - blend[1]) + k['vs'][blend[0]][len(toks)] * blend[1]
    a = k['sess'].run(None, {k['tk']: np.array([[0, *toks, 0]], dtype=np.int64), 'style': style.astype(np.float32), 'speed': np.array([speed], dtype=np.float32)})[0].reshape(-1)
    return a / (np.abs(a).max() + 1e-9)
def save_voice(path, a, excited=False):
    raw = f'{TMP}/{os.path.basename(path)}.wav'; wf.write(raw, 24000, a.astype(np.float32))
    # broadcast commentary: present, bright, compressed; no pitch shifting or echo (they blur the words)
    af = ('silenceremove=start_periods=1:start_threshold=-45dB:stop_periods=1:stop_threshold=-45dB:stop_duration=0.15,aresample=44100,highpass=f=90,'
          f'equalizer=f=180:t=q:w=1:g=1.5,equalizer=f=2800:t=q:w=1.2:g={4 if excited else 3},equalizer=f=7000:t=q:w=1:g=1,'
          'acompressor=threshold=-24dB:ratio=4:attack=3:release=90,volume=13dB,alimiter=limit=0.92')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '1', '-codec:a', 'libmp3lame', '-b:a', '48k', f'{OUT}/{path}.mp3'], check=True)

LINES = {
    'orders': ("They're under starters' orders.", False), 'off': ('And they are off!', True), 'leads': ('is in front!', True),
    'halfway': ('At halfway, the leader is', False), '2f': ('Two furlongs to run!', True), '1f': ('Inside the final furlong!', True),
    'photo': ("It's a photo finish!", True), 'wins': ('wins it!', True), 'close': ('It is very close!', True),
}
def voices(names_file='/tmp/claude-0/names.json'):
    for k, (text, ex) in LINES.items(): save_voice(f'voice/{k}', tts(phon(text), speed=1.08 if ex else 1.0), ex)
    names = json.load(open(names_file))
    for i, (hid, name) in enumerate(names):
        save_voice(f'voice/horse/h{hid}', tts(phon(name + '!'), speed=1.05), True)
        if i % 40 == 0: print('names', i)
    print('voice done', len(LINES), '+', len(names))

# ── crowd ───────────────────────────────────────────────────────
MURMUR = ['what a lovely day for it', 'I fancy the grey', 'have you got the next', 'two pounds each way', 'look at the going', 'she ran well last time', 'shall we get a drink', 'that one looks lively',
          'where are we standing', 'I like the number four', 'the favourite is drifting', 'he has a good draw', 'see you at the rail', 'it should be a good race', 'what odds did you get', 'come and see the horses']
SHOUTS = ['come on!', 'go on!', 'yes!', 'come on my son!', 'go on go on!', 'keep going!', 'come on four!', 'go on then!', 'push!', 'yes yes yes!']
CROWD_VOICES = ['bm_george', 'bm_lewis', 'bm_daniel', 'bm_fable', 'bf_emma', 'bf_isabella', 'bf_alice', 'bf_lily', 'am_adam', 'am_michael', 'am_eric', 'am_liam', 'af_bella', 'af_sarah', 'af_nicole', 'af_jessica']
def to44(a):
    from scipy.signal import resample_poly
    return resample_poly(a, 147, 80)  # 24 kHz → 44.1 kHz
def crowd_layer(phrases, sec, n, seed, gain=(0.15, 0.4), speed=(0.95, 1.15), lp=3200):
    r = np.random.default_rng(seed); out = np.zeros((int(sec * SR), 2))
    for i in range(n):
        ph = phon(phrases[r.integers(len(phrases))].replace('!', '') + ('!' if '!' in phrases[0] else '.'))
        a = to44(tts(ph, CROWD_VOICES[r.integers(len(CROWD_VOICES))], float(r.uniform(*speed))))
        a = P.lp(a, lp) * r.uniform(*gain)
        t = int(r.uniform(0, sec) * SR); pan = r.uniform(-0.8, 0.8)
        st = np.stack([a * np.sqrt((1 - pan) / 2), a * np.sqrt((1 + pan) / 2)], 1)
        # wrap around so the loop has no seam
        idx = (np.arange(len(st)) + t) % len(out); np.add.at(out, idx, st)
    return out
def loopify(x, xf=0.6):
    n = int(xf * SR); y = x[:-n].copy(); y[:n] = y[:n] * np.linspace(0, 1, n)[:, None] + x[-n:] * np.linspace(1, 0, n)[:, None]; return y

# ── sounds ──────────────────────────────────────────────────────
def hoof(seed, bright=1.0):
    r = np.random.default_rng(seed); n = int(0.12 * SR); t = np.arange(n) / SR
    thud = np.sin(2 * np.pi * r.uniform(70, 95) * t * (1 - t * 2)) * np.exp(-t / 0.03)
    turf = P.bp(r.standard_normal(n), 300 * bright, 2400 * bright) * np.exp(-t / 0.018) * 0.7
    clods = P.bp(r.standard_normal(n), 2000, 6000) * np.exp(-t / 0.05) * 0.12
    return thud + turf + clods
def gallop_loop(sec=4.0, horses=10, stride=0.42, seed=5):
    """A field of horses galloping: each horse's four-beat gallop at its own phase, with snorts of breath."""
    r = np.random.default_rng(seed); out = np.zeros((int(sec * SR), 2))
    for hz in range(horses):
        ph = r.uniform(0, stride); pan = r.uniform(-0.7, 0.7); g = r.uniform(0.4, 1.0); sp = stride * r.uniform(0.97, 1.03)
        offs = [0, 0.09, 0.2, 0.27]  # rotary gallop footfalls within a stride
        t = ph
        while t < sec:
            for k, o in enumerate(offs):
                tt = t + o + r.normal(0, 0.004)
                if tt >= sec: continue
                h = hoof(hz * 100 + k * 7 + int(t * 50), r.uniform(0.85, 1.15)) * g * (1.0 if k in (0, 3) else 0.8)
                i = int(tt * SR); idx = (np.arange(len(h)) + i) % len(out)
                np.add.at(out, idx, np.stack([h * np.sqrt((1 - pan) / 2), h * np.sqrt((1 + pan) / 2)], 1))
            # a breath every stride
            br = P.bp(r.standard_normal(int(0.16 * SR)), 300, 1800) * np.hanning(int(0.16 * SR)) * 0.08 * g
            i = int((t + 0.3) * SR) % len(out); idx = (np.arange(len(br)) + i) % len(out); np.add.at(out, idx, np.stack([br, br], 1))
            t += sp
    rumble = P.st(P.lp(P.noise(sec), 120)) * 0.4
    return P.hall(out + rumble[:len(out)], 0.6, 0.12)
def sfx():
    # crowd bed: murmuring voices in a big space, plus soft room tone
    bed = crowd_layer(MURMUR, 14, 70, 1, (0.08, 0.22), (0.95, 1.1), 2600)
    tone = P.st(P.lp(P.noise(14), 500)) * 0.05
    S('sfx/crowd', loopify(P.hall(bed + tone, 1.6, 0.4)), -8, 64)
    # roar: many voices shouting, rising and falling, loopable
    roar = crowd_layer(SHOUTS, 8, 90, 2, (0.2, 0.5), (1.0, 1.2), 3800) + P.st(P.bp(P.noise(8), 300, 2500)) * 0.12
    S('sfx/roar', loopify(P.hall(roar, 1.4, 0.35)), -4, 64)
    for k, (n, sec, seed) in {'cheer1': (40, 3.2, 3), 'cheer2': (90, 5.0, 4)}.items():
        c = crowd_layer(SHOUTS, sec, n, seed, (0.25, 0.6), (1.0, 1.2), 4200)
        env = np.minimum(1, np.linspace(0, sec, len(c)) / 0.25) * np.exp(-np.maximum(0, np.linspace(0, sec, len(c)) - sec * 0.5) / (sec * 0.25))
        S(f'sfx/{k}', P.hall(c * env[:, None] + P.st(P.bp(P.noise(sec), 400, 3000)) * 0.1 * env[:, None], 1.4, 0.3), -2, 64)
    gasp = crowd_layer(['oh!', 'ooh!', 'oh no!'], 1.6, 40, 6, (0.2, 0.5), (0.9, 1.0), 3000)
    S('sfx/gasp', P.fadeout(P.hall(gasp, 1.2, 0.3), 0.4), -4, 64)
    claps = P.lay(((np.random.default_rng(i).uniform(0, 3.5), P.st(P.bp(P.noise(0.03), 900, 5000) * np.exp(-np.arange(int(0.03 * SR)) / SR / 0.006)) * np.random.default_rng(i + 9).uniform(0.2, 1)) for i in range(600)), 4.0)
    S('sfx/applause', P.fadeout(P.hall(claps, 1.2, 0.3), 1.0), -4, 64)
    S('sfx/gallop', gallop_loop(), -5, 64)
    # stalls opening: a heavy metallic crash of the gates springing back
    sec = 1.4; t = P.T(sec)
    crash = sum(np.sin(2 * np.pi * f * t) * np.exp(-t / d) * a for f, d, a in [(310, 0.25, 1), (537, 0.18, .6), (812, 0.12, .4), (1290, 0.08, .25), (1980, 0.05, .2)])
    gates = P.mix((0, P.st(crash), 0.6), (0, P.st(P.bp(P.noise(sec), 800, 6000) * np.exp(-t / 0.08)), 0.7), (0.01, P.thump(60, 0.4, 0.6), 0.6))
    S('sfx/gates', P.hall(gates, 1.0, 0.25), -2)
    bell = GM(lambda s: (s.prog(0, 14, rev=90, vol=120), [s.note(i * 0.12, 0, m('C6'), 0.1, 110) for i in range(10)]), 2.4)
    S('sfx/bell', bell, -3)
    shutter = P.mix((0, P.st(P.click(0.012, 3000)), 1), (0.05, P.st(P.click(0.01, 2400)), 0.7), (0.06, P.st(P.bp(P.noise(0.08), 1500, 6000) * np.exp(-np.arange(int(0.08 * SR)) / SR / 0.02)), 0.4))
    S('sfx/photo', shutter, -6)
    fan = GM(lambda s: (s.prog(0, 56, rev=80, vol=120), s.prog(1, 61, rev=80, vol=110), s.prog(2, 47, rev=60, vol=110),
                        [s.note(t, 0, m(n), d, 115) for n, t, d in [('G4', 0, .14), ('C5', .15, .14), ('E5', .3, .14), ('G5', .45, .45), ('E5', .9, .14), ('G5', 1.05, 1.0)]],
                        [s.note(.45, 1, m(n), 1.6, 100) for n in ['C4', 'E4', 'G4']], s.note(.45, 2, m('C2'), .4, 120), s.note(1.05, 2, m('C2'), .6, 127)), 3.0)
    S('sfx/fanfare', P.hall(fan, 1.4, 0.25), -2)
    conf = GM(lambda s: (s.prog(0, 11, rev=80, vol=110), [s.note(i * .07, 0, m(n), .6, 100) for i, n in enumerate(['G5', 'C6', 'E6'])]), 1.2)
    S('sfx/confirm', P.hall(conf, .8, .2), -6)
    S('ui/confirm', P.hall(P.mix((0, P.st(P.coinclink(3)), .8), (.05, P.st(P.coinclink(7)), .6)), .6, .2), -8)
    S('ui/select', P.st(P.mix((0, P.click(0.02, 2600), 1), (0, P.bp(P.noise(0.04), 1200, 3000) * np.exp(-np.arange(int(.04 * SR)) / SR / .008), .4))), -10)

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('voice', 'all'): voices()
    if what in ('sfx', 'all'): sfx()
