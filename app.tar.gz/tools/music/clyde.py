# Clyde Blackjack sound package, free tools only:
#   * dealer voice: Piper "en_GB-alba-medium" (CC-BY 4.0, trained on the VCTK corpus: a Scottish
#     speaker), run with onnxruntime. Spellings come from Kokoro's British dictionary (misaki) and are
#     nudged towards Scottish speech: rhotic r, pure "ay"/"oh" vowels. All lines in ONE sprite.
#   * effects: numpy synthesis (card slide, flip, chips, shuffle, tap, room) in ONE sprite
#   * music: FluidSynth + FluidR3 Mono GM soundfont (MIT): a quiet lounge loop with piano and brushes
# Output: client/audio/clyde/{music/base.mp3, sfx.mp3, voice.mp3} and client/src/pages/clyde/sprites.js
import sys, os, re, json, subprocess, numpy as np, scipy.io.wavfile as wf
sys.path.insert(0, os.path.dirname(__file__))
from fs import m, SR
import phoenix as P
import racing as R
HERE = os.path.dirname(__file__)
OUT = os.path.join(HERE, '../../client/audio/clyde')
SPRITES = os.path.join(HERE, '../../client/src/pages/clyde/sprites.js')
TMP = '/tmp/claude-0/clx'; os.makedirs(TMP, exist_ok=True)
os.makedirs(f'{OUT}/music', exist_ok=True)
ALBA = '/tmp/claude-0/alba/en_GB-alba-medium.onnx'
GM = lambda fn, sec, room=.6, level=.45: P.st(P.fsynth(fn, sec, room, level))
DRUMS = 9

def save_mp3(path, x, peak_db=-1.0, kbps=96):
    x = P.st(x); x = x / (np.abs(x).max() + 1e-9) * 10 ** (peak_db / 20)
    w = f'{TMP}/{os.path.basename(path)}.wav'; wf.write(w, SR, x.astype(np.float32))
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', w, '-codec:a', 'libmp3lame', '-b:a', f'{kbps}k', '-ar', '44100', f'{OUT}/{path}.mp3'], check=True)
    print(path, round(len(x) / SR, 2), 's')

# ── dealer voice ────────────────────────────────────────────────
LINES = {
    'welcome_1': "Evening! Welcome tae the Clyde Room. Take a seat, pal.",
    'welcome_2': "Hiya, welcome in. Get yer bets on when you're ready.",
    'bets_1': "Place your bets, please.",
    'bets_2': "Right, bets on for the next hand.",
    'bets_3': "In you go, place your bets.",
    'nomore_1': "No more bets, thank you.",
    'nomore_2': "That's bets closed. Good luck.",
    'hit_1': "Card.", 'hit_2': "There you go.", 'hit_3': "Another one.",
    'stand_1': "Standing.", 'stand_2': "Stays there.",
    'double_1': "Doubling down. One card only.", 'double_2': "Double it is. Good luck, pal.",
    'split_1': "Splitting them. Two hands.", 'split_2': "Split, aye. Let's go.",
    'bj_1': "Blackjack! Pays three tae two. Braw!", 'bj_2': "Blackjack! Lovely stuff!",
    'dbust_1': "Dealer's bust. Everybody wins!", 'dbust_2': "Too many. Dealer busts.",
    'win_1': "Winner! Well played.", 'win_2': "You've beaten me there. Nice one.", 'win_3': "That's a winner.",
    'push_1': "It's a push. Stake back.", 'push_2': "Same total. Push.",
    'bust_1': "Oh, that's too many. Unlucky.", 'bust_2': "Bust, I'm afraid.",
    'lose_1': "Dealer wins this one.", 'lose_2': "Hard luck. Next one's yours.",
    'dealer_bj': "Dealer has blackjack, I'm afraid.",
    'pp_1': "And the pair pays!", 'pp_2': "Pair! Nice wee side bet.",
    't213_1': "Twenty one plus three, that's a winner!",
    'top3_1': "Top three! Big winner, that!", 'top3_2': "Top three pays! Magic!",
    'shuffle': "New shoe, just give me a wee minute.",
}
NUM = ['', '', '', '', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty', 'twenty one']
for v in range(4, 22): LINES[f'n{v}'] = NUM[v].capitalize() + ('!' if v == 21 else '.')

# Scots words, spelt in misaki's style
R.EXTRA.update({'a': 'ə', 'tae': 'tˈe', 'yer': 'jɜː', 'aye': 'ˈI', 'braw': 'bɹˈɔː', 'wee': 'wˈiː', 'hiya': 'hˈIjə', 'pal': 'pˈal', "dealer's": 'dˈiːləz',
                "that's": 'ðˈats', "it's": 'ɪts', "let's": 'lˈɛts', "you're": 'jˈɔː', "you've": 'jˈuːv', "i'm": 'Im', "one's": 'wˈʌnz', 'clyde': 'klˈId'})
MISAKI_TO_IPA = {'A': 'eː', 'I': 'aɪ', 'W': 'ʌʊ', 'Y': 'ɔɪ', 'Q': 'oː', 'O': 'oː', 'ᵊ': 'ə', 'ʤ': 'dʒ', 'ʧ': 'tʃ', 'ɐ': 'ʌ'}

def scots(word, ph):
    """Nudge one RP word towards Scottish speech: pure vowels (done in the map) and rhotic r."""
    w = word.lower()
    if re.search(r'r(?![aeiouy])|re$|r[e]?s$', w):   # an r not followed by a vowel letter is sounded in Scots
        for a, b in (('ɑː', 'aɹ'), ('ɔː', 'oɹ'), ('ɜː', 'ʌɹ'), ('ɪə', 'iɹ'), ('ɛː', 'eɹ'), ('eə', 'eɹ'), ('ʊə', 'uɹ')):
            if a in ph: return ph.replace(a, b, 1)
        if ph.endswith('ə') and w.endswith(('er', 'or', 'ar', 'our')): return ph + 'ɹ'
    return ph.replace('uː', 'ʉː').replace('ʊ', 'ʉ')

def phonemes(text):
    out = []
    for tok in re.findall(r"[A-Za-z']+|[,.!?]", text):
        if tok in ',.!?': out.append(tok); continue
        out.append((' ' if out else '') + scots(tok, R.word(tok)))
    s = ''.join(out).strip()
    return ''.join(MISAKI_TO_IPA.get(c, c) for c in s)

_s = {}
def alba(ipa, length=1.0, noise=0.6, noise_w=0.8):
    if not _s:
        import onnxruntime as ort
        cfg = json.load(open(ALBA + '.json'))
        _s['map'] = cfg['phoneme_id_map']; _s['sess'] = ort.InferenceSession(ALBA)
    pm = _s['map']; ids = list(pm['^'])
    for c in ipa:
        if c in pm: ids += pm[c] + pm['_']
        else: print('  (no phoneme for', repr(c), ')')
    ids += pm['$']
    a = _s['sess'].run(None, {'input': np.array([ids], dtype=np.int64), 'input_lengths': np.array([len(ids)], dtype=np.int64),
                              'scales': np.array([noise, length, noise_w], dtype=np.float32)})[0].reshape(-1)
    return a / (np.abs(a).max() + 1e-9)

def voices():
    gap = .3; parts = []; clips = {}; pos = 0.0
    for k, text in LINES.items():
        excited = '!' in text
        ipa = phonemes(text)
        a = alba(ipa, 0.95 if excited else 1.02)
        raw = f'{TMP}/v_{k}.wav'; wf.write(raw, 22050, a.astype(np.float32))
        proc = f'{TMP}/v_{k}_p.wav'
        # a close, warm dealer at the table: gentle presence lift, light room
        af = ('silenceremove=start_periods=1:start_threshold=-42dB:stop_periods=1:stop_threshold=-42dB:stop_duration=0.15,aresample=44100,highpass=f=80,'
              f'equalizer=f=220:t=q:w=1:g=2,equalizer=f=3200:t=q:w=1.2:g={3.5 if excited else 2.5},'
              'aecho=0.8:0.5:23|37:0.12|0.08,acompressor=threshold=-24dB:ratio=3.5:attack=4:release=100,volume=11dB,alimiter=limit=0.92')
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '1', proc], check=True)
        sr, y = wf.read(proc); y = y.astype(np.float64)
        if np.abs(y).max() > 2: y = y / 32768
        clips[k] = [round(pos, 3), round(len(y) / sr, 3)]
        parts += [y, np.zeros(int(gap * sr))]; pos += len(y) / sr + gap
        print(f'  {k:10s} {ipa}')
    w = f'{TMP}/voice_all.wav'; wf.write(w, 44100, np.concatenate(parts).astype(np.float32))
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', w, '-ac', '1', '-codec:a', 'libmp3lame', '-b:a', '56k', f'{OUT}/voice.mp3'], check=True)
    print('voice lines', len(clips), round(pos, 1), 's')
    return clips

# ── effects (sprite) ────────────────────────────────────────────
def card_slide(sec=.22, seed=1):
    r = np.random.default_rng(seed); n = int(sec * SR); t = np.arange(n) / SR
    x = P.bp(r.standard_normal(n), 1800, 7500) * np.minimum(1, t / .02) * np.exp(-t / (sec * .45))
    return P.mix((0, x, .8), (sec * .82, P.click(.01, 3400), .5))

def chip_click(k=0):
    return P.mix((0, P.click(.008, 4800 + k * 300), 1), (.004, P.chime([3100 + k * 140, 5200], .09, .025), .35))

def effects():
    E = {}
    E['deal'] = card_slide(.22, 1)
    E['deal2'] = card_slide(.18, 2)
    E['flip'] = P.mix((0, P.bp(P.noise(.07), 900, 5000) * P.env(int(.07 * SR), .004, tau=.02), .8), (.05, P.click(.012, 2600), .7))
    E['chip'] = P.mix((0, chip_click(0), 1), (.03, chip_click(2), .6))
    E['chips'] = P.mix(*[(k * .028 + (k % 3) * .006, chip_click(k % 5), .7 - k * .04) for k in range(10)])
    E['collect'] = P.mix((0, P.bp(P.noise(.35), 1200, 6000) * P.env(int(.35 * SR), .02, tau=.12), .45), *[(.12 + k * .035, chip_click(k % 4), .5) for k in range(7)])
    E['tap'] = P.mix((0, P.thump(95, .12, .9), 1), (0, P.bp(P.noise(.03), 300, 1500) * P.env(int(.03 * SR), .001, tau=.008), .5))
    E['wave'] = P.bp(P.noise(.35), 400, 2200) * P.env(int(.35 * SR), .12, tau=.1) * .35
    E['shuffle'] = P.mix(*[(k * .045, card_slide(.05, 10 + k), .45) for k in range(40)])
    E['win'] = P.hall(GM(lambda s: (s.prog(0, 11, rev=90, vol=104), [s.note(i * .09, 0, m(n), .7, 100) for i, n in enumerate(['G5', 'B5', 'D6', 'G6'])]), 1.3), .8, .2)
    E['bj'] = P.hall(GM(lambda s: (s.prog(0, 11, rev=90, vol=110), s.prog(1, 0, rev=80, vol=96), [s.note(i * .08, 0, m(n), .8, 106) for i, n in enumerate(['C5', 'E5', 'G5', 'C6', 'E6'])], [s.note(.35, 1, m(n), 1.2, 90) for n in ['C4', 'E4', 'G4', 'C5']]), 1.8), .9, .22)
    # a background bed of the room: murmur, a distant slot, a chip somewhere (looped quietly in game)
    gap = .25; parts = []; clips = {}; pos = 0.0
    for k, x in E.items():
        x = P.st(P.tail_trim(P.st(x)))
        x = x / (np.abs(x).max() + 1e-9) * 10 ** (-3 / 20)
        clips[k] = [round(pos, 3), round(len(x) / SR, 3)]
        parts += [x, np.zeros((int(gap * SR), 2))]; pos += len(x) / SR + gap
    save_mp3('sfx', np.concatenate(parts), -1.5, 96)
    return clips

# ── music: a quiet late-night lounge loop (piano trio + soft room) ──
def lounge(s, bars=16, bpm=84):
    beat = 60 / bpm
    s.prog(0, 0, rev=70, vol=86, pan=60)    # piano
    s.prog(1, 32, rev=40, vol=92, pan=64)   # acoustic bass
    s.prog(2, 48, rev=100, vol=50, pan=50)  # strings pad
    s.prog(DRUMS, 40, rev=50, vol=70)       # brush kit
    prog = [('D3', 'm9'), ('G2', '13'), ('C3', 'M9'), ('A2', '7b9'), ('D3', 'm9'), ('B2', 'ø'), ('E2', '7'), ('A2', '7')]
    V = {'m9': [3, 7, 10, 14], '13': [4, 10, 14, 21], 'M9': [4, 7, 11, 14], '7b9': [4, 10, 13, 19], 'ø': [3, 6, 10, 15], '7': [4, 10, 14, 19]}
    mel = ['A5', 'F5', 'E5', 'D5', 'G5', 'E5', 'D5', 'C5', 'E5', 'D5', 'B4', 'A4', 'C#5', 'E5', 'G5', 'F5']
    r = np.random.default_rng(3)
    for b in range(bars):
        root, kind = prog[b % len(prog)]; rr = m(root); T = b * 4 * beat
        for o in V[kind]: s.note(T + .02 * r.random(), 0, rr + 12 + o, 4 * beat * .9, 52 + int(r.integers(0, 10)))
        for o in V[kind][:3]: s.note(T, 2, rr + 12 + o, 4 * beat, 44)
        walk = [0, 7, 12, 10] if b % 2 else [0, 4, 7, 9]
        for q in range(4): s.note(T + q * beat, 1, rr - 12 + walk[q], beat * .85, 84 - q * 4)
        for q in range(4):
            s.note(T + q * beat, DRUMS, 59, beat * .5, 40)                       # ride, soft
            s.note(T + q * beat + beat * .66, DRUMS, 59, beat * .3, 30)
            if q in (1, 3): s.note(T + q * beat, DRUMS, 44, .1, 44)              # foot hat
        if b % 2 == 0:
            for i, n in enumerate(mel[(b // 2) * 2 % len(mel):(b // 2) * 2 % len(mel) + 2]):
                s.note(T + beat * (.5 + i * 1.5), 0, m(n), beat * 1.3, 66)
    return bars * 4 * beat

def base_music():
    sec = 16 * 4 * 60 / 84
    x = GM(lambda s: lounge(s), sec + 1.5, .7, .4)
    n = int(sec * SR); tail = x[n:]; x = x[:n].copy(); x[:len(tail)] += tail[:n]    # seamless loop: fold the reverb tail back in
    room = P.st(P.bp(P.noise(sec), 250, 1800) * .05)
    save_mp3('music/base', P.mix((0, x, 1), (0, room, 1)), -6, 80)

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('music', 'all'): base_music()
    sfx_clips = effects() if what in ('sfx', 'all') else None
    voice_clips = voices() if what in ('voice', 'all') else None
    old = open(SPRITES).read() if os.path.exists(SPRITES) else ''
    def keep(name):
        mm = re.search(rf'export const {name} = (\{{.*?\}});', old, re.S); return json.loads(mm.group(1)) if mm else {}
    sfx_clips = sfx_clips or keep('SFX'); voice_clips = voice_clips or keep('VOICE')
    with open(SPRITES, 'w') as f:
        f.write('// Generated by tools/music/clyde.py: [offset, duration] in seconds within sfx.mp3 / voice.mp3.\n')
        f.write(f'export const SFX = {json.dumps(sfx_clips)};\n')
        f.write(f'export const VOICE = {json.dumps(voice_clips)};\n')
