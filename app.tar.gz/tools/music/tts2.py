import sys; sys.path.insert(0,'/tmp/claude-0/sfx'); sys.path.insert(0,'/tmp/claude-0/vo')
import json, numpy as np, onnxruntime as ort, scipy.io.wavfile as wf
cfg=json.load(open('/tmp/claude-0/ko/src/kokoro_onnx/config.json')); vocab=cfg['vocab']
sess=ort.InferenceSession('/tmp/claude-0/kk/kokoro-v1.0.int8.onnx'); voices=np.load('/tmp/claude-0/kk/voices-v1.0.bin')
tk='input_ids' if 'input_ids' in {i.name for i in sess.get_inputs()} else 'tokens'
def say(ph, voice, speed):
    toks=[vocab[c] for c in ph if c in vocab]
    a=sess.run(None,{tk:np.array([[0,*toks,0]],dtype=np.int64),'style':voices[voice][len(toks)].astype(np.float32),'speed':np.array([speed],dtype=np.float32)})[0].reshape(-1)
    return a/np.abs(a).max()
# announcer style: a held first word, a beat, then the punch word
PH={'tiger':('tˈIɡəɹ… bˈOnəs!',0.8),'dragon':('dɹˈæɡən… bˈOnəs!',0.8),'combined':('tˈIɡəɹ ænd dɹˈæɡən… bˈOnəs!',0.84),
    'luck':('lˈʌk… hæz əɹˈIvd!',0.8),'jackpot':('ʤˈækpɑt!',0.8),'bigwin':('bˈɪɡ wˈɪn!',0.82),'megawin':('mˈɛɡə wˈɪn!',0.82)}
for k,(p,sp) in PH.items():
    a=say(p,'am_onyx',sp); wf.write(f'/tmp/claude-0/vo/raw_{k}.wav',24000,a.astype(np.float32)); print(k,round(len(a)/24000,2))
