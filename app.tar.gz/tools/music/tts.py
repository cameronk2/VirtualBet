import json, numpy as np, onnxruntime as ort, scipy.io.wavfile as wf, sys
cfg=json.load(open('/tmp/claude-0/ko/src/kokoro_onnx/config.json')); vocab=cfg['vocab']
sess=ort.InferenceSession('/tmp/claude-0/kk/kokoro-v1.0.int8.onnx'); voices=np.load('/tmp/claude-0/kk/voices-v1.0.bin')
names={i.name:i for i in sess.get_inputs()}; tk='input_ids' if 'input_ids' in names else 'tokens'
def say(ph, voice, speed, out):
    toks=[vocab[c] for c in ph if c in vocab]; miss=[c for c in ph if c not in vocab]
    if miss: print('missing',miss)
    st=voices[voice][len(toks)]
    a=sess.run(None,{tk:np.array([[0,*toks,0]],dtype=np.int64),'style':st.astype(np.float32),'speed':np.array([speed],dtype=np.float32)})[0].reshape(-1)
    wf.write(out,24000,(a/np.abs(a).max()*0.95).astype(np.float32)); print(out, len(a)/24000)
PH={'tiger':'tˈIɡəɹ bˈOnəs!','dragon':'dɹˈæɡən bˈOnəs!','combined':'tˈIɡəɹ ænd dɹˈæɡən bˈOnəs!','jackpot':'ʤˈækpɑt!','mystery':'mˈɪstəɹi ɡˈɔŋz!','bigwin':'bˈɪɡ wˈɪn!','megawin':'mˈɛɡə wˈɪn!'}
for v in sys.argv[1:]:
    for k,p in PH.items(): say(p,v,0.95,f'/tmp/claude-0/vo/{v}_{k}.wav')
