import sys; sys.path.insert(0,'/tmp/claude-0/mu'); sys.path.insert(0,'/tmp/claude-0/sfx')
import numpy as np, scipy.signal as sg, scipy.io.wavfile as wf
from fs import Synth, m, SR
from gongs import gong, hall, save
def ld(name):
    sr,x=wf.read(f'/tmp/claude-0/sfx/{name}.wav'); return x if x.ndim==2 else np.stack([x,x],1)
def place(dst,src,t,g=1.0):
    if src.ndim==1: src=np.stack([src,src],1)
    i=int(t*SR); n=min(len(src),len(dst)-i)
    if n>0: dst[i:i+n]+=src[:n]*g
def blank(sec): return np.zeros((int(sec*SR),2))
def norm(x,p=0.9): return x/np.abs(x).max()*p
KOTO,FLUTE,STR,TREM,PIZZ,TAIKO,TIMP,BRASS,CHOIR,BELLS,CELESTA,GLOCK,ORCH=107,73,48,44,45,116,47,61,52,14,8,9,55
def synth_part(fn,sec):
    s=Synth(room=0.8,level=0.6); fn(s); a=s.render(sec); return a/ (np.abs(a).max()+1e-9)
# ── roars ─────────────────────────────────────────────
def roar(f0a,f0b,dur,formants,seed=0,growl=28,breath=0.5):
    rng=np.random.default_rng(seed); n=int(dur*SR); t=np.arange(n)/SR
    f0=f0a+(f0b-f0a)*(t/dur)**0.7; f0*=1+0.04*rng.standard_normal(n).cumsum()/np.sqrt(np.arange(1,n+1))*0+0.03*np.sin(2*np.pi*5.3*t)
    ph=2*np.pi*np.cumsum(f0)/SR; src=sg.sawtooth(ph)*0.7+rng.standard_normal(n)*breath
    src*=1+0.55*np.sin(2*np.pi*growl*t+rng.uniform(0,6))  # rattle
    y=np.zeros(n)
    for F,bw,g in formants:
        b,a=sg.butter(2,[(F-bw/2)/(SR/2),(F+bw/2)/(SR/2)],'band'); y+=sg.lfilter(b,a,src)*g
    env=np.minimum(1,t/0.12)*np.exp(-np.maximum(0,t-dur*0.55)/(dur*0.18)); y=np.tanh(2.5*y*env)
    return y/np.abs(y).max()
def whoosh(dur,f1,f2,seed=0):
    rng=np.random.default_rng(seed); n=int(dur*SR); t=np.arange(n)/SR; x=rng.standard_normal(n); y=np.zeros(n); blk=512
    for i in range(0,n,blk):
        f=f1*(f2/f1)**(i/n); b,a=sg.butter(2,[f*0.6/(SR/2),min(0.99,f*1.6/(SR/2))],'band'); y[i:i+blk]=sg.lfilter(b,a,x[i:i+blk])
    env=np.sin(np.pi*np.clip(t/dur,0,1))**1.5; return y*env/np.abs(y).max()
tiger=roar(110,70,1.5,[(600,300,1),(1100,400,.6),(2500,600,.25)],seed=1,growl=30)
save('roar_tiger',hall(tiger,1.8,0.25,seed=2))
dr=roar(80,48,2.4,[(450,260,1),(900,300,.7),(2100,700,.35)],seed=3,growl=22,breath=0.8)
dw=whoosh(2.4,300,3500,seed=4)*0.45
save('roar_dragon',hall(np.stack([dr+dw*0.8,dr+dw*1.0],1),2.5,0.3,seed=3))
# ── musical cues ─────────────────────────────────────
def roll(s,ch,note,t0,t1,v0,v1,step=0.07):
    k=0; t=t0; N=int((t1-t0)/step)
    while t<t1: s.note(t,ch,m(note),step*1.2,v0+(v1-v0)*k/max(1,N)); t+=step; k+=1
def gliss(s,ch,t0,notes,step,v=90):
    for i,n in enumerate(notes): s.note(t0+i*step,ch,m(n),1.6,v+i*2)
PENT=['D4','E4','F#4','A4','B4','D5','E5','F#5','A5','B5','D6','E6','F#6']
# Hold & Spin opening: three ascending gongs, taiko, strings swell, koto run. Voice lands at 1.25s.
def hs(s):
    s.prog(0,KOTO,pan=40,rev=80); s.prog(1,STR,rev=90,vol=110); s.prog(4,TAIKO,rev=50,vol=125); s.prog(6,BRASS,rev=80,vol=100); s.prog(7,TIMP,rev=60,vol=110)
    for t in (0,0.45,0.9): s.note(t,4,m('C2'),0.4,120)
    roll(s,7,'D2',0.1,1.2,40,110)
    for n in ['D3','A3','D4','F#4']: s.note(0.15,1,m(n),1.1,60); s.note(1.25,1,m(n)+12 if m(n)<60 else m(n),1.6,110)
    for n in ['D3','A3','D4']: s.note(1.25,6,m(n),1.3,105)
    s.note(1.25,4,m('C2'),0.6,127); gliss(s,0,1.25,PENT,0.035)
x=blank(4.2); place(x,synth_part(hs,4.2),0,0.8)
for i,(t,g) in enumerate([(0,'gong_land_1'),(0.45,'gong_land_3'),(0.9,'gong_land_5')]): place(x,ld(g),t,0.55+i*0.12)
place(x,ld('gong_big_2'),1.25,0.55); save('cue_holdspin',x)
# Dragon intro: timp roll from nothing, dragon roar, three slow gongs, choir + brass. Voice at 2.0s.
def dg(s):
    s.prog(1,TREM,rev=100,vol=110); s.prog(3,CHOIR,rev=110,vol=110); s.prog(6,BRASS,rev=90,vol=105); s.prog(7,TIMP,rev=70,vol=120); s.prog(4,TAIKO,rev=60,vol=127)
    roll(s,7,'A1',0.0,1.9,20,120,0.06)
    for n in ['A2','E3','A3']: s.note(0.0,1,m(n),1.9,70)
    for t in (0.6,1.2): s.note(t,4,m('C2'),0.5,110)
    for n in ['A2','E3','A3','C4','E4']: s.note(1.95,3,m(n),2.4,110); s.note(1.95,6,m(n),1.6,100)
    s.note(1.95,4,m('C2'),0.7,127)
    for i,n in enumerate(['E5','G5','A5','C6','E6']): s.note(2.5+i*0.09,1,m(n),1.0,90)
x=blank(5.5); place(x,synth_part(dg,5.5),0,0.75); place(x,ld('roar_dragon'),0.05,0.7)
for t,g in [(0.6,'gong_land_1'),(1.2,'gong_land_2')]: place(x,ld(g),t,0.5)
place(x,ld('gong_big'),1.95,0.75); save('cue_dragon',x)
# LUCK HAS ARRIVED: 1 opening gong, 2 build-up, (3 voice at 2.2s, scheduled separately), 4 metallic resonance at 3.75s, 5 finish.
def lk(s):
    s.prog(0,KOTO,pan=36,rev=90); s.prog(1,TREM,rev=100,vol=115); s.prog(2,FLUTE,pan=84,rev=95,vol=110); s.prog(3,CHOIR,rev=110,vol=100)
    s.prog(4,TAIKO,rev=60,vol=127); s.prog(6,BRASS,rev=90,vol=110); s.prog(7,TIMP,rev=70,vol=120); s.prog(8,STR,rev=100,vol=115); s.prog(9,0,rev=80)
    roll(s,7,'D2',0.35,2.15,25,118,0.06)
    for n in ['D3','A3','D4','F#4','A4']: s.note(0.35,1,m(n),1.85,64)
    for i,t in enumerate([0.9,1.3,1.6,1.85,2.0]): s.note(t,4,m('C2'),0.3,80+i*10)
    gliss(s,0,1.55,PENT[:11],0.055,80)
    s.note(2.15,4,m('C2'),0.6,127); s.note(2.15,9,52,2.5,90)
    for n in ['D3','A3','D4','F#4','A4']: s.note(2.15,8,m(n),1.5,70)   # bed under the voice (kept low)
    # finish (after the resonance gong)
    for n in ['D3','A3','D4','F#4','A4','D5']: s.note(3.9,8,m(n),2.6,112); s.note(3.9,6,m(n)-12 if m(n)>62 else m(n),2.0,105); s.note(3.9,3,m(n),2.6,95)
    s.note(3.9,4,m('C2'),0.8,127); s.note(3.9,9,49,3,110)
    for i,n in enumerate(['A5','B5','D6','E6','F#6','A6']): s.note(3.95+i*0.08,2,m(n),0.5 if i<5 else 1.8,110)
    gliss(s,0,3.9,PENT,0.03,95)
x=blank(7.5); place(x,synth_part(lk,7.5),0,0.8); place(x,ld('gong_big'),0.0,0.95); place(x,ld('gong_big_2'),3.75,0.8); place(x,ld('gong_lock'),3.78,0.4)
save('cue_luck',x)
# near completion riser (2.2s)
def nr(s):
    s.prog(1,TREM,rev=90,vol=120); s.prog(7,TIMP,rev=60,vol=115)
    roll(s,7,'A1',0,2.1,20,120,0.055)
    for n in ['A2','E3','A3','D#4']: s.note(0,1,m(n),2.1,50)
    for k in range(8): s.cc(k*0.26,1,11,50+k*11)
save('cue_near',norm(synth_part(nr,2.8)))
# feature complete
def cp(s):
    s.prog(0,KOTO,rev=90); s.prog(1,STR,rev=100,vol=120); s.prog(6,BRASS,rev=90,vol=115); s.prog(4,TAIKO,rev=60,vol=127); s.prog(9,0,rev=80); s.prog(2,FLUTE,rev=90,vol=110)
    for t,ch in [(0,['A3','D4','F#4','A4']),(0.32,['B3','E4','G#4','B4']),(0.64,['D4','F#4','A4','D5'])]:
        d=2.4 if t>0.5 else 0.3
        for n in ch: s.note(t,1,m(n),d,110); s.note(t,6,m(n)-12,d*0.9,100)
        s.note(t,4,m('C2'),0.5,120)
    s.note(0.64,9,49,3,110); gliss(s,0,0.64,PENT,0.035,95)
    for i,n in enumerate(['F#5','A5','D6']): s.note(0.7+i*0.12,2,m(n),1.4 if i==2 else 0.2,110)
x=blank(4.5); place(x,synth_part(cp,4.5),0,0.8); place(x,ld('gong_big_2'),0.64,0.55); save('cue_complete',x)
# reveal sounds: small (bell + coin), medium (koto chord + bell), big (gong + brass hit)
def rv_s(s): s.prog(0,CELESTA,rev=70); s.note(0,0,m('A6'),0.5,100); s.note(0.04,0,m('D7'),0.6,90)
def rv_m(s): s.prog(0,KOTO,rev=80); s.prog(1,GLOCK,rev=80); [s.note(i*0.03,0,m(n),1.2,100) for i,n in enumerate(['D5','F#5','A5','D6'])]; s.note(0.05,1,m('A6'),0.8,100)
def rv_b(s): s.prog(6,BRASS,rev=90,vol=120); s.prog(1,STR,rev=90,vol=120); s.prog(0,GLOCK,rev=80); [ (s.note(0,6,m(n),0.9,120), s.note(0,1,m(n)+12,1.0,110)) for n in ['D3','A3','D4','F#4']]; [s.note(0.05+i*0.05,0,m(n),0.8,110) for i,n in enumerate(['D6','F#6','A6','D7'])]
save('reveal_s',synth_part(rv_s,1.2)); save('reveal_m',synth_part(rv_m,1.8))
x=blank(3.2); place(x,synth_part(rv_b,3.2),0,0.8); place(x,ld('gong_land_4'),0,0.6); save('reveal_b',x)
# spin used: taiko + woodblock + short whoosh. last spin: heartbeat
def su(s): s.prog(4,TAIKO,rev=50,vol=110); s.prog(5,115,rev=40,vol=90); s.note(0,4,m('D2'),0.3,90); s.note(0.0,5,m('E5'),0.2,90); s.note(0.12,5,m('B4'),0.2,70)
x=blank(0.9); place(x,synth_part(su,0.9),0,0.8); place(x,np.stack([whoosh(0.6,400,2500,7)]*2,1),0.05,0.25); save('spin_use',x)
def hb(s): s.prog(4,TAIKO,rev=40,vol=127); s.prog(7,TIMP,rev=40,vol=110); s.note(0,4,m('C2'),0.3,120); s.note(0.22,4,m('C2'),0.3,95); s.note(0,7,m('D2'),0.4,100)
save('spin_last',synth_part(hb,1.0))
