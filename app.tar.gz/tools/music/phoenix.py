# Phoenix Ember Link – the complete sound package, made only with free tools:
#   * music and orchestral parts: FluidSynth (libfluidsynth via ctypes, fs.py) + FluidR3 Mono GM soundfont (MIT)
#   * fire, impacts, whooshes, sparkles, the phoenix cry: synthesised here with numpy/scipy
#   * announcer: Kokoro-82M (Apache 2.0) through onnxruntime, processed with ffmpeg
# Output: client/audio/phoenix/{music,sfx,voice}/*.mp3 (ffmpeg libmp3lame).
# Usage: python3 phoenix.py [music|sfx|voice|all]
import sys, os, subprocess, json, numpy as np, scipy.signal as sg, scipy.io.wavfile as wf
sys.path.insert(0, os.path.dirname(__file__))
from fs import Synth, m, SR
OUT = os.path.join(os.path.dirname(__file__), '../../client/audio/phoenix')
TMP = '/tmp/claude-0/phx'; os.makedirs(TMP, exist_ok=True)
for d in ('music', 'sfx', 'voice'): os.makedirs(f'{OUT}/{d}', exist_ok=True)
rng = np.random.default_rng(7)
# GM programs
STR, TREM, PIZZ, CHOIR, VOX, HORN, TPT, TBN, BRASS, TIMP, TAIKO, HARP, CELESTA, GLOCK, CHIMES, MARIMBA, PAD_WARM, PAD_HALO, FX_ATMO, CELLO, CBASS, SYNBR, ORCHHIT, CYMB = \
    48, 44, 45, 52, 53, 60, 56, 57, 61, 47, 116, 46, 8, 9, 14, 12, 89, 94, 99, 42, 43, 62, 55, 119

# ── helpers ─────────────────────────────────────────────────────
def T(sec): return np.arange(int(sec * SR)) / SR
def st(x): return np.stack([x, x], 1) if x.ndim == 1 else x
def norm(x, p=0.95): return x / (np.abs(x).max() + 1e-9) * p
def env(n, a=0.005, d=None, tau=0.2):
    t = np.arange(n) / SR; e = np.exp(-t / tau)
    k = int(a * SR)
    if k: e[:k] *= np.linspace(0, 1, k)
    return e
def bp(x, lo, hi, o=2): sos = sg.butter(o, [lo / (SR / 2), min(hi, SR / 2 - 100) / (SR / 2)], 'band', output='sos'); return sg.sosfilt(sos, x, axis=0)
def lp(x, f, o=2): sos = sg.butter(o, f / (SR / 2), output='sos'); return sg.sosfilt(sos, x, axis=0)
def hp(x, f, o=2): sos = sg.butter(o, f / (SR / 2), 'high', output='sos'); return sg.sosfilt(sos, x, axis=0)
def noise(sec): return rng.standard_normal(int(sec * SR))
def hall(x, secs=2.5, wet=0.3, damp=5000, seed=1):
    r = np.random.default_rng(seed); n = int(secs * SR); t = np.arange(n) / SR; x = st(x)
    out = np.zeros((len(x) + n - 1, 2))
    for ch in range(2):
        ir = r.standard_normal(n) * np.exp(-t * 6.9 / secs); ir = lp(ir, damp); ir[:int(.01 * SR)] *= np.linspace(0, 1, int(.01 * SR)); ir /= np.sqrt((ir ** 2).sum())
        out[:, ch] = sg.fftconvolve(x[:, ch], ir) * wet
    out[:len(x)] += x * (1 - wet * .4)
    return out
def mix(*parts, sec=None):
    L = max(int(t * SR) + len(st(p)) for t, p, g in parts) if sec is None else int(sec * SR)
    out = np.zeros((L, 2))
    for t, p, g in parts:
        p = st(p) * g; i = int(t * SR); j = min(L, i + len(p)); out[i:j] += p[:j - i]
    return out
def lay(items, sec): return mix(*[(t, x, 1) for t, x in items], sec=sec)
def pan(x, p):  # -1..1
    x = x if x.ndim == 1 else x.mean(1); return np.stack([x * np.sqrt((1 - p) / 2), x * np.sqrt((1 + p) / 2)], 1) * 1.41
def fadeout(x, sec): n = int(sec * SR); x = x.copy(); x[-n:] *= np.linspace(1, 0, n)[:, None] if x.ndim == 2 else np.linspace(1, 0, n); return x
def tail_trim(x, thr=1e-4):
    a = np.abs(st(x)).max(1); idx = np.where(a > thr)[0]; return x[:idx[-1] + 1] if len(idx) else x
def save(path, x, peak_db=-1.0, kbps=None):
    x = st(x); x = x / (np.abs(x).max() + 1e-9) * 10 ** (peak_db / 20)
    w = f'{TMP}/{os.path.basename(path)}.wav'; wf.write(w, SR, x.astype(np.float32))
    br = kbps or (96 if '/music/' in path else 80)
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', w, '-codec:a', 'libmp3lame', '-b:a', f'{br}k', '-ar', '44100', f'{OUT}/{path}.mp3'], check=True)
    print(path, round(len(x) / SR, 2), 's')
def fsynth(fn, sec, room=0.75, level=0.55):
    s = Synth(room=room, level=level); fn(s); return s.render(sec).astype(np.float64)

# ── fire, impacts and magic (synthesised) ──────────────────────
def crackle(sec, rate=60, bright=1.0, seed=0):
    r = np.random.default_rng(seed); n = int(sec * SR); y = np.zeros(n)
    for _ in range(int(rate * sec)):
        i = r.integers(0, n - 400); L = r.integers(30, 260)
        y[i:i + L] += r.standard_normal(L) * np.exp(-np.arange(L) / (L / 4)) * r.uniform(.2, 1)
    return hp(y, 1200 * bright) * .8
def roar(sec, lo=80, hi=1400, flick=7, seed=1):
    r = np.random.default_rng(seed); n = int(sec * SR); t = np.arange(n) / SR
    body = bp(r.standard_normal(n), lo, hi, 2)
    am = 1 + .35 * np.sin(2 * np.pi * flick * t + r.uniform(0, 6)) * np.sin(2 * np.pi * 1.3 * t)
    rumble = lp(r.standard_normal(n), 120, 2) * 3
    return body * am + rumble
def whoosh(sec, f1, f2, seed=0, q=3):
    r = np.random.default_rng(seed); n = int(sec * SR); x = r.standard_normal(n); out = np.zeros(n); blk = 512
    for i in range(0, n, blk):
        k = i / n; f = f1 * (f2 / f1) ** k; bw = f / q
        seg = x[max(0, i - 2048):i + blk]; y = bp(seg, max(30, f - bw), f + bw); out[i:i + blk] = y[-len(out[i:i + blk]):]
    e = np.sin(np.pi * np.linspace(0, 1, n)) ** 1.5
    return out * e
def thump(f0=70, sec=.5, drop=.5):
    t = T(sec); f = f0 * (1 + drop * np.exp(-t / .03)); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * env(len(t), .002, tau=sec / 4)
def click(sec=.03, f=3500): return bp(noise(sec), f * .6, f * 1.6) * env(int(sec * SR), .0005, tau=.006)
def chime(freqs, sec=1.6, tau=.5, inh=1.0):
    t = T(sec); y = np.zeros(len(t))
    for i, f in enumerate(freqs):
        for k, (r, a) in enumerate([(1, 1), (2.76 * inh, .35), (5.4 * inh, .15), (8.9 * inh, .06)]):
            y += a * np.sin(2 * np.pi * f * r * t + i) * np.exp(-t / (tau / (1 + k * .7)))
    return y * env(len(t), .001, tau=sec)
def sparkle(sec=1.0, n=18, lo=2500, hi=7000, seed=3):
    r = np.random.default_rng(seed); y = np.zeros(int(sec * SR) + SR)
    for _ in range(n):
        f = r.uniform(lo, hi); i = r.integers(0, int(sec * SR * .8)); c = chime([f], .5, .12)
        y[i:i + len(c)] += c * r.uniform(.2, .6)
    return y[:int(sec * SR)]
def coinclink(seed=0):
    r = np.random.default_rng(seed); t = T(.45); y = np.zeros(len(t))
    for f, a in [(r.uniform(3900, 4300), 1), (r.uniform(6100, 6500), .6), (r.uniform(8800, 9300), .35), (r.uniform(2400, 2600), .3)]:
        y += a * np.sin(2 * np.pi * f * t) * np.exp(-t / r.uniform(.05, .12))
    y[:int(.01 * SR)] += click(.01, 6000) * .5
    return y
def phoenix_cry(sec=1.4, base=1500, seed=2):
    """A soaring raptor-like cry: FM voice with a rising-then-falling pitch, vibrato and breath."""
    r = np.random.default_rng(seed); t = T(sec); k = t / sec
    contour = base * (1 + .55 * np.sin(np.pi * np.clip(k * 1.3, 0, 1)) - .25 * k)
    vib = 1 + .02 * np.sin(2 * np.pi * 23 * t) + .01 * np.sin(2 * np.pi * 7 * t)
    f = contour * vib; ph = 2 * np.pi * np.cumsum(f) / SR
    mod = np.sin(ph * 2) * (2.2 * np.exp(-t / .5) + .6)
    y = np.sin(ph + mod) * .8 + np.sin(2 * ph + .5 * mod) * .3 + np.sin(3 * ph) * .1
    breath = bp(r.standard_normal(len(t)), 2500, 7000) * .25
    e = np.clip(k * 12, 0, 1) * np.exp(-np.clip(k - .55, 0, 1) * 5)
    return (y + breath) * e

def wild_sfx():
    """Phoenix Wild landing: a warm, low burst of flame with a soft horn-and-strings swell.
    No high bird cry: everything sits below ~5 kHz so it stays pleasant when it repeats."""
    r = np.random.default_rng(42)
    flame = whoosh(.8, 110, 900, 21, 2.2) * np.linspace(1, .6, int(.8 * SR))
    body = lp(r.standard_normal(int(.9 * SR)), 700) * env(int(.9 * SR), .02, tau=.25) * 1.6
    swell = gm(lambda s: (s.prog(0, HORN, rev=100, vol=96), s.prog(1, STR, rev=100, vol=88), s.prog(2, HARP, rev=100, vol=80),
                          [s.note(.04, 0, m(n), .9, 78) for n in ['D3', 'A3', 'D4']], [s.note(.04, 1, m(n), 1.0, 70) for n in ['F#3', 'A3', 'D4']],
                          [s.note(.06 + k * .05, 2, m(n), .9, 70) for k, n in enumerate(['D4', 'F#4', 'A4'])]), 1.8)
    x = mix((0, flame, .55), (0, body, .5), (0, thump(62, .5, .6), .55), (.02, crackle(.7, 30, .6, seed=43), .12), (0, swell, .9))
    return hall(lp(x, 5000), 1.6, .28)

# ── announcer ───────────────────────────────────────────────────
def voices():
    import onnxruntime as ort
    cfg = json.load(open('/tmp/claude-0/ko/src/kokoro_onnx/config.json')); vocab = cfg['vocab']
    sess = ort.InferenceSession('/tmp/claude-0/kk/kokoro-v1.0.int8.onnx'); vs = np.load('/tmp/claude-0/kk/voices-v1.0.bin')
    tk = 'input_ids' if 'input_ids' in {i.name for i in sess.get_inputs()} else 'tokens'
    def say(ph, voice='am_onyx', speed=.84):
        toks = [vocab[c] for c in ph if c in vocab]
        a = sess.run(None, {tk: np.array([[0, *toks, 0]], dtype=np.int64), 'style': vs[voice][len(toks)].astype(np.float32), 'speed': np.array([speed], dtype=np.float32)})[0].reshape(-1)
        return a / np.abs(a).max()
    lines = {'arealink': ('ˈɛɹiə lˈɪŋk!', .82), 'firestorm': ('fˈinɪks… fˈIəɹstˌɔɹm!', .8), 'bigwin': ('bˈɪɡ wˈɪn!', .82), 'megawin': ('mˈɛɡə wˈɪn!', .82),
             'epicwin': ('ˈɛpɪk wˈɪn!', .8), 'mini': ('mˈɪni ʤˈækpɑt!', .84), 'minor': ('mˈInəɹ ʤˈækpɑt!', .84), 'major': ('mˈAʤəɹ ʤˈækpɑt!', .82), 'grand': ('ɡɹˈænd… ʤˈækpɑt!', .78)}
    for k, (ph, sp) in lines.items():
        a = say(ph, 'am_onyx', sp); raw = f'{TMP}/vo_{k}.wav'; wf.write(raw, 24000, a.astype(np.float32))
        # deeper, present, compressed, with an arena echo
        af = 'asetrate=24000*0.93,aresample=44100,atempo=1.07,highpass=f=70,equalizer=f=3000:t=q:w=1:g=4,equalizer=f=180:t=q:w=1:g=3,acompressor=threshold=-18dB:ratio=4:attack=5:release=120,aecho=0.8:0.55:70|140:0.25|0.12,volume=14dB,alimiter=limit=0.9'
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '2', '-codec:a', 'libmp3lame', '-b:a', '80k', f'{OUT}/voice/{k}.mp3'], check=True)
        print('voice', k)

# ── music ───────────────────────────────────────────────────────
def chord(root, kind='min'):
    r = m(root); return {'min': [r, r + 3, r + 7], 'maj': [r, r + 4, r + 7], 'sus': [r, r + 5, r + 7], 'min7': [r, r + 3, r + 7, r + 10]}[kind]
PROG = [('D3', 'min'), ('Bb2', 'maj'), ('F3', 'maj'), ('C3', 'maj'), ('D3', 'min'), ('Bb2', 'maj'), ('G2', 'min'), ('A2', 'maj')]
def base_music():
    bpm = 72; beat = 60 / bpm; bars = 24; sec = bars * 4 * beat
    def f(s):
        s.prog(0, CHOIR, rev=100, vol=70); s.prog(1, STR, rev=95, vol=72, pan=50); s.prog(2, HARP, rev=90, vol=74, pan=36); s.prog(3, HORN, rev=100, vol=88, pan=74)
        s.prog(4, TAIKO, rev=70, vol=78); s.prog(5, CBASS, rev=70, vol=78); s.prog(6, CELESTA, rev=100, vol=60, pan=90); s.prog(7, TIMP, rev=80, vol=70)
        for b in range(bars):
            root, kind = PROG[b % 8]; t0 = b * 4 * beat; ch = chord(root, kind)
            for n in ch: s.note(t0, 0, n + 12, 4 * beat * .98, 52); s.note(t0, 1, n, 4 * beat * .98, 58)
            s.note(t0, 5, ch[0] - 12, 4 * beat * .9, 72)
            arp = [ch[0] + 12, ch[1] + 12, ch[2] + 12, ch[1] + 24, ch[2] + 12, ch[1] + 12]
            for i, n in enumerate(arp + arp[:2]): s.note(t0 + i * beat / 2, 2, n, beat, 54 + (8 if i % 4 == 0 else 0))
            s.note(t0, 4, m('C2'), .4, 70); s.note(t0 + 2.5 * beat, 4, m('C2'), .3, 46)
            if b % 4 == 3: s.note(t0 + 3 * beat, 7, m('D2'), .5, 60); s.note(t0 + 3.5 * beat, 7, m('D2'), .5, 70)
        mel = [('A4', 2), ('D5', 1), ('E5', 1), ('F5', 3), ('E5', 1), ('D5', 2), ('C5', 2), ('A4', 4), ('-', 4),
               ('A4', 2), ('C5', 1), ('D5', 1), ('E5', 3), ('D5', 1), ('Bb4', 2), ('C5', 2), ('A4', 4), ('-', 4),
               ('D5', 2), ('F5', 1), ('G5', 1), ('A5', 3), ('G5', 1), ('F5', 2), ('E5', 2), ('D5', 4), ('-', 4),
               ('F5', 2), ('E5', 1), ('D5', 1), ('C5', 3), ('Bb4', 1), ('A4', 2), ('C#5', 2), ('D5', 6), ('-', 2)]
        t = 4 * 4 * beat
        for n, d in mel:
            if n != '-': s.note(t, 3, m(n) - 12, d * beat * .95, 74)
            t += d * beat
        for k in range(bars // 2): s.note(k * 8 * beat + 6 * beat, 6, m('A6') + (k % 3) * 2, 2 * beat, 40)
    mus = fsynth(f, sec + 4, room=.85, level=.7)
    lava = st(lp(roar(sec + 4, 40, 300, 2, seed=9), 220)) * .05 + st(crackle(sec + 4, 18, seed=4)) * .02
    n = min(len(mus), len(lava)); out = st(mus)[:n] + st(lava)[:n]
    return out[:int(sec * SR) + int(2 * SR)]
def bonus_music():
    bpm = 116; beat = 60 / bpm; bars = 16; sec = bars * 4 * beat
    def f(s):
        s.prog(0, STR, rev=70, vol=90); s.prog(1, PIZZ, rev=60, vol=95, pan=40); s.prog(2, BRASS, rev=80, vol=96, pan=70); s.prog(3, CHOIR, rev=90, vol=70)
        s.prog(4, TAIKO, rev=50, vol=110); s.prog(5, CBASS, rev=50, vol=90); s.prog(6, TIMP, rev=60, vol=95); s.prog(7, HORN, rev=80, vol=90, pan=56); s.prog(8, GLOCK, rev=80, vol=60, pan=90)
        for b in range(bars):
            root, kind = PROG[b % 8]; t0 = b * 4 * beat; ch = chord(root, kind)
            for i in range(16):   # spiccato ostinato
                n = [ch[0], ch[0] + 12, ch[1], ch[2]][i % 4] + 12
                s.note(t0 + i * beat / 4, 1, n, beat / 5, 70 + (18 if i % 4 == 0 else 0))
            for n in ch: s.note(t0, 3, n + 12, 4 * beat, 58); s.note(t0, 0, n, 4 * beat * .95, 60)
            for i in range(8): s.note(t0 + i * beat / 2, 5, ch[0] - 12, beat / 2.2, 82 if i % 2 == 0 else 64)
            for i, v in [(0, 118), (1.5, 92), (2, 108), (3, 100), (3.5, 86)]: s.note(t0 + i * beat, 4, m('C2'), .3, v)
            s.note(t0 + 3.75 * beat, 4, m('D2'), .2, 80)
            if b % 2 == 1: s.note(t0 + 3 * beat, 6, ch[0] - 12, .4, 90)
        hook = [('D5', 1.5), ('F5', .5), ('A5', 1), ('G5', 1), ('F5', 1), ('E5', .5), ('D5', .5), ('C5', 1), ('A4', 1),
                ('Bb4', 1.5), ('C5', .5), ('D5', 1), ('F5', 1), ('E5', 2), ('C#5', 2)]
        for rep in range(4):
            t = (rep * 4 + 0) * 4 * beat
            if rep == 0: continue
            for n, d in hook:
                s.note(t, 2 if rep % 2 else 7, m(n) - (12 if rep % 2 else 0), d * beat * .9, 92); t += d * beat
        for k in range(bars): s.note(k * 4 * beat + 3.5 * beat, 8, m('D6') + [0, 3, 7, 10][k % 4], .4, 50)
    mus = fsynth(f, sec + 3, room=.7, level=.5)
    fire = st(roar(sec + 3, 60, 900, 5, seed=3)) * .025
    n = min(len(mus), len(fire)); return st(mus)[:n] + fire[:n]
def sting(kind):
    if kind == 'win':
        def f(s):
            s.prog(0, BRASS, rev=90, vol=110); s.prog(1, STR, rev=100, vol=96); s.prog(2, GLOCK, rev=90, vol=90); s.prog(3, TIMP, rev=80, vol=100)
            for i, n in enumerate(['D4', 'F4', 'A4', 'D5']): s.note(i * .12, 0, m(n), .5 if i < 3 else 1.6, 104)
            for n in chord('D3', 'maj') + [m('D4')]: s.note(.36, 1, n + 12, 2, 90)
            for i, n in enumerate(['A5', 'D6', 'F#6', 'A6']): s.note(.36 + i * .07, 2, m(n), 1, 90)
            s.note(0, 3, m('D2'), .4, 90); s.note(.36, 3, m('D2'), .6, 110)
        return fsynth(f, 3.6, room=.8)
    def f(s):  # jackpot: orchestral fanfare with choir and a final swell
        s.prog(0, BRASS, rev=90, vol=118); s.prog(1, STR, rev=100, vol=100); s.prog(2, CHOIR, rev=100, vol=96); s.prog(3, TIMP, rev=80, vol=110); s.prog(4, GLOCK, rev=90, vol=96); s.prog(5, TPT, rev=90, vol=110, pan=80); s.prog(6, ORCHHIT, rev=80, vol=100)
        seq = [('D4', 0, .3), ('F4', .3, .3), ('A4', .6, .3), ('D5', .9, 1.2), ('C5', 2.1, .3), ('Bb4', 2.4, .3), ('C5', 2.7, .3), ('D5', 3.0, 2.6)]
        for n, t, d in seq: s.note(t, 0, m(n), d, 110); s.note(t, 5, m(n) + 12, d, 96)
        s.note(.9, 6, m('D4'), .5, 110); s.note(3.0, 6, m('D4'), .5, 120)
        for n in chord('D3', 'maj'): s.note(.9, 1, n + 12, 1.2, 96); s.note(.9, 2, n + 12, 1.2, 90)
        for n in chord('Bb2', 'maj'): s.note(2.1, 1, n + 12, .9, 90)
        for n in chord('D3', 'maj') + [m('A3')]: s.note(3.0, 1, n + 12, 2.8, 104); s.note(3.0, 2, n + 12, 2.8, 100)
        for k in range(10): s.note(3.0 + k * .07, 4, m('D6') + [0, 4, 7, 12, 16][k % 5], .6, 90)
        for k in range(14): s.note(2.2 + k * .05, 3, m('D2'), .1, 60 + k * 4)
        s.note(3.0, 3, m('D2'), .8, 127)
    return fsynth(f, 6.8, room=.85)

# ── effects ─────────────────────────────────────────────────────
def gm(fn, sec, room=.7, level=.55): return st(fsynth(fn, sec, room, level))
def sfx():
    S = {}
    S['spin'] = hall(mix((0, whoosh(.55, 300, 1800, 1, 2.5), .9), (0, thump(55, .35, .8), .6), (0, click(.02, 2500), .4)), 1.0, .2)
    S['stop'] = mix((0, thump(78, .28, .6), 1), (0, click(.025, 2800), .5), (.01, chime([1320], .3, .06), .08))
    S['stop_fb'] = hall(mix((0, thump(70, .35, .8), 1), (0, lp(noise(.4), 2200) * env(int(.4 * SR), .002, tau=.07), .9), (.02, crackle(.5, 90, seed=5), .5), (.03, chime([1568, 2349], .8, .25), .18)), 1.2, .22)
    S['wild'] = wild_sfx()
    S['fb_land'] = hall(mix((0, thump(140, .45, 1.2), .8), (0, lp(noise(.5), 1600) * env(int(.5 * SR), .003, tau=.09), 1), (.04, crackle(.7, 110, seed=7), .45)), 1.4, .25)
    S['egg_fill'] = hall(mix((0, gm(lambda s: (s.prog(0, CELESTA, rev=90), [s.note(i * .06, 0, m(n), .5, 96) for i, n in enumerate(['A5', 'D6', 'F6'])]), 1.2), 1), (.0, sparkle(.6, 8, 3500, 8000, 4), .35)), 1.4, .3)
    S['egg_ready'] = hall(mix((0, gm(lambda s: (s.prog(0, HARP, rev=100), s.prog(1, PAD_HALO, rev=100, vol=90), s.prog(2, GLOCK, rev=100), [s.note(i * .045, 0, m(n), 1.2, 100) for i, n in enumerate(['D5', 'F5', 'A5', 'D6', 'F6', 'A6'])], [s.note(.2, 1, m(n), 1.6, 80) for n in ['D4', 'F4', 'A4', 'D5']], s.note(.3, 2, m('D7'), 1, 96)), 2.6), 1), (.2, sparkle(1.4, 20), .3)), 2.0, .3)
    crack = lay(((t, click(.012, f) * a) for t, f, a in [(0, 5000, 1), (.035, 3500, .8), (.07, 6000, .6), (.11, 4200, .5)]), .4)
    S['egg_crack'] = hall(mix((0, crack, 1.2), (.12, lp(noise(.6), 3000) * env(int(.6 * SR), .004, tau=.12), .9), (.12, thump(90, .5, 1), .7), (.14, gm(lambda s: (s.prog(0, CHIMES, rev=100), s.prog(1, BRASS, rev=90, vol=100), [s.note(0, 0, m(n), 1.5, 100) for n in ['D5', 'A5']], [s.note(0, 1, m(n), .7, 100) for n in ['D4', 'F#4', 'A4']]), 2.0), .8), (.12, crackle(1, 80, seed=8), .4)), 2.2, .3)
    # Phoenix Firestorm: rumble rises, the fire roars, choir and brass, a boom (announcer at 1.2s)
    rise = st(roar(4.6, 50, 1600, 9, seed=11)) * np.clip(np.linspace(0, 1.4, int(4.6 * SR)), 0, 1)[:, None] ** 1.5
    sub = thump(42, 3.5, .1) * np.linspace(.3, 1, int(3.5 * SR))
    orch = gm(lambda s: (s.prog(0, CHOIR, rev=110, vol=110), s.prog(1, BRASS, rev=100, vol=120), s.prog(2, TIMP, rev=90, vol=120), s.prog(3, ORCHHIT, rev=90, vol=120), s.prog(4, STR, rev=100, vol=110), s.prog(5, CYMB, rev=100, vol=90),
                          [s.note(.2 + k * .06, 2, m('D2'), .1, 50 + k * 3) for k in range(16)],
                          [s.note(1.15, 1, m(n), 1.8, 120) for n in ['D3', 'A3', 'D4', 'F4']], [s.note(1.15, 0, m(n), 3.0, 110) for n in ['D4', 'F4', 'A4', 'D5']],
                          s.note(1.15, 3, m('D4'), .6, 127), s.note(1.15, 2, m('D2'), 1.2, 127), [s.note(2.6, 4, m(n), 2, 110) for n in ['D4', 'F4', 'A4', 'D5', 'F5']], s.note(2.6, 1, m('Bb3'), 1.6, 115), s.note(2.6, 1, m('F4'), 1.6, 115),
                          s.note(3.6, 3, m('D4'), .6, 127), s.note(3.6, 2, m('D2'), 1.4, 127), [s.note(3.6, 1, m(n), 1.6, 127) for n in ['D3', 'A3', 'D4', 'F#4', 'A4']]), 6.5, .85, .7)
    S['firestorm'] = hall(mix((0, rise, .5), (0, sub, .5), (0, orch, 1.0), (.9, phoenix_cry(1.6, 1300, 5), .3), (1.1, whoosh(1.2, 150, 3000, 4, 2), .5), (3.55, thump(48, 1.8, 1.5), .8)), 3.0, .3)
    S['arealink'] = hall(mix((0, gm(lambda s: (s.prog(0, TAIKO, rev=60, vol=127), s.prog(1, BRASS, rev=90, vol=118), s.prog(2, STR, rev=90, vol=100), s.prog(3, TIMP, rev=80, vol=110), s.prog(4, GLOCK, rev=90, vol=90),
                          [s.note(t, 0, m('C2'), .3, v) for t, v in [(0, 127), (.25, 100), (.5, 120), (1.0, 127)]], [s.note(1.0, 1, m(n), 1.4, 116) for n in ['D4', 'F4', 'A4']], s.note(1.4, 1, m('C5'), .25, 110), s.note(1.65, 1, m('D5'), 1.2, 118),
                          [s.note(1.0, 2, m(n), 2, 100) for n in ['D3', 'A3', 'D4']], s.note(1.0, 3, m('D2'), .8, 120), [s.note(1.65 + k * .06, 4, m(n), .8, 90) for k, n in enumerate(['D6', 'F6', 'A6', 'D7'])]), 3.4), 1), (0, whoosh(.9, 200, 2500, 6, 2.5), .5), (.05, crackle(1.2, 60, seed=9), .3)), 1.6, .25)
    S['respin'] = mix((0, whoosh(.7, 500, 1400, 7, 4), .6), (0, bp(noise(.7), 900, 3000) * (0.5 + .5 * np.sin(2 * np.pi * 26 * T(.7))) * env(int(.7 * SR), .05, tau=.3), .25))
    S['lock'] = hall(mix((0, thump(160, .25, .4), .7), (0, click(.02, 4200), .8), (.005, chime([2093, 3136], .6, .15, 1.05), .3), (0, lp(noise(.25), 1800) * env(int(.25 * SR), .002, tau=.05), .5)), .8, .2)
    S['reset'] = hall(lay(((t, chime([f], .5, .15)) for t, f in [(0, 1760), (.08, 2217), (.16, 2637)]), .9), .9, .25)
    S['tick'] = mix((0, click(.02, 3000), .6), (0, chime([2600], .12, .03), .2))
    S['mult'] = hall(mix((0, whoosh(.6, 400, 4000, 8, 2), .6), (.45, gm(lambda s: (s.prog(0, SYNBR, rev=90, vol=118), s.prog(1, GLOCK, rev=90), [s.note(0, 0, m(n), .6, 115) for n in ['F4', 'A4', 'C5', 'F5']], [s.note(k * .05, 1, m(n), .7, 100) for k, n in enumerate(['C6', 'F6', 'A6', 'C7'])]), 1.6), .9), (.45, sparkle(.8, 12), .3)), 1.6, .28)
    suck = whoosh(.75, 4000, 250, 9, 2.5) * np.linspace(.2, 1.2, int(.75 * SR))
    S['red'] = hall(mix((0, suck, .8), (.72, thump(60, .9, 1.4), 1), (.72, lp(noise(.7), 2500) * env(int(.7 * SR), .002, tau=.15), .8), (.75, lay(((i * .04, coinclink(i)) for i in range(10)), 1.1), .35), (.75, crackle(1, 120, seed=10), .4)), 2.0, .3)
    zaps = lay(((t, np.sin(2 * np.pi * np.cumsum(np.linspace(f, f * .4, int(.18 * SR))) / SR) * env(int(.18 * SR), .002, tau=.05)) for t, f in [(0, 3200), (.09, 2600), (.18, 3600), (.3, 2900)]), 1.0)
    S['blue'] = hall(mix((0, zaps, .5), (0, sparkle(1, 20, 3000, 9000, 6), .45), (.05, gm(lambda s: (s.prog(0, CELESTA, rev=100), [s.note(k * .05, 0, m(n), .6, 96) for k, n in enumerate(['E6', 'B5', 'G#5', 'E5'])]), 1.0), .7)), 1.4, .3)
    S['green'] = hall(mix((0, gm(lambda s: (s.prog(0, MARIMBA, rev=80, vol=110), s.prog(1, HARP, rev=90), [s.note(k * .06, 0, m(n), .3, 100) for k, n in enumerate(['G4', 'B4', 'D5', 'G5'])], s.note(.24, 1, m('G6'), .8, 90)), 1.2), 1), (.1, sparkle(.6, 8, 2500, 6000, 7), .25)), 1.2, .28)
    swell = gm(lambda s: (s.prog(0, PAD_HALO, rev=110, vol=110), s.prog(1, CHOIR, rev=110, vol=90), s.prog(2, CHIMES, rev=100), [s.note(0, 0, m(n), 1.6, 100) for n in ['E4', 'G#4', 'B4', 'E5']], [s.note(.3, 1, m(n), 1.6, 90) for n in ['E4', 'B4']], s.note(1.2, 2, m('E5'), 1.2, 100)), 3.0)
    S['magenta'] = hall(mix((0, whoosh(1.2, 120, 3500, 10, 2) * np.linspace(.2, 1, int(1.2 * SR)), .7), (0, swell, 1), (1.1, sparkle(1.2, 22, 3000, 9000, 8), .35), (1.15, thump(70, .6, .8), .5)), 2.4, .32)
    S['near'] = hall(gm(lambda s: (s.prog(0, TIMP, rev=70, vol=110), s.prog(1, TREM, rev=90, vol=100), [s.note(k * .07, 0, m('A1'), .1, 40 + k * 4) for k in range(18)], [s.note(0, 1, m(n), 1.4, 90) for n in ['A5', 'Bb5']]), 2.0), 1.2, .2)
    S['complete'] = hall(gm(lambda s: (s.prog(0, BRASS, rev=100, vol=118), s.prog(1, STR, rev=100, vol=100), s.prog(2, TIMP, rev=80, vol=110), s.prog(3, GLOCK, rev=90, vol=90),
                                       [s.note(0, 0, m(n), .3, 104) for n in ['C4', 'E4', 'G4']], [s.note(.32, 0, m(n), 1.6, 116) for n in ['D4', 'F#4', 'A4', 'D5']], [s.note(.32, 1, m(n), 1.8, 100) for n in ['D3', 'A3', 'D4', 'F#4']], s.note(.32, 2, m('D2'), .8, 120), [s.note(.32 + k * .06, 3, m(n), .7, 96) for k, n in enumerate(['D6', 'F#6', 'A6', 'D7'])]), 2.6), 1.6, .25)
    S['win_s'] = hall(gm(lambda s: (s.prog(0, CELESTA, rev=90), [s.note(k * .07, 0, m(n), .5, 90) for k, n in enumerate(['D5', 'F#5', 'A5'])]), 1.0), .8, .25)
    S['win_m'] = hall(mix((0, gm(lambda s: (s.prog(0, HARP, rev=90, vol=110), s.prog(1, GLOCK, rev=90), [s.note(k * .06, 0, m(n), .6, 100) for k, n in enumerate(['D5', 'F#5', 'A5', 'D6', 'F#6'])], s.note(.3, 1, m('A6'), .8, 96)), 1.6), 1), (.1, lay(((i * .07, coinclink(i)) for i in range(5)), 1), .2)), 1.2, .25)
    S['win_b'] = hall(mix((0, gm(lambda s: (s.prog(0, BRASS, rev=100, vol=118), s.prog(1, STR, rev=100), s.prog(2, GLOCK, rev=90), s.prog(3, CYMB, rev=100, vol=80), [s.note(k * .08, 0, m(n), .4 if k < 3 else 1.4, 110) for k, n in enumerate(['D4', 'F#4', 'A4', 'D5'])], [s.note(.24, 1, m(n), 1.6, 96) for n in ['D4', 'A4', 'D5']], [s.note(.24 + k * .05, 2, m(n), .7, 96) for k, n in enumerate(['D6', 'F#6', 'A6', 'D7', 'F#7'])], s.note(.24, 3, m('C5'), 1, 80)), 2.4), 1), (.25, lay(((i * .05, coinclink(i)) for i in range(12)), 1.4), .25)), 1.6, .28)
    # four jackpots, each its own jingle, bigger every tier
    def jp(level):
        def f(s):
            s.prog(0, GLOCK, rev=100, vol=110); s.prog(1, BRASS, rev=100, vol=120); s.prog(2, STR, rev=100, vol=110); s.prog(3, CHOIR, rev=110, vol=110); s.prog(4, TIMP, rev=90, vol=120); s.prog(5, CHIMES, rev=100, vol=110); s.prog(6, ORCHHIT, rev=90, vol=120); s.prog(7, TPT, rev=100, vol=118, pan=80)
            key = {0: 'E', 1: 'F', 2: 'D', 3: 'D'}[level]
            r = m(f'{key}4')
            if level == 0:
                for k, o in enumerate([0, 4, 7, 12, 16, 19, 24]): s.note(k * .07, 0, r + 12 + o, .6, 104)
                for o in [0, 4, 7]: s.note(.5, 5, r + 12 + o, 1.2, 100)
            if level >= 1:
                for k, o in enumerate([0, 4, 7, 12]): s.note(k * .1, 1, r + o, .3 if k < 3 else 1.4, 116); s.note(k * .1, 7, r + 12 + o, .3 if k < 3 else 1.4, 100)
                for o in [0, 4, 7, 12]: s.note(.3, 2, r - 12 + o, 1.8, 100)
                for k in range(8): s.note(.3 + k * .05, 0, r + 24 + [0, 4, 7, 12][k % 4], .5, 96)
            if level >= 2:
                s.note(0, 6, r, .5, 127); s.note(1.4, 6, r, .5, 127)
                for o in [0, 4, 7, 12]: s.note(1.4, 3, r + o, 2.2, 110); s.note(1.4, 1, r + o - 12, 2.2, 120)
                for k, (o, t) in enumerate([(7, 1.0), (9, 1.15), (11, 1.25)]): s.note(t, 7, r + 12 + o, .15, 110)
                for k in range(12): s.note(.9 + k * .04, 4, r - 24, .08, 60 + k * 5)
                s.note(1.4, 4, r - 24, 1, 127)
            if level >= 3:
                for o in [5, 9, 12]: s.note(3.2, 1, r + o - 12, .5, 120); s.note(3.2, 2, r + o, .5, 110)
                for o in [7, 11, 14]: s.note(3.7, 1, r + o - 12, .5, 120); s.note(3.7, 2, r + o, .5, 110)
                for o in [0, 4, 7, 12, 16]: s.note(4.2, 1, r + o - 12, 3, 127); s.note(4.2, 3, r + o, 3, 120); s.note(4.2, 2, r + o, 3, 120)
                s.note(4.2, 6, r, .6, 127); s.note(4.2, 4, r - 24, 1.4, 127)
                for k in range(16): s.note(4.2 + k * .06, 0, r + 24 + [0, 4, 7, 12][k % 4], .5, 100)
        sec = [2.0, 3.0, 4.4, 8.0][level]
        x = gm(f, sec, .85, .65)
        if level == 3: x = mix((0, x, 1), (4.15, thump(45, 2.2, 1.6), .8), (4.2, sparkle(2.5, 40, 2500, 9000, 12), .4), (4.2, lay(((i * .05, coinclink(i)) for i in range(30)), 2.6), .25))
        if level == 2: x = mix((0, x, 1), (1.35, thump(50, 1.4, 1.3), .7), (1.4, sparkle(1.6, 26, 3000, 9000, 13), .35))
        return hall(x, 2.2, .25)
    for i, t in enumerate(['mini', 'minor', 'major', 'grand']): S[f'jp_{t}'] = jp(i)
    S['coin'] = hall(coinclink(3), .5, .15)
    S['count'] = lay(((i * .055, coinclink(i) * (.5 + .5 * (i % 2))) for i in range(18)), 1.3)
    for k, x in S.items(): save(f'sfx/{k}', fadeout(tail_trim(x, 3e-4), .05), -1.5 if not k.startswith('jp_') else -1.0)

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('music', 'all'):
        save('music/base', base_music(), -3); save('music/bonus', bonus_music(), -2); save('music/win', fadeout(sting('win'), .4), -2, 96); save('music/jackpot', fadeout(sting('jackpot'), .6), -1.5, 96)
    if what in ('sfx', 'all'): sfx()
    if what in ('voice', 'all'): voices()
