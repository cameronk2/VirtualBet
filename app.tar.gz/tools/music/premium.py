import sys; sys.path.insert(0,'/tmp/claude-0/sfx')
import numpy as np, scipy.signal as sg, scipy.io.wavfile as wf
from gongs import gong, hall, save, SR
def predelay(x, ms): 
    n=int(ms*SR/1000); return np.concatenate([np.zeros((n,)+x.shape[1:]),x])
def lush(dry, secs=4.2, wet=0.4, seed=0):
    # two-stage space: a short early room plus a long dark hall with 25 ms pre-delay
    early=hall(dry,0.6,0.25,seed=seed+10,damp=6000)
    tail=hall(dry,secs,1.0,seed=seed,damp=4200)[:, :]
    tail=predelay(tail,25)
    n=max(len(early),len(tail)); out=np.zeros((n,2)); out[:len(early)]+=early; out[:len(tail)]+=tail*wet
    return out
for i,(f,b) in enumerate([(147,0.25),(165,0.3),(185,0.22),(196,0.28)]):
    g=gong(f,4.2,partials=72,tilt=0.98,bloom=b,bright=1.0,glide=0.012,glide_tau=0.4,seed=60+i,strike=0.75,decay=1.15)
    # a quiet shimmer an octave and a fifth up, for the "premium" sparkle
    sh=gong(f*3.01,2.0,partials=24,tilt=1.3,seed=70+i,strike=0.1,decay=0.6)*0.12
    x=g.copy(); x[:len(sh)]+=sh
    save(f'gong_land_{i+1}', lush(x,4.5,0.42,seed=i))
