# Blackjack sound package, free tools only:
#   * announcer: Kokoro-82M (Apache 2.0), British female voice "bf_emma", through onnxruntime + ffmpeg
#   * lounge jazz loop and stings: FluidSynth + FluidR3 Mono GM soundfont (MIT)
#   * bust / double / blackjack effects: numpy synthesis mixed with FluidSynth parts
# Output: client/audio/blackjack/{music,voice,sfx}/*.mp3
# Usage: python3 blackjack.py [voice|music|sfx|all]
import sys, os, json, subprocess, numpy as np, scipy.io.wavfile as wf
sys.path.insert(0, os.path.dirname(__file__))
from fs import Synth, m, SR
import phoenix as P   # shared DSP helpers (filters, reverb, synth voices)
OUT = os.path.join(os.path.dirname(__file__), '../../client/audio/blackjack')
TMP = '/tmp/claude-0/bjx'; os.makedirs(TMP, exist_ok=True)
for d in ('music', 'voice', 'sfx'): os.makedirs(f'{OUT}/{d}', exist_ok=True)

# British pronunciations (Kokoro/misaki phoneme set: A = "ay", I = "eye", W = "ow")
NUM = {4: 'fˈɔː', 5: 'fˈIv', 6: 'sˈɪks', 7: 'sˈɛvən', 8: 'ˈAt', 9: 'nˈIn', 10: 'tˈɛn', 11: 'ɪlˈɛvən', 12: 'twˈɛlv',
       13: 'θˌɜːtˈiːn', 14: 'fˌɔːtˈiːn', 15: 'fˌɪftˈiːn', 16: 'sˌɪkstˈiːn', 17: 'sˌɛvəntˈiːn', 18: 'ˌAtˈiːn', 19: 'nˌIntˈiːn',
       20: 'twˈɛnti', 21: 'twˈɛnti wˈʌn'}
def lines():
    L = {}
    for n, ph in NUM.items(): L[f't{n}'] = (ph[0].upper() + ph[1:] if False else ph) + '.'
    for n in range(12, 21): L[f's{n}'] = f'sˈɒft {NUM[n]}.'
    for n in range(17, 22): L[f'd{n}'] = f'dˈiːlə hɐz {NUM[n]}.'
    L.update({'blackjack': 'blˈækʤæk!', 'bust': 'bˈʌst!', 'double': 'dˈʌbəl dˈWn!', 'split': 'splˈɪt.', 'dbust': 'dˈiːlə bˈʌsts!',
              'push': 'pˈʊʃ.', 'win': 'juː wˈɪn!', 'lose': 'dˈiːlə wˈɪnz.', 'dbj': 'dˈiːlə hɐz blˈækʤæk.'})
    return L

def voices(voice='bf_emma'):
    import onnxruntime as ort
    cfg = json.load(open('/tmp/claude-0/ko/src/kokoro_onnx/config.json')); vocab = cfg['vocab']
    sess = ort.InferenceSession('/tmp/claude-0/kk/kokoro-v1.0.int8.onnx'); vs = np.load('/tmp/claude-0/kk/voices-v1.0.bin')
    tk = 'input_ids' if 'input_ids' in {i.name for i in sess.get_inputs()} else 'tokens'
    for k, ph in lines().items():
        toks = [vocab[c] for c in ph if c in vocab]
        speed = 0.92 if k in ('blackjack', 'bust', 'double', 'win') else 0.98
        a = sess.run(None, {tk: np.array([[0, *toks, 0]], dtype=np.int64), 'style': vs[voice][len(toks)].astype(np.float32), 'speed': np.array([speed], dtype=np.float32)})[0].reshape(-1)
        a = a / (np.abs(a).max() + 1e-9)
        raw = f'{TMP}/{k}.wav'; wf.write(raw, 24000, a.astype(np.float32))
        # clean, warm and present; a touch of room; trimmed silence so the call lands right on the card
        af = ('silenceremove=start_periods=1:start_threshold=-45dB:stop_periods=1:stop_threshold=-45dB:stop_duration=0.15,'
              'aresample=44100,highpass=f=90,equalizer=f=250:t=q:w=1:g=-2,equalizer=f=3500:t=q:w=1.2:g=3,'
              'acompressor=threshold=-20dB:ratio=3:attack=4:release=100,aecho=0.8:0.4:45:0.12,volume=10dB,alimiter=limit=0.9')
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '1', '-codec:a', 'libmp3lame', '-b:a', '64k', f'{OUT}/voice/{k}.mp3'], check=True)
    print('voice lines', len(lines()))

# ── lounge jazz ─────────────────────────────────────────────────
PIANO, EPIANO, BASS, VIBES, TSAX, MUTED, DRUMS = 0, 4, 32, 11, 66, 59, 9
def chord_tones(root, q):
    r = m(root)
    return {'m7': [r, r + 3, r + 7, r + 10], '7': [r, r + 4, r + 7, r + 10], 'maj7': [r, r + 4, r + 7, r + 11], 'm7b5': [r, r + 3, r + 6, r + 10]}[q]
# a 16-bar loop in F: ii-V-I with turnarounds
PROG = [('G2', 'm7'), ('C3', '7'), ('F2', 'maj7'), ('D2', '7'), ('G2', 'm7'), ('C3', '7'), ('A2', 'm7'), ('D2', '7'),
        ('Bb2', 'maj7'), ('Bb2', 'm7'), ('A2', 'm7'), ('D2', '7'), ('G2', 'm7'), ('C3', '7'), ('F2', 'maj7'), ('C3', '7')]
def music():
    bpm = 104; beat = 60 / bpm; sw = beat * 2 / 3   # swing eighths
    bars = len(PROG) * 2; sec = bars * 4 * beat
    rng = np.random.default_rng(5)
    def f(s):
        s.prog(0, EPIANO, rev=60, vol=78, pan=50); s.prog(1, BASS, rev=40, vol=100, pan=64); s.prog(2, VIBES, rev=70, vol=66, pan=84); s.prog(3, TSAX, rev=70, vol=74, pan=70)
        s.cc(0, DRUMS, 7, 70); s.cc(0, DRUMS, 91, 50)
        for b in range(bars):
            root, q = PROG[b % len(PROG)]; t0 = b * 4 * beat; ch = chord_tones(root, q)
            # walking bass: root, chord tone, approach, chromatic lead into next bar
            nxt = m(PROG[(b + 1) % len(PROG)][0])
            walk = [ch[0], ch[1] if rng.random() < .5 else ch[2], ch[2] if rng.random() < .5 else ch[0] + 12 - 5, nxt + (1 if rng.random() < .5 else -1)]
            for i, n in enumerate(walk): s.note(t0 + i * beat, 1, n - 12 if n > m('E3') else n, beat * .9, 88 + (8 if i == 0 else 0))
            # piano comping: shell voicings on 2-and and 4 (Charleston-ish)
            voic = [ch[1] + 12, ch[3] + 12, ch[2] + 12 + (2 if q != 'm7b5' else 0)]
            for t, d, v in [(beat * 1 + sw, beat * .5, 58), (beat * 3, beat * .7, 52)] if b % 2 == 0 else [(0, beat * .6, 56), (beat * 2 + sw, beat * .5, 54)]:
                for n in voic: s.note(t0 + t, 0, n, d, v + rng.integers(-4, 4))
            # brushes: ride pattern, soft hi-hat on 2 and 4, feathered kick
            for i in range(4):
                s.note(t0 + i * beat, DRUMS, 51, .2, 50 + (8 if i % 2 else 0));
                if i % 2: s.note(t0 + i * beat + sw, DRUMS, 51, .15, 38)
                if i % 2: s.note(t0 + i * beat, DRUMS, 44, .1, 50)
                s.note(t0 + i * beat, DRUMS, 36, .1, 26)
            if b % 4 == 3: s.note(t0 + 3 * beat + sw, DRUMS, 38, .1, 40)
        # sax melody on the second chorus, vibes answering
        mel = [('A4', 1), ('C5', .67), ('D5', .33), ('F5', 1.5), ('E5', .5), ('D5', 1), ('C5', 1), ('A4', 2), ('-', 2),
               ('Bb4', 1), ('D5', .67), ('F5', .33), ('A5', 1.5), ('G5', .5), ('F5', 1), ('E5', 1), ('C5', 2), ('-', 2),
               ('D5', 1), ('F5', .67), ('A5', .33), ('C6', 1), ('Bb5', 1), ('A5', 1), ('G5', 1), ('F5', 1), ('D5', 1), ('C5', 2), ('-', 2),
               ('A4', 1), ('Bb4', 1), ('C5', 1), ('E5', 1), ('F5', 4), ('-', 4)]
        t = len(PROG) * 4 * beat
        for n, d in mel:
            if n != '-': s.note(t, 3, m(n) - 12, d * beat * .92, 70 + rng.integers(-6, 6))
            t += d * beat
        for b in range(0, len(PROG), 2): s.note(b * 4 * beat + 3 * beat, 2, m('F5') + [0, 4, 7, 9][(b // 2) % 4], 1.2, 44)
    x = P.st(P.fsynth(f, sec + 3, room=.55, level=.4))
    P.save('../blackjack/music/base', x[:int((sec + 2) * SR)], -3, 80)

def stings_and_sfx():
    def gm(fn, sec): return P.st(P.fsynth(fn, sec, .7, .5))
    # Blackjack!: a bright brass-and-vibes flourish with sparkle
    bj = gm(lambda s: (s.prog(0, 61, rev=90, vol=118), s.prog(1, VIBES, rev=90, vol=100), s.prog(2, 48, rev=90, vol=96),
                       [s.note(i * .09, 0, m(n), .3 if i < 3 else 1.4, 110) for i, n in enumerate(['F4', 'A4', 'C5', 'F5'])],
                       [s.note(.27 + i * .05, 1, m(n), .8, 96) for i, n in enumerate(['F5', 'A5', 'C6', 'E6', 'F6'])],
                       [s.note(.27, 2, m(n), 1.6, 90) for n in ['F3', 'C4', 'A4', 'E5']]), 2.6)
    P.save('../blackjack/sfx/blackjack', P.hall(P.mix((0, bj, 1), (.27, P.sparkle(1.2, 20), .3)), 1.6, .25), -1.5)
    # Bust: a dull felt thud, a cracking snap and a falling muted-trumpet "wah-wah"
    crack = P.lay(((t, P.click(.014, f) * a) for t, f, a in [(0, 3800, 1), (.03, 2600, .8), (.06, 4500, .5)]), .3)
    wah = gm(lambda s: (s.prog(0, MUTED, rev=60, vol=110), s.note(.0, 0, m('C4'), .32, 96), s.note(.34, 0, m('B3'), .32, 92), s.note(.68, 0, m('Bb3'), 1.0, 90),
                        s.bend(.8, 0, 8192), *[s.bend(.8 + k * .03, 0, 8192 - k * 220) for k in range(1, 20)]), 2.2)
    P.save('../blackjack/sfx/bust', P.hall(P.mix((0, P.thump(70, .45, .8), .9), (0, crack, .8), (.12, wah, .9)), 1.0, .2), -2)
    # Double down: chips sliding and stacking, then a confident rising stab
    chips = P.lay(((i * .055, P.coinclink(i) * (.6 + .4 * (i % 2))) for i in range(7)), .8)
    slide = P.bp(P.noise(.35), 1500, 6000) * P.env(int(.35 * SR), .05, tau=.12)
    stab = gm(lambda s: (s.prog(0, 61, rev=80, vol=110), [s.note(0, 0, m(n), .5, 104) for n in ['C4', 'E4', 'G4', 'C5']]), 1.2)
    P.save('../blackjack/sfx/double', P.hall(P.mix((0, slide, .5), (.08, chips, .5), (.45, stab, .8)), 1.0, .2), -2)
    # Win / push / lose stings (short, so they never step on the announcer)
    win = gm(lambda s: (s.prog(0, VIBES, rev=90, vol=110), s.prog(1, EPIANO, rev=80, vol=90), [s.note(i * .07, 0, m(n), .9, 100) for i, n in enumerate(['C5', 'E5', 'G5', 'C6'])], [s.note(.21, 1, m(n), 1.2, 80) for n in ['C4', 'E4', 'G4', 'B4']]), 1.8)
    P.save('../blackjack/sfx/win', P.hall(P.mix((0, win, 1), (.1, P.lay(((i * .06, P.coinclink(i)) for i in range(6)), .8), .25)), 1.2, .22), -2)
    push = gm(lambda s: (s.prog(0, VIBES, rev=90, vol=100), s.note(0, 0, m('G5'), .8, 80), s.note(.12, 0, m('G5'), .8, 70)), 1.2)
    P.save('../blackjack/sfx/push', P.hall(push, 1, .2), -4)
    lose = gm(lambda s: (s.prog(0, EPIANO, rev=80, vol=90), s.note(0, 0, m('E4'), .5, 70), s.note(.18, 0, m('C4'), .9, 64)), 1.4)
    P.save('../blackjack/sfx/lose', P.hall(lose, 1, .2), -5)

if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('voice', 'all'): voices()
    if what in ('music', 'all'): music()
    if what in ('sfx', 'all'): stings_and_sfx()
