import sys; sys.path.insert(0,'/tmp/claude-0/mu')
import numpy as np, random, scipy.io.wavfile as wf
from fs import Synth, m, SR
random.seed(7)
KOTO,SHAM,SHAKU,FLUTE,FIDDLE,STR,PIZZ,TAIKO,WOOD,ORCH,HARP,BRASS,TIMP,CHOIR=107,106,77,73,110,48,45,116,115,55,46,61,47,52
def mel(s,ch,start,beat,seq,vel=96,leg=1.0,swell=False):
    t=start
    for n,b in seq:
        if n!='-':
            d=b*beat*leg; v=vel+random.randint(-6,6)
            s.note(t,ch,m(n),d,v)
            if swell and b>=1.5:   # erhu-like: expression swell
                for k in range(8): s.cc(t+d*k/8,ch,11,70+int(57*min(1,k/3)))
        t+=b*beat
    return t
def chordtones(root,kind):
    r=m(root); return {'maj':[r,r+4,r+7],'min':[r,r+3,r+7],'sus2':[r,r+2,r+7],'sus4':[r,r+5,r+7]}[kind]
def koto_arp(s,ch,t,beat,ch_,vel=78,pattern=(0,1,2,3,4,3,2,1),octs=12):
    tones=ch_+[x+12 for x in ch_]+[x+24 for x in ch_]
    for i,p in enumerate(pattern):
        s.note(t+i*beat/2,ch,tones[p]+octs,beat*1.6,vel+(10 if i%4==0 else 0)+random.randint(-5,5))
def bars_to_sec(n,bpm): return n*4*60/bpm

def write(name,a,gain_db=-1.0):
    pk=np.abs(a).max(); a=a/pk*10**(gain_db/20)
    wf.write(f'/tmp/claude-0/mu/{name}.wav',SR,a.astype(np.float32)); print(name,round(len(a)/SR,2),'s')

# ── BASE: festive, D major pentatonic, 96 bpm, 16 bars ────────────
def base():
    bpm=92; beat=60/bpm; s=Synth(room=0.75,level=0.6)
    s.prog(0,KOTO,pan=40,rev=70); s.prog(1,FLUTE,pan=76,rev=80,vol=96); s.prog(2,STR,pan=64,rev=90,vol=60); s.prog(3,PIZZ,pan=58,rev=50,vol=105)
    s.prog(4,TAIKO,pan=64,rev=40,vol=110); s.prog(5,WOOD,pan=90,rev=40,vol=70); s.prog(6,FIDDLE,pan=70,rev=85,vol=92); s.prog(7,HARP,pan=30,rev=80,vol=70)
    s.prog(9,0,rev=50,vol=80)
    prog=[('D3','maj'),('D3','maj'),('B2','min'),('B2','min'),('G2','maj'),('A2','sus4'),('D3','maj'),('D3','maj'),
          ('B2','min'),('G2','maj'),('D3','maj'),('A2','sus2'),('B2','min'),('G2','maj'),('A2','sus4'),('A2','maj')]
    A=[('F#5',1),('E5',.5),('D5',.5),('E5',1),('A5',1), ('F#5',1.5),('E5',.5),('D5',2),
       ('B4',1),('D5',.5),('E5',.5),('F#5',1),('E5',.5),('D5',.5), ('B4',3),('-',1),
       ('D5',1),('E5',.5),('F#5',.5),('A5',1),('B5',1), ('A5',1.5),('F#5',.5),('E5',1),('A4',1),
       ('B4',.5),('D5',.5),('E5',.5),('F#5',.5),('E5',1),('D5',1), ('D5',3),('-',1)]
    B=[('B4',1.5),('A4',.5),('F#4',1),('A4',1), ('B4',2),('D5',1),('B4',1), ('A4',1.5),('F#4',.5),('E4',1),('F#4',1), ('E4',3),('-',1),
       ('F#5',1.5),('E5',.5),('D5',1),('B4',1), ('D5',1.5),('B4',.5),('A4',1),('B4',1), ('A4',1),('B4',.5),('D5',.5),('E5',2), ('E5',2),('-',2)]
    N=16; reps=3  # render 3 passes; the loop is cut from the middle one so reverb tails carry across the seam
    for rep in range(reps):
        T0=rep*bars_to_sec(N,bpm)
        mel(s,1,T0,beat,A,vel=92,leg=0.95)
        mel(s,6,T0+bars_to_sec(8,bpm),beat,B,vel=96,leg=1.0,swell=True)
        for b,(root,kind) in enumerate(prog):
            t=T0+bars_to_sec(b,bpm); ct=chordtones(root,kind)
            koto_arp(s,0,t,beat,ct,vel=70 if b<8 else 64)
            for x in ct: s.note(t,2,x+12,4*beat*0.98,52)
            r=m(root); s.note(t,3,r,beat*0.9,100); s.note(t+2*beat,3,r+7,beat*0.9,88); s.note(t+3.5*beat,3,r+12 if b%2 else r+7,beat*0.4,72)
            s.note(t,4,m('C2') if b%2==0 else m('D2'),beat,112); s.note(t+2*beat,4,m('D2'),beat,86)
            if b%2==1: s.note(t+3.5*beat,4,m('D2'),beat,78)
            for k in (1,3): s.note(t+k*beat+beat/2*(b%2),5,m('E5'),beat/2,60+random.randint(-8,8))
            for k in range(8): s.note(t+k*beat/2,9,69,beat/3,30+(14 if k%2 else 0))   # cabasa
            if b in (0,8): s.note(t,9,52,beat*4,78)   # chinese cymbal
            if b in (7,15): # harp glissando into the next phrase
                gl=[m(x) for x in ['D4','E4','F#4','A4','B4','D5','E5','F#5','A5','B5','D6']]
                for i,n in enumerate(gl): s.note(t+3*beat+i*beat/11,7,n,beat*1.5,70+i*3)
    period=bars_to_sec(N,bpm)
    a=s.render(2*period+6)
    return a[int(period*SR):int((2*period+3)*SR)]

# ── BONUS: driving, E minor pentatonic, 128 bpm, 16 bars ─────────
def bonus():
    bpm=128; beat=60/bpm; s=Synth(room=0.6,level=0.45)
    s.prog(0,KOTO,pan=38,rev=55); s.prog(1,FIDDLE,pan=76,rev=70,vol=100); s.prog(2,STR,pan=64,rev=60,vol=80); s.prog(3,PIZZ,pan=56,rev=40,vol=110)
    s.prog(4,TAIKO,pan=64,rev=35,vol=120); s.prog(5,SHAM,pan=88,rev=45,vol=88); s.prog(6,BRASS,pan=50,rev=70,vol=70); s.prog(7,TIMP,pan=64,rev=50,vol=95)
    s.prog(9,0,rev=40,vol=85)
    prog=[('E3','min'),('E3','min'),('C3','maj'),('D3','maj'),('E3','min'),('E3','min'),('A2','min'),('B2','sus4'),
          ('E3','min'),('G2','maj'),('C3','maj'),('D3','maj'),('A2','min'),('C3','maj'),('B2','sus4'),('B2','min')]
    LEAD=[('B4',3),('A4',.5),('G4',.5), ('E4',4), ('G4',2),('A4',1),('B4',1), ('D5',3),('-',1),
          ('E5',3),('D5',.5),('B4',.5), ('A4',2),('G4',2), ('E4',1),('G4',1),('A4',1),('C5',1), ('B4',4),
          ('E5',2),('G5',2), ('D5',3),('B4',1), ('E5',2),('D5',1),('C5',1), ('D5',2),('A4',2),
          ('C5',2),('B4',1),('A4',1), ('G4',2),('E4',2), ('F#4',2),('A4',2), ('B4',4)]
    RIFF=['E5','G5','A5','B5','A5','G5','E5','D5']
    N=16; reps=3
    for rep in range(reps):
        T0=rep*bars_to_sec(N,bpm)
        mel(s,1,T0,beat,LEAD,vel=100,swell=True)
        for b,(root,kind) in enumerate(prog):
            t=T0+bars_to_sec(b,bpm); ct=chordtones(root,kind); r=m(root)
            # shamisen riff 8ths, transposed to fit chord
            sh={'E':0,'C':-4,'D':-2,'A':-7,'B':-5,'G':3}[root[0]]
            for i,n in enumerate(RIFF): s.note(t+i*beat/2,5,m(n)+sh-12,beat*0.4,80+(16 if i%4==0 else 0)+random.randint(-6,6))
            if b>=8: koto_arp(s,0,t,beat/2,ct,vel=62,pattern=(0,1,2,3,4,5,4,3,2,3,4,5,4,3,2,1),octs=12)
            # staccato strings ostinato 8ths
            for i in range(8): s.note(t+i*beat/2,2,ct[i%3]+12,beat*0.22,70+(18 if i%2==0 else 0))
            # bass
            for i,o in enumerate([0,0,12,0,7,0,12,7]): s.note(t+i*beat/2,3,r+o,beat*0.35,104 if i%2==0 else 84)
            # taiko groove
            for pos,v,n in [(0,120,'C2'),(1.5,90,'D2'),(2,112,'C2'),(2.75,80,'D2'),(3,100,'D2'),(3.5,90,'D2')]: s.note(t+pos*beat,4,m(n),beat,v)
            for k in range(8): s.note(t+k*beat/2,9,42 if k%2 else 46 if k==7 else 42,beat/4,50+(20 if k%2 else 0))
            for k in (1,3): s.note(t+k*beat,9,39,beat/2,80)   # claps on 2 and 4
            if b%4==3:
                for k in range(8): s.note(t+2*beat+k*beat/4,7,m('E2'),beat/4,60+k*8)  # timp roll into next phrase
            if b%4==0: s.note(t,9,52,beat*4,90); s.note(t,6,r+12,beat*3.5,80); s.note(t,6,r+19,beat*3.5,70)
    period=bars_to_sec(N,bpm)
    a=s.render(2*period+6)
    return a[int(period*SR):int((2*period+3)*SR)]

# ── STINGS ───────────────────────────────────────────────────────
def win():
    bpm=120; beat=0.5; s=Synth(room=0.8,level=0.7)
    s.prog(0,KOTO,pan=40,rev=80); s.prog(1,FLUTE,pan=80,rev=90); s.prog(2,STR,rev=90,vol=90); s.prog(4,TAIKO,rev=60,vol=120); s.prog(6,BRASS,rev=80,vol=90); s.prog(9,0,rev=70)
    gl=['D4','E4','F#4','A4','B4','D5','E5','F#5','A5','B5','D6','E6']
    for i,n in enumerate(gl): s.note(i*0.055,0,m(n),1.5,80+i*3)
    for n in ['D4','A4','D5','F#5']: s.note(0.7,2,m(n),2.6,95); s.note(0.7,6,m(n)-12,1.6,90)
    mel(s,1,0.7,beat,[('A5',.5),('B5',.5),('D6',2)],vel=105)
    s.note(0.7,4,m('C2'),1,127); s.note(0.7,9,52,3,110); s.note(0.0,9,49,3,70)
    return s.render(4.5)
def jackpot():
    s=Synth(room=0.9,level=0.75)
    s.prog(0,KOTO,pan=40,rev=80); s.prog(1,FLUTE,pan=80,rev=90); s.prog(2,STR,rev=90,vol=100); s.prog(3,CHOIR,rev=100,vol=90); s.prog(4,TAIKO,rev=60,vol=125); s.prog(6,BRASS,rev=80,vol=100); s.prog(7,TIMP,rev=60,vol=110); s.prog(9,0,rev=70)
    for k in range(16): s.note(k*0.075,7,m('D2'),0.1,50+k*4)    # timp roll
    for k in range(6): s.note(k*0.2,4,m('C2'),0.3,80+k*8)
    gl=['D4','E4','F#4','A4','B4','D5','E5','F#5','A5','B5','D6','E6','F#6']
    for i,n in enumerate(gl): s.note(0.6+i*0.045,0,m(n),2,85+i*2)
    for t,ch in [(1.25,['D3','A3','D4','F#4','A4','D5']),(3.0,['G3','B3','D4','G4','B4']),(3.9,['A3','E4','A4','C#5','E5']),(4.8,['D3','A3','D4','F#4','A4','D5','F#5'])]:
        d=3.6 if t>4 else 0.85 if t>1.3 else 1.7
        for n in ch: s.note(t,2,m(n),d,100); s.note(t,6,m(n)-12 if m(n)>60 else m(n),d*0.9,92); s.note(t,3,m(n),d,70)
        s.note(t,4,m('C2'),1,127); s.note(t,9,52 if t<4 else 49,3,115)
    mel(s,1,1.25,0.45,[('A5',1),('F#5',.5),('A5',.5),('B5',1),('D6',.5),('E6',.5),('F#6',1),('E6',.5),('D6',.5),('A5',1),('D6',4)],vel=110)
    return s.render(9)
import sys
which=sys.argv[1:] or ['base','bonus','win','jackpot']
for w in which: write(w,globals()[w]())
