# Fortune Live: rules and maths

Fortune Live is an original money-wheel game show for VirtualBet (virtual money only). It follows the
general format of TV money-wheel shows (number segments, bonus-game segments and a pre-spin
multiplier slot), with original names, art, music and host. Nothing in it is a live stream: the studio,
presenter and wheel are animated in the browser, and the server decides every result before anything moves.

## The round

1. **Betting**: chips on any of 8 spots (10p to £100 per spot). A betting timer (10 / 15 / 25 s, or off)
   closes bets; *Spin now* skips it. If no chips are down when the timer ends, it simply restarts.
2. **Fortune Booster**: two reels pick a spot and a multiplier (2x, 3x, 4x, 5x, 7x, 10x, 15x, 20x, 25x, 50x).
   When they line up (a "hit"), that spot is boosted for this round. At most one spot per round.
3. **The wheel**: 54 equal segments; the one under the pointer wins.
4. **Settlement**: numbers pay `bet × (1 + pay × boost)`. A bonus pays `bet × (1 + result × boost)`, capped at
   20,000x. Bets on other spots lose.

| Spot | Segments | Chance | Pays | Booster chance |
|---|---|---|---|---|
| 1 | 21 | 1 in 2.6 | 1:1 | 11.2% |
| 2 | 13 | 1 in 4.2 | 2:1 | 11.8% |
| 5 | 7 | 1 in 7.7 | 5:1 | 6.7% |
| 10 | 4 | 1 in 13.5 | 10:1 | 4.7% |
| Coin Toss | 4 | 1 in 13.5 | bonus | 5% |
| Prize Wall | 2 | 1 in 27 | bonus | 4% |
| Drop Zone | 2 | 1 in 27 | bonus | 4% |
| Fortune Frenzy | 1 | 1 in 54 | bonus | 4% |

## Bonus games

- **Coin Toss**: the red side draws a multiplier from the Coin Toss table and the blue side draws from the same table without red's value, so the two sides always differ; a fair flip decides. Its average is `Σ p_r (v_r + E[v | v ≠ v_r]) / 2`, and the table's first weight is solved by bisection to hit the target exactly.
- **Prize Wall**: 108 prizes drawn from the Prize Wall table, stored on the server (never sent to the browser
  before the pick). The player aims at one before a 15 s timer; if they don't, a random one is chosen.
  Because every position holds an independent draw, the choice can't change the expected return.
- **Drop Zone**: 16 slots, 14 with prizes from the Drop Zone table and 2 marked DOUBLE (random positions).
  The puck starts above a random slot and bounces left or right on each of 12 rows (walls reflect). On a
  DOUBLE every prize doubles and the puck drops again.
- **Fortune Frenzy**: 64 segments, 61 prizes from the Frenzy table, 2 DOUBLE, 1 TRIPLE. Three flappers sit
  21 and 43 segments apart. The player picks a flapper (12 s timer, else random); the wheel spins and that
  flapper's segment pays. DOUBLE / TRIPLE multiply every prize and the wheel spins again.

Players with no bet on the bonus that lands watch it with a random choice and can skip it.

## Maths

Every spot is set to return exactly 96%:

- Numbers: `RTP = P(segment) × (1 + pay × E[boost])`, where `E[boost] = 1 + p × (E[mult] − 1)`. The booster
  chance `p` for each number is solved from that equation (`config.js`).
- Bonuses: `RTP = P(segment) × (1 + E[result] × E[boost])`. For Drop Zone and Frenzy the doubling rules scale
  the table average by a constant (`7/6` and `61/57`: a landing on a multiplier segment happens with
  probability `d`, multiplies by `k`, and repeats, so `E = (1 − d) E[v] / (1 − Σ d·k)`). The weight of each
  table's lowest prize is solved so the bonus hits its target exactly.

`server/games/fortune/maths.js` gives the exact returns. `node scripts/sim-fortune.mjs <rounds>`
simulates them; the bonuses (and the boosted 10) are high-variance, so a few million rounds still wander by
about ±1%. A separate check of one million bonus games each matched the closed-form averages to within
0.3%. The 20,000x cap is reached so rarely that it moves the return by less than 0.05%.

## Sound and art

- Music, effects and host voice are made by `tools/music/fortune.py` with free tools only: FluidSynth with
  the FluidR3 Mono GM soundfont (MIT), numpy synthesis, and Kokoro-82M (Apache 2.0) with the British voice
  `bf_emma` (blended with `bf_isabella`). The host's words are in `client/src/pages/fortune/lines.json`
  and appear as captions.
- All art (wheels, icons, logo, studio, host) is original vector or canvas drawing.
