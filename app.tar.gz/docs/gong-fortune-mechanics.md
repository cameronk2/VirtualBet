# Gong Fortune: mechanics, sources and test results

Gong Fortune reproduces the published rules of IGT's *Tiger and Dragon: Cash on
Reels* with original artwork, sound and an original name. All art is vector
artwork drawn for this game; no IGT assets were used. "Cash on Reels" is IGT
branding, so the in-game feature is called **Mystery Gongs**.

Code: `server/games/tigerdragon/` (engine, config, gongs, reels) and
`client/src/pages/premium/tigerdragon/`. Maths tools: `scripts/sim-tigerdragon.mjs`,
`scripts/tune-tigerdragon.mjs`, `scripts/rtp-tigerdragon.mjs`. Tests:
`test/tigerdragon.test.js`.

## Sources

- VegasSlotsOnline game page (specs, paytable, triggers, bonus rules, bonus buy).
- Ispinix review (cluster reading, Arrow examples, grid sizes, buy names).
- Casino Player Magazine, "Tigers, Dragons and Jackpots" (the land-based Cash on
  Reels version: adjacent numbers read as one number, Arrows nudge the first digit,
  Lock & Respin "can start with three or more gongs", top rows start locked).
- IGT's Cash on Reels page (gongs "horizontally adjacent", arrows "boost the leftmost numbers").

The playable demo needs a browser session these tools can't run, so rules were
taken from the written sources only.

## What is confirmed, interpreted or estimated

| Rule | Status | Implementation |
|---|---|---|
| 5 reels, 3 rows, 243 ways from the leftmost reel | Confirmed | `evaluateWays` |
| Bet range 0.75 to 90 | Confirmed | stakes £0.75 to £90, plus 10p, 20p, 30p, 40p, 50p and £1 added for this site (16 bets in all; only listed bets are accepted) |
| RTP 96%, high volatility, max win 2,000x | Confirmed (targets) | tuned by simulation; 2,000x cap per spin and per bonus (trigger spin + bonus together) |
| Paytable: high (Envelope, Lotus, Lantern) 36/72/108, low (Fan, Bangle, Ornament) 18/54/90 at stake 90 | Confirmed | 0.40/0.80/1.20x and 0.20/0.60/1.00x of the stake, per way (linear scaling from the stake-90 figures is our reading) |
| No wild symbol | Confirmed by absence | none in any source |
| 3 Tigers: Tiger Bonus; 3 Dragons: Dragon Bonus; 5+ combined: Tiger & Dragon Bonus | Confirmed | combined takes priority (e.g. 3 Tigers + 2 Dragons) |
| Tiger Bonus: 3 spins, only gongs, gongs lock, reset to 3, ends at 0 or full grid, clusters of 2+ pay | Confirmed | 5 x 3 grid (grid size from Ispinix) |
| Dragon Bonus: exactly one spin on 5 x 8, clusters pay | Confirmed | no respin reset |
| Tiger & Dragon: 3 of 8 rows open; rows open at 6 / 9 / 14 / 19 / 25 gongs; new gongs reset to 3; 32 gongs win the jackpot | Confirmed | counts use every gong collected, including starting gongs |
| Bottom rows open first, top rows locked | Interpreted | "top rows start locked" (land-based description) |
| A row opened during a spin plays from the next spin | Interpreted | brief: "newly unlocked rows become available for subsequent spins" |
| Gong values 1 to 99 or an Arrow | Confirmed | |
| Cluster = 2+ gongs side by side in the same row | Confirmed ("horizontally adjacent") | vertical and diagonal neighbours do not connect: no source mentions them, so they don't |
| Cluster pays its numbers read left to right as one number | Confirmed (Ispinix: 8, 5, 0 reads 850; Casino Player: 1-5-5 pays $1.55) | |
| Arrow adds 1 to 90 to the cluster's leftmost number | Confirmed by examples (1 becomes 81: "125" to "8125"; 1 becomes 6: "120" to "620"; 5 becomes 10: "5350" to "10350") | an Arrow must be inside the cluster; several Arrows add up; a cluster of only Arrows pays nothing |
| Numbers are credits at 75 credits per spin | Interpreted | 0.75 minimum = 75 credits at 1p; a cluster pays credits x stake / 75, rounded to the nearest penny (so small stakes are not rounded down to nothing) |
| Mystery Gongs only after a non-winning base spin | Confirmed | not after a ways win or a bonus trigger |
| Bonus buy: random bonus 50x, Tiger & Dragon 100x | Confirmed | |
| Bonuses start with gongs where the triggering Tigers/Dragons landed | Interpreted | the land-based Lock & Respin "can start with three or more gongs". Bought bonuses get 3 (Tiger) or 5 (combined) starting gongs on random spots. The Dragon Bonus starts empty. |
| Jackpot amount | **Not published** | set to 2,000x (the published max win); replaces cluster pays |
| Symbol weights, gong land chances, gong value odds, Arrow odds, Mystery Gong rate, random-buy split | **Not published** | estimated and tuned by simulation (marked `[EST]` in config.js) |
| "One or two of either can trigger randomly" (Ispinix) | Not implemented | unclear and unsupported by other sources |
| "Luck Has Arrived": a random guaranteed bonus | **Not published** (described by the site owner) | on a base spin that did not trigger a bonus itself, 1 in 750 chance that luck arrives: the screen covers over with its own sound and a bonus is awarded (Tiger 45%, Dragon 45%, Tiger & Dragon 10%, started like a bought bonus). To keep the RTP, the Tiger/Dragon weight on each reel dropped from 1.95 to 1.84 |
| Wilds, scatter pays, retriggers, multipliers | Not in the game | no source mentions them; Tiger/Dragon only trigger bonuses; respins reset to 3 (that is the only "retrigger") |

## Configurable RTP

`RTP_PROFILES` in `config.js` holds three tuned profiles; set `GONG_FORTUNE_RTP` to 96 (default), 94 or 92.
Only the bonus land chances differ. Measured with `scripts/rtp-tigerdragon.mjs` (4 million base spins, 150,000 runs of each bonus):

Measured after Luck Has Arrived was added (8 million base spins, 150,000 runs of each bonus; bonus frequencies include lucky bonuses):

| Profile | Base ways | Mystery Gongs | Tiger | Dragon | Tiger & Dragon | Total | Random buy | T&D buy |
|---|---|---|---|---|---|---|---|---|
| 96 | 45.76% | 9.77% | 1 in 234, 46.1x (19.67%) | 1 in 236, 39.2x (16.60%) | 1 in 2,151, 95.5x (4.44%) | **96.25%** | 95.8% | 95.5% |
| 94 | 45.76% | 9.77% | 43.7x | 37.2x | 90.5x | **94.13%** | 90.9% | 90.5% |
| 92 | 45.76% | 9.77% | 41.9x | 34.2x | 85.2x | **91.89%** | 85.6% | 85.2% |

Luck Has Arrived contributes about 6.4% of the return (1 in 750 spins x about 48x average bonus).

Before luck was added the same measurement at 10p and £1 matched 75p exactly (all pays scale with the stake; rounding is to the nearest penny).

## Full-game simulation (96 profile, bonuses played out; measured before Luck Has Arrived was added)

`scripts/report-tigerdragon.mjs [stake] [spins]`, 3 million spins each:

| Stake | Simulated RTP (95% range) | Hit frequency | Std dev per spin | Highest return |
|---|---|---|---|---|
| 10p | 98.44% (±2.41%) | 1 in 2.49 | 21.3x | 2,000x |
| 50p | 98.26% (±2.42%) | 1 in 2.49 | 21.4x | 2,000x |
| £1 | 95.89% (±2.31%) | 1 in 2.49 | 20.4x | 2,000x |

All three are within their statistical range of the 96.28% theoretical value (the game is very volatile, so even 3 million spins leave ±2.4%).

Bonuses at £1: Tiger 1 in 238 spins, average 46.5x, pays more than the stake 47.7%, pays nothing 26.5%, median 0.9x, 90th percentile 57x, 99th 1,137x.
Dragon 1 in 234, average 40.7x, beats the stake 79.9%, pays nothing 4.1%, median 3.3x, 90th 64x, 99th 937x.
Tiger & Dragon 1 in 2,406, average 100.2x, beats the stake 65.4%, pays nothing 8.4%, median 2.1x, 90th 227x, 99th 1,937x. Mystery Gongs: 1 in 61 spins.

Return per spin (£1, including bonuses): 0x 59.8% · under 1x 24.3% · 1-2x 8.1% · 2-5x 6.6% · 5-10x 0.77% · 10-50x 0.30% · 50-100x 0.05% · 100-500x 0.05% · 500-2,000x 0.03% · 2,000x 1 in 32,609.

## Maths (estimated values, 6 million simulated spins plus 300,000 runs of each bonus)

Measured with `scripts/rtp-tigerdragon.mjs` (12 million base spins; each bonus
averaged over 300,000 runs):

| Part | How often | Average | Share of RTP |
|---|---|---|---|
| Ways wins | hit 1 in 2.5 spins (incl. Mystery Gongs) | | 45.3% |
| Mystery Gongs | after non-winning spins | | 9.7% to 11.0% (long tail) |
| Tiger Bonus | 1 in 235 spins | 46.3x | 19.7% |
| Dragon Bonus | 1 in 235 spins | 39.4x | 16.8% |
| Tiger & Dragon Bonus | 1 in about 2,400 spins | 96.2x | 4.0% |
| **Total** | | | **about 96% (95.5% to 96.7% across runs)** |

Bonus buys: random bonus (50x) returns 96.3%; Tiger & Dragon Bonus (100x) returns 96.2%.
The jackpot (32 gongs) comes up in about 1 in 785 Tiger & Dragon Bonuses.
How often each bonus pays nothing: Tiger about 27%, Dragon about 4%, Tiger & Dragon about 9%.
The max win of 2,000x is reached by long gong rows and the jackpot.

## Audio (all original, all free)

Levels were refined after the first version: one soft gong per column that lands gongs (not one per gong), quieter and darker landing gongs, a single gentle opening cue per bonus (no roars or extra gongs stacked on it), the bonus music only comes in after the intro, the near-completion riser plays once per bonus, and the announcer is quieter with lighter processing.

`client/audio/tigerdragon/` — `music/` (base, bonus, dragon loops; win and jackpot stings), `voice/` (one male announcer:
luck, tiger, dragon, combined, jackpot, bigwin, megawin) and `sfx/` (6 landing gongs, 2 big tam-tams and a soft one, lock, reset,
feature cues for Hold & Spin, Dragon, Luck Has Arrived, near-completion and completion, 3 reveal sizes, spin-used and
last-spin, tiger and dragon roars). Music and cues: FluidSynth with the FluidR3 Mono GM soundfont (MIT). Gongs and roars:
physical-model synthesis in Python. Voice: Kokoro-82M (Apache 2.0) with processing. None are IGT recordings.
Scripts are in `tools/music/`. The sound menu has separate Music, Sound effects and Announcer voice switches and sliders.

## Developer tools

Add `#dev` to the game URL (or set `localStorage.vb_dev = '1'`) for practice
buttons: Tiger, Dragon, Tiger & Dragon, 32-gong jackpot (every open spot
lands until 32 gongs), and Mystery Gongs. Practice rounds cost nothing and pay
nothing. Tests force exact outcomes through the engine's `inject` option.
