# Gong Fortune: mechanics, sources and test results

Gong Fortune reproduces the published rules of IGT's *Tiger and Dragon: Cash on
Reels* with original artwork, sound and an original name. All art is vector
artwork drawn for this game; no IGT assets were used. "Cash on Reels" is IGT
branding, so the in-game feature is called **Mystery Gongs**.

Code: `server/games/tigerdragon/` (engine, config, gongs, reels) and
`client/src/pages/premium/tigerdragon/`. Maths tools: `scripts/sim-tigerdragon.mjs`,
`scripts/tune-tigerdragon.mjs`, `scripts/rtp-tigerdragon.mjs`. Tests:
`test/tigerdragon.test.js`.

## Sources

- VegasSlotsOnline game page (specs, paytable, triggers, bonus rules, bonus buy).
- Ispinix review (cluster reading, Arrow examples, grid sizes, buy names).
- Casino Player Magazine, "Tigers, Dragons and Jackpots" (the land-based Cash on
  Reels version: adjacent numbers read as one number, Arrows nudge the first digit,
  Lock & Respin "can start with three or more gongs", top rows start locked).
- IGT's Cash on Reels page (gongs "horizontally adjacent", arrows "boost the leftmost numbers").

The playable demo needs a browser session these tools can't run, so rules were
taken from the written sources only.

## What is confirmed, interpreted or estimated

| Rule | Status | Implementation |
|---|---|---|
| 5 reels, 3 rows, 243 ways from the leftmost reel | Confirmed | `evaluateWays` |
| Bet range 0.75 to 90 | Confirmed | stakes £0.75 to £90 |
| RTP 96%, high volatility, max win 2,000x | Confirmed (targets) | tuned by simulation; 2,000x cap per spin and per bonus (trigger spin + bonus together) |
| Paytable: high (Envelope, Lotus, Lantern) 36/72/108, low (Fan, Bangle, Ornament) 18/54/90 at stake 90 | Confirmed | 0.40/0.80/1.20x and 0.20/0.60/1.00x of the stake, per way (linear scaling from the stake-90 figures is our reading) |
| No wild symbol | Confirmed by absence | none in any source |
| 3 Tigers: Tiger Bonus; 3 Dragons: Dragon Bonus; 5+ combined: Tiger & Dragon Bonus | Confirmed | combined takes priority (e.g. 3 Tigers + 2 Dragons) |
| Tiger Bonus: 3 spins, only gongs, gongs lock, reset to 3, ends at 0 or full grid, clusters of 2+ pay | Confirmed | 5 x 3 grid (grid size from Ispinix) |
| Dragon Bonus: exactly one spin on 5 x 8, clusters pay | Confirmed | no respin reset |
| Tiger & Dragon: 3 of 8 rows open; rows open at 6 / 9 / 14 / 19 / 25 gongs; new gongs reset to 3; 32 gongs win the jackpot | Confirmed | counts use every gong collected, including starting gongs |
| Bottom rows open first, top rows locked | Interpreted | "top rows start locked" (land-based description) |
| A row opened during a spin plays from the next spin | Interpreted | brief: "newly unlocked rows become available for subsequent spins" |
| Gong values 1 to 99 or an Arrow | Confirmed | |
| Cluster = 2+ gongs side by side in the same row | Confirmed ("horizontally adjacent") | vertical and diagonal neighbours do not connect: no source mentions them, so they don't |
| Cluster pays its numbers read left to right as one number | Confirmed (Ispinix: 8, 5, 0 reads 850; Casino Player: 1-5-5 pays $1.55) | |
| Arrow adds 1 to 90 to the cluster's leftmost number | Confirmed by examples (1 becomes 81: "125" to "8125"; 1 becomes 6: "120" to "620"; 5 becomes 10: "5350" to "10350") | an Arrow must be inside the cluster; several Arrows add up; a cluster of only Arrows pays nothing |
| Numbers are credits at 75 credits per spin | Interpreted | 0.75 minimum = 75 credits at 1p; a cluster pays credits x stake / 75 |
| Mystery Gongs only after a non-winning base spin | Confirmed | not after a ways win or a bonus trigger |
| Bonus buy: random bonus 50x, Tiger & Dragon 100x | Confirmed | |
| Bonuses start with gongs where the triggering Tigers/Dragons landed | Interpreted | the land-based Lock & Respin "can start with three or more gongs". Bought bonuses get 3 (Tiger) or 5 (combined) starting gongs on random spots. The Dragon Bonus starts empty. |
| Jackpot amount | **Not published** | set to 2,000x (the published max win); replaces cluster pays |
| Symbol weights, gong land chances, gong value odds, Arrow odds, Mystery Gong rate, random-buy split | **Not published** | estimated and tuned by simulation (marked `[EST]` in config.js) |
| "One or two of either can trigger randomly" (Ispinix) | Not implemented | unclear and unsupported by other sources |

## Maths (estimated values, 6 million simulated spins plus 300,000 runs of each bonus)

Measured with `scripts/rtp-tigerdragon.mjs` (12 million base spins; each bonus
averaged over 300,000 runs):

| Part | How often | Average | Share of RTP |
|---|---|---|---|
| Ways wins | hit 1 in 2.5 spins (incl. Mystery Gongs) | | 45.3% |
| Mystery Gongs | after non-winning spins | | 9.7% to 11.0% (long tail) |
| Tiger Bonus | 1 in 235 spins | 46.3x | 19.7% |
| Dragon Bonus | 1 in 235 spins | 39.4x | 16.8% |
| Tiger & Dragon Bonus | 1 in about 2,400 spins | 96.2x | 4.0% |
| **Total** | | | **about 96% (95.5% to 96.7% across runs)** |

Bonus buys: random bonus (50x) returns 96.3%; Tiger & Dragon Bonus (100x) returns 96.2%.
The jackpot (32 gongs) comes up in about 1 in 785 Tiger & Dragon Bonuses.
How often each bonus pays nothing: Tiger about 27%, Dragon about 4%, Tiger & Dragon about 9%.
The max win of 2,000x is reached by long gong rows and the jackpot.

## Developer tools

Add `#dev` to the game URL (or set `localStorage.vb_dev = '1'`) for practice
buttons: Tiger, Dragon, Tiger & Dragon, 32-gong jackpot (every open spot
lands until 32 gongs), and Mystery Gongs. Practice rounds cost nothing and pay
nothing. Tests force exact outcomes through the engine's `inject` option.
