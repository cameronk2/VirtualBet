# Bonus Buy – universal system, audit and test report

Virtual money only. Every slot with a real bonus round has a Bonus Buy button next to Spin. It opens a menu of
the bonuses that slot actually has, then a confirmation screen (cost, current balance, balance after).

## How it works

* **Price** = total bet × the option's cost multiplier. The server works it out from its own settings at the
  moment of purchase; the screen only shows it. Changing the bet changes the price.
* **The bonus is real.** A purchase plays that slot's own spin, with its own reels and weights, drawn until the
  spin triggers the feature that was bought (a conditional draw: every triggering spin is exactly as likely as
  it would be naturally). Its line wins and the whole bonus that follows are played and paid by the slot's own
  code, through the same screens as a natural trigger. Gong Fortune keeps its own purpose-built buy (it starts
  the bonus directly). No reel, paytable or bonus number changes because a bonus was bought.
* **Atomic and safe.** The debit, the triggering spin and the purchase record happen in one database transaction.
  Each purchase carries a one-time reference, so a repeated tap or resent request is refused and never charged
  twice. Purchases are refused with a bonus already in play, in practice mode, outside the bet range, for an
  option that is switched off, or without enough balance (nothing is taken).
* **Records.** Every purchase is stored (`bonus_buys`): slot, bonus, bet, multiplier, price, everything the bonus
  paid, status (in play / settled) and times. Players see them under Account → Bonus buys and in each game's
  menu; the game's own history marks the row as a Bonus Buy; the wallet line reads "<slot> – Bonus Buy: <bonus>".
* **Admin** (Account → Admin: Bonus Buy, for usernames listed in the `ADMIN_USERS` environment variable):
  switch Bonus Buy on or off globally, per slot and per option; set each cost multiplier; set the minimum and
  maximum bet; see purchases, money in and out, observed return per option, and the change log. Every saved
  change is validated on the server and logged with who made it.

## Adding a new slot

1. Add an adapter in `server/games/bonusbuy/adapters.js`: its options, how to recognise each feature in the
   slot's spin result (`match`/`matchAll`), `inBonus(state)` and, for pick or respin bonuses, `autoplay`.
2. Run `node scripts/sim-bonusbuy.mjs 20000 <game>` to price it, then `node scripts/bonusbuy-report.mjs`.
3. Put `<SpinBar buy={{ game, onBuy: (b) => { armBuy(b); spin(); } }} …>` (or `<BonusBuy …>`) next to its spin
   button. `armBuy` turns the page's next spin request into the purchase, so nothing else on the page changes.

## Prices and theoretical return

Average return = everything a bought bonus pays (its triggering spin plus the whole bonus), in multiples of the
bet, measured by playing that many purchases through the real engines. Default cost = average ÷ 0.96, rounded,
so each option returns about 96% (Gong Fortune keeps its published 50x and 100x prices).

| Slot | Bonus | Starts from | Default cost | Average return | RTP | Bonuses simulated |
| --- | --- | --- | --- | --- | --- | --- |
| Phoenix Ember Link | Area Link | 6+ Fireballs, a hatching egg or the Firestorm | 67x | 64.3x ± 1.32 | 96.0% | 20,000 |
| Phoenix Ember Link | Phoenix Firestorm | Phoenix Firestorm | 88x | 84.27x ± 1.33 | 95.8% | 20,000 |
| Gong Fortune | Random Bonus | Tiger, Dragon or combined bonus | 50x | 46.36x ± 1.4 | 92.7% | 20,000 |
| Gong Fortune | Tiger & Dragon Bonus | Tiger & Dragon Bonus | 100x | 94.47x ± 2.16 | 94.5% | 20,000 |
| Golden Wishes | Free Spins | 3+ Lamps | 44x | 41.87x ± 0.42 | 95.2% | 20,000 |
| Golden Wishes | Genie's Treasure | Genie's Treasure trigger | 92x | 88.24x ± 1.46 | 95.9% | 20,000 |
| Stampede Link | Hold & Spin | 6+ Cash symbols | 29x | 28.08x ± 0.46 | 96.8% | 20,000 |
| Stampede Link | Free Games | 3+ Coin scatters | 28x | 27.17x ± 0.65 | 97.0% | 20,000 |
| Brick by Brick | Hat Free Spins | Hard-hat trigger | 51x | 49.1x ± 0.63 | 96.3% | 20,000 |
| Brick by Brick | Saw Wheel | Saw trigger | 93x | 88.98x ± 1.39 | 95.7% | 20,000 |
| Mystery of the Mummy | Free Games | 3+ scatters | 49x | 47.45x ± 0.43 | 96.8% | 20,000 |
| Mystery of the Mummy | Cash Collect | Mummy with gems | 50x | 48.28x ± 0.36 | 96.6% | 20,000 |
| Moonridge | Free Spins | Triggered by 3+ Moon scatters | 58x | 55.77x ± 1.3 | 96.2% | 20,000 |
| Frostfang | Free Spins | Triggered by 3+ Moons | 24x | 23.31x ± 0.94 | 97.1% | 20,000 |
| Atlantis – Kingdom of the Deep | Treasure Chests | 3+ Chests | 65x | 62.19x ± 0.58 | 95.7% | 20,000 |
| Neon Overdrive | Overdrive Free Spins | Triggered by 3+ Overdrive symbols | 44x | 42.18x ± 0.43 | 95.9% | 20,000 |
| Dragon's Fortune | Free Spins | Triggered by 3+ Pearls | 20x | 19.31x ± 0.31 | 96.5% | 20,000 |
| Cosmic Collapse | Free Spins | Triggered by 4+ Black Holes | 87x | 83.15x ± 0.72 | 95.6% | 20,000 |
| Pharaoh's Gold | Free Spins | Triggered by 3+ Scarabs | 26x | 24.73x ± 0.18 | 95.1% | 20,000 |
| Starlight Observatory | Free Spins | Triggered by 3+ Telescopes | 90x | 85.99x ± 0.7 | 95.5% | 20,000 |
| Nebula Clusters | Free Spins | Triggered by 4+ scatters | 34x | 32.37x ± 0.23 | 95.2% | 20,000 |
| Coin Vault | Hold & Spin | 6+ coins | 191x | 183.6x ± 2.57 | 96.1% | 20,000 |

Not available: **fruit** – Fruit Shack has no bonus round: its holds and nudges are offered on ordinary spins. **polarcatch** – Polar Catch is a wheel game, not a slot: its fishing bonuses are bets on the wheel. Lakeside Lures (the
original slot on its own page) is not included yet: it runs on a separate older system.

## Test report

* `test/bonusbuy.test.js` (run with `npm test`): for every option on every slot it buys through the real
  casino handler and wallet, checks the price (bet × multiplier) at several bets, checks the bought spin really
  triggers that feature, plays the bonus to the end, checks the purchase record equals everything paid and the
  balance equals start − price + winnings, and checks the wallet ledger is continuous. It also checks: not
  enough balance (refused, nothing taken), duplicate reference, bonus already in play, negative / fractional /
  too-large bets, unknown option, a slot with no bonus, bets outside a slot's own list, admin-only settings,
  switching a slot off, an admin price change, the change log, and settings validation.
* Browser check (Chromium, iPhone-size screen) on all 16 slots: opened the menu, read the confirmation (price,
  balance, balance after), confirmed, and saw each slot's own bonus intro start, with the price taken from the
  balance and the purchase recorded. Admin page: changed a price, saved, saw it logged, reset.
* Natural spins are untouched: the full suite (including every slot's own tests) passes.
