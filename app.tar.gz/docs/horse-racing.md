# Horse Racing Lounge

A virtual horse racing section: a race every three minutes across eight fictional racecourses, races
on demand, real-time 3D broadcasts, fixed-odds betting with every common UK bet type, horse profiles,
leaderboards and statistics. Virtual credits only, using the site's existing wallet.

## What is real and what is virtual

Everything you can bet on is **virtual**: fictional horses, jockeys, trainers, owners, racecourses and
prize money, simulated on the server. Pages label it as virtual everywhere.

### Live video (researched November 2026)

* ITV Racing's free coverage (ITVX), racecourse channels (Racing TV, Sky Sports Racing) and official
  racecourse streams can't be embedded in other websites without a licence. There's no free, legally
  embeddable live UK racing feed.
* So **no live video is shown by default**. The player is built and ready: `RACING_STREAMS` (an environment
  variable on the server) accepts streams you are licensed to show, as JSON:
  `[{"name":"Course TV","course":"Example Park","type":"hls","url":"https://…/index.m3u8"}]`. Types are
  `hls`, `mp4` and `iframe`, and only https URLs are accepted. HLS plays natively on Safari, iOS and
  Android, and through hls.js (loaded only when needed) elsewhere. The player has live badge, course name,
  quality selection, full screen, loading, error and "stream unavailable" states.
* With no stream configured, the Live tab says so plainly and shows the virtual race that is running. It
  never presents a recording as live.

### Real race data (researched November 2026)

* The usual sources (The Racing API, Racing Post, Timeform and similar) are paid, and The Racing API's
  terms forbid use by betting sites. No free official UK racecard or results API was found.
* So the schedule is an **independent fictional timetable**. Real meetings and results are never
  invented or imitated.

## How a race works

`server/racing/core.js` is the engine, shared with the single-file build.

* **Horses**: 240 fictional horses, the same on every server (`server/racing/data.js`). Each has speed,
  stamina, acceleration, finishing, temperament, a running style, a preferred going, a coat, silks,
  trainer and owner. Runs, wins, places, form figures and (fictional) earnings are stored in `rc_horses`;
  every run is stored in `rc_runs`.
* **Cards**: race formats are sprint, sprint handicap, mile, middle distance, middle-distance handicap,
  long distance and championship. Distances run from 5f to 2m 2f, with fields of 6, 8, 10, 12 and 16.
  Fields are drawn from horses of similar class. Handicaps weight horses by rating.
* **The run**: the race is simulated every 0.15 s. Each horse:
  * reacts to the stalls (temperament);
  * accelerates (acceleration rating);
  * settles at a pace set by its speed rating, the going, its liking for the going, its weight and its
    running style;
  * tires according to its stamina and the distance;
  * finds a finishing kick in the last 320 m (finishing rating);
  * varies a little all the way (temperament).

  The finishing order is the order in which horses cross the line. Margins come from the time gaps, with
  dead heats when horses finish within 1 ms of each other.
* **One result for everything**: the run is stored as a trace (every horse's distance every 0.5 s). The
  same trace drives the 3D broadcast, the replay, the result table and bet settlement. A test checks
  that the trace order matches the result for every race.
* **Secure randomness**: outcomes use `crypto.randomInt` on the server. Scheduled races are run at the
  off and settled after the broadcast of the run has finished, so balances never spoil a race.

## Odds and bets

* **Prices**: each card is simulated about 500 times to find every horse's chance of winning and of
  placing. Win prices are the chance with a book of about 112–125%, rounded down to the usual fractional
  ladder (1/10 … 500/1). Odds can be shown as fractional or decimal (the player's choice). The price is
  fixed on the bet when it is placed.
* **Bet types**: Win, Each Way (win + place, two bets), Place, Forecast, Reverse Forecast (two bets),
  Tricast and Trio. Place terms follow the usual UK rules (configurable in `PLACE_TERMS`):
  * 5–7 runners: ¼ odds, 2 places;
  * 8–11 runners: ⅕ odds, 3 places;
  * 12–15 runners: handicaps ¼ odds, 3 places; other races ⅕ odds, 3 places;
  * 16+ runners: handicaps ¼ odds, 4 places; other races ⅕ odds, 3 places.
* **Dead heats**: the stake is divided by the number of horses sharing the paying places.
* **Exotic prices**: Forecast, tricast and trio prices come from the win chances with the Lo & Bacon-Shone
  discount for minor places, with a margin.
* **Theoretical returns** (`node scripts/sim-racing.mjs`, averaged over every possible selection):

  | Bet | Return |
  | --- | --- |
  | Win (the favourite) | about 86% |
  | Win (all horses, including outsiders) | about 65–70% |
  | Each way | about 83–90% |
  | Place | about 85% |
  | Forecast / Reverse Forecast | about 85–90% |
  | Tricast | about 80% |
  | Trio | about 85–90% |

* **Safety**: every bet is validated on the server:
  * selections must be different horses in the race;
  * the stake is 10p–£1,000 per bet, whole pence;
  * betting is open only before the off;
  * the player must have enough balance and be within their daily limit, and not on a break.

  Bets are placed in one database transaction with the debit. A one-time slip reference stops a repeated
  tap placing the bets twice.

## The 3D broadcast

`client/src/pages/racing/engine3d.js` uses Three.js r170 (MIT), vendored in `client/vendor/three`.

* **Horses**: Quaternius' animated horse (CC0, see `client/models/LICENSES.md`) with its Gallop, Walk and
  Idle animations, blended by speed. Each horse is recoloured to its coat.
* **Built in code**: jockeys in each horse's silks, saddle cloths, starting stalls that open at the off,
  rails, furlong poles, the winning post, grandstand, crowd, trees, hills, and each course's features
  (river, sea, castle, floodlights).
* **Cameras**: Director (automatic), broadcast, side-on tracking, jockey's view, overhead and finish line.
* **Replays and photo finish**: replays at 0.5×, 1× or 2×, or from the final furlong. Close finishes get a
  photo-finish still taken from the finish camera.
* **Quality**: Auto, HD, Lite (no shadows, fewer crowd and trees, lower resolution) and 2D. The 2D
  track view is also used automatically when WebGL isn't available. The 3D code loads only when a race is
  opened.

## Sound

`tools/music/racing.py`, free tools only:

* **Commentary**: Kokoro TTS, British male. Every horse's name is recorded, using Kokoro's British
  dictionary for pronunciation.
* **Crowd**: dozens of Kokoro voices murmuring and shouting, layered.
* **Effects**: hooves, gates, bell, shutter and fanfare, synthesised or played on FluidSynth.
* **Controls**: separate volumes for commentary, horses, crowd and interface, plus master and mute,
  saved per device. The commentary ducks the crowd and hooves. With sound off, the commentary shows as
  captions.

## API

| Method | Path | |
| --- | --- | --- |
| GET | `/api/racing` | Dashboard: next race, live, upcoming, today, results, courses, formats |
| GET | `/api/racing/races?status=upcoming\|results&course=` | Race lists |
| GET | `/api/racing/races/:id` | Racecard; with the run and result once it is off |
| POST | `/api/racing/quick` | Create a race on demand `{format, field, course?}` |
| POST | `/api/racing/races/:id/start` | Run your on-demand race |
| POST | `/api/racing/quote` | Price a slip |
| POST | `/api/racing/bets` | Place a slip `{raceId, bets:[{type,picks,stake}], nonce}` |
| GET | `/api/racing/bets?status=open\|settled\|all` | Your bets |
| GET | `/api/racing/stats` | Your racing statistics |
| GET | `/api/racing/leaderboard?period=week\|month\|all` | Profit, winners, biggest win, win % and most active |
| GET | `/api/racing/horses?q=`, `/api/racing/horses/:id` | Search and profiles |
| GET | `/api/racing/courses/:id` | Racecourse page |
| GET/POST | `/api/racing/favourites` | Favourite horses and courses |
| GET | `/api/racing/streams` | Authorised live streams (none by default) |

## Tests

`test/racing.test.js` covers:

* the horse database;
* each-way terms;
* every format and field size;
* the simulation, including that the trace agrees with the result;
* favourite calibration and margins;
* settlement of every bet type, including dead heats;
* bet validation;
* full flows through the real wallet: quick races with every bet type, refusals (balance, duplicates,
  other players' races, bad input), and the timetable (run at the off, nothing paid during the broadcast,
  settled after).
