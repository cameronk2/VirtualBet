# Phoenix Ember Link – mechanics, maths and assets

An original 5 × 3, 20-line hold-and-win slot with five egg upgrades, built for VirtualBet (virtual money only).
It is inspired by the "egg upgrade" style of Area Link games but uses none of their names, art, sounds or numbers.

## Code map

| Part | File |
| --- | --- |
| Tunable numbers (paytable, strips, chances, jackpots, stakes) | `server/games/phoenix/config.js` |
| Reel strips, Fireball draws, 20-line evaluation | `server/games/phoenix/reels.js` |
| Area Link bonus manager (arrays, respins, all five upgrades, settlement) | `server/games/phoenix/bonus.js` |
| Game flow and state (lit eggs, triggers, Firestorm, practice rounds) | `server/games/phoenix/engine.js` |
| Screen, animations, sound cues | `client/src/pages/premium/phoenix/Phoenix.jsx`, `.ph-*` rules in `client/src/styles.css` |
| Art | `client/src/assets/phoenix/` (built by `tools/art/phoenix_build.py`) |
| Audio | `client/audio/phoenix/{music,sfx,voice}/` (built by `tools/music/phoenix.py`) |
| Simulator | `scripts/sim-phoenix.mjs` |
| Tests | `test/phoenix.test.js` |

The server is authoritative: every spin and respin is decided by `act()` with the server's cryptographic
RNG (`crypto.randomInt`), inside a database transaction that also moves the money. The client only animates
the result it is given. A bonus in progress is stored with the player's game state, so refreshing resumes it
and a spin can't be placed until it has finished. Each respin is one request; the prize is paid once, when
the last array stops.

## Base game

* 5 reels × 3 rows, 20 fixed lines, wins left to right from reel 1, 3+ in a row; the best win per line pays.
* Bets: 20p, 50p, £1, £2, £5, £10 (total stake). Every pay and prize is a multiple of the stake.
* Phoenix Wild: reels 2–5 only, in stacks of three; substitutes for every paying symbol, never for a Fireball.
* Any visible spot can become a Fireball (11.5% each). A Fireball carries a cash prize (1x–8x) or a jackpot
  label (Mini 10x, Minor 20x, Major 100x).
* Fireball colours: Yellow 87%, Orange 2.8%, Magenta 2.0%, Red 2.6%, Blue 2.8%, Green 2.8%.

### Eggs (random, nothing builds up)

A coloured Fireball lights the egg of its colour for that spin. Each coloured Fireball has a 0.5% chance to
hatch its egg and start Area Link on the spot, even with fewer than 6 Fireballs. Nothing is carried from one
spin to the next, so every spin has the same chances (this replaced an earlier collect-and-fill design).

### Triggers

* 6+ Fireballs: Area Link.
* An egg hatches (above): Area Link.
* Phoenix Firestorm: on any spin with at least one Fireball, a 0.19% chance (about 1 spin in 620). The Phoenix
  sweeps across the screen and Area Link starts at once (with at least 3 Fireballs) with 1–5 random upgrades
  (34/34/20/9/3%), so all five together is possible.
* Whatever starts Area Link, every egg lit on the reels adds its upgrade.

## Area Link

Each array is 5 × 3. The trigger Fireballs lock where they landed (as Yellow prizes). 3 respins; each empty spot
lands a Fireball with chance 5.2%. A landing resets that array's counter to 3; otherwise it drops by 1; the array
stops at 0. Filling all 15 spots wins the **Grand (5,000x)** on top of the prizes. The feature pays when every
array has stopped: the sum of every locked prize, plus a Grand per full array.

Upgrades are applied by one bonus manager in a fixed order on every respin:

1. **Orange – Multiplier**: a 2x / 3x / 5x (60/30/10%) multiplier is drawn; Yellow cash prizes that lock on that
   respin are multiplied (jackpots are not).
2. **Green – Prize Increase**: Green Fireballs (10% of landings while active) grow by 1x–10x every respin after
   they land; growth accumulates and is never reset.
3. New Fireballs land.
4. **Blue – Prize Boost**: Blue Fireballs (9% of landings) add their prize to 1–5 random Yellow cash prizes
   (picked with replacement, so one prize can be boosted more than once), then turn Yellow.
5. **Red – Instant Collect**: Red Fireballs (7% of landings) add up every other prize on their array (cash,
   jackpots and Greens) and take the total as their own prize, then turn Yellow. Collected prizes stay where they
   are and are paid once; the Red total is one new prize. Reds landing together don't collect each other.
6. **Magenta – Second Array**: a second array (starting with 3 Fireballs) plays alongside, with its own counter,
   its own Grand and its own prizes. Both must stop before the feature ends.

Any combination of the five works (all 31 are covered by the tests).

## Return to player

Design target 96.45%. Measured by `node scripts/sim-phoenix.mjs <spins> <seed> <stake> <volatility> <rtp>`, which
plays the real engine. The random-egg version of the game was tuned over 100 million simulated spins at £1
(medium volatility); the final setting (land chance 4.93%) measured 96.10% in its own 20-million-spin run, and a
straight-line fit across all five tuning runs puts it at about 96.4%. Each 20M-spin run carries roughly ±0.4%
of noise because the 5,000x Grand is rare.

| Measure | Result (final setting, 20M spins) |
| --- | --- |
| RTP | 96.1% measured, ~96.4% fitted (target 96.45%) |
| Base game / Area Link | 48.9% / 47.1% |
| Hit rate | 27.4% |
| Area Link | 1 in 137 spins (146,000 bonuses simulated), average 64.7x stake |
| Phoenix Firestorm | 1 in 622 spins |
| Upgrades per Area Link | none 27%, 1: 45%, 2: 18%, 3: 6.4%, 4: 2.6%, 5: 1.2% |
| Jackpots | Mini 1 in 311 spins, Minor 1 in 960, Major 1 in 7,000, Grand 1 in 96,000 |
| Biggest win seen | 5,490x |
| Spin-to-spin standard deviation | about 17.7x stake |

Profiles (environment variables): `PHOENIX_RTP` = 96 / 94 / 92 (94 and 92 measured 94.2% and 92.3% over 4M
spins); `PHOENIX_VOLATILITY` = low / medium / high, which moves weight between small Fireball prizes and the
jackpots, with the land chance re-tuned per profile (low measured 96.1% over 6M spins; high re-tuned after a
6M-spin run and should be re-checked with a long run before use).

## Assets and tools (all free, nothing paid)

* **Images**: Stable Diffusion 1.5 (open weights, CreativeML OpenRAIL-M licence, commercial use allowed) run
  locally on CPU with onnxruntime. Prompts and seeds are in `/home/claude/sd/gen/jobs*.json` on the build
  machine. Cut-outs (OpenCV GrabCut), recolouring (gradient maps for the Fireballs, hue tinting for the eggs),
  the royals and the logo lettering (Caladea font, SIL OFL) and the 3D finish (`tools/art/paint.py`) are local
  scripts.
* **Music**: FluidSynth with the FluidR3 Mono GM soundfont (MIT).
* **Effects**: synthesised with numpy/scipy (fire crackle and roar, whooshes, impacts, chimes, the phoenix cry)
  mixed with FluidSynth orchestra parts.
* **Voice**: Kokoro-82M (Apache 2.0) text-to-speech through onnxruntime, processed with ffmpeg.
